//
//  AppDelegate.m
//  MCU
//
//  Created by Chen Jin on 5/30/16.
//  Copyright (c) 2016 Bojay. All rights reserved.
//

#import "AppDelegate.h"
#import <dirent.h>

#define WR_FOR_OK(x)    {if([self write_then_readFor_Ok:x]<0) break;}

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    //初始化
    _logString = [[NSMutableString alloc] init];
    _isopen = NO; //判斷接口是否連通
    _isLooping = NO;
//    [_close_button setEnabled:NO];
    [_dut_pop selectItemAtIndex:1];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    MCUclose();
    return YES;//關閉 window 后應用消失
}

-(void)showlog:(NSString *)str{
    [self performSelectorOnMainThread:@selector(refreshLog:) withObject:str waitUntilDone:YES];//在主線程中執行 selector 更新 UI
}

-(void)refreshLog:(NSString *)str{
    if (_logString.length > 100*1024) [_logString setString:@""];//判斷 log 上面存放的內容是否過多
    [_logString appendString:str];
    [_log_view setString:_logString];
    [_log_view scrollToEndOfDocument:nil];
}

//cmd is the command from user
//read the return from MCU
-(int)write_then_read:(char *)cmd{
    int ret = -1;
    if (!_isopen){
        [self showlog:@"port not opend\n"];
        return ret;
    }
    
    ret = MCUwrite(cmd);//cmd
    NSString *log = [NSString stringWithFormat:@"write command : %s\n",cmd];
    [self showlog:log];
    
    usleep(DELAY_TIME);
    char readbuffer[BUFFER_SIZE] = {0};
    ret = MCUread(readbuffer, BUFFER_SIZE);
    if (ret < 0)[self showlog:@"read failed\n"];
    
    NSString *temp = [NSString stringWithFormat:@"%s",readbuffer];
    [self showlog:temp];
    return ret;

}

-(int)write_then_readFor_Ok:(char *)cmd{
    int ret = -1;
    if (!_isopen){
        [self showlog:@"port not opend\n"];
        return ret;
    }
    
    ret = MCUwriteForuSeconds(cmd, TIMEOUT);//判斷返回的結果以及是否超時
    NSString *log = [NSString stringWithFormat:@"write command : %s\n",cmd];
    [self showlog:log];
    
    NSString *temp ;
    switch (ret) {
        case 0:
            temp = @"read : ok\n";
            break;
        case -1:
            temp = @"read failed\n";
            break;
        case -2:
            temp = @"write command failed \n";
            break;
        case -3:
            temp = @"invalid command \n";
            break;
        case -4:
            temp = @"read timeout\n";
            break;
        default:
            temp=@"";
            break;
    }
    [self showlog:temp];
    return ret;
}

//自定義的超時時間
-(int)write_then_readFor_Ok:(char *)cmd utime:(int)timeout{
    int ret = -1;
    if (!_isopen){
        [self showlog:@"port not opend\n"];
        return ret;
    }
    
    ret = MCUwriteForuSeconds(cmd, timeout);
    NSString *log = [NSString stringWithFormat:@"write command : %s\n",cmd];
    [self showlog:log];
    
    NSString *temp ;
    switch (ret) {
        case 0:
            temp = @"read : ok\n";
            break;
        case -1:
            temp = @"read failed\n";
            break;
        case -2:
            temp = @"write command failed \n";
            break;
        case -3:
            temp = @"invalid command \n";
            break;
        case -4:
            temp = @"read timeout\n";
            break;
        default:
            temp=@"";
            break;
    }
    [self showlog:temp];
    return ret;
}

-(int)readForStart{
    int ret = -1;
    if (!_isopen){
        [self showlog:@"port not opend\n"];
        return ret;
    }
    
    [self showlog:@"read for test start\n"];
    ret = MCUreadStart();
    
    NSString *temp;
    if (ret==0) temp = @"read for test start : ok\n";
    else temp = @"read for test start : failed\n";
    [self showlog:temp];
    return ret;
}

- (IBAction)refreshPort:(id)sender {
    [_port_pop removeAllItems];
    NSMutableArray *arr= [[NSMutableArray alloc] init];
    struct dirent *ptr;
    DIR *dir;
    dir = opendir("/dev/");//用来打开参数name指定的目录，并返回DIR*形态的目录流，和open()类似，接下来对目录的读取和搜索都要使用此返回值
    
    // readdir()返回参数dir目录流的下个目录进入点
    while ((ptr=readdir(dir))!=NULL) {
        //strstr:返回字符串中首次出现子串的地址-->尋找子串
        if (strstr(ptr->d_name, "cu.usb")) {
            [arr addObject:[NSString stringWithFormat:@"/dev/%s",ptr->d_name]];
        }
    }
    [_port_pop addItemsWithObjectValues:arr];
    if(arr.count>1)[_port_pop selectItemAtIndex:0];
}

- (IBAction)open:(id)sender {
    char *device = (char *)[[_port_pop stringValue] UTF8String];//當前選擇的端口
    int ret = MCUopen(device);//打開端口
    if (ret == 0) {
        [_open_button setEnabled:NO];
        [_refresh_button setEnabled:NO];
        [_port_pop setEnabled:NO];
        _isopen = YES;
    }
}

- (IBAction)close:(id)sender {
    MCUclose();
    [_open_button setEnabled:YES];
    [_refresh_button setEnabled:YES];
    [_port_pop setEnabled:YES];
//    [_close_button setEnabled:NO];
    _isopen = NO;
}

- (IBAction)send:(id)sender {
    char *str = (char *)[[_command_field stringValue] UTF8String];//獲取發送的 NSTextField 上的內容
    if (strcmp(str, "")==0) return;
    [self write_then_read:str];
}

- (IBAction)teststart:(id)sender {
    [self write_then_readFor_Ok:TEST_START utime:0];
}

- (IBAction)testfinish:(id)sender {
    if ([self write_then_readFor_Ok:MAGLOCK_DISABLE]<0) return;
    [self write_then_readFor_Ok:TEST_FINISH];
}

- (IBAction)maglockEnable:(id)sender {
    [self write_then_readFor_Ok:MAGLOCK_ENABLE];
}

- (IBAction)maglockDisable:(id)sender {
    [self write_then_readFor_Ok:MAGLOCK_DISABLE];
}

- (IBAction)shutterEnable:(id)sender {
    if ([self write_then_readFor_Ok:SHUTTER_ENABLE utime:TIMEOUT_S]<0) {
        [self write_then_readFor_Ok:SHUTTER_DISABLE];
    }
}

- (IBAction)shutterDisable:(id)sender {
    [self write_then_readFor_Ok:SHUTTER_DISABLE];
}

- (IBAction)lampon:(id)sender {
    [self write_then_readFor_Ok:LAMP_ON];
}

- (IBAction)lampoff:(id)sender {
    [self write_then_readFor_Ok:LAMP_OFF];
}

- (IBAction)cpcup:(id)sender {
    if ([self write_then_readFor_Ok:CPC_UP utime:TIMEOUT_S]<0) {
        [self write_then_readFor_Ok:CPC_DOWN];
    }
}

- (IBAction)cpcdown:(id)sender {
    [self write_then_readFor_Ok:CPC_DOWN];
}

- (IBAction)cpc36:(id)sender {
    [self write_then_readFor_Ok:CPC_ROTATE_36];
}

- (IBAction)cpcOriginal:(id)sender {
    [self write_then_readFor_Ok:CPC_ROTATE_ORIGINAL];
}

- (IBAction)drawerP1:(id)sender {
    NSInteger index = [_dut_pop indexOfSelectedItem];
    char *cmd;
    switch (index) {
        case 0:
            cmd = DRAWER_P1_SMALL;
            break;
        case 1:
            cmd = DRAWER_P1_LARGER;
            break;
        default:
            cmd = DRAWER_P1_SMALL;
    }
    [self write_then_readFor_Ok:cmd];
    [self write_then_readFor_Ok:DRAWER_ORIGINAL];
}

- (IBAction)drawerP2:(id)sender {
    NSInteger index = [_dut_pop indexOfSelectedItem];
    char *cmd;
    switch (index) {
        case 0:
            cmd = DRAWER_P2_SMALL;
            break;
        case 1:
            cmd = DRAWER_P2_LARGER;
            break;
        default:
            cmd = DRAWER_P2_SMALL;
    }
    [self write_then_readFor_Ok:cmd];
}

- (IBAction)drawerOriginal:(id)sender {
    [self write_then_readFor_Ok:DRAWER_ORIGINAL];
}

- (IBAction)help:(id)sender {
    [self write_then_read:HELP];
}

- (IBAction)version:(id)sender {
    [self write_then_read:VERSION];
}

- (IBAction)start_all:(id)sender {
    if (_isLooping) return;
    _isLooping = YES;
    [_start_button setEnabled:NO];
    NSInteger index = [_dut_pop indexOfSelectedItem];//區分 large/small 型號
    //兩個位置的控制語句
    char *p1;
    char *p2;
    switch (index) {
        case 0:
            p1 = DRAWER_P1_SMALL;
            p2 = DRAWER_P2_SMALL;
            break;
        case 1:
            p1 = DRAWER_P1_LARGER;
            p2 = DRAWER_P2_LARGER;
            break;
        default:
            p1 = DRAWER_P1_SMALL;
            p2 = DRAWER_P2_SMALL;
    }
    
    //DISPATCH_QUEUE_CONCURRENT:生成一个并发执行队列，對應block被分发到多个线程去执行
    dispatch_queue_t concurrentQueue = dispatch_queue_create("loop.queue", DISPATCH_QUEUE_CONCURRENT);
    //異步執行，函数立即返回,讓 end 可以控制
    dispatch_async(concurrentQueue, ^(){
        while (_isLooping) {
            int loop_times = [_times_field intValue];
            if (loop_times <= 0)break;

            WR_FOR_OK(FANS_ON);
            WR_FOR_OK(CPC_ROTATE_ORIGINAL);
            WR_FOR_OK(LAMP_ON);
//            if([self readForStart]<0)break;
            WR_FOR_OK(MAGLOCK_ENABLE);
            WR_FOR_OK(p1);
            WR_FOR_OK(DRAWER_ORIGINAL);
            
            if ([self write_then_readFor_Ok:SHUTTER_ENABLE utime:TIMEOUT_S]<0) {
                WR_FOR_OK(SHUTTER_DISABLE);
            }
            for (int i=0 ; i<10; i++) {
//                WR_FOR_OK(CPC_UP);
//                WR_FOR_OK(SHUTTER_ENABLE);
                if ([self write_then_readFor_Ok:CPC_UP utime:TIMEOUT_S]<0) {
                    WR_FOR_OK(CPC_DOWN);
                }
//                if ([self write_then_readFor_Ok:SHUTTER_ENABLE utime:TIMEOUT_S]<0) {
//                    WR_FOR_OK(SHUTTER_DISABLE);
//                }
                sleep(2);
                [self showlog:@"test 1\n"];
//                WR_FOR_OK(SHUTTER_DISABLE);
                WR_FOR_OK(CPC_DOWN);
                if(i<9)WR_FOR_OK(CPC_ROTATE_36);
                usleep(500000);
            }
            WR_FOR_OK(SHUTTER_DISABLE);
            
            WR_FOR_OK(CPC_ROTATE_ORIGINAL);
            WR_FOR_OK(p2);
            [self showlog:@"test 2\n"];

            WR_FOR_OK(DRAWER_ORIGINAL);
            WR_FOR_OK(MAGLOCK_DISABLE);
//            WR_FOR_OK(TEST_FINISH);
            WR_FOR_OK(LAMP_OFF);
            WR_FOR_OK(FANS_OFF);
            
            loop_times--;
            [_times_field setIntValue:loop_times];
        }
        _isLooping = NO;
        [_start_button setEnabled:YES];
    });
    
}

- (IBAction)end:(id)sender {
    _isLooping = NO;
}

- (IBAction)fanson:(id)sender {
    [self write_then_readFor_Ok:FANS_ON];
}

- (IBAction)fansoff:(id)sender {
    [self write_then_readFor_Ok:FANS_OFF];
}

@end

















