//
//  main.m
//  MCU
//
//  Created by Chen Jin on 5/30/16.
//  Copyright (c) 2016 Bojay. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
