//
//  SerialPort.c
//  test
//
//  Created by Chen Jin on 3/8/16.
//  Copyright (c) 2016 Bojay. All rights reserved.
//

#include "SerialPort.h" //實現 h 文件裡面的函數
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

int serial_fd = -1; //控制位


int openPort(char *devicePath,Baudrate baudrate,Databits databits,StopBits stopbits,Parity parity,FlowControls flows){
    if(serial_fd != -1)return 0;
    
    serial_fd = open(devicePath, O_RDWR|O_NOCTTY|O_NDELAY|O_NONBLOCK);
    if(serial_fd < 0 ){
        printf("SerialPort : open port %s failed \n",devicePath);
        return serial_fd;
    }
    
    if(setBaudrate(baudrate)){
        printf("SerialPort : set boudrate failed \n");
        closePort();
        return -1;
    }
    if (setDatabits(databits)) {
        printf("SerialPort : set datebits failed \n");
        closePort();
        return -1;
    }
    if (setStopbits(stopbits)) {
        printf("SerialPort : set stopbits failed \n");
        closePort();
        return -1;
    }
    if (setParity(parity)) {
        printf("SerialPort : set parity failed \n");
        closePort();
        return -1;
    }
    if (setFlowcontrol(flows)) {
        printf("SerialPort : set flowcontrol failed \n");
        closePort();
        return -1;
    }
    return 0;
}

void closePort(){
    if (serial_fd < 0 )return;
    close(serial_fd);
    serial_fd = -1;
}

int isOpen(){
    if (serial_fd < 0) return -1;
    else return 0;
}

int readLine(char *buffer,int size){
    if (serial_fd < 0) return -1;
    //read:參數1:要讀取的文件描述符 int
    //存儲讀取內容緩衝區，同时文件的当前读写位置向后移
    return (int)read(serial_fd, buffer, size);
}

//按長度寫入
int writeLine(char *buffer){
    if(serial_fd < 0 )return -1; //先確保MCU和 Mini接通
    
    size_t size = strlen(buffer);//计算给定字符串的（unsigned int型）长度，不包括'\0'在内
    //write:參數1:要寫入的文件描述符 int
    // 參數2：取讀取內容的緩衝區
    // 參數3：寫入的長度--在內容中取
    // 返回：返回實際寫入的字節數 或者 -1
    size_t ret = write(serial_fd, buffer,size);
    return (int)ret;
}

int  setBaudrate(Baudrate baudrate){
    if(serial_fd < 0 )return -1;
    
    switch (baudrate)
    {
        case B50:
        case B75:
        case B110:
        case B134:
        case B150:
        case B200:
        case B300:
        case B600:
        case B1200:
        case B1800:
        case B2400:
        case B4800:
        case B9600:
        case B19200:
        case B38400:
        case B57600:
        case B115200:
        case B230400:
        {
            struct termios term_setting;
            
            if( -1 == tcgetattr(serial_fd, &term_setting) )//tcgetattr初始化一个终端对应的termios结构
            {
                return -1;
            }
            //
            // Modify the baud rate in the term_setting structure.
            //
            cfsetispeed( &term_setting, baudrate);
            cfsetospeed( &term_setting, baudrate );
            term_setting.c_cflag |= CREAD; //按位或操作  启用字符接收器
            term_setting.c_iflag |= CRTS_IFLOW;
            term_setting.c_iflag |= CDTR_IFLOW;
            //            term_setting.c_oflag |= CDSR_OFLOW;
            //            term_setting.c_oflag |= CCAR_OFLOW;
            
            if( -1 == tcsetattr(serial_fd, TCSANOW, &term_setting) )
            {
                return -1;
            }
            break ;
        }
        default:
            return -1;
            break;
    }
    return 0;//if 0 為假
}

int  setDatabits(Databits databits){
    if(serial_fd < 0 )return -1;
    struct termios term_setting ;
    switch(databits)
    {
        case DATABITS_5:
        case DATABITS_6:
        case DATABITS_7:
        case DATABITS_8:
            if( -1 == tcgetattr(serial_fd, &term_setting))
            {
                return -1 ;
            }
            if( databits == DATABITS_8 )
            {
                term_setting.c_iflag &= ~ISTRIP ; // clear the ISTRIP flag.
            }
            else
            {
                term_setting.c_iflag |= ISTRIP ;  // set the ISTRIP flag.
            }
            //输入模式控制输入数据在传递给程序之前的处理方式 c_iflag
            //控制模式控制终端的硬件特性,通过c_cflag成员标识配置.
            term_setting.c_cflag &= ~CSIZE ;     // clear all the CSIZE bits.
            term_setting.c_cflag |= databits ;  // set the character size.
            
            if( -1 == tcsetattr(serial_fd, TCSANOW, &term_setting) )
            {
                return -1 ;
            }
            break ;
        default:
            return -1;
            break;
    }
    return 0;

}

int  setStopbits(StopBits stopbits){
    if (serial_fd < 0) return -1;
    
    struct termios term_setting ;
    
    if( -1 == tcgetattr(serial_fd, &term_setting) )
    {
        return -1;
    }
    
    switch( stopbits )
    {
        case StopBits_1:
            term_setting.c_cflag &= ~CSTOPB ;
            break ;
        case StopBits_2:
            term_setting.c_cflag |= CSTOPB ;
            break ;
        default:
            return  -1;
            break ;
    }
    if( -1 == tcsetattr(serial_fd, TCSANOW, &term_setting) )
    {
        return -1;
    }
    return 0;

}

int  setParity(Parity parity){
    if (serial_fd < 0) return -1;
    
    struct termios term_setting ;
    
    if( -1 == tcgetattr(serial_fd, &term_setting) )
    {
        return -1 ;
    }
    switch(parity)
    {
        case PARITY_NONE:
            term_setting.c_cflag &= ~PARENB ;
            break ;
        case PARITY_ODD:
            term_setting.c_cflag |= PARENB ;
            term_setting.c_cflag |= PARODD ;
            break ;
        case PARITY_EVEN:
            term_setting.c_cflag |= PARENB ;
            term_setting.c_cflag &= ~PARODD ;
            break ;
        default:
            return -1 ;
            break;
    }
    if( -1 == tcsetattr(serial_fd, TCSANOW, &term_setting) )
    {
        return -1 ;
    }
    return 0;
}

int  setFlowcontrol(FlowControls flow){
    if (serial_fd < 0) return -1;
    //清空终端未完成的输入/输出请求及数据。
    // TCIFLUSH  // 清除正收到的数据，且不会读取出来。
    //TCIOFLUSH // 清除所有正在发生的I/O数据。
    if( -1 == tcflush(serial_fd, TCIOFLUSH) ) return -1;
    
    struct termios tset;
    int retval = tcgetattr(serial_fd, &tset);
    if (-1 == retval) return -1;
    //
    // Set the flow control. Hardware flow control uses the RTS (Ready
    // To Send) and CTS (clear to Send) lines. Software flow control
    // uses IXON|IXOFF
    switch (flow)
    {
        case FLOW_CONTROL_NONE:
            tset.c_iflag &= ~(IXON|IXOFF);
            tset.c_cflag &= ~CRTSCTS;
            break;
        case FLOW_CONTROL_HARD:
            tset.c_iflag &= ~ (IXON|IXOFF);
            tset.c_cflag |= CRTSCTS;
            tset.c_cc[VSTART] = _POSIX_VDISABLE;
            tset.c_cc[VSTOP] = _POSIX_VDISABLE;
            break;
        case FLOW_CONTROL_SOFT:
            tset.c_iflag |= IXON|IXOFF;
            tset.c_cflag &= ~CRTSCTS;
            tset.c_cc[VSTART] = 0x11;
            tset.c_cc[VSTOP]  = 0x13;
        default:
            return -1;
            break;
    }
    retval = tcsetattr(serial_fd, TCSANOW, &tset);
    if (-1 == retval)
    {
        return -1 ;
    }
    return 0;
}



