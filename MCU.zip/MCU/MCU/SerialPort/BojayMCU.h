//
//  BojayMCU.h
//  
//
//  Created by Chen Jin on 5/30/16.
//
//

#ifndef ____BojayMCU__
#define ____BojayMCU__

#define LINE_END                "\r\n"
#define SMALL_DUT               "SMALL DUT"
#define LARGER_DUT              "LARGER DUT"
#define TEST_START              "TEST START"
#define TEST_FINISH             "TEST FINISH"

#define LAMP_ON                 "LAMP ON"
#define LAMP_OFF                "LAMP OFF"
#define MAGLOCK_ENABLE          "MAGLOCK ENABLE"
#define MAGLOCK_DISABLE         "MAGLOCK DISABLE"

#define FANS_ON                 "FANS ON"
#define FANS_OFF                "FANS OFF"

#define DRAWER_P1_SMALL         "DRAWER MOTOR ROTATE TO POSITION 1_SMALL DUT"
#define DRAWER_P2_SMALL         "DRAWER MOTOR ROTATE TO POSITION 2_SMALL DUT"
#define DRAWER_P1_LARGER        "DRAWER MOTOR ROTATE TO POSITION 1_LARGER DUT"
#define DRAWER_P2_LARGER        "DRAWER MOTOR ROTATE TO POSITION 2_LARGER DUT"
#define DRAWER_ORIGINAL         "DRAWER MOTOR ROTATE TO ORIGINAL"

#define CPC_UP                  "CPC LIGHT ISOLATOR UP"
#define CPC_DOWN                "CPC LIGHT ISOLATOR DOWN"
#define CPC_ROTATE_36           "CPC MOTOR ROTATE 36 DEGREE"
#define CPC_ROTATE_ORIGINAL     "CPC MOTOR ROTATE TO ORIGINAL"

#define SHUTTER_ENABLE          "SHUTTER ENABLE"
#define SHUTTER_DISABLE         "SHUTTER DISABLE"

#define INVALID_COMMAND         "This command is illegal, please check it again."
#define OK                      "OK"
#define FAIL                    "FAIL"
#define HELP                    "HELP"
#define VERSION                 "VERSION"

#define TIMEOUT                 20000000
#define TIMEOUT_S               5000000
#define BUFFER_SIZE             1024
#define DELAY_TIME              300000

#include <stdio.h>

int MCUopen(char *devicePath);
int MCUisOpen();
void MCUclose();
int MCUwrite(char *buffer);
int MCUwriteForuSeconds(char *buffer,int usecond);
int MCUread(char *buffer,int size);
int MCUreadStart();


#endif /* defined(____BojayMCU__) */
