//
//  BojayMCU.c
//  
//
//  Created by Chen Jin on 5/30/16.
//
//

#include "BojayMCU.h"
#include "SerialPort.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>


int MCUopen(char *devicePath)
{
    return openPort(devicePath, B115200, DATABITS_8, StopBits_1, PARITY_NONE, FLOW_CONTROL_NONE);
}

int MCUisOpen(){
    return isOpen();
}

void MCUclose(){
    return closePort();
}

int MCUwrite(char *buffer){
    char strBuffer[BUFFER_SIZE] = {0};
    strcat(strBuffer, buffer);//連接兩個 char 字符串 把buffer 放到緩衝區，然後寫進文件描述符對應的地方
    strcat(strBuffer, LINE_END);
    return writeLine(strBuffer);
}

int MCUread(char *buffer,int size){
    return readLine(buffer, size);
}

int MCUreadStart(){
    if (MCUisOpen()) return -1;
    
    char readbuffer[BUFFER_SIZE] ={0};
    MCUread(readbuffer, BUFFER_SIZE);
    
    while (1) {
        int ret = MCUwrite(TEST_START);
        if (ret < 0 ) return -1;
        usleep(DELAY_TIME);
        char cbuffer[BUFFER_SIZE]={0};
        int cret = MCUread(cbuffer, sizeof(cbuffer));
//        if (cret < 0) return -1;
        if (strstr(cbuffer, OK""LINE_END)) return 0;//判断字符串str2是否是str1的子串。如果是，则该函数返回str2在str1中首次出现的地址；否则，返回NULL。
        if (MCUisOpen()) return -1;
    }
}

int MCUwriteForuSeconds(char *buffer,int usecond){
    if (MCUisOpen()) return -1; //要接上，為真就是不為0
    //清空MCU缓存数据
    char readbuffer[BUFFER_SIZE] ={0};
    MCUread(readbuffer, BUFFER_SIZE);//讀 0 個字節到緩衝區
    
    int ret = MCUwrite(buffer);
    if (ret < 0 ) return -2;
    
    struct timeval start,end;
    gettimeofday(&start, NULL);//gettimeofday()会把目前的时间用tv(timeval) 结构体返回
    
    while (1) {
        usleep(DELAY_TIME);
        char cbuffer[BUFFER_SIZE]={0};
        int cret = MCUread(cbuffer, sizeof(cbuffer));//讀取 到cbuffer數組
//        if (cret < 0) return -1;
        char realBuffer[BUFFER_SIZE]={0};
        sprintf(realBuffer, "%s%s%s%s",buffer,LINE_END,OK,LINE_END);//把格式化的数据写入某个字符串中
        
        //單片機判斷返回的字符串
        if (strstr(cbuffer, INVALID_COMMAND""LINE_END)) return -3;
        if (strstr(cbuffer, OK""LINE_END)) return 0;
        if (strstr(cbuffer,FAIL""LINE_END)) return -1;
        
        gettimeofday(&end, NULL);
        long cost_time = (end.tv_sec-start.tv_sec)*1000000 + end.tv_usec-start.tv_usec;//微妙
        if (cost_time >= usecond) return -4;//超時未返回結果
    }
    return 0;
}




