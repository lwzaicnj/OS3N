//
//  XMLUtil.m
//  XML
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "XMLUtil.h"

static XMLUtil *_instance;

@implementation XMLUtil

+ (instancetype)shareXML{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        _instance = [[XMLUtil alloc]init];
    });
    return _instance;
}

- (instancetype)init{
    
    if (self) {
        //獲取 xml 文件
        NSString *xmlPath = [[NSBundle mainBundle] pathForResource:@"Students" ofType:@"xml"];
        NSData *data = [NSData dataWithContentsOfFile:xmlPath];
        
        self.par = [[NSXMLParser alloc]initWithData:data];
        //添加代理
        self.par.delegate = self;
        
        //初始化數組
        self.list = [NSMutableArray arrayWithCapacity:5];
        
    }
    return self;
}

#pragma mark -代理方法實現
- (void)parserDidStartDocument:(NSXMLParser *)parser{
    
    NSLog(@"parserDidStartDocument...");
}

//準備節點
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict{
    
    self.currentElement = elementName;
    if ([self.currentElement isEqualToString:@"student"]) {
        self.person = [[person alloc]init];
    }
}

//準備節點內容 string 就是節點內容
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    
    if([self.currentElement isEqualToString:@"pid"]){
        
        [self.person setPid:string];
    } else if ([self.currentElement isEqualToString:@"name"])[self.person setName:string];
        
    else if([self.currentElement isEqualToString:@"sex"]) [self.person setSex:string];
    else if([self.currentElement isEqualToString:@"age"]) [self.person setAge:string];
    
}

//解完一個節點
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    
    if ([elementName isEqualToString:@"student"]) {
        [self.list addObject:self.person];
    }
    self.currentElement = nil;
}


//解析結束
- (void)parserDidEndDocument:(NSXMLParser *)parser{
    NSLog(@"parserDidEndDocument...");
}

- (void)parse{

    [self.par parse];
}

@end

























