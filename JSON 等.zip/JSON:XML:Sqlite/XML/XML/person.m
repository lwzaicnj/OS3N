//
//  person.m
//  XML
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "person.h"

@implementation person

@end
