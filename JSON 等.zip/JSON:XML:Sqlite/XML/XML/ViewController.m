//
//  ViewController.m
//  XML
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ViewController.h"
#import "XMLUtil.h"
#import "person.h"
#import "GDataXMLNode.h"

@interface ViewController ()
@property (nonatomic,copy) NSMutableString *GDatatext;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    XMLUtil *xmlUtil = [XMLUtil shareXML];
    [xmlUtil parse];
    
    for (person *p in xmlUtil.list) {
        
        NSLog(@"id:%@\nname:%@\nsex:%@\nage:%@\n",p.pid,p.name,p.sex,p.age);
    }
//    NSLog(@"Parser results %@",xmlUtil.list);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)GDataXML:(id)sender {
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Students" ofType:@"xml"];
    
    NSData *data = [[NSData alloc] initWithContentsOfFile:path];
    
    //對象初始化
    GDataXMLDocument *doc = [[GDataXMLDocument alloc]initWithData:data options:0 error:nil];
    
    //獲取根節點
    GDataXMLElement *rootElement = [doc rootElement];
    
    //獲取其他節點
    NSArray *students = [rootElement elementsForName:@"student"];
    
    //初始化 這裡這樣初始化就是不可變...下面 appendString 會崩潰
//    self.GDatatext = [[NSMutableString alloc]initWithString:@""];
    
    NSMutableString *text = [[NSMutableString alloc]init];
    
    for(GDataXMLElement *student in students){
        
        //獲取第一個 pid ：{type:1 name:pid xml:"<pid>1001</pid>"}
        GDataXMLElement *pidElement = [[student elementsForName:@"pid"] objectAtIndex:0]; //返回是個數組 (雖然只有一個數)
        
        NSLog(@"%@ ",[student elementsForName:@"pid"]);//GDataXMLElement 0x7fcce1710520:{type:1 name:pid xml:\"<pid>1003</pid>\"}"
        NSString *pid = [pidElement stringValue];
        
        GDataXMLElement *sexElement = [[student elementsForName:@"sex"] objectAtIndex:0];
        NSString *sex = [sexElement stringValue];
        
        GDataXMLElement *nameElement = [[student elementsForName:@"name"] objectAtIndex:0];
        NSString *name = [nameElement stringValue];
        
        GDataXMLElement *ageElement = [[student elementsForName:@"age"] objectAtIndex:0];
        NSString *age = [ageElement stringValue];
        
        NSString *t = [NSString stringWithFormat:@"學號：%@ 姓名：%@ 年齡：%@ 性別：%@",pid,name,age,sex];
        
        [text appendString:t];
    }
    
    _txtView.text = text;
    
}
@end


















