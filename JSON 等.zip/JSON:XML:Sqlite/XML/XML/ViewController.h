//
//  ViewController.h
//  XML
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@property (weak, nonatomic) IBOutlet UITextView *txtView;
- (IBAction)GDataXML:(id)sender;

@end

