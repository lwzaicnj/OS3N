//
//  ViewController.h
//  Sqlite3
//
//  Created by apple on 2/18/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface ViewController : UIViewController{
    
    sqlite3 *db;
}


@end

