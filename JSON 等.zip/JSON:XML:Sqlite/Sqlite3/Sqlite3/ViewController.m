//
//  ViewController.m
//  Sqlite3
//
//  Created by apple on 2/18/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self openDataBase];
    
    [self createTabels];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark 打开创建数据库

- (void)openDataBase {
    
    // 创建并打开数据库
    
    // 获取数据库的路径
    
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
//    NSLog(@"數據庫路徑：%@",documentPath);
    
    // 设置数据库的路径和名词
    NSString *dataBasePath = [[NSString alloc] initWithString:[documentPath stringByAppendingPathComponent:@"sqlite.sqlite"]];
    
    // 创建并打开数据库
    int result = sqlite3_open([dataBasePath UTF8String], &db);
    
    if (result == SQLITE_OK) {
        
        NSLog(@"数据库打开成功");
        
    } else {
        
        NSLog(@"数据库打开失败。。。。。。");
    }
}


// 创建数据表

#pragma mark 创建数据表

- (void)createTabels {
    
    // sql语句
    char *sql = "create table if not exists t_persons (id integer primary key autoincrement, name text, age integer);";
    
    // 用于保存错误信息
    
    char *error;
    
    // 执行创建语句并接收结果
    //sqlite3_exec: 非查询类的语句，例如创建，添加，删除等操作
    int result = sqlite3_exec(db, sql, NULL, NULL, &error);
    
    // 判断是否创建成功
    
    if (result != SQLITE_OK) {
        
        NSLog(@"创建数据表失败~~~~~~~~：%s", error);
        
    } else {
        
        NSLog(@"数据表创建成功");
        
    }
    
    [self insertData];
    
}

// 插入数据
#pragma mark 插入数据

- (void)insertData {
    
    // sql语句
    
    char *sql = "insert into t_persons(name, age) values(?, ?)";
    
    // 存储的内容
    sqlite3_stmt *stmt;
    
    // 执行语句并接收结果
    int result = sqlite3_prepare_v2(db, sql, -1, &stmt, NULL);
    
    // 判断是否成功
    
    if (result == SQLITE_OK) { // 语法通过
        
        // 绑定数据 (就是插入實際的數據) name = "lidazw" age = 10
        sqlite3_bind_text(stmt, 1, "lidaze", -1, NULL);
        
        sqlite3_bind_int(stmt, 2, 10);
        
        // 执行插入语句
        
        if (sqlite3_step(stmt)  == SQLITE_DONE) {
            
            NSLog(@"插入成功。。。。。");
            
        } else {
            
            NSLog(@"插入失败");
            
        }
        
    } else {
        
        NSLog(@"语法不通过 ");
        
    }
    
    // 释放stmt
    sqlite3_finalize(stmt);
    
    [self findData];
}

// 查找数据
#pragma mark 查找数据
- (void)findData {
    
    // 准备C语言sql语句
    
    char *sql = "select * from t_persons";
    
    // 准备stmt
    
    sqlite3_stmt *stmt;
    
    // 判断sql语句，并接收结果
    
    int result = sqlite3_prepare_v2(db, sql, -1, &stmt, NULL);
    
    // 判断结果
    if (result == SQLITE_OK) { // sql语句正确
        
        NSLog(@"sql语句正确");
        
        // 进行逐行读取内容
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            
            int ID = sqlite3_column_int(stmt, 0);
            
            char *name = (char *)sqlite3_column_text(stmt, 1);
            
            int age = sqlite3_column_int(stmt, 2);
            
            NSLog(@"id:%i, name:%s, age:%i", ID, name, age);
            
        }
        
    } else {
        
        NSLog(@"sql语句错误");
        
    }
    // 释放stmt
//    sqlite3_finalize(stmt);
    
    [self deleteData];
}

// 删除数据
#pragma mark 删除数据
- (void)deleteData {
    
    // 准备sql语句
    char *sql = "delete from t_persons where id = ?";
    
    // stmt
    sqlite3_stmt *stmt;
    
    // 判断sql语句 -1代表全部選取字符串
    int result = sqlite3_prepare_v2(db, sql, -1, &stmt, NULL);
    
    // 判断sql语句时候通过
    if (result == SQLITE_OK) {
        
        NSLog(@"删除语句正确");
        
        // 绑定数据 第二個參數代表上面需要綁定的下標（1開始）,id = 3
        sqlite3_bind_int(stmt, 1, 3);
        
        // 判断时候执行成功
        if (sqlite3_step(stmt) == SQLITE_DONE) {
            
            NSLog(@"删除成功");
            
        } else {
            
            NSLog(@"删除失敗");
        }
        
    } else {
        
        NSLog(@"删除语句错误");
        
    }
    // 释放stmt
    sqlite3_finalize(stmt);
    
    [self updateData];
}



// 修改数据
#pragma mark 修改数据

- (void)updateData {
    
    // 准备C语言sql语句
    char *sql = "update t_persons set name = ?, age=18 where id = ?;";
    
    // 准备stmt
    sqlite3_stmt *stmt;
    
    // 执行sql语句的判断
    int result = sqlite3_prepare(db, sql, -1, &stmt, NULL);
    
    // 判断sql语句时候可用
    
    if (result == SQLITE_OK) {
        
        NSLog(@"修改语句正确");
        
        // 绑定数据
        sqlite3_bind_text(stmt, 1, "Zeeeeeeeeeee", -1, NULL);
        
        sqlite3_bind_int(stmt, 2, 11);
        
        // 执行并判断结果
        
        if (sqlite3_step(stmt) == SQLITE_DONE) {
            
            NSLog(@"修改成功");
            
        } else {
            
            NSLog(@"修改失败....");
            
        }
        
    } else {
        
        NSLog(@"修改语句错误....");
        
    }
    // 释放stmt
    sqlite3_finalize(stmt);
    
    //重新查詢
//    [self findData];
    
}




@end
