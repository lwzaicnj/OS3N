//
//  ViewController.m
//  JSON
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ViewController.h"
#import "CJSONDeserializer.h"//TouchJson
#import "SBJson5.h"
#import "SBJson.h"
#import "JSONKit.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnPressTouchJson:(id)sender {
    
    //http://m.weather.com.cn/data/101010100.html
    NSURL *url = [NSURL URLWithString:@"http://www.weather.com.cn/data/cityinfo/101010100.html"];
    NSError *error ;
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
   
    NSLog(@"%@",error);
    
    //把解析的內容放在字典內，UTF-8編碼，防止亂碼
    NSDictionary *rootDict = [[CJSONDeserializer deserializer] deserialize:[jsonString dataUsingEncoding:NSUTF8StringEncoding] error:&error];
    NSLog(@"rootDict--->%@",rootDict);
    
    //判斷返回的 json 文件層數，這裡有兩層字典
    NSDictionary *weatherInfo = [rootDict objectForKey:@"weatherinfo"];
    NSLog(@"weatherInfo--->%@",weatherInfo);
    
    _txView.text = [NSString stringWithFormat:@"今天是 %@ %@ %@ 的天氣狀況是：%@ %@ ",[weatherInfo objectForKey:@"date_y"],[weatherInfo objectForKey:@"week"],[weatherInfo objectForKey:@"city"],[weatherInfo objectForKey:@"weather"],[weatherInfo objectForKey:@"temp1"]];
    
}

- (IBAction)btnPressSBJson:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"http://m.weather.com.cn/data/101180701.html"];
    NSError *error;
    
    //把接口內容轉成 string
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
//    SBJson5Parser *parser = [[SBJson5Parser alloc]init];
//    
//    NSDictionary *rootDict = [parser ]
    
    SBJsonParser *parser = [[SBJsonParser alloc]init];
    NSDictionary *rootDict = [parser objectWithString:jsonString error:&error];
    
    NSDictionary *weatherInfo = [rootDict objectForKey:@"weatherinfo"];
     NSLog(@"rootDict--->%@",rootDict);
     NSLog(@"weatherInfo--->%@",weatherInfo);
    
    _txView.text = [NSString stringWithFormat:@"今天是 %@ %@ %@ 的天氣狀況是：%@ %@ ",[weatherInfo objectForKey:@"date_y"],[weatherInfo objectForKey:@"week"],[weatherInfo objectForKey:@"city"],[weatherInfo objectForKey:@"weather"],[weatherInfo objectForKey:@"temp1"]];
    
    
}

- (IBAction)btnPressIOSJson:(id)sender {
    
    NSError *error;
//    //加載 URL 對象
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://m.weather.com.cn/data/101180601.html"]];
//    
//    //把請求的 url 數據放到 NSData 對象
//    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
//    NSLog(@"DATA--->%@",response);
//    
//    //自帶解析類 NSJSonSerailization
//    NSDictionary *weatherDic = [NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableLeaves error:&error];
//    NSLog(@"weatherDic字典里面的内容为-->%@", weatherDic);
//    
//    NSDictionary *weatherInfo = [weatherDic objectForKey:@"wetherinfo"];
//    
//    _txView.text = [NSString stringWithFormat:@"今天是 %@  %@  %@  的天气状况是：%@  %@ ",[weatherInfo objectForKey:@"date_y"],[weatherInfo objectForKey:@"week"],[weatherInfo objectForKey:@"city"], [weatherInfo objectForKey:@"weather1"], [weatherInfo objectForKey:@"temp1"]];
//    
//    NSLog(@"weatherInfo字典里面的内容为-->%@", weatherInfo);
//*******************************************************************************************************//
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"json"];
//    NSData *data = [NSData dataWithContentsOfFile:path];
//    
//    NSDictionary *rootDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
////    NSLog(@"Dict from local file----->%@",rootDict);
//    
//    NSArray *author = [rootDict objectForKey:@"authors"];
//    NSLog(@"authors ---------> %@",author);
//    
//    NSDictionary *firstAuthor = [author objectAtIndex:0];
//    NSLog(@"First author name ---> %@",[firstAuthor objectForKey:@"firstName"]);
    
//*******************************************************************************************************//
    //字典或數組轉 json 格式
//    NSDictionary *dict1 = [NSDictionary dictionaryWithObjectsAndKeys:@"name" , @"me", @"do" , @"something", @"with" , @"her", @"address" , @"home", nil];
//    
//    NSDictionary *dict = @{@"name" : @"me", @"do" : @"something", @"with" : @"her", @"address" : @"home"};
//    
//    NSArray *array = @[@"qn", @18, @"ya", @"wj"];
//    
//    BOOL isYes = [NSJSONSerialization isValidJSONObject:dict1];
//    
//    if (isYes) {
//        NSLog(@"可以转换");
//        
//        NSData *data = [NSJSONSerialization dataWithJSONObject:dict1 options:0 error:NULL];
//        
//        [data writeToFile:@"/Users/apple/base.json" atomically:YES];
//        
//    } else {
//        
//        NSLog(@"JSON数据生成失败，请检查数据格式");
    
//    }
    
//*******************************************************************************************************//
//    NSString *jsonPath = [NSString stringWithContentsOfFile:@"/Users/apple/base.json" encoding:NSASCIIStringEncoding error:&error];//直接讀成了 string
//    
//    NSLog(@"Path ---> %@",jsonPath);//Path ---> {"me":"name","something":"do","home":"address","her":"with"}
//    
//    NSData *jsonData = [NSData dataWithContentsOfFile:@"/Users/apple/base.json"];
//    
//    NSDictionary *rootD = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
//    
//    
//    NSLog(@"從自己寫的 json 讀取信息 ---> %@",[rootD objectForKey:@"home"]);
    
//*******************************************************************************************************//

    //異步加載
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        //加載 NSURL 對象
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.douban.com/v2/movie/subject/25881786"]];
        //使用 NSURLSession 獲取網絡返回的 json 并處理
        NSURLSession *session = [NSURLSession sharedSession];
        
        NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error){
            
            //試著寫數據
            NSFileHandle  *fileHandle = [NSFileHandle fileHandleForWritingAtPath:@"/Users/apple/filmData"];
            [fileHandle truncateFileAtOffset:0];
            [fileHandle writeData:data];
            
            //從網絡返回的 Json 數據，調用 NSJSONSerialization 解析，轉為字典對象
            dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            NSString *title = [dic objectForKey:@"original_title"];
            //Array 就是 [] 括起來的
            NSArray *genresArr = [dic objectForKey:@"genres"];
            NSString *genres = [NSString stringWithFormat:@"%@/%@",[genresArr objectAtIndex:0],[genresArr objectAtIndex:1]];
            NSString *summary = [dic objectForKey:@"summary"];
            
            text = [NSString stringWithFormat:@"電影名稱: \n%@\n 體裁:\n%@\n 劇情簡介:\n%@\n",title,genres,summary];
            
            //主線程更新 UI
            dispatch_async(dispatch_get_main_queue(), ^{
                
                _txView.text = text;
            });
            
        }];
        //調用任務
        [task resume];
        
    });
    
}

- (IBAction)btnPressJsonKit:(id)sender {
    
    //GCD异步实现
    dispatch_queue_t q1 = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(q1, ^{
        
        //还是先获取url
        NSURL *url = [NSURL URLWithString:@"https://api.douban.com/v2/movie/subject/26279433"];
        NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
        //代码越来越简单了有木有！！就一个方法搞定~
        dic = [jsonString objectFromJSONStringWithParseOptions:JKParseOptionLooseUnicode];
        
        
        NSString *title = [dic objectForKey:@"original_title"];
        NSMutableArray *genresArray = [dic objectForKey:@"genres"];
        NSString *genres = [NSString stringWithFormat:@"%@/%@", [genresArray objectAtIndex:0], [genresArray objectAtIndex:1]];
        NSString *summary = [dic objectForKey:@"summary"];
        text = [NSString stringWithFormat:@"电影名称：\n%@\n体裁：\n%@\n剧情简介：\n%@", title, genres, summary];
        
        //更新UI操作需要在主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            _txView.text = text;
        });
    });
    
    //如果json是“单层”的，即value都是字符串、数字，可以使用objectFromJSONString
    NSString *json1 = @"{\"a\":123, \"b\":\"abc\"}";
    NSLog(@"json1:%@",json1);
    NSDictionary *data1 = [json1 objectFromJSONString];
    NSLog(@"json1.a:%@",[data1 objectForKey:@"a"]);
    NSLog(@"json1.b:%@",[data1 objectForKey:@"b"]);

    //如果json有嵌套，即value里有array、object，如果再使用objectFromJSONString，程序可能会报错（测试结果表明：使用由网络或得到的php/json_encode生成的json时会报错，但使用NSString定义的json字符串时，解析成功），最好使用objectFromJSONStringWithParseOptions：
    NSString *json2 = @"{\"a\":123, \"b\":\"abc\", \"c\":[456, \"hello\"], \"d\":{\"name\":\"张三\", \"age\":\"32\"}}";
    NSLog(@"json2:%@", json2);
    NSDictionary *data2 = [json2 objectFromJSONStringWithParseOptions:JKParseOptionLooseUnicode];
    NSLog(@"json2.c:%@", [data2 objectForKey:@"c"]);
    NSLog(@"json2.d:%@", [data2 objectForKey:@"d"]);

    
    
}
@end


























