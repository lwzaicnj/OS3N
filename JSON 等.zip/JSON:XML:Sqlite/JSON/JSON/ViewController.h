//
//  ViewController.h
//  JSON
//
//  Created by apple on 2/17/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{

    NSMutableDictionary *dic;
    NSString *text;
}

@property (weak, nonatomic) IBOutlet UITextView *txView;


- (IBAction)btnPressTouchJson:(id)sender;

- (IBAction)btnPressSBJson:(id)sender;

- (IBAction)btnPressIOSJson:(id)sender;

- (IBAction)btnPressJsonKit:(id)sender;


@end

