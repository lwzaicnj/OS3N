//
//  SerialPort.h
//  OS3NS
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#ifndef SerialPort_h
#define SerialPort_h

#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */

#include <termios.h>
    
typedef enum{
        
    B_50      = B50,
    B_75      = B75,
    B_110     = B110,
    B_134     = B134,
    B_150     = B150,
    B_200     = B200,
    B_300     = B300,
    B_600     = B600,
    B_1200    = B1200,
    B_1800    = B1800,
    B_2400    = B2400,
    B_4800    = B4800,
    B_9600    = B9600,
    B_19200   = B19200,
    B_38400   = B38400,
    B_57600   = B57600,
    B_115200  = B115200,
    B_230400  = B230400,
    
}Baudrate; //波特率
    
typedef enum{
    
    DATABITS_5 = CS5,
    DATABITS_6 = CS6,
    DATABITS_7 = CS7,
    DATABITS_8 = CS8,
    
}Databits; //数据位
    
typedef enum{
    
    StopBits_1 = 1,
    StopBits_2 = 2,
    
}StopBits;      //停止位

typedef enum{
    
    PARITY_NONE = 0,
    PARITY_ODD = 1,
    PARITY_EVEN = 2
    
}Parity;        //校验位

typedef enum{
    
    FLOW_CONTROL_NONE,
    FLOW_CONTROL_HARD,
    FLOW_CONTROL_SOFT,
    
}FlowControls; //流控制

    
int openPort(char *devicePath,Baudrate baudrate,Databits databits, StopBits stopbits,Parity parity,FlowControls flows);
void closePort();
int isOpen();
int readData(char *buffer,int size);
int writeData(char *buffer);

int  setBaudrate(Baudrate baudrate);
int  setDatabits(Databits databits);
int  setStopbits(StopBits stopbits);
int  setParity(Parity parity);
int  setFlowcontrol(FlowControls flow);

#ifdef __cpluscplus
};
#endif /* __cplusplus */

#endif /* SerialPort_h */
