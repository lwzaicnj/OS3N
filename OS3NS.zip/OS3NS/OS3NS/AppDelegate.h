//
//  AppDelegate.h
//  OS3NS
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "BojayMCU.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>{
    
    NSMutableString *_logString;
    BOOL _isOpen; //接通控制位
    BOOL _isLooping; //循環測試控制位
    
}


//outlet
@property (weak) IBOutlet NSComboBox *port_pop;
@property (unsafe_unretained) IBOutlet NSTextView *log_view;
@property (weak) IBOutlet NSTextField *command_field;
@property (weak) IBOutlet NSComboBox *dut_pop;
@property (weak) IBOutlet NSButton *refresh_button;//enable
@property (weak) IBOutlet NSButton *open_button;
@property (weak) IBOutlet NSButton *close_button;
@property (weak) IBOutlet NSTextField *times_field;
@property (weak) IBOutlet NSButton *start_button;


//action
- (IBAction)refreshPort:(id)sender;
- (IBAction)open:(id)sender;
- (IBAction)close:(id)sender;
- (IBAction)send:(id)sender;

- (IBAction)teststart:(id)sender;
- (IBAction)testfinish:(id)sender;
- (IBAction)maglockEnable:(id)sender;
- (IBAction)maglockDisable:(id)sender;
- (IBAction)shutterEnable:(id)sender;
- (IBAction)shutterDisable:(id)sender;
- (IBAction)lampon:(id)sender;
- (IBAction)lampoff:(id)sender;
- (IBAction)cpcup:(id)sender;
- (IBAction)cpcdown:(id)sender;
- (IBAction)cpc36:(id)sender;
- (IBAction)cpcOriginal:(id)sender;
- (IBAction)drawerP1:(id)sender;
- (IBAction)drawerP2:(id)sender;
- (IBAction)drawerOriginal:(id)sender;
- (IBAction)help:(id)sender;
- (IBAction)version:(id)sender;
- (IBAction)start_all:(id)sender;
- (IBAction)end:(id)sender;
- (IBAction)fanson:(id)sender;
- (IBAction)fansoff:(id)sender;


@end

