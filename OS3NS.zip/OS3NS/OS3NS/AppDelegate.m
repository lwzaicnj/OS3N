//
//  AppDelegate.m
//  OS3NS
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "AppDelegate.h"
#import <dirent.h>

#define WR_FOR_OK(x) {if([self write_then_readFor_OK:x utime:-1]<0) break;}

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
    _logString = [[NSMutableString alloc]init];
    _isOpen = NO;
    _isLooping = NO;
    [_dut_pop selectItemAtIndex:0];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    MCUClose();
    return YES;
}

- (IBAction)refreshPort:(id)sender{
    
    [_port_pop removeAllItems];
    
    NSMutableArray *ports = [[NSMutableArray alloc] init];
    
    struct dirent *dirent;
    
    DIR *dir = opendir("/dev/");//用来打开参数name指定的目录，并返回DIR*形态的目录流，和open()类似，接下来对目录的读取和搜索都要使用此返回值

    while ((dirent=readdir(dir)) != NULL ) {
        
        if (strstr(dirent->d_name, "cu.usb")) {
            [ports addObject:[NSString   stringWithFormat:@"/dev/%s",dirent->d_name]];
        }
    }
    
    [_port_pop addItemsWithObjectValues:ports];
    
    if (ports.count>0)   [_port_pop selectItemAtIndex:0];
}


- (IBAction)open:(id)sender{
    
    char *devicePath = (char *)[[_port_pop stringValue] UTF8String];
    
    int ret = MCUOpen(devicePath);//打開所選端口
    
    if (ret == 0) {
        
        [_open_button setEnabled:NO];
        [_refresh_button setEnabled:NO];
        [_port_pop setEnabled:NO];
        _isOpen = YES;
    }
}

- (IBAction)close:(id)sender{
    
    MCUClose();
    
    [_open_button setEnabled:YES];
    [_refresh_button setEnabled:YES];
    [_port_pop setEnabled:YES];
    _isOpen = NO;
}

//把手動寫的命令寫進 MCU
- (IBAction)send:(id)sender{
    
    char *str = (char *)[[_command_field    stringValue] UTF8String];
    
    if (strcmp(str , "") == 0) return;
    
    [self write_then_read:str];
    
}

- (int)write_then_read:(char *)cmd{
    
    int ret = -1;
    
    if (!_isOpen) {
        [self showLog:@"port not opened\n"];
        
        return ret;
    }
    
    ret = MCUWrite(cmd);
    [self showLog:[NSString stringWithFormat:@"write command : %s\n",cmd]];
    
    usleep(DELAY_TIME);
    char readBuf[BUFFER_SIZE] = {0};
    
    ret = MCURead(readBuf, BUFFER_SIZE);
    
    if (ret<0) [self showLog:@"read failed\n"];
    
    [self showLog:[NSString stringWithFormat:@"%s",readBuf]];
    
    return ret;
}

- (void)showLog:(NSString *)logStr{

    [self performSelectorOnMainThread:@selector(refreshLog:) withObject:logStr waitUntilDone:YES];
}

- (void)refreshLog:(NSString *)logStr{
    
    if (_logString.length > 100*1024) [_logString setString:@""]; //過多清空
    
    [_logString appendString:logStr];
    [_log_view setString:_logString];
    [_log_view scrollToEndOfDocument:nil];
    
}

- (int)write_then_readFor_OK:(char *)cmd utime:(int)timeout{

    int ret = -1;
    
    if (!_isOpen) {
        [self showLog:@"port not opened\n"];
        
        return ret;
    }
    
    if (timeout == -1) timeout = TIMEOUT;
    ret = MCUWriteForuSeconds(cmd, timeout);
    
    [self showLog:[NSString stringWithFormat:@"write command : %s\n",cmd]];
    
    NSString *temp;
    switch (ret) {
        case 0:
            temp = @"read : ok\n";
            break;
        case -1:
            temp = @"read failed\n";
            break;
        case -2:
            temp = @"write command failed\n";
            break;
        case -3:
            temp = @"invalid command\n";
            break;
        case -4:
            temp = @"read timeout\n";
            break;
        default:
            break;
    }
    [self showLog:temp];
    return ret;
}

-(int)readForStart{
    int ret = -1;
    if (!_isOpen){
        [self showLog:@"port not opend\n"];
        return ret;
    }
    
    [self showLog:@"read for test start\n"];
    ret = MCUReadStart();
    
    NSString *temp;
    if (ret==0) temp = @"read for test start : ok\n";
    else temp = @"read for test start : failed\n";
    [self showLog:temp];
    return ret;
}

- (IBAction)teststart:(id)sender {
    
    [self write_then_readFor_OK:TEST_START utime:TIMEOUT_S];
}

- (IBAction)testfinish:(id)sender{
    
    if ([self write_then_readFor_OK:MAGLOCK_DISABLE utime:-1] < 0) return;
    [self write_then_readFor_OK:TEST_FINISH utime:-1];
}

- (IBAction)maglockEnable:(id)sender{
    
    [self write_then_readFor_OK:MAGLOCK_ENABLE utime:-1];
}

- (IBAction)maglockDisable:(id)sender{
    
    [self write_then_readFor_OK:MAGLOCK_DISABLE utime:-1];
}

- (IBAction)shutterEnable:(id)sender{
    
    if ([self write_then_readFor_OK:SHUTTER_ENABLE utime:TIMEOUT_S] < 0){
        [self write_then_readFor_OK:SHUTTER_DISABLE utime:-1];
    }
}

- (IBAction)shutterDisable:(id)sender{
    [self write_then_readFor_OK:SHUTTER_DISABLE utime:-1];
}

- (IBAction)lampon:(id)sender{
    [self write_then_readFor_OK:LAMP_ON utime:-1];
}

- (IBAction)lampoff:(id)sender{
    [self write_then_readFor_OK:LAMP_OFF utime:-1];
}

- (IBAction)cpcup:(id)sender{
    
    if ([self write_then_readFor_OK:CPC_UP utime:TIMEOUT_S]<0) {
        [self write_then_readFor_OK:CPC_DOWN utime:-1];
    }
}

- (IBAction)cpcdown:(id)sender{
    
    [self write_then_readFor_OK:CPC_DOWN utime:-1];
}

- (IBAction)cpc36:(id)sender{
    
    [self write_then_readFor_OK:CPC_ROTATE_36 utime:-1];
}

- (IBAction)cpcOriginal:(id)sender{
    [self write_then_readFor_OK:CPC_ROTATE_ORIGINAL utime:-1];
}

- (IBAction)drawerP1:(id)sender{
    NSInteger index = [_dut_pop indexOfSelectedItem];
    char *cmd;
    switch (index) {
        case 0:
            cmd = DRAWER_P1_SMALL;
            break;
        case 1:
            cmd = DRAWER_P1_LARGER;
            break;
        default:
            cmd = DRAWER_P1_SMALL;
    }
    
    [self write_then_readFor_OK:cmd utime:-1];
}

- (IBAction)drawerP2:(id)sender{
    
    NSInteger index = [_dut_pop indexOfSelectedItem];
    char *cmd;
    switch (index) {
        case 0:
            cmd = DRAWER_P2_SMALL;
            break;
        case 1:
            cmd = DRAWER_P2_LARGER;
            break;
        default:
            cmd = DRAWER_P2_SMALL;
    }
    
    [self write_then_readFor_OK:cmd utime:-1];
}

- (IBAction)drawerOriginal:(id)sender{
    
    [self write_then_readFor_OK:DRAWER_ORIGINAL utime:-1];
}

- (IBAction)help:(id)sender{
    [self write_then_read:HELP];
}

- (IBAction)version:(id)sender{
    [self write_then_read:VERSION];
}

- (IBAction)start_all:(id)sender{
    
    if (_isLooping) return;
    _isLooping = YES;
    [_start_button setEnabled:NO];
    
    NSInteger index = [_dut_pop indexOfSelectedItem];
    char *p1; char *p2;
    switch (index) {
        case 0:
            p1 = DRAWER_P1_SMALL;
            p2 = DRAWER_P2_SMALL;
            break;
        case 1:
            p1 = DRAWER_P1_LARGER;
            p2 = DRAWER_P2_LARGER;
            break;
        default:
            p1 = DRAWER_P1_SMALL;
            p2 = DRAWER_P2_SMALL;
    }
    
    //并发执行队列，對應block被分发到多个线程去执行
    dispatch_queue_t concurentQueue = dispatch_queue_create("loop_queue", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(concurentQueue, ^(){
        
        while (_isLooping) {
            int loop_times = [_times_field  intValue];
            
            if (loop_times<0) break;
            
            if ([self readForStart] < 0) break;
            
            WR_FOR_OK(FANS_ON);
            WR_FOR_OK(CPC_ROTATE_ORIGINAL);
            WR_FOR_OK(LAMP_ON);
            
            WR_FOR_OK(MAGLOCK_ENABLE);
            WR_FOR_OK(p1);
            WR_FOR_OK(DRAWER_ORIGINAL);
            
            if ([self write_then_readFor_OK:SHUTTER_ENABLE utime:TIMEOUT_S]<0) {
                WR_FOR_OK(SHUTTER_DISABLE);
            }
            
            for (int i=0 ; i<10; i++) {
                
                if ([self write_then_readFor_OK:CPC_UP utime:TIMEOUT_S]<0) {
                    WR_FOR_OK(CPC_DOWN);
                }
                sleep(2);
                [self showLog:@"test p1\n"];
                
                WR_FOR_OK(CPC_DOWN);
                if(i<9)WR_FOR_OK(CPC_ROTATE_36);
                usleep(500000);
            }
            
            WR_FOR_OK(SHUTTER_DISABLE);
            
            WR_FOR_OK(CPC_ROTATE_ORIGINAL);
            WR_FOR_OK(p2);
            
            [self showLog:@"test p2\n"];
            
            WR_FOR_OK(DRAWER_ORIGINAL);
            WR_FOR_OK(MAGLOCK_DISABLE);
            
            WR_FOR_OK(LAMP_OFF);
            WR_FOR_OK(FANS_OFF);
            
            loop_times--;
            [_times_field setIntValue:loop_times];

        }
        
        _isLooping = NO; //loop over
        
        [_start_button setEnabled:YES];
    });
}

- (IBAction)end:(id)sender{
    
     _isLooping = NO;
}

- (IBAction)fanson:(id)sender{
    [self write_then_readFor_OK:FANS_ON utime:-1];
}

- (IBAction)fansoff:(id)sender{
    [self write_then_readFor_OK:FANS_OFF utime:-1];
}



@end
