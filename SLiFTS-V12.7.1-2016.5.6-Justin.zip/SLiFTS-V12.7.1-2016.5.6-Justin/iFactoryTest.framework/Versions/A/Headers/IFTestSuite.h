//
//  IFTestSuite.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class IFTestSiteManager;
@class IFTLogger;

@interface IFTestSuite : NSObject {
    NSMutableDictionary* testFlows;
    NSString* siteName;
    NSString* currentSN;

    NSMutableDictionary* resources;
    NSMutableDictionary* siteAttributes;
	int currentIndex;
}

@property (readwrite, retain) NSDictionary* resources;
@property (readwrite, copy) NSString* siteName;
@property (readwrite, copy) NSString* currentSN;
@property (readonly) NSMutableDictionary* siteAttributes;
@property (readwrite) int currentIndex;

-(void)setFlow:(NSMutableArray*)flow forName:(NSString*)name;
-(NSMutableArray*)flowForName:(NSString*)name;
-(void)removeFlow:(NSString*)name;
-(id)init:(NSString*)siteName;
-(NSArray*)flowNames;
-(void)addResource:(id)resource forName:(NSString*)resourceName;
-(IFTLogger*)logger;

//should be called when the program is loaded.
//it should be OK to call it more than once, but there should be no 
//effect after the first time
+(BOOL)onLoad:(NSDictionary*)stationInfo error:(NSError**) error;

//should be called when you are done with the program. paried with the call to onLoad
//it should be OK to call it more than once, but there should be no 
//effect after the first time
+(BOOL)onUnload:(NSError**) error;

//should be called every time the testing of a new DUT gets under way
//returns the attributes that should be logged by instant pudding
-(NSDictionary*)onDUTStart:(NSMutableDictionary*)deviceInfo returnedError:(NSError**) error;

//should be called every time the testing of a DUT ends
-(BOOL)onDUTFinished:(NSError**) error;

//called when the test fails. This function may not do anything
-(BOOL)onDUTFail:(NSError**) error;

//called when an exception happens during testing. Should reset the hardware state
-(BOOL)onException:(NSError**) error;


@end
