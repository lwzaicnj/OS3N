//
//  IFTestMethodDelay.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 1/4/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTestMethod.h"

@interface IFTestMethodDelay : IFTestMethod {

}
-(BOOL)run:(int)index error:(NSError**)error;

@end
