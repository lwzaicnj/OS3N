//
//  IFTCSVLogger.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 10/1/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTLogger.h"

@interface IFTCSVLogger : IFTLogger {
    NSString* path;
    NSFileHandle* handle;
}

@property (readwrite, copy) NSString* path;


-(id)init:(NSString*)p_path;

-(BOOL)open:(NSArray*)p_deviceAttributeKeys extra:(NSArray*)extraKeys error:(NSError**)error;
-(BOOL)close:(NSError**)error;

-(void)log:(IFTestResult*) result;
-(void)writeString:(NSString*)strToWrite;
-(void)appendProperty:(NSString*)pName ofResult:(IFTestResult*)result toLine:(NSMutableString*)line;

+(NSString*)timeStampedFileName:(NSString*)fn;
@end
