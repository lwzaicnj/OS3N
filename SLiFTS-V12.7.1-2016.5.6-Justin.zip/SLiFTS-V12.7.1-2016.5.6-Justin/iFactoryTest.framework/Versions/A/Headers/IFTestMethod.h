//
//  IFTestMethod.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTestResult.h"
@class IFTestResult;
@class IFTestSuite;
@class IFTSubTestInfo;

@interface IFTestMethod : NSObject {
    NSString* displayName;
    NSArray* subTests;
    IFTestSuite* suite;
    NSMutableArray* aryReturn;
    NSDictionary* params;
    int testIndex;
	BOOL allowRetest;
	BOOL shouldStopOnFail;
}

@property (readonly) NSString* displayName;
@property (readwrite, assign) IFTestSuite* suite;
@property (readonly) NSArray* subTests;
@property (readwrite, copy) NSDictionary* params;
@property (readwrite) BOOL allowRetest;
@property (readwrite) BOOL shouldStopOnFail;


//the test method does not need to retain the resources, it's the TestSuite's responsibility to retain the resources
-(id)init:(IFTestSuite*)p_suite withResources:(NSDictionary*)resources displayName:(NSString*)displayName subTestInfos:(NSArray*)stInfos;

//if you implement your own preRun method, you must call [super willRun] at the begining of your method
-(BOOL)willRun:(int)index error:(NSError**)error;
//return boolean indicates if the test has passed
-(BOOL)run:(int)index error:(NSError**)error;
//retest just cleans the results from the last run and call [self run] again. If retest is called is decided by the retest policy
-(BOOL)retest:(int)index error:(NSError**)error;

//if you implement your own postRun method, you must call return [super didRun] at the end of your method
-(NSArray*)didRun:(int)index error:(NSError**)error;

-(IFTestResultType)addResultAndMatch:(int)testNumber value:(NSString*)actual extras:(NSMutableDictionary*)extras;
-(IFTestResultType)addResultAndCompare:(int)testNumber value:(double)actual extras:(NSMutableDictionary*)extras;
-(IFTestResultType)addResultAndMatch:(int)testNumber value:(NSString*)actual extras:(NSMutableDictionary*)extras failMessage:(NSString*)msg;
-(IFTestResultType)addResultAndCompare:(int)testNumber value:(double)actual extras:(NSMutableDictionary*)extras failMessage:(NSString*)msg;
-(IFTestResult*)addResult:(int)testNumber value:(NSString*)actual extras:(NSMutableDictionary*)extras result:(IFTestResultType)p_result;
-(void)addRuntimeError:(int)testNumber errorMessage:(NSString*)msg;

-(NSArray*)subTestNames;

 
-(NSView*)view;



@end
