/*
 *  IFTAgilentConstants.h
 *  iFactoryTest
 *
 *  Created by Wei Wang on 7/2/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
extern const NSString* kIFTAgilentRangeLow;
extern const NSString* kIFTAgilentRangeMedium;
extern const NSString* kIFTAgilentRangeHigh;
extern const NSString* kIFTAgilentRangeAuto;

extern const NSString* kIFTAgilentDCVoltage;
extern const NSString* kIFTAgilentDCVoltRatio;
extern const NSString* kIFTAgilentACVoltage;
extern const NSString* kIFTAgilentDCCurrent;
extern const NSString* kIFTAgilentACCurrent;
extern const NSString* kIFTAgilent2WireRes;
extern const NSString* kIFTAgilent4WireRes;
extern const NSString* kIFTAgilentFreq;
extern const NSString* kIFTAgilentPeriod;
extern const NSString* kIFTAgilentCont;
extern const NSString* kIFTAgilentDiode;
