//
//  IFTDavDPEther.h
//  iFactoryTest
//
//  Created by Wei on 8/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTDavDP.h"
#import "IFTSocket.h"


@interface IFTDavDPEther : IFTDavDP {
    IFTSocket* socket;
}

@property(readonly) IFTSocket* socket;

-(id)init:(const char*)ipAddr;
-(id)initWithSocket:(IFTSocket*)socket;

-(NSArray*)sendCommand:(NSString*)cmd timeOutInSeconds:(int)timeOut error:(NSError**)e;
@end
