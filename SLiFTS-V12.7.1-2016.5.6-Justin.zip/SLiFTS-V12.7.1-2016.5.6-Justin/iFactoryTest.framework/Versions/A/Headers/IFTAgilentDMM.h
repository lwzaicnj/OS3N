//
//  IFTAgilentDMM.h
//  iFactoryTest
//
//  Created by Wei Wang on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IFTAsciiReadWriteDevice.h"
#import "IFTScpiInstrument.h"
#import "IFTAgilentConstants.h"

@interface IFTAgilentDMM : IFTScpiInstrument {

}

-(id)initWithAsciiReadWriteDevice:(id<IFTAsciiReadWriteDevice>)device;

-(float)measure:(const NSString*)measureType inRange:(float)expectValue error:(NSError**)e;
-(BOOL)setRange:(float)expectValue forMeasurement:(const NSString*)measureType error:(NSError**)e;

@end
