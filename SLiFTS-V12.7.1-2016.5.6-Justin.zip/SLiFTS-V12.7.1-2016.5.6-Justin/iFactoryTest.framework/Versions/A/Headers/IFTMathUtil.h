//
//  IFTMathUtil.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 11/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTUtil.h"

@interface IFTUtil (IFTMathUtil) 
    +(int)hex2int:(NSString*)hexValue;
    +(NSString*)int2hex:(int)intValue width:(int)width;
    +(int)bin2int:(NSString*)binValue;
    +(NSString*)int2bin:(int)intValue width:(int)width;

@end
