//
//  IFTestResult.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class IFTestMethod;

typedef enum {
    IFTResultFail = 0,
    IFTResultPass=1,
    IFTResultNA
} IFTestResultType;

@interface IFTestResult : NSObject {
	int runIndex;
    NSString* testName;
    NSString* subTestName;
    NSString* serialNumber;
    NSString* siteName;
    NSString* expected;
    NSString* actual;
    NSString* lowLimit;
    NSString* highLimit;
    NSMutableDictionary* extras;
    IFTestResultType result;
    NSString* testNumber;
    NSString* failMessage;
    int priority;
}

@property (readwrite) int runIndex;
@property (readwrite, copy) NSString* testName;
@property (readwrite, copy) NSString* serialNumber;
@property (readwrite, copy) NSString* subTestName;
@property (readwrite, copy) NSString* expected;
@property (readwrite, copy) NSString* actual;
@property (readwrite, copy) NSString* lowLimit;
@property (readwrite, copy) NSString* highLimit;
@property (readwrite, copy) NSMutableDictionary* extras;
@property (readwrite, copy) NSString* testNumber;
@property (readwrite, copy) NSString* siteName;
@property (readwrite, copy) NSString* failMessage;
@property (readwrite) IFTestResultType result;
@property (readwrite) int priority;

//we can get the serial number and sitename from the suite from the testmethod
+(id)resultWithValues:(IFTestMethod*)tm 
            subTestName:(NSString*)stName
               expected:(NSString*)e
               lowLimit:(float)ll
              highLimit:(float)hh
            majorNumber:(int)major
            minorNumber:(int)minor
                 extras:(NSMutableDictionary*)ex
                 actual:(NSString*)val 
                 result:(IFTestResultType)res;
    

+(id)resultWithValues:(IFTestMethod*)tm 
            subTestName:(NSString*)stName
               expected:(NSString*)e
            majorNumber:(int)major
            minorNumber:(int)minor
                 extras:(NSMutableDictionary*)ex
               actual:(NSString*)val 
               result:(IFTestResultType)res;

-(id)init;
-(void)setTestNumberWithMajor:(int)major minor:(int)minor;
-(void) setLimitsWithLow:(float)ll high:(float)hh;
-(IFTestResult*)copyAttributesWithSubTestName:(NSString*)subTestName majorNumber:(int)major minorNumber:(int)minor;
-(NSString*)description;
-(void)setActual:(NSString*)p_actual;
@end
