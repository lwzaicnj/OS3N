//
//  IFTLogger.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 10/1/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTestResult.h"

//differnt loggers chained together to implement the decorator pattern
@interface IFTLogger : NSObject {
    IFTLogger* lowerLogger;
    NSArray* extraKeys;
    NSArray* deviceAttributeKeys;
    NSDictionary* deviceAttributes;
}

@property (readwrite, retain) IFTLogger* lowerLogger;
@property (readwrite, retain) NSArray* extraKeys;
@property (readwrite, retain) NSDictionary* deviceAttributes;
@property (readwrite, retain) NSArray* deviceAttributeKeys;

-(BOOL)open:(NSArray*)deviceAttributeKeys extra:(NSArray*)extraKeys error:(NSError**)error;
-(BOOL)close:(NSError**)error;

-(void)log:(IFTestResult*) result;
-(void)startDevice:(NSDictionary*)deviceAttributes;
+(void)clearLogs:(NSString*)path;
+(BOOL)createLogPath:(NSString*)path error:(NSError**)e;
@end
