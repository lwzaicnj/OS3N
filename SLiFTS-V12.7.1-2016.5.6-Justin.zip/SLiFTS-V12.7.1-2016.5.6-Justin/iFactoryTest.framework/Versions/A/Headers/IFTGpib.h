//
//  IFTGpib.h
//  iFactoryTest
//
//  Created by Wei Wang on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "IFTAsciiReadWriteDevice.h"
typedef enum {
	kIFTGpibTimeoutInfinite=0,   /* Infinite timeout (disabled)         */
	kIFTGpibTimeout10us=1,   /* Timeout of 10 us (ideal)            */
	kIFTGpibTimeout30us=2,   /* Timeout of 30 us (ideal)            */
	kIFTGpibTimeout100us=3,   /* Timeout of 100 us (ideal)           */
	kIFTGpibTimeout300us=4,   /* Timeout of 300 us (ideal)           */
	kIFTGpibTimeout1ms=5,   /* Timeout of 1 ms (ideal)             */
	kIFTGpibTimeout3ms=6,   /* Timeout of 3 ms (ideal)             */
	kIFTGpibTimeout10ms=7,   /* Timeout of 10 ms (ideal)            */
	kIFTGpibTimeout30ms=8,   /* Timeout of 30 ms (ideal)            */
	kIFTGpibTimeout100ms=9,   /* Timeout of 100 ms (ideal)           */
	kIFTGpibTimeout300ms=10,   /* Timeout of 300 ms (ideal)           */
	kIFTGpibTimeout1s=11,   /* Timeout of 1 s (ideal)              */
	kIFTGpibTimeout3s=12,   /* Timeout of 3 s (ideal)              */
	kIFTGpibTimeout10s=13,   /* Timeout of 10 s (ideal)             */
	kIFTGpibTimeouts30s=14,   /* Timeout of 30 s (ideal)             */
	kIFTGpibTimeout100s=15,   /* Timeout of 100 s (ideal)            */
	kIFTGpibTimeout300s=16,   /* Timeout of 300 s (ideal)            */
	kIFTGpibTimeout1000s=17   /* Timeout of 1000 s (ideal)           */
} IFTGpibTimeout;

@interface IFTGpib : NSObject <IFTAsciiReadWriteDevice> {
	int device;
	int address;
}

@property (readonly) int address;

-(id)initWithAddress:(int)p_address;
-(BOOL)isConnected;
-(BOOL)connect:(IFTGpibTimeout)timeout error:(NSError**)e;
-(BOOL)close:(NSError**) e;
-(BOOL)write:(NSString*)cmd error:(NSError**)e;
-(NSString*)read:(int)maxLength error:(NSError**)e;

@end
