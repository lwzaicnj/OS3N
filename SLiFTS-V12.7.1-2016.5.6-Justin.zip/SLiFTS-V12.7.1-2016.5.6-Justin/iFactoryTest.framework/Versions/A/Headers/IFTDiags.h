//
//  IFTDiags.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTSerial.h"
#define kIFTDiagNoPromptErrorCode 15000
#define kIFTDiagTimeOutErrorCode 15001

@interface IFTDiags : NSObject {
    IFTSerial* com;
    double timeOutInSeconds;
}
@property (readonly) IFTSerial* com;
@property (readwrite) double timeOutInSeconds;

-(id)init:(NSString*)bsdPath;
-(id)initWithPort:(IFTSerial*)p_com;
-(BOOL)open:(NSError**)error;

-(BOOL)resetCommunication:(NSError**)error;
-(NSArray*)sendCommand:(NSString*)cmd error:(NSError**)e;
@end
