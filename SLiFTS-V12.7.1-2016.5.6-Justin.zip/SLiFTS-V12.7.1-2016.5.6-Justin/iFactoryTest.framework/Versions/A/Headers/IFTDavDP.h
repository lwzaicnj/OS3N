//
//  IFTDavDP.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTestResult.h"
#import "IFTErrorCodes.h"


@interface IFTDavDP : NSObject {
    NSString* revFPGA;
    NSString* revDPRx;
    NSString* revHDMIRx;
    NSString* revPIC;
    double timeOutInSeconds;
}

@property(readonly) NSString* revFPGA;
@property(readonly) NSString* revDPRx;
@property(readonly) NSString* revHDMIRx;
@property(readonly) NSString* revPIC;
@property(readwrite) double timeOutInSeconds;





-(IFTestResultType)parseForPassFail:(NSArray*) retArray resultIndex:(int)index;
-(NSArray*)sendCommand:(NSString*)cmd timeOutInSeconds:(int)timeOut error:(NSError**)e;
-(BOOL)checkReturn:(NSArray*)array expectedFieldCount:(int)fieldCount error:(NSError**)error;
-(NSArray*)packageReturn:(NSString*)strReturn addr:(NSString*)addr error:(NSError**)error;
-(id)initVersionInfo;
@end
