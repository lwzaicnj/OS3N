
#import <Foundation/Foundation.h>
@protocol IFTAsciiReadWriteDevice <NSObject>

- (BOOL)close:(NSError**) error;
-(BOOL)write:(NSString*)cmd error:(NSError**)e;
-(NSString*)read:(int)maxLength error:(NSError**)e;
@end

@interface IFTAsciiReadWriteSimDevice : NSObject <IFTAsciiReadWriteDevice>{
	NSMutableDictionary* responses;
	NSMutableArray* scriptResponses;
	int currentScriptIndex; //where we are in the script now
	NSString* lastChallenge;
	BOOL inScript;
}

@property (readwrite) BOOL inScript;

-(id)initWithFile:(NSString*)path;

-(NSString*)response:(const NSString*)challenge;
-(NSString*)nextScriptedResponse;
-(void)addResponse:(const NSString*)response forChallenge:(const NSString*)challenge;
-(void)insertResponse:(const NSString*)response atScriptIndex:(int)index;


@end