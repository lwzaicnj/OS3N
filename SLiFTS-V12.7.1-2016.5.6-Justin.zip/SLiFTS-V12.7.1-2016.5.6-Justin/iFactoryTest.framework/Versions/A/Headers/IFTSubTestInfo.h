//
//  IFTSubTestInfo.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 10/7/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface IFTSubTestInfo : NSObject {
    NSString* name;
    int priority;
    double lowLimit;
    double highLimit;
    NSString* expected;
    NSString* failMessage;
    BOOL hasLimits;
}

@property (readwrite) int priority;
@property (readwrite, copy) NSString* name;
@property (readwrite) double lowLimit;
@property (readwrite) double highLimit;
@property (readwrite, copy) NSString* expected;
@property (readwrite, copy) NSString* failMessage;
@property (readonly) BOOL hasLimits;

+(IFTSubTestInfo*)subTestInfo:(NSString*)name priority:(int)p;
+(IFTSubTestInfo*)subTestInfo:(NSString*)name priority:(int)p failMessage:(NSString*)msg;
+(IFTSubTestInfo*)subTestInfo:(NSString*)name priority:(int)p withExpected:(NSString*)expectedValue failMessage:(NSString*)msg;
+(IFTSubTestInfo*)subTestinfo:(NSString*)name priority:(int)p withLowLimit:(double)ll andHighLimit:(double)hl  failMessage:(NSString*)msg;
-(void)setLimits:(double)ll highLimit:(double)hl;

@end
