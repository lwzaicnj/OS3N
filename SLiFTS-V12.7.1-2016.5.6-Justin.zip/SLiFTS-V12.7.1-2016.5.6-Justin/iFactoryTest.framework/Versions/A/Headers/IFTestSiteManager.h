//
//  IFTestSiteManager.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString* const kAppleIFTMethodPrefix;
extern NSString* const kAppleIFTAttributeBundleVersion;
extern NSString* const kAppleIFTAttributeFrameworkVersion;
@class IFTestSuite;

@interface IFTestSiteManager : NSObject {
    NSMutableDictionary* infoForSites;
    NSMutableDictionary* sites;
    NSMutableDictionary* instruments;
    NSMutableDictionary* config;
    NSMutableDictionary* stationAttributes;
    int runIndex;
}

+(IFTestSiteManager*)sharedInstance;

-(NSArray*)siteNames;
-(void)setSuite:(IFTestSuite*)suite forSite:(NSString*) siteName;
-(IFTestSuite*)suiteForSite:(NSString*) siteName;
-(IFTestSuite*)nextAvailableSite;
-(BOOL)loadConfig:(NSBundle*)bundle stationInfo:(NSDictionary*)info error:(NSError**)error;
-(int)nextRunIndex;
-(BOOL)loadTesterConfig:(NSError**)error;

@property (readwrite, retain) NSMutableDictionary* infoForSites;
@property (readonly) NSDictionary* config;
@property (readonly) NSDictionary* stationAttributes;
@end
