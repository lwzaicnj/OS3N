//
//  main.m
//  iFTS
//
//  Created by diags on 5/5/10.
//  Copyright Foxconn 2010. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "scriptParse.h" 
#import "testItemManage.h"
#import "testItemParse.h"
#import "UIWinManage.h"
#import "UI_LockScript.h"
extern BOOL isAdmin;


//added by caijunbo on 2010-09-10 for Display Port Test

#include <stdio.h>
#import "iFactoryTest/IFTPlugIn.h"
#import "testExecution.h"
#import "pubFun.h"
#import <Cocoa/Cocoa.h>
void ReplaceDPDeviceFile(NSString* DeviceFile1,NSString* DeviceFile2);
void UnlockScriptSuccess();
NSBundle* loadBundle();
NSBundle* DPBundle=nil;
NSMutableString* ParametricDataFilePath=nil;



//added by caijunbo on 2010-09-10 for Display Port Test

int main(int argc, char *argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApp = [NSApplication sharedApplication];
    
    /*JianSheng Add on 2014-07-30: Use jsonFile provisioning IP replace the one in fiel JMET.py for test item "EZLinkConnected"*/
    NSString *strJMET = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/JMET.py"] encoding:NSASCIIStringEncoding error:nil] ;
    if([strJMET length] > 0)
    {
        NSString *IP_JMET = [ToolFun getStrFromPrefixAndPostfix:strJMET Prefix:@"http://" Postfix:@":"] ;
        if([IP_JMET length] > 0)
        {
            NSString* jsonFile = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
            //NSString* jsonFile = [NSString stringWithContentsOfFile:@"/vault/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
            if([jsonFile length] > 0)
            {
                jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\t" withString:@""];
                jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@" " withString:@""];
                jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                
                NSString *IP_jsonFile = [ToolFun getStrFromPrefixAndPostfix:jsonFile Prefix:@"PROV_IP:" Postfix:@","];
                if([IP_jsonFile length] > 0)
                {
                    if([IP_jsonFile rangeOfString:IP_JMET].length <= 0)
                    {
                        strJMET = [strJMET stringByReplacingOccurrencesOfString:IP_JMET withString:IP_jsonFile];
                        
                        
                        FILE* fp=NULL;
                        fp=fopen([[NSHomeDirectory()stringByAppendingString:@"/JMET.py"] UTF8String],"wr");
                        fclose(fp);
                        
                        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:[NSHomeDirectory()stringByAppendingString:@"/JMET.py"]];
                        if (filehandTmp!=nil)
                        {
                            
                            [filehandTmp seekToEndOfFile] ;
                            [filehandTmp writeData:[NSData dataWithData:[strJMET dataUsingEncoding:NSASCIIStringEncoding]]] ;
                            [filehandTmp closeFile] ;
                            
                        }
                        
                    }
                }
            }
            
        }
    }
    /*JianSheng Add on 2014-07-30: End*/
    
    // add by Annie for lock script
    NSString *curModifyDateStr;
    NSString *origModifyDateStr;
    
    
    /*    
    NSString *strAppconfig = [NSString stringWithContentsOfFile:@"/Checkcb_UUTLog1_20120922015809.txt" encoding:NSASCIIStringEncoding error:nil] ;
    
    NSString *DoefileName1 = @"/eeData1.txt";
    
    FILE* fp=NULL;
    fp=fopen([DoefileName1 UTF8String],"wr");
    fclose(fp);//[371A20B6:4E2B9118] 
    
    strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"[3E1A2335:4DAA3118]" withString:@""];
    strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@" " withString:@""];
    strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    NSString *find = [ToolFun getStrFromPrefixAndPostfix:strAppconfig Prefix:@"mipiread0x140xc40x15" Postfix:@":-)"];
    
    while(find!=nil)
    {
        find = [find stringByAppendingString:@","];
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:DoefileName1];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[find dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
        
        strAppconfig = [strAppconfig substringFromIndex:[strAppconfig rangeOfString:@"mipiread0x140xc40x15"].location + 19];
        find = [ToolFun getStrFromPrefixAndPostfix:strAppconfig Prefix:@"mipiread0x140xc40x15" Postfix:@":-)"];
    }
    
    */
	//SCRID:46
	//add by caijunbo on 2010-12-18
	NSString* open=@"open /usbterm";
	system([open UTF8String]);
	//add end
//    NSString *mQueryString=@"123";
//	NSLog(@"mQueryString:%@",mQueryString);
    
	bool bTmp ;
	
	bTmp = [ScriptParse parseAppConfig:[NSHomeDirectory()stringByAppendingString:@"/AppConfig.txt"]] ;
	if (bTmp==false)
		[ToolFun setAPPInitLog:@"APPconfig script parse fail!"] ;
    bTmp=[TestItemManage initTestItemInfo];
    
//    char *user=getlogin();
//    NSString *userStr=[NSString stringWithUTF8String:user];
//    NSString *basePathStr=[NSString stringWithFormat:@"/Users/%@/Documents",userStr];
    NSString *basePathStr=[NSHomeDirectory()stringByAppendingString:@"/Documents"];
    
    //NSURL *permissionPath = [NSURL fileURLWithPath:[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Contents"]];
    NSURL *permissionPath = [NSURL URLWithString:basePathStr];
    NSURL *adminPath = [permissionPath URLByAppendingPathComponent:@"admin.txt"];
    NSString *permission = [NSString stringWithContentsOfFile:[adminPath path] encoding:NSUTF8StringEncoding error:nil];
    if((permission != nil) && [permission isEqualToString:@"1"])
    {
        isAdmin = YES;
        UnlockScriptSuccess();
    }
    else
    {
        //add by Annie for clocking script--------------------------------------------------
        //-----get current script modified date
        NSString *strTestScriptPath = [NSHomeDirectory()stringByAppendingString:[ScriptParse getValueFromSummary:@"TestScript"]] ;
        NSString *stationStr = strTestScriptPath;//[strTestScriptPath stringByReplacingOccurrencesOfString:@"/" withString:@""];
        NSRange blankRange=[stationStr rangeOfString:@" "];
        
        if (blankRange.length>0) {
            stationStr = [stationStr stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
        }
        
        /*****
         //- old method "ls -l %@ >%@/vv.txt"-------------------------------------
        NSString *curModifyTimeCommand=[NSString stringWithFormat:@"ls -l %@ >%@/vv.txt",stationStr,[permissionPath path]];
        system([curModifyTimeCommand UTF8String]);
        
        NSMutableString* curModifyDateAllStr=[[NSMutableString alloc] initWithString:@"\n"];
        NSString*  curModifyDateAllStrTmp=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vv.txt",[permissionPath path]]  encoding:NSASCIIStringEncoding error:nil];
        curModifyDateStr=[ToolFun getStrFromPrefixAndPostfix:curModifyDateAllStrTmp Prefix:@"-rw" Postfix:@".txt"];
        [curModifyDateAllStr appendString:curModifyDateAllStrTmp];
        
        //-----get origin script modified data
        //NSString *scriptTmpStr=[NSString stringWithContentsOfFile:@"/Library/Java/lock.txt" encoding:NSASCIIStringEncoding error:nil];
        NSString *scriptTmpStr=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]] encoding:NSASCIIStringEncoding error:nil];
        origModifyDateStr=[ToolFun getStrFromPrefixAndPostfix:scriptTmpStr Prefix:@"-rw" Postfix:@".txt"];
         */
        //new method "openssl sha1 %@ >%@/vv.txt"-------------------------------------
         NSString *curModifyTimeCommand=[NSString stringWithFormat:@"openssl sha1 %@ >%@/vv.txt",stationStr,[permissionPath path]];
         system([curModifyTimeCommand UTF8String]);
         
         NSString*  curModifyDateAllStrTmp=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vv.txt",[permissionPath path]]  encoding:NSASCIIStringEncoding error:nil];
        int curModifyDataLength=[curModifyDateAllStrTmp length];
        while (curModifyDateAllStrTmp==nil || curModifyDataLength==0)
        {
            system([curModifyTimeCommand UTF8String]);
            usleep(500);
            curModifyDateAllStrTmp=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vv.txt",[permissionPath path]]  encoding:NSASCIIStringEncoding error:nil];
            curModifyDataLength=[curModifyDateAllStrTmp length];
        }
        
         curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@" " withString:@""];
         curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
         curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
         curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\t" withString:@""];
       
        NSString *curModifyStrTmp=[curModifyDateAllStrTmp substringFromIndex:curModifyDataLength-43];

         
         //-----get origin script modified data
         //NSString *scriptTmpStr=[NSString stringWithContentsOfFile:@"/Library/Java/lock.txt" encoding:NSASCIIStringEncoding error:nil];
         NSString *origModifyDateStr=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]] encoding:NSASCIIStringEncoding error:nil];
        int origModifyDateLength=[origModifyDateStr length];
        origModifyDateStr = [origModifyDateStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        origModifyDateStr = [origModifyDateStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        origModifyDateStr = [origModifyDateStr stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        origModifyDateStr = [origModifyDateStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        //-----write current script modified date to script-------------------
        if (origModifyDateStr==nil || origModifyDateLength==0) {
            if (strTestScriptPath!=nil)
            {
                FILE* fp=NULL;
                //fp=fopen([@"/Library/Java/lock.txt" UTF8String],"wr");
                fp=fopen([[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]] UTF8String],"wr");
                fclose(fp);
                
                //NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:@"/Library/Java/lock.txt"];
                NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]]];
                if (filehandTmp!=nil)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[curModifyStrTmp dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp closeFile] ;
                }
            }
            UnlockScriptSuccess();
        }else
        {   //-------------------new method -----------------------------------
            //bool mflag=[curModifyDateStr isEqualToString:origModifyDateStr];
            if (![curModifyStrTmp isEqualToString:origModifyDateStr])
            {
                if ([ScriptParse getValueFromSummary:@"NeedUnlockScript"]!=nil)
                {
                    NSString *cockFlagStr=[ScriptParse getValueFromSummary:@"NeedUnlockScript"];
                    if ([cockFlagStr isEqualToString:@"yes"])
                    {  //judge weather need cock script
                        [UIWinManage UIWin_UnlockScript];
                        
                    }else{
                        NSAlert *theAlert = [NSAlert alertWithError:nil];
                        [theAlert setMessageText:@"Locked the test script ! Please GH !"];
                        [theAlert setInformativeText:@"You modified the test script ?"];
                        [theAlert runModal];
                        return 1;
                    }
                }else{
                    NSAlert *theAlert = [NSAlert alertWithError:nil];
                    [theAlert setMessageText:@"Locked the test script ! Please GH !"];
                    [theAlert setInformativeText:@"You modified the test script ?"];
                    [theAlert runModal];
                    return 1;
                }

            }else
            {
               UnlockScriptSuccess(); 
            }
        }
    }
    //UnlockScriptSuccess();
	

#if 0 //test
	NSString *strPath = [NSString stringWithFormat:@"/aa%@",[ScriptParse getValueFromSummary:@"TestScript"]] ;
	NSRange rangeTmp = [strPath rangeOfString:@".txt"] ;
	if (rangeTmp.location!=NSNotFound)
	{
		strPath = [strPath stringByReplacingCharactersInRange:rangeTmp withString:@".plist"] ;
	    [ScriptParse convertScriptToPlist:strPath] ;
	}
#endif //endif	
	
	//NSLog(@"\n get snlength is :%@",[ScriptParse getValueFromSummary:@"SnLength"]);
	[NSApp run] ;
	[NSApp release] ;
	[pool release] ;
	
	return 0 ;
	
}

void UnlockScriptSuccess()
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
    bool bTmp ;    
    bTmp=[TestItemParse testItemParseInit];
    if (bTmp==false)
        [ToolFun setAPPInitLog:@"Testitemparse parse fail!"] ;
    //Modified by henry 2011-02-24
    //SCRID:94 modify by Henry for Prox Cal new fixture
    NSString* strUIName=[ScriptParse getValueFromSummary:@"SwitchUI"];
    //SCRID:94 modify end
    if([strUIName isEqualToString:@"UI3Prox"])
        bTmp=[UIWinManage UIWinManageInitProxCal] ;
    else
        bTmp=[UIWinManage UIWinManageInit] ;
    if (bTmp==false)
        [ToolFun setAPPInitLog:@"UI Window Manager init fail!"] ;
    
    [pool drain] ;
    
    
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        NSLog(@"writecsv");
        NSDate *ParametricDataCSVDate =[NSDate date];
        NSString *ParametricDataCSVFileName =[ParametricDataCSVDate description];
        
        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@" " withString:@""];
        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@":" withString:@""];
        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"-" withString:@""];
        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        ParametricDataFilePath = [[NSMutableString alloc] initWithString: @"/vault/ParametricData" ];
        [ParametricDataFilePath appendString:ParametricDataCSVFileName];
        [ParametricDataFilePath appendString:@".csv"];
        
        FILE* fp=NULL;
        fp=fopen([ParametricDataFilePath UTF8String],"wr");
        fclose(fp);
        
        NSString *stationName = [ScriptParse getValueFromSummary:@"TestStation"];
        NSString *version = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/version.txt"] encoding:NSASCIIStringEncoding error:nil];
        NSString *title = [NSString stringWithFormat:@"%@,%@\nProduct,SerialNumber,Special Build Description,Test Pass/Fail Status,StartTime,EndTime,",stationName,version];
        
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[title dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
        
    } //add by Rick for write csvfile 2012-10-27
    
    
    
    
    
    
    //NSLog(@"%@",[ScriptParse getDeviceInfo]) ;
    //[ScriptParse DeletePostfixInvisableChar:@"1234567890"] ;
    //=============dsx=======================
    int i=0;
    const char * DFUPath="open /Users/gdlocal/Desktop/DFU\\ Slurper.app"; //need to modify
    i=system(DFUPath);
    
    
    //added by caijunbo on 2010-09-10
    NSBundle* bundle =nil;
    NSString* strIsNeedBundle=[ScriptParse getValueFromSummary:@"SwitchUI"];
    NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
    /** SCRID:054 Modify for QT0b use 2 UI 2010-12-27 **/
    if (([strIsNeedBundle isEqualToString:@"UI4DP"])||([strIsNeedBundle isEqualToString:@"UI2QT"]))
    /** SCRID:054 end 2010-12-27 **/
    {
        /** SCRID-38: When DP Use serial cable instead of Ethernet Cable, no need replace serial port 2010-12-14 **/
        NSString*strAutoTrigger =[ScriptParse getValueFromSummary:@"AutoTrigger"];
        if ([strAutoTrigger boolValue])
        {
            NSAutoreleasePool * autoPool = [[NSAutoreleasePool alloc] init] ;
            NSString* DeviceFile1=@"";
            NSString* DeviceFile2=@"";
            NSArray *arrayDeviceList=[UartComm ScanPort] ;
            [arrayDeviceList retain];
            int icount=[arrayDeviceList count];
            if (icount>=2)
            {
                DeviceFile1=[arrayDeviceList objectAtIndex:0];
                DeviceFile2=[arrayDeviceList objectAtIndex:1];
                ReplaceDPDeviceFile(DeviceFile1,DeviceFile2);
            }
            
            [arrayDeviceList release];
            [autoPool drain];
        }
        /** SCRID-38 end **/
        //bundle = loadBundle();
        //DPBundle=bundle;
        //[DPBundle retain];
    }
    
    //added end by caijunbo on 2010-09-10
    
    //modified by caijunbo on 2010-10-12
    //else if([stationName isEqualToString:@"iPad-1"])//xiuxiu-2010-10-09 replace real uart address for ipad-1 at path vault/
    /** SCRID-34: Change iPad-1 to iPad-1b. Modify by Shou-Xiu **/
    //if([stationName isEqualToString:@"iPad-1"])
    if([stationName isEqualToString:@"iPad-1b"])
        //end modify
    {
        /*
         NSAutoreleasePool * autoPool = [[NSAutoreleasePool alloc] init] ;
         
         NSString* DeviceFile1=@"";
         NSString *fileName =@"";
         NSString *readFData=@"";
         
         NSArray *arrayDeviceList=[UartComm ScanPort] ;
         if ([arrayDeviceList count]>1)
         {
         DeviceFile1=[arrayDeviceList objectAtIndex:0];
         fileName = @"/vault/iFactoryTest/TesterConfig_oc.csv";
         //NSString *folderPath = @"/vault/iFactoryTest";
         readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
         }
         if([readFData rangeOfString: @"REALUART"].length>0)
         {
         readFData=[readFData stringByReplacingOccurrencesOfString:@"REALUART" withString:DeviceFile1];
         [readFData writeToFile:fileName atomically:YES encoding:NSASCIIStringEncoding error:NULL] ;
         }
         
         //[arrayDeviceList release];
         [autoPool release];
         */
        /** SCRID-34 Modify End**/
        
        //bundle = loadBundle();
        //DPBundle=bundle;
        //[DPBundle retain];
        
    }
    
    
    [UIWinManage UIWinSeleToRun] ;
}

void ReplaceDPDeviceFile(NSString* DeviceFile1,NSString* DeviceFile2)
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	if (DeviceFile1==nil||DeviceFile2==nil)
		return;
	
	NSString *fileName = @"/vault/iFactoryTest/TesterConfig_oc.csv";
	NSString *folderPath = @"/vault/iFactoryTest";
	NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	int uu = [readFData rangeOfString: @"davdp_site1"].location;
	NSString* readFData1 = @"";
	NSString* readFData2 = @"";
	if(uu < [readFData length])
	{
		readFData1 = [readFData substringToIndex:uu];
		readFData2 = [readFData substringFromIndex:uu];
	}
	//readFData = [readFData stringByReplacingOccurrencesOfString:@"bsdPath" withString:@"123Path"];
	int starIndex = [readFData rangeOfString: @"bsdPath"].location;
	int endIndex = 0;
	NSString* tmpS = readFData;
	NSString* eee = @"bsdPath=";
	starIndex = starIndex + [eee length];
	if(starIndex < [readFData length])
	{
		tmpS = [tmpS substringFromIndex:starIndex];
		endIndex = [tmpS rangeOfString: @"\r"].location;
		if(endIndex <= [tmpS length])
			tmpS = [tmpS substringToIndex: endIndex];
	}
	
	NSString* tmpS2 = [readFData substringFromIndex: starIndex + [tmpS length]];
	starIndex = [tmpS2 rangeOfString: @"bsdPath"].location;
	starIndex = starIndex + [eee length];
	if(starIndex < [tmpS2 length])
	{
		tmpS2 = [tmpS2 substringFromIndex:starIndex];
		endIndex = [tmpS2 rangeOfString: @"\r"].location;
		if(endIndex <= [tmpS2 length])
			tmpS2 = [tmpS2 substringToIndex: endIndex];
	}
	
	readFData1=[readFData1 stringByReplacingOccurrencesOfString:tmpS withString:DeviceFile1];
	readFData2=[readFData2 stringByReplacingOccurrencesOfString:tmpS2 withString:DeviceFile2];
	if(readFData1 != nil && readFData2 != nil)
	{
		readFData = @"";
		readFData = [readFData stringByAppendingString:readFData1];
		readFData = [readFData stringByAppendingString:readFData2];
	}
	
	
	
	//delete file
	NSString * sysCmd =@"rm -r ";
	sysCmd = [sysCmd stringByAppendingString:fileName];
	system([sysCmd UTF8String]);
	//create folder
	sysCmd =@"mkdir -p ";
	sysCmd = [sysCmd stringByAppendingString:folderPath];
	system([sysCmd UTF8String]);
	//create file
	FILE *fp;
	fp = fopen([fileName UTF8String], "wr");
	fclose(fp);
	
	NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:fileName];
	if (filehandTmp!=nil)
	{
		[filehandTmp seekToEndOfFile] ;
		[filehandTmp writeData:[NSData dataWithData:[readFData dataUsingEncoding:NSASCIIStringEncoding]]] ;
		[filehandTmp closeFile] ;
	}
	
	[pool release];
	
}


//added  by caijunbo on 2010-09-10

NSBundle* loadBundle()
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
    NSError* e;
    //we know the test we want to do
    //NSArray* testNames = [NSArray arrayWithObjects:@"ComAppleItestTestOneTestMethod1", nil];
    
    //build the path to the bundle
	//    NSString* folderPath = [[NSBundle mainBundle] builtInPlugInsPath];
    //  NSLog(@"plug in path is %@", folderPath);
	/*
	 NSArray* array = [NSArray arrayWithObjects:@"build", @"Debug", @"DisplayPort.bundle", nil];
	 NSString* folderPath = [NSBundle mainBundle] ;
	 NSLog(@"\n****The folder Path is: %@****\n",folderPath);
	 NSString* bundlePath = [NSString pathWithComponents:array];
	 //   NSLog(@"bundle path is %@", bundlePath);
	 */
	
	NSString* bundlePath =[[NSBundle mainBundle] pathForResource:@"DisplayPort" ofType:@"bundle"];
    //check if this is our bundle
    NSBundle* bundle = [NSBundle bundleWithPath:bundlePath];
    
    NSString* bundleIDStr = [bundle objectForInfoDictionaryKey:@"CFBundleIdentifier"];
    NSLog(@"bundle id is %@", bundleIDStr);
    
    //runmode is 0 for hardware, 1 for simulation
    NSDictionary* stationInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:1], @"runMode", nil];
	//    NSDictionary* stationInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:1], @"runMode", @"mybsdpath", @"bsdPath",nil];
    id suiteClass = [bundle principalClass];
    BOOL ret = [suiteClass onLoad:stationInfo error:&e];
    if(!ret )
    {
        NSAlert *theAlert = [NSAlert alertWithError:e];
        [theAlert runModal];
    }
    [stationInfo release];
    NSLog(@"DisplayPort.bundle version is; %@", [bundle objectForInfoDictionaryKey:@"CFBundleVersion"]);
    NSBundle* bundleFramework = [NSBundle bundleWithIdentifier:@"com.apple.iFactoryTest"];
    NSLog(@"iFactoryTest.framework version is: %@", [bundleFramework objectForInfoDictionaryKey:@"CFBundleVersion"]);
	
	[pool release];
	
	return bundle;
}
//added end by caijunbo on 2010-09-10





