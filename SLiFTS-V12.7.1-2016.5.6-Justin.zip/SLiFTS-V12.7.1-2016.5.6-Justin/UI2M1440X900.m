/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI2M1440X900.mm  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI2M1440X900.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */


#import "UI2M1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"

/*SCRID:59
 *2011-01-08 Xiu-Xiu modified
 */
//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGBUTTONMIN = {1340, 29,  30,	18};
static const UI_INFOR LOGBUTTONMAX = {1340, 29,  30,	18};
static const UI_INFOR LABELRESULT  = {230, 10,  140,	50};

static const UI_INFOR LOGTEXTMAX   = {-2,	-4, 690,	700};
static const UI_INFOR TABVIEWMAX   = {681,	 21, 706,	727};


#define UNITINDEX 1  //only test one unit and the unit index is 1

@implementation UI2M1440X900
-(id)init
{
	self = [super init] ;
	dicScanData = nil;
	stringModuleSn = [[NSMutableString alloc] init] ;
	stringModuleSn2 = [[NSMutableString alloc] init] ;
	
	return self ;
}

-(void)dealloc
{
	[stringModuleSn  release] ;
	[stringModuleSn2  release] ;
	[[NSNotificationCenter defaultCenter] removeObserver:self] ;
	[super dealloc] ;
}

- (void)awakeFromNib
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1 setFont:[NSFont userFontOfSize:25]] ;//28
		[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	}
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
		[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
		[textLabel2 setTextColor:[NSColor blackColor]];
	}
	
	[textTestResult setFrame:NSMakeRect(LABELRESULT.x, LABELRESULT.y, LABELRESULT.width, LABELRESULT.height)];
	[textTestResult setStringValue:@"No Unit"];
	[textTestResult setFont:[NSFont userFontOfSize:25]];//30
	[textTestResult setTextColor:[NSColor grayColor]] ;
	[textTestResult2 setFrame:NSMakeRect(LABELRESULT.x, LABELRESULT.y, LABELRESULT.width, LABELRESULT.height)];
	[textTestResult2 setStringValue:@"No Unit"];
	[textTestResult2 setFont:[NSFont userFontOfSize:25]];//30
	[textTestResult2 setTextColor:[NSColor grayColor]] ;
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	
	[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
	[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
	
	//check if need SN 
	NSString * strWhetherScanSN = [ScriptParse getValueFromSummary:STRKEYWHETHERSCANSN] ;
	if(strWhetherScanSN == nil)
		strWhetherScanSN = @"No";
	
	if(([strWhetherScanSN isEqualToString:@"No"])||([strWhetherScanSN isEqualToString:@"no"]))
    {
        [textModuleSN setEnabled:NO];
        [textModuleSN2 setEnabled:NO];
//		NSRunAlertPanel(@"WARNNING", @"Please check the SN needed !", @"prompt", nil, nil) ;
	}
	[textModuleSN becomeFirstResponder];
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];	
	}
	/*SCRID:68 by XiuXiu Fix Crash problem about UI2M1440X900 for iPad-1 */
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;//dsx -01-18 fix crash issue
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor2:) name:@"SET_UI_BGD_COLOR2" object:nil ] ;//dsx -01-18 fix crash issue
	[self showInitLog];
}
#pragma mark -
#pragma mark for unit 1
//table datasource implement method
-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	/*SCRID:61
	 *2011-01-08 Henry modified to add finally for return
	 */
	id retValue ;
	@try
	{
		NSInteger resultRowIdx =1; 
		if(tvTableview2==aTableView)
			resultRowIdx = 2;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			retValue = [UIWinManage getTestItemUIName:rowIndex] ;
		else
			retValue = [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex] ;
	}
	@catch (NSException * e) 
	{
		retValue =@"Test Item UI name or result error !";
		NSLog(@"ui2m tableview error\n");
	}
	@finally 
	{
		return retValue ;
	}
	//SCRID:61 end
}

//20100727 add for set box background color for Pass/fail
-(void)setTableBgdColor:(NSNotification*)notification/*SCRID:68 2011-01-18 by XiuXiu Fix Crash problem about UI2M1440X900 for iPad-1 */
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
	{
		if([[textTestResult stringValue] isEqualToString:@"Fail"])
		{
			[boxTestState setBoxType:NSBoxCustom];
			[boxTestState setBorderType:NSLineBorder];
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			//For COF
			//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([[textTestResult stringValue] isEqualToString:@"PASS"])
		{
			[boxTestState setBoxType:NSBoxCustom];
			[boxTestState setBorderType:NSLineBorder];
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
		}
		else 
		{
			//	[boxTestState setBoxType:NSBoxPrimary];
			[boxTestState setBoxType:NSBoxCustom];
			[boxTestState setBorderType:NSLineBorder];
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
		}
		[boxTestState display];
	}
	NSLog(@"set bgd color\n");
}

-(IBAction)btnStart_Click:(id)sender
{	
	//20100902 henry add for fixture ID check
	if(([strNeedFixtureID isEqualToString:@"yes"])&&([UICommon getFixtureIDScanedFlag] ==NO))
	{
		NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		[fixtureIdPanelController showWindow:self];
		return ;
	}
	
	//Henry added for refresh TableView
	[tvTableview reloadData];
	[tvTableview setUsesAlternatingRowBackgroundColors:YES];
	
	if([textModuleSN isEnabled])
	{
		[stringModuleSn setString:@""];
		[stringModuleSn appendString:[textModuleSN stringValue]];
		if (stringModuleSn==nil)
			return ;
		[stringModuleSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
		[stringModuleSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
		[stringModuleSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
		
		NSInteger len= [stringModuleSn length];
		NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
		NSInteger checkLen=12 ;
		if (strlen!=nil)
		{
			if ([strlen intValue]>0)
				checkLen = [strlen intValue] ;
		}
		
		if(len !=checkLen)
		{
			[textModuleSN setStringValue:@""];
			[textModuleSN becomeFirstResponder];
			return;
		}
		
		dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithString:stringModuleSn] ,STRKEYMODULESN,nil];
	}
	if([UIWinManage isCheckDUTID:1] == FALSE)
	{
		//[self showLog:0 isDisable:FALSE];
		NSLog(@"\n   dicScanData  is %@\n",dicScanData);
		[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :false ScanData:dicScanData] ;
		[textModuleSN setStringValue:@""];
		[textLabelModuleSnCopy setStringValue:stringModuleSn];//dsx copy scan string
		[textModuleSN2 becomeFirstResponder];//dsx-04-20
		dicScanData = nil;
	}
	else 
	{
		NSRunAlertPanel(@"WARNNING", @"Don't press Start button when it is running !", @"prompt", nil, nil) ;
	}
}

-(IBAction)btnCancel_Click:(id)sender
{
	[UIWinManage stopTest:1] ;
}

//text textModuleSnChange  change
-(IBAction)textModuleSnChange:(id)sender
{
	[stringModuleSn setString:@""];
	[stringModuleSn appendString:[textModuleSN stringValue]];
	if (stringModuleSn==nil)
		return ;
	[stringModuleSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	[stringModuleSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	[stringModuleSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	
	NSInteger len= [stringModuleSn length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[textModuleSN setStringValue:@""];
		[textModuleSN becomeFirstResponder];
	}
	else
	{	
		dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn,STRKEYMODULESN,nil];
        [btnStart performClick:textModuleSN];
		[btnStart becomeFirstResponder];
	}
}

#pragma mark -
#pragma mark for common 
-(void)showInitLog
{
	NSString *temStr =[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
		NSRunAlertPanel(@"init log info", temStr, @"prompt", nil, nil) ;
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

#pragma mark -
#pragma mark for unit 2
-(IBAction)btnStart2_Click:(id)sender
{
	//20100902 henry add for fixture ID check
	if(([strNeedFixtureID isEqualToString:@"yes"])&&([UICommon getFixtureIDScanedFlag] ==NO))
	{
		NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		[fixtureIdPanelController showWindow:self];
		return ;
	}
	
	//Henry added for refresh TableView
	[tvTableview2 reloadData];
	[tvTableview2 setUsesAlternatingRowBackgroundColors:YES];
	
	if([textModuleSN2 isEnabled])
	{
		[stringModuleSn2 setString:@""];
		[stringModuleSn2 appendString:[textModuleSN2 stringValue]];
		if (stringModuleSn2==nil)
			return ;
		[stringModuleSn2 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
		[stringModuleSn2 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
		[stringModuleSn2 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
		
		NSInteger len= [stringModuleSn2 length];
		NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
		NSInteger checkLen=12 ;
		if (strlen!=nil)
		{
			if ([strlen intValue]>0)
				checkLen = [strlen intValue] ;
		}
		
		if(len !=checkLen)
		{
			[textModuleSN2 setStringValue:@""];
			[textModuleSN2 becomeFirstResponder];
			return;
		}
		
		dicScanData2 = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithString:stringModuleSn2] ,@"strMouleSn",nil];
	}
	if([UIWinManage isCheckDUTID:2] == FALSE)
	{
		//[self showLog:0 isDisable:FALSE];
		NSLog(@"\n   dicScanData2  is %@\n",dicScanData2);
		[UIWinManage startTest:2 :tvTableview2 :textItemTime2 :textTotalTime2 :textTestResult2 :false ScanData:dicScanData2] ;
		[textModuleSN2 setStringValue:@""];
		[textLabelModuleSnCopy2 setStringValue:stringModuleSn2];//dsx copy scan string
		[textModuleSN becomeFirstResponder];
		dicScanData2 = nil;
	}
	else 
	{
		NSRunAlertPanel(@"WARNNING", @"Don't press Start button when it is running !", @"prompt", nil, nil) ;
	}
}

-(IBAction)btnCancel2_Click:(id)sender
{
	[UIWinManage stopTest:2] ;
}

-(IBAction)textModuleSnChange2:(id)sender
{
	[stringModuleSn2 setString:@""];
	[stringModuleSn2 appendString:[textModuleSN2 stringValue]];
	if (stringModuleSn2==nil)
		return ;
	[stringModuleSn2 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	[stringModuleSn2 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	[stringModuleSn2 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	
	NSInteger len= [stringModuleSn2 length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[textModuleSN2 setStringValue:@""];
		[textModuleSN2 becomeFirstResponder];
	}
	else
	{	
		dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn2,@"strMouleSn2",nil];
        [btnStart2 performClick:textModuleSN2];
		[btnStart2 becomeFirstResponder];
	}	
}
/*SCRID:68 2011-01-18 by XiuXiu Fix Crash problem about UI2M1440X900 for iPad-1 */
-(void)setTableBgdColor2:(NSNotification*)notification
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR2"])
	{
		if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
		{
			[boxTestState2 setBoxType:NSBoxCustom];
			[boxTestState2 setBorderType:NSLineBorder];
			[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			//For COF
			//[boxTestState2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
		{
			[boxTestState2 setBoxType:NSBoxCustom];
			[boxTestState2 setBorderType:NSLineBorder];
			[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
		}
		else 
		{
			//	[boxTestState2 setBoxType:NSBoxPrimary];
			[boxTestState2 setBoxType:NSBoxCustom];
			[boxTestState2 setBorderType:NSLineBorder];
			[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
		}
		[boxTestState2 display];	
	}	
	NSLog(@"set bgd color2\n");
}

@end
/*SCRID:59 end
 */