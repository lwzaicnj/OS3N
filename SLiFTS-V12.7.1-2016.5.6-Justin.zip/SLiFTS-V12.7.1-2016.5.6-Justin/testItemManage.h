/************************************************************
 //  testItemManage.h
 //  For UI use
 //  Created  on 5/12/10.
 //  
 //  All rights reserved.
 *************************************************************/

#import <Cocoa/Cocoa.h>

enum TestResutStatus
{
	RESULT_FOR_FAIL =0,
	RESULT_FOR_PASS =1,
	RESULT_FOR_COF= 2 ,
	RESULT_FOR_BYPASS=3 ,
	RESULT_FOR_OTHER=4,
	RESULT_FOR_ONTEST=5,
	RESULT_FOR_DEFINE =RESULT_FOR_PASS , 
} ; 
/*
enum UnitStatus
{
	UnitStatus_FOR_IBOOT,
	UnitStatus_FOR_DIAGS,
};
 */
@interface MyTestObject : NSObject {
    
}

-(void)test1:(NSTableView*)view;
-(void)test2:(NSTableView*)view;
-(void)test3:(NSTableView*)view;
-(void)test4:(NSTableView*)view;

@end

enum UnitStatus
{
	UnitStatus_FOR_IBOOT,
	UnitStatus_FOR_DIAGS,
    UnitStatus_FOR_FIXTURE,//added for px 20120710 Julian
    UnitStatus_FOR_FIXTURE_IN,//added for p105 20120727 Julian
    UnitStatus_FOR_FIXTURE_OUT,
};

@interface TestItemManage : NSObject {
	
}
+(bool)initTestItemInfo ; //general test item and test item action info
+(NSUInteger)getTestItemCount ;
+(NSString*)getTestItem:(int)iRow ;
+(NSAttributedString*)getTestItemResultForUI:(int)DUTID row:(int)iRow ;
+(NSArray*)getTestItemResult:(int)DUTID row:(int)iRow ;


//public function  --according with UI
+(void)StartTest:(NSTableView*)tableView :(NSTextField*)ItemTime :(NSTextField*)TotalTime :(NSTextField*)showPassOrFail :(NSDictionary*)dictUNITInfo :(bool)bDirection :(NSDictionary*)scanDataParm;
+(void)StopTest:(int)DUTID ;

+(bool)CheckThreadRun:(int)DUTID ;

//set the test result
+(void)setTestItemResult:(int)DUTID :(int)testItemIndex :(enum TestResutStatus)enumResult ;
+(void)setTestActionResult:(int)DUTID :(int)testItemIndex :(enum TestResutStatus)enumResult ;
+(void)setTestItemResultForUI:(int)DUTID :(int)testItemIndex :(NSString*)strResultForUI :(enum TestResutStatus)resultParm ;

//according with Data parse 
+(NSString*)getBufferValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey ;
+(void)setBufferValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue ;
+(NSString*)getSFCValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey ;
+(void)setSFCValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue ;
+(NSString*)getUnitValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey ;
+(void)setUnitValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue ;

+(NSString*)getUnitLogInfo:(int)DUTID;
+(void)setUnitLogInfo:(NSDictionary*)dictUNITInfo :(NSString*)strLogInfo :(bool)bWriteDataTime; //bWriteDataTime mean whether write current date and time 
+(NSString*)generalLogFileName:(NSDictionary*)dictUNITInfo; //general file name ,and return the filename ;

//set subtest item PDCA Log
+(void)setSubItemPDCAInfo:(NSDictionary*)dictUNITInfo :(NSString*)strSubItem :(NSString*)strSubSubItem :(NSString*)strLowLimit :(NSString*)strUpLimit
                         :(NSString*)strTestValue
                         :(NSString*)strTestUnit
                         :(enum TestResutStatus)enumTestResult
                         :(NSString*)strFailMsg  ;

+(NSArray*)getPDCAInfo:(NSDictionary*)dictUNITInfo ; //get PDCA info

+(NSString*)getScanValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey ;
+(void)setScanValue:(int)DUTID :(NSString*)strKey : (NSString*)strValue ;

+(bool)checkPriorTestItemResult:(NSDictionary*)dictUNITInfo ;//check prior test item result ,fail --false ,
+(bool)checkPriorAllTestItemResult:(NSDictionary*)dictUNITInfo ;//check prior all test item result .

//inner function
+(void)testEngineerThread:(NSDictionary*)dictParam ;
+(void)testTimerRefresh:(NSDictionary*)dictParam ; //Refresh timer
+(void)clearTestActionInfo:(NSString*)DUTID ; //Clear old message .
+(void)amountResultRefresh:(NSString*)DUTID :(NSTextField*)showPassOrFail ; //refresh The test result
+(void)setUnitLogInfoTitle:(NSDictionary*)dictUNITInfo :(int)testItemIndex :(int)testActionIndex :(int)Laye;  //0 --testitem ,1--testaction
+(void)setSYSSN:(NSDictionary*)dictUNITInfo ; 
+(void)handleStopFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex ; 
//set PDCA Log
+(void)setPDCAInfo:(NSDictionary*)dictUNITInfo :(int)index;
+(NSString*)getLogPath:(NSDictionary*)dictUNITInfo ;
+(void)printAllKeys;

+(NSString*)getResultInfo:(int)DUTID;
// Owner:Henry DATE :1.19.2011  SCRID:00 Desc  :Add for QT3
+(void)testEngineerThreadQT3:(NSDictionary*)dictParam ;
+(void)handleNotification:(NSString*)DUTID type:(NSString*)notificationType;
// Owner:Henry DATE :2.14.2011  for clean old thread
+(void)cleanThread:(NSString*)DUTID ;

//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
+(void)btnHandleStopFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex ; 
//SCRID:109 end

//Added by caijunbo on 2011-09-27
//Description:Used to handle network based cb failure
+(void)handleNetWorkCBFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex ; 
//end

//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
+(void)handleRetestItems:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex;
//SCRID:155 end

+(void)writeEZLinkLog:(NSString*)logPath :(NSString*)logContent;

@end
