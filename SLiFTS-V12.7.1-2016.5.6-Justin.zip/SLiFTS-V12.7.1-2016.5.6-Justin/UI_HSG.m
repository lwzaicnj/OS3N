//
//  UI_HSG.m
//  iFTS
//
//  Created by Annie on 4/12/13 for HSG station.


#import "WritePDCA.h"
#import "Pudding.h"
#import	"SFCConnecter.h"

#import <Foundation/Foundation.h>
#import <Foundation/NSURL.h>
#import "Foundation/NSURLHandle.h"
#import "Foundation/NSURLRequest.h"


#import "UI1QT1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"
#import "testItemParse.h"

//           UI Item Name             x,	 y,   Width, Height
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGBUTTONMIN = {1340, 29, 30,	18};
static const UI_INFOR LOGBUTTONMAX = {1340, 29, 30,	18};
static const UI_INFOR LOGTEXTMIN   = {1,    -11,	 291,	405};
static const UI_INFOR LOGTEXTMAX   = {1 ,	-11,	 1340,	652};
static const UI_INFOR TABVIEWMIN   = {1069,  41,  315,	440};
static const UI_INFOR TABVIEWMAX   = {11 ,	 41, 1359,	698};
//static const UI_INFOR LABELRESULT  = {1085, 10,  140,	50};

#define UNITINDEX 1



#import "UI_HSG.h"

NSMutableArray *SNNameArray;
NSMutableArray *SNValueArray;
NSMutableArray *SNValueAttributeArray;
NSMutableArray *checkLenArray;
NSMutableDictionary *mutdictTmp;
NSString *strTestStation;


NSMutableString * ParametricDataFilePath;//csv file name
bool CSVTitleFlag;
int scanSNTimes;//The toltal scan SN times.
float itemTime=0.0;
float totalTime=0.0;
NSDate *dateTmp;
NSTimer *freshTime;

@implementation UI_HSG

- (id)init
{
    self = [super init];
    if (self) {
                
        if (strTestStation==nil) {
            strTestStation=[[NSString alloc] init];
        }
        strTestStation = [ScriptParse getValueFromSummary:@"TestStation"] ;
        if ([strTestStation isEqualToString:@"2DBarcode"])
        {
            SNNameArray =[[NSMutableArray alloc] init];
            SNNameArray =[NSMutableArray arrayWithObjects:@"SN",@"Display",@"BLU",@"Grape",@"Vendor",@"WritePDCA", nil];
            [SNNameArray retain];
            SNValueArray=[[NSMutableArray alloc] init];
            SNValueArray=[NSMutableArray arrayWithObjects:@"",@"",@"",@"",@"",@"", nil];
            [SNValueArray retain];
            checkLenArray=[NSMutableArray arrayWithObjects:@"false",@"false",@"false",@"false",@"false",@"false",nil];
            [checkLenArray retain];
            
            SNValueAttributeArray=[[NSMutableArray alloc] init];
            //        SNValueAttributeArray=[NSMutableArray arrayWithObjects:nil,nil,nil,nil,nil, nil];
            //        [SNValueAttributeArray retain];
            mutdictTmp=[[NSMutableDictionary alloc] init];
            CSVTitleFlag=false;
        }
        else if([strTestStation isEqualToString:@"HSG"])
        {

            SNNameArray =[[NSMutableArray alloc] init];
            //SNNameArray =[NSMutableArray arrayWithObjects:@"Unit SN",@"IX:Inner X data",@"IY:Inner Y data",@"AF:Datum A Flatness",@"BF:Backside flatness",@"WritePDCA", nil];
            //modify for HSG 2D Barcode   Annie 2014.02.24//
            SNNameArray =[NSMutableArray arrayWithObjects:@"Unit SN",@"Inner X",@"Inner Y",@"Datum A",@"Backside Flatness",@"Logo Battery Offset",@"Battery Wall Thickness",@"WritePDCA", nil];
            [SNNameArray retain];
            SNValueArray=[[NSMutableArray alloc] init];
            SNValueArray=[NSMutableArray arrayWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",  nil];
            [SNValueArray retain];
            checkLenArray=[NSMutableArray arrayWithObjects:@"false",@"false",@"false",@"false",@"false",@"false",@"false",@"false", nil];
            [checkLenArray retain];
            
            SNValueAttributeArray=[[NSMutableArray alloc] init];
    //        SNValueAttributeArray=[NSMutableArray arrayWithObjects:nil,nil,nil,nil,nil, nil];
    //        [SNValueAttributeArray retain];
            mutdictTmp=[[NSMutableDictionary alloc] init];
            CSVTitleFlag=false;
        }
        
    }
    return self;
}

- (void)awakeFromNib
{
    scanSNTimes=0;
    //initial result attribute
    //for (int i=0; i<6; i++) {
    int countTmp=[SNNameArray count];
    for (int i=0; i<countTmp; i++) {
        NSString *StrTmp=[SNValueArray objectAtIndex:i];
        //[self setResultAttribut:i :[SNValueArray objectAtIndex:i]];
        [self setResultAttribut:i :StrTmp:[SNNameArray objectAtIndex:i]:@"true"];
    }
    
    float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	
	
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
		[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	}
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
		[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
		[textLabel2 setTextColor:[NSColor blackColor]];
	}
	
	[itemTimeTxt setStringValue:@"0.0"];
    [totalTimeTxt setStringValue:@"0.0"];
    
	NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
	
//	if([stationName isEqualToString:@"Connectivity2 Test"])
//	{
//		[textLabelSysSn setStringValue:@"LCD SN"];
//		[textLabelBarCode setStringValue:@"Grape SN"];
//	}
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[NSBundle mainBundle];
	NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
    //	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	[imageAppleLogo release];
	[imageBgd release];
//	[[textTestResultDetail documentView]setEditable:false] ;
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
    
}

-(void)freshTestTimes
{
    //NSDate *dateTmp=[[[NSDate alloc] init] autorelease];
    float timeInterVal=-[dateTmp timeIntervalSinceNow];
    itemTime=timeInterVal;
    [itemTimeTxt setStringValue:[NSString stringWithFormat:@"%5.2f",timeInterVal]];
    //[totalTimeTxt setStringValue:[NSString stringWithFormat:@"%5.2f",totalTime+itemTime]];
    [totalTimeTxt setStringValue:[NSString stringWithFormat:@"%5.2f",totalTime]];
}


-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [SNNameArray count] ;
}
//
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
    if ([[aTableColumn identifier] isEqualToString:@"TestItem"]) {
        return [SNNameArray objectAtIndex:rowIndex];
        
    }else
    {
        //return nil;
        //return [SNValueArray objectAtIndex:rowIndex];
        return [self getResultAttribut:rowIndex];
    }
    
}


-(IBAction)textSysSnChange:(id)sender
{
    NSMutableString *strSNTmp=[[NSMutableString alloc] init];
	[strSNTmp setString:@""];
	[strSNTmp appendString:[inputSNTxt stringValue]];
	if (strSNTmp==nil)
		return ;
	[strSNTmp replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [strSNTmp length])];
	[strSNTmp replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [strSNTmp length])];
	[strSNTmp replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [strSNTmp length])];
	
	NSInteger len= [strSNTmp length];
	
    [inputSNTxt setStringValue:@""];
    if(scanSNTimes==0)
	{
        if (len !=12)
        {
            [inputSNTxt becomeFirstResponder];
            [strSNTmp release];
            return ;
        }else
        {   //--add scan sn value to SNValueArray array---------------
            [SNValueArray replaceObjectAtIndex:scanSNTimes withObject:strSNTmp];
            [self setResultAttribut:scanSNTimes:strSNTmp:[SNNameArray objectAtIndex:scanSNTimes]:@"true"];

            int b=3;
            [HSG_tableView reloadData];
            [strSNTmp release];
            [checkLenArray replaceObjectAtIndex:scanSNTimes withObject:@"true"];
            //   [dicScanData setObject:[NSString stringWithString:stringSysSn] forKey:STRKEYSYSSN] ;
            if ([strTestStation isEqualToString:@"2DBarcode"])
            {
                for (int i=1; i<6; i++)//clean and inital all the sn value
                {
                    NSString *StrTmp=[SNValueArray objectAtIndex:i];
                    [self setResultAttribut:i :StrTmp:[SNNameArray objectAtIndex:i]:@"true"];
                    [SNValueArray replaceObjectAtIndex:i withObject:@""];
                    [checkLenArray replaceObjectAtIndex:i withObject:@""];
                }
            }else if ([strTestStation isEqualToString:@"HSG"])
            {
                for (int i=1; i<8; i++)//clean and inital all the sn value
                {
                    NSString *StrTmp=[SNValueArray objectAtIndex:i];
                    [self setResultAttribut:i :StrTmp:[SNNameArray objectAtIndex:i]:@"true"];
                    [SNValueArray replaceObjectAtIndex:i withObject:@"false"];
                    [checkLenArray replaceObjectAtIndex:i withObject:@"false"];
                }

            }
            
            // start fresh timer
            dateTmp=[[NSDate alloc] init];
            totalTime=0;
            itemTime=0;
            freshTime=[[NSTimer scheduledTimerWithTimeInterval:0.1
                                                                    target:self
                                                                  selector:@selector(freshTestTimes)
                                                                  userInfo:nil
                                                                   repeats:YES] retain];
        }
	}else
    {
        if ([strTestStation isEqualToString:@"2DBarcode"])
        {
            dateTmp=[[NSDate alloc] init];//// start count fresh timer
            int scanStrLenth=[strSNTmp length];
            int snSequ;
            
            if (scanStrLenth==75)
            {
                snSequ=1;
                scanSNTimes ++;
                
            }else if (scanStrLenth==17)
            {
                snSequ=2;
                scanSNTimes ++;
            }
            else if(scanStrLenth==24)
            {
                snSequ=3;
                scanSNTimes ++;
            }
            else if (scanStrLenth==13)
            {
                snSequ=4;
                scanSNTimes ++;
                
            }
            else{
                [inputSNTxt becomeFirstResponder];
                [strSNTmp release];
                return ;
            }
            
            [SNValueArray replaceObjectAtIndex:snSequ withObject:strSNTmp];
            [checkLenArray replaceObjectAtIndex:snSequ withObject:@"true"];
            
            [self setResultAttribut:snSequ:strSNTmp:[SNNameArray objectAtIndex:snSequ]:@"true"];
            //NSAttributedString *strTmp=[self getResultAttribut:scanSNTimes];
            //int b=3;
            
            totalTime=totalTime+itemTime;
            itemTime=0;
            [HSG_tableView reloadData];
            [strSNTmp release];
            
        }
        else if([strTestStation isEqualToString:@"HSG"])
        {
            //----1D HSG Barcode scan ok---->delete 2014.2.24 for 2D Barcode-------------------
            /*
           NSString *firstStrFix=[strSNTmp substringToIndex:2];
           dateTmp=[[NSDate alloc] init];//// start count fresh timer

            int snSequ;
            if ([firstStrFix isEqualToString:@"IX"])
            {
                snSequ=1;
                
            }else if ([firstStrFix isEqualToString:@"IY"])
            {                
                snSequ=2;
            }else if ([firstStrFix isEqualToString:@"AF"])
            {                
                snSequ=3;
            }else if ([firstStrFix isEqualToString:@"BF"])
            {
                snSequ=4;
                
            }else
            {
                [inputSNTxt becomeFirstResponder];
                [strSNTmp release];
                return ;               
            }
            NSString * strSNTmp0=[strSNTmp substringFromIndex:2];
            [SNValueArray replaceObjectAtIndex:snSequ withObject:strSNTmp0];
            [checkLenArray replaceObjectAtIndex:snSequ withObject:@"true"];            
            
            [self setResultAttribut:snSequ:strSNTmp0:[SNNameArray objectAtIndex:snSequ]:@"true"];

            int b=3;
            
            totalTime=totalTime+itemTime;
            itemTime=0;
            [HSG_tableView reloadData];
            [strSNTmp release];
            */
            
            // 2D Barcode scan 2014.2.24 Annie--------------------------------
            NSString *firstStrFix=[strSNTmp substringToIndex:2];
            dateTmp=[[NSDate alloc] init];//// start count fresh timer
            NSArray *HSG2DBarArray=[strSNTmp componentsSeparatedByString:@","]; //Creat for HSG2DBarcode
            
            int snSequ;
            //HSG2DBarArray=[strSNTmp componentsSeparatedByString:@","];
            if ([HSG2DBarArray count] !=30) {
                [inputSNTxt becomeFirstResponder];
                [strSNTmp release];
                return ;
            }
            NSString *StrTmp=[HSG2DBarArray objectAtIndex:0];
            if ((![StrTmp rangeOfString:@"XY"].length<=0&&(![StrTmp isEqualToString:@"OK"]))) {
            //if ((![StrTmp isEqualToString:@"XY1"])) {
                [inputSNTxt becomeFirstResponder];
                [strSNTmp release];
                return ;
            }
            snSequ=1;
           
            NSMutableString *TmpStr=[[NSMutableString alloc] initWithString:@""];
            int comNum=0;
            NSRange comRange=[strSNTmp rangeOfString:@","];
            
            while (comRange.length>0) {
                
                NSString *ss=[strSNTmp substringToIndex:comRange.location+1];
                [TmpStr appendString:ss];
                
                NSRange rangClear ;
                rangClear.location = 0 ;
                rangClear.length = comRange.location+comRange.length ;
                [strSNTmp deleteCharactersInRange:rangClear] ;
                
                comRange=[strSNTmp rangeOfString:@","];
                if (comNum==4) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:1 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:1 withObject:@"true"];
                    [self setResultAttribut:1:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                if (comNum==8) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:2 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:2 withObject:@"true"];
                    [self setResultAttribut:2:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                if (comNum==9) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:3 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:3 withObject:@"true"];
                    [self setResultAttribut:3:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                if (comNum==10) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:4 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:4 withObject:@"true"];
                    [self setResultAttribut:4:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                if (comNum==11) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:5 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:5 withObject:@"true"];
                    [self setResultAttribut:5:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                /*
                if (comNum==28) {
                    StrTmp=[strSNTmp substringToIndex:comRange.location];
                    [SNValueArray replaceObjectAtIndex:6 withObject:TmpStr];
                    [checkLenArray replaceObjectAtIndex:6 withObject:@"true"];
                    TmpStr=[NSMutableString stringWithString:@""];
                }
                */
                comNum++;
            }
            [TmpStr appendString:strSNTmp];
            [SNValueArray replaceObjectAtIndex:6 withObject:TmpStr];
            [checkLenArray replaceObjectAtIndex:6 withObject:@"true"];
            [self setResultAttribut:6:TmpStr:[SNNameArray objectAtIndex:1]:@"true"];
            
            totalTime=totalTime+itemTime;
            itemTime=0;
            [HSG_tableView reloadData];
            [strSNTmp release];
            
            [self WritePDCA_HSG:nil];
            [self WriteCSVFile];
            
            scanSNTimes=0;
            [freshTime invalidate];
            [freshTime release];
            for (int i=0; i<8; i++)
            {
                [checkLenArray replaceObjectAtIndex:i withObject:@"false"];
                [SNValueArray replaceObjectAtIndex:i withObject:@""];
            }
            [boxTestState setFillColor:[NSColor greenColor]];

            return ;
        }
    }
    //scanSNTimes++;
    scanSNTimes=scanSNTimes+1;
    [inputSNTxt becomeFirstResponder];
    if ([[checkLenArray objectAtIndex:0] isEqualToString:@"true"] && [[checkLenArray objectAtIndex:1] isEqualToString:@"true"] &&[[checkLenArray objectAtIndex:2] isEqualToString:@"true"] &&[[checkLenArray objectAtIndex:3] isEqualToString:@"true"] &&[[checkLenArray objectAtIndex:4] isEqualToString:@"true"])
    {
        [self WritePDCA_HSG:nil];
        [self WriteCSVFile];
        
        scanSNTimes=0;
        [freshTime invalidate];
        [freshTime release];
        for (int i=0; i<5; i++)
        {
            [checkLenArray replaceObjectAtIndex:i withObject:@"false"];
            [SNValueArray replaceObjectAtIndex:i withObject:@""];
        }
        [boxTestState setFillColor:[NSColor greenColor]];
    }
    
}

-(void)WriteCSVFile
{
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        NSLog(@"writecsv");
        
        NSString *title =@"";
        NSString *valueStr =@"";
        
        if (!CSVTitleFlag)
        {
                    
            NSDate *ParametricDataCSVDate =[NSDate date];
            NSString *ParametricDataCSVFileName =[ParametricDataCSVDate description];
            
            ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@" " withString:@""];
            ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@":" withString:@""];
            ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"-" withString:@""];
            ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            //NSMutableString * ParametricDataFilePath = [[NSMutableString alloc] initWithString: @"/vault/HSG" ];
            ParametricDataFilePath = [[NSMutableString alloc] initWithString: @"/vault/HSG" ];
            [ParametricDataFilePath appendString:ParametricDataCSVFileName];
            [ParametricDataFilePath appendString:@".csv"];
            
            FILE* fp=NULL;
            fp=fopen([ParametricDataFilePath UTF8String],"wr");
            fclose(fp);
            
            NSString *stationName = [ScriptParse getValueFromSummary:@"TestStation"];
            NSString *version = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/version.txt"] encoding:NSASCIIStringEncoding error:nil];
            //NSString *title = [NSString stringWithFormat:@"%@,%@\nProduct,SerialNumber,Special Build Description,Test Pass/Fail Status,StartTime,EndTime,",stationName,version];

            if ([strTestStation isEqualToString:@"HSG"])
            {
                title = [NSString stringWithFormat:@"SN,Inner_X,Inner_Y,Datum A,Backside Flatness,Logo Battery Offset,Battery Wall Thickness,Write PDCA \n"];
                
                NSString *tmpS=@"";
                for (int i=0; i<[SNNameArray count]-1; i++) {
                    tmpS=[SNValueArray objectAtIndex:i];
                    tmpS = [tmpS stringByReplacingOccurrencesOfString:@"," withString:@" "];
                    [SNValueArray replaceObjectAtIndex:i withObject:tmpS];
                    
                }
                valueStr = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@,%@ \n",[SNValueArray objectAtIndex:0],[SNValueArray objectAtIndex:1],[SNValueArray objectAtIndex:2],[SNValueArray objectAtIndex:3],[SNValueArray objectAtIndex:4],[SNValueArray objectAtIndex:5],[SNValueArray objectAtIndex:6],[SNValueArray objectAtIndex:7]];
                
            }
            else if ([strTestStation isEqualToString:@"2DBarcode"])
            {
                title = [NSString stringWithFormat:@"SN,Display,BLU,Grape,Vendor \n"];
                valueStr = [NSString stringWithFormat:@"%@,%@,%@,%@,%@ \n",[SNValueArray objectAtIndex:0],[SNValueArray objectAtIndex:1],[SNValueArray objectAtIndex:2],[SNValueArray objectAtIndex:3],[SNValueArray objectAtIndex:4]];
                
                
            }
            
           
            NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];

            if (filehandTmp!=nil)
            {
                [filehandTmp seekToEndOfFile] ;
                [filehandTmp writeData:[NSData dataWithData:[title dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[valueStr dataUsingEncoding:NSASCIIStringEncoding]]] ;               
                [filehandTmp closeFile] ;
                CSVTitleFlag=true;
            }
        }else
        {
            
            NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];
            //NSString *valueStr = [NSString stringWithFormat:@"%@,%@,%@,%@,%@  \n",[SNValueArray objectAtIndex:0],[SNValueArray objectAtIndex:1],[SNValueArray objectAtIndex:2],[SNValueArray objectAtIndex:3],[SNValueArray objectAtIndex:4]];
            
            if (filehandTmp!=nil)
            {
                [filehandTmp seekToEndOfFile] ;
                [filehandTmp writeData:[NSData dataWithData:[valueStr dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp closeFile] ;
            }

        }
            
        
    }

}

-(void)WritePDCA_HSG:(NSDictionary*)dictKeyDefined
{
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        NSMutableArray* itemNameForCSV = [[NSMutableArray alloc] init];
//        upLimitForCSV = [[NSMutableArray alloc] init];
//        lowLimitForCSV = [[NSMutableArray alloc] init];
//        valueForCSV = [[NSMutableArray alloc] init];
    }
    
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
    
	NSString* AttributesForPudding = nil;

	NSArray* itemsForPudding =  [[NSArray alloc] init];
	itemsForPudding= [NSMutableArray arrayWithArray:SNValueAttributeArray] ;
	Pudding* puddintInstanse = [[Pudding alloc] init];
	//Get From Scrip instead of default Value
	//NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];// [TestItemManage getBufferValue:dictKeyDefined :@"SN"] ;
    NSString *strSN = [SNValueArray objectAtIndex:0];
    
    
	NSString* initRet = @"";
    //initRet = [puddintInstanse initPuddingWithSwVersion:[ScriptParse getSWVerision] SwName:<#(NSString *)#> SerialNumber:<#(NSString *)#> LimitsVersion:<#(NSString *)#> StationIdentifier:<#(NSString *)#> StartTime:<#(long)#>]
	initRet = [puddintInstanse initPuddingWithSwVersion:[ScriptParse getSWVerision] SwName:@"iFTS" SerialNumber:strSN LimitsVersion:@"1.1" StationIdentifier:[ScriptParse getStationID] StartTime:nil];
	if([initRet rangeOfString:@"FAIL"].length>0)
	{
		NSLog(@"Write pdca initPuddingWithSwVersion fail");
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
        [self setResultAttribut:[SNNameArray count]-1:initRet:[SNNameArray objectAtIndex:[SNNameArray count]-1]:@"false"];
		return;
	}
	NSLog(@"Write pdca initPuddingWithSwVersion pass");
	
	int returnvalue = -1;

    //for(int i=0;i<5;i++ )
    int n=[SNNameArray count];
    for(int i=0;i<n-1;i++ )
    {
        NSString*  AttributeValue = [SNValueArray objectAtIndex:i];
        //Get From manager
        if(nil==AttributeValue)
            AttributeValue= @"";
        initRet = [puddintInstanse puddingAttributeWithKeyName:[SNNameArray objectAtIndex:i] andKeyValue:AttributeValue];
        if([initRet rangeOfString:@"FAIL"].length>0)
        {
            NSLog(@"Write pdca puddingAttributeWithKeyName fail");
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
            return;
        }
    }
    
	NSLog(@"dp dp dp itemsForPudding=%@", itemsForPudding);
//    int count = 0;
//	for(NSDictionary* item in itemsForPudding)
//	{
//
//        
//        returnvalue = [puddintInstanse puddingWithParametricDataForTestItem:(NSString*)[item objectForKey:@"SNName"]
//                                                                SubTestItem:nil
//                                                             SubSubTestItem:nil
//                                                                   LowLimit:nil
//                                                                    UpLimit:nil
//                                                                  TestValue:(NSString*)[item objectForKey:@"SNResultStr"]
//                                                                   TestUnit:nil
//                                                                 TestResult:nil
//                                                                    FailMsg:nil
//                                                                   Priority:0];
//
//		NSString *testItemName = [item objectForKey:@"SNName"];
//        
//		NSLog(@"dp dp dp testItemName=%@", testItemName);
//		if(returnvalue < 0)
//		{
//			NSLog(@"Write pdca puddingWithParametricDataForTestItem fail");
//			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD TESTRESULT FAIL"];
//            NSString *strTmp=@"ADD TESTRESULT FAIL";
//            [self setResultAttribut:count:strTmp:[SNNameArray objectAtIndex:count]:@"false"];
//            [HSG_tableView reloadData];
//
//			return;
//		}
//        count++;
//        
//     }
//
//	NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
    
	//for(int i=0;i<5;i++)
    for(int i=0;i<[SNNameArray count]-1;i++)
	{
        
        
        returnvalue = [puddintInstanse puddingWithParametricDataForTestItem:(NSString*)[SNNameArray objectAtIndex:i]
                                                                SubTestItem:nil
                                                             SubSubTestItem:nil
                                                                   LowLimit:nil
                                                                    UpLimit:nil
                                                                  TestValue:(NSString*)[SNValueArray objectAtIndex:i]
                                                                   TestUnit:nil
                                                                 TestResult:1
                                                                    FailMsg:nil
                                                                   Priority:0];
        
		NSString *testItemName = [SNNameArray objectAtIndex:i];
        
		NSLog(@"dp dp dp testItemName=%@", testItemName);
		if(returnvalue < 0)
		{
			NSLog(@"Write pdca puddingWithParametricDataForTestItem fail");
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD TESTRESULT FAIL"];
            NSString *strTmp=@"ADD TESTRESULT FAIL";
            [self setResultAttribut:[SNNameArray count]-1:strTmp:[SNNameArray objectAtIndex:[SNNameArray count]-1]:@"false"];
            [HSG_tableView reloadData];
            
			return;
		}
        
    }
    
	NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");

	
	NSString* Logpath = [TestItemManage getLogPath:dictKeyDefined];
	if(nil != Logpath )
	{
		returnvalue = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:Logpath];
		if( returnvalue < 0)
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD BLOB FAIL"];
            [self setResultAttribut:[SNNameArray count]-1:@"ADD BLOB FAIL":[SNNameArray objectAtIndex:[SNNameArray count]-1]:@"false"];
            [HSG_tableView reloadData];
			return;
		}
	}
	NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
	
	NSString * reErrorM =@"Fail";
	//returnvalue = [puddintInstanse puddingCommit];
	reErrorM = [puddintInstanse puddingCommit];

	NSString* strUIName=[ScriptParse getValueFromSummary:@"SwitchUI"];

    if([reErrorM rangeOfString:@"FAIL"].length>0)
		{
			NSLog(@"Write pdca puddingCommit fail");
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
            [self setResultAttribut:[SNNameArray count]-1:strTestResultForUIinfo:[SNNameArray objectAtIndex:[SNNameArray count]-1]:@"false"];
		}
		else
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo =@"Pass" ;
            [self setResultAttribut:[SNNameArray count]-1:strTestResultForUIinfo:[SNNameArray objectAtIndex:[SNNameArray count]-1]:@"true"];
			NSLog(@"Write pdca puddingCommit pass");
		}

    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
    //[self setResultAttribut:count:strTestResultForUIinfo:[SNNameArray objectAtIndex:count]:@"false"];
    [HSG_tableView reloadData];
    
    
}

-(void)setResultAttribut:(int)ItemIndex:(NSString *)ValueTmp:(NSString *)ValueName:(NSString *)TestResult
{
    //    NSMutableDictionary *dictTmp=[SNValueAttributeArray objectAtIndex:ItemIndex];
    //    if (dictTmp==nil) {
    //        dictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
    //    }
    
    NSMutableDictionary *dictTmp=[[[NSMutableDictionary alloc] init] autorelease];
    NSDictionary *txtDict=[[[NSMutableDictionary alloc] init] autorelease];
    //--add to result attribut dictionary
    
    if ([TestResult boolValue]) {
        txtDict = [NSDictionary dictionaryWithObjectsAndKeys:[NSFont userFontOfSize:13],NSFontAttributeName,[NSColor blueColor],NSForegroundColorAttributeName ,nil];
        //NSAttributedString *attrStr1 = [[[NSAttributedString alloc] initWithString:ValueTmp attributes:txtDict] autorelease];
        
    }else{
        txtDict = [NSDictionary dictionaryWithObjectsAndKeys:[NSFont userFontOfSize:16],NSFontAttributeName,[NSColor redColor],NSForegroundColorAttributeName ,nil];
        //NSAttributedString *attrStr1 = [[[NSAttributedString alloc] initWithString:ValueTmp attributes:txtDict] autorelease];
    }
    
    NSAttributedString *attrStr1 = [[[NSAttributedString alloc] initWithString:ValueTmp attributes:txtDict] autorelease];
    [dictTmp setObject:attrStr1 forKey:@"SNValueAttribute"] ;
    [dictTmp setObject:ValueTmp forKey:@"SNResultStr"];
    [dictTmp setObject:ValueName forKey:@"SNName"];
    [dictTmp setObject:TestResult forKey:@"TestResult"];
    
    //-----add sn value and sn display attribute to SNValueAttributeArray array
    if ((ItemIndex+1)>[SNValueAttributeArray count]) {
        [SNValueAttributeArray addObject:dictTmp];
    }else{
        
        [SNValueAttributeArray replaceObjectAtIndex:ItemIndex withObject:dictTmp];
    }
    
}

-(NSMutableAttributedString *)getResultAttribut:(int)ItemIndex
{
    NSMutableDictionary *dictTmp=[SNValueAttributeArray objectAtIndex:ItemIndex];
    return [dictTmp objectForKey:@"SNValueAttribute"];
}


@end
