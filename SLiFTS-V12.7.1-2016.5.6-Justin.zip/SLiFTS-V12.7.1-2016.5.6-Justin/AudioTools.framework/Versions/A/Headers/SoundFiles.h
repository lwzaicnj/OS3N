#ifndef mpetit__audio_tools__sound_files__hh__
#define mpetit__audio_tools__sound_files__hh__

#include <string>
#include <vector>


extern int load_sound_file(std::string const &fname, std::vector<std::vector<int16_t> > &channels);
extern int load_sound_file(std::string const &fname, std::vector<std::vector<float  > > &channels);
extern int load_sound_file(std::string const &fname, std::vector<std::vector<double > > &channels);



extern int save_sound_file(std::string const &fname, std::vector<std::vector<int16_t> > const &channels, unsigned sample_rate = 48000);
extern int save_sound_file(std::string const &fname, std::vector<int16_t> const &channels, unsigned sample_rate = 48000);

//NOTE: For saving non-int16_t vectors to wav, each sample must fall in the range [-1,1]
extern int save_sound_file(std::string const &fname, std::vector<std::vector<float  > > const &channels, unsigned sample_rate = 48000);
extern int save_sound_file(std::string const &fname, std::vector<float> const &channels, unsigned sample_rate = 48000);
extern int save_sound_file(std::string const &fname, std::vector<std::vector<double > > const &channels, unsigned sample_rate = 48000);
extern int save_sound_file(std::string const &fname, std::vector<double > const &signal, unsigned sample_rate = 48000);


template <typename T>
std::vector<std::vector<T> >
load_sound_file(std::string const &fname)
{
	std::vector< std::vector<T> > retval;

	load_sound_file(fname, retval);

	return retval;
}

#endif
