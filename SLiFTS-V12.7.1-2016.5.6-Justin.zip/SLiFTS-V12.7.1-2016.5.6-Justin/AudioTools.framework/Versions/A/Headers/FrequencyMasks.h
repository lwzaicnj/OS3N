#ifndef audio_tools__frequency_masks__hh__
#define audio_tools__frequency_masks__hh__


#include <vector>
#include <FTK/option.h>


struct mask_violation_item_t
{
	std::string mask_name;
	double      start_freq;
	double      stop_freq;
	double      max_excursion;
	double      peak_value;
};

struct mask_point
{
	double         point;
	
	option<double> cof_max;
	option<double> max;
	option<double> min;
	option<double> cof_min;
};



typedef std::vector<mask_violation_item_t> mask_violation_t;

struct sub_mask_segment_list_t;



struct mask_specification_t
{
	mask_specification_t(FTKValue val);

	mask_violation_t verify(std::vector<double> const &mag, double sample_rate, bool cof_limits = false);
	mask_violation_t verify(std::vector<double> const &mag, std::vector<double> const &freqs, double sample_rate, bool cof_limits = false);

	/*
	 * XXX : mpetit : ideally asking for a cof verification in a
	 *                mask without CoF limits should raise an
	 *                exception. However, I dislike exceptions, so
	 *                the current behavior is that if there are no
	 *                explicit CoF limits, then CoF limits are
	 *                implicitly the normal limits. And I provide an
	 *                inspector to query the existance of explicit
	 *                CoF limits.
	 *
	 * XXX : mpetit : consider an API review.
     */
	bool has_cof_limits() const;

	mask_point mask_point_at(double freq);

	virtual ~mask_specification_t();

private:
	sub_mask_segment_list_t *m_specs;
};


#endif
