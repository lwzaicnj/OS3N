#ifndef renard_series__hh__
#define renard_series__hh__


#include <vector>


/*
 * this computes the Renard series (as used by ISO.3, and ITU standards (R10 is the typical
 * frequecy distribution used in LR and similar calculations, and R40 is close to what 
 * FACT used to do
 */
enum
{
	RENARD_SERIES_5  =  5,
	RENARD_SERIES_10 = 10,
	RENARD_SERIES_20 = 20,
	RENARD_SERIES_40 = 40,
	RENARD_SERIES_80 = 80,
};

std::vector<double> renard_series(double low, double high, unsigned resolution);


#endif