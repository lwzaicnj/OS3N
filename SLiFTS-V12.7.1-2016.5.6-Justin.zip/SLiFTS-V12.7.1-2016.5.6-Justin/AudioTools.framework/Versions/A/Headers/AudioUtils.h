#ifndef audio_utils__hh__
#define audio_utils__hh__


#include <complex>
#include <vector>
#include <string>
#include <fstream>
#include <iomanip>


#define SIGNAL_FLOOR (1e-24)


#define SAVE_ARRAYS    0
#define SAVE_PRECISION 5


#ifndef __cplusplus
# error AudioUtils can only be used from C++
#endif


typedef std::complex<double> complex;


unsigned long long round_to_pow2(unsigned n);

double value_at_freq(std::vector<double> const &spectrum, double freq, double sample_rate);


/*
 * rectangular to polar, and back
 */
double              magnitude(complex const &c);
void                magnitude(std::vector<double> &mag, std::vector<complex> const &c);
std::vector<double> magnitude(std::vector<complex> const &c);

double              phase(complex const & c);
void                phase(std::vector<double> &pha, std::vector<complex> const &c);
std::vector<double> phase(std::vector<complex> const &c);

void                unwrap(std::vector<double> &pha, std::vector<double> const &c);
std::vector<double> unwrap(std::vector<double> const &c);

void				 conjugate(std::vector<complex> &out, std::vector<complex> const &in);
std::vector<complex> conjugate(std::vector<complex> const &in);

void
polar_to_rectangular(
		std::vector<complex> &c,
		std::vector<double> const &mag,
		std::vector<double> const &pha
);

std::vector<complex>
polar_to_rectangular(
		std::vector<double> const &mag,
		std::vector<double> const &pha
);

void
rectangular_to_polar(
		 std::vector<double> &mag,
		 std::vector<double> &pha,
		 std::vector<complex> const &c
);

std::pair< std::vector<double>, std::vector<double> > rectangular_to_polar(std::vector<complex> const &c);


/*
 * direct FFT
 */
void                 fft(std::vector<complex> &result, std::vector<double> const &wave);
std::vector<complex> fft(                              std::vector<double> const &wave);

void                 fft(std::vector<complex> &result, std::vector<float> const &wave);
std::vector<complex> fft(                              std::vector<float> const &wave);


/*
 * inverse FFT
 */
void                ifft(std::vector<double> &result, std::vector<complex> const &freq_data);
std::vector<double> ifft(                             std::vector<complex> const &freq_data);


/*
 * zero pad a wave to a given length, and return its fft
 */
void                 pad_wave_and_perform_fft(std::vector<complex> &result, std::vector<float> const &wave, unsigned numPaddedSamples);
std::vector<complex> pad_wave_and_perform_fft(std::vector<float> const &wave, unsigned numPaddedSamples);


/*
 * deconvolve two signals in {Re,Im} format
 */
void                 deconvolve(std::vector<complex> &transfer, std::vector<complex> const &input, std::vector<complex> const &output);
std::vector<complex> deconvolve(std::vector<complex> const &input, std::vector<complex> const &output);


/*
 * vector scaling (in-place)
 */
#if 0
template<typename T>
void
scale(std::vector<T> &v, T f)
{
	for (size_t i= 0; i< v.size(); i++) {
		v[i] *= f;
	}
}
#endif


/*
 * vector scaling (out-place)
 */
template<typename T>
void
scale(std::vector<T> &out, std::vector<T> const &in, T f)
{
	out.resize(in.size());

	for (size_t i= 0; i< in.size(); i++) {
		out[i] = in[i]*f;
	}
}

template<typename T>
std::vector<T>
scale(std::vector<T> const &in, T f)
{
	std::vector<T> retval;

	scale(retval, in, f);

	return retval;
}


/*
 * deconvolve two signals in polar form
 */
void
deconvolve(
		std::vector<double>       &transfer_mag,
		std::vector<double>       &transfer_pha,
		std::vector<double> const &input_mag,
		std::vector<double> const &input_pha,
		std::vector<double> const &output_mag,
		std::vector<double> const &output_pha
);

std::pair< std::vector<double>, std::vector<double> >
deconvolve(
		std::vector<double> const &input_mag,
		std::vector<double> const &input_pha,
		std::vector<double> const &output_mag,
		std::vector<double> const &output_pha
);


/*
 * convolve two signals in {Re,Im} format
 */
void convolve(std::vector<complex> &transfer, std::vector<complex> const &input, std::vector<complex> const &output);
std::vector<complex> convolve(std::vector<complex> const &input, std::vector<complex> const &output);


/*
 * cross-correlation
 */
void cross_correlation(std::vector<double> &xc, std::vector<float> const &a, std::vector<float> const &b);
std::vector<double> cross_correlation(std::vector<float> const &a, std::vector<float> const &b);


/*
 * spectrum filtering (in-place)
 */
void filter_band_pass (std::vector<complex> &v, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
void filter_band_block(std::vector<complex> &v, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);

void filter_band_pass (std::vector<double> &v, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
void filter_band_block(std::vector<double> &v, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);


/*
 * spectrum filtering (out-place)
 */
void                 filter_band_pass (std::vector<complex> &out, std::vector<complex> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
std::vector<complex> filter_band_pass (                           std::vector<complex> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
void                 filter_band_block(std::vector<complex> &out, std::vector<complex> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
std::vector<complex> filter_band_block(                           std::vector<complex> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);

void                 filter_band_pass (std::vector<double> &out, std::vector<double> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
std::vector<double>  filter_band_pass (                          std::vector<double> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
void                 filter_band_block(std::vector<double> &out, std::vector<double> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);
std::vector<double>  filter_band_block(                          std::vector<double> const &in, unsigned low_freq, unsigned hi_freq, unsigned sample_rate);


/*
 * array saving (either in /tmp or in a given absolute path)
 */
template <typename T>
static
void
save_array(std::string const &filename, T const *data, size_t len, bool force= false)
{
	if (SAVE_ARRAYS || force) {
		char b[32768];
		std::ofstream  f;

		f.open(filename.c_str(), std::ios::out | std::ios::trunc);
		f.rdbuf()->pubsetbuf(b, sizeof(b));

		f << std::setprecision(SAVE_PRECISION);

		for (unsigned i= 0; i< len; i++) {
			f << data[i] << "\n"; //std::endl;
		}
		f.close();
	}
}

template <typename T>
static
void
save_array(std::string const &filename, std::vector<T> const &data, bool force= false)
{
	if (SAVE_ARRAYS || force) {
		char b[32768];
		std::ofstream  f;

		f.open(filename.c_str(), std::ios::out | std::ios::trunc);
		f.rdbuf()->pubsetbuf(b, sizeof(b));

		f << std::setprecision(SAVE_PRECISION);

		for (unsigned i= 0; i< data.size(); i++) {
			f << data[i] << "\n"; //std::endl;
		}
		f.close();
	}
}


/*
 * vector windowing (out-place)
 */
template <typename T>
std::vector<T> &
window(std::vector<T> &out, std::vector<T> const &in, unsigned min, unsigned max, T const &mask_value = T(SIGNAL_FLOOR))
{
	out.resize(in.size());

	if (min< max) {
		std::fill(out.begin(), out.begin()+min, mask_value);
		std::copy(in.begin()+min, in.begin()+max, out.begin()+min);
		std::fill(out.begin()+max, out.end(), mask_value);
	} else {
		std::copy(in.begin(), in.begin()+max, out.begin());
		std::fill(out.begin()+max, out.begin()+min, mask_value);
		std::copy(in.begin()+min, in.end(), out.begin()+min);
	}

	return out;
}

template <typename T>
std::vector<T>
window(std::vector<T> const &in, unsigned min, unsigned max, T const &mask_value = T(SIGNAL_FLOOR))
{
	std::vector<T> retval;

	window(retval, in, min, max, mask_value);

	return retval;
}


/*
 * Harmonic pack (typically used for harmonic analysis)
 */
template <typename T>
void
harmonic_pack(std::vector<T> &out, std::vector<T> const &in, unsigned harmonic_number, T const &pad)
{
	out.resize(in.size());

	std::fill(out.begin(), out.end(), pad);

	for (unsigned i= 0; i< in.size()/harmonic_number; i++) {
		out[i] = in[i*harmonic_number];
	}
}

template <typename T>
std::vector<T>
harmonic_pack(std::vector<T> const &in, unsigned harmonic_number, T const &pad)
{
	std::vector<T> retval;

	harmonic_pack(retval, in, harmonic_number, pad);

	return retval;
}


/*
 * fuck-o-phone
 */
std::vector<double> fuckophone(std::vector<double> const &in, unsigned rec_len, unsigned num_taps = 4);
std::vector<float>  fuckophone(std::vector<float> const &in, unsigned rec_len, unsigned num_taps = 4);


#endif
