#ifndef mpetit__audio_tools__sweep_generators__hh__
#define mpetit__audio_tools__sweep_generators__hh__

#include <stdint.h>
#include <vector>
#include <FTK/FTKMap.h>
#include <AudioTools/AudioUtils.h>



enum
{
	SWEEP__UNDEFINED,
	SWEEP__PINKCHIRP,
	SWEEP__PINKNOISE,
	SWEEP__500TONE,
	SWEEP__STEP
};

/*
 *	Supports Chirp and Step Sine
 */
struct sweep_gen_data_t
{
public:
	double   Scaling()          const  { return m_scaling;		}
	unsigned NumSamples()       const  { return unsigned(m_sample_rate * m_sweep_time + 0.5);					}
	unsigned NumPaddedSamples() const  { return unsigned(m_sample_rate * (m_sweep_time + 2*m_sweep_pad) + 0.5); } /* Not Supported for Step Sine */
	double   SampleRate()       const  { return m_sample_rate;	}
	double	 SweepTime()		const  { return m_sweep_time;	}

	unsigned SweepType()        const  { return m_sweep_type;	}
	double   StartFreq()        const  { return m_start_freq;	}
	double   StopFreq()         const  { return m_stop_freq;	}

	bool     TaperIn()          const  { return m_taper_in;		}
	bool     TaperOut()         const  { return m_taper_out;	}
	unsigned TaperMode()        const  { return m_taper_mode;	}

	/* Step Sine Getters Only */
    unsigned Density()          const  { return m_density;		}
	double   MinCycles()        const  { return m_min_cycles;	}
	double   MinDuration()      const  { return m_min_duration; }

	sweep_gen_data_t &setScaling     (double      scaling)  { m_scaling      = scaling;     return *this; }
	sweep_gen_data_t &setSweepTime   (double   sweep_time)  { m_sweep_time   = sweep_time;  return *this; } /* Not Supported for Step Sine */
	sweep_gen_data_t &setSweepPadding(double    sweep_pad)  { m_sweep_pad    = sweep_pad;   return *this; } /* Not Supported for Step Sine */
	sweep_gen_data_t &setSampleRate  (double  sample_rate)  { m_sample_rate  = sample_rate; return *this; }
 
	sweep_gen_data_t &setSweepType   (unsigned sweep_type)  { m_sweep_type   = sweep_type;  return *this; }
	sweep_gen_data_t &setStartFreq   (double   start_freq)  { m_start_freq   = start_freq;  return *this; }
	sweep_gen_data_t &setStopFreq    (double    stop_freq)  { m_stop_freq    = stop_freq;   return *this; }

	sweep_gen_data_t &setTaperIn     (bool       taper_in)  { m_taper_in     = taper_in;    return *this; } /* Not Supported for Step Sine */
	sweep_gen_data_t &setTaperOut    (bool      taper_out)  { m_taper_out    = taper_out;   return *this; } /* Not Supported for Step Sine */
	sweep_gen_data_t &setTaperMode   (unsigned taper_mode)  { m_taper_mode   = taper_mode;  return *this; } /* Not Supported for Step Sine */

	/* Step Sine Setters Only */
    sweep_gen_data_t &setDensity     (unsigned density)		{ m_density		 = density;	    return *this; }
	sweep_gen_data_t &setMinCycles   (double   min_cycles)	{ m_min_cycles	 = min_cycles;  return *this; }
	sweep_gen_data_t &setMinDuration (double   min_duration){ m_min_duration = min_duration;return *this; }

	double const  *m_eq_points;
	unsigned       m_eq_spacing;

	sweep_gen_data_t(FTKMap const &);

private:
	double   m_scaling;
	double   m_sweep_time;
	double   m_sweep_pad;
	double   m_sample_rate;

	unsigned m_sweep_type;
	double   m_start_freq;
	double   m_stop_freq;

	bool     m_taper_in;
	bool     m_taper_out;
	unsigned m_taper_mode;

	/* StepSine Only Member Variables */
    unsigned m_density;
	double   m_min_cycles;
	double   m_min_duration;  /* seconds */
};

struct step_sweep_t
{
public:
    std::vector<double>   Freqs()			  const	{ return m_freqs;			   }
	std::vector<double>	  SynthesizedSweep()  const	{ return m_sweep;			   }
    std::vector<unsigned> SegmentBoundaries() const	{ return m_segment_boundaries; }
	unsigned			  NumSteps()		  const { return m_steps;			   }
	unsigned			  NumSamples()		  const	{ return m_num_samples;		   }
	double				  SweepTime()		  const { return m_sweep_time;		   }

	step_sweep_t(sweep_gen_data_t const *);
	
private:
    std::vector<double>   m_freqs;
	std::vector<double>	  m_sweep;
    std::vector<unsigned> m_segment_boundaries;
	unsigned			  m_steps;
	unsigned			  m_num_samples;
	double				  m_sweep_time;
};

double               sweep_rate_for				(sweep_gen_data_t const *def);
double               sweep_time_for				(sweep_gen_data_t const *def);
double               sweep_tstart_for			(sweep_gen_data_t const *def);

int                  makeSweepFR(std::vector<double> &outMagnitude, std::vector<double> &outPhase, sweep_gen_data_t const *def, unsigned logicalSize);
std::vector<complex> makeSweepFR(sweep_gen_data_t const *def, unsigned logicalSize);

int makeSweepFromFreqDomain(int16_t *outSweep, sweep_gen_data_t const *def);
int makeSweepFromFreqDomain(int32_t *outSweep, sweep_gen_data_t const *def);
int makeSweepFromFreqDomain(float   *outSweep, sweep_gen_data_t const *def);
int makeSweepFromFreqDomain(double  *outSweep, sweep_gen_data_t const *def);

std::vector<float>  synthesize_sweep(sweep_gen_data_t const *def);
std::vector<float>  synthesize_sweep(FTKMap def);

#endif
