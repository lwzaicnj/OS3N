#ifndef mpetit__clf2__fact_tests__smoothers__hh__
#define mpetit__clf2__fact_tests__smoothers__hh__


#include <vector>
#include <FTK/FTKMap.h>


void                smooth(std::vector<float> &, std::vector<float> const &, double sample_rate, FTKMap options);
std::vector<float>  smooth(                      std::vector<float> const &, double sample_rate, FTKMap options);

void                smooth(std::vector<double> &, std::vector<double> const &, double sample_rate, FTKMap options);
std::vector<double> smooth(                       std::vector<double> const &, double sample_rate, FTKMap options);

#endif