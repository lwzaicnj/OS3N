#ifndef audio_tools__taper_windows__hh__
#define audio_tools__taper_windows__hh__

#include <iostream>
#include <vector>

enum
{
	TAPER__BARLETT,
	TAPER__HANNING,
	TAPER__HAMMING,
    
	/* last resort */
	TAPER__UNIFORM = -1,
};


inline double taper__uniform(int position, int length);
inline double taper__barlett(int position, int length);
inline double taper__hanning(int position, int width);
inline double taper__hamming(int position, int width);

double (*taper_for_mode(unsigned mode))(int, int);

std::vector<double> taper__hanning(std::vector<double> const &wave, double percentage);
std::vector<float> taper__hanning(std::vector<float> const &wave, double percentage);

#endif
