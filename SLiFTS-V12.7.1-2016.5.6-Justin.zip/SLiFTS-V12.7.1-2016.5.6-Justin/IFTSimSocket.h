//
//  IFTSimSocket.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTSocket.h"

@interface IFTSimSocket : IFTSocket {
    NSString* lastCmd;
    double delayTimeInSeconds;
    NSDate* writeDate;
}

@property (readwrite, copy) NSString* lastCmd;
@property (readwrite) double delayTimeInSeconds;

-(id)init:(const char*)ipAddr port:(int)port;
-(Boolean) WaitForConnection:(CFWriteStreamRef) wStream;

-(BOOL)write:(NSString*)cmd error:(NSError**)error;
-(NSString*)read:(NSError**)error;
-(NSString*)readLine:(NSError**)error;
-(NSString*)readUntil:(NSString*)marker error:(NSError**)error;

+(void)setResponseMap:(NSMutableDictionary*)map;
@end
