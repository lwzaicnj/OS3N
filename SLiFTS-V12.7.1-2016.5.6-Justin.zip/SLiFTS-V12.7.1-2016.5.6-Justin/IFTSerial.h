//
//  IFTSerial.h
//  iFacotoryTestFramework
//
//  Created by Wei Wang on 9/24/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <termios.h>
#import "IFTErrorCodes.h"

typedef enum {
    kIFTSerialParityNone=0,
    kIFTSerialParityOdd=1,
    kIFTSerialParityEven=2
} IFTSerialParity;

typedef enum {
    kIFTSerialStopBitsOne = 0,
    kIFTSerialStopBitsTwo = 1
} IFTSerialStopBits;

typedef enum {
    kIFTSerialByte5 = 0,
    kIFTSerialByte6 = 1,
    kIFTSerialByte7 = 2,
    kIFTSerialByte8 = 3
} IFTSerialByteSize;





extern NSString* const IFTSerialErrorDomain;

@interface IFTSerial : NSObject {
    NSString* bsdPath;
    unsigned int timeOutInSeconds;
    unsigned long baudRate;
    IFTSerialParity parity;
    IFTSerialByteSize byteSize;
    IFTSerialStopBits stopBits;
    int fd;
	unsigned int interCharDelayInMicroSeconds;
    struct termios options;
}

@property (readwrite, copy) NSString* bsdPath;
@property (readwrite) unsigned long baudRate;
@property (readwrite) unsigned int interCharDelayInMicroSeconds;
@property (readwrite) unsigned int timeOutInSeconds;
@property (readwrite) IFTSerialParity parity;
@property (readwrite) IFTSerialByteSize byteSize;
@property (readwrite) IFTSerialStopBits stopBits;

-(id)init:(NSString*)_bsdPath;
- (NSError*)handleError:(int)errorNumber withMessage:(NSString*) msg;
- (BOOL)open:(NSError**)error;
- (BOOL)close:(NSError**) error;

-(void)setStopBitsFlag:(IFTSerialStopBits)stopBits;
-(void)setParityFlag:(IFTSerialParity)parity;
-(void)setBytesSizeFlag:(IFTSerialByteSize)byteSize;

- (BOOL)write:(NSString*)cmd error:(NSError**)pError;

//the code does not read more than 5000 characters for now. If you need to read
//more than that you have to break up the read yourself.
- (NSString*)read:(int)maxLength error:(NSError**)error;
- (NSString*)readLine:(int)timeOutInSeconds error:(NSError**)error;
-(BOOL)flushBuffer:(NSError**)error;
@end
