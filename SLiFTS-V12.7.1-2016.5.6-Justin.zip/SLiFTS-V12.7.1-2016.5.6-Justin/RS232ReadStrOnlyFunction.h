//
//  RS232ReadStrOnlyFunction.h
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(RS232ReadStrOnlyFunction)

+(void)RS232ReadStrOnly:(NSDictionary*) DictionaryPtr;
+(void)RS232ReadStrOnlyEvery50ms:(NSDictionary*) DictionaryPtr;
//phantom click no trigger parse function----Added by Annie 2014.10.07
+(void)RS232PhantomNoTrigger:(NSDictionary*) DictionaryPtr;

@end