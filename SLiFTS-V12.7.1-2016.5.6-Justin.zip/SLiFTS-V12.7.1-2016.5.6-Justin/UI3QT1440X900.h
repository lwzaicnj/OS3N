/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI3QT1440X900.h		 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI3QT1440X900.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 21.03.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "UICommon.h"
#import "FixtureIdPanelController.h"

#define MaxUnitFlag    10

@interface UI3QT1440X900 : NSObject  {
	//iboutlet variable
	IBOutlet NSWindow *window;
	IBOutlet NSTextField *textIcon ;
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSBox *boxUnitView1 ;
	IBOutlet NSBox *boxUnitView2 ;
	IBOutlet NSBox *boxUnitView3 ;
	IBOutlet NSTextField *txtStatusBar11 ;
	IBOutlet NSTextField *txtStatusBar12 ;
	IBOutlet NSTextField *txtStatusBar13 ;
	IBOutlet NSTextField *txtStatusBar21 ;
	IBOutlet NSTextField *txtStatusBar22 ;
	IBOutlet NSTextField *txtStatusBar23 ;
	IBOutlet NSTextField *txtStatusBar31 ;
	IBOutlet NSTextField *txtStatusBar32 ;
	IBOutlet NSTextField *txtStatusBar33 ;
	IBOutlet NSTextField *txtTest ;
	
	IBOutlet NSTableView *tableView11 ;
	IBOutlet NSTableView *tableView12 ;
	IBOutlet NSTableView *tableView13 ;
	IBOutlet NSTableView *tableView21 ;
	IBOutlet NSTableView *tableView22 ;
	IBOutlet NSTableView *tableView23 ;
	IBOutlet NSTableView *tableView31 ;
	IBOutlet NSTableView *tableView32 ;
	IBOutlet NSTableView *tableView33 ;
	IBOutlet NSScrollView* textLog ;
	
	IBOutlet NSTextField *textTotalTime1;
	IBOutlet NSTextField *textTotalTime2;
	IBOutlet NSTextField *textTotalTime3;
	IBOutlet NSTextField *textItemTime1;
	IBOutlet NSTextField *textItemTime2;
	IBOutlet NSTextField *textItemTime3;
	IBOutlet NSTextField *textTestResult1;
	IBOutlet NSTextField *textTestResult2;
	IBOutlet NSTextField *textTestResult3;

	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	
	int tableViewCnt;
	NSTableView *tableViewForCnt;
	NSTableView *tableViewArray[4];
	BOOL initTableFlag;
	BOOL mTestStartFlag[MaxUnitFlag];
	BOOL mTestFlag;
	int refreshTimeCnt;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
	NSInteger mUIItems[3];
}

-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)setFixtureID:(id)sender;

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer ;
-(void)timerUnitCheckFireMethod:(NSTimer*)theTimer ;
-(void)initUIScanLabelAndText;
-(void)showInitLog;
-(void)setBoxBgdColor:(id)obj objType:(NSString*)strType;
-(IBAction)CallEditScriptUI:(id)sender ;
@end

