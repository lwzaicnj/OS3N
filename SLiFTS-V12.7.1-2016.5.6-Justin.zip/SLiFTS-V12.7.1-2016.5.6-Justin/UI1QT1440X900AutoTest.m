/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIWithoutScan.h  $|
 | $Author:: Henry                  $Revision::  2					 $|
 | CREATED: 13.05.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIWithoutScan.h                                       $
 * *****************  Version 1  *****************
 * User: Giga           Date: 24.02.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */


#import "UI1QT1440X900AutoTest.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"


//           UI Item Name             x,	 y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGBUTTONMIN = {1041, 27, 41,	23};
static const UI_INFOR LOGBUTTONMAX = {1041, 27, 41,	23};
static const UI_INFOR LOGTEXTMIN   = {1,    -11,	 291,	405};
static const UI_INFOR LOGTEXTMAX   = {1 ,	-11,	 1340,	652};
static const UI_INFOR TABVIEWMIN   = {1035,  40,  315,	440};
static const UI_INFOR TABVIEWMAX   = {11 ,	 40, 1359,	698};

#define UNITINDEX 1
#define TIMERINTERVEL			1  //for check if unit plug in
#define TIMERINTERVEL_REFRESH  0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"
BOOL bReloadTableViewOnceBeforeTest3 = TRUE;//add by judith 20111202

@implementation UI1QT1440X900AutoTest
-(id)init
{
	self = [super init] ;
	mTestStartFlag = YES;
	refreshTimeCnt = 0;
	return self ;
}

-(void)dealloc
{
	[super dealloc] ;
}

- (void)awakeFromNib
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
		[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	}
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
		[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
		[textLabel2 setTextColor:[NSColor blackColor]];
	}
	
	//add for hide simulator button  by Henry 20101005
	NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
	if([stationName isEqualToString:@"ALS Test"])
		[btnSimulator setHidden:YES];
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
	[[textTestResultDetail documentView]setEditable:false] ;
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	
	[self showInitLog];
	NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
																			:self selector
																			:@selector(timerRefreshTableViewMethod:) userInfo
																			:TIMERFORUNITPLUGINCHECK repeats
																			:YES ] retain] ;
	[timerRefreshTableView release] ;
	
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	/*SCRID-146: for resove the ui crash. Judith, 2011-12-02*/
	if(bReloadTableViewOnceBeforeTest3) 
	{
		bReloadTableViewOnceBeforeTest3 = FALSE;
		if(tableViewArray != nil)
			[tableViewArray reloadData];
	}	
	/*SCRID-146: end*/
	
	refreshTimeCnt++ ;
	if (refreshTimeCnt>2)
	{
		NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL target
																   :self selector
																   :@selector(timerUnitCheckFireMethod:) userInfo
																   :TIMERFORUNITPLUGINCHECK repeats
																   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
		
	if([UIWinManage isCheckDUTID:1]);
	else 
	{
		if([UIWinManage getUnit:1])
		{
			if(mTestStartFlag)
			{
				[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :NO ScanData:nil] ;
				mTestStartFlag=NO ;
			}
		}else
		{
			mTestStartFlag = YES;
		}
	}
	return ;
}


-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
    NSString *tmpMagnetHallS = [ScriptParse getValueFromSummary:@"TestStation"];
    //if([tmpMagnetHallS rangeOfString:@"Magnet-Hall"].length > 0)
    if(0)
        return nil;
    
	if(([[textTestResult stringValue] isEqualToString:@"No Unit"])
	   ||([[textTestResult stringValue] isEqualToString:@"on going"]))  
		;
	else if(([[textTestResult stringValue] isEqualToString:@"PASS"])||([[textTestResult stringValue] isEqualToString:@"Fail"]))
	{
		[self showTestResult];
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	else
	{
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	
	[self setTableBgdColor];
	
	if ([[aTableColumn identifier] isEqual:@"testItem"])
    	return [UIWinManage getTestItemUIName:rowIndex] ;
	else
		return [UIWinManage getTestItemUIResult:1 :rowIndex] ;
}

-(void)setTableBgdColor
{
	if([[textTestResult stringValue] isEqualToString:@"Fail"])
	{
		[boxTestState setBoxType:NSBoxCustom];
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
	}
	else if([[textTestResult stringValue] isEqualToString:@"PASS"])
	{
		[boxTestState setBoxType:NSBoxCustom];
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
	}
	else 
	{
		[boxTestState setBoxType:NSBoxCustom]; 
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
 	}
	//[boxTestState display];
}


-(IBAction)btnCancel_Click:(id)sender
{
	//helen20110530
	[UICommon setStopFailFlag:YES];
};

-(void)showInitLog
{
	NSString *temStr =[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
}

-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}

-(IBAction)btnTabViewMaxMin_Click:(id)sender
{
	
	NSString *strTitle =[btnLogMaxMin title];
	
	if([strTitle isEqualToString:@"Max"])
	{
		[tvTableview setEnabled:FALSE];
		[tvTableview setHidden:TRUE];
		[testItemScroView setHidden:TRUE];
		[btnLogMaxMin setTitle:@"Min"];
		[btnExit setHidden:TRUE];
		[tvTabview setFrame:NSMakeRect(TABVIEWMAX.x, TABVIEWMAX.y, TABVIEWMAX.width, TABVIEWMAX.height)];
		[btnSimulator setHidden:TRUE];
		[boxTestState setHidden:TRUE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
	}
	else if([strTitle isEqualToString:@"Min"])
	{
		[tvTableview setEnabled:TRUE];
		[tvTableview setHidden:FALSE];
		[testItemScroView setHidden:FALSE];
		[btnLogMaxMin setTitle:@"Max"];
		[tvTabview setFrame:NSMakeRect(TABVIEWMIN.x, TABVIEWMIN.y, TABVIEWMIN.width, TABVIEWMIN.height)];
		[btnSimulator setHidden:FALSE];
		[boxTestState setHidden:FALSE];
		[btnExit setHidden:FALSE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
	}
}

- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem
{
	NSLog(@"Tab :%@  Clicked",[tabViewItem identifier]);
	if([[tabViewItem identifier] isEqualToString:@"result"])
	{
		[self tabViewItemUpdate:(NSInteger)1];
		[self showTestResult];
	}
	else if([[tabViewItem identifier] isEqualToString:@"all log"])
	{
		[self tabViewItemUpdate:(NSInteger)2];
		[self showLog:1 isDisable:TRUE];
	}
	else if([[tabViewItem identifier] isEqualToString:@"item log"])
	{
		[self tabViewItemUpdate:(NSInteger)3];
		[self showItemLog];
	}
}


-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag
{
	
	[[[[textAllLog documentView] textStorage] mutableString] setString:@""] ;
	if(iShowFlag == FALSE)
		return TRUE;
	
	NSString *temStr =[TestItemManage getUnitLogInfo:logIndex] ;
	if(temStr ==nil)
		temStr = @"No log found";
	[[[[textAllLog documentView] textStorage] mutableString] appendString:temStr] ;
	
	return TRUE;
}

-(void)showItemLog
{
	
	NSString *temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
	[[[[textItemLog documentView] textStorage] mutableString] setString:@""] ;
	
	if(temStr ==nil)
		temStr = @"Can't find the log file !";
	else
		temStr = [self getItemClickedString];
	
	[[[[textItemLog documentView] textStorage] mutableString] appendString:temStr] ;
}

-(void)showTestResult
{
	[[[[textTestResultDetail documentView] textStorage] mutableString] setString:@""] ;
	NSString *temStr =[TestItemManage getResultInfo:UNITINDEX] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
	//[textTestResultDetail display];
}

-(NSString *)getItemClickedString
{
	NSInteger rowIndex=-1;
	NSString *testItemStr = nil;
	NSString *nextTestItemStr = nil;
	NSString *lastTestItemStr = nil;
	NSString *temStr = nil;
	NSRange	range,rangePostStr,rangeLastStr;
	
	rowIndex=[tvTableview selectedRow];
	if((rowIndex<0)||(rowIndex>[UIWinManage getTestItemTotal ]))
	{
		temStr = @"";
		return temStr;
	}
	else if(rowIndex == ([UIWinManage getTestItemTotal]-1))
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error2: Cannot find log information";
			return temStr;
		}
		NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
		if((rowIndex+1)<=9)
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
		else
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
		
		range = [temStr rangeOfString:testItemStr];
		if (range.length <= 0)
			temStr = @"Error3: Cannot find log information";
		else
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
	}
	else
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		nextTestItemStr =[UIWinManage getTestItemUIName:(rowIndex+1)];
		lastTestItemStr =[UIWinManage getTestItemUIName:([UIWinManage getTestItemTotal]-1)];
		
		NSRange temStrRang =[testItemStr rangeOfString:@"[" ];
		if (temStrRang.length > 0)
			testItemStr = [testItemStr substringToIndex:(NSInteger)temStrRang.location];
		NSRange temStrRang2 =[nextTestItemStr rangeOfString:@"[" ];
		if (temStrRang2.length > 0)
			nextTestItemStr = [nextTestItemStr substringToIndex:(NSInteger)temStrRang2.location];
		NSRange temStrRang3 =[lastTestItemStr rangeOfString:@"[" ];
		if (temStrRang3.length > 0)
			lastTestItemStr = [lastTestItemStr substringToIndex:(NSInteger)temStrRang3.location];
		
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error4: Cannot find log information";
			return temStr;
		}
		else if((testItemStr!=nil)&&(nextTestItemStr==nil))
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			range = [temStr rangeOfString:testItemStr];
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
			return temStr;
		}
		else
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			NSString *indexNextHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+2] autorelease];
			NSString *indexLastHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",[UIWinManage getTestItemTotal]] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			if((rowIndex+2)<=9)
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexNextHeadStr];
			else
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexNextHeadStr];
			
			range = [temStr rangeOfString:testItemStr];
			rangePostStr = [temStr rangeOfString:nextTestItemStr];
			if ((range.length <= 0)||(rangePostStr.length<=0))
			{
				
				if(lastTestItemStr!=nil)
				{
					if([UIWinManage getTestItemTotal]<=9)
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexLastHeadStr];
					else
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexLastHeadStr];
					rangeLastStr = [temStr rangeOfString:lastTestItemStr];
					if ((range.length <= 0)||(rangeLastStr.length<=0))
						temStr = @"Error5: Cannot find log information";
					else
						temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangeLastStr.location-range.location))];
				}
				else 
				{
					temStr = @"Error5: Cannot find log information";
				}
			}
			else
				temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangePostStr.location-range.location))];
		}
	}
	return temStr;
}

-(void)tabViewItemUpdate:(NSInteger)index 
{
	NSString *strTitle =[btnLogMaxMin title];
	
	switch (index) 
	{
		case 1:
			if([strTitle isEqualToString:@"Min"])
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 2:
			if([strTitle isEqualToString:@"Min"])
				[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 3:
			if([strTitle isEqualToString:@"Min"])
				[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		default:
			break;
	}
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}
@end
