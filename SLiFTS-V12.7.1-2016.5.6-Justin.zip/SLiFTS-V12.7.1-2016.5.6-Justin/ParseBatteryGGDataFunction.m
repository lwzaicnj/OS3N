//
//  ParseBatteryGGDataFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseBatteryGGDataFunction.h"


@implementation TestItemParse(ParseBatteryGGDataFunction)

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  2010.04.01.17:30    
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Special Parser Method
 
 PURPOSE :Check Battery  related attributes.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.04.01   Time: 17:30
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

+(void)ParseBatteryGGDataV2:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mBufferValue = nil;
	
	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	//mBufferValue = @" device -k GasGauge -p type: \"GasGauge\" vendor: \"TI\" model: \"BQ27541\" fw-version: \"0x135\" hw-version: \"0xB5\" temperature: \"28C\" voltage: \"3702mV\" remaining-capacity: \"1437mAh\" full-capacity: \"11125mAh\" current: \"-725mA\" time-to-empty: \"119min\" time-to-full: \"N/A\" average-power: \"-268mW\" charge-percentage: \"13%\" cycle-count: \"1\" chem-id: \"0x1136\" chem-capacity: \"12063mAh\" chem-cap-updates-en: \"Yes\" sealed: \"Yes\" :-) ";
	
	if (mBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
	    return  ;
	}
	
	//Add by Lucky for grab SOCHOT ERROR
	NSRange rangeSocHot = [mBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
	//Lucky add end
	
	
	BOOL res = TRUE;
	
	NSString * fw_version = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															   :@"fw-version: \"" Postfix
															   :@"\""] ;
    if(fw_version == nil)
        fw_version=@"N/A";
	//char* stopEnd=nil;
	int intfw_version = (int)strtol([fw_version UTF8String], NULL, 16);
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"fw-version":nil:nil:nil:[NSString stringWithFormat:@"%d",intfw_version]:nil:IP_PASS:@"PASS"];
	
	
	NSString *hw_version = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															  :@"hw-version: \"" Postfix
															  :@"\""] ;
    //if(hw_version == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery hw_version"] ;
	//    return  ;
    //}
    if(hw_version == nil)
        hw_version=@"N/A";
	int inthw_version = (int)strtol([hw_version UTF8String], NULL, 16);
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"hw-version":nil:nil:nil:[NSString stringWithFormat:@"%d",inthw_version]:nil:IP_PASS:@"PASS"];
	
	
	NSString * temperature = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																:@"temperature: \"" Postfix
																:@"C"] ;
    //if(temperature == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery temperature"] ;
	//    return  ;
    //}
    if(temperature == nil)
        temperature=@"N/A";
	//int inttemperature = (int)strtol([temperature UTF8String], NULL, 10);
    int inttemperature = [temperature intValue];
	if(-65535 < inttemperature && inttemperature< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"temperature":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",inttemperature]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"temperature":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",inttemperature]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	NSString * voltage = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															:@"voltage: \"" Postfix
															:@"mV"] ;
    //if(voltage == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery voltage"] ;
	//    return  ;
    //}
    if(voltage == nil)
        voltage=@"N/A";
	//int intvoltage = (int)strtol([voltage UTF8String], NULL, 10);
    int intvoltage = [voltage intValue];
	if(-65535 < intvoltage && intvoltage < 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"voltage":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intvoltage]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"voltage":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intvoltage]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * remaining_capacity = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																	   :@"remaining-capacity: \"" Postfix
																	   :@"mAh"] ;
    //if(remaining_capacity == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery remaining_capacity"] ;
	//    return  ;
    //}
    if(remaining_capacity == nil)
        remaining_capacity=@"N/A";
	//int intremaining_capacity = (int)strtol([remaining_capacity UTF8String], NULL, 10);
    int intremaining_capacity = [remaining_capacity intValue];
	if(-65535 < intremaining_capacity && intremaining_capacity< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"remaining-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intremaining_capacity]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"remaining-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intremaining_capacity]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	
	NSString * full_capacity = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																  :@"full-capacity: \"" Postfix
																  :@"mAh"] ;
    //if(full_capacity == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery full_capacity"] ;
	//    return  ;
    //}
    if(full_capacity == nil)
        full_capacity=@"N/A";
	//int intfull_capacity = (int)strtol([full_capacity UTF8String], NULL, 10);
    int intfull_capacity = [full_capacity intValue];
	if(-65535 < intfull_capacity && intfull_capacity< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"full-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intfull_capacity]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"full-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intfull_capacity]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * current = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															:@"current: \"" Postfix
															:@"mA"] ;
    //if(current == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery current"] ;
	//    return  ;
    //}
    if(current == nil)
        current=@"N/A";
	//int intcurrent = (int)strtol([current UTF8String], NULL, 10);
    int intcurrent = [current intValue];
	if(-65535 < intcurrent && intcurrent< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"current":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intcurrent]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"current":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intcurrent]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * time_to_empty = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																  :@"time-to-empty: \"" Postfix
																  :@"min"] ;
    //if(time_to_empty == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery time_to_empty"] ;
	//    return  ;
    //}
    if(time_to_empty == nil)
        time_to_empty=@"N/A";
	//int inttime_to_empty = (int)strtol([time_to_empty UTF8String], NULL, 10);
    int inttime_to_empty = [time_to_empty intValue];
	if(-65535 < inttime_to_empty && inttime_to_empty< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"time-to-empty":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",inttime_to_empty]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"time-to-empty":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",inttime_to_empty]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * average_power = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																  :@"average-power: \"" Postfix
																  :@"mW"] ;
    //if(average_power == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery average_power"] ;
	//    return  ;
    //}
    if(average_power == nil)
        average_power=@"N/A";
	//int intaverage_power = (int)strtol([average_power UTF8String], NULL, 10);
    int intaverage_power = [average_power intValue];
	if(-65535 < intaverage_power && intaverage_power < 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"average-power":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intaverage_power]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"average-power":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intaverage_power]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * chem_id = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															:@"chem-id: \"" Postfix
															:@"\""] ;
    //if(chem_id == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery chem_id"] ;
	//    return  ;
    //}
    if(chem_id == nil)
        chem_id=@"N/A";
	int intchem_id = (int)strtol([chem_id UTF8String], NULL, 16);
	if(-65535 < intchem_id && intchem_id< 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"chem-id":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intchem_id]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"chem-id":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intchem_id]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	NSString * chem_capacity = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																  :@"chem-capacity: \"" Postfix
																  :@"mAh"] ;
    //if(chem_capacity == nil)
    //{
    //    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change! battery chem_capacity"] ;
	//    return  ;
    //}
	//int intchem_capacity = (int)strtol([chem_capacity UTF8String], NULL, 10);
    if(chem_capacity == nil)
        chem_capacity=@"N/A";
    int intchem_capacity = [chem_capacity intValue];
	if(-65535 < intchem_capacity && intchem_capacity < 65535)
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"chem-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intchem_capacity]:nil:IP_PASS:@"PASS"];
	else
	{
		res = FALSE;
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"chem-capacity":nil:[NSString stringWithFormat:@"%d",-65535]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",intchem_capacity]:nil:RESULT_FOR_FAIL:@"FAIL"];
	}
	
	
	if (res)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
	}
	
}


+(void)ParseBatteryGGData:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mBufferValue = nil;
	
	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	//mBufferValue = @"battoolReg0x02: 0x0000, 00000, AtRate0x04: 0x1B1A, 06938, AtRateTimeToEmpty0x06: 0x0C1A, 03098, Temperature0x08: 0x105F, 04191, Voltage0x0A: 0x0281, 00641, Flags0x0C: 0x1B62, 07010, NominalAvailableCapacity0x0E: 0x1B63, 07011, FullAvailableCapacity0x10: 0x1A30, 06704, RemainingCapacity0x12: 0x1A31, 06705, FullChargeCapacity0x14: 0x0005, 00005, AverageCurrent0x16: 0x1DA5, 07589, TimeToEmpty0x18: 0xFFFF, 65535, TimeToFull0x1A: 0xFFFD, 65533, StandbyCurrent0x1C: 0x0002, 00002, StandbyTimeToEmpty0x1E: 0xFCA0, 64672, MaxLoadCurrent0x20: 0x0C17, 03095, MaxLoadTimeToEmpty0x22: 0x1BD8, 07128, AvailableEnergy0x24: 0x0015, 00021, AveragePower0x26: 0x0000, 00000, TimeToEmptyAtConstantPower0x2A: 0x0000, 00000, CycleCount0x2C: 0x0064, 00100, StateOfCharge0x3A: 0x8931, 35121, PackConfiguration0x3C: 0x1964, 06500, DesignCapacity0x00: 0x6A0B, 27147, Status0x01: 0x0541, 01345, DeviceType0x02: 0x0125, 00293, FWVersion0x03: 0x00B5, 00181, HWVersion0x08: 0x0142, 00322, ChemID:-)";
	if (mBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
	    return  ;
	}
	
	mBufferValue = [mBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mBufferValue = [mBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	mBufferValue = [mBufferValue stringByReplacingOccurrencesOfString:@" "  withString:@""];
	
	NSRange range;
	range		= [mBufferValue rangeOfString:@":"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Receive data from diags Error!"] ;
	    return  ;
	}
	
	range.location = range.location+1;
	mBufferValue   = [mBufferValue substringFromIndex:(NSUInteger)range.location];
	
	NSAutoreleasePool * pool		= [ [NSAutoreleasePool alloc] init];
	NSMutableArray *mutableArray	= [ [ [NSMutableArray alloc] init] autorelease];
	
	while(YES)
	{
		range = [mBufferValue rangeOfString:@":"];
		if (range.length <= 0)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Receive data from diags Error!"] ;
			return  ;
		}
		range.length	= range.location - 4;
		int index		= range.location;
		range.location	= 0;
		[mutableArray addObject:[mBufferValue substringWithRange:range] ];
		mBufferValue	= [mBufferValue substringFromIndex:(NSUInteger)index + 1];
		
		if ([mBufferValue length] < 4 )
			break;
	}
	
	int IntData[28]; 
	for (int i = 0;i<28;i++)
	{
		range		= [[mutableArray objectAtIndex:(NSUInteger)i] rangeOfString:@","];
		if (range.length <= 0)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Receive data from diags Error!"] ;
			return  ;
		}
		
		range.length	= 5;
		range.location	= range.location + 1;
		
		IntData[i]		= [ [ [mutableArray objectAtIndex:(NSUInteger)i] substringWithRange:range] intValue];
		
	
	}
	
	[pool release];
	
	BOOL result	= YES;
	BOOL flag	= YES;
	for (int i=0;i<28;i++)
	{
		if (IntData[i]>65535||IntData[i]<0)
		{
			flag	= NO;
			result	= NO;
		}
		switch (i)
		{
			case 0:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AtRate_0x02":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
					
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AtRate_0x02":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 1:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AtRateTimeToEmpty_0x04":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
					
				}
				else
				{
					
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AtRateTimeToEmpty_0x04":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 2:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Temperature_0x06":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Temperature_0x06":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 3:
				if (flag)
				{	
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Voltage_0x08":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Voltage_0x08":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 4:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Flags_0x0A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Flags_0x0A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 5:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"NominalAvailableCapacity_0x0C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"NominalAvailableCapacity_0x0C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 6:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FullAvalableCapacity_0x0E":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}

				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FullAvalableCapacity_0x0E":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 7:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RemainingCapacity_0x10":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RemainingCapacity_0x10":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 8:
				if (flag)	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FullChargeCapacity_0x12":nil:[NSString stringWithFormat:@"%d",10000]:[NSString stringWithFormat:@"%d",13000]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FullChargeCapacity_0x12":nil:[NSString stringWithFormat:@"%d",10000]:[NSString stringWithFormat:@"%d",13000]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}	/*SCRID-104: end*/
				break;
			case 9:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AverageCurrent_0x14":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AverageCurrent_0x14":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 10:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToEmpty_0x16":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToEmpty_0x16":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 11:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToFull_0x18":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToFull_0x18":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
					
				}
				break;
			case 12:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StandbyCurrent_0x1A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StandbyCurrent_0x1A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
				
			case 13:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StandbyTimeToEmpty_0x1C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StandbyTimeToEmpty_0x1C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 14:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"MaxLoadCurrent_0x1E":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"MaxLoadCurrent_0x1E":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 15:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"MaxLoadTimeToEmpty_0x20":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"MaxLoadTimeToEmpty_0x20":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 16:
				if (flag)	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AvailableEnergy_0x22":nil:[NSString stringWithFormat:@"%d",11000]:[NSString stringWithFormat:@"%d",15000]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AvailableEnergy_0x22":nil:[NSString stringWithFormat:@"%d",11000]:[NSString stringWithFormat:@"%d",15000]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}	/*SCRID-104: end*/
				break;
			case 17:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AveragePower_0x24":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"AveragePower_0x24":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
		
				break;
			case 18:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToEmptyAtConstantPower_0x26":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"TimeToEmptyAtConstantPower_0x26":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 19:
				if (flag)	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CycleCount_0x2A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",5]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CycleCount_0x2A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",5]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}	/*SCRID-104: end*/
				break;
			case 20:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StateOfCharge_0x2C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"StateOfCharge_0x2C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 21:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"PackConfiguration_0x3A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"PackConfiguration_0x3A":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 22:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"DesignCapacity_0x3C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"DesignCapacity_0x3C":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 23:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Status_0x00":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Status_0x00":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 24:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"DeviceType_0x01":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"DeviceType_0x01":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 25:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FWVersion_0x02":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"FWVersion_0x02":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 26:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"HWVersion_0x03":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"HWVersion_0x03":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
			case 27:
				if (flag)
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"ChemID_0x08":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:IP_PASS:@"PASS"];
				}
				else
				{
					[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"ChemID_0x08":nil:[NSString stringWithFormat:@"%d",0]:[NSString stringWithFormat:@"%d",65535]:[NSString stringWithFormat:@"%d",IntData[i]]:nil:RESULT_FOR_FAIL:@"FAIL"];
					flag = YES;
				}
				break;
				
		}
		
	}
	
	if (result)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
	}
	return;
	
}

//Henry Add 20120218
+(void)ParsePMUStateFault:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	NSString *mIsBefore				= nil	 ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"IsBefore"])
		{
			mIsBefore = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mBufferValue = nil;
	
	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	//mBufferValue = @" device -k GasGauge -p type: \"GasGauge\" vendor: \"TI\" model: \"BQ27541\" fw-version: \"0x135\" hw-version: \"0xB5\" temperature: \"28C\" voltage: \"3702mV\" remaining-capacity: \"1437mAh\" full-capacity: \"11125mAh\" current: \"-725mA\" time-to-empty: \"119min\" time-to-full: \"N/A\" average-power: \"-268mW\" charge-percentage: \"13%\" cycle-count: \"1\" chem-id: \"0x1136\" chem-capacity: \"12063mAh\" chem-cap-updates-en: \"Yes\" sealed: \"Yes\" :-) ";
	//mBufferValue = @"PMU Status test\nNTC_SHDN: 0x0\nWDOG: 0x0\nRESET_IN: 0x1\nRST: 0x0\nPOR: 0x0\nBOOST_OC_OV: 0x0\nOVER_TEMP: 0x0\nVDD_UNDER: 0x0\nLDO6_BACKPOW: 0x0\n:-)";
	
	if (mBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"no receive data!"] ;
	    return  ;
	}
	else
	{
		NSRange rangeTmp = [mBufferValue rangeOfString:@"NTC_SHDN:"];
		if(rangeTmp.length <= 0)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"The diag version is wrong!!!"] ;
			return  ;
		}
	}
	
	BOOL res = TRUE;
	
	NSString * ntc_shdn = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															 :@"NTC_SHDN: " Postfix
															 :@"WDOG:"] ;
	char* stopEnd=nil;
	int intNTC_SHDN = (int)strtol([ntc_shdn UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"NTC_SHDN_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intNTC_SHDN]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"NTC_SHDN_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intNTC_SHDN]:nil:IP_PASS:@"PASS"];
	
	
	NSString *wdog = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
														:@"WDOG: " Postfix
														:@"RESET_IN:"] ;
	int intWDOG = (int)strtol([wdog UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"WDOG_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intWDOG]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"WDOG_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intWDOG]:nil:IP_PASS:@"PASS"];
	
	
	NSString *reset_in = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															:@"RESET_IN: " Postfix
															:@"RST:"] ;
	int intRESET_IN = (int)strtol([reset_in UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RESET_IN_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intRESET_IN]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RESET_IN_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intRESET_IN]:nil:IP_PASS:@"PASS"];
	
	
	NSString *rst = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
													   :@"RST: " Postfix
													   :@"POR:"] ;
	int intRST = (int)strtol([rst UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RST_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intRST]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"RST_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intRST]:nil:IP_PASS:@"PASS"];
	
	
	NSString *por = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
													   :@"POR: " Postfix
													   :@"BOOST_OC_OV:"] ;
	int intPOR = (int)strtol([por UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"POR_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intPOR]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"POR_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intPOR]:nil:IP_PASS:@"PASS"];
	
	
	NSString *boost_oc_ov = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															   :@"BOOST_OC_OV: " Postfix
															   :@"OVER_TEMP:"] ;
	int intBOOST_OC_OV = (int)strtol([boost_oc_ov UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"BOOST_OC_OV_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intBOOST_OC_OV]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"BOOST_OC_OV_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intBOOST_OC_OV]:nil:IP_PASS:@"PASS"];
	
	
	NSString *over_temp = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															 :@"OVER_TEMP: " Postfix
															 :@"VDD_UNDER:"] ;
	int intOVER_TEMP = (int)strtol([over_temp UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"OVER_TEMP_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intOVER_TEMP]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"OVER_TEMP_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intOVER_TEMP]:nil:IP_PASS:@"PASS"];
	
	
	NSString *vdd_under = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
															 :@"VDD_UNDER: " Postfix
															 :@"LDO6_BACKPOW"] ;
	int intVDD_UNDER = (int)strtol([vdd_under UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"VDD_UNDER_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intVDD_UNDER]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"VDD_UNDER_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intVDD_UNDER]:nil:IP_PASS:@"PASS"];
	
	
	NSString *ld06_backpow = [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																:@"LDO6_BACKPOW: " Postfix
																:@":-)"] ;
	int intLDO6_BACKPOW = (int)strtol([ld06_backpow UTF8String], &stopEnd, 16);
	if([mIsBefore boolValue])
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"LDO6_BACKPOW_BeforeTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intLDO6_BACKPOW]:nil:IP_PASS:@"PASS"];
	else
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"LDO6_BACKPOW_AfterTest":nil:nil:nil:[NSString stringWithFormat:@"%d",intLDO6_BACKPOW]:nil:IP_PASS:@"PASS"];
	
	
	if (res)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
	}
	
}
//End 20120218
@end
