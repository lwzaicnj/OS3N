/*
 
 SCRID:11
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: CheckNandSizeFunction.h
 | $Author::caijunbo                    $Revision:: 1               
 | CREATED: 2010.11.08                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :Check  Nand Size between syscfg and that from hardware. 
 */

#import "CheckNandSizeWithSyscfgFunction.h"


@implementation TestItemParse(CheckNandSizeWithSyscfgFunction)

+(void)CheckNandSizeWithSyscfg:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName1=nil;
	NSString *mReferenceBufferName2=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName1==nil||mReferenceBufferName2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];
	if (mReferenceBufferValue1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
	if (mReferenceBufferValue1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	long int iNandSizeFromSFC=0;
	long int iNandSizeFromUnit=0;
/*
	NSString *HWCofig = @"";
	HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
	if(HWCofig == nil || [HWCofig length] < 4)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWCofig is nil or The format of HWCofig from SFC invalid"] ; 
		return;
	}
 */
	//HWCofig =@"ASU=WIFI&BT/NAND,SIZE=64G/RAM,SIZE=256M";
	mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"	" withString:@""];
	NSString *speStr = @"NAND,SIZE=";
	
	NSRange rangeTmp=[mReferenceBufferValue2 rangeOfString:speStr];
	if(rangeTmp.length<=0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The string format from syscfg invalid"] ; 
		return;
	}

	NSString *postSubStr = @"";
	postSubStr = [mReferenceBufferValue2 substringFromIndex:rangeTmp.location];
	postSubStr = [postSubStr stringByReplacingOccurrencesOfString:speStr withString:@""];
	NSRange rangeTmpG = [postSubStr rangeOfString:@"G"];
	if(rangeTmpG.length<=0)             
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The string format from syscfg invalid"] ; 
		return;
	}

	iNandSizeFromSFC = [[postSubStr substringToIndex:rangeTmpG.location] integerValue];

	NSRange range0 = [mReferenceBufferValue1 rangeOfString:@"0x"];
	NSRange range1 = [mReferenceBufferValue1 rangeOfString:@"0X"];
	if(range0.length>0 || range1.length>0)
	{
		char* stopEnd = "";
		iNandSizeFromUnit = (int)strtol([mReferenceBufferValue1 UTF8String], &stopEnd, 16);
		iNandSizeFromUnit  = iNandSizeFromUnit*1024;
        iNandSizeFromUnit = iNandSizeFromUnit/1000000000;
		
		//SCRID:95 Modify for Check NandSize by Helen 20110408.
        
		if (iNandSizeFromSFC == 16) {
            if (iNandSizeFromUnit==iNandSizeFromSFC){
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ; 
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ; 
            }
            
        }
        else if(iNandSizeFromSFC == 32)
        {  
            if (iNandSizeFromUnit==iNandSizeFromSFC){
            
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ; 
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ; 
            }
        }
        else if(iNandSizeFromSFC == 64)
        {
           if (iNandSizeFromUnit==iNandSizeFromSFC){
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ;
            }
            
        }
        else if(iNandSizeFromSFC == 128)
        {
           if (iNandSizeFromUnit==iNandSizeFromSFC){
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ;
            }
            
        }
        else if(iNandSizeFromSFC == 256)
        {
            if (iNandSizeFromUnit==iNandSizeFromSFC){
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ;
            }
            
        }
        else if(iNandSizeFromSFC == 512)
        {
            if (iNandSizeFromUnit==iNandSizeFromSFC){
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue1] ;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ;
            }
            
        }
        else
        {
  
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is out of 512"] ;
            
            
        }//Changed by Bruce 2015.8.22
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diags received Data is not a Hex value"] ; 
	}
	
	return;
	
}

@end

