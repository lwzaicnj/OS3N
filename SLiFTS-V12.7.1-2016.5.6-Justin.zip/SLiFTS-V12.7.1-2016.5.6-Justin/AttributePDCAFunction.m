/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: AttributePDCAFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.04.09                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :AttributePDCA
 
 PURPOSE :Prepare Attribute which upload to PDCA.
 
 $History:: AttributePDCAFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.04.09   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "AttributePDCAFunction.h"


@implementation TestItemParse(AttributePDCAFunction)


+(void)AttributePDCA:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mDevice=nil;
	NSString *mBufferName=nil;

	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
	}


	NSString *barCode = [TestItemManage getSFCValue:dictKeyDefined :@"strBarcodeSn"];
	NSString *HWYsn =[TestItemManage getSFCValue:dictKeyDefined :@"strHwySn"];
	NSString *X15sn =[TestItemManage getSFCValue:dictKeyDefined :@"strX15Sn"];
	NSString *X17sn =[TestItemManage getSFCValue:dictKeyDefined :@"strX17Sn"];
	NSString *bufferV =@"";
	
	
	if(mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferName is Null"] ;
		return ;
	}

	
	if([mBufferName isEqualToString:@"HWYSN"])
	{
		if([HWYsn length]<=0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is Null"] ;
			return ;
		}
		bufferV = HWYsn;
	}
	if([mBufferName isEqualToString:@"X15SN"])
	{
		if([X15sn length]<=0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is Null"] ;
			return ;
		}
		bufferV = X15sn;
	}
	if([mBufferName isEqualToString:@"X17SN"])
	{
		if([X17sn length]<=0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is Null"] ;
			return ;
		}
		bufferV = X17sn;
	}
	if(barCode!=nil || [barCode length]>0)
	{
		// ======  Barcode  ========
		//
		// K48M_EVT2_MAIN3_0003
		// K94-PROTO1_SOP-01_0001
		//
		// ==========================
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
//		NSMutableArray * mutArrayTemp = [barCode componentsSeparatedByString:@"_"];
		NSArray * mutArrayTemp = [barCode componentsSeparatedByString:@"_"];
		//end
		if([mutArrayTemp count] > 2)
		{
			if([mBufferName isEqualToString:@"BUILD_EVENT"])
			{
				bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:0]];
				// serin 20100718 delete
					//bufferV = [bufferV stringByAppendingString:@"_"];
					//bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
				// end
			}
			if([mBufferName isEqualToString:@"BUILD_MATRIX_CONFIG"])
			{
				// serin 20100718
				bufferV = [mutArrayTemp objectAtIndex:1];
				//bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
				//bufferV = [bufferV stringByAppendingString:[matrixConfig objectAtIndex:1]];
				// end

                //20150730_add_peter
                
                 NSRange range= [bufferV rangeOfString :@"-"];
                 bufferV=[bufferV substringFromIndex : range.location+1];
                 
                //bufferV=[bufferV substringfromindex:3];
                
                //end
                
				if([bufferV length]<=0)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is Null"] ;
					return ;
				}
			}
			if([mBufferName isEqualToString:@"S_BUILD"])
			{
				bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:0]];
				bufferV = [bufferV stringByAppendingString:@"_"];
				bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
				
				// serin 20100718 delete
					//bufferV = [bufferV stringByAppendingString:@"_"];
					//bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
				// end
			}
			if([mBufferName isEqualToString:@"UNIT#"])
			{
				// serin 20100718
				//bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:3]];
				bufferV = [bufferV stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
				
				if([bufferV length]<=0)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is Null"] ;
					return ;
				}
			}			
		}
	}
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :bufferV];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:bufferV] ;
	return ;

}

@end
