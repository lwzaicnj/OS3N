//
//  UI_LockScript.h
//  iFTS
//
//  Created by Fox on 5/23/13.
//
//
//#import <Cocoa/Cocoa.h>
//#import "scriptParse.h"
//#import "testItemManage.h"
//#import "testItemParse.h"
//#import "UIWinManage.h"
//
//
//
////added by caijunbo on 2010-09-10 for Display Port Test
//
//#include <stdio.h>
//#import "iFactoryTest/IFTPlugIn.h"
//#import "testExecution.h"
//#import "pubFun.h"
//#import <Cocoa/Cocoa.h>
//#import <Foundation/Foundation.h>
//
BOOL isAdmin;
@interface UI_LockScript : NSObject
{
    
    IBOutlet NSWindow *lockScript_win;
    IBOutlet NSTextField *inputHitInfoLab;
    IBOutlet NSComboBox *acconut;
    //IBOutlet NSTextField *accountTxt;
    //IBOutlet NSTextField *passwordTxt;    
    IBOutlet NSSecureTextField *passwordTxt;
    
    NSButton *unlock_click;
}

- (IBAction)unlock_click:(id)sender;
- (bool)unlockSucess;
- (NSInteger)runModal;

@end
