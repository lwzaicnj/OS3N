//
//  ParseGrapeCalFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseGrapeCalFunction.h"


@implementation TestItemParse(ParseGrapeCalFunction)

#define COLUMNNUM 30
#define ROWNUM 40

+(void)ParseGrapeCal:(NSDictionary*) DictionaryPtr
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mUpperlimit=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mPDCAWrite =@"no"  ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Upperlimit"])
		{
			mUpperlimit = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mUpperlimit==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	//need to trim heading and trailing white space.???????
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@" "] ;
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@" "] ;
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@" "] ;
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"  " withString:@" "] ;
	
	BOOL flag = YES;
	NSArray * matrixArray=[mReferenceBufferValue componentsSeparatedByString:@" "];
	NSMutableArray * tempArray=[NSMutableArray arrayWithCapacity:40];
	NSMutableArray * subtractArray=[NSMutableArray arrayWithCapacity:40];
	NSMutableArray * sortArray=[NSMutableArray arrayWithCapacity:40];
	
	int iTemp;
	int iSubtract;
	int iSort;
	float iAverage=0;
	
	for (int i=0;i<COLUMNNUM;i++)
	{
		for (int j=0;j<ROWNUM;j++)
		{
			iTemp=strtol([[matrixArray objectAtIndex:(51*j+i)] UTF8String],NULL,16);
			NSNumber *number=[NSNumber numberWithInt:iTemp];
			[tempArray addObject:number];
			
		}
		
		for (int k=0;k<ROWNUM-1;k++)
		{
			iSubtract= [ [tempArray objectAtIndex:(k+1)] intValue]-[ [tempArray objectAtIndex:k] intValue];
			[subtractArray addObject:[NSNumber numberWithInt:iSubtract]];
		}
		
		
		
		subtractArray=[ToolFun sortArrayWithIntObj:subtractArray];
		
		
		int isize=[subtractArray count];
		for (int n=5;n<isize-5;n++)
		{
			iSort=[ [subtractArray objectAtIndex:n] intValue];
			[sortArray addObject:[NSNumber numberWithInt:iSort] ];
		}
		
		//get the average value
		
		for (int m=0;m<[sortArray count];m++)
		{
			iAverage+=[[sortArray objectAtIndex:m] intValue]; 
			
		}
		
		iAverage=iAverage/(ROWNUM-11);
		
		if (iAverage<0)
			iAverage=-1*iAverage;
		
		if(iAverage>[mUpperlimit intValue])
			flag=NO;
		
		
	 [tempArray removeAllObjects];
	 [subtractArray removeAllObjects];
	 [sortArray removeAllObjects];
		
	}
	
	if (flag==NO)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
		
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
		
	}
	
}

//SCRID-152: Add parse to resove LCD Align and V8 stations CB clean issue in checkin and checkout.Judith.2011-12-19.
+(void)ParseGrapeLCD:(NSDictionary*) DictionaryPtr
{
	NSString *mStrSpecLcd=nil ;
	NSString *mStrSpecGrape=nil     ;
	NSString *mReferenceBufferNameLcd=nil ;
	NSString *mReferenceBufferNameGrape=nil ;
	NSString *mBufferName=nil ;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"StrSpecLcd"])
		{
			mStrSpecLcd = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpecGrape"])
		{
			mStrSpecGrape= [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferNameLcd"])
		{
			mReferenceBufferNameLcd = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferNameGrape"])
		{
			mReferenceBufferNameGrape = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName= [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferNameLcd==nil ||
		mReferenceBufferNameGrape==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValueLcd ;
	NSString *mReferenceBufferValueGrape ;
	mReferenceBufferValueLcd = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferNameLcd] ;
	mReferenceBufferValueGrape = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferNameGrape] ;
	if (mReferenceBufferValueLcd==nil || mReferenceBufferValueGrape==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSRange rangeTmpLcd=[mReferenceBufferValueLcd rangeOfString:mStrSpecLcd] ;
	NSRange rangeTmpGrape=[mReferenceBufferValueGrape rangeOfString:mStrSpecGrape] ;
	NSString *strTestResult;
	if (rangeTmpLcd.length <= 0 && rangeTmpGrape.length > 0 )
	{
		strTestResult =@"BYPASS" ;
		[TestItemManage setBufferValue:DictionaryPtr:mBufferName :strTestResult];
	}
	else
	{
		strTestResult =@"PASS" ;
		[TestItemManage setBufferValue:DictionaryPtr:mBufferName :strTestResult];
	}	
}

//SCRID-152:end

@end
