/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIModuleSN.mm  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIModuleSN.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */


#import "UI1M1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"


//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGBUTTONMIN = {1340, 29,  30,	18};
static const UI_INFOR LOGBUTTONMAX = {1340, 29,  30,	18};
static const UI_INFOR LABELRESULT  = {1085, 10,  140,	50};
static const UI_INFOR LOGTEXTMIN   = {1,    -11, 291,	405};
static const UI_INFOR LOGTEXTMAX   = {1 ,	-11, 1340,	652};
static const UI_INFOR TABVIEWMIN   = {1069,  41, 312,	440};
static const UI_INFOR TABVIEWMAX   = {11 ,	 41, 1359,	698};


#define UNITINDEX 1  //only test one unit and the unit index is 1

@implementation UI1M1440X900
-(id)init
{
	self = [super init] ;
	dicScanData = nil;
	stringModuleSn = [[NSMutableString alloc] init] ;
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	fixtureIdPanelController = nil;
	//end
	
	return self ;
}

-(void)dealloc
{
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	if(fixtureIdPanelController)
	{
		[fixtureIdPanelController release];
		fixtureIdPanelController =nil ;
	}
	//end
	[[NSNotificationCenter defaultCenter] removeObserver:self] ;
	[stringModuleSn  release] ;
	[super dealloc] ;
}

- (void)awakeFromNib
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
		[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	}
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
		[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
		[textLabel2 setTextColor:[NSColor blackColor]];
	}
	[textTestResult setFrame:NSMakeRect(LABELRESULT.x, LABELRESULT.y, LABELRESULT.width, LABELRESULT.height)];
	[textTestResult setStringValue:@"No Unit"];
	[textTestResult setFont:[NSFont userFontOfSize:30]];
	[textTestResult setTextColor:[NSColor grayColor]] ;
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
	[[textTestResultDetail documentView]setEditable:false] ;
	[[textAllLog documentView]setEditable:false] ;
	[[textItemLog documentView]setEditable:false] ;
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	
	[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];

	//check if need SN 
	NSString * strWhetherScanSN = [ScriptParse getValueFromSummary:STRKEYWHETHERSCANSN] ;
	if(strWhetherScanSN == nil)
		strWhetherScanSN = @"No";

	if(([strWhetherScanSN isEqualToString:@"No"])||([strWhetherScanSN isEqualToString:@"no"]))
		NSRunAlertPanel(@"WARNNING", @"Please check the SN needed !", @"prompt", nil, nil) ;

	[textModuleSN becomeFirstResponder];
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];	
	}
	[btnSimulator setHidden:YES];/*SCRID:68 by XiuXiu Fix Crash problem about UI2M1440X900 for iPad-1 */
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;//dsx -01-18 fix crash issue
	[self showInitLog];
}

//table datasource implement method
-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	if(([[textTestResult stringValue] isEqualToString:@"No Unit"])
	   ||([[textTestResult stringValue] isEqualToString:@"on going"]))  
		;
	else if(([[textTestResult stringValue] isEqualToString:@"PASS"])||([[textTestResult stringValue] isEqualToString:@"Fail"]))
	{
		[self showTestResult];
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	else
	{
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	
	if ([[aTableColumn identifier] isEqual:@"testItem"])
    	return [UIWinManage getTestItemUIName:rowIndex] ;
	else
		return [UIWinManage getTestItemUIResult:1 :rowIndex] ;
}
- (void)tableViewSelectionDidChange:(NSNotification *)aNotification
{
	NSLog(@"Select changed=================");
}
//20100727 add for set box background color for Pass/fail
-(void)setTableBgdColor:(NSNotification*)notification /*SCRID:68 by XiuXiu Fix Crash problem about UI2M1440X900 for iPad-1 */
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
	{
		if([[textTestResult stringValue] isEqualToString:@"Fail"])
		{
			[boxTestState setBoxType:NSBoxCustom];
			NSLog(@"setboxtype-fail");
			[boxTestState setBorderType:NSLineBorder];
			NSLog(@"setBorderType-fail");
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			NSLog(@"setFillColor-fail");
			//For COF
			//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([[textTestResult stringValue] isEqualToString:@"PASS"])
		{
			[boxTestState setBoxType:NSBoxCustom];
			NSLog(@"setboxtype-pass");
			[boxTestState setBorderType:NSLineBorder];
			NSLog(@"setBorderType-pass");
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			NSLog(@"setFillColor-pass");
		}
		else 
		{
			//	[boxTestState setBoxType:NSBoxPrimary];
			[boxTestState setBoxType:NSBoxCustom];
			NSLog(@"setboxtype-ongoing");
			[boxTestState setBorderType:NSLineBorder];
			NSLog(@"setBorderType-ongoing");
			[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
			NSLog(@"setFillColor-ongoing");
		}
		[boxTestState display];
		NSLog(@"displayboxstate-finally");
	}
	[pool release];
}

-(IBAction)btnStart_Click:(id)sender
{	
	//20100902 henry add for fixture ID check
	if(([strNeedFixtureID isEqualToString:@"yes"])&&([UICommon getFixtureIDScanedFlag] ==NO))
	{
		NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		[fixtureIdPanelController showWindow:self];
		return ;
	}
	
	//Henry added for refresh TableView
	[tvTableview reloadData];
	[tvTableview setUsesAlternatingRowBackgroundColors:YES];

	if([textLabelModuleSn isEnabled])
	{
		[stringModuleSn setString:@""];
		[stringModuleSn appendString:[textModuleSN stringValue]];
		if (stringModuleSn==nil)
			return ;
		[stringModuleSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
		[stringModuleSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
		[stringModuleSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	
		NSInteger len= [stringModuleSn length];
		NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
		NSInteger checkLen=12 ;
		if (strlen!=nil)
		{
			if ([strlen intValue]>0)
				checkLen = [strlen intValue] ;
		}
	
		if(len !=checkLen)
		{
			[textModuleSN setStringValue:@""];
			[textModuleSN becomeFirstResponder];
			return;
		}
		
		dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithString:stringModuleSn] ,STRKEYMODULESN,nil];
	}
	if([UIWinManage isCheckDUTID:1] == FALSE)
	{
		[self showLog:0 isDisable:FALSE];
		//NSLog(@"\n   dicScanData  is %@\n",dicScanData);
		[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :false ScanData:dicScanData] ;
		[textModuleSN setStringValue:@""];
		[textModuleSN becomeFirstResponder];
		dicScanData = nil;
	}
	else 
	{
		NSRunAlertPanel(@"WARNNING", @"Don't press Start button when it is running !", @"prompt", nil, nil) ;
	}
}

-(IBAction)btnCancel_Click:(id)sender
{
	[UIWinManage stopTest:1] ;
};

-(void)showInitLog
{
	NSString *temStr =[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
}


-(IBAction)btnTabViewMaxMin_Click:(id)sender
{
	
	NSString *strTitle =[btnLogMaxMin title];

	if([strTitle isEqualToString:@"Max"])
	{
		[tvTableview setEnabled:FALSE];
		[tvTableview setHidden:TRUE];
		[testItemScroView setHidden:TRUE];
		[btnLogMaxMin setTitle:@"Min"];
		[btnExit setHidden:TRUE];
		[tvTabview setFrame:NSMakeRect(TABVIEWMAX.x, TABVIEWMAX.y, TABVIEWMAX.width, TABVIEWMAX.height)];
		[btnSimulator setHidden:TRUE];
		[boxTestState setHidden:TRUE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
	}
	else if([strTitle isEqualToString:@"Min"])
	{
		[tvTableview setEnabled:TRUE];
		[tvTableview setHidden:FALSE];
		[testItemScroView setHidden:FALSE];
		[btnLogMaxMin setTitle:@"Max"];
		[tvTabview setFrame:NSMakeRect(TABVIEWMIN.x, TABVIEWMIN.y, TABVIEWMIN.width, TABVIEWMIN.height)];
		[btnSimulator setHidden:FALSE];
		[boxTestState setHidden:FALSE];
		[btnExit setHidden:FALSE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
	}
}

//text textModuleSnChange  change
-(IBAction)textModuleSnChange:(id)sender
{
	[stringModuleSn setString:@""];
	[stringModuleSn appendString:[textModuleSN stringValue]];
	if (stringModuleSn==nil)
		return ;
	[stringModuleSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	[stringModuleSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	[stringModuleSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn length])];
	
	NSInteger len= [stringModuleSn length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}

	if(len !=checkLen)
	{
		[textModuleSN setStringValue:@""];
		[textModuleSN becomeFirstResponder];
	}
	else
	{	
		dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn,STRKEYMODULESN,nil];
		[btnStart becomeFirstResponder];
		/*
		[btnStart performClick:textModuleSN];
		[textModuleSN setStringValue:@""];
		[textModuleSN becomeFirstResponder];
		 */
	}
}
-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}
#pragma mark -
#pragma mark Tab View
- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem
{
	NSLog(@"Tab :%@  Clicked",[tabViewItem identifier]);
	if([[tabViewItem identifier] isEqualToString:@"result"])
	{
		[self tabViewItemUpdate:(NSInteger)1];
		[self showTestResult];
	}
	else if([[tabViewItem identifier] isEqualToString:@"all log"])
	{
		[self tabViewItemUpdate:(NSInteger)2];
		[self showLog:1 isDisable:TRUE];
	}
	else if([[tabViewItem identifier] isEqualToString:@"item log"])
	{
		[self tabViewItemUpdate:(NSInteger)3];
		[self showItemLog];
	}
}


-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag
{
	
	[[[[textAllLog documentView] textStorage] mutableString] setString:@""] ;
	if(iShowFlag == FALSE)
		return TRUE;
	
	NSString *temStr =[TestItemManage getUnitLogInfo:logIndex] ;
	if(temStr ==nil)
		temStr = @"No log found";
	[[[[textAllLog documentView] textStorage] mutableString] appendString:temStr] ;
	
	return TRUE;
}

-(void)showItemLog
{
	
	NSString *temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
	[[[[textItemLog documentView] textStorage] mutableString] setString:@""] ;
	
	if(temStr ==nil)
		temStr = @"Can't find the log file !";
	else
		temStr = [self getItemClickedString];
	
	[[[[textItemLog documentView] textStorage] mutableString] appendString:temStr] ;
}

-(void)showTestResult
{
	[[[[textTestResultDetail documentView] textStorage] mutableString] setString:@""] ;
	NSString *temStr =[TestItemManage getResultInfo:UNITINDEX] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
	[textTestResultDetail display];
}

-(NSString *)getItemClickedString
{
	NSInteger rowIndex=-1;
	NSString *testItemStr = nil;
	NSString *nextTestItemStr = nil;
	NSString *lastTestItemStr = nil;
	NSString *temStr = nil;
	NSRange	range,rangePostStr,rangeLastStr;
	
	rowIndex=[tvTableview selectedRow];
	if((rowIndex<0)||(rowIndex>[UIWinManage getTestItemTotal ]))
	{
		temStr = @"";
		return temStr;
	}
	else if(rowIndex == ([UIWinManage getTestItemTotal]-1))
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error2: Cannot find log information";
			return temStr;
		}
		NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
		if((rowIndex+1)<=9)
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
		else
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
		
		range = [temStr rangeOfString:testItemStr];
		if (range.length <= 0)
			temStr = @"Error3: Cannot find log information";
		else
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
	}
	else
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		nextTestItemStr =[UIWinManage getTestItemUIName:(rowIndex+1)];
		lastTestItemStr =[UIWinManage getTestItemUIName:([UIWinManage getTestItemTotal]-1)];
		
		NSRange temStrRang =[testItemStr rangeOfString:@"[" ];
		if (temStrRang.length > 0)
			testItemStr = [testItemStr substringToIndex:(NSInteger)temStrRang.location];
		NSRange temStrRang2 =[nextTestItemStr rangeOfString:@"[" ];
		if (temStrRang2.length > 0)
			nextTestItemStr = [nextTestItemStr substringToIndex:(NSInteger)temStrRang2.location];
		NSRange temStrRang3 =[lastTestItemStr rangeOfString:@"[" ];
		if (temStrRang3.length > 0)
			lastTestItemStr = [lastTestItemStr substringToIndex:(NSInteger)temStrRang3.location];
		
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error4: Cannot find log information";
			return temStr;
		}
		else if((testItemStr!=nil)&&(nextTestItemStr==nil))
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			range = [temStr rangeOfString:testItemStr];
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
			return temStr;
		}
		else
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			NSString *indexNextHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+2] autorelease];
			NSString *indexLastHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",[UIWinManage getTestItemTotal]] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			if((rowIndex+2)<=9)
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexNextHeadStr];
			else
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexNextHeadStr];
			
			range = [temStr rangeOfString:testItemStr];
			rangePostStr = [temStr rangeOfString:nextTestItemStr];
			if ((range.length <= 0)||(rangePostStr.length<=0))
			{
				
				if(lastTestItemStr!=nil)
				{
					if([UIWinManage getTestItemTotal]<=9)
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexLastHeadStr];
					else
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexLastHeadStr];
					rangeLastStr = [temStr rangeOfString:lastTestItemStr];
					if ((range.length <= 0)||(rangeLastStr.length<=0))
						temStr = @"Error5: Cannot find log information";
					else
						temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangeLastStr.location-range.location))];
				}
				else 
				{
					temStr = @"Error5: Cannot find log information";
				}
			}
			else
				temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangePostStr.location-range.location))];
		}
	}
	return temStr;
}

-(void)tabViewItemUpdate:(NSInteger)index 
{
	NSString *strTitle =[btnLogMaxMin title];
	
	switch (index) 
	{
		case 1:
			if([strTitle isEqualToString:@"Min"])
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 2:
			if([strTitle isEqualToString:@"Min"])
				[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 3:
			if([strTitle isEqualToString:@"Min"])
				[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		default:
			break;
	}
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}

@end
