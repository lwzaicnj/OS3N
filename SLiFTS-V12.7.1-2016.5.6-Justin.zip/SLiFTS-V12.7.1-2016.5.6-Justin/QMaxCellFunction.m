/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: QMaxCellFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :Check QMax function.
 
 $History:: QMaxCellFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.31   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "QMaxCellFunction.h"


@implementation TestItemParse(QMaxCellFunction)

+(void)QMaxCellStatus:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mSubTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix =@"";
	NSString *mPostfix =@"";
	NSString *mLenStr =@"";
	int mLen =-1;
	NSString *mSpec =@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SubTestItemName"])
		{
			mSubTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Len"])
		{
			mLenStr = [dictKeyDefined objectForKey:strKey] ;
			mLen = [mLenStr integerValue];
		}
		else if ([strKey isEqualToString:@"Spec"])
		{
			mSpec = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	//mReferenceBufferValue=@"batqmaxUnsealing...status:,B,42 ,gf2UnSealed PASS0x1C 0xDE 0x00 0x18 0x06 0x10 0x60 0xFD 0xC2 
	//						0xF6 0xED 0x00 0x02 0x02 0xBC 0x00 0x64 0x03 0xE8 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00
	//						checksum = 0xC6 Sealing... status:B,62Sealed PASS:-)";
	/*
	Unsealing...
status:,B,42
	UnSealed PASS
	0x1B 0xDB 0x00 0x00 0x06 0x10 0x5A 0xFC 0xA0 0xF2 0x51 0x00 0x01 0x02 0xBC 0x00 0x64 0x03 0xE8 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 
	checksum = 0xAC
	Sealing...
status:B,62
	Sealed PASS
	*/
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	mPrefix = [mPrefix stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	mPrefix = [mPrefix stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	bool flag = false;
	NSString *buffer = @"";
	if(mLen <= 0)
	{
		buffer = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
		if (buffer!=nil && [buffer length] > 0)
			flag = true;
	}
	else
	{
		NSRange rangeTmp = [mReferenceBufferValue rangeOfString:mPrefix];
		if(rangeTmp.length > 0)
		{
			if(([mReferenceBufferValue length] - (rangeTmp.location+[mPrefix length])) < mLen)
			{
				flag = false;
				if([mReferenceBufferValue length] > rangeTmp.location+[mPrefix length])
				{
					buffer = [mReferenceBufferValue substringFromIndex:rangeTmp.location+[mPrefix length]];
				}
			}
			else
			{
				flag = true;
				NSString *tmp = @"";
				if([mReferenceBufferValue length] > rangeTmp.location+[mPrefix length])
				{
					tmp = [mReferenceBufferValue substringFromIndex:rangeTmp.location+[mPrefix length]];
				}
				if([tmp length] >= mLen)
				{
					buffer = [tmp substringToIndex:mLen];
				}
			}
		}
	}

	if(!flag)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Response length less than LEN"] ; 
	}
	else
	{
		NSString *tBuf = buffer;
		tBuf = [tBuf stringByReplacingOccurrencesOfString:@" " withString:@""];
		tBuf = [tBuf stringByReplacingOccurrencesOfString:@"	" withString:@""];
		tBuf = [tBuf stringByReplacingOccurrencesOfString:@"0x" withString:@""];
		tBuf = [tBuf stringByReplacingOccurrencesOfString:@"0X" withString:@""];
		tBuf = [tBuf stringByReplacingOccurrencesOfString:@"," withString:@""];
		
		NSString *HexChar = @"abcdefABCDEF0123456789";
		bool bHex = true;
		NSString *tmp = tBuf;
		for(int i=0; i<[tmp length]; i++)
		{
			tBuf = [tmp substringFromIndex:i];
			NSString *PP = [tBuf substringToIndex:1];
			NSRange rangeAA = [HexChar rangeOfString:PP];
			if(rangeAA.length<=0)
			{
				bHex = false;
				break;
			}
		}
		if(!bHex)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Is not Hex Value"] ;
			return;
		}
				
	/*	
		NSString *testValue = @"";
		NSRange rangeS = [buffer rangeOfString:@","];
		if(rangeS.length <= 0)
		{
			testValue = buffer;
		}
		else
		{	
			testValue = [testValue stringByAppendingString:@"0X"];
			testValue = [testValue stringByAppendingString:[buffer substringToIndex: rangeS.location]];
			testValue = [testValue stringByAppendingString:[buffer substringFromIndex: rangeS.location+1]];
		}
	*/
		
		NSString *tValue = @"";
		tValue = [tValue stringByAppendingString:@"0X"];
		if(tmp != nil)
			tValue = [tValue stringByAppendingString:tmp];
		
		if(mSpec==nil || ([mSpec length] <= 0))
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :tValue] ; 
		}
		else
		{
			if([buffer isEqualToString:mSpec])
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :tValue] ; 
			else
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :tValue] ; 
		}
	}

	return;
	
}

+(void)QMaxCell:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mSubTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix =@"";
	NSString *mLenStr =@"";
	int mLen =-1;
	NSString *mLowerValue =@"";
	NSString *mUpperValue =@"";
	int intLower =0;
	int intUpper =0;
	NSString *mPDCAWrite =@"no";
	NSString *mRecord =@"no";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SubTestItemName"])
		{
			mSubTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey] ;
			intLower = [mLowerValue integerValue];
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue = [dictKeyDefined objectForKey:strKey] ;
			intUpper = [mUpperValue integerValue];
		}
		else if ([strKey isEqualToString:@"Len"])
		{
			mLenStr = [dictKeyDefined objectForKey:strKey] ;
			mLen = [mLenStr integerValue];
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Record"])
		{
			mRecord = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	//mReferenceBufferValue=@"batqmaxUnsealing...status:,B,42 ,gf2UnSealed PASS0x1C 0xDE 0x00 0x18 0x06 0x10 0x60 0xFD 0xC2 0xF6 0xED 0x00 0x02 0x02";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}

	bool flag = false;
	NSString *buffer = nil;

	if(mLen > 0)
	{
		NSRange rangeTmp = [mReferenceBufferValue rangeOfString:mPrefix];
		if(rangeTmp.length > 0)
		{
			if(([mReferenceBufferValue length] - (rangeTmp.location+[mPrefix length])) < mLen)
			{
				flag = false;
				if([mReferenceBufferValue length] > rangeTmp.location+[mPrefix length])
					buffer = [mReferenceBufferValue substringFromIndex:rangeTmp.location+[mPrefix length]];
			}
			else
			{
				flag = true;
				NSString *tmp = @"";
				if([mReferenceBufferValue length] > rangeTmp.location+[mPrefix length])
					tmp = [mReferenceBufferValue substringFromIndex:rangeTmp.location+[mPrefix length]];
				if([tmp length] >= mLen)
					buffer = [tmp substringToIndex:mLen];
			}
		}
	}

	if(!flag)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
	}
	else
	{
		buffer = [buffer stringByReplacingOccurrencesOfString:@" " withString:@""];
		buffer = [buffer stringByReplacingOccurrencesOfString:@"	" withString:@""];
		buffer = [buffer stringByReplacingOccurrencesOfString:@"0x" withString:@""];
		buffer = [buffer stringByReplacingOccurrencesOfString:@"0X" withString:@""];
		
		NSString *tBuf = buffer;
		NSString *HexChar = @"abcdefABCDEF0123456789";
		bool bHex = true;
		NSString *tmp = tBuf;
		for(int i=0; i<[tmp length]; i++)
		{
			tBuf = [tmp substringFromIndex:i];
			NSString *PP = [tBuf substringToIndex:1];
			NSRange rangeAA = [HexChar rangeOfString:PP];
			if(rangeAA.length<=0)
			{
				bHex = false;
				break;
			}
		}
		if(!bHex)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Is not Hex Value"] ;
			return;
		}
		
		char* stopEnd = "";
		int tv = (int)strtol([buffer UTF8String], &stopEnd, 16);

		NSString* testValue = [[NSString alloc] initWithFormat:@"%d",tv];
	

		if(tv<=intUpper && tv>=intLower)
		{
		
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :testValue] ; 
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :testValue] ; 
		}
		
		[testValue autorelease];
		testValue= nil;
	}

	return;
	
}

@end

