#ifndef crimson__acoustics__uart_low_level__hh__
#define crimson__acoustics__uart_low_level__hh__


extern int UART_ReadLine(int handle, void *buffer, size_t buffer_len, bool block= true);


#endif
