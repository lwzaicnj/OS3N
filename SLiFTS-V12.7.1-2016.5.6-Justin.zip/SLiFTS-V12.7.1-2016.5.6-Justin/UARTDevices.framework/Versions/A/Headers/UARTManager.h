#ifndef crimson_acoustic__uart_manager__hh__
#define crimson_acoustic__uart_manager__hh__

#include <vector>
#include <string>


#ifdef __cplusplus

struct uart_description_t
{
	std::string base_name;
	std::string call_out;
	std::string dial_in;
	bool        busy;

	uart_description_t()
	: busy(false)
	{
	}
};


struct UART_t
{
	virtual ~UART_t() {}

	/* configuration */
	virtual bool Configure(unsigned speed) = 0;

	/* raw read write */
	virtual int ReadBytes(void *buffer, size_t buffer_len, bool block = false) = 0;
	virtual int WriteBytes(void const *buffer, size_t buffer_len) = 0;

	/* line oriented API */
	virtual bool ReadLine(std::string &, bool block = true) = 0;
	virtual void WriteLine(std::string const &) = 0;
	
	virtual void SetNL(std::string const &nl_seq) = 0;
    
    /* logging API */   // (added by Kevin on 4/15/13)
    virtual bool BeginLoggingCommunication(std::string serialNumber, bool forwardToSTDOUT = false) = 0;
    virtual bool StopLoggingCommunication() = 0;
    
    virtual std::string LogName() = 0;
    virtual std::string LogDirectory() = 0;
    virtual std::string LogPath() = 0;
};


/*
 * Objective C API
 */
#ifdef __OBJC__



@protocol UARTMgrClient
- (void)UARTListChanged;
@end


@interface UARTMgr: NSObject

+ (UARTMgr *)sharedInstance;

- (std::vector<uart_description_t>)listUARTS;


- (UART_t *) OpenUART: (std::string const &)uart_name;

- (id)  registerForNotification:(id <UARTMgrClient>)watcher;
- (void)unregisterForNotification:(id)exWatcher;

@end

#endif



/*
 * C++ API
 */
class UARTMgr_t
{
public:
	static UART_t                          * OpenUART(std::string const &);
	static std::vector<uart_description_t>   ListUARTS();

	/* XXX : mpetit : need to add some other stuff */
};


#endif


#endif
