/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIWithoutScan.h  $|
 | $Author:: Henry                  $Revision::  2					 $|
 | CREATED: 13.05.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIWithoutScan.h                                       $
 * *****************  Version 1  *****************
 * User: Giga           Date: 24.02.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */


#import "UI1QT1024X768.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"
#import "testItemParse.h"

//           UI Item Name             x,	 y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGBUTTONMIN = {1340, 29, 30,	18};
static const UI_INFOR LOGBUTTONMAX = {1340, 29, 30,	18};
static const UI_INFOR LOGTEXTMIN   = {1,    -11,	 291,	405};
static const UI_INFOR LOGTEXTMAX   = {1 ,	-11,	 1340,	652};
static const UI_INFOR TABVIEWMIN   = {1069,  41,  315,	440};
static const UI_INFOR TABVIEWMAX   = {11 ,	 41, 1359,	698};
//static const UI_INFOR LABELRESULT  = {1085, 10,  140,	50};

#define UNITINDEX 1


@implementation UI1QT1024X768
-(id)init
{
	self = [super init] ;
    //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.
	//dicScanData = nil;
	dicScanData = [[NSMutableDictionary alloc] init] ;
    //SCRID-149:end
	stringSysSn = [[NSMutableString alloc] init] ;
	stringBarcode = [[NSMutableString alloc] init] ;
    //	stringHwySn = [[NSMutableString alloc] init] ;
	stringX15Sn = [[NSMutableString alloc] init] ;
	
	for(int i=0;i<4;i++)
		bSnScanedFlag[i]=NO;
	
	return self ;
}

-(void)dealloc
{
	[stringSysSn  release] ;
	[stringBarcode  release] ;//
    //	[stringHwySn  release] ;
	[stringX15Sn  release] ;
    //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.	
	[dicScanData release] ;
    //SCRID-149:end
	
	[[NSNotificationCenter defaultCenter] removeObserver:self] ; //henry add 2011-02-28
	[super dealloc] ;
}

- (void)awakeFromNib
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	
	
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
		[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	}
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
		[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
		[textLabel2 setTextColor:[NSColor blackColor]];
	}
	
	//add for hide simulator button  by Henry 20101005
	NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
	if([stationName isEqualToString:@"ALS Test"])
		[btnSimulator setHidden:YES];
	
	if([stationName isEqualToString:@"Connectivity2 Test"])
	{
		[textLabelSysSn setStringValue:@"LCD SN"];
		[textLabelBarCode setStringValue:@"Grape SN"];
	}
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
    //	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
	[[textTestResultDetail documentView]setEditable:false] ;
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	
	//check if need SN
	NSString * strWhetherScanSN = [ScriptParse getValueFromSummary:STRKEYWHETHERSCANSN] ;
	if(strWhetherScanSN == nil)
		strWhetherScanSN = @"No";
	NSString * strWhether4SnOr2Sn = [ScriptParse getValueFromSummary:STRKEYWHETHER4SN] ;
	if (strWhether4SnOr2Sn==nil)
		strWhether4SnOr2Sn = @"no";
	NSString * strWhetherNeedBarcode = [ScriptParse getValueFromSummary:STRKEYWHETHERNEEDBARCODE] ;
	if(strWhetherNeedBarcode == nil)
		strWhetherNeedBarcode = @"No";
	if((([strWhetherScanSN isEqualToString:@"No"])||([strWhetherScanSN isEqualToString:@"no"]))
       &&((([strWhether4SnOr2Sn isEqualToString:@"yes"])||([strWhether4SnOr2Sn isEqualToString:@"Yes"]))||(([strWhetherNeedBarcode isEqualToString:@"yes"])||([strWhetherNeedBarcode isEqualToString:@"Yes"]))))
	{
		NSRunAlertPanel(@"WARNNING", @"Please check the SN needed !", @"prompt", nil, nil) ;
	}
	if(([strWhetherScanSN isEqualToString:@"No"])||([strWhetherScanSN isEqualToString:@"no"]))
	{
		[textSysSN  setEnabled:false];
		[textBarCode  setEnabled:false];
        //		[textHwySn  setEnabled:false];
		[textX15Sn  setEnabled:false];
		[textLabelSysSn  setTextColor:[NSColor grayColor] ];
		[textLabelBarCode  setTextColor:[NSColor grayColor] ];
        //		[textLabelHWySn  setTextColor:[NSColor grayColor] ];
		[textLabelX15Sn  setTextColor:[NSColor grayColor] ];
	}
	else
	{
		if(([strWhether4SnOr2Sn isEqualToString:@"no"])||([strWhether4SnOr2Sn isEqualToString:@"No"]))
		{
            //			[textHwySn setEnabled:NO];
			[textX15Sn setEnabled:NO];
            //			[textLabelHWySn setTextColor:[NSColor grayColor]];
			[textLabelX15Sn setTextColor:[NSColor grayColor]];
			if(([strWhetherNeedBarcode isEqualToString:@"No"])||([strWhetherNeedBarcode isEqualToString:@"no"]))
			{
				mNeedBarcode = FALSE;
				[textBarCode  setEnabled:false];
				[textLabelBarCode  setTextColor:[NSColor grayColor] ];
			}
			else 
			{
				mNeedBarcode = TRUE;
			}
		}
		else
			[textSysSN becomeFirstResponder];	
	}
    
	//20100902 henry add for fixture ID
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		[UICommon setFixtureIDScanedFlag:NO];
		[textFixtureID setEnabled:YES];
		[textFixtureID becomeFirstResponder];
	}	
	else
	{
		[textFixtureID setEnabled:NO];
	}
	//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
	strNeedConfig = [ScriptParse getValueFromSummary:STRKEYNEEDCONFIG];
	if(strNeedConfig == nil)
		strNeedConfig = @"no";
	if([strNeedConfig isEqualToString:@"yes"])
	{
		[UICommon setConfigScanedFlag:NO];
		[textConfig setEnabled:YES];
	}	
	else
	{
		[textConfig setEnabled:NO];
	}
	//SCRID-71:END
	
	//[tvTabview setFrame:NSMakeRect(TABVIEWMIN.x, TABVIEWMIN.y, TABVIEWMIN.width, TABVIEWMIN.height)];
	
	//henry add for set status bar and box satatus 2011-02-28
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;
    
	
	[self showInitLog];
}

//table datasource implement method
-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	
	if(([[textTestResult stringValue] isEqualToString:@"No Unit"])
	   ||([[textTestResult stringValue] isEqualToString:@"on going"]))  
		;
	else if(([[textTestResult stringValue] isEqualToString:@"PASS"])||([[textTestResult stringValue] isEqualToString:@"Fail"]))
	{
		[self showTestResult];
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	else
	{
		[self showLog:1 isDisable:TRUE];
		[self showItemLog];
	}
	
	if ([[aTableColumn identifier] isEqual:@"testItem"])
    	return [UIWinManage getTestItemUIName:rowIndex] ;
	else
		return [UIWinManage getTestItemUIResult:1 :rowIndex] ;
}

-(void)setBoxBgdColor:(NSNotification*)notification ; //henry added 2011-02-28 for set box background color for Pass/fail
{
	if([[textTestResult stringValue] isEqualToString:@"Fail"])
	{
		[boxTestState setBoxType:NSBoxCustom];
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		//For COF
		//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
	}
	else if([[textTestResult stringValue] isEqualToString:@"PASS"])
	{
		[boxTestState setBoxType:NSBoxCustom];
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
	}
	else 
	{
		//	[boxTestState setBoxType:NSBoxPrimary];
		[boxTestState setBoxType:NSBoxCustom]; //20100727 added by henry
		[boxTestState setBorderType:NSLineBorder];
		[boxTestState setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
 	}
	//[boxTestState display];
}

-(IBAction)btnStart_Click:(id)sender
{	
   
	//Henry add for Fixture ID 20100908  
	if(([strNeedFixtureID isEqualToString:@"yes"])&&([UICommon getFixtureIDScanedFlag] ==NO))
	{
		[stringSysSn setString:@""];
		[stringBarcode setString:@""];
		NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
		[textFixtureID becomeFirstResponder];
		return ;
	}
    
	if([strNeedConfig isEqualToString:@"yes"])
	{
		//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
		if([UICommon getConfigScanedFlag] ==NO)
		{
			[stringSysSn setString:@""];
			[stringBarcode setString:@""];
			NSRunAlertPanel(@"WARNNING", @"Please scan the Config!", @"prompt", nil, nil) ;
			[textConfig becomeFirstResponder];
			return ;
		}
		//SCRID-71:END	
		
		
		
		//SCRID-75: add by Evan for protect OP scan wrong WOSN 2011-02-12;
		NSString *strConfig =[textConfig stringValue];
		NSMutableString * stringConfig = [NSMutableString stringWithString:strConfig];
		
		if (stringConfig==nil)
			return ;
		[stringConfig replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
		[stringConfig replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
		[stringConfig replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
		
		NSInteger checkConfigLen=10 ;
		
		if ([stringConfig length] != checkConfigLen || [stringConfig characterAtIndex:0] != 'W' || [stringConfig characterAtIndex:3] != '-')
		{
			[textConfig setStringValue:@""];
			return;
		}
		// SCRID-75:END
	}
	
	
	if( [textSysSN isEnabled] )
	{	
		[stringSysSn setString:@""];
		[stringSysSn appendString:[textSysSN stringValue]];
		if (stringSysSn==nil)
			return ;
		[stringSysSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
		[stringSysSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
		[stringSysSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
		NSInteger len= [stringSysSn length];
		NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
		NSInteger checkLen=12 ;
        NSInteger checkLen2=0 ;
        NSInteger checkLen3=0 ;
		if (strlen!=nil)
		{
			if ([strlen intValue]>0)
				checkLen = [strlen intValue] ;
            if([strlen rangeOfString:@"|"].length > 0)
            {
                NSArray *tmpSN = [strlen componentsSeparatedByString:@"|"];
                if([tmpSN count] == 2)
                {
                    checkLen = [[tmpSN objectAtIndex:0] intValue];
                    checkLen2 = [[tmpSN objectAtIndex:1] intValue];
                }
                else if([tmpSN count] == 3)
                {
                    checkLen = [[tmpSN objectAtIndex:0] intValue];
                    checkLen2 = [[tmpSN objectAtIndex:1] intValue];
                    checkLen3 = [[tmpSN objectAtIndex:2] intValue];
                }
                
            }
		}
		if(len != checkLen && len != checkLen2 && len != checkLen3)
		{
			[stringSysSn setString:@""];
			[textSysSN becomeFirstResponder];
			return;
		}
	}
	
	if([UIWinManage isCheckDUTID:1] == FALSE)
	{
		//[stringSysSn setString:@""];
		[self showLog:0 isDisable:FALSE];
		[textSysSN becomeFirstResponder];
        //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.	
		//[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :false ScanData:dicScanData] ;
		//dicScanData = nil;
        [textSysSN setStringValue:@""];
        [textBarCode setStringValue:@""];
		if ([dicScanData count]>0)
		{
			NSDictionary *dictTmp = [NSDictionary dictionaryWithDictionary:dicScanData] ;
			[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :false ScanData:dictTmp] ;
			[dicScanData removeAllObjects] ;
		}else
		{
			[UIWinManage startTest:1 :tvTableview :textItemTime :textTotalTime :textTestResult :false ScanData:nil] ;
		}
        //SCRID-149:end
	}
	else 
	{
		NSRunAlertPanel(@"WARNNING", @"Don't press Start button when it is running !", @"prompt", nil, nil) ;
	}
}

-(IBAction)btnCancel_Click:(id)sender
{
	[UIWinManage stopTest:1] ;
};


-(void)showInitLog
{
	NSString *temStr =[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
}


-(IBAction)btnTabViewMaxMin_Click:(id)sender
{
	
	NSString *strTitle =[btnLogMaxMin title];
	
	if([strTitle isEqualToString:@"Max"])
	{
		[tvTableview setEnabled:FALSE];
		[tvTableview setHidden:TRUE];
		[testItemScroView setHidden:TRUE];
		[btnLogMaxMin setTitle:@"Min"];
		[btnExit setHidden:TRUE];
		//[tvTabview setFrame:NSMakeRect(TABVIEWMAX.x, TABVIEWMAX.y, TABVIEWMAX.width, TABVIEWMAX.height)];
		[btnSimulator setHidden:TRUE];
		[boxTestState setHidden:TRUE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
	}
	else if([strTitle isEqualToString:@"Min"])
	{
		[tvTableview setEnabled:TRUE];
		[tvTableview setHidden:FALSE];
		[testItemScroView setHidden:FALSE];
		[btnLogMaxMin setTitle:@"Max"];
		//[tvTabview setFrame:NSMakeRect(TABVIEWMIN.x, TABVIEWMIN.y, TABVIEWMIN.width, TABVIEWMIN.height)];
		[btnSimulator setHidden:FALSE];
		[boxTestState setHidden:FALSE];
		[btnExit setHidden:FALSE];
		[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
		[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
	}
}

//text SysSn/Barcode/HwySn/X15Sn  change
-(IBAction)textSysSnChange:(id)sender
{
	[stringSysSn setString:@""];
	[stringSysSn appendString:[textSysSN stringValue]];
	if (stringSysSn==nil)
		return ;
	[stringSysSn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
	[stringSysSn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
	[stringSysSn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringSysSn length])];
	
	NSInteger len= [stringSysSn length];
	
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	// serin 0620 change SN lenth from 11 to 12
	NSInteger checkLen=12 ;
    NSInteger checkLen2=-1 ;
    NSInteger checkLen3=-1 ;
	if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
        if([strlen rangeOfString:@"|"].length > 0)
        {
            NSArray *tmpSN = [strlen componentsSeparatedByString:@"|"];
            if([tmpSN count] == 2)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
            }
            else if([tmpSN count] == 3)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
                checkLen3 = [[tmpSN objectAtIndex:2] intValue];
            }
            
        }
	}
	if(len != checkLen && len != checkLen2 && len != checkLen3)
	{
		[textSysSN setStringValue:@""];
		[textSysSN becomeFirstResponder];
	}
	else
	{	
		if(mNeedBarcode == TRUE)
		{
			bSnScanedFlag[0] =TRUE;
			[textBarCode becomeFirstResponder];
		}
		else
		{
            //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.	
			//dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringSysSn,STRKEYSYSSN,nil];
			[dicScanData setObject:[NSString stringWithString:stringSysSn] forKey:STRKEYSYSSN] ;
            //SCRID-149:end
            NSString *strNoStarTestAfterScanSN= [ScriptParse getValueFromSummary:@"NoStarTestAfterScanSN"];
            NSString *strTestStation= [ScriptParse getValueFromSummary:@"TestStation"];
            if((![strTestStation isEqualToString:@"iQC RGBW"]) && (![strNoStarTestAfterScanSN boolValue]))
            {
                [btnStart performClick:textSysSN];
                [textSysSN setStringValue:@""];
            }
			[textSysSN becomeFirstResponder];
			[self showLog:0 isDisable:FALSE];
		}
	}
}

-(IBAction)textBarcodeChange:(id)sender
{
	[stringBarcode setString:@""];
	[stringBarcode appendString:[textBarCode stringValue]];
	if (stringBarcode==nil)
		return ;
	[stringBarcode replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringBarcode length])];
	[stringBarcode replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringBarcode length])];
	[stringBarcode replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringBarcode length])];
	
	// K94-PROTO1_SOP-01_0001
	NSInteger len = [stringBarcode length];
	NSString *temp = [stringBarcode stringByReplacingOccurrencesOfString:@" " withString:@""];
	NSArray *array = [stringBarcode componentsSeparatedByString:@"_"];
	NSInteger count = [array count];
	
	NSString *stationName =[ScriptParse getValueFromSummary:@"TestStation"];
	// serin 20100718
    // if((count != 4)||([array containsObject:@""]!=0)||([temp length]!=len))
    
    /* blake add for RGBW 20130328*/
    if ([stationName isEqualToString:@"iQC RGBW"])
    {
        if (len!=8)
        {
            [textBarCode setStringValue:@""];
        }
        else
        {
            {
                bSnScanedFlag[1] = TRUE;
                if(bSnScanedFlag[0] && bSnScanedFlag[1])
                {
                    NSString * strWhether4SnOr2Sn = [ScriptParse getValueFromSummary:STRKEYWHETHER4SN] ;
                    if (strWhether4SnOr2Sn==nil)
                        strWhether4SnOr2Sn = @"no";
                    
                    if(([strWhether4SnOr2Sn isEqualToString:@"yes"])||([strWhether4SnOr2Sn isEqualToString:@"Yes"]))
                    {
                        //			[textHwySn becomeFirstResponder];
                    }
                    else
                    {
                        [dicScanData setObject:[NSString stringWithString:stringSysSn] forKey:STRKEYSYSSN] ;
                        [dicScanData setObject:[NSString stringWithString:stringBarcode] forKey:STRKEYBCSN];
                        
                        for(int i=0;i<4;i++)
                            bSnScanedFlag[i] = FALSE;
                        //[textSysSN becomeFirstResponder];
                        [self showLog:0 isDisable:FALSE];
                    }
                }
            }
            
        }
        
    }/* blake add end for RGBW 20130328*/
    else
    {
        //normal barcode
        if(((count != 3)||([array containsObject:@""]!=0)||([temp length]!=len)) && (![stationName isEqualToString:@"Connectivity2 Test"]))
            // end
        {
            [textBarCode setStringValue:@""];
        }
        /*else if([stationName isEqualToString:@"Connectivity2 Test"])
         {
         [textLabelSysSn setStringValue:@"LCD SN"];
         [textLabelBarCode setStringValue:@"Grape SN"];
         }*/
        else
        {
            if([stationName isEqualToString:@"Connectivity2 Test"] && (len != [[ScriptParse getValueFromSummary:@"BarCodeLength"] intValue]))
            {
                //if(len != [[ScriptParse getValueFromSummary:@"BarCodeLength"] intValue])
                [textBarCode setStringValue:@""];
            }
            else
            {
                bSnScanedFlag[1] = TRUE;
                if(bSnScanedFlag[0] && bSnScanedFlag[1])
                {
                    NSString * strWhether4SnOr2Sn = [ScriptParse getValueFromSummary:STRKEYWHETHER4SN] ;
                    if (strWhether4SnOr2Sn==nil)
                        strWhether4SnOr2Sn = @"no";
                    
                    if(([strWhether4SnOr2Sn isEqualToString:@"yes"])||([strWhether4SnOr2Sn isEqualToString:@"Yes"]))
                    {
                        //			[textHwySn becomeFirstResponder];
                    }
                    else
                    {
                        //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.
                        //dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringSysSn,STRKEYSYSSN,stringBarcode,STRKEYBCSN, nil];
                        [dicScanData setObject:[NSString stringWithString:stringSysSn] forKey:STRKEYSYSSN] ; //add by giga
                        [dicScanData setObject:[NSString stringWithString:stringBarcode] forKey:STRKEYBCSN]; //add by giga
                        //SCRID-149:end
                        [btnStart performClick:textSysSN];
                        [textSysSN setStringValue:@""];
                        [textBarCode setStringValue:@""];
                        
                        for(int i=0;i<4;i++)
                            bSnScanedFlag[i] = FALSE;
                        [textSysSN becomeFirstResponder];
                        [self showLog:0 isDisable:FALSE];
                    }
                }
                else
                {
                    NSRunAlertPanel(@"Warning", @"One of the InputBox is empty!", @"OK",nil,nil);
                }
            }
        }
    }
}
/*-(IBAction)textHwySnChange:(id)sender
 {
 [stringHwySn setString:@""];
 [stringHwySn appendString:[textHwySn stringValue]];
 if (stringHwySn==nil)
 return ;
 [stringHwySn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringHwySn length])];
 [stringHwySn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringHwySn length])];
 [stringHwySn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringHwySn length])];
 
 int len= [stringHwySn length];			// the length is 13
 
 //check HwySn 
 if(len!=13)
 {		
 [textHwySn setStringValue:@""];	
 }
 else	
 {
 bSnScanedFlag[2] = TRUE;
 if(bSnScanedFlag[0]&& bSnScanedFlag[1]&&bSnScanedFlag[2])
 [textX15Sn becomeFirstResponder];
 else
 NSRunAlertPanel(@"Warning", @"One of the InputBox is empty!", @"OK",nil,nil);
 }
 }
 */
-(IBAction)textFixtureIdChange:(id)sender
{
	NSString *strFixtureIDScan =[textFixtureID stringValue];
	[UICommon setFixtureID:strFixtureIDScan];
	if(![strFixtureIDScan isEqualTo:@""])
	{
		[UICommon setFixtureIDScanedFlag:YES];
		[textFixtureID setEnabled:NO] ;
		[textSysSN becomeFirstResponder];
		[textConfig becomeFirstResponder];//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
	}
}

//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
-(IBAction)textConfigChange:(id)sender 
{
	NSString *strConfig =[textConfig stringValue];
	[UICommon setConfig: strConfig];
	
	
	// SCRID-75: add by Evan for protect OP scan wrong WOSN 2011-02-12;
	NSMutableString * stringConfig = [NSMutableString stringWithString:strConfig];
    
	if (stringConfig==nil)
		return ;
	[stringConfig replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
	[stringConfig replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
	[stringConfig replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringConfig length])];
	
	NSInteger checkConfigLen=10 ;
	
	if ([stringConfig length] != checkConfigLen || [stringConfig characterAtIndex:0] != 'W' || [stringConfig characterAtIndex:3] != '-')
	{
		[textConfig setStringValue:@""];
		return;
	}
	// SCRID-75:END
    
	
	if(![strConfig isEqualTo:@""])
	{	
		[UICommon setConfigScanedFlag:YES];
		[textFixtureID setEnabled:NO] ;
		[textSysSN becomeFirstResponder];
	}
	
    
}
//SCRID-71:END

-(IBAction)textX15SnChange:(id)sender
{
	[stringX15Sn setString:@""];
	[stringX15Sn appendString:[textX15Sn stringValue]];
	if (stringX15Sn==nil)
		return ;
	[stringX15Sn replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringX15Sn length])];
	[stringX15Sn replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringX15Sn length])];
	[stringX15Sn replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringX15Sn length])];
	
	int len = [stringX15Sn length];
	//check HwySn 
	if(len!=13)
	{
		[textX15Sn setStringValue:@""];
	}
	else
	{
		bSnScanedFlag[3] = TRUE;
		if(bSnScanedFlag[0] && bSnScanedFlag[1] && bSnScanedFlag[2] && bSnScanedFlag[3])
		{
            //			dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringSysSn,STRKEYSYSSN,stringBarcode,STRKEYBCSN,stringHwySn,STRKEYHWSN, stringX15Sn,STRKEYX15SN ,nil];
            //SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.	
			//dicScanData = [NSDictionary dictionaryWithObjectsAndKeys:stringSysSn,STRKEYSYSSN,stringBarcode,STRKEYHWSN, stringX15Sn,STRKEYX15SN ,nil];
			[dicScanData setObject:[NSString stringWithString:stringSysSn] forKey:STRKEYSYSSN] ; //add by giga
			[dicScanData setObject:[NSString stringWithString:stringBarcode] forKey:STRKEYHWSN]; //add by giga
			[dicScanData setObject:[NSString stringWithString:stringX15Sn] forKey:STRKEYX15SN]; //add by giga
            //SCRID-149:end			
			[btnStart performClick:textSysSN];
			[textSysSN setStringValue:@""];
			[textBarCode setStringValue:@""];
            //			[textHwySn setStringValue:@""];
			[textX15Sn setStringValue:@""];
			for(int i=0;i<4;i++)
				bSnScanedFlag[i] = FALSE;
			[textSysSN becomeFirstResponder];
			[self showLog:0 isDisable:FALSE];
		}
		else
		{
			NSRunAlertPanel(@"Warning", @"One of the InputBox is empty!", @"OK",nil,nil);
		}
	}
}
-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

#pragma mark -
#pragma mark Tab View
- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem
{
	NSLog(@"Tab :%@  Clicked",[tabViewItem identifier]);
	if([[tabViewItem identifier] isEqualToString:@"result"])
	{
		[self tabViewItemUpdate:(NSInteger)1];
		[self showTestResult];
	}
	else if([[tabViewItem identifier] isEqualToString:@"all log"])
	{
		[self tabViewItemUpdate:(NSInteger)2];
		[self showLog:1 isDisable:TRUE];
	}
	else if([[tabViewItem identifier] isEqualToString:@"item log"])
	{
		[self tabViewItemUpdate:(NSInteger)3];
		[self showItemLog];
	}
}


-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag
{
	
	[[[[textAllLog documentView] textStorage] mutableString] setString:@""] ;
	if(iShowFlag == FALSE)
		return TRUE;
	
	NSString *temStr =[TestItemManage getUnitLogInfo:logIndex] ;
	if(temStr ==nil)
		temStr = @"No log found";
	[[[[textAllLog documentView] textStorage] mutableString] appendString:temStr] ;
	
	return TRUE;
}

-(void)showItemLog
{
	
	NSString *temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
	[[[[textItemLog documentView] textStorage] mutableString] setString:@""] ;
	
	if(temStr ==nil)
		temStr = @"Can't find the log file !";
	else
		temStr = [self getItemClickedString];
	
	[[[[textItemLog documentView] textStorage] mutableString] appendString:temStr] ;
}

-(void)showTestResult
{
	[[[[textTestResultDetail documentView] textStorage] mutableString] setString:@""] ;
	NSString *temStr =[TestItemManage getResultInfo:UNITINDEX] ;
	if (temStr!=nil) 
		[[[[textTestResultDetail documentView] textStorage] mutableString] appendString:temStr] ;
	//[textTestResultDetail display];
}

-(NSString *)getItemClickedString
{
	NSInteger rowIndex=-1;
	NSString *testItemStr = nil;
	NSString *nextTestItemStr = nil;
	NSString *lastTestItemStr = nil;
	NSString *temStr = nil;
	NSRange	range,rangePostStr,rangeLastStr;
	
	rowIndex=[tvTableview selectedRow];
	if((rowIndex<0)||(rowIndex>[UIWinManage getTestItemTotal ]))
	{
		temStr = @"";
		return temStr;
	}
	else if(rowIndex == ([UIWinManage getTestItemTotal]-1))
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error2: Cannot find log information";
			return temStr;
		}
		NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
		if((rowIndex+1)<=9)
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
		else
			testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
		
		range = [temStr rangeOfString:testItemStr];
		if (range.length <= 0)
			temStr = @"Error3: Cannot find log information";
		else
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
	}
	else
	{
		testItemStr = [UIWinManage getTestItemUIName:rowIndex];
		nextTestItemStr =[UIWinManage getTestItemUIName:(rowIndex+1)];
		lastTestItemStr =[UIWinManage getTestItemUIName:([UIWinManage getTestItemTotal]-1)];
		
		NSRange temStrRang =[testItemStr rangeOfString:@"[" ];
		if (temStrRang.length > 0)
			testItemStr = [testItemStr substringToIndex:(NSInteger)temStrRang.location];
		NSRange temStrRang2 =[nextTestItemStr rangeOfString:@"[" ];
		if (temStrRang2.length > 0)
			nextTestItemStr = [nextTestItemStr substringToIndex:(NSInteger)temStrRang2.location];
		NSRange temStrRang3 =[lastTestItemStr rangeOfString:@"[" ];
		if (temStrRang3.length > 0)
			lastTestItemStr = [lastTestItemStr substringToIndex:(NSInteger)temStrRang3.location];
		
		temStr =[TestItemManage getUnitLogInfo:UNITINDEX] ;
		
		if((testItemStr==nil)||(temStr==nil))
		{
			temStr =@"Error4: Cannot find log information";
			return temStr;
		}
		else if((testItemStr!=nil)&&(nextTestItemStr==nil))
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			range = [temStr rangeOfString:testItemStr];
			temStr =[ temStr substringFromIndex:(NSUInteger)range.location ];
			return temStr;
		}
		else
		{
			NSString *indexHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+1] autorelease];
			NSString *indexNextHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",rowIndex+2] autorelease];
			NSString *indexLastHeadStr = [[[NSString alloc] initWithFormat:@"%d : ",[UIWinManage getTestItemTotal]] autorelease];
			if((rowIndex+1)<=9)
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexHeadStr];
			else
				testItemStr = [testItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexHeadStr];
			if((rowIndex+2)<=9)
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexNextHeadStr];
			else
				nextTestItemStr = [nextTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexNextHeadStr];
			
			range = [temStr rangeOfString:testItemStr];
			rangePostStr = [temStr rangeOfString:nextTestItemStr];
			if ((range.length <= 0)||(rangePostStr.length<=0))
			{
				
				if(lastTestItemStr!=nil)
				{
					if([UIWinManage getTestItemTotal]<=9)
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 2) withString:indexLastHeadStr];
					else
						lastTestItemStr = [lastTestItemStr stringByReplacingCharactersInRange:NSMakeRange(0, 3) withString:indexLastHeadStr];
					rangeLastStr = [temStr rangeOfString:lastTestItemStr];
					if ((range.length <= 0)||(rangeLastStr.length<=0))
						temStr = @"Error5: Cannot find log information";
					else
						temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangeLastStr.location-range.location))];
				}
				else 
				{
					temStr = @"Error5: Cannot find log information";
				}
			}
			else
				temStr =[temStr substringWithRange:NSMakeRange(range.location, (rangePostStr.location-range.location))];
		}
	}
	return temStr;
}

-(void)tabViewItemUpdate:(NSInteger)index 
{
	NSString *strTitle =[btnLogMaxMin title];
	
	switch (index) 
	{
		case 1:
			if([strTitle isEqualToString:@"Min"])
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textTestResultDetail setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 2:
			if([strTitle isEqualToString:@"Min"])
				[textAllLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textAllLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		case 3:
			if([strTitle isEqualToString:@"Min"])
				[textItemLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
			else
				[textItemLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];
			break;
		default:
			break;
	}
}
-(IBAction)reloadScript:(id)sender
{
    if([ScriptParse parseTestScript:[ScriptParse getValueFromSummary:@"TestScript"]])
    {
        [TestItemManage initTestItemInfo];
        [TestItemParse testItemParseInit];
        [tvTableview reloadData];
        //system([[NSString stringWithFormat:@"open %@",[ScriptParse getValueFromSummary:@"TestScript"]] UTF8String]);
    }
    else
        NSLog(@"Reload Fail");
    
}
-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}
@end
