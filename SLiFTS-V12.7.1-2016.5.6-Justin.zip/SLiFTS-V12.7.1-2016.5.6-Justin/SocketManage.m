//
//  SocketManage.m
//  iFTS
//
//  Created by SW QT on 11/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SocketManage.h"

CommManage *commManageForSocket=nil ;  //one socket manage one client 
//buffer info
NSMutableDictionary *mutDictScriptData=nil ;
NSMutableString		*strAppConfigForSocket=nil ; 
NSMutableString		*strTestScriptForSocket=nil; 
NSMutableArray      *mutArrayStationIdForSocket=nil ;
NSMutableArray      *mutArrayScriptVerForSocket=nil ;

NSMutableString     *mutstrCloudErrorMessage=nil ;

@implementation SocketManage
+(bool)loadDataFromCloudServer:(NSString*) strIP PortID
                              :(int)iPortID  ProtocolStr
							  :(NSString *)strCmd  DataType
                              :(enum SocketDataType) socketDataType TimeOut  
                              :(int) iTimeOut 
{
	if (strCmd==nil || strIP==nil)
	{
		[self setCloudErrorMsg:@"Error :incoming paraemter is null!"];
		return FALSE ;
	}
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	if (commManageForSocket==nil)
	{
		commManageForSocket = [[CommManage alloc] init] ;
		if (commManageForSocket==nil)
		{
			[pool release] ;
			[self setCloudErrorMsg:@"Error :socket communication model init fail !"];
			return FALSE ;
		}
	} ;
	bool bRtn= FALSE ;
	
	//step 1 : close the prior connection .
	[commManageForSocket ClosePort:SocketDefineDevice] ;
	//step 2 : create a new connection ,then send protocol string
	NSMutableDictionary *mutDictKey=[[[NSMutableDictionary alloc] init] autorelease] ;
	[mutDictKey setObject:@":-):-)" forKey:@"EndString"] ;
	bRtn = [commManageForSocket Socket_OpenPort:SocketDefineDevice IPAddress:strIP PortID:iPortID KeysDefine:mutDictKey] ;
	if (bRtn==FALSE)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :socket connect fail !"];
		return FALSE ;
	}	
	
	bRtn = [commManageForSocket WriteData:SocketDefineDevice DataBuffer:[NSData dataWithBytes:[strCmd cStringUsingEncoding:NSASCIIStringEncoding] length:[strCmd length]] :mutDictKey] ;
	if (bRtn==FALSE)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release];
		[self setCloudErrorMsg:@"Error :send data fail !"];
		return FALSE ;
	}
	//step 3 :read the respondance
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = 3 ;//define 
	if (iTimeOut>0)
		iTmp = iTimeOut ;
	
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		if ([commManageForSocket CheckISCompleteDataUsingCurrKey:SocketDefineDevice]) 
			break ;
		else
			usleep(100000) ; //delay 100ms
	}
	//read data
	NSData* dataTmp= [commManageForSocket ReadData:SocketDefineDevice] ;
	if (dataTmp==nil)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :Cloud server is not feedback !"] ;
		return FALSE ;
	}
	if ([dataTmp length]<=0)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :Cloud server is not feedback !"] ;
		return FALSE ;
	}
	
	//NSLog(@"\n %@ \n",strRtn) ;
	//fill to public buffer
	switch (socketDataType) {
		case SocketDataType_ScriptData:
			bRtn = [self fillDataToScriptData:dataTmp] ;
			break;
		case SocketDataType_VersionList:
			bRtn = [self fillDataToVersionList:dataTmp] ;
			break;	
		case SocketDataType_StationList:
			bRtn = [self fillDataToStationList:dataTmp] ;
			break;
		case SocketDataType_Appconfig:
			bRtn = [self fillDataToAppconfig:dataTmp] ;
			break;	
		case SocketDataType_TestScript:
			bRtn = [self fillDataToTestScript:dataTmp] ;
			break;		
		default:
			bRtn = FALSE ;
			break;
	}
	[commManageForSocket ClosePort:SocketDefineDevice] ;
	[pool release] ;
	return bRtn ;
}

+(bool)sendDataToCloudServer:(NSString*) strIP PortID
							:(int)iPortID  ProtocolStr
							:(NSString *)strCmd  TimeOut
							:(int)iTimeOut 
{
	if (strCmd==nil || strIP==nil)
	{
		[self setCloudErrorMsg:@"Error :incoming paraemter is null!"] ;
		return FALSE ;
	}
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	if (commManageForSocket==nil)
	{
		commManageForSocket = [[CommManage alloc] init] ;
		if (commManageForSocket==nil)
		{
			[pool release] ;
			[self setCloudErrorMsg:@"Error :socket communication model init fail !"] ;
			return FALSE ;
		}
	} ;
	bool bRtn= FALSE ;
	//step 1 : close the prior connection .
	[commManageForSocket ClosePort:SocketDefineDevice] ;
	//step 2 : create a new connection ,then send protocol string
	NSMutableDictionary *mutDictKey=[[[NSMutableDictionary alloc] init] autorelease] ;
	[mutDictKey setObject:@":-):-)" forKey:@"EndString"] ;
	bRtn = [commManageForSocket Socket_OpenPort:SocketDefineDevice IPAddress:strIP PortID:iPortID KeysDefine:mutDictKey] ;
	if (bRtn==FALSE)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :socket connect fail !"];
		return FALSE ;
	}	
	
	bRtn = [commManageForSocket WriteData:SocketDefineDevice DataBuffer:[NSData dataWithBytes:[strCmd cStringUsingEncoding:NSASCIIStringEncoding] length:[strCmd length]] :mutDictKey] ;
	if (bRtn==FALSE)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :send data fail !"];
		return FALSE ;
	}
	//step 3 :read the respondance
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = 3 ;//define
	if (iTimeOut>0) 
		iTmp = iTimeOut ;
	
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		if ([commManageForSocket CheckISCompleteDataUsingCurrKey:SocketDefineDevice]) 
			break ;
		else
			usleep(100000) ; //delay 100ms
	}
	//read data
	NSData* dataTmp= [commManageForSocket ReadData:SocketDefineDevice] ;
	if (dataTmp==nil)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :Cloud server is not feedback!"];
		return FALSE ;
	}
	if ([dataTmp length]<=0)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:@"Error :Cloud server is not feedback!"];
		return FALSE ;
	}
	
	NSString *strScriptData=[[[NSString alloc] initWithData:dataTmp encoding:NSASCIIStringEncoding] autorelease];
	if (strScriptData==nil)
	{
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		return FALSE ;
	}
	//step 1 : check whether error message 
	NSRange rangeTmp = [strScriptData rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[commManageForSocket ClosePort:SocketDefineDevice] ;
		[pool release] ;
		[self setCloudErrorMsg:strScriptData] ;
		return FALSE ;
	}
	
	[commManageForSocket ClosePort:SocketDefineDevice] ;
	[pool release] ;
	return true ;
}

+(void)setCloudErrorMsg:(NSString*)strErr
{
	if (strErr==nil)
		return  ;
	
	if (mutstrCloudErrorMessage==nil)
	{
		mutstrCloudErrorMessage = [[NSMutableString alloc] initWithString:strErr] ;
		return ;
	}
	[mutstrCloudErrorMessage appendFormat:@"\n%@",strErr] ;
	return ;
}

+(NSString*)getCloudErrorMsg
{
	if (mutstrCloudErrorMessage==nil)
		return nil ;
	
	if ([mutstrCloudErrorMessage length]<=1)
		return nil ;
	
	NSString *strErr = [NSString stringWithString:mutstrCloudErrorMessage] ;
	[mutstrCloudErrorMessage setString:@""] ;
	return strErr ;
}

+(NSString*)getAppconfigData  
{
	if (strAppConfigForSocket==nil)
		return nil ;
	if ([strAppConfigForSocket length]<=0)
		return nil ;
	
	return [NSString stringWithString:strAppConfigForSocket] ;
}

+(NSString*)getTestScriptData
{
	if (strTestScriptForSocket==nil)
		return nil ;
	if ([strTestScriptForSocket length]<=0)
		return nil ;
	
	return [NSString stringWithString:strTestScriptForSocket] ;
}

+(NSArray*)getStationListData 
{
	if (mutArrayStationIdForSocket==nil)
		return nil ;
	if ([mutArrayStationIdForSocket count]<=0)
		return nil ;
	
	return [NSArray arrayWithArray:mutArrayStationIdForSocket] ;
}
+(NSArray*)getVersionListData 
{
	if (mutArrayScriptVerForSocket==nil)
		return nil ;
	if ([mutArrayScriptVerForSocket count]<=0)
		return nil ;
	
	return [NSArray arrayWithArray:mutArrayScriptVerForSocket] ;
}

+(NSDictionary*)getDictSummaryFromScriptData 
{
	if (mutDictScriptData==nil)
		return nil ;
	if ([mutDictScriptData count]<=0)
		return nil ;
	
	return [mutDictScriptData objectForKey:KEY_Summary] ;
}

+(NSDictionary*)getDictLogServiceFromScriptData 
{
	if (mutDictScriptData==nil)
		return nil ;
	if ([mutDictScriptData count]<=0)
		return nil ;
	
	return [mutDictScriptData objectForKey:KEY_LogService] ;
}

+(NSArray*)getArrayDeviceServiceFromScriptData 
{
	if (mutDictScriptData==nil)
		return nil ;
	if ([mutDictScriptData count]<=0)
		return nil ;
	
	return [mutDictScriptData objectForKey:KEY_DeviceService] ;
}

+(NSArray*)getArrayTestScriptFromScriptData
{
	if (mutDictScriptData==nil)
		return nil ;
	if ([mutDictScriptData count]<=0)
		return nil ;
	
	return [mutDictScriptData objectForKey:KEY_TestScript] ;
}

+(NSArray*)getArrayDeviceIDListFromScriptData
{
	if (mutDictScriptData==nil)
		return nil ;
	if ([mutDictScriptData count]<=0)
		return nil ;
	
	return [mutDictScriptData objectForKey:KEY_DeviceIDList] ;
}

//inner function
+(bool)fillDataToScriptData:(NSData*)receData 
{
	if (receData==nil)
		return FALSE ;
	NSMutableString *strScriptData=[[[NSMutableString alloc] initWithData:receData encoding:NSASCIIStringEncoding] autorelease];
	if (strScriptData==nil)
		return FALSE ;
	//step 1 : check whether error message 
	NSRange rangeTmp = [strScriptData rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[self setCloudErrorMsg:strScriptData] ;
		return FALSE ;
	}
	
	//clear  :-):-) 
	rangeTmp = [strScriptData rangeOfString:@":-):-)"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strScriptData deleteCharactersInRange:rangeTmp] ;
	//NSLog(@"\n strtestsct is %@ \n",strtestsct) ;
	
	
	//write to disk
	if ([strScriptData writeToFile:@"/TempScriptData.txt" atomically:NO encoding:NSASCIIStringEncoding error:nil]==FALSE)
		return FALSE ;
	
	if (mutDictScriptData)
	{
		[mutDictScriptData release] ;
		mutDictScriptData = nil     ;
	}
	mutDictScriptData = [[NSMutableDictionary alloc] initWithContentsOfFile:@"/TempScriptData.txt"] ;
    if (mutDictScriptData==nil)
		return FALSE ;
	return true ;
	
}

+(bool)fillDataToAppconfig:(NSData*)receData 
{
	if (receData==nil)
		return FALSE ;
	NSMutableString *strAppcfg=[[[NSMutableString alloc] initWithData:receData encoding:NSASCIIStringEncoding] autorelease];
	if (strAppcfg==nil)
		return FALSE ;
	//step 1 : check whether error message 
	NSRange rangeTmp = [strAppcfg rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[self setCloudErrorMsg:strAppcfg] ;
		return FALSE ;
	}
	
	//clear  :-):-) 
	rangeTmp = [strAppcfg rangeOfString:@":-):-)"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strAppcfg deleteCharactersInRange:rangeTmp] ;
	//NSLog(@"\n strtestsct is %@ \n",strtestsct) ;
	
	if (strAppConfigForSocket)
	{
		[strAppConfigForSocket setString:@""] ;
		[strAppConfigForSocket appendString:strAppcfg] ;
	}else
	{
		strAppConfigForSocket = [[NSMutableString alloc] initWithString:strAppcfg] ;
	}
	return true ;	
}

+(bool)fillDataToTestScript:(NSData*)receData
{
	if (receData==nil)
		return FALSE ;
	NSMutableString *strtestsct=[[[NSMutableString alloc] initWithData:receData encoding:NSASCIIStringEncoding] autorelease];
	if (strtestsct==nil)
		return FALSE ;
	//step 1 : check whether error message 
	NSRange rangeTmp = [strtestsct rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[self setCloudErrorMsg:strtestsct] ;
		return FALSE ;
	}
	
	//clear  :-):-) 
	rangeTmp = [strtestsct rangeOfString:@":-):-)"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strtestsct deleteCharactersInRange:rangeTmp] ;
	//NSLog(@"\n strtestsct is %@ \n",strtestsct) ;
	
	if (strTestScriptForSocket)
	{
		[strTestScriptForSocket setString:@""] ;
		[strTestScriptForSocket appendString:strtestsct] ;
	}else
	{
		strTestScriptForSocket = [[NSMutableString alloc] initWithString:strtestsct] ;
	}
	return true ;
	
}

+(bool)fillDataToStationList:(NSData*)receData 
{
	if (receData==nil)
		return FALSE ;
	NSMutableString *strstdList=[[[NSMutableString alloc] initWithData:receData encoding:NSASCIIStringEncoding] autorelease];
	if (strstdList==nil)
		return FALSE ;
	//NSLog(@"\n strstdlist is %@ \n",strstdList) ;
	//step 1 : check whether error message 
	NSRange rangeTmp = [strstdList rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[self setCloudErrorMsg:strstdList] ;
		return FALSE ;
	}
	//clear  :-):-) 
	rangeTmp = [strstdList rangeOfString:@":-):-)"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strstdList deleteCharactersInRange:rangeTmp] ;
	//NSLog(@"\n strstdlist is %@ \n",strstdList) ;
	
	NSMutableArray *mutarrayTmp = [NSArray arrayWithArray:[strstdList componentsSeparatedByString:@"||"]] ;
	mutarrayTmp = [self sortArrayWithStrObj:mutarrayTmp] ; 
	
	if (mutarrayTmp==nil)
		return FALSE ;
	
	if ([mutarrayTmp count]< 1)
		return FALSE ;
	
	if (mutArrayStationIdForSocket)
	{
		[mutArrayStationIdForSocket release] ;
		mutArrayStationIdForSocket = nil ;
	}
	mutArrayStationIdForSocket = [[NSMutableArray alloc] initWithArray:mutarrayTmp] ;
	return true ;	
}

+(bool)fillDataToVersionList:(NSData*)receData 
{
	if (receData==nil)
		return FALSE ;
	NSMutableString *strverList=[[[NSMutableString alloc] initWithData:receData encoding:NSASCIIStringEncoding] autorelease];
	//NSLog(@"\n strverlist is :%@\n",strverList) ;
	if (strverList==nil)
		return FALSE ;
	//step 1 : check whether error message 
	NSRange rangeTmp = [strverList rangeOfString:@"Error"] ;
	if (rangeTmp.location==0) //it is mean :error message 
	{
		//here add error message handle .
		[self setCloudErrorMsg:strverList] ;
		return FALSE ;
	}
	//clear .DS_Store|| and :-):-) 
	rangeTmp = [strverList rangeOfString:@".DS_Store||"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strverList deleteCharactersInRange:rangeTmp] ;

	rangeTmp = [strverList rangeOfString:@":-):-)"] ;
	if (rangeTmp.location!=NSNotFound)//it is mean :exist DS_STORE
		[strverList deleteCharactersInRange:rangeTmp] ;
	
	//NSLog(@"\n strverlist is :%@\n",strverList) ;
	
	NSMutableArray *mutarrayTmp = [NSArray arrayWithArray:[strverList componentsSeparatedByString:@"||"]] ;
	mutarrayTmp = [self sortArrayWithStrObj:mutarrayTmp] ; 
	
	if (mutarrayTmp==nil)
		return FALSE ;
	
	if ([mutarrayTmp count]< 1)
		return FALSE ;
	
	if (mutArrayScriptVerForSocket)
	{
		[mutArrayScriptVerForSocket release] ;
		mutArrayScriptVerForSocket = nil ;
	}
	mutArrayScriptVerForSocket = [[NSMutableArray alloc] initWithArray:mutarrayTmp] ;
	return true ;	
}


+(NSMutableArray*)sortArrayWithStrObj:(NSMutableArray*)array
{
	NSMutableArray* temparray=[NSMutableArray arrayWithArray:array];
	int isize=[temparray count];
	if (isize<=1)
		return array;
	
	for(int i=isize-1;i>0;i--)
	{
		for(int j=0;j<i;j++)
		{
			NSString *strTemp = nil;
			if(( [[temparray objectAtIndex:j] compare: [temparray objectAtIndex:(j+1)]])!= -1)
				//		if([[temparray objectAtIndex:j] intValue]<[[temparray objectAtIndex:(j+1)] intValue])
			{
				strTemp=[temparray objectAtIndex:j];
				[temparray replaceObjectAtIndex:j withObject:[temparray objectAtIndex:(j+1)]];
				[temparray replaceObjectAtIndex:(j+1) withObject:strTemp];
			}
			
		}
		
	}
	
	return temparray;
	
}

@end
