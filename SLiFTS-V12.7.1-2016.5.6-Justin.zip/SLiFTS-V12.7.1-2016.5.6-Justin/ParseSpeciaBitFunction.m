//
//  ParseSpeciaBitFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseSpeciaBitFunction.h"


@implementation TestItemParse(ParseSpeciaBitFunction)


/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 1               
 | CREATED: 2010.03.29                  $Modtime::  2010.03.30.17:10     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Special Parser Method
 
 PURPOSE :Check specified bit of a Hex string to see if it is 0 or 1.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.03.30   Time: 17:10
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


+(void)ParseSpeciaBit:(NSDictionary*) DictionaryPtr
{
	
	//Parser Attributes
	NSString *mBitIndex				= nil    ;
	NSString *mBitValue				= nil    ;
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BitIndex"])
		{
			mBitIndex = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BitValue"])
		{
			mBitValue = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil || mBitIndex==nil || mBitValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	NSString *mBufferValue = nil;
	BOOL	  flag		   = NO;
	NSRange   rangeHead;
	NSRange	  rangeTail;
	
	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	if (mBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
	    return  ;
	}
	
	mBufferValue		= [mBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mBufferValue		= [mBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	mBufferValue		= [mBufferValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	mBufferValue		= [mBufferValue stringByReplacingOccurrencesOfString:@" "  withString:@""];
	rangeHead			= [mBufferValue rangeOfString:@"0x"];
	rangeTail.length	= [mBufferValue length];
	if (rangeHead.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Return Sring from Diag Error!"] ;
	    return  ;
	}
	rangeHead.location	= rangeHead.location + 2;
	rangeHead.length	=rangeTail.length - rangeHead.location;
	mBufferValue		= [mBufferValue substringWithRange:rangeHead];
	
	int iBitIndex		= [mBitIndex intValue];
	int iBitValue		= [mBitValue intValue];
	int iBuffervalue	= strtol([mBufferValue UTF8String],NULL,16);
	int iMask			= 1;
	
	
	if (iBitIndex ==0)
	{
		int p=iMask&iBuffervalue;
		if (p==iBitValue)
			flag =YES;
	}
	else
	{
		iMask=1<<(iBitIndex);
		int m=iMask&iBuffervalue;
		if (iBitValue==0)
		{
			if (m==0)
				flag =YES;
		}
		else if (iBitValue==1)
		{
			if(m>0)
				flag=YES;
		}
		
	}
	
	if(flag)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
	}
	return;
}



@end
