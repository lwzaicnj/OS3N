//
//  CommManage.h
//  qt_simulator
//
//  Created by diags on 1/15/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "UartComm.h"

extern NSString* const MACOS_COMM_CONNECT_SUCCESS  ;     //obtain the device success
extern NSString* const MACOS_COMM_CONNECT_FAIL     ;     //obtain the device fail
extern NSString* const MACOS_COMM_RECV_CHAR        ;     //notification for receive data
extern NSString* const MACOS_COMM_SEND_CHAR        ;     //notification for send data ok
extern NSString* const MACOS_COMM_CONNECT_ABOUT    ;    //notification for connect about

@interface CommManage : NSObject {

	NSMutableDictionary *mdComm ;//used to manage comm .
	NSMutableDictionary *mdReceDatabuffer ; //manage all data received 
	NSMutableDictionary *mdSendDataBuffer ; //manage all data sended ;
	NSMutableDictionary *mdCurrentKeyUsed ;//it is to store last cmd's key
}
+(enum BaudRate)strBaudRateToEnum:(NSString*)strParm ;
+(enum DataBits)strDataBitToEnum:(NSString*)strParm ; 
+(enum StopBit)strStopBitToEnum:(NSString*)strParm ;
+(enum Parity)strParityToEnum:(NSString*)strParm ; 
+(enum FlowControl)strFlowControlToEnum:(NSString*)strParm ;   
  
//public function
-(bool)OpenPort:(NSString*)strDeviceID  PortName
               :(NSString*)portName     BaudRate
               :(enum BaudRate)baudRate DataBits   
               :(enum DataBits)dataBits StopBit
               :(enum StopBit)stopBit   Parity
               :(enum Parity)parity     FlowControl
               :(enum FlowControl)flowControl      KeysDefine    
			   :(NSDictionary*) dKey;

-(bool)Socket_OpenPort:(NSString*)strDeviceID IPAddress
                      :(NSString*)strIP PortID
                      :(int)iPortID     KeysDefine    
					  :(NSDictionary*) dKey;

-(bool)IsOpen:(NSString*)strDeviceID ;
-(void)ClosePort:(NSString*)strDeviceID ;
-(NSString*)getPortName:(NSString*)strDeviceID ;
-(bool)WriteData:(NSString*)strDeviceID DataBuffer
               :(NSData*)sendBuffer
			   :(NSDictionary*)dtKey  ;

-(NSData*)ReadData:(NSString*)strDeviceID ;
- (bool)CheckISCompleteDataUsingCurrKey:(NSString*)strDeviceID ; //true==complete data .flase ==not complete data
- (NSString*)CheckISCompleteDataUsingCurrKeyAndGetSN:(NSString*)strDeviceID ;


///inner function
- (void)handleNotificationHandle:(NSNotification*)notification ;
- (void)timerFireMethod:(NSTimer*)theTimer ;

- (id)GetCurrentKeyUsed:(NSString*)nsstrDeviceID :(NSString*)nsstrKey ;
- (void)SetCurrentKeyUsed:(NSString*)nsstrDeviceID :(NSString*)nsstrKey:(id)newValue;
- (bool)ISExistOnCurrKeys:(NSString*)nsstrDeviceID :(NSString*)nsstrKey ;
-(void)clearData:(NSString*)strDeviceID ;//clear old data

@end
