/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseUnitSnFunction.m $|
 | $Author:: Henry                  $Revision::  1					  $|
 | CREATED: 2011-01-20              $Modtime:: 2011-02-15			  $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseUnitSnFunction.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 2011-01-20   Time: 15:58
 * Created in 
 * first implementation
 */

#import "Pudding.h"
#import "ParseUnitSnFunction.h"
#import "UICommon.h"
#import "ConditionObj.h"
#import "testItemManage.h"


NSString *Thread1SN=@"default";
NSString *Thread2SN=@"default";
NSString *Thread3SN=@"default";

BOOL canTestFixture1=TRUE;
BOOL canTestFixture2=TRUE;
BOOL canTestFixture3=TRUE;

BOOL canDetectFixture1=TRUE;
BOOL canDetectFixture2=TRUE;
BOOL canDetectFixture3=TRUE;

extern NSInteger testResult[3];
extern NSTextField *SN1;
extern NSTextField *SN2;
extern NSTextField *SN3;

NSString *preDUTID=nil;
NSString *curDUTID=nil;

@implementation TestItemParse(ParseUnitSnFunction)

+(void)ParseUnitSn:(NSDictionary*) dictKeyDefined
{
	 NSString *mDevice=nil        ;
	 NSString *mWriteCmd=nil      ;// write cmd
	 NSString *mBufferName=nil    ;
	 
	 NSString *mTimeOut=@"60"      ;
	 NSString *mWriteCmdEnd=@"\n"  ;
	 NSString *mWhetherRead = @"yes" ;
	 
	 NSString *mPostfix =@":-)";
	 NSString *mTestItemName=nil     ;
	 
	 NSString *mReferenceBufferName=nil ;
	 NSString *mStationName =@"";
	NSString *mTestStep=nil     ;
	NSString *mPosition=nil     ;

	ConditionObj *threadConditionCheckSn=[[ConditionObj alloc] init];
	[threadConditionCheckSn initConditionObj];
	

	 
	 for(int i=0 ;i<[dictKeyDefined count] ;i++)
	 {
		 NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		 if ([strKey isEqualToString:@"Device"])
		 {
		 mDevice = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"WriteCmd"])
		 {
		 mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"BufferName"])
		 {
		 mBufferName = [dictKeyDefined objectForKey:strKey] ;
		 }		
		 else if ([strKey isEqualToString:@"TimeOut"])
		 {
		 mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"WriteCmdEnd"])
		 {
		 mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"WhetherRead"])
		 {
		 mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"Postfix"])
		 {
		 mPostfix = [dictKeyDefined objectForKey:strKey] ;
		 }else if ([strKey isEqualToString:@"TestItemName"])
		 {
		 mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		 }
		 else if ([strKey isEqualToString:@"ReferenceBufferName"])
		 {
		 mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		 }
		 else if ([strKey isEqualToString:@"StationName"])
		 {
		 mStationName = [dictKeyDefined objectForKey:strKey] ;
		 }
		 else if ([strKey isEqualToString:@"TestStep"])
		 {
			 mTestStep = [dictKeyDefined objectForKey:strKey] ;
		 }
		 else if ([strKey isEqualToString:@"Position"])
		 {
			 mPosition = [dictKeyDefined objectForKey:strKey] ;
		 }
	 }
	
	NSString *strErrorMessage1=@"Test incomplete, wrong position";
//	NSString *strErrorMessage2=@"Test incomplete, wrong unit";
	enum FAILTYPE mFailType =FAIL_NONE;
	NSString *strDutID = [dictKeyDefined objectForKey:@"DUTID"];
	

	//finish currenc position test added by henry 2011-01-27
	if([mPosition isEqualToString:@"0"])
	{
		canTestFixture1=FALSE;
		canDetectFixture1=FALSE;
		if([strDutID isEqualToString:@"1"])
		{
			//[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
			//[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar11"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			//[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
			//[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar21"] Key:@"pink" objType:@"statusBar"];
		}		
		if([strDutID isEqualToString:@"3"])
		{
			//[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar31"] indexBox:2 indexBar:0];
			//[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar31"] Key:@"pink" objType:@"statusBar"];
		}
	}
	if([mPosition isEqualToString:@"1"])
	{
		canDetectFixture1=TRUE;
		//canDetectFixture1=FALSE;
		//canDetectFixture2=TRUE;
		//henry added 2011-02-06
		NSMutableDictionary *dictKeyDefined =[[NSMutableDictionary alloc] init];
		[dictKeyDefined setObject:@"IPad11" forKey:@"UNITDevice"] ;
		[dictKeyDefined setObject:@"IPad" forKey:@"Device"] ;
		NSString *mWriteCmd = @"pattern 4\n" ; //White
		[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
		[dictKeyDefined release];

		
		if([strDutID isEqualToString:@"1"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar11"] Key:@"gray" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar21"] Key:@"gray" objType:@"statusBar"];
		}		
		if([strDutID isEqualToString:@"3"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar31"] indexBox:2 indexBar:0];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar31"] Key:@"gray" objType:@"statusBar"];
		}
	}
	else if([mPosition isEqualToString:@"2"])
	{
		canDetectFixture2=TRUE;
		//canDetectFixture2=FALSE;
		//canDetectFixture3=TRUE;
		//henry added 2011-02-06
		NSMutableDictionary *dictKeyDefined =[[NSMutableDictionary alloc] init];
		[dictKeyDefined setObject:@"UUT11" forKey:@"UNITDevice"] ;
		[dictKeyDefined setObject:@"UUT" forKey:@"Device"] ;
		NSString *mWriteCmd = @"pattern 0\n" ;
		[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
		[dictKeyDefined release];

		
		if([strDutID isEqualToString:@"1"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar12"] indexBox:0 indexBar:1];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar12"] Key:@"gray" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar22"] indexBox:1 indexBar:1];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar22"] Key:@"gray" objType:@"statusBar"];
		}		
		if([strDutID isEqualToString:@"3"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar32"] indexBox:2 indexBar:1];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar32"] Key:@"gray" objType:@"statusBar"];
		}
	}
	
	//henry added 2011-02-09
	if([mPosition isEqualToString:@"0"])
	{
		NSNotification *myRestartNotification=nil ;
		NSDictionary *unitRestartInfor = [[NSDictionary dictionaryWithObject:strDutID forKey:@"DUTID"] retain];
		
		if ([strDutID isEqualToString:@"1"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT1_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"2"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT2_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"3"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT3_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		
		[[NSNotificationCenter defaultCenter] postNotification:myRestartNotification] ;
		
		[unitRestartInfor release]; //henry added to avoid memory leakage 2011-02-22
		[myRestartNotification release];
	}
	else 
	{
		NSNotification *myNotification=nil ;
		NSDictionary *unitInfor = [[NSDictionary dictionaryWithObject:strDutID forKey:@"DUTID"] retain];
		
		if ([strDutID isEqualToString:@"1"])
		{
			myNotification = [[NSNotification notificationWithName:@"UUT1_TIMER_STOP" object:self userInfo:unitInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"2"])
		{
			myNotification = [[NSNotification notificationWithName:@"UUT2_TIMER_STOP" object:self userInfo:unitInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"3"])
		{
			myNotification = [[NSNotification notificationWithName:@"UUT3_TIMER_STOP" object:self userInfo:unitInfor] retain] ;
		}
		
		[[NSNotificationCenter defaultCenter] postNotification:myNotification] ;

		[unitInfor release]; //henry added to avoid memory leakage 2011-02-22
		[myNotification release];
}

	
	
	//henry added end 2011-01-27
	
	//step:1 check if unit is plug in and in correct position
	NSThread *threadCheckUUTExist = [[NSThread alloc] initWithTarget:threadConditionCheckSn selector:@selector(CheckUUTPlugin:) object:dictKeyDefined];
	[threadCheckUUTExist start];
	
	[[threadConditionCheckSn getConditionObj] lock];
	[[threadConditionCheckSn getConditionObj] wait];
	[[threadConditionCheckSn getConditionObj] unlock];
	[threadCheckUUTExist release];
	
	
	
	mFailType =[threadConditionCheckSn getFailType]; 
	//check whether the wrong unit in the right position
	if(mFailType ==FAIL_WRONG_POSITION) 
	{			
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:strErrorMessage1:nil:nil:nil:nil:nil:IP_NA:nil];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Wrong Position"] ;	
		return ;
	}
	
	//finish currenc position test added by henry 2011-01-27
	if([mPosition isEqualToString:@"0"])
	{
		canTestFixture1=FALSE;
		canDetectFixture1=FALSE;
		if([strDutID isEqualToString:@"1"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
			//usleep(300000);
			usleep(500000) ;  //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa11"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];	
			usleep(500000) ;  //delay 100ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa21"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"3"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar31"] indexBox:2 indexBar:0];
			usleep(500000) ;  //delay 100ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa31"] Key:@"pink" objType:@"statusBar"];
		}
	}
	if([mPosition isEqualToString:@"1"])
	{
		//canDetectFixture1=TRUE;//delete by caijunbo on 2011-02-14
		canDetectFixture2=FALSE;
		canTestFixture1=TRUE;
		canTestFixture2=FALSE;
		if([strDutID isEqualToString:@"1"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar12"] indexBox:0 indexBar:1];
			usleep(500000) ;  //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa12"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar22"] indexBox:1 indexBar:1];	
			usleep(500000) ;  //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa22"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"3"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar32"] indexBox:2 indexBar:1];
			usleep(500000) ; 
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa32"] Key:@"pink" objType:@"statusBar"];
		}
		//henry added 2011-02-13
		NSInteger iTem;
		iTem = testResult[1];
		testResult[1]=testResult[0];
		testResult[0]=iTem;
		NSTableView *aTableView1= [UICommon getObjectFromUIComm:@"tableView11"];
		NSTableView *aTableView2= [UICommon getObjectFromUIComm:@"tableView12"];
		
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		[aTableView1 reloadData];
		[aTableView1 display];
		[aTableView2 reloadData];
		[aTableView2 display];
		[pool release];
		
		NSNotification *myNotification=nil ;
		NSDictionary* unitInfor = [[NSDictionary alloc] initWithObjectsAndKeys:strDutID, @"DUTID", [NSString stringWithFormat:@"%d",testResult[0]], @"PREPOSITION",[NSString stringWithFormat:@"%d",testResult[1]], @"CURPOSITION",nil];
		myNotification = [[NSNotification notificationWithName:@"SET_UI_BOX_POSITION" object:self userInfo:unitInfor] retain] ;
		[[NSNotificationCenter defaultCenter] postNotification:myNotification] ;
		[unitInfor release];
		//henry added end 2011-02-13
		
	}
	else if([mPosition isEqualToString:@"2"])
	{
		//canDetectFixture2=TRUE;//delete by caijunbo on 2011-02-14
		canDetectFixture3=FALSE;
		canTestFixture2=TRUE;
		canTestFixture3=FALSE;
		if([strDutID isEqualToString:@"1"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:0 indexBar:2];
			usleep(500000) ; //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa13"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"2"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar23"] indexBox:1 indexBar:2];	
			usleep(500000) ; //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa23"] Key:@"pink" objType:@"statusBar"];
		}
		if([strDutID isEqualToString:@"3"])
		{
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar33"] indexBox:2 indexBar:2];
			usleep(500000) ;  //delay 300ms
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBa33"] Key:@"pink" objType:@"statusBar"];
		}
		//henry added 2011-02-13
		
		curDUTID = strDutID;
		if(nil== preDUTID)
			preDUTID =strDutID;
		if(curDUTID!=preDUTID)
		{
			[TestItemManage cleanThread:preDUTID];
			preDUTID=curDUTID;
		}
		
		NSInteger iTem;
		iTem = testResult[2];
		testResult[2]=testResult[1];
		testResult[1]=iTem;
		
		NSTableView *aTableView2= [UICommon getObjectFromUIComm:@"tableView12"];
		NSTableView *aTableView3= [UICommon getObjectFromUIComm:@"tableView13"];
				
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		[aTableView2 reloadData];
		[aTableView2 display];
		[aTableView3 reloadData];
		[aTableView3 display];
		[pool release];

		NSNotification *myNotification=nil ;
		NSDictionary* unitInfor = [[NSDictionary alloc] initWithObjectsAndKeys:strDutID, @"DUTID", [NSString stringWithFormat:@"%d",testResult[1]], @"PREPOSITION",[NSString stringWithFormat:@"%d",testResult[2]], @"CURPOSITION",nil];
		myNotification = [[NSNotification notificationWithName:@"SET_UI_BOX_POSITION" object:self userInfo:unitInfor] retain] ;
		[[NSNotificationCenter defaultCenter] postNotification:myNotification] ;
		[unitInfor release];
		//henry added end 2011-02-13
		
	}
	//henry added end 2011-01-27
	
	[threadConditionCheckSn deallocConditionObj];
	[threadConditionCheckSn release];
	
	if(![mPosition isEqualToString:@"0"])
	{
		NSNotification *myRestartNotification=nil ;
		NSDictionary *unitRestartInfor = [[NSDictionary dictionaryWithObject:strDutID forKey:@"DUTID"] retain];
		
		if ([strDutID isEqualToString:@"1"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT1_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"2"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT2_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		else if ([strDutID isEqualToString:@"3"])
		{
			myRestartNotification = [[NSNotification notificationWithName:@"UUT3_TIMER_RESTART" object:self userInfo:unitRestartInfor] retain] ;
		}
		
		[[NSNotificationCenter defaultCenter] postNotification:myRestartNotification] ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;

}

+(void)ParseShowUnitSN:(NSDictionary*)dictKeyDefined 
{
	
	NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
	
	NSString *strDutID = [dictKeyDefined objectForKey:@"DUTID"];
	
	if(strSN ==nil)
		return;
	if(strDutID ==nil)
		return;
	
	//post a notification to show Unit SN on UI  .
	NSNotification *myNotification=nil ;
	NSDictionary *unitInfor = [[NSDictionary dictionaryWithObject:strSN forKey:@"UnitSN"] retain];
	
	if ([strDutID isEqualToString:@"1"])
	{
		myNotification = [[NSNotification notificationWithName:@"SHOW_UNIT_SN1" object:self userInfo:unitInfor] retain] ;
	}
	else if ([strDutID isEqualToString:@"2"])
	{
		myNotification = [[NSNotification notificationWithName:@"SHOW_UNIT_SN2" object:self userInfo:unitInfor] retain] ;
	}
	else if ([strDutID isEqualToString:@"3"])
	{
		myNotification = [[NSNotification notificationWithName:@"SHOW_UNIT_SN3" object:self userInfo:unitInfor] retain] ;
	}
	else if ([strDutID isEqualToString:@"4"])
	{
		myNotification = [[NSNotification notificationWithName:@"SHOW_UNIT_SN4" object:self userInfo:unitInfor] retain] ;
	}
	
	[[NSNotificationCenter defaultCenter] postNotification:myNotification] ;

	[unitInfor release];  //henry added to avoid memory leakage 2011-02-22
	[myNotification release];
	
}

@end
