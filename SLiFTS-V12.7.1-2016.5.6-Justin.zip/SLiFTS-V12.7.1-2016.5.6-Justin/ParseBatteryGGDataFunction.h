//
//  ParseBatteryGGDataFunction.h
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseBatteryGGDataFunction)

+(void)ParseBatteryGGData:(NSDictionary*) DictionaryPtr;

+(void)ParseBatteryGGDataV2:(NSDictionary*) DictionaryPtr ;

//Henry Add 20120218
+(void)ParsePMUStateFault:(NSDictionary*) DictionaryPtr;
//End 20120218
@end