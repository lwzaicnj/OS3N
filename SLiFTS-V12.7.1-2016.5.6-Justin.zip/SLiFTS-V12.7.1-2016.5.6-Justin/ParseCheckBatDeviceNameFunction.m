//
//  ProxIQCParse.m
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ParseCheckBatDeviceNameFunction.h"


@implementation TestItemParse(ParseCheckBatDeviceNameFunction)

+(void)ParseCheckBatDeviceName:(NSDictionary*)dictKeyDefined
{
	
	NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
	
	//key parse
	NSString *mTestItemName=nil;
	NSString *mStrSpec_00=nil;
	NSString *mStrSpec_01=nil;
	NSString *mStrSpec1=nil;
	NSString *mStrSpec2=nil;
	NSString *mStrSpec3=nil;
	NSString *mStrSpec4=nil;
	NSString *mStrSpec5=nil;
	NSString *mStrSpec6=nil;
	NSString *mStrSpec7=nil;
	NSString *mReferenceBufferName=nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec_00"])
		{
			//mLowValue = [dictKeyDefined objectForKey:strKey] ;
			//mIntLowValue = [mLowValue integerValue];
			mStrSpec_00 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec_01"])
		{
			mStrSpec_01 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec1"])
		{
			mStrSpec1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec2"])
		{
			mStrSpec2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec3"])
		{
			mStrSpec3 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec4"])
		{
			mStrSpec4 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec5"])
		{
			mStrSpec5 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec6"])
		{
			mStrSpec6 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec7"])
		{
			mStrSpec7 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	NSString *buffervalue_batDeviceName1  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName1"] ;
	NSString *buffervalue_batDeviceName2  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName2"] ;
	NSString *buffervalue_batDeviceName3  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName3"] ;
	NSString *buffervalue_batDeviceName4  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName4"] ;
	NSString *buffervalue_batDeviceName5  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName5"] ;
	NSString *buffervalue_batDeviceName6  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName6"] ;
	NSString *buffervalue_batDeviceName7  = [TestItemManage getBufferValue:dictKeyDefined :@"buffervalue_batDeviceName7"] ;
	 
	/*
	mReferenceBufferValue =  @"hjjhkjhjshjkfhsj 0x01 0x02 0x03 0x04 0x05 0x06 0x07 0x08 0x09 0x35 0x4D 0x51 0x46 0x4A 0x59 jkjkjdjgijgp";
	
	NSString *buffervalue_batDeviceName1  =  @"0x71 :-)";
	NSString *buffervalue_batDeviceName2  =  @"0x3q :-)";
	NSString *buffervalue_batDeviceName3  =  @"0x37 :-)";
	NSString *buffervalue_batDeviceName4  =  @"0x35 :-)";
	NSString *buffervalue_batDeviceName5  =  @"0x34:-)";
	NSString *buffervalue_batDeviceName6  =  @"0x31:-)";
	NSString *buffervalue_batDeviceName7  =  @"0x42:-)";
	*/
	
	bool flagName00 = false;
	bool flagName01 = false;
	bool flag1 = false;
	bool flag2 = false;
	bool flag3 = false;
	bool flag4 = false;
	bool flag5 = false;
	bool flag6 = false;
	bool flag7 = false;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSRange rangeTmp00=[mReferenceBufferValue rangeOfString:mStrSpec_00];
	NSRange rangeTmp01=[mReferenceBufferValue rangeOfString:mStrSpec_01];
	
	if (rangeTmp00.length > 0)  //has find Special str
		flagName00 = true;
	if (rangeTmp01.length > 0)  //has find Special str
		flagName01 = true;

	if(flagName00)
	{
		//still need to jude the special str is the tenth hex value
		NSString *tmpStr = [mReferenceBufferValue substringToIndex:rangeTmp00.location];
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
//		NSMutableArray * mutArrayTemp = [tmpStr componentsSeparatedByString:@"0x"];
		NSArray * mutArrayTemp = [tmpStr componentsSeparatedByString:@"0x"];
		//end
		if([mutArrayTemp count] == 10)
			flagName00 = true;
		else
			flagName00 = false;
	}
	if(flagName01)
	{
		//still need to jude the special str is the tenth hex value
		NSString *tmpStr = [mReferenceBufferValue substringToIndex:rangeTmp01.location];
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
//		NSMutableArray * mutArrayTemp = [tmpStr componentsSeparatedByString:@"0x"];
		NSArray * mutArrayTemp = [tmpStr componentsSeparatedByString:@"0x"];
		//end
		if([mutArrayTemp count] == 10)
			flagName01 = true;
		else
			flagName01 = false;
	}



	if(flagName00 || flagName01)
	{
		NSRange rangeTmp1=[buffervalue_batDeviceName1 rangeOfString:mStrSpec1] ;
		NSRange rangeTmp2=[buffervalue_batDeviceName2 rangeOfString:mStrSpec2] ;
		NSRange rangeTmp3=[buffervalue_batDeviceName3 rangeOfString:mStrSpec3] ;
		NSRange rangeTmp4=[buffervalue_batDeviceName4 rangeOfString:mStrSpec4] ;
		NSRange rangeTmp5=[buffervalue_batDeviceName5 rangeOfString:mStrSpec5] ;
		NSRange rangeTmp6=[buffervalue_batDeviceName6 rangeOfString:mStrSpec6] ;
		NSRange rangeTmp7=[buffervalue_batDeviceName7 rangeOfString:mStrSpec7] ;
		if (rangeTmp1.length > 0)
			flag1 = true;
		if (rangeTmp2.length > 0)
			flag2 = true;
		if (rangeTmp3.length > 0)
			flag3 = true;
		if (rangeTmp4.length > 0)
			flag4 = true;
		if (rangeTmp5.length > 0)
			flag5 = true;
		if (rangeTmp6.length > 0)
			flag6 = true;
		if (rangeTmp7.length > 0)
			flag7 = true;

		if(flag1 && flag2 && flag3 && flag4 && flag5 && flag6 && flag7)
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = @"Pass" ;
		}
		else
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = mReferenceBufferValue ;
		}
	}
	else
	{
		//judge the unit return information is Strang str or not
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
//		NSMutableArray * mutArrayTemp = [mReferenceBufferValue componentsSeparatedByString:@"0x"];
		NSArray * mutArrayTemp = [mReferenceBufferValue componentsSeparatedByString:@"0x"];
		//end
		if([mutArrayTemp count] < 11)
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = mReferenceBufferValue ;
		}
		else
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = @"Pass" ;
		}
	}

	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

@end

