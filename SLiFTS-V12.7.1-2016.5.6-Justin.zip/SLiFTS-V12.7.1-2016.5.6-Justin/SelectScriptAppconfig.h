
/*
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SelectScriptAppconfig.h	    $|
 | $Author:: Henry                  $Revision::  1							$|
 | CREATED: 20 Oct. 2010            $Modtime:: 26 Oct. 2010 15:24			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History: UICommon.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 20 Oct. 2010   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
/*
enum Init_Fail_Status {
	Fail_Connect_Net	= 0,
	Fail_Get_APPConfig	= 1,
	Fail_Get_TestScript ,
} ;

enum STATION_ID {
	QT0                   = 0X01 ,
	QT0b                  = 0x02 ,
	Connectivity1         = 0x03 ,
	ALS                   = 0X04 ,
	QT1                   = 0X05 ,
	HomeButtonGrape		  = 0x06 ,
	DisplayTest           = 0x07 ,
	ProxCal1              = 0x08 ,
	ProxCal2              = 0x09 ,
	ProxCal3              = 0x0a ,
	Gatekeeper            = 0x0b ,
};

 
enum COMMAND_ID {
	Sumary               = 0x01 ,
	LogService           = 0x02 ,
	DeviceService        = 0x03 ,
	DeviceIDList         = 0x04 ,
	TestScript           = 0x05 ,
};
*/

enum Script {
	Sumary               = 0x01 ,
	LogService           = 0x02 ,
	DeviceService        = 0x03 ,
	DeviceIDList         = 0x04 ,
	TestScript           = 0x05 ,
};

@interface SelectScriptAppconfig : NSObject {
	
	//add by Giga
	BOOL isChangeTableViewItem ;
	NSString *strIP ;
	NSString *strPort ;
	int iTimeOut ;
	
	IBOutlet NSScrollView * testscript ;
	IBOutlet NSButton * btnLoadScript ;
	IBOutlet NSButton * btnLoadAppConfig ;
	IBOutlet NSButton * btnEnter;
	IBOutlet NSTabView * tabview ;
	IBOutlet NSProgressIndicator * indicator ;
	IBOutlet NSBox * boxSelect;
	IBOutlet NSComboBox * comboStationL;
	IBOutlet NSComboBox * comboVersionL;
	IBOutlet NSTextField * txtUsrName;
	IBOutlet NSTextField * txtPassword;
	
	NSMutableArray *mutArrayStation ;
	NSMutableArray *mutArrayVer;
}

-(NSString*)getCurrStationID;
-(NSString*)getCurrStationName;
-(NSString*)getCurrVersion;
-(void)versionInforUpdate ;
-(void)lockUIComponent ;
-(void)unLockUIComponent ;
/* check netstatus, load appconfig , load test script,then  enter test UI 
 */
-(IBAction)btnEnter_Click:(id)sender;

/* buttons for load appconfig and test script , all the scripts are something like text .
 * So we can easily read and edit the script . Also when we finish editing ,we can save them to server .
 */
-(IBAction)btnLoadAppconfig_Click:(id)sender;
-(IBAction)btnLoadScript_Click:(id)sender;
-(IBAction)btnSave_Click:(id)sender;
-(IBAction)btnExitEdit_Click:(id)sender;
-(void)comboBoxSelectionDidChange:(NSNotification *)notification;

/* Alert panel for hint where occur error
 */
-(void)show_Fail_Panel:(NSString*)strError ;

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication ; 
-(BOOL)windowShouldClose:(id)window;

@end
