//
//  GetTestTimeFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "GetTestTimeFunction.h"


@implementation TestItemParse(GetTestTimeFunction)



/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 1               
 | CREATED: 2010.03.25                  $Modtime::  17:00    
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Special Parser Method
 
 PURPOSE :Get system time and write it to unit.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.03.25   Time: 17:00
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


+(void)GetTestTime:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mDevice			= nil    ;
	NSString *mWriteCmd			= nil    ;
	NSString *mBufferName		= nil    ;
	NSString *mPDCAWrite		= @"no"  ;
    NSString *mTimeOut			= @"6"   ;
	NSString *mWriteCmdEnd		= @"\n"	 ;
	//NSString *mPostfix			= @"-:)" ;
	NSString *mPostfix			= @":-)" ; // modify by Evan;
	NSString *mTestItemName		= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [DictionaryPtr objectForKey:strKey] ;
			mDevice = [TestItemParse getDeviceID:mDevice :DictionaryPtr] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	if (mDevice==nil || mWriteCmd==nil ||mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	NSRange  range;
	NSDate   *currentDate		= nil;
	NSString *strTemp			= nil;
	NSString *strCurrentTime	= nil;
	
	
	range = [mWriteCmd rangeOfString:@"[currentTime]"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script error"] ;
		return;
	}
	
	currentDate		= [NSDate date];
	strCurrentTime	= [currentDate description];
	
	/*SCRID-114: Change writing date and time from local time to zero zone time(GMT). joko 2011-07-19*/
	NSString *timeZone = [strCurrentTime substringFromIndex:20];
	timeZone = [timeZone substringToIndex:3];
	double intervalOfCurrenTimeToZeroZoneTime = [timeZone doubleValue] * 60 * 60 * -1;
	NSDate   *zeroZoneDate = [NSDate dateWithTimeIntervalSinceNow:intervalOfCurrenTimeToZeroZoneTime];
	strCurrentTime = [zeroZoneDate description];
	/*SCRID-114: end*/
	
	strCurrentTime	= [ToolFun deleteFromString:strCurrentTime trimStr:@"+"] ;
	strCurrentTime	= [ToolFun deleteFromString:strCurrentTime trimStr:@"-"] ;
	strCurrentTime	= [ToolFun deleteFromString:strCurrentTime trimStr:@":"] ;
	strCurrentTime	= [ToolFun deleteFromString:strCurrentTime trimStr:@" "] ;
	strCurrentTime	= [strCurrentTime substringToIndex:(NSUInteger)14];
	strTemp			= [mWriteCmd stringByReplacingCharactersInRange:range withString:strCurrentTime];
	
		
	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:strTemp] ;
	if (mWriteCmdEnd!=nil)
		[strMutSendBuffer appendString:mWriteCmdEnd] ;
	
	bool bTmp = [self SendData:DictionaryPtr :strMutSendBuffer :mPostfix] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Write Date and Time fail "] ;
		return ;
	}
	
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:DictionaryPtr]) 
				break ;
			else
				usleep(500000) ; //delay 500
		}
		//read data
		NSString *dataResult = [self ReceData:DictionaryPtr] ;
		if (dataResult!=nil )
		{
			[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
		}
		
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;	
		
	return ;	
}


@end
