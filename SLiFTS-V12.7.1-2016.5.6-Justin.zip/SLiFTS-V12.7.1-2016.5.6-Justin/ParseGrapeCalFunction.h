//
//  ParseGrapeCalFunction.h
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseGrapeCalFunction)

+(void)ParseGrapeCal:(NSDictionary*) DictionaryPtr;
//SCRID-152: Add parse to resove LCD Align and V8 stations CB clean issue in checkin and checkout.Judith.2011-12-19.
+(void)ParseGrapeLCD:(NSDictionary*) DictionaryPtr;
//SCRID-152:end

@end