//
//  ALS_Sequencer_API.h
//  als_frame
//
//  Created by Pete Panagas on 9/15/10.
//  Copyright 2010 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "als_defs.h"

@interface ALS_Sequencer_API : NSObject 
{
}

-(ALS_ERR) Initialize;

-(ALS_ERR) LastError;

-(ALS_ERR) ALS_RunSOP:(NSString*) path;

-(ALS_ERR) ALS_RunCal:(NSString*) path;

-(ALS_ERR) ALS_Abort;

// Test functions LED controller

-(ALS_ERR) TestLED:(NSString *) address Power:(NSString *) power;

-(ALS_ERR) PrintEEpromTest:(NSString *) address Result:(unsigned char *) data;

-(ALS_ERR) WriteEEpromTest:(NSString *) address Data:(NSString *) data;

-(ALS_ERR) ReadFixtureSNTest:(unsigned short *)serial_number;

-(void) CycleLEDTest;


// Test functions LuxMeter

-(void) InitLuxMeterTest;

-(void) SampleLuxMeterTest:(float *) lux;

// Test functions DUT

-(void) DUTDiagsVersionTest;

-(void) SampleDUTTest:(float *) clear IR:(float *) ir;

@end
