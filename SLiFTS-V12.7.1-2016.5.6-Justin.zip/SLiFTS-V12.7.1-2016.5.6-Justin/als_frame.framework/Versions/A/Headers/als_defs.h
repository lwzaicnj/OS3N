/*
 *  als_defs.h
 *  als_frame
 *
 *  Created by Pete Panagas on 9/14/10.
 *  Copyright 2010 Apple. All rights reserved.
 *
 */

static const float als_frame_ver = 1.10;

typedef enum
{
	ALS_ERR_SUCCESS = 0,
	ALS_ERR_FAIL,
	ALS_ERR_ABORTED,
	ALS_ERR_SERIAL_DEVICE_NOT_FOUND,
	ALS_ERR_LUXMETER_NOT_PRESENT,
	ALS_ERR_CAL_TIMEOUT,
	ALS_ERR_EEPROM_COMM_FAIL,
	ALS_ERR_LED_FAIL,
	ALS_ERR_DUT_COMM_FAIL,
	ALS_ERR_LUXMETER_COMM_FAIL,
	ALS_ERR_DUT_DATA_NOISY,
	ALS_ERR_CAL_VALIDATION,
	ALS_ERR_NUM_TYPES
	
} ALS_ERR;


static const NSString *alsErrStrings[ALS_ERR_NUM_TYPES] =
{
	@"ALS Success",
    @"ALS Failure",
	@"ALS Sequence Aborted",
	@"ALS Serial device not found",
	@"ALS Lux meter not present",
	@"ALS Calibration step timed out",
	@"ALS EEPROM communication fail",
	@"ALS LED driver fail",
	@"ALS DUT communication fail",
	@"ALS Lux meter communication fail",
	@"ALS DUT data noisy",
	@"ALS Fixture calibration verify failed"

};

// Use this notification channel to catch asyncronous sequence completions
static const NSString *alsNotifyName = @"SequenceComplete";
static const NSString *alsNotifyObject = @"Sequence Complete";

