//
//  CheckTimeAndDateFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "CheckTimeAndDateFunction.h"


@implementation TestItemParse(CheckTimeAndDateFunction)

+(void)CheckTimeAndDate:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mPrefix				= nil    ;
	NSString *mPostfix				= nil    ;
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	NSString *mTimeDifferUpLimit	= nil	 ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeDifferUpLimit"])
		{
			mTimeDifferUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil || mTimeDifferUpLimit==nil ||mPrefix==nil ||mPostfix==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSDate *dateFromUnit	= nil;
	NSDate *dateFromMac		= nil;
	dateFromMac				= [NSDate date];
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	//NSString *mReferenceBufferValue =@"rtc --read20100403124532:-)";
	if (mReferenceBufferValue==nil )
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive Data"] ;
	    return  ;
	}
	
	NSString *strDateFromUnit	= nil;
	strDateFromUnit				= [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix];
	if (strDateFromUnit==nil )
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Receive Data Error!"] ;
	    return  ;
	}
	
	strDateFromUnit	= [strDateFromUnit stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	strDateFromUnit	= [strDateFromUnit stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	strDateFromUnit	= [strDateFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	NSString *strOffset		= nil;
	NSRange range;
	NSString *strDateFromMac= nil;
	strDateFromMac			= [dateFromMac description];
	 
	range					= [strDateFromMac rangeOfString:@"+"];
	if (range.length <= 0)
	{
		range	= [strDateFromMac rangeOfString:@"-"];
		if (range.length <= 0)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Time from local Mac Error!"] ;
			return  ;
		}
	}
		strOffset		= [strDateFromMac substringFromIndex:(NSUInteger)range.location];
		strDateFromUnit	= [ToolFun getInternationalStr:strDateFromUnit offset:strOffset];
	
	if (strDateFromUnit==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Time format translate Error!"] ;
	    return  ;
	
	}
		dateFromUnit	= [NSDate dateWithString:strDateFromUnit];
	
	NSTimeInterval timeInterval = 10000;
	timeInterval = [dateFromUnit timeIntervalSinceDate:dateFromMac];
	//translate mTimeDifferUplimit time format from minute to second.
	int iTimeDifferUpLimit	= [mTimeDifferUpLimit intValue]*60;
	
	if (timeInterval < 0)
		timeInterval = timeInterval * (-1);
	
	if (timeInterval < iTimeDifferUpLimit)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
	}
	return;

}


@end
