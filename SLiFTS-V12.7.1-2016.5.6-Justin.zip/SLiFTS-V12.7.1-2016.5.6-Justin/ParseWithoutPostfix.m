
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ProxIQCParse.h  $|
 | $Author:: Dengshouxiu                 $Revision::  1              $|
 | CREATED: 2010-03-24                   $Modtime:: 2.03.00 15:24    $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 $History:: ProxIQCParse.h                                              $
 * *****************  Version 1  *****************
 * User: Dengshouxiu          Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import "ParseWithoutPostfix.h"
#import "toolFun.h"
#import "Pudding.h"

/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
static char tempbuf[256];
char *dectobin(int dec, int len)
{
	int i = 0;
	char buf[256];
	memset(buf, 0, 256);
	memset(buf, 48, len);
	while (dec != 0)
	{
		buf[i] = dec % 2+48;
		dec = dec / 2;
		i++;
	}
	int j=7;
	i=0;
	tempbuf[256];
	memset(tempbuf,0, 256);
	memset(tempbuf,48, len);
	for(i;i<8;i++)
	{
		tempbuf[i]=buf[j];
		j--;
		
	}
	return tempbuf;
	
}
/*SCRID-104: end*/

@implementation TestItemParse(ParseWithoutPostfix)

+(void)ParseWithoutPostfix:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	//NSString *Value=[ToolFun getStrFromLen:mReferenceBufferValue length:[mReferenceBufferValue length]-[mPrefix length] Option:FALSE];
	
	NSString *Value=[mReferenceBufferValue substringFromIndex:[mPrefix length]];
	
	if (Value==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Value] ;
		return;

	}
	
}
	
	
/*SCRID-99: add parser "ParseAvrageBetweenPrefixAndPostfix" and "ParseMiddleAvrageBetweenPrefixAndPostfix". joko 2011-04-23*/
+(void)ParseAvrageBetweenPrefixAndPostfix:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mPartSeparateStr=nil ;
	NSString *mNumber=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	
	NSString *mPrefix1=nil ;
	NSString *mPrefix2=nil ;
	NSString *mPrefix3=nil ;
	NSString *mPrefix4=nil ;
	NSString *mPrefix5=nil ;
	NSString *mPrefix6=nil ;
	NSString *mPrefix7=nil ;
	NSString *mPrefix8=nil ;
	NSString *mPrefix9=nil ;
	NSString *mPrefix10=nil ;
	
	NSString *mPostfix1=nil ;
	NSString *mPostfix2=nil ;
	NSString *mPostfix3=nil ;
	NSString *mPostfix4=nil ;
	NSString *mPostfix5=nil ;
	NSString *mPostfix6=nil ;
	NSString *mPostfix7=nil ;
	NSString *mPostfix8=nil ;
	NSString *mPostfix9=nil ;
	NSString *mPostfix10=nil ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PartSeparateStr"])
		{
			mPartSeparateStr = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Number"])
		{
			mNumber = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix1"])
			mPrefix1 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix2"])
			mPrefix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix3"])
			mPrefix3 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix4"])
			mPrefix4 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix5"])
			mPrefix5 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix6"])
			mPrefix6 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix7"])
			mPrefix7 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix8"])
			mPrefix8 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix9"])
			mPrefix9 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix10"])
			mPrefix10 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix1"])
			mPostfix1 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix2"])
			mPostfix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix3"])
			mPostfix3 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix4"])
			mPostfix4 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix5"])
			mPostfix5 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix6"])
			mPostfix6 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix7"])
			mPostfix7 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix8"])
			mPostfix8 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix9"])
			mPostfix9 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix10"])
			mPostfix10 = [dictKeyDefined objectForKey:strKey];
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	if((mPartSeparateStr != nil) && ([mPartSeparateStr length] > 0))
	{
		if([mReferenceBufferValue rangeOfString:mPartSeparateStr].length <= 0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not find the Part Separate String"] ;
			return  ;
		}
		int startIndex = [mReferenceBufferValue rangeOfString:mPartSeparateStr].location ;
		mReferenceBufferValue = [mReferenceBufferValue substringFromIndex:startIndex];
		if (mReferenceBufferValue==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no parse data"] ;
			return ;
		}
	}
	
	NSString *bufferValue1 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix1 Postfix:mPostfix1] ;
	NSString *bufferValue2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix2 Postfix:mPostfix2] ;
	NSString *bufferValue3 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix3 Postfix:mPostfix3] ;
	NSString *bufferValue4 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix4 Postfix:mPostfix4] ;
	NSString *bufferValue5 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix5 Postfix:mPostfix5] ;
	NSString *bufferValue6 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix6 Postfix:mPostfix6] ;
	NSString *bufferValue7 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix7 Postfix:mPostfix7] ;
	NSString *bufferValue8 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix8 Postfix:mPostfix8] ;
	NSString *bufferValue9 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix9 Postfix:mPostfix9] ;
	NSString *bufferValue10 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix10 Postfix:mPostfix10] ;
	
	if(bufferValue1 == nil)
		bufferValue1 = @"0";
	if(bufferValue2 == nil)
		bufferValue2 = @"0";
	if(bufferValue3 == nil)
		bufferValue3 = @"0";
	if(bufferValue4 == nil)
		bufferValue4 = @"0";
	if(bufferValue5 == nil)
		bufferValue5 = @"0";
	if(bufferValue6 == nil)
		bufferValue6 = @"0";
	if(bufferValue7 == nil)
		bufferValue7 = @"0";
	if(bufferValue8 == nil)
		bufferValue8 = @"0";
	if(bufferValue9 == nil)
		bufferValue9 = @"0";
	if(bufferValue10 == nil)
		bufferValue10 = @"0";
	
	double totalValue = ([bufferValue1 doubleValue] + [bufferValue2 doubleValue] + [bufferValue3 doubleValue] + [bufferValue4 doubleValue] + [bufferValue5 doubleValue] 
						 + [bufferValue6 doubleValue] + [bufferValue7 doubleValue] + [bufferValue8 doubleValue] + [bufferValue9 doubleValue] + [bufferValue10 doubleValue]);
	
	if([mNumber intValue] < 1)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Number value < 1"] ;
		return  ;
	}
	
	double averageValue = totalValue/[mNumber intValue];
	
	if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(averageValue>=[mLowerValue doubleValue]))
	   && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(averageValue<=[mUpperValue doubleValue])))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",averageValue]] ;
	}else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",averageValue]] ;
	}
	
}

+(void)ParseMiddleAvrageBetweenPrefixAndPostfix:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mPartSeparateStr=nil ;
	NSString *mNumber=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	
	NSString *mPrefix=nil ;
	
	NSString *mPostfix=nil ;
	
	NSString *mBufferName=nil;
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PartSeparateStr"])
		{
			mPartSeparateStr = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Number"])
		{
			mNumber = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"BufferName"])
		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	//mReferenceBufferValue = @"OK 4105 mV ** Baseline Begin **	Control status:0x6009 DLOG 2, 2 mA DLOG 1, 1 mA OK ** Baseline End **  OK";
	
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	
	
	if(bufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get string between prefix and posfix"] ;
		return;
	}
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSMutableArray *dlogArray = (NSMutableArray*)[bufferValue componentsSeparatedByString:@"LOG"];
	
	double totalValue = 0;
	double averageValue = 0;
	
	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	if([dlogArray count] ==12)
	{
		for(int i=1; i<12; i++)
		{
			NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
			strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
			double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
			totalValue = totalValue + doubleCurrentArrayObject;
		}
		averageValue = totalValue/11;
		
	}
	/*SCRID-104: end*/
	else
	{
		if([dlogArray count] > 7)
		{
			for(int i=3; i<([dlogArray count]-2); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-5);
		}
		else if([dlogArray count] == 7)
		{
			for(int i=3; i<([dlogArray count]-1); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-4);
		}
		else if ([dlogArray count] == 6)
		{
			for(int i=3; i<([dlogArray count]-1); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-4);
		}
		
		/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
		/*SCRID-110: Modify the code which change in EVT by Kenshin 2011-06-01 */
		else if([dlogArray count] == 5)
		{
			for(int i=2; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-2);
		}
		
		else if([dlogArray count] == 4)
		{
			for(int i=1; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-1);
		}
		
		else if([dlogArray count] == 3)
		{
			for(int i=1; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-1);
		}
		else if([dlogArray count] <= 2) 
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"the DLOG value number are less than 2"] ;
			return;
		}
	}	
	/*SCRID-110: Modify the code which change in EVT by Kenshin 2011-06-01 */
	
	if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",averageValue]] ;
	}
	/*SCRID-104: end*/
	
	if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(averageValue>=[mLowerValue doubleValue]))
	   && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(averageValue<=[mUpperValue doubleValue])))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%0.3f",averageValue]] ;
	}else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%0.3f",averageValue]] ;
	}
	
}
/*SCRID-99:end*/	

/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/

/*SCRID-121: Add middle avrage between prefix and postfix with spec parse. 2011-08-01, Tony*/
+(void)ParseMiddleAvrageBetweenPrefixAndPostfixWithSpec:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mPartSeparateStr=nil ;
	NSString *mNumber=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	
	NSString *mPrefix=nil ;
	
	NSString *mPostfix=nil ;
	
	NSString *mBufferName=nil;
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PartSeparateStr"])
		{
			mPartSeparateStr = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Number"])
		{
			mNumber = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"BufferName"])
		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	//mReferenceBufferValue = @"OK 4105 mV ** Baseline Begin **	Control status:0x6009 DLOG 2, 2 mA DLOG 1, 1 mA OK ** Baseline End **  OK";
	
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	
	
	if(bufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get string between prefix and posfix"] ;
		return;
	}
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSMutableArray *dlogArray = (NSMutableArray*)[bufferValue componentsSeparatedByString:@"DLOG"];
	
	double totalValue = 0;
	double averageValue = 0;
	
	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	if([dlogArray count] ==12)
	{
		for(int i=1; i<12; i++)
		{
			NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
			strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
			double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
			totalValue = totalValue + doubleCurrentArrayObject;
		}
		averageValue = totalValue/11;
		
	}
	/*SCRID-104: end*/
	else
	{
		if([dlogArray count] > 7)
		{
			for(int i=3; i<([dlogArray count]-2); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-5);
		}
		else if([dlogArray count] == 7)
		{
			for(int i=3; i<([dlogArray count]-1); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-4);
		}
		else if ([dlogArray count] == 6)
		{
			for(int i=3; i<([dlogArray count]-1); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-4);
		}
		
		/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
		/*SCRID-110: Modify the code which change in EVT by Kenshin 2011-06-01 */
		else if([dlogArray count] == 5)
		{
			for(int i=2; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-2);
		}
		
		else if([dlogArray count] == 4)
		{
			for(int i=1; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-1);
		}
		
		else if([dlogArray count] == 3)
		{
			for(int i=1; i<([dlogArray count]); i++)
			{
				NSString *strCurrentArrayObject = [dlogArray objectAtIndex:i];
				strCurrentArrayObject = [ToolFun getStrFromPrefixAndPostfix:strCurrentArrayObject Prefix:@"," Postfix:@"mA"] ;
				double doubleCurrentArrayObject = [strCurrentArrayObject doubleValue];
				totalValue = totalValue + doubleCurrentArrayObject;
			}
			averageValue = totalValue/([dlogArray count]-1);
		}
		else if([dlogArray count] <= 2) 
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"the DLOG value number are less than 2"] ;
			return;
		}
	}	
	/*SCRID-110: Modify the code which change in EVT by Kenshin 2011-06-01 */
	
	if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",averageValue]] ;
	}
	/*SCRID-104: end*/
	
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:nil:nil:mLowerValue:mUpperValue:[NSString stringWithFormat:@"%.2f",averageValue]:@"watts":IP_NA:nil];
	
	if(averageValue >= [mLowerValue floatValue] && averageValue <= [mUpperValue floatValue])
	{
		enumResult = RESULT_FOR_PASS;
		strTestResultForUIinfo = [NSString stringWithFormat:@"%.2f",averageValue];
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		strTestResultForUIinfo = [NSString stringWithFormat:@"%.2f",averageValue];
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	
	/*
	 if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(averageValue>=[mLowerValue doubleValue]))
	 && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(averageValue<=[mUpperValue doubleValue])))
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",averageValue]] ;
	 }else 
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",averageValue]] ;
	 }
	 */
}
/*SCRID-121:end*/	

/*SCRID-120: Add calculate power with spec parse. 2011-07-29, Tony*/
+(void)CalculatePowerWithSpec:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName1=nil ;
	NSString *mReferenceBufferName2=nil ;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	NSString *mBufferName=nil;
	
	//NSString *strTestResultForUIinfo ;
	//enum TestResutStatus enumResult ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 =[dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 =[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if ((mReferenceBufferName1==nil)||(mReferenceBufferName2==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
	NSString* mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
	if ((mReferenceBufferValue1==nil)||(mReferenceBufferValue2==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"] ;
		return ;
	}
	if([mReferenceBufferValue2 isEqualToString:@"needn't test"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"BYPASS"] ;
		return ;
        
    }
	float fPower=0;
	fPower=([mReferenceBufferValue1 floatValue]*[mReferenceBufferValue2 floatValue])/(1e3);
	//NSString *strPower = [NSString stringWithFormat:@"%.2f",fPower];
	
	//added by caijunbo on 2011-05-23
	if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",fPower]];
	}
	//end added by caijunbo on 2011-05-23
	
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:nil:nil:mLowerValue:mUpperValue:[NSString stringWithFormat:@"%.2f",fPower]:@"watts":IP_NA:nil];
	
	/*SCRID-104: Merge the code which change in dry-run. Tony, 2011-07-21*/
//	if(fPower >= [mLowerValue floatValue] && fPower <= [mUpperValue floatValue]) //diable the code which change in dry-run proto2 .Lucky,2012-03-16
//	{
//		enumResult = RESULT_FOR_PASS;
//		strTestResultForUIinfo =[NSString stringWithFormat:@"%.4f",fPower];
//	}
//	else
//	{
//		enumResult = RESULT_FOR_FAIL;
//		strTestResultForUIinfo = [NSString stringWithFormat:@"%.4f",fPower];
//	}
	
//  [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
//	end added by Tony on 2011-07-21
	
	 if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(fPower>=[mLowerValue doubleValue]))
	 && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(fPower<=[mUpperValue doubleValue])))
	 {
         [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%0.3f",fPower]];
         return;
	 }
     else 
	 {
         [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%0.3f",fPower]];
         return;
	 }
	 
}
/*SCRID-120:end*/

+(void)CalculatePower:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mReferenceBufferName2=nil ;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	NSString *mBufferName=nil;
	
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName =[dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 =[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if ((mReferenceBufferName==nil)||(mReferenceBufferName2==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	NSString* mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
	if ((mReferenceBufferValue==nil)||(mReferenceBufferValue2==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	float fPower=0;
	fPower=[mReferenceBufferValue floatValue]*[mReferenceBufferValue2 floatValue];
	
	//added by caijunbo on 2011-05-23
	if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",fPower]] ;
	}
	//end added by caijunbo on 2011-05-23
	
	if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(fPower>=[mLowerValue doubleValue]))
	   && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(fPower<=[mUpperValue doubleValue])))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",fPower]] ;
	}else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",fPower]] ;
	}
	
}


+(void)ParsePanelID:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mSpecByte0=nil ;
	NSString *mSpecByte1=nil ;
	NSString *mSpecByte2=nil ;
	NSString *mSpecByte3=nil ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mPrefix=nil ;
	
	NSString *mPostfix=nil ;
	
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"SpecByte0"])
		{
			mSpecByte0 = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SpecByte1"])
		{
			mSpecByte1=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SpecByte2"])
		{
			mSpecByte2=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"SpecByte3"])
		{
			mSpecByte3 = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey];
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	//mReferenceBufferValue = @"OK 4105 mV ** Baseline Begin **	Control status:0x6009 DLOG 7, -217 mA DLOG 6, -216 mA DLOG 5, -215 mA DLOG 4, -214 mA DLOG 3, -213 mA DLOG 2, -212 mA DLOG 1, -211 mA OK ** Baseline End **  OK";
	
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	
	
	if(bufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get string between prefix and posfix"] ;
		return;
	}
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSMutableArray *dlogArray = (NSMutableArray*)[bufferValue componentsSeparatedByString:@" "];
	if([dlogArray count] <5)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Panel ID From Unit is wrong"] ;
		return;
	}
	
	int flag=0;
	
	//step 1 check byte 0 is not zero
	if(!([[dlogArray objectAtIndex:2] isEqualToString:mSpecByte0]))
	{
		flag++;
	
	}
	
	//step 2 check byte 1 is samsung or LGD

	NSMutableArray *arrVendorID =nil;
	
	NSString *strVendorID=[dlogArray objectAtIndex:3];
	int iVendorID=strtol([strVendorID UTF8String], NULL, 16);
	char* p=dectobin(iVendorID,8);
	
	strVendorID=[NSString stringWithUTF8String:p];
	strVendorID=[strVendorID substringToIndex:5];
	
	if (([mSpecByte1 rangeOfString:@","].length)>0 ) 
	{
		arrVendorID=(NSMutableArray*)[mSpecByte1 componentsSeparatedByString:@","];
		for (int i=0;i<[arrVendorID count];i++)
		{
			if ([[arrVendorID objectAtIndex:i] isEqualToString:strVendorID])
			{
				flag++;
				break;
			}
		}
	}
	else 
	{
		if ([strVendorID isEqualToString:mSpecByte1])
		{
			flag++;
		}
	}

	
	
	
	//step 3 check byte 2 is J2(01)
	if ([[dlogArray objectAtIndex:4] isEqualToString:mSpecByte2])
	{
		flag++;
	
	}
	//step 4 heck it is Parade Magnolia (41)
	if ([[dlogArray objectAtIndex:5] isEqualToString:mSpecByte3])
	{
		flag++;
		
	}
	if(flag==4)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"pass"] ;
	}
	else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"panel id is not expected"] ;
	}
	
}
/*SCRID-104: end*/

+(void)CheckEEPROMVER:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mSpecByte10=nil ;
	NSString *mSpecByte11=nil ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mSkipJudge=nil;
	NSString *mBufferName=@"IfNeedToSkip";
	
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	
	NSString *mReferenceBufferName2=nil ;
	NSString *mPrefix2=nil ;
	NSString *mPostfix2=nil ;
	NSString *mSpecByte1=nil;
	NSString *mNeedVendor=nil;
	
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecByte1"])
		{
			mSpecByte1 = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"SpecByte10"])
		{
			mSpecByte10 = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SpecByte11"])
		{
			mSpecByte11=[dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"SkipJudge"])
			mSkipJudge = [dictKeyDefined objectForKey:strKey];
		
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"Prefix2"])
			mPrefix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix2"])
			mPostfix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"NeedCheckVendor"])
			mNeedVendor = [dictKeyDefined objectForKey:strKey];
			
		
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue=@"BE NA+01.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	//added by caijunbo on 2011-05-27
	//used to get vendor id such as samsung
	NSString *strVendorID=nil;
	if ([mNeedVendor isEqualToString:@"yes"])
	{
		NSString* mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
		if (mReferenceBufferValue2==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
			return ;
		}
		NSString *bufferValue2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue2 Prefix:mPrefix2 Postfix:mPostfix2] ;
		bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
		bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
		
		NSMutableArray *dlogArray2 = (NSMutableArray*)[bufferValue2 componentsSeparatedByString:@" "];
		if([dlogArray2 count] <5)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Panel ID From Unit is wrong"] ;
			return;
		}
		
		strVendorID=[dlogArray2 objectAtIndex:4];
		int iVendorID=strtol([strVendorID UTF8String], NULL, 16);
		char* p=dectobin(iVendorID,8);
		
		strVendorID=[NSString stringWithUTF8String:p];
		strVendorID=[strVendorID substringToIndex:5];
		
	}
	//end added by caijunbo on 2011-05-27
	
	//mReferenceBufferValue = @"OK 4105 mV ** Baseline Begin **	Control status:0x6009 DLOG 7, -217 mA DLOG 6, -216 mA DLOG 5, -215 mA DLOG 4, -214 mA DLOG 3, -213 mA DLOG 2, -212 mA DLOG 1, -211 mA OK ** Baseline End **  OK";
	
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	
	
	
	if(bufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get string between prefix and posfix"] ;
		return;
	}
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	
	
	NSMutableArray *dlogArray = (NSMutableArray*)[bufferValue componentsSeparatedByString:@" "];
	if([dlogArray count] <15)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"EEPROM Formate is wrong"] ;
		return;
	}
	
		
	
	int flag=0;
	
	
	
	
	//step 1 check byte 13 is 08
	NSString *strtest=[dlogArray objectAtIndex:13];
	strtest=[dlogArray objectAtIndex:14];
	if([[dlogArray objectAtIndex:13] isEqualToString:mSpecByte10])
	{
		flag++;
		
	}
	
	//step 2 check byte 14 is 00
	if([[dlogArray objectAtIndex:14] isEqualToString:mSpecByte11])
	{
		flag++;
		
	}
	
	
	NSString *UIVersion = @"";
	UIVersion = [UIVersion stringByAppendingString:[dlogArray objectAtIndex:13]];
	UIVersion = [UIVersion stringByAppendingString:@" "];
	UIVersion = [UIVersion stringByAppendingString:[dlogArray objectAtIndex:14]];
	
	
	
	if(flag==2)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UIVersion] ;
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName: @"yes"];
		
	}
	else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :UIVersion] ;
		//added by caijunbo on 2011-05-28
		//if it is not samsung then skip update EEPROM
		if (![strVendorID isEqualToString:mSpecByte1])
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName: @"yes"];
		//added end by caijunbo on 2011-05-28
	}
	
	//used to skip judge pass or fail.If seted then the default is pass.
	//added by caijunbo on 2011-05-26
	
	if ([mSkipJudge isEqualToString:@"yes"])
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UIVersion] ;
		return;
	}
	//end added by caijunbo on 2011-05-26
	
}
/*SCRID-104: end*/


/*SCRID-131
  Added by caijunbo on 2011-08-17
  Description:used to check multi-vendor's EEPROM version,such as LG and SAMSUNG
 */
+(void)CheckMultiVendorEEPROMVER:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mstrSamsungVersion=nil;
	NSString *mstrLGVersion=nil;
	
	NSString *mstrSharpVersion=nil;
	
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mReferenceBufferName2=nil ;
	NSString *mPrefix2=nil ;
	NSString *mPostfix2=nil ;
	
//SCRID-150:to manage SANXING versions.Judith 2011-12-12.
	NSAutoreleasePool * pool= [ [NSAutoreleasePool alloc] init];
	NSMutableArray *mstrVersionFirstTwoCharacterArray=[[[NSMutableArray alloc] init] autorelease]; 
	NSMutableArray *mstrVersionLastTwoCharacterArray=[[[NSMutableArray alloc] init] autorelease]; 
//SCRID-150:end
	NSString *UIVersion = @"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"Prefix2"])
			mPrefix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Postfix2"])
			mPostfix2 = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"SAMSUNGVER"])
			mstrSamsungVersion = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"LGVER"])
			mstrLGVersion = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"SHARPVER"])
			mstrSharpVersion = [dictKeyDefined objectForKey:strKey];
		
	}
	
	if (mReferenceBufferName==nil||mReferenceBufferName2==nil||mstrSamsungVersion==nil||mstrLGVersion==nil||mstrSharpVersion==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	//used to get vendor id such as samsung,LG,Sharp
	NSString *strVendorID=nil;
	NSString* mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
	if (mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *bufferValue2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue2 Prefix:mPrefix2 Postfix:mPostfix2] ;
	bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue2 = [bufferValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSMutableArray *dlogArray2 = (NSMutableArray*)[bufferValue2 componentsSeparatedByString:@" "];
	if([dlogArray2 count] <5)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Error to get vendor infor"] ;
		return;
	}
	
	strVendorID=[dlogArray2 objectAtIndex:3];
	int iVendorID=strtol([strVendorID UTF8String], NULL, 16);
	char* p=dectobin(iVendorID,8);
	
	strVendorID=[NSString stringWithUTF8String:p];
	strVendorID=[strVendorID substringToIndex:5];
	//used to get vendor information
	//end	
	NSMutableArray *samsungVersionArray = (NSMutableArray*)[mstrSamsungVersion componentsSeparatedByString:@","];
	NSMutableArray *LGVersionArray = (NSMutableArray*)[mstrLGVersion componentsSeparatedByString:@","];
	NSMutableArray *sharpVersionArray = (NSMutableArray*)[mstrSharpVersion componentsSeparatedByString:@","];
	int count;
	if ([strVendorID isEqualToString:@"00101"])//means it is SAMSUNG
	{
	//SCRID-153:manage EEPRO versions.Judith.2011-12-23.
		count = [samsungVersionArray count];
		for(int i=0;i < count;i++)
		{
			[mstrVersionFirstTwoCharacterArray addObject:[[samsungVersionArray objectAtIndex:i] substringToIndex:2]];
			[mstrVersionLastTwoCharacterArray addObject:[[samsungVersionArray objectAtIndex:i] substringFromIndex:2]];
		}
		UIVersion = [UIVersion stringByAppendingString:@"SamSung "];
	}
	else if([strVendorID isEqualToString:@"00110"])//means it is LG
	{
		count = [LGVersionArray count];
		for(int i=0;i< count;i++)
		{
			[mstrVersionFirstTwoCharacterArray addObject:[[LGVersionArray objectAtIndex:i] substringToIndex:2]];
			[mstrVersionLastTwoCharacterArray addObject:[[LGVersionArray objectAtIndex:i] substringFromIndex:2]];
		}		
		UIVersion = [UIVersion stringByAppendingString:@"LG "];
	}
	
	else if([strVendorID isEqualToString:@"00100"])//means it is SHARP
	{
		count = [sharpVersionArray count];
		for(int i=0;i< count;i++)
		{
			[mstrVersionFirstTwoCharacterArray addObject:[[sharpVersionArray objectAtIndex:i] substringToIndex:2]];
			[mstrVersionLastTwoCharacterArray addObject:[[sharpVersionArray objectAtIndex:i] substringFromIndex:2]];
		}		
		UIVersion = [UIVersion stringByAppendingString:@"SHARP "];
	}
	//SCRID-153:end
	
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Illegal LCD has been used"] ;
		return;
	}
	
	
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	bufferValue = [bufferValue substringFromIndex:[bufferValue rangeOfString:@":"].location];
	
	if(bufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get string between prefix and posfix"] ;
		return;
	}
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	NSString *tmpValueV = [[bufferValue substringFromIndex:21] substringToIndex:4];
	
	/*
	NSMutableArray *dlogArray = (NSMutableArray*)[bufferValue componentsSeparatedByString:@" "];
	if([dlogArray count] <15)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Error to get EEPROM version infor"] ;
		return;
	}
	*/
	
	UIVersion = [UIVersion stringByAppendingString:tmpValueV];
	
	//UIVersion = [UIVersion stringByAppendingString:[dlogArray objectAtIndex:12]];
	//UIVersion = [UIVersion stringByAppendingString:@" "];
	//UIVersion = [UIVersion stringByAppendingString:[dlogArray objectAtIndex:13]];
	//SCRID-153:manage EEPRO versions.Judith.2011-12-23.
	BOOL flag = FALSE ;
	//step 1 check byte 13 (The First two characters of version)
	for(int i=0;i< count;i++)
		{
			//NSLog(@"12= %@",[dlogArray objectAtIndex:12]);
			//NSLog(@"b = %@",[mstrVersionFirstTwoCharacterArray objectAtIndex:i]);
			if([[tmpValueV substringToIndex:2] isEqualToString:[mstrVersionFirstTwoCharacterArray objectAtIndex:i]]
				&& [[tmpValueV substringFromIndex:2] isEqualToString:[mstrVersionLastTwoCharacterArray objectAtIndex:i]])
			{
				flag = TRUE;
				break;
			}
		}
	if(flag)  //SCRID-153:end
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UIVersion] ;
		
	}
	else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :UIVersion] ;
	}
	[pool release];
}

+(void)ParseCurrent:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName=nil ;
	NSString *mUpLimitPower=nil;
    NSString *mDeltaLowLimit=nil;
    NSString *mDeltaUpLimit=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName =[dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpLimitPower"])
		{
			mUpLimitPower=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"DeltaLowLimit"])
		{
			mDeltaLowLimit=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"DeltaUpLimit"])
		{
			mDeltaUpLimit=[dictKeyDefined objectForKey:strKey];
		}
	}

    BOOL resFlag = TRUE;
    NSString *failUIInfor = @"FailValue: ";
    
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    //mReferenceBufferValue = @"Control Status: 0x620D3821 mVControl Status: 0x600Denabling auto-calibration mode** Low Perf Baseline Begin ** LOG 6, -78 mALOG 5, -78 mALOG 4, -78 mALOG 3, -78 mALOG 2, -78 mALOG 1, -78 mA** Low";
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if([mReferenceBufferValue rangeOfString:@"mV"].length <= 0 || [mReferenceBufferValue rangeOfString:@"mV"].location <= 6)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return change, can not get volt now"] ;
        return;
    }
    //1.=====================Volt================
    NSString *volt = [mReferenceBufferValue substringFromIndex:([mReferenceBufferValue rangeOfString:@"mV"].location - 4)];
    volt = [volt substringToIndex:4];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Volt":nil:nil:nil:volt:@"mV":RESULT_FOR_PASS:nil];
    
    //2.=====================Current================
    NSString *current1 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG1," Postfix:@"mA"] ;
    NSString *current2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG2," Postfix:@"mA"] ;
    NSString *current3 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG3," Postfix:@"mA"] ;
    NSString *current4 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG4," Postfix:@"mA"] ;
    NSString *current5 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG5," Postfix:@"mA"] ;
    NSString *current6 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"LOG6," Postfix:@"mA"] ;
    if([current1 length] <= 0 || [current2 length] <= 0 || [current3 length] <= 0
       || [current4 length] <= 0 || [current5 length] <= 0 || [current6 length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return change, can not get all current now"] ;
        return;
    }
    
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_1":nil:nil:nil:current1:@"mA":RESULT_FOR_PASS:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_2":nil:nil:nil:current2:@"mA":RESULT_FOR_PASS:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_3":nil:nil:nil:current3:@"mA":RESULT_FOR_PASS:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_4":nil:nil:nil:current4:@"mA":RESULT_FOR_PASS:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_5":nil:nil:nil:current5:@"mA":RESULT_FOR_PASS:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Curr_6":nil:nil:nil:current6:@"mA":RESULT_FOR_PASS:nil];
    
    //3.=====================Power================
    double power1 = [volt doubleValue] * [current1 doubleValue] / 1000;
    double power2 = [volt doubleValue] * [current2 doubleValue] / 1000;
    double power3 = [volt doubleValue] * [current3 doubleValue] / 1000;
    double power4 = [volt doubleValue] * [current4 doubleValue] / 1000;
    double power5 = [volt doubleValue] * [current5 doubleValue] / 1000;
    double power6 = [volt doubleValue] * [current6 doubleValue] / 1000;
    
    /*if(power1 < 0)
        power1 = -1 * power1;
    if(power2 < 0)
        power2 = -1 * power2;
    if(power3 < 0)
        power3 = -1 * power3;
    if(power4 < 0)
        power4 = -1 * power4;
    if(power5 < 0)
        power5 = -1 * power5;
    if(power6 < 0)
        power6 = -1 * power6;*/
    
    if(power1 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_1":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power1]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power1:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power1]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_1":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power1]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    if(power2 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_2":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power2]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power2:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power2]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_2":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power2]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    if(power3 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_3":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power3]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power3:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power3]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_3":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power3]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    if(power4 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_4":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power4]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power4:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power4]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_4":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power4]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    if(power5 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_5":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power5]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power5:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power5]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_5":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power5]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    if(power6 <= [mUpLimitPower doubleValue])
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_6":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power6]:@"mW":RESULT_FOR_PASS:nil];
    else
    {
        resFlag = FALSE;
        failUIInfor = [failUIInfor stringByAppendingString:@"power6:"];
        failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",power6]];
        failUIInfor = [failUIInfor stringByAppendingString:@", "];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_6":nil:nil:mUpLimitPower:[NSString stringWithFormat:@"%f",power6]:@"mW":RESULT_FOR_FAIL:nil];
    }
    
    //4.=====================Average================
    double current_average = ([current1 doubleValue] + [current2 doubleValue] + [current3 doubleValue] + [current4 doubleValue] + [current5 doubleValue] + [current6 doubleValue]) / 6;
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Current_Ave":nil:nil:nil:[NSString stringWithFormat:@"%f",current_average]:@"mA":RESULT_FOR_PASS:nil];
    
    double power_average = (power1 + power2 + power3 + power4 + power5 + power6) / 6;
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Power_Ave":nil:nil:nil:[NSString stringWithFormat:@"%f",power_average]:@"mW":RESULT_FOR_PASS:nil];
    
    
     //5.=====================Delta================
    if([mTestItemName rangeOfString:@"Low Perf Baseline State"].length > 0)
    {
        [TestItemManage setBufferValue:dictKeyDefined :@"BaseLineCurrentAverage":[NSString stringWithFormat:@"%f",current_average]];
        [TestItemManage setBufferValue:dictKeyDefined :@"BaseLinePowerAverage":[NSString stringWithFormat:@"%f",power_average]];
    }
    else
    {
        NSString* baseLineCurrentAve = [TestItemManage getBufferValue:dictKeyDefined :@"BaseLineCurrentAverage"] ;
        NSString* baseLinePowerAve = [TestItemManage getBufferValue:dictKeyDefined :@"BaseLinePowerAverage"] ;
        if([baseLineCurrentAve length] <= 0 || [baseLinePowerAve length] <= 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"cann't get base line average value"] ;
            return;
        }
        double deltaCurrent = current_average - [baseLineCurrentAve doubleValue];
        if(deltaCurrent < 0)
            deltaCurrent = -1 * deltaCurrent;
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta of Current_Ave":nil:nil:nil:[NSString stringWithFormat:@"%f",deltaCurrent]:nil:RESULT_FOR_PASS:nil];
        
        
        double deltaPower = power_average - [baseLinePowerAve doubleValue];
        if(deltaPower < 0)
            deltaPower = -1 * deltaPower;
        if(((mDeltaLowLimit==nil||[mDeltaLowLimit length]<=0)?1:(deltaPower>=[mDeltaLowLimit doubleValue]))
           && ((mDeltaUpLimit==nil||[mDeltaUpLimit length]<=0)?1:(deltaPower<=[mDeltaUpLimit doubleValue])))
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta of Power_Ave":nil:mDeltaLowLimit:mDeltaUpLimit:[NSString stringWithFormat:@"%f",deltaPower]:nil:RESULT_FOR_PASS:nil];
        }
        else
        {
            resFlag = FALSE;
            failUIInfor = [failUIInfor stringByAppendingString:@"PowerDelta:"];
            failUIInfor = [failUIInfor stringByAppendingString:[NSString stringWithFormat:@"%f",deltaPower]];
            failUIInfor = [failUIInfor stringByAppendingString:@","];
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta of Power_Ave":nil:mDeltaLowLimit:mDeltaUpLimit:[NSString stringWithFormat:@"%f",deltaPower]:nil:RESULT_FOR_FAIL:nil];
        }
    }
    
    
    if(resFlag)
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failUIInfor] ;
}

/*SCRID-131
 END
 */


@end
