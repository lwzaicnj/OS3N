//
//  IFTMobDevUtil.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 11/6/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//


#define kIFTAMDeviceAppearedNotification			@"kCFTSAMDeviceAppearedNotification"
#define kIFTSAMDeviceDisappearedNotification		@"kCFTSAMDeviceDisappearedNotification"
#import "IFTMobileDevice.h"

typedef enum {
    kIFTMobileDeviceNormal=0,
    kIFTMobileDeviceDFU,
    kIFTMobileDeviceRecovery
} IFTMobileDeviceType;

typedef enum {
    kIFTMobileDeviceAttach = 0,
    kIFTMobileDeviceDetach,
    kIFTMobileDeviceNotificationStopped
} IFTMobileDeviceEventType;

@protocol IFTMobileDeviceObserver
-(void)handleDeviceEvent:(IFTMobileDevice*)device eventType:(IFTMobileDeviceEventType)et;
@end

@interface IFTMobDevManager : NSObject {
    NSMutableArray* normalObservers;
    NSMutableArray* dfuObservers;
    NSMutableArray* recoveryObservers;
    NSMutableArray* devices;
}

+ (IFTMobDevManager *)sharedInstance;

- (BOOL)startListening:(NSError**)error;
- (BOOL)stopListening:(NSError**)error;

-(void)addObserver:(id <IFTMobileDeviceObserver>)observer forDevice:(IFTMobileDeviceType)deviceType;
-(void)removeObserver:(id <IFTMobileDeviceObserver>)observer forDevice:(IFTMobileDeviceType)deviceType;

@end





