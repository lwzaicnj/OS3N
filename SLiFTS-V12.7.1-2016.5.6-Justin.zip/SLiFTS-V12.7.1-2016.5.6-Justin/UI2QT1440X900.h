// Owner:Helen DATE :12.27.2010
// SCRID :054
// Desc  :Add for QT0b Only 2 UI
// 

#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"

#define MaxUnitFlag    10

@interface UI2QT1440X900: NSObject
{
	//iboutlet variable
	IBOutlet NSWindow *window;
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSBox *boxTestItem ;
	
	IBOutlet NSTableView *testInforTableview1 ;
	IBOutlet NSTableView *testInforTableview2 ;
	IBOutlet NSScrollView* scrollView1 ;
	IBOutlet NSScrollView* scrollView2 ;
	IBOutlet NSScrollView* textLog ;
	
	IBOutlet NSTextField *textTotalTime1;
	IBOutlet NSTextField *textTotalTime2;
	IBOutlet NSTextField *textItemTime1;
	IBOutlet NSTextField *textItemTime2;
	IBOutlet NSTextField *textTestResult1;
	IBOutlet NSTextField *textTestResult2;
	
	IBOutlet NSButton* btnLog1;
	IBOutlet NSButton* btnLog2;
	IBOutlet NSButton* btnLogClose;
	IBOutlet NSButton* btnSimulator;
		
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	
	int tableViewCnt;
	NSTableView *tableViewForCnt;
	NSTableView *tableViewArray[2];
	BOOL initTableFlag;
	BOOL mTestStartFlag[MaxUnitFlag];
	BOOL mTestFlag;
	int refreshTimeCnt;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
}
- (IBAction)bt1_Start:(id)sender;
- (IBAction)bt2_Start:(id)sender;

-(IBAction)btnOpenLog1_Click:(id)sender;
-(IBAction)btnOpenLog2_Click:(id)sender;
-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)closeLog_Click:(id)sender;
-(IBAction)setFixtureID:(id)sender;

-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer ;
-(void)timerUnitCheckFireMethod:(NSTimer*)theTimer ;
-(void)initUIScanLabelAndText;
-(void)showInitLog;
-(void)setTableBgdColor:(NSInteger)uiIndex;

-(IBAction)CallEditScriptUI:(id)sender ;

@end
//End by Helen 12.27.2010
