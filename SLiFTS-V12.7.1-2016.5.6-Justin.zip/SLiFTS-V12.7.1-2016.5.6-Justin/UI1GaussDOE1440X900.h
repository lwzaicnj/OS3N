/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI1GaussDOE1440X900.h		 $|
 | $Author:: Helen                  $Revision::  1					 $|
 | CREATED: 14.02.11                $Modtime:: 14.02.11 14:06		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI1GaussDOE1440X900.h                                      $
 * *****************  Version 1  *****************
 * User: Helen           Date: 14.02.11   Time: 14:06
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"

#define MaxUnitFlag    10

//extern NSString* getAPPInitLog() ;
@interface UI1GaussDOE1440X900 : NSObject  {
	//iboutlet variable
	IBOutlet NSWindow *window;
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSBox *boxTestItem ;
	
	IBOutlet NSTableView *testInforTableview1 ;
	IBOutlet NSScrollView* scrollView1 ;
	
	IBOutlet NSTextField *textTotalTime1;
	IBOutlet NSTextField *textItemTime1;
	IBOutlet NSTextField *textTestResult1;
	IBOutlet NSTextField *textLabelTimes1 ;

	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	
	int tableViewCnt;
	NSTableView *tableViewForCnt;
	NSTableView *tableView;
	BOOL initTableFlag;
	BOOL mTestStartFlag;
	BOOL mTestFlag;
	int refreshTimeCnt;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
	NSInteger mLoopTimes;
	NSInteger mTotalLoopTimes ;
}

-(IBAction)setFixtureID:(id)sender;

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer ;
-(void)timerUnitCheckFireMethod:(NSTimer*)theTimer ;
-(void)initUIScanLabelAndText;
-(void)setTableBgdColor:(NSInteger)uiIndex;
-(IBAction)CallEditScriptUI:(id)sender ;
@end

