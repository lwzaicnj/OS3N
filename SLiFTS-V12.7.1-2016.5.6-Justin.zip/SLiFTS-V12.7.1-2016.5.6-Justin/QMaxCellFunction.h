/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: QMaxCellFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :Check QMax function.
 
 $History:: QMaxCellFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.31   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(QMaxCellFunction)

+(void)QMaxCell:(NSDictionary*)dictKeyDefined;
+(void)QMaxCellStatus:(NSDictionary*)dictKeyDefined;

@end
