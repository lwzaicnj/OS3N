//
//  StringParseFuncation.h
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(StringParseFuncation)
+(void)ParseStrWithStrSpecForMagnetBackSide:(NSDictionary*)dictKeyDefined;
+(void)ParseStrWithStrSpec:(NSDictionary*)dictKeyDefined ;
    
+(void)ParseCompareTwoBuffers:(NSDictionary*)dictKeyDefined ;
+(void)ParseStrWithStrSpecPostfix:(NSDictionary*)dictKeyDefined ;
+(void)ParseStrWithStrSpec_CB:(NSDictionary*)dictKeyDefined;
+(void)ParseStrWithMultiStrSpecForRGBW:(NSDictionary*)dictKeyDefined;
// add by Evan on 2010-12-19
+(void)ParseJudgeRevision:(NSDictionary*)dictKeyDefined;
// end;
+(void)ParseStrWithStrSpecPostfixLCDVendor:(NSDictionary*)dictKeyDefined;//dsx 03-08
+(void)ParseStrWithStrSpec_RGBW:(NSDictionary*)dictKeyDefined;
+(void)ParseStrWithStrSpecPostfixBaseBand_SN:(NSDictionary*)dictKeyDefined; //SCRID:156 Add by kenshin 2012/01/02

+(void)CalculateAverageOfArray:(NSDictionary*)dictKeyDefined;
+(void)CaculateSimulateAngleValueForHEFF:(NSDictionary*)dictKeyDefined;
+(void)ParseStrWithStrSpecForHellEffect:(NSDictionary*)dictKeyDefined; //judith added 2012-05-29
+(NSMutableArray *)SendManyCmds:(NSDictionary *)dictKeyDefined
                    Cmds       :(NSMutableArray*)writeCmdArray 
                    WriteCmdEnd:(NSString *)mWriteCmdEnd
                    Postfix    :(NSString *)mPostfix
                    TimeOut    :(NSString *)mTimeOut;
+ (float)CalculatDistanceUsingProximity:(NSDictionary*)dictKeyDefined;
+(float) CalculateDistanceFromBytes:(unsigned char) high low:(unsigned char) low;

+(void)ParseStrWithStrSpecForButtonsTest:(NSDictionary*)dictKeyDefined ;

+(void)ParseInitPositionHESTest:(NSDictionary*)dictKeyDefined;

+(void)ParseCompareDevieColor:(NSDictionary*)dictKeyDefined ;

+(void)ParseSaGrapeCurrentDeltaMax:(NSDictionary*)dictKeyDefined ;

+(void)ParseGrapeSubItem:(NSDictionary*)dictKeyDefined ;

+(void)ParseStrWithStrSpecForButtonsTestV2:(NSDictionary*)dictKeyDefined ;
// Read MBT fixture information need judge UpLimit and LowLimit,then upload UpLimit and LowLimit to PDCA. Annie  2012-11-15 
+(void)ParseStrWithStrSpecPostfixUpLowLimitForMBT:(NSDictionary*)dictKeyDefined;
// Read string only from buffer,put the value of (BufferName-ReferenceBufferName) to BufferName address, and display the value to UI-------add by Annie  2012-11-21 
+(void)ParseCalculateMaxSubtractMinValueForMBT:(NSDictionary*)dictKeyDefined;//search the Max and Min value from 4 buffer,and then calulate Max-Min value.-----add by Annie 2013-0504
+(void)ParseStrOnlyFromBuffer:(NSDictionary*)dictKeyDefined;
// Read string only from buffer,get the BufferName value, and display the value to UI-------add by Annie  2013-7-13
+(void)ParseStrFromBuffer:(NSDictionary*)dictKeyDefined;
+(void)ParseStrCompoForNVTest:(NSDictionary*)dictKeyDefined;//add by judith 20130129

+(void)ParsePlistTestItems:(NSDictionary*)dictKeyDefined;

+(void)ParseLoopOscarInit:(NSDictionary*)dictKeyDefined;


+(void)ParseStrWithBBLib:(NSDictionary*)dictKeyDefined;
+(void)ParseStrWithBBLibWithOutSimCard:(NSDictionary*)dictKeyDefined;

//add by Justin on 2013-08-27 Start
+(void)CompareBobcatWithQueryOracle:(NSDictionary*)dictKeyDefined ;
//end



+(void)ParseOrionFW:(NSDictionary*)dictKeyDefined;//add by kevin 20150925


@end