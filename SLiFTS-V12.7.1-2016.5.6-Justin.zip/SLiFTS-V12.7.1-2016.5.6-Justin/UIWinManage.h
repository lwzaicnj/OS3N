/************************************************************
 //  UIWinManage.h
 //  For UI use
 //  Created  on 5/12/10.
 //  
 //  All rights reserved.
 *************************************************************/

#import <Cocoa/Cocoa.h>

@interface UIWinManage : NSObject {

}
+(bool)UIWinManageInit;
+(bool)UIWinManageInitProxCal;
+(bool)UIWinManageInitProxCalTest;
+(void)UIWinSeleToRun;
+(void)UIWin_UnlockScript; //add by Annie for unlocking script

//UI data related function
+(int)getTestItemTotal; //get the test item summary
+(id)getTestItemUIName:(int)rowIndex ;
+(id)getTestItemUIResult:(int)DUTID :(int)rowIndex ;//get the test item test value
+(NSArray*)getTestItemResult:(int)DUTID :(int)rowIndex ;//get the test item test result
+(NSArray*)getTotalUnitInfo ;

+(bool)startTest:(int)DUTID:(NSTableView*)tableView :(NSTextField*)testITemTime:(NSTextField*)testTotalTime :(NSTextField*)showPassorFail :(bool)bDirection ScanData:(NSDictionary*)ScanDataParm;
+(bool)stopTest:(int)DUTID ;

+(bool)isCheckDUTID:(int)DUTID ;

+(NSString*)getUnitSN:(int)DUTID: (NSString*)command ;
+(bool)getUnit:(int)DUTID;
+(bool)OpenAllPort;
+(bool)CloseAllPort;
//inner function
+(NSDictionary*)getDUTIDDeviceParameter:(int)DUTID ;
+(bool)getUnitInDiags:(int)DUTID ; //check unit whether exit through DUTID.
+(bool)getUnitInIBoot:(int)DUTID ; //check unit whether exit through DUTID.

+(void)copyResToMainBoundle ;
+(NSBundle*)getCurrentFramework;
+(BOOL) compareFileModifyTime;//dsx 0602
@end
