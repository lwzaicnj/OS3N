//
//  Bounding Module Check.m
//  iFTS
//
//  Created by Foxconn001 on 09-7-21.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "BoundingModuleCheck.h"

@implementation TestItemParse(BoundingModuleCheck)

//julian 2011-07-14
+(void)ParseModuleMatch:(NSDictionary*)dictKeyDefined;
{
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	NSString *mReferenceBufferName=nil ;
	NSString *mReferenceBufferValue=nil;
	NSString *mTestItemName=nil;
	NSString* mPrefix=nil;
	NSString* mPostfix=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if(mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
		return;
	}
	
	NSString *bb = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix];
	bb = [bb stringByReplacingOccurrencesOfString:@" " withString:@""];
	bb = [bb stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bb = [bb stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSString *HWconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG]; 
	if([HWconfig length]<=0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No HWConfig"];
		return;
	}
	
	if([HWconfig rangeOfString:@"UMTS"].length>0)
	{
		NSString *bondinginfo=[NSString stringWithFormat:@"J2 %@",bb];
		if([bb isEqualToString:@"\"X26\""])
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
		}
	}
	else if([HWconfig rangeOfString:@"CDMA2000"].length>0)
	{
		NSString *bondinginfo=[NSString stringWithFormat:@"J2A %@",bb];
		if([bb isEqualToString:@"\"X26A\""])
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"boardtype error"];
	}
	
	return;
	
}
//end 2011-07-14

/*SCRID-115: add parser "ParseModuleBonding" and boardid check. julian 2011-07-14*/
+(void)ParseModuleBonding:(NSDictionary*)dictKeyDefined;
{
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	NSString *mReferenceBufferName=nil ;
	NSString *mReferenceBufferValue=nil;
	NSString *mTestItemName=nil;
	NSString* mPrefix=nil;
	NSString* mPostfix=nil;
	NSString* mReferenceBufferNameBoardID=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ; 
		}else if ([strKey isEqualToString:@"ReferenceBufferNameBoardID"])
		{
			mReferenceBufferNameBoardID = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if(mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
		return;
	}
	
	NSString *mReferenceBufferValueBoardID = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameBoardID];
	if(mReferenceBufferValueBoardID == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received board id"];
		return;
	}
	
	NSString *bb = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix];
	bb = [bb stringByReplacingOccurrencesOfString:@" " withString:@""];
	bb = [bb stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bb = [bb stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	if([mReferenceBufferValueBoardID rangeOfString:@"0x0C"].length>0)
	{
		NSString *bondinginfo=[NSString stringWithFormat:@"%@ PS6 %@",mReferenceBufferValueBoardID,bb];
		if([bb isEqualToString:@"\"X26\""])
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
		}
	}
	else if([mReferenceBufferValueBoardID rangeOfString:@"0x0E"].length>0)
	{
		NSString *bondinginfo=[NSString stringWithFormat:@"%@ PS7 %@",mReferenceBufferValueBoardID,bb];
		if([bb isEqualToString:@"\"X26A\""])
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"boardtype error"];
	}
	
	/*
	 NSString *HWconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG]; 
	 if([HWconfig length]<=0)
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No HWConfig"];
	 return;
	 }
	 
	 if([HWconfig rangeOfString:@"UMTS"].length>0)
	 {
	 NSString *bondinginfo=[NSString stringWithFormat:@"J2 %@",bb];
	 if([bb isEqualToString:@"\"X26\""])
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
	 }
	 else
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
	 }
	 }
	 else if([HWconfig rangeOfString:@"CDMA2000"].length>0)
	 {
	 NSString *bondinginfo=[NSString stringWithFormat:@"J2A %@",bb];
	 if([bb isEqualToString:@"\"X26A\""])
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :bondinginfo];
	 }
	 else
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :bondinginfo];
	 }
	 }
	 else
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"boardtype error"];
	 }
	 */
	
}
/*SCRID-115: end*/


+(void)ParseBoardId:(NSDictionary*)dictKeyDefined
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mConditionStr=nil      ;// write cmd
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ConditionStr"])
		{
			mConditionStr = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :nil];
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	//mReferenceBufferValue=@"board id :0x02 :-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :nil];
		return ;
	}
	NSRange Locate = [mReferenceBufferValue rangeOfString:mConditionStr];
	
	if(Locate.length==0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
		[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :nil];
		return ;
	}
	NSString* subBoardid = [mReferenceBufferValue substringToIndex:(Locate.location+Locate.length+1)];
	subBoardid =[subBoardid substringFromIndex:(Locate.location+Locate.length)];
	
	NSString* UIStr = mReferenceBufferValue;
	UIStr = [UIStr stringByReplacingOccurrencesOfString:@":-)" withString:@""];
	UIStr = [UIStr stringByReplacingOccurrencesOfString:@"boardid" withString:@""];
	//dsx 03-14 J1 boardid 0x00,J2 boardid 0x02
	NSString* pro = @"";
    
//3.12 disabled by kevin for new boardid start
//	switch ([subBoardid intValue])
//	{
//		case 0:
//			pro = @"RL1  ";
//			if(UIStr != nil)
//				pro = [pro stringByAppendingString:UIStr];
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :pro] ;
//			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@"WFBT"];
//			break;
//		case 2:
//			pro = @"RL2  ";
//			if(UIStr != nil)
//				pro = [pro stringByAppendingString:UIStr];
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :pro] ;
//			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@"UMTS"];
//			break;
//		/*SCRID-115: add parser "ParseModuleBonding" and boardid check. julian 2011-07-14*/
//		case 4:
//			pro = @"RL3  ";
//			if(UIStr != nil)
//				pro = [pro stringByAppendingString:UIStr];
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :pro] ;
//			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@"CDMA2000"];
//			break;
//		/*SCRID-115: end*/
//		default:
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"invalid board id"] ;
//			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :nil];
//			break;
//	}
    //3.12 disabled by kevin for new boardid end
    
    
    
    // 3.12 add by kevin for new boardid start   J127:0X08   J128;0X0A
    if([subBoardid rangeOfString:@"8"].length>0)
    {
        pro = @"SL7";
        if(UIStr != nil)
            pro = [pro stringByAppendingString:UIStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :pro] ;
        [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@"WFBT"];
    }
    else if([subBoardid rangeOfString:@"A"].length>0){
        //pro = @"J2  ";
        //pro = @"PS6 ";
        pro = @"SL8";
        if(UIStr != nil)
            pro = [pro stringByAppendingString:UIStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :pro] ;
        [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@"UMTS"];
    }
    else{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"invalid board id"] ;
        [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :nil];
	}
    // 3.12 add by kevin for new boardid end

	
    //end dsx 03-14
	///write test result and uiinfo.
	return ;
	
}
+(void)ParseModuleSFCUnit:(NSDictionary*)dictKeyDefined 
{
			
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mSFCKey=nil      ;// write cmd
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	NSString* mPrefix=nil;
	NSString* mPostfix=nil;
	NSString* mBufferNameBefore =nil;//dsx 05-04
	NSString* mBufferName =nil;//dsx 08-09
	NSString* mBufferName2 =nil;//dsx 08-09
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SFCKey"])
		{
			mSFCKey = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameBefore"])
		{/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			mBufferNameBefore = [dictKeyDefined objectForKey:strKey] ;//dsx 05-04
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;//dsx 08-09
		}else if ([strKey isEqualToString:@"BufferName2"])
		{
			mBufferName2 = [dictKeyDefined objectForKey:strKey] ;//dsx 08-09
		}
	}
	
	if (mReferenceBufferName==nil||mPrefix==nil||mPostfix==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	NSString* projectType= [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG];//dsx 08-09
	
	NSString* snFromSFC=[TestItemManage getSFCValue:dictKeyDefined :mSFCKey];
	if([snFromSFC length]<=0)
	{
		NSString *testInfoUI =@"";
		testInfoUI= [testInfoUI stringByAppendingFormat:@"no information about %@ from SFC",mSFCKey];
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :testInfoUI] ;
	    return  ;
		
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	//mReferenceBufferValue=@"board id :0x02 :-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *mReferTemp=mReferenceBufferValue;
	NSArray *list = [NSArray arrayWithObjects:@" ",@"\r",@"\t",@"\n",nil];
	
	for(int i =0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferTemp rangeOfString:tmp];
		if (Locate.length > 0)
			mReferTemp = [mReferTemp stringByReplacingOccurrencesOfString:tmp withString:@""];
	}
	
	NSString *snFromUnit = [ToolFun getStrFromPrefixAndPostfix:mReferTemp Prefix:mPrefix Postfix:mPostfix];
	if(snFromUnit==nil)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
		return ;
	}
	
	if([snFromSFC isEqualToString:snFromUnit])
	{
		if(mBufferName!=nil)
		{
			if([projectType isEqualToString:@"CDMA2000"])
			{	
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :snFromSFC] ;//dsx 08-09
			}
			else
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :snFromSFC] ;
		}
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :snFromSFC] ;
	}
	else	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	{
		NSString *mBufferBeforeValue = [TestItemManage getBufferValue:dictKeyDefined :mBufferNameBefore] ;
		if([mBufferBeforeValue rangeOfString:@"Time out"].length>0)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Compare Fail-TimeOut"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Compare Fail"] ;
	}	/*SCRID-104: end*/
	return ;
	
}
+(void)ParseModuleRecord:(NSDictionary*)dictKeyDefined 
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mTime=nil      ;
	int mCount=100;
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	NSString* mPrefix=nil;
	NSString* mPostfix=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Count"])
		{
			mTime = [dictKeyDefined objectForKey:strKey] ;
			mCount =[mTime intValue];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	NSString* HWConfig=[TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG];
	if([HWConfig length]<=0)
	{	
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No HWConfig"] ;
	    return  ;
	}
	//dsx -03-14 modify for polo
	NSRange temp = [HWConfig rangeOfString:@"WFBT"];
	if(temp.length>0)
	{
		NSString *mlbR=[TestItemManage getSFCValue:dictKeyDefined :STRKEYMLBRECORD];
		//NSString *x23R =[TestItemManage getSFCValue:dictKeyDefined :STRKEYX23RECORD];
		
		if([mlbR length]>0)
		{
			NSString *testInfoUI=@"";
			testInfoUI= [testInfoUI stringByAppendingFormat:@"MLB FA Record %@",mlbR];
			if([mlbR intValue]<mCount)
			{
				enumResult = RESULT_FOR_PASS;
			}
			else
			{
			    enumResult =RESULT_FOR_FAIL;
			}
			
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :testInfoUI] ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Record from SFC"] ;
		}
		
		return;
	}
	
	temp =[HWConfig rangeOfString:@"UMTS"];
	if(temp.length>0)
	{	
		NSString *mlbR=[TestItemManage getSFCValue:dictKeyDefined :STRKEYMLBRECORD];
		NSString *x26R =[TestItemManage getSFCValue:dictKeyDefined :STRKEYX26RECORD];
				
		if(([mlbR length]>0)&&([x26R length]>0))
		{
			NSString *testInfoUI=@"";
			testInfoUI= [testInfoUI stringByAppendingFormat:@"MLB FA Record %@ X26 FA Record %@",mlbR,x26R];
			if(([mlbR intValue]<mCount)&&([x26R intValue]<mCount))
			{
				enumResult = RESULT_FOR_PASS;
			}
			else
			{
			    enumResult =RESULT_FOR_FAIL;
			}
			
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :testInfoUI] ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Record from SFC"] ;
		}
		
		return;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No HWConfig"] ;
	return;
}
/*SCRID-19:Add Parser ParseModulePing for ACF test.*/

/*Shou-Xiu Modify,2010-11-23*/
+(void)ParseModulePing:(NSDictionary*)dictKeyDefined
{

	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mConditionStr=nil      ;// write cmd
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	NSString *mSpecialString=nil;
	NSArray *arrayBufferName=nil;
	
	NSString *mReferenceBufferValue1 =nil;
	NSString *mReferenceBufferValue2 =nil;
	NSString *mReferenceBufferValue3 =nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ConditionStr"])
		{
			mConditionStr = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"SpecPostfix"])
		{
		    mSpecialString=[dictKeyDefined objectForKey:strKey];
		
		}
		else if([strKey isEqualToString:@"Prefix"])
		{
		    mPrefix=[dictKeyDefined objectForKey:strKey];
			
		}
		else if([strKey isEqualToString:@"Postfix"])
		{
		    mPostfix=[dictKeyDefined objectForKey:strKey];
			
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
			arrayBufferName =[mReferenceBufferName componentsSeparatedByString:@","];
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :[arrayBufferName objectAtIndex:0]] ;
	mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :[arrayBufferName objectAtIndex:1]] ;
	mReferenceBufferValue3 = [TestItemManage getBufferValue:dictKeyDefined :[arrayBufferName objectAtIndex:2]] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	//mReferenceBufferValue=@"board id :0x02 :-)";
	if (mReferenceBufferValue1==nil||mReferenceBufferValue2==nil||mReferenceBufferValue3==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	int flag1=0,flag2=0,flag3=0;
	//NSRange Locate = [mReferenceBufferValue1 rangeOfString:mConditionStr options:NSBackwardsSearch];
	
	NSString *mReferTemp1=mReferenceBufferValue1;
	NSString *mReferTemp2=mReferenceBufferValue2;
	
	NSArray *list = [NSArray arrayWithObjects:@" ",@"\r",@"\t",@"\n",@".",@">",nil];
	
	for(int i =0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate1 = [mReferTemp1 rangeOfString:tmp];
		NSRange Locate2 = [mReferTemp2 rangeOfString:tmp];
		if (Locate1.length > 0)
			mReferTemp1 = [mReferTemp1 stringByReplacingOccurrencesOfString:tmp withString:@""];
		if (Locate2.length > 0)
			mReferTemp2 = [mReferTemp2 stringByReplacingOccurrencesOfString:tmp withString:@""];
	}
	
	NSRange specialBit1=[mReferTemp1 rangeOfString:mConditionStr];
	NSRange specialBit2=[mReferTemp2 rangeOfString:mConditionStr];
	if(specialBit1.length>0)
		flag1=1;
	if(specialBit2.length>0)
	 	flag2=1;
	
	NSString *lastValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue3 Prefix:mPrefix Postfix:mPostfix];
	
	if([lastValue rangeOfString:mSpecialString].length>0)
		flag3=1;
		
	if((flag1==1)&&(flag2==1)&&(flag3==1))
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		return ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
		return ;	
	}
}

//Added by Julian for QL Proto1 Dryrun Spk to DMIC test
//Modified by Annie for SL PreP2 DryRun----change all "Max Power=" to "Peak Magnitude"
+(void)ParseDMIC:(NSDictionary*)dictKeyDefined//dsx 03-16 auto test Mikey
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	int mSendFreq=0      ;// write cmd
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
    NSString *mBufferName=nil;
	NSString *mSeperateStr=nil;
	int mMaxPowerlimit=0;//dsx 05-20 check maxpower valuex
    NSString *mMaxPowerDletaLowLimit=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SendFreq"])
		{
			mSendFreq = [[dictKeyDefined objectForKey:strKey] intValue];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SeperateStr"])
		{
			mSeperateStr = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"MaxPowerlimit"])
		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			mMaxPowerlimit = [[dictKeyDefined objectForKey:strKey] intValue];//dsx 05-20
		}	/*SCRID-104: end*/
        else if ([strKey isEqualToString:@"MaxPowerDletaLowLimit"])
		{
			mMaxPowerDletaLowLimit = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	NSString *mReferenceBufferValue =nil;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    
//    mReferenceBufferValue=@"Number of samples does not equal power of 2 - truncating to 65536 samples...\nChannel 0:\nUsing 65536 bins, Peak Bin=4094; Peak Magnitude=0.001370 FS; Frequency: 2998.535156 +/- 0.366210 Hz\nDC Magnitude=0.007770 FS\nSINAD: 357.054391\nTHD+N: -9.411679 dB\nChannel 1:\nUsing 65536 bins, Peak Bin=4094; Peak Magnitude=0.003723 FS; Frequency: 2998.535156 +/- 0.366210 Hz\nDC Magnitude=0.003951 FS\nSINAD: 355.217574\nTHD+N: -17.541222 dB\nOK";

//    mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Users/jeffliu/1s.txt" encoding:NSASCIIStringEncoding error:nil];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSArray *receiveFreq =[mReferenceBufferValue componentsSeparatedByString:mSeperateStr];
	if([receiveFreq count]!=2)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
		return ;
	}
	
	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	NSString *leftChannel =[receiveFreq objectAtIndex:0];
	//leftChannel =[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Frequency:" Postfix:@"+/-"];
	//int leftValue=[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Frequency:" Postfix:@"+/-"] intValue];
	//int leftMaxPower =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Peak Magnitude=" Postfix:@";"] intValue];//dsx 05-20
    double leftMaxPower =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Peak Magnitude=" Postfix:@";"] doubleValue];//update by kevin 20151006
	double leftDCPower =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"DC Magnitude=" Postfix:@"SINAD"] doubleValue];
    double leftSINAD =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"SINAD=" Postfix:@"dB"] doubleValue];
    double leftTHD =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"THD+N:" Postfix:@"dB"] doubleValue];
	NSString *rightChannel =[receiveFreq objectAtIndex:1];
	//rightChannel =[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Frequency:" Postfix:@"+/-"];
	//int rightValue=[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Frequency:" Postfix:@"+/-"] intValue];
	//int rightMaxPower =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Peak Magnitude=" Postfix:@";"] intValue];//dsx 05-20
    double rightMaxPower =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Peak Magnitude=" Postfix:@";"] doubleValue];//update by kevin 20151006
	double rightDCPower =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"DC Magnitude=" Postfix:@"SINAD"] doubleValue];
//    double rightSINAD =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"SINAD:" Postfix:@"THD+N"] doubleValue];
//    double rightTHD =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"THD+N:" Postfix:@"dB"] doubleValue];
    double rightSINAD =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"SINAD=" Postfix:@"dB"] doubleValue];
    double rightTHD =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"THD+N:" Postfix:@"dB"] doubleValue];
    
   // NSString *result = [NSString stringWithFormat:@"TopMic Mag:%d;BackMic Mag:%d",leftMaxPower,rightMaxPower];//Changed by bruce 2015.7.20
     NSString *result = [NSString stringWithFormat:@"TopMic Mag:%f;BackMic Mag:%f",leftMaxPower,rightMaxPower];//Changed by bruce 2015.7.20


    
    if (mBufferName!=nil)  //add by Bruce 2015.8.17
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :result] ;
    //NSLog(@"%f,%f,%f,%f,%f,%f,%d,%d",leftDCPower,rightDCPower,leftSINAD,rightSINAD,leftTHD,rightTHD,leftMaxPower,rightMaxPower);
    NSString *leftMaxPowerStr = [ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Peak Magnitude=" Postfix:@";"];
    NSString *rightMaxPowerStr = [ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Peak Magnitude=" Postfix:@";"];
    
	if((leftDCPower!=rightDCPower) && (leftMaxPower!=rightMaxPower) && (leftSINAD!=rightSINAD)&&(leftTHD!=rightTHD)&&(leftMaxPower>mMaxPowerlimit)&&(rightMaxPower>mMaxPowerlimit))
	{
        float maxPowerDleta = leftMaxPower - rightMaxPower;
        if(maxPowerDleta < 0)
            maxPowerDleta = -1 * maxPowerDleta;
        
        if (maxPowerDleta >= [mMaxPowerDletaLowLimit floatValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :result] ;
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 0:Peak Magnitude":nil:nil:nil:leftMaxPowerStr:nil:RESULT_FOR_PASS:nil];
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 1:Peak Magnitude":nil:nil:nil:rightMaxPowerStr:nil:RESULT_FOR_PASS:nil];
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :result] ;
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 0:Peak Magnitude":nil:nil:nil:leftMaxPowerStr:nil:RESULT_FOR_FAIL:nil];
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 1:Peak Magnitude":nil:nil:nil:rightMaxPowerStr:nil:RESULT_FOR_FAIL:nil];
        }
		return ;
		
	}
	else
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :result] ;
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 0:Peak Magnitude":nil:nil:nil:leftMaxPowerStr:nil:RESULT_FOR_FAIL:nil];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Channel 1:Peak Magnitude":nil:nil:nil:rightMaxPowerStr:nil:RESULT_FOR_FAIL:nil];
		return ;
	}
	/*SCRID-104: end*/
}

//end
+(void)ParseMikey:(NSDictionary*)dictKeyDefined//dsx 03-16 auto test Mikey
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	int mSendFreq=0      ;// write cmd
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	NSString *mSeperateStr=nil;
	int mMaxPowerlimit=0;//dsx 05-20 check maxpower value
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SendFreq"])
		{
			mSendFreq = [[dictKeyDefined objectForKey:strKey] intValue];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SeperateStr"])
		{
			mSeperateStr = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"MaxPowerlimit"])
		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			mMaxPowerlimit = [[dictKeyDefined objectForKey:strKey] intValue];//dsx 05-20
		}	/*SCRID-104: end*/
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	NSString *mReferenceBufferValue =nil;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	//mReferenceBufferValue=@"board id :0x02 :-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSArray *receiveFreq =[mReferenceBufferValue componentsSeparatedByString:mSeperateStr];
	if([receiveFreq count]!=2)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
		return ;
	}
	
	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	NSString *leftChannel =[receiveFreq objectAtIndex:0];
	//leftChannel =[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Frequency:" Postfix:@"+/-"];
	int leftValue=[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Frequency:" Postfix:@"+/-"] intValue];
	int leftMaxPower =[[ToolFun getStrFromPrefixAndPostfix:leftChannel Prefix:@"Peak Magnitude=" Postfix:@";"] intValue];//dsx 05-20
	
	NSString *rightChannel =[receiveFreq objectAtIndex:1];
	//rightChannel =[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Frequency:" Postfix:@"+/-"];
	int rightValue=[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Frequency:" Postfix:@"+/-"] intValue];
	int rightMaxPower =[[ToolFun getStrFromPrefixAndPostfix:rightChannel Prefix:@"Peak Magnitude=" Postfix:@";"] intValue];//dsx 05-20
	
	NSString *result = [NSString stringWithFormat:@"LFreq:%d,LMaxPower:%d;RFreq:%d,RMaxPower:%d",leftValue,leftMaxPower,rightValue,rightMaxPower];
	
	if((rightValue>(mSendFreq-8))&&(rightValue<(mSendFreq+8))&&
	   (leftValue>(mSendFreq-8))&&(leftValue<(mSendFreq+8))&&(leftMaxPower>mMaxPowerlimit)&&(rightMaxPower>mMaxPowerlimit))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :result] ;
		return ;
		
	}
	else
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :result] ;
		return ;	
	}
	/*SCRID-104: end*/
}

/*SCRID-19:Modify end*/

/*
+(void)ParseModuleRecord:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mSpeStr1=nil      ;// write cmd
	NSString *mSpeStr2=nil;
	//NSInteger mIntLowValue = 0;
	NSString *mReferenceBufferName=nil ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpeStr1"])
		{
			mSpeStr1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpeStr2"])
		{
			mSpeStr2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		//[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWSN :nil];
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	//mReferenceBufferValue=@"errorPass";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		//[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWSN :nil];
		return ;
	}
	NSString *BoardHW=[TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG];
	if(BoardHW==nil)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"invalid board id"] ;
		return;
	}
	if ([BoardHW isEqualToString:@"WiFi"])
	{
		NSRange Locate1 =[mReferenceBufferValue rangeOfString:mSpeStr1];
		NSRange Locate2 =[mReferenceBufferValue rangeOfString:mSpeStr2];
		if((Locate1.length>0)&&(Locate2.length==0))
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else if(((Locate1.length==0)||(Locate1.length>0))&&(Locate2.length>0))
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Module Wrong"] ;
		else
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;	
			
	}
	else if([BoardHW isEqualToString:@"UMTS"])
	{
		NSRange Locate1 =[mReferenceBufferValue rangeOfString:mSpeStr1];
		NSRange Locate2 =[mReferenceBufferValue rangeOfString:mSpeStr2];
		if((Locate1.length==0)&&(Locate2.length>0))
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else if(((Locate2.length==0)||(Locate2.length>0))&&(Locate1.length>0))
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Module Wrong"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;	
	
	}
	else if([BoardHW isEqualToString:@"CDMA2000"])
	{}
	else
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"invalid board id"];
	
	///write test result and uiinfo.
	return ;
	
	
}*/
@end
