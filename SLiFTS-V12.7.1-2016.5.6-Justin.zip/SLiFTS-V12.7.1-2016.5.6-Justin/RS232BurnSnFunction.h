//
//  RS232BurnSnFunction.h
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"

@interface TestItemParse(RS232BurnSnFunction)

//+(void)RS232WriteAndReadStr:(NSDictionary*)dictKeyDefined ;
+(void)RS232BurnSn:(NSDictionary*)dictKeyDefined;

+(void)BurnSnWithPrefixAndPostfix:(NSDictionary*)dictKeyDefined;

@end
