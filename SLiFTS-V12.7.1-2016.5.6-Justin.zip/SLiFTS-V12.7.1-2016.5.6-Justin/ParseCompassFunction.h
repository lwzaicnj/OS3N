//
//  ParseCompassFunction.h
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseCompassFunction)
+(void)ParseCompass:(NSDictionary*) DictionaryPtr;
+(void)ParseDOECompass:(NSDictionary*) DictionaryPtr ;
+(void)ParseCompassV2:(NSDictionary*) DictionaryPtr ;
+(void)ParseCompassV3:(NSDictionary*) DictionaryPtr ;//Created by Fred 2012.6.12
+(void)ParseCompassWithCameraOld:(NSDictionary*) DictionaryPtr ;
+(void)ParseCompassWithCamera:(NSDictionary*) DictionaryPtr ;
+(void)CompareValueWithTwoBuffer:(NSDictionary*) DictionaryPtr ;
@end