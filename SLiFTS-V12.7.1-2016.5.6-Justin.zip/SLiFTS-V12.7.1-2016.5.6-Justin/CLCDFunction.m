/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: CLCDFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :CLCD Method
 
 PURPOSE :CLCD function.
 
 $History:: CLCDFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.31   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "QMaxCellFunction.h"


@implementation TestItemParse(CLCDFunction)

+(void)ParseWithCLCD:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix =@"";
	NSString *mPostfix =@"";
	NSString *mBufferName=@"";

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	//mReferenceBufferValue=@"device --key Display@built-in --get edid34ad0x00 0xf0 0x00 0x00 0x1a:-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}

	bool flag = false;
	NSString *buffer = nil;
	
	buffer = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if (buffer!=nil && [buffer length] > 0)
		flag = true;

	if(!flag)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diags' Respond between Prefix and Postfix is null"] ; 
	}
	else
	{
		NSString * kkBuf = buffer;
		kkBuf = [kkBuf stringByReplacingOccurrencesOfString:@" " withString:@""];
		kkBuf = [kkBuf stringByReplacingOccurrencesOfString:@"	" withString:@""];
		kkBuf = [kkBuf stringByReplacingOccurrencesOfString:@"\r" withString:@""];
		kkBuf = [kkBuf stringByReplacingOccurrencesOfString:@"\n" withString:@""];
		kkBuf = [kkBuf stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		

		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
		//NSMutableArray * mutArrayTemp = [kkBuf componentsSeparatedByString:@"0x"];
		NSArray * mutArrayTemp = [kkBuf componentsSeparatedByString:@"0x"];
		//end
		int jj = [mutArrayTemp count];
		if(jj<5)
		{
			mutArrayTemp = [kkBuf componentsSeparatedByString:@"0X"];
			jj = [mutArrayTemp count];
		}
		if(jj<5)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Less than 4 Hex Value"] ;
			return;
		}

		NSString *tBuf = @"";
		if([mutArrayTemp objectAtIndex:1]!=nil && [mutArrayTemp objectAtIndex:2]!=nil
			&& [mutArrayTemp objectAtIndex:3]!=nil && [mutArrayTemp objectAtIndex:4]!=nil)
		{
			tBuf = [tBuf stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
			tBuf = [tBuf stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
			tBuf = [tBuf stringByAppendingString:[mutArrayTemp objectAtIndex:3]];
			tBuf = [tBuf stringByAppendingString:[mutArrayTemp objectAtIndex:4]];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Less than 4 Hex Value"] ;
			return;
		}

		//judge is Hex value or not
		NSString *HexChar = @"abcdefABCDEF0123456789";
		bool bHex = true;
		NSString *tmp = tBuf;
		NSString *tmpSub = @"";
		for(int i=0; i<[tmp length]; i++)
		{
			tmpSub = [tmp substringFromIndex:i];
			NSString *PP = [tmpSub substringToIndex:1];
			NSRange rangeAA = [HexChar rangeOfString:PP];
			if(rangeAA.length<=0)
			{
				bHex = false;
				break;
			}
		}
		if(!bHex)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Is not Hex Value"] ;
			return;
		}

		//judge are all Zero Hex value or not
		NSString *TS = tBuf;
		bool bAllZero = true;
		for(int i=0; i<[TS length]; i++)
		{
			tBuf = [TS substringFromIndex:i];
			NSString *PP = [tBuf substringToIndex:1];
			if(![PP isEqualToString:@"0"])
			{
				bAllZero=false;
				break;
			}
		}
		
		NSString *testValue = @"0x";
		testValue = [testValue stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
		testValue = [testValue stringByAppendingString:@" 0x"];
		testValue = [testValue stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
		testValue = [testValue stringByAppendingString:@" 0x"];
		testValue = [testValue stringByAppendingString:[mutArrayTemp objectAtIndex:3]];
		testValue = [testValue stringByAppendingString:@" 0x"];
		testValue = [testValue stringByAppendingString:[mutArrayTemp objectAtIndex:4]];
		
		if(bAllZero)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :testValue] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :testValue] ;
		
		if (mBufferName!=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :testValue] ;
	}
	
	return;
	
}

@end

