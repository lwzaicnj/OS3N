//
//  UI_LockScript.m
//  iFTS
//
//  Created by Fox on 5/23/13.
//
//
#import "scriptParse.h"
#import "UI_LockScript.h"
bool unlockPassFlag;

@implementation UI_LockScript

-(void)awakeFromNib
{
    unlockPassFlag=false;
    NSMutableArray *myArray =[[NSMutableArray alloc] init];
    //{@"Main",@"Mini",@"SOP"};
    [myArray addObject:@"SW_QT"];
    [myArray addObject:@"EE_DRI"];
    [acconut addItemsWithObjectValues:myArray];
    if ([myArray count])
    {
        [acconut selectItemAtIndex:0];
    }
    
}

//-(id)init
//{
////    NSPoint winPosition;
////    winPosition.x=680;
////    winPosition.y=780;
////    [lockScript_win setFrameOrigin:winPosition];
////    //[lockScript_win display];
//}

- (void)windowDidLoad
{
	NSLog(@"Nib UIAlert is loaded !");
}
- (bool)unlockSucess
{
    return unlockPassFlag;
}

- (IBAction)unlock_click:(id)sender
{
    char *user=getlogin();
    NSString *userStr=[NSString stringWithUTF8String:user];
    NSString *basePathStr=[NSString stringWithFormat:@"/Users/%@/Documents",userStr];
    
    //NSURL *permissionPath = [NSURL fileURLWithPath:[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Contents"]];
    NSURL *permissionPath = [NSURL URLWithString:basePathStr];
    
    NSString *accountStr=[acconut objectValueOfSelectedItem];
    NSString *passWordStr=[passwordTxt stringValue];
    if (([accountStr isEqualToString:@"EE_DRI"] &&[passWordStr isEqualToString:@"f1221755"])||([accountStr isEqualToString:@"SW_QT"] &&[passWordStr isEqualToString:@"sm01.7680"]))
    {
        //if input accout and password good--->refresh test script log       
        
        if([accountStr isEqualToString:@"SW_QT"])
            isAdmin = YES;
        else
            isAdmin = NO;
        //Rick add at 20130613
        
        unlockPassFlag=true;
        NSString *strTestScriptPath = [NSHomeDirectory()stringByAppendingString:[ScriptParse getValueFromSummary:@"TestScript"]] ;
        NSString *stationStr = strTestScriptPath;//[strTestScriptPath stringByReplacingOccurrencesOfString:@"/" withString:@""];
        NSRange blankRange=[stationStr rangeOfString:@" "];
        if (blankRange.length>0) {
            stationStr = [stationStr stringByReplacingOccurrencesOfString:@" " withString:@"\\ "];
        }
        NSString *curModifyTimeCommand=[NSString stringWithFormat:@"openssl sha1 %@ >%@/vv.txt",stationStr,[permissionPath path]];
        system([curModifyTimeCommand UTF8String]);
        
        NSString*  curModifyDateAllStrTmp=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vv.txt",[permissionPath path]] encoding:NSASCIIStringEncoding error:nil];

        int curModifyDataLength=[curModifyDateAllStrTmp length];
        while (curModifyDateAllStrTmp==nil || curModifyDataLength==0)
        {
            system([curModifyTimeCommand UTF8String]);
            usleep(500);
            curModifyDateAllStrTmp=[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/vv.txt",[permissionPath path]]  encoding:NSASCIIStringEncoding error:nil];
            curModifyDataLength=[curModifyDateAllStrTmp length];
        }
        
        curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@" " withString:@""];
        curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        curModifyDateAllStrTmp = [curModifyDateAllStrTmp stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        
        NSString *curModifyStrTmp=[curModifyDateAllStrTmp substringFromIndex:curModifyDataLength-43];

        
        FILE* fp=NULL;
        fp=fopen([[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]] UTF8String],"wr");
        fclose(fp);
        
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:[NSString stringWithFormat:@"%@/vlock.txt",[permissionPath path]]];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[curModifyStrTmp dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }

        [lockScript_win performClose:self];
        exit(0);
        
    }else
    {
        unlockPassFlag=false;
        [inputHitInfoLab setStringValue:@"account and password error !"];
        [inputHitInfoLab setTextColor:[NSColor redColor]];
        [inputHitInfoLab setFont:[NSFont userFontOfSize:15]];
        
        [passwordTxt setStringValue:@""];
        //[inputHitInfoLab setStringValue:@""];
        
    }
}

@end

//void UnlockScriptSuccess()
//{
//    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
//    bool bTmp ;
//    if (bTmp==false)
//        [ToolFun setAPPInitLog:@"Testitemmanager parse fail!"];
//    
//    bTmp=[TestItemParse testItemParseInit];
//    if (bTmp==false)
//        [ToolFun setAPPInitLog:@"Testitemparse parse fail!"] ;
//    //Modified by henry 2011-02-24
//    //SCRID:94 modify by Henry for Prox Cal new fixture
//    NSString* strUIName=[ScriptParse getValueFromSummary:@"SwitchUI"];
//    //SCRID:94 modify end
//    if([strUIName isEqualToString:@"UI3Prox"])
//        bTmp=[UIWinManage UIWinManageInitProxCal] ;
//    else
//        bTmp=[UIWinManage UIWinManageInit] ;
//    if (bTmp==false)
//        [ToolFun setAPPInitLog:@"UI Window Manager init fail!"] ;
//    
//    [pool drain] ;
//    
//    
//    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
//    {
//        NSLog(@"writecsv");
//        NSDate *ParametricDataCSVDate =[NSDate date];
//        NSString *ParametricDataCSVFileName =[ParametricDataCSVDate description];
//        
//        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@" " withString:@""];
//        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@":" withString:@""];
//        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"-" withString:@""];
//        ParametricDataCSVFileName=[ParametricDataCSVFileName stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
//        
//        ParametricDataFilePath = [[NSMutableString alloc] initWithString: @"/vault/ParametricData" ];
//        [ParametricDataFilePath appendString:ParametricDataCSVFileName];
//        [ParametricDataFilePath appendString:@".csv"];
//        
//        FILE* fp=NULL;
//        fp=fopen([ParametricDataFilePath UTF8String],"wr");
//        fclose(fp);
//        
//        NSString *stationName = [ScriptParse getValueFromSummary:@"TestStation"];
//        NSString *version = [NSString stringWithContentsOfFile:@"/version.txt" encoding:NSASCIIStringEncoding error:nil];
//        NSString *title = [NSString stringWithFormat:@"%@,%@\nProduct,SerialNumber,Special Build Description,Test Pass/Fail Status,StartTime,EndTime,",stationName,version];
//        
//        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];
//        if (filehandTmp!=nil)
//        {
//            [filehandTmp seekToEndOfFile] ;
//            [filehandTmp writeData:[NSData dataWithData:[title dataUsingEncoding:NSASCIIStringEncoding]]] ;
//            [filehandTmp closeFile] ;
//        }
//        
//    } //add by Rick for write csvfile 2012-10-27
//    
//    
//    
//    
//    
//    
//    //NSLog(@"%@",[ScriptParse getDeviceInfo]) ;
//    //[ScriptParse DeletePostfixInvisableChar:@"1234567890"] ;
//    //=============dsx=======================
//    int i=0;
//    const char * DFUPath="open /Users/gdlocal/Desktop/DFUfile/DFU\\ Slurper.app"; //need to modify
//    i=system(DFUPath);
//    
//    
//    //added by caijunbo on 2010-09-10
//    NSBundle* bundle =nil;
//    NSString* strIsNeedBundle=[ScriptParse getValueFromSummary:@"SwitchUI"];
//    NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
//    /** SCRID:054 Modify for QT0b use 2 UI 2010-12-27 **/
//    if (([strIsNeedBundle isEqualToString:@"UI4DP"])||([strIsNeedBundle isEqualToString:@"UI2QT"]))
//    /** SCRID:054 end 2010-12-27 **/
//    {
//        /** SCRID-38: When DP Use serial cable instead of Ethernet Cable, no need replace serial port 2010-12-14 **/
//        NSString*strAutoTrigger =[ScriptParse getValueFromSummary:@"AutoTrigger"];
//        if ([strAutoTrigger boolValue])
//        {
//            NSAutoreleasePool * autoPool = [[NSAutoreleasePool alloc] init] ;
//            NSString* DeviceFile1=@"";
//            NSString* DeviceFile2=@"";
//            NSArray *arrayDeviceList=[UartComm ScanPort] ;
//            [arrayDeviceList retain];
//            int icount=[arrayDeviceList count];
//            if (icount>=2)
//            {
//                DeviceFile1=[arrayDeviceList objectAtIndex:0];
//                DeviceFile2=[arrayDeviceList objectAtIndex:1];
//                ReplaceDPDeviceFile(DeviceFile1,DeviceFile2);
//            }
//            
//            [arrayDeviceList release];
//            [autoPool drain];
//        }
//        /** SCRID-38 end **/
//        //bundle = loadBundle();
//        //DPBundle=bundle;
//        //[DPBundle retain];
//    }
//    
//    //added end by caijunbo on 2010-09-10
//    
//    //modified by caijunbo on 2010-10-12
//    //else if([stationName isEqualToString:@"iPad-1"])//xiuxiu-2010-10-09 replace real uart address for ipad-1 at path vault/
//    /** SCRID-34: Change iPad-1 to iPad-1b. Modify by Shou-Xiu **/
//    //if([stationName isEqualToString:@"iPad-1"])
//    if([stationName isEqualToString:@"iPad-1b"])
//        //end modify
//    {
//        /*
//         NSAutoreleasePool * autoPool = [[NSAutoreleasePool alloc] init] ;
//         
//         NSString* DeviceFile1=@"";
//         NSString *fileName =@"";
//         NSString *readFData=@"";
//         
//         NSArray *arrayDeviceList=[UartComm ScanPort] ;
//         if ([arrayDeviceList count]>1)
//         {
//         DeviceFile1=[arrayDeviceList objectAtIndex:0];
//         fileName = @"/vault/iFactoryTest/TesterConfig_oc.csv";
//         //NSString *folderPath = @"/vault/iFactoryTest";
//         readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
//         }
//         if([readFData rangeOfString: @"REALUART"].length>0)
//         {
//         readFData=[readFData stringByReplacingOccurrencesOfString:@"REALUART" withString:DeviceFile1];
//         [readFData writeToFile:fileName atomically:YES encoding:NSASCIIStringEncoding error:NULL] ;
//         }
//         
//         //[arrayDeviceList release];
//         [autoPool release];
//         */
//        /** SCRID-34 Modify End**/
//        
//        //bundle = loadBundle();
//        //DPBundle=bundle;
//        //[DPBundle retain];
//        
//    }
//    
//    
//    [UIWinManage UIWinSeleToRun] ;
//}

