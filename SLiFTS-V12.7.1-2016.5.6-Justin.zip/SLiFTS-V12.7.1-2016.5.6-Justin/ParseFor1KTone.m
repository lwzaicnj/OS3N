
/*
 SCRID:31
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ParseMagnetFunction.m  $|
 | $Author:: Evan                        $Revision::  1						$|
 | CREATED: 2010-12-06                   $Modtime:: 2.03.00 08:43			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to test the Magnetic testItem "The Max value" 
 
 */

#import "ParseMagnetFunction.h"
#import "toolFun.h"



@implementation TestItemParse(ParseFor1KTone)

+(void)ParseFor1KTone:(NSDictionary*)dictKeyDefined
{
	enum TestResutStatus enumResult ;
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString *mUpvalue=nil;
	NSString *mLowValue=nil;
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
			
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpValue"])
		{
			mUpvalue = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowValue"])
		{
			mLowValue = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//NSString *mReferenceBufferValue=@"SPKON 00710Hz";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *Value=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"SPKON" Postfix:@"Hz"];
	//NSString *Value=[ToolFun getStrToEndString:mReferenceBufferValue EndString:@"Hz" Option:FALSE];
	if (Value==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	double Value1 = [Value doubleValue];
	
	if(Value1 >= [mLowValue doubleValue] && Value1 <= [mUpvalue doubleValue])
	   
	{
		enumResult = RESULT_FOR_PASS;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"Pass"] ;

	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"Fail"] ;
	}

	
	return;
}

@end
