//
//  ParserBand.m
//  iFTS
//
//  Created by justin on 13-8-2.
//
//

#import "ParserBand.h"
#import "toolFun.h"
#import "pubFun.h"
#import "ParseCL200AData.h"
#import "CommManage.h"

BOOL CL200AInitFlag = YES;
BOOL CL200A_SecInitFlag = YES;

@implementation TestItemParse(ParserBand)
//For SL CT1 LcmCal test in SL P2 US Dry Run--Annie added on 2015.8.13
+(void)SmokeyLcmCalGetPlist:(NSDictionary*) dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;
    NSString *mWriteCmdTmp1=nil      ;
    NSString *mWriteCmdTmp2=nil      ;
    
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mWhetherRead = @"yes" ;
    NSString *mPostfix =@":-)";
    NSString* mStrSpec=nil;//add by jack 20151223
    
    
    for (int i=0; i < [dictKeyDefined count]; i++)
    {
        NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
        
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey];
        }
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
            //NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
        }else if ([strKey isEqualToString:@"WriteCmd2"])
        {
            mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }

    }
    
    NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
    if(mWriteCmdTmp2 != nil)
        mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
    else
        mWriteCmd =mWriteCmdTmp1;
    
    if (mDevice==nil ||
        mWriteCmd==nil ||mBufferName==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    //-------------------Send diag command to unit---------------------
    
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
    if (mWriteCmdEnd!=nil)
    {
        if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
        {
            NSLog(@"NOCMDEND");
        }
        else
            [strMutSendBuffer appendString:mWriteCmdEnd] ;
    }
    
    bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer:mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    if ([mWhetherRead boolValue])
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        
        
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        if ([dataResult rangeOfString:mStrSpec].length==0)//add by jack on 20151223
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Writing PDCA plist file Fail!"] ;
            return ;

        }
        
        
        if (mBufferName !=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Send Diag command PASS"] ;
        }
    }
    //------------Get PDCA.plist file from unit--------------------------------------
    //------------Open DFU Slurper---------------------------------------------------
    //NSString *dfuPathStr=@"/Users/anniezhang/Desktop/DFU Slurper.app";
    //system([dfuPathStr UTF8String]);
    // Annie Debug
    //bTmp = [self SendData:dictKeyDefined :@"dfufile --read nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\Agni\\PDCA.plist\n":mPostfix] ;
    // Annie Debug
    
    bTmp = [self SendData:dictKeyDefined :@"dfufile --read nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\LcmCal\\PDCA.plist\n":mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"dfufile --read nandfs:send data fail "] ;
        return ;
    }
    
    if ([mWhetherRead boolValue])
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        
        
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"dfufile --read nandfs:NO Receive Data!"] ;
            return ;
        }
    }
    
    
}
//For SL CT1 LcmCal test in SL P2 US Dry Run--Annie added on 2015.8.13
+(void)SmokeyLcmCal:(NSDictionary*) dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mDevice=nil        ;
    NSString *mSNSeperateType=nil;
    NSString *mPostfix =@":-)";
    
    for (int i=0; i < [dictKeyDefined count]; i++)
    {
        NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
        
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey];
        }
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"SNSeperateType"])
        {
            mSNSeperateType = [dictKeyDefined objectForKey:strKey] ;
            //NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
        }
    }
    
    if (mSNSeperateType==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    
    //------------Get PDCA.plist file from unit--------------------------------------
    //NSString *pathStr=@"/Users/anniezhang/Desktop/PDCA.plist";
    NSString *pathStr=[NSHomeDirectory() stringByAppendingString:@"/PDCA.plist"];
    NSDictionary *pdcaDic=[[NSDictionary dictionaryWithContentsOfFile:pathStr] objectForKey:@"0"];
    
    if (pdcaDic==nil) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no valid plist file"] ;
        return;
    }
    NSArray *pdcaTestArray=[pdcaDic objectForKey:@"Tests"];
    if ([pdcaTestArray count]<4) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no valid plist file (tests)"] ;
        return;
    }
    
    
    if ([mSNSeperateType isEqualToString:@"DBCl"])
    {
        NSDictionary *testDic1=[pdcaTestArray objectAtIndex:1];
        NSString *valueStr1=[testDic1 objectForKey:@"value"];
        NSString *resultStr1=[testDic1 objectForKey:@"result"];
        if ([resultStr1 isEqualToString:@"PASS"] ||[resultStr1 isEqualToString:@"Pass"]||[resultStr1 isEqualToString:@"pass"])
        {
            //[TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"DBCl" :nil :nil :nil :valueStr1 :nil :RESULT_FOR_PASS :@"PASS"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :valueStr1] ;
            return;
        }else
        {
            //[TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"DBCl" :nil :nil :nil :valueStr1 :nil :RESULT_FOR_FAIL :@"FAIL"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :valueStr1] ;
            return;
        }
        
    }else
    {
        NSDictionary *testDic2=[pdcaTestArray objectAtIndex:2];
        NSString *valueStr2=[testDic2 objectForKey:@"value"];
        NSString *resultStr2=[testDic2 objectForKey:@"result"];
        if ([resultStr2 isEqualToString:@"PASS"] ||[resultStr2 isEqualToString:@"Pass"]||[resultStr2 isEqualToString:@"pass"]) {
           // [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"DTCl" :nil :nil :nil :valueStr2 :nil :RESULT_FOR_PASS :@"PASS"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :valueStr2] ;
            return;
        }else
        {
            //[TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"DTCl" :nil :nil :nil :valueStr2 :nil :RESULT_FOR_FAIL :@"FAIL"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :valueStr2] ;
            return;
        }
    }
    
}

+(void)ParserBand:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mReferenceBufferName = nil;
    NSString *mContainString = nil;
    NSString *mNotContainString = nil;
    NSArray *mReferenceBufferNamesArray;
    NSArray *mNotContainStringArray;
    for (int i=0; i < [dictKeyDefined count]; i++)
    {
        NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
        
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ContainString"])
        {
            mContainString = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"NotContainString"])
        {
            mNotContainString = [dictKeyDefined objectForKey:strKey];
        }
    }
//    *************************************************************************
//    NSString *EGSM900_buffer1 = @"Request:\n0000000: 7B\nResponse:\n\n0000000: 7B ";
//    NSString *EGSM900_buffer2 = @"Request:\n0000000: 7C\nResponse:\n0000000: 7C 02 00 00 00 20 6F 70 E6 0F 00 00 30 2E 32 35  |.... op....0.25\n0000010: 2E 31 33 5F 44 45 42 55 47 00 00";
//    NSString *EGSM900_buffer3 = @"Request:\n0000000: 7B\nResponse:\n\n0000000: 7B ";
//    
//    NSString *EGSM900_buffer4 = @"Request:\n0000000: 4B 0F 00 00 00 00\nResponse:\n0000000: 4B 0F 00 00 00 00 00 00 05 00 00 00 00 00 00 00  K...............\n0000010: 02 00 00 00 FF FF FF BF FF 00 00 00 02 00 00 00  ................\n0000020: 00 00 00 00 00 00 00 00 00 00 00 00 04 00 00 00  …………….";
//    NSMutableArray *try = [NSArray arrayWithObjects:EGSM900_buffer1,EGSM900_buffer2,EGSM900_buffer3,EGSM900_buffer4,nil];
//    mReferenceBufferName =@"EGSM900_buffer1,EGSM900_buffer2,EGSM900_buffer3,EGSM900_buffer4,EGSM900_buffer5,EGSM900_buffer6,EGSM900_buffer7,EGSM900_buffer8,EGSM900_buffer9,EGSM900_buffer10";
//    mContainString = @"Response:";
//    mNotContainString = @"ERROR,Error,error";
//    
////    *************************************************************************
    if (mReferenceBufferName==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
    }
    else
    {
        if ((mContainString == nil)||(mNotContainString==nil))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"ContainString Or NotContainString is NULL"];
            return;
        }
        mReferenceBufferNamesArray = [[[NSArray alloc] init]autorelease];
        mReferenceBufferNamesArray = [mReferenceBufferName componentsSeparatedByString:@"," ];
        
        mNotContainStringArray = [[[NSArray alloc] init]autorelease];
        mNotContainStringArray = [mNotContainString componentsSeparatedByString:@"," ];
        
        //get the bufferValue of each CMD return
        NSString *reference_BufferName = nil;
        NSRange rangeContainString;
        NSRange rangeNotContainString;
        for (int i = 0 ; i < [mReferenceBufferNamesArray count]; i++)
        {
            reference_BufferName = [ToolFun deleteFromString:[mReferenceBufferNamesArray objectAtIndex:i] trimStr:@" "];
//            reference_BufferName = 
            NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :reference_BufferName];
            if (mReferenceBufferValue == nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No received data"];
                return;
            }
            rangeContainString = [mReferenceBufferValue rangeOfString:mContainString];
            
            
            for (int j = 0; j < [mNotContainStringArray count] ; j++)
            {
                NSString *notContainStringValue =[ToolFun deleteFromString: [mNotContainStringArray objectAtIndex:j] trimStr:@" "];
                rangeNotContainString = [mReferenceBufferValue rangeOfString:notContainStringValue];
                if (rangeNotContainString.length > 0)
                {
                    NSString * failMsg = [NSString stringWithFormat:@"The buffer%d contain Error",i];
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:failMsg];
                    return;
                }
            }
            
            if (rangeContainString.length > 0 )
            {
                if (i == [mReferenceBufferNamesArray count] -1)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:@"Pass"];
                    return;
                }
                else
                    continue;
            
            }
            else
            {
                NSString * failMsg = [NSString stringWithFormat:@"The buffer%d have no respond",i];
                [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:failMsg];
                return;
            }
    
        }
    }
}

+(void)ParseTwoBufferTwoSpecStr:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferName2 = nil;
    NSString *mSpecStr = nil;
    NSString *mSpecStr2 = nil;
    
    for (int i=0; i < [dictKeyDefined count]; i++)
    {
        NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
        
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"SpecStr"])
        {
            mSpecStr = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"SpecStr2"])
        {
            mSpecStr2 = [dictKeyDefined objectForKey:strKey];
        }
    }
    
    if (mReferenceBufferName==nil || mReferenceBufferName2 == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
    }
    
    NSString *mBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    NSString *mBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    
    if (mBufferValue==nil || mBufferValue2 == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"no receive data"];
		return;
    }
    //20151017 peter Chem ID & DF Check
    if ([mTestItemName isEqualTo:@"Static Chem ID Checksum"]||[mTestItemName isEqualTo:@"Static DF Checksum"])
    {
        if([mBufferValue rangeOfString:mSpecStr].length > 0 && [mSpecStr2 rangeOfString:mBufferValue2].length > 0)
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:[NSString stringWithFormat:@"Pass [%@]",mBufferValue2]];
            [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"1":nil:RESULT_FOR_PASS:@"PASS"];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:[NSString stringWithFormat:@"Fail [%@]",mBufferValue2]];
            [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
            return;
        }
        
    }//end
    if([mBufferValue rangeOfString:mSpecStr].length > 0 && [mBufferValue2 rangeOfString:mSpecStr2].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:@"Pass"];
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Fail"];
    }
    
}

+(void)ParseMaxMinusMin:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mReferenceBufferName2=nil;
    NSString *mReferenceBufferName3=nil;
    
	NSString *mBuffferName=nil;
	
	
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName3"])
		{
			mReferenceBufferName3=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}        
	}
    
    if(mReferenceBufferName==nil || mReferenceBufferName2==nil || mReferenceBufferName3==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    NSString *mReferenceBufferValue3 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3] ;
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    mReferenceBufferValue3 = [mReferenceBufferValue3 stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue3 = [mReferenceBufferValue3 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue3 = [mReferenceBufferValue3 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue3 = [mReferenceBufferValue3 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if (mReferenceBufferValue==nil || mReferenceBufferValue2==nil || mReferenceBufferValue3==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    double minV = [mReferenceBufferValue doubleValue];
    double maxV = [mReferenceBufferValue doubleValue];
    
    if([mReferenceBufferValue2 doubleValue] < minV)
        minV = [mReferenceBufferValue2 doubleValue];
    
    if([mReferenceBufferValue3 doubleValue] < minV)
        minV = [mReferenceBufferValue3 doubleValue];
    
    if([mReferenceBufferValue2 doubleValue] > maxV)
        maxV = [mReferenceBufferValue2 doubleValue];
    
    if([mReferenceBufferValue3 doubleValue] > maxV)
        maxV = [mReferenceBufferValue3 doubleValue];
    
    double minusV = maxV - minV;
    
    if (mBuffferName!=nil) 
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%f",minusV]] ;
    
    
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",minusV]] ;
	return;
}

+(void)ParseStrFromMultiBuffer:(NSDictionary*)dictKeyDefined
{
	
	//key parse
	NSString *mTestItemName=nil        ;
	
	NSString *mBufferName=nil    ;
	//NSString *mPDCAWrite =@"no"  ;
	
    //	NSString *mUpLimit = nil;
    //	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        //		else if ([strKey isEqualToString:@"UpperValue"])
        //		{
        //			mUpLimit = [dictKeyDefined objectForKey:strKey];
        //		}
        //		else if ([strKey isEqualToString:@"LowerValue"])
        //		{
        //			mLowLimit = [dictKeyDefined objectForKey:strKey];
        //		}
	}
	
	if (mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
    
    NSArray *bufNameArray = [mBufferName componentsSeparatedByString:@","];
    
    NSString * BufferValue = @"";
    
    for(int i=0; i<[bufNameArray count]; i++)
    {
        BufferValue=[TestItemManage getBufferValue:dictKeyDefined :[bufNameArray objectAtIndex:i]];
        
        BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        if([BufferValue length] > 0)
        {
            NSArray *bufValueArray = [BufferValue componentsSeparatedByString:@","];
            if([bufValueArray count] >= 6)
            {
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"-height %d",(i+1)]:nil:nil:nil:[bufValueArray objectAtIndex:2]:nil:RESULT_FOR_PASS:nil];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"-width %d",(i+1)]:nil:nil:nil:[bufValueArray objectAtIndex:3]:nil:RESULT_FOR_PASS:nil];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"-rising edge slope %d",(i+1)]:nil:nil:nil:[bufValueArray objectAtIndex:4]:nil:RESULT_FOR_PASS:nil];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"-falling edge slope %d",(i+1)]:nil:nil:nil:[bufValueArray objectAtIndex:5]:nil:RESULT_FOR_PASS:nil];
            }
        }
    }
    
    
	if([BufferValue length] > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :BufferValue] ; 
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Fail"] ;
    }
	
}

+(void)MesaCalDataVerifyAtFDRServer:(NSDictionary*)dictKeyDefined
{
	NSString *mTerminalCommand=nil;
	NSString *mSpecStr = nil;
    
	NSString *mBuffferName=nil;
    NSString *mLengthOfMesaSN=nil;
	
	
	
	//NSString *strTestResultForUIinfo ;
	//enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TerminalCommand"])
		{
			mTerminalCommand=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SpecStr"])
		{
			mSpecStr=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"LengthOfMesaSN"])
		{
			mLengthOfMesaSN=[dictKeyDefined objectForKey:strKey];
		}
	}
    
    //    if(mTerminalCommand==nil)
    //    {
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
    //        return;
    //    }
    
    
    NSString *strMesaSNFromBarcode = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
    //NSString *strMesaSNFromBarcode = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
    //NSString *strMesaSNFromBarcode = [TestItemManage getScanValue:dictKeyDefined :@"strBarcodeSn"];
    
    if([mLengthOfMesaSN length] > 0)
    {
        if([strMesaSNFromBarcode length] > mLengthOfMesaSN)
        {
            strMesaSNFromBarcode = [strMesaSNFromBarcode substringToIndex:mLengthOfMesaSN];
        }
    }
    
    if([strMesaSNFromBarcode length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"No Mesa SN, please scan"];
        return;
    }
    
    //NSString * returnFile = @"/vault/FDR_ReturnInfo.txt";
    
    NSString* returnRes = @"";
    
    int resultTimes = 0;
    
    for(int i=0; i<3; i++)
    {
        
        if(i==0)
            mTerminalCommand = @"get -k hop0 -u (mesa module sn) -o vault/output.txt -f -a https://fdruca.apple.com:8443 -d https://fdrds.apple.com:8443 -U http://fdruca.apple.com:8080/fdrtrustobject";
        //mTerminalCommand = @"ls /dev/cu.*";
        //mTerminalCommand = @"ls /dev/cu.*";
        else if(i==1)
            mTerminalCommand = @"get -k FSCl -u (mesa module sn) -o vault/output.txt -f -a https://fdruca.apple.com:8443 -d https://fdrds.apple.com:8443 -U http://fdruca.apple.com:8080/fdrtrustobject";
        //mTerminalCommand = @"ls /dev/cu.*";
        //mTerminalCommand = @"ls /dev/cu.*";
        else if(i==2)
            mTerminalCommand = @"get -k NvMR -u (mesa module sn) -o vault/output.txt -f -a https://fdruca.apple.com:8443 -d https://fdrds.apple.com:8443 -U http://fdruca.apple.com:8080/fdrtrustobject";
        //mTerminalCommand = @"ls /dev/cu.*";
        //mTerminalCommand = @"ls /dev/cu.*";
        
        mTerminalCommand = [mTerminalCommand stringByReplacingOccurrencesOfString:@"(mesa module sn)" withString:strMesaSNFromBarcode];
        
        //mTerminalCommand = [mTerminalCommand stringByAppendingFormat:@" > %@",returnFile];
        
        //mTerminalCommand = [mTerminalCommand stringByAppendingFormat:@" > %@",returnRes];
        
        //mTerminalCommand = @"ls";
        
        //int i = system([mTerminalCommand UTF8String]);
        
        //NSString *filePath = @"/Users/lijiansheng/Desktop/0716/esaCalDataVerifyInFDR.txt\ 2.zip";
        
        NSArray *arguments = [mTerminalCommand componentsSeparatedByString:@" "];
        
        NSString *cmdLineTool = @"/usr/local/bin/fdr_client";
        
        //NSString *sha1Value = [self runCMD:@"/usr/bin/openssl sha1" argument:[NSArray arrayWithObjects:@"sha1",filePath,nil]];
        NSString *returnRes = [self runCMD:cmdLineTool argument:arguments];
        
        //NSString *sha1Value = [self runCMD:@"/usr/local/bin/astris" argument:[NSArray arrayWithObjects:@"-l",nil]];
        
        usleep(200000);
        
        //returnRes = [NSString stringWithContentsOfFile:returnFile encoding:NSASCIIStringEncoding error:nil];
        
        NSString *wholdCmd = [cmdLineTool stringByAppendingString:@" "];
        wholdCmd = [wholdCmd stringByAppendingString:mTerminalCommand];;
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :wholdCmd] ;
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :returnRes] ;
        
        if([returnRes length] <= 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Get Infamation from FDR server fail"] ;
            return;
        }
        
        
        
        if([returnRes rangeOfString:mSpecStr].length > 0)
        {
            resultTimes++;
        }
    }
    
    if(resultTimes == 3)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"1"] ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"0"] ;
    }
    
    if (mBuffferName!=nil) 
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :returnRes] ;
    
    
}

+(NSString *)runCMD:(NSString *)cmd argument:(NSArray *)argument
{
    NSTask *mtask = [[NSTask alloc] init];
    [mtask setLaunchPath: cmd];
    
    NSArray *arguments;
    arguments = argument;
    [mtask setArguments: arguments];
    NSPipe *mpipe = [NSPipe pipe];
    [mtask setStandardOutput: mpipe];
    
    NSFileHandle *file;
    file = [mpipe fileHandleForReading];
    
    [mtask launch];
    NSData *data = [file readDataToEndOfFile];
    NSString *string;
    string = [[NSString alloc] initWithData: data
                                   encoding: NSUTF8StringEncoding];
    
    NSString *tmp = @"\n[first time]\n";
    NSString *aa = [NSString stringWithString:string];
    aa = [tmp stringByAppendingString:aa];
    
    if([aa length] <= 0)
    {
        NSTask *mtask2 = [[NSTask alloc] init];
        [mtask2 setLaunchPath: cmd];
        [mtask2 setArguments: arguments];
        NSPipe *mpipe2 = [NSPipe pipe];
        [mtask2 setStandardError: mpipe2];
        [mtask2 launch];
        
        
        NSFileHandle *file2;
        file2 = [mpipe2 fileHandleForReading];
        data = [file2 readDataToEndOfFile];
        
        NSString *string2 = [[NSString alloc] initWithData: data
                                                  encoding: NSUTF8StringEncoding];
        
        tmp = @"\n[second time]\n";
        aa = [NSString stringWithString:string2];
        aa = [tmp stringByAppendingString:aa];
        [string2 release];
        [mtask2 release];
    }
    
    [string release];
    [mtask release];
    
    return aa;
}

+(void)ShowBarcode:(NSDictionary*)dictKeyDefined
{
    
	NSString *mSpecStr = nil;
    
	NSString *mBuffferName=nil;
    NSString *mLengthOfMesaSN=nil;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"SpecStr"])
		{
			mSpecStr=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"LengthOfMesaSN"])
		{
			mLengthOfMesaSN=[dictKeyDefined objectForKey:strKey];
		}
	}
    
    NSString *strMesaSNFromBarcode = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
    //NSString *strMesaSNFromBarcode = [TestItemManage getScanValue:dictKeyDefined :@"strBarcodeSn"];
    
    
    strMesaSNFromBarcode = [strMesaSNFromBarcode stringByReplacingOccurrencesOfString:@" " withString:@""];
    strMesaSNFromBarcode = [strMesaSNFromBarcode stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    strMesaSNFromBarcode = [strMesaSNFromBarcode stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    strMesaSNFromBarcode = [strMesaSNFromBarcode stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    
    if([strMesaSNFromBarcode length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"No barcode, please scan"];
        //return;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:strMesaSNFromBarcode];
    }
    
    
    if (mBuffferName!=nil) 
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :strMesaSNFromBarcode] ;
    
    
}

+(void)ParseSubStringHexValue:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBuffferName=nil;
    
	NSString *mLowerValue=nil;
    NSString *mUpperValue=nil;
    NSString *mPrefix=nil;
    NSString *mPostfix=nil;
    NSString *mSubStringLength=@"2";
    NSString *mStartStringLocation=nil;  //added by Annie for RX P3 battery pack info 2014.9.04
    NSString *mDivide=@"";
    
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SubStringLength"])
		{
			mSubStringLength=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"StartStringLocation"])
		{
			mStartStringLocation=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"Divide"])
		{
			mDivide=[dictKeyDefined objectForKey:strKey];
		}
	}
    
    if(mReferenceBufferName==nil|| mStartStringLocation==nil || mSubStringLength==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //debug start
    //mReferenceBufferValue=@"Class 59, Block 0:0000000: 02 D8 00 DC 10 F8 0E 83 09 03 EC C7 01 51 00 00  .............Q..     0000010: 26 9F 13 88 00 1E 00 02 FB D8 F6 F0 28 E6 13 88  &...........(...  OK";
    
    //debug end
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
    
    if([strFind length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"get prefix and postfix fail"] ;
        return ;
    }
    
    //Added by Annie 2014.9.04  for battery pack information
    if([strFind length] < [mSubStringLength intValue] || [strFind length] <[mStartStringLocation intValue])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"get value fail"] ;
        return ;
    }
    NSString *stringV = [strFind substringFromIndex:[mStartStringLocation intValue]];
    stringV = [stringV substringToIndex:[mSubStringLength intValue]];
    
    
    char* stopEnd;
    double resultValue = (int)strtol([stringV UTF8String], &stopEnd, 16);
    if ([mTestItemName isEqualToString:@"Max battery dsg current"]) {
        resultValue=-(65536-resultValue);
    }
    //----------Added end------------------------------------------
    
    if([mDivide length] > 0)
    {
        if([mDivide doubleValue] != 0)
            resultValue = resultValue / [mDivide doubleValue];
    }
    
    
    if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue doubleValue]))
       && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",resultValue]] ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",resultValue]] ;
    }
    
    if (mBuffferName!=nil)
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%f",resultValue]] ;
    
}

//add by kevin for ct1 & ct3 "Orb Init" testitem 20150205
+(void)ParseThreeBufferThreeSpecStr:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferName2 = nil;
    NSString *mReferenceBufferName3 = nil;
    NSString *mSpecStr = nil;
    NSString *mSpecStr2 = nil;
    NSString *mSpecStr3 = nil;
    
    for (int i=0; i < [dictKeyDefined count]; i++)
    {
        NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
        
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName3"])
        {
            mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"SpecStr"])
        {
            mSpecStr = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"SpecStr2"])
        {
            mSpecStr2 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"SpecStr3"])
        {
            mSpecStr3 = [dictKeyDefined objectForKey:strKey];
        }
    }
    
    if (mReferenceBufferName==nil || mReferenceBufferName2 == nil || mReferenceBufferName3 == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
    }
    
    NSString *mBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    NSString *mBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    NSString *mBufferValue3 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3];
    
    if (mBufferValue==nil || mBufferValue2 == nil || mBufferValue3 == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"no receive data"];
		return;
    }
    
    if([mBufferValue rangeOfString:mSpecStr].length > 0 && [mBufferValue2 rangeOfString:mSpecStr2].length > 0 && [mBufferValue3 rangeOfString:mSpecStr3].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:@"Pass"];
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Fail"];
    }
    
}
//for SL QT1 Strobe test with CL200a communicate with visual RS232port----Added by Annie 2015.5.31
+(void)StrobeCL200A_SL:(NSDictionary*) DictionaryPtr
{
    NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mColorBuffferEv=nil;
    NSString *mColorBuffferX=nil;
    NSString *mColorBuffferY=nil;
    
    
    for(int i=0;i<[DictionaryPtr count];i++)
    {
        NSString *strKey=[[DictionaryPtr allKeys] objectAtIndex:i];
        if([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferEv"])
        {
            mColorBuffferEv=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferX"])
        {
            mColorBuffferX=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferY"])
        {
            mColorBuffferY=[DictionaryPtr objectForKey:strKey];
        }
    }
    NSString *imPathStr=@"/vault/pyserial-2.5/CL200A.py";
    NSString *outPartStr=@"/vault/cl200Log.txt";
    NSString *pyPathStr=[NSString stringWithFormat:@"python %@ > %@",imPathStr,outPartStr];
    system([pyPathStr UTF8String]);
    usleep(8000);
    
    //-------------Read value form cl200Log.txt and parase-----------------------------
    //    NSFileManager *fileManager;
    //    if ([fileManager fileExistsAtPath:outPartStr])
    //    {
    //        NSLog(@"CL200ALog file did not exsit");
    //        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"CL200ALog file did not exsit"];
    //        return;
    //    }
    NSString*  cl200aLogStr=[NSString stringWithContentsOfFile:outPartStr encoding:NSASCIIStringEncoding error:nil];
    if (cl200aLogStr==nil)
    {
        NSLog(@"no data in CL200ALog file");
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"no data in CL200ALog file"];
        return;
    }
    if ([cl200aLogStr rangeOfString:@"0002"].location<=0)
    {
        NSLog(@"invalid data in CL200ALog file");
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"invalid data in CL200ALog file"];
        return;
    }
    NSString *valueStr=[pubFun getStrFromPrefixAndPostfix:cl200aLogStr Prefix:@"0002" Postfix:@"0003"];
    if (valueStr==nil)
    {
        NSLog(@"invalid data CL200A");
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"invalid data CL200A"];
        return;
    }
    //------------------Get color Ev value ----------------------------
    NSString *symbol1=[valueStr substringFromIndex:4];
    symbol1=[symbol1 substringToIndex:1];
    NSString *valueEvStr=[valueStr substringFromIndex:5];
    valueEvStr=[valueEvStr substringToIndex:4];
    NSString *by1=[valueStr substringFromIndex:9];
    by1=[by1 substringToIndex:1];
    
    float ValueEv=[valueEvStr floatValue]/10000;
    for (int i=0; i<[by1 intValue]; i++)
    {
        ValueEv=ValueEv*10;
    }
    if ([symbol1 isEqualTo:@"-"])
    {
        ValueEv=-ValueEv;
    }else if ([symbol1 isEqualTo:@"="])
    {
        ValueEv=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferEv :[NSString stringWithFormat:@"%f",ValueEv]];
    
    //------------------Get color X value -----------------------------
    NSString *symbol2=[valueStr substringFromIndex:10];
    symbol2=[symbol2 substringToIndex:1];
    NSString *valueXStr=[valueStr substringFromIndex:11];
    valueXStr=[valueXStr substringToIndex:4];
    NSString *by2=[valueStr substringFromIndex:15];
    by2=[by2 substringToIndex:1];
    
    float ValueX=[valueXStr floatValue]/10000;
    for (int i=0; i<[by2 intValue]; i++)
    {
        ValueX=ValueX*10;
    }
    if ([symbol2 isEqualTo:@"-"])
    {
        ValueX=-ValueX;
    }else if ([symbol2 isEqualTo:@"="])
    {
        ValueX=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferX :[NSString stringWithFormat:@"%f",ValueX]];
    //------------------Get color Y value -----------------------------
    NSString *symbol3=[valueStr substringFromIndex:16];
    symbol3=[symbol3 substringToIndex:1];
    NSString *valueYStr=[valueStr substringFromIndex:17];
    valueYStr=[valueYStr substringToIndex:4];
    NSString *by3=[valueStr substringFromIndex:21];
    by3=[by3 substringToIndex:1];
    
    float ValueY=[valueYStr floatValue]/10000;
    for (int i=0; i<[by3 intValue]; i++)
    {
        ValueY=ValueY*10;
    }
    if ([symbol3 isEqualTo:@"-"])
    {
        ValueY=-ValueY;
    }else if ([symbol3 isEqualTo:@"="])
    {
        ValueY=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferY :[NSString stringWithFormat:@"%f",ValueY]];
    
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS:@"PASS"];
}

//add by Justin Shang @20151019
+(void)StrobeCL200A_SL2:(NSDictionary*) DictionaryPtr
{
    NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mColorBuffferEv=nil;
    NSString *mColorBuffferX=nil;
    NSString *mColorBuffferY=nil;
    
    
    for(int i=0;i<[DictionaryPtr count];i++)
    {
        NSString *strKey=[[DictionaryPtr allKeys] objectAtIndex:i];
        if([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferEv"])
        {
            mColorBuffferEv=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferX"])
        {
            mColorBuffferX=[DictionaryPtr objectForKey:strKey];
        }else if([strKey isEqualToString:@"ColorBuffferY"])
        {
            mColorBuffferY=[DictionaryPtr objectForKey:strKey];
        }
    }
    
    NSString *valueStr = nil;
    NSString *strDutId=[DictionaryPtr objectForKey:@"DUTID"];
    NSLog(@"DUTID=%@",strDutId);
    if ([strDutId isEqualToString:@"1"])
    {
        for (int i = 0; i<10; ++i)
        {
            
            
            
            //------------------CL200A Communication ----------------------------
            if (CL200AInitFlag)
            {
                CL200AInitFlag = NO;
                BOOL flag = [ParseCL200AData OpenSerialPort];
                if (flag == 0)
                {
                    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"Connect to CL200A device failed !"];
                    CL200AInitFlag = YES;
                    [ParseCL200AData CloseSerialPort];
                    return;
                }
                BOOL conFlag=[ParseCL200AData CL200AInitialize];
                if (!conFlag)
                {
                    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"Initialize CL200A failed,pls repower on CL200A !"];
                    CL200AInitFlag = YES;
                    [ParseCL200AData CloseSerialPort];
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert setAlertStyle:NSInformationalAlertStyle];
                    [alert setMessageText:@"Please repower on CL200A"];
                    [alert addButtonWithTitle:@"Stop test!"];
                    [alert runModal];
                    [alert release];
                    exit(0);
                    
                }
                usleep(100000);
            }
            
            
            valueStr = [ParseCL200AData CL200APerformMeasurement];
            
            
            if (valueStr == nil)
            {
                //[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"CL200A measeure failed,Pls reopen iFTS!"];
                CL200AInitFlag=YES;
                usleep(1000000);
                [ParseCL200AData CloseSerialPort];
                NSLog(@"ValueStr is nil %d times",i);
                continue;
            }else
            {
                break;
            }
        }
        if (CL200AInitFlag)
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"CL200A measeure failed,Pls reopen iFTS!"];
            [ParseCL200AData CloseSerialPort];
            return;
        }
    }else if([strDutId isEqualToString:@"2"])
    {
        for (int i = 0; i<10; ++i)
        {
            
            
            
            //------------------CL200A Communication ----------------------------
            if (CL200A_SecInitFlag)
            {
                CL200A_SecInitFlag = NO;
                BOOL flag = [ParseCL200AData OpenSecSerialPort];
                if (flag == 0)
                {
                    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"Connect to CL200A device failed !"];
                    CL200A_SecInitFlag = YES;
                    [ParseCL200AData CloseSecSerialPort];
                    return;
                }
                BOOL conFlag=[ParseCL200AData CL200ASecInitialize];
                if (!conFlag)
                {
                    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"Initialize CL200A failed,pls repower on CL200A !"];
                    CL200A_SecInitFlag = YES;
                    [ParseCL200AData CloseSecSerialPort];
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert setAlertStyle:NSInformationalAlertStyle];
                    [alert setMessageText:@"Please repower on CL200A"];
                    [alert addButtonWithTitle:@"Stop test!"];
                    [alert runModal];
                    [alert release];
                    exit(0);
                    
                }
                usleep(100000);
            }
            
            
            valueStr = [ParseCL200AData CL200ASecPerformMeasurement];
            
            
            if (valueStr == nil)
            {
                //[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"CL200A measeure failed,Pls reopen iFTS!"];
                CL200A_SecInitFlag=YES;
                usleep(1000000);
                [ParseCL200AData CloseSecSerialPort];
                NSLog(@"ValueStr is nil %d times",i);
                continue;
            }else
            {
                break;
            }
        }
        if (CL200A_SecInitFlag)
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"CL200A measeure failed,Pls reopen iFTS!"];
            [ParseCL200AData CloseSecSerialPort];
            return;
        }
    }
    //------------------Get color Ev value ----------------------------
    NSString *symbol1=[valueStr substringFromIndex:9];
    symbol1=[symbol1 substringToIndex:1];
    NSString *valueEvStr=[valueStr substringFromIndex:10];
    valueEvStr=[valueEvStr substringToIndex:4];
    NSString *by1=[valueStr substringFromIndex:14];
    by1=[by1 substringToIndex:1];
    
    float ValueEv=[valueEvStr floatValue]/10000;
    for (int i=0; i<[by1 intValue]; i++)
    {
        ValueEv=ValueEv*10;
    }
    if ([symbol1 isEqualTo:@"-"])
    {
        ValueEv=-ValueEv;
    }else if ([symbol1 isEqualTo:@"="])
    {
        ValueEv=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferEv :[NSString stringWithFormat:@"%f",ValueEv]];
    
    //------------------Get color X value -----------------------------
    NSString *symbol2=[valueStr substringFromIndex:15];
    symbol2=[symbol2 substringToIndex:1];
    NSString *valueXStr=[valueStr substringFromIndex:16];
    valueXStr=[valueXStr substringToIndex:4];
    NSString *by2=[valueStr substringFromIndex:20];
    by2=[by2 substringToIndex:1];
    
    float ValueX=[valueXStr floatValue]/10000;
    for (int i=0; i<[by2 intValue]; i++)
    {
        ValueX=ValueX*10;
    }
    if ([symbol2 isEqualTo:@"-"])
    {
        ValueX=-ValueX;
    }else if ([symbol2 isEqualTo:@"="])
    {
        ValueX=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferX :[NSString stringWithFormat:@"%f",ValueX]];
    //------------------Get color Y value -----------------------------
    NSString *symbol3=[valueStr substringFromIndex:21];
    symbol3=[symbol3 substringToIndex:1];
    NSString *valueYStr=[valueStr substringFromIndex:22];
    valueYStr=[valueYStr substringToIndex:4];
    NSString *by3=[valueStr substringFromIndex:26];
    by3=[by3 substringToIndex:1];
    
    float ValueY=[valueYStr floatValue]/10000;
    for (int i=0; i<[by3 intValue]; i++)
    {
        ValueY=ValueY*10;
    }
    if ([symbol3 isEqualTo:@"-"])
    {
        ValueY=-ValueY;
    }else if ([symbol3 isEqualTo:@"="])
    {
        ValueY=0.0;
    }
    [TestItemManage setBufferValue:DictionaryPtr :mColorBuffferY :[NSString stringWithFormat:@"%f",ValueY]];
    
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS:@"PASS"];
}
@end
