//
//  ParseStrWithBetweenNumberFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseStrWithBetweenNumberFunction.h"


@implementation TestItemParse(ParseStrWithBetweenNumberFunction)


+(void)ParseStrWithBetweenNumber:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mLower				= nil    ;
	NSString *mUpper				= nil    ;
	NSString *mReferenceBufferName1	= nil    ;
	NSString *mReferenceBufferName2	= nil    ;
	NSString *mTestItemName			= nil    ;
    NSString *mNumberType           = nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLower = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpper = [DictionaryPtr objectForKey:strKey] ;
		}
        else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[DictionaryPtr objectForKey:strKey];
		}
		
	}
	if (mReferenceBufferName1==nil || mReferenceBufferName2==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error!"] ;
		return;
	}
	
	NSString *buffervalue1 = nil;
	NSString *buffervalue2 = nil;
    
	
	buffervalue1 = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName1] ;
	buffervalue2 = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName2] ;
	//buffervalue1=@"25.36";
	//buffervalue2=@"355.61";
	if (buffervalue1==nil || buffervalue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
		return;
	}
    if ([buffervalue2 rangeOfString:@"Not been triggered, bypass this item"].length > 0)
	{
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Not been triggered, bypass this item"] ;
        return;
	}
	if([mNumberType isEqualToString:@"double"]) //judith add  2012-06-01
    {
        float fsubtract = [buffervalue2 floatValue] -[buffervalue1 floatValue];
        fsubtract = fsubtract > 0 ? fsubtract : -fsubtract;
        if(((mLower==nil||[mLower length]<=0)?1:(fsubtract >=[mLower doubleValue]))
		   && ((mUpper==nil||[mUpper length]<=0)?1:(fsubtract<=[mUpper doubleValue])))
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :[NSString stringWithFormat:@"%0.3f",fsubtract]] ;
		}
        else 
		{
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%0.3f",fsubtract]] ;
		}
    }
    else
    {
        int isubtract = [buffervalue2 intValue] -[buffervalue1 intValue];
        
        if(((mLower==nil||[mLower length]<=0)?1:(isubtract >=[mLower intValue]))
		   && ((mUpper==nil||[mUpper length]<=0)?1:(isubtract<=[mUpper intValue])))
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",isubtract]] ;
            
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",isubtract]] ;
            
        }
	}
	return;
	
}


@end
