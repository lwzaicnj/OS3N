/************************************************************
 //  UIWinManage.m
 //  For UI use
 //  Created  on 5/12/10.
 //  
 //  All rights reserved.
 *************************************************************/

#import "UIWinManage.h"
#include <copyfile.h>
#import "pubFun.h"
#import "keysDefine.h"
#import "testItemManage.h"
#import "scriptParse.h"
#import "testItemParse.h"

NSMutableArray *uiWinManageInfo=nil ;
@implementation UIWinManage

+(bool)UIWinManageInitProxCalTest
{	
	if (uiWinManageInfo!=nil)
	{
		[uiWinManageInfo release] ;
		uiWinManageInfo = nil ;
	}
	
	NSArray *arrayDeviceID = [ScriptParse getDeviceIDList] ;
	NSLog(@"\n  arrayDeviceID = %@ \n",arrayDeviceID) ;
	if([arrayDeviceID count] < 2)
	{
		return false ;
	}
	
	NSString *strUnitDevice=nil;
	uiWinManageInfo = [[NSMutableArray alloc] init] ;
	NSMutableArray *mutFixtureList = [[[NSMutableArray alloc] init] autorelease] ;
	for(int i=1; i<3; i++)
	{
		NSMutableDictionary *mutDictTmpDutID = [[NSMutableDictionary alloc] init]  ;
		[mutDictTmpDutID setObject:[NSString stringWithFormat:@"%d",i] forKey:@"BelongToDUT"] ;
		[uiWinManageInfo addObject:mutDictTmpDutID] ; 
		[mutDictTmpDutID release];
	}
	
	for(int i=0 ;i<[arrayDeviceID count] ;i++)
	{
		NSString *strTmp = [arrayDeviceID objectAtIndex:i] ;
		NSRange rangeTmp = [strTmp rangeOfString:@"IPhone"] ;
		if (rangeTmp.length <= 0)
			rangeTmp = [strTmp rangeOfString:@"IPod"] ;
		
		if (rangeTmp.length <= 0)
			rangeTmp = [strTmp rangeOfString:@"IPad"] ;
		
		if (rangeTmp.length <= 0)//Fixture
			[mutFixtureList addObject:strTmp] ;	
		else //IPad
			strUnitDevice = strTmp;
	}
	
	for(int i=0 ;i<[uiWinManageInfo count] ;i++)
	{
		NSMutableDictionary *mutWinInfo = [uiWinManageInfo objectAtIndex:i] ;
		
		[mutWinInfo setObject:strUnitDevice forKey:@"UNITDevice"] ;
		[mutWinInfo setObject:mutFixtureList forKey:@"FixtureDevice"] ;
		[mutWinInfo setObject:@"1" forKey:@"BelongToTester"] ;
	}
	NSLog(@"\n--------uiWinManageInfo=%@----------\n",uiWinManageInfo) ;
	
	if ([uiWinManageInfo count] < 2)
		return false ;
	
	return true ;
}
+(bool)UIWinManageInitProxCal
{	
	if (uiWinManageInfo!=nil)
	{
		[uiWinManageInfo release] ;
		uiWinManageInfo = nil ;
	}
	
	NSArray *arrayDeviceID = [ScriptParse getDeviceIDList] ;
	NSLog(@"\n  arrayDeviceID = %@ \n",arrayDeviceID) ;
	if([arrayDeviceID count] < 3)
	{
		return false ;
	}
	
	NSString *strUnitDevice=nil;
	uiWinManageInfo = [[NSMutableArray alloc] init] ;
	NSMutableArray *mutFixtureList = [[[NSMutableArray alloc] init] autorelease] ;
	for(int i=1; i<4; i++)
	{
		NSMutableDictionary *mutDictTmpDutID = [[NSMutableDictionary alloc] init]  ;
		[mutDictTmpDutID setObject:[NSString stringWithFormat:@"%d",i] forKey:@"BelongToDUT"] ;
		[uiWinManageInfo addObject:mutDictTmpDutID] ; 
		[mutDictTmpDutID release];
	}
	
	for(int i=0 ;i<[arrayDeviceID count] ;i++)
	{
		NSString *strTmp = [arrayDeviceID objectAtIndex:i] ;
		NSRange rangeTmp = [strTmp rangeOfString:@"IPhone"] ;
		if (rangeTmp.length <= 0)
			rangeTmp = [strTmp rangeOfString:@"IPod"] ;
		
		if (rangeTmp.length <= 0)
			rangeTmp = [strTmp rangeOfString:@"IPad"] ;
		
		if (rangeTmp.length <= 0)//Fixture
			[mutFixtureList addObject:strTmp] ;	
		else //IPad
			strUnitDevice = strTmp;
	}
	
	for(int i=0 ;i<[uiWinManageInfo count] ;i++)
	{
		NSMutableDictionary *mutWinInfo = [uiWinManageInfo objectAtIndex:i] ;
		
		[mutWinInfo setObject:strUnitDevice forKey:@"UNITDevice"] ;
		[mutWinInfo setObject:mutFixtureList forKey:@"FixtureDevice"] ;
		[mutWinInfo setObject:@"1" forKey:@"BelongToTester"] ;
	}
	NSLog(@"\n--------uiWinManageInfo=%@----------\n",uiWinManageInfo) ;
	
	if ([uiWinManageInfo count] < 3)
		return false ;
	
	return true ;
}

+(bool)UIWinManageInit
{	
	if (uiWinManageInfo!=nil)
	{
		[uiWinManageInfo release] ;
		uiWinManageInfo = nil ;
	}
	
	NSArray *arrayDeviceID = [ScriptParse getDeviceIDList] ;
	NSLog(@"\n  arrayDeviceID = %@ \n",arrayDeviceID) ;
	if (arrayDeviceID!=nil)
	{
		uiWinManageInfo = [[NSMutableArray alloc] init] ;
        
		for(int i=0 ;i<[arrayDeviceID count] ;i++)
		{
			NSString *strTmp = [arrayDeviceID objectAtIndex:i] ;
			NSRange rangeTmp = [strTmp rangeOfString:@"IPad"] ;
			
            
			if (rangeTmp.length > 0)
			{
				NSMutableDictionary *mutDictTmp = [[NSMutableDictionary alloc] init]  ;
				[mutDictTmp setObject:strTmp forKey:@"UNITDevice"] ;
				//read dutid,belongToTester
				NSString *strBelongAndDudid=[strTmp substringFromIndex:rangeTmp.location+rangeTmp.length] ;
                if (strBelongAndDudid==nil ||
					[strBelongAndDudid length]<2)
				{
					[mutDictTmp release] ;
					return false;
				} ;
				
				NSString *strBelongToTester = [strBelongAndDudid substringToIndex:1];
				NSString *strDUTID = nil;
				if ([strBelongToTester isEqualToString:@"1"])
					strDUTID = [strBelongAndDudid substringFromIndex:1];
				else
					strDUTID = [NSString stringWithString:strBelongToTester] ;
				
				[mutDictTmp setObject:strBelongToTester forKey:@"BelongToTester"] ;
				[mutDictTmp setObject:strDUTID forKey:@"BelongToDUT"] ;
				
				[uiWinManageInfo addObject:mutDictTmp] ; 
				[mutDictTmp release] ;
			}
            
		}
		
		if ([uiWinManageInfo count]<1)
			return false ;
		
		
        for(int i=0 ;i<[uiWinManageInfo count] ;i++)
        {
            NSMutableDictionary *mutWinInfo = [uiWinManageInfo objectAtIndex:i] ;
            
            if (mutWinInfo==nil)
                return false ;
            NSString* DutTester=[mutWinInfo objectForKey:@"BelongToTester"];
            DutTester = [DutTester stringByAppendingString:[mutWinInfo objectForKey:@"BelongToDUT"]];
            NSMutableArray *mutArrayFixtureList = [[[NSMutableArray alloc] init] autorelease] ;
            
            for(int i=0 ;i<[arrayDeviceID count] ;i++)
            {
                NSString *deviceID = [arrayDeviceID objectAtIndex:i] ;
                
                if([deviceID rangeOfString:@"IPad"].length <= 0 && [deviceID rangeOfString:DutTester].length > 0)
                {
                    [mutArrayFixtureList addObject:deviceID] ;	
                }
            }
            
            [mutWinInfo setObject:mutArrayFixtureList forKey:@"FixtureDevice"]; 
        }
        
		
		NSLog(@"\n--------%@----------\n",uiWinManageInfo) ;
		return true ;
		
	}else
		return false ;
}


+(void)UIWin_UnlockScript //add by Annie for unlocking script
{
    [NSBundle loadNibNamed:@"UI_LockScript" owner:self];
	return ;
}

+(void)UIWinSeleToRun
{
	//NSApp = [NSApplication sharedApplication];
//	[self compareFileModifyTime];//dsx 0602	
	NSString *strTmp = [ScriptParse getValueFromSummary:@"SwitchUI"] ;
	if (strTmp==nil)
		strTmp=@"UI1QT1440X900" ;
	else
	{
		if ([strTmp isEqualToString:@"UI1"])
			strTmp=@"UI1QT1440X900" ;
        else if ([strTmp isEqualToString:@"UI1024"])
			strTmp=@"UI1QT1024X768" ;
		else if ([strTmp isEqualToString:@"UI4"])
			strTmp=@"UI4GK1440X900" ;
		else if ([strTmp isEqualToString:@"UI4DOE"])  
			strTmp=@"UI4DOE1440X900" ;
        else if ([strTmp isEqualToString:@"UI4M"])
			strTmp=@"UI4M1440X900" ;//add by kevin for RL QT0a
		else if ([strTmp isEqualToString:@"UI1M"])
			strTmp=@"UI1M1440X900" ;
		else if ([strTmp isEqualToString:@"UI1M2"])
			strTmp=@"UI1M1280X720" ;
		else if ([strTmp isEqualToString:@"UI3"])
			strTmp=@"UI3QT1440X900" ;
		else if ([strTmp isEqualToString:@"UI3Prox"])   
			strTmp=@"UI3Prox1440X900" ;
		else if ([strTmp isEqualToString:@"UI1GaussDOE"])  //SCRID:77 Owner: Helen  DATE:04.02.2011 added for Megneti Retention
			strTmp=@"UI1GaussDOE1440X900" ;
		else if ([strTmp isEqualToString:@"UI1GAUSS"])  //SCRID:025 Owner: Helen  DATE:11.30.2010 added for Megneti Retention
			strTmp=@"UIGaussMeter" ;
		else if ([strTmp isEqualToString:@"UI2QT"])
			strTmp=@"UI2QT1440X900" ;
		else if ([strTmp isEqualToString:@"UI2"])
			strTmp=@"UI2M1440X900" ;
		else if ([strTmp isEqualToString:@"UI2S"])
			strTmp=@"UI2M1280X720" ;
		else if ([strTmp isEqualToString:@"UIAUTO"])  //SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
			strTmp=@"UI1QT1440X900AutoTest" ;
		// add by Evan on 2011-08-08
		else if ([strTmp isEqualToString:@"UISensor"])
			strTmp = @"UISensor1020X640";
        else if ([strTmp isEqualToString:@"HSG"])
			strTmp = @"UI_HSG";

		// add end;
		else
			strTmp=@"UI1QT1440X900" ;
	}
	[NSBundle loadNibNamed:strTmp owner:self];
	return ;
}

//UI data related function
+(int)getTestItemTotal //get the test item summary
{
	return [TestItemManage getTestItemCount] ;
}

+(id)getTestItemUIName:(int)rowIndex
{
	if (rowIndex>=[self getTestItemTotal])
		return nil ;
	return [TestItemManage getTestItem:rowIndex] ;
}

+(id)getTestItemUIResult:(int)DUTID :(int)rowIndex
{
	if (rowIndex>=[self getTestItemTotal])
		return nil ;
	return [TestItemManage getTestItemResultForUI:DUTID row:rowIndex] ;
}

+(NSArray*)getTestItemResult:(int)DUTID :(int)rowIndex //get the test item test result
{
	if (rowIndex>=[self getTestItemTotal])
		return nil ;

	return [TestItemManage getTestItemResult:DUTID row:rowIndex] ;	
}

+(NSArray*)getTotalUnitInfo
{
	if (uiWinManageInfo==nil)
		return nil ;
	NSMutableArray* mutArrTmp=[[[NSMutableArray alloc] init] autorelease] ;
	for(int i=0 ;i<[uiWinManageInfo count] ;i++)
	{
		NSDictionary* dictTmp = [uiWinManageInfo objectAtIndex:i] ;
		if (dictTmp==nil)
			return nil;
		NSString *strDUTID = [dictTmp objectForKey:@"BelongToDUT"] ;
		if (strDUTID==nil)
			return nil ;
		[mutArrTmp addObject:strDUTID] ;
	}
	return mutArrTmp ;
}

+(bool)startTest:(int)DUTID:(NSTableView*)tableView :(NSTextField*)testITemTime:(NSTextField*)testTotalTime:(NSTextField*)showPassorFail:(bool)bDirection ScanData:(NSDictionary*)ScanDataParm
{
	if ([self isCheckDUTID:DUTID])
	{
		NSRunAlertPanel(@"WARNNING", @"Test is on going !!!", @"prompt", nil, nil) ;
		return false;
	}
	if (tableView==nil ||
		testTotalTime==nil ||
		testITemTime==nil ||
		showPassorFail ==nil 
		)
	{
		NSRunAlertPanel(@"WARNNING", @"refresh object don't empty", @"prompt", nil, nil) ;
		return false;
	}
	//get the DUTID'S related parameter ....
	NSDictionary *dictTmp = [self getDUTIDDeviceParameter:DUTID] ;
	if (dictTmp==nil)
	{
		NSRunAlertPanel(@"WARNNING", @"UI Windows don't initialize", @"prompt", nil, nil) ;
		return false;	
	}
	
	[TestItemManage StartTest:tableView :testITemTime:testTotalTime:showPassorFail:dictTmp:bDirection:ScanDataParm] ;
	
	return true ;
} ;

+(bool)stopTest:(int)DUTID
{
	[TestItemManage StopTest:DUTID] ;
	if ([self isCheckDUTID:DUTID]) //no finish
	{
		NSRunAlertPanel(@"WARNNING", @"test is on going, wait for mement will Stop ", @"prompt", nil, nil) ;
		return false;		
	}
	return true ;
}

+(bool)isCheckDUTID:(int)DUTID
{
	return [TestItemManage CheckThreadRun:DUTID] ;
};

+(bool)getUnit:(int)DUTID
{
	NSString *strCheckDiagMode = [ScriptParse getValueFromSummary:STRKEYCHECKDIAGMODE] ;
	if (strCheckDiagMode==nil)
		strCheckDiagMode = @"no" ;
	
	if ([strCheckDiagMode boolValue])
		return [self getUnitInDiags:DUTID] ;
	else
		return [self getUnitInIBoot:DUTID] ;
}

+(NSString*)getUnitSN:(int)DUTID: (NSString*)command
{
	//NSString *strCheckDiagMode = [ScriptParse getValueFromSummary:STRKEYCHECKDIAGMODE] ;
	//if (strCheckDiagMode==nil)
	//	strCheckDiagMode = @"no" ;
	
	//if ([strCheckDiagMode boolValue])
	//return [self getUnitInDiags:DUTID] ;
	//else
	//	return [self getUnitInIBoot:DUTID] ;
	
	//get the DUTID'S related parameter ....
	NSDictionary *dictTmp = [self getDUTIDDeviceParameter:DUTID] ;
	
	NSLog(@"%@",dictTmp);
	if (dictTmp==nil)
		return false;
	
	NSString *strDevice = [dictTmp objectForKey:@"UNITDevice"];
	if (strDevice==nil)
		return false ;
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	
	return [TestItemParse CheckUnitSNExist:strDevice:strTmp:command] ;
}
/*
+(NSString*)getUnitSN:(int)DUTID: (NSString*)command
{
	//get the DUTID'S related parameter ....
	NSDictionary *dictTmp = [self getDUTIDDeviceParameter:DUTID] ;
	
	NSLog(@"%@",dictTmp);
	if (dictTmp==nil)
		return false;
	
	NSString *strDevice = [dictTmp objectForKey:@"UNITDevice"];
	if (strDevice==nil)
		return false ;
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	
	return [TestItemParse CheckUnitSNExist:strDevice:strTmp:command] ;
}
*/
+(bool)OpenAllPort
{
	//check all unit whether run 
	if (uiWinManageInfo!=nil)
	{
		for(NSDictionary* item in uiWinManageInfo)
		{
			NSString *strDUTID = [item objectForKey:@"BelongToDUT"] ;
			if (strDUTID==nil)
				return FALSE ;
			if ([self isCheckDUTID:[strDUTID intValue]]) //no finish
				return false;
		}
	}
	
	return [TestItemParse testItemParseInit] ;
}

+(bool)CloseAllPort
{
	//check all unit whether run 
	if (uiWinManageInfo!=nil)
	{
		for(NSDictionary* item in uiWinManageInfo)
		{
			NSString *strDUTID = [item objectForKey:@"BelongToDUT"] ;
			if (strDUTID==nil)
				return FALSE ;
			if ([self isCheckDUTID:[strDUTID intValue]]) //no finish
				return false;
		}
	}
	
	[TestItemParse testItemParseRelease] ;
	return true ;
}

+(bool)getUnitInDiags:(int)DUTID  //check unit whether exit through DUTID.
{
	//get the DUTID'S related parameter ....
	NSDictionary *dictTmp = [self getDUTIDDeviceParameter:DUTID] ;
	if (dictTmp==nil)
		return false;
	
	NSString *strDevice = [dictTmp objectForKey:@"UNITDevice"];
	if (strDevice==nil)
		return false ;
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	return [TestItemParse CheckUnitExist:strDevice:strTmp] ;
}

+(bool)getUnitInIBoot:(int)DUTID //check unit whether exit through DUTID.
{
	//get the DUTID'S related parameter ....
	NSDictionary *dictTmp = [self getDUTIDDeviceParameter:DUTID] ;
	if (dictTmp==nil)
		return false;
	
	NSString *strDevice = [dictTmp objectForKey:@"UNITDevice"];
	if (strDevice==nil)
		return false ;
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_IBOOT];
	return [TestItemParse CheckUnitExist:strDevice:strTmp] ;
}

//inner function
+(NSDictionary*)getDUTIDDeviceParameter:(int)DUTID ;
{
	if (uiWinManageInfo==nil)
		return nil ;
	//NSLog(@"%@",uiWinManageInfo);
	for(int i=0;i<[uiWinManageInfo count] ;i++)
	{
		NSDictionary *dictTmp = [uiWinManageInfo objectAtIndex:i] ;
		NSString *strDUT = [dictTmp objectForKey:@"BelongToDUT"] ;
		if (strDUT==nil)
			continue ;
		if ([strDUT intValue]==DUTID)
			return dictTmp ;
	}
	
	return nil ;
};

+(void)copyResToMainBoundle
{
	NSBundle *bundle=nil ;
	NSBundle * mainBundle =[ NSBundle mainBundle];
	if (mainBundle==nil)
		return ;
	NSString *strDist = [NSString stringWithFormat:@"%@/Contents/Resources",[mainBundle bundlePath]] ;
	
	NSArray *arrayTmp = [NSBundle allFrameworks] ;
	for(int i=0 ;i<[arrayTmp count] ;i++)
	{
		NSRange rangeTmp = [[[arrayTmp objectAtIndex:i] description] rangeOfString:@"iPFCommon.framework"] ;
		if (rangeTmp.location == NSNotFound)
			continue ;
		else
		{
			bundle = [arrayTmp objectAtIndex:i] ;
			break ;
		}
	} ;

	if (bundle!=nil)
	{
		NSString *pathOfRes ;
		
		pathOfRes = [bundle pathForResource:@"UIFor4Unit" ofType:@"nib"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
		
		pathOfRes = [bundle pathForResource:@"UIForMultipleUnit" ofType:@"nib"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
		
		pathOfRes = [bundle pathForResource:@"SingleUIWithoutScan" ofType:@"nib"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
		
		pathOfRes = [bundle pathForResource:@"LightHouse01" ofType:@"jpg"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
		
		pathOfRes = [bundle pathForResource:@"foxconnLogo" ofType:@"jpg"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
		
		pathOfRes = [bundle pathForResource:@"appleLogo" ofType:@"jpg"];
		if (pathOfRes!=nil)
		{
			NSString *strCp=[NSString stringWithFormat:@"cp %@  %@",pathOfRes,strDist] ;
			int i=system([strCp cStringUsingEncoding:NSASCIIStringEncoding]);
			if (i!=0)
				NSLog(@"\n copy resource file :%@  faile \n",pathOfRes) ;
		}
	}	
}

+(NSBundle*)getCurrentFramework
{
	NSBundle *bundle=nil ;
	
	NSArray *arrayTmp = [NSBundle allFrameworks] ;
	for(int i=0 ;i<[arrayTmp count] ;i++)
	{
		NSRange rangeTmp = [[[arrayTmp objectAtIndex:i] description] rangeOfString:@"iPFCommon.framework"] ;
		if (rangeTmp.location == NSNotFound)
			continue ;
		else
		{
			bundle = [arrayTmp objectAtIndex:i] ;
			break ;
		}
	} ;
	return bundle ;
}

//added by dsx 0602
+(BOOL) compareFileModifyTime
{	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	NSFileManager *fScript = [NSFileManager defaultManager];	
	//NSFileManager *fAppconfig = [NSFileManager defaultManager];	
	
	//NSFileManager *fStoreTime = [NSFileManager defaultManager];
	
	NSString *pathScript = [NSHomeDirectory()stringByAppendingString:[ScriptParse getValueFromSummary:@"TestScript"]];
	NSString *pathAppconfig = [NSHomeDirectory()stringByAppendingString:@"/AppConfig.txt"];
	
	NSString *storeScriptTime= @"/.time/recordScriptDate.txt";
	NSString *storeApptTime= @"/.time/recordAppDate.txt";
	NSString *compareResult=@"/.time/compareResult.txt";
	
	NSString *fileModDatePreScript = nil;
	NSString *fileModDatePreApp = nil;
	NSString *fileModDateNowScript = nil;
	NSString *fileModDateNowApp = nil;
	
	NSDictionary *fileAttributes = [fScript fileAttributesAtPath:pathScript traverseLink:NO];
	fileModDatePreScript =[NSString stringWithFormat:@"%@",[fileAttributes objectForKey:NSFileModificationDate] ];
	NSLog(@"%@", fileModDatePreScript);
	
	fileAttributes = [fScript fileAttributesAtPath:pathAppconfig traverseLink:NO];
	fileModDatePreApp = [NSString stringWithFormat:@"%@",[fileAttributes objectForKey:NSFileModificationDate] ];
	NSLog(@"%@", fileModDatePreApp);
	
	if (NO == [fScript fileExistsAtPath:storeScriptTime])
	{			
		system("mkdir /.time");
		
		BOOL flag=[fileModDatePreScript writeToFile:storeScriptTime atomically:YES encoding:NSASCIIStringEncoding error:NULL];
		if(flag==NO)
		{
			return YES;
		}
		
		flag=[fileModDatePreApp writeToFile:storeApptTime atomically:YES encoding:NSASCIIStringEncoding error:NULL];
		if(flag==NO)
		{
			return YES;
		}
		/*
		 if (NO == [fileManager_modify createFileAtPath:ModifyPath contents:[NSString stringWithFormat:@"%@",fileModDatePre] attributes:nil])
		 {	
		 NSLog(@"createFile for Script_time error");
		 return YES;
		 }*/
	}
	
	
	fileModDateNowScript = [NSString stringWithContentsOfFile:storeScriptTime encoding:NSASCIIStringEncoding error:nil];
	fileModDateNowApp = [NSString stringWithContentsOfFile:storeApptTime encoding:NSASCIIStringEncoding error:nil];
	
	
	if ((NO == [fileModDateNowScript isEqualToString:fileModDatePreScript])||(NO == [fileModDateNowApp isEqualToString:fileModDatePreApp]))
	{
		
		[@"NO" writeToFile:compareResult atomically:YES encoding:NSASCIIStringEncoding error:NULL];
		
		int resBtn = NSRunAlertPanel(@"WARNNING", @"脚本已被修改！", @"继续", @"退出", nil);
		
		if (NSAlertAlternateReturn == resBtn) // NO;
			exit(0);
		[pool release];
		return YES;
	}
	
	[@"YES" writeToFile:compareResult atomically:YES encoding:NSASCIIStringEncoding error:NULL];
	[pool release];
	
	return NO;
	
}


+(bool)sendCMDtoFixture:(int)DUTID :(NSString*)command
{
    NSString* strDevice = [self getDUTIDFixtureParameter:DUTID];
    NSLog(@"sendCMDtoFixture DUTID %d,%@",DUTID,strDevice);
    NSString *strTmp=nil;
    if ([command isEqualToString:@"GET START1\r"])
    {
        strTmp= [NSString stringWithFormat:@"%d",UnitStatus_FOR_FIXTURE];//Modified for P105 4-up fixture
        NSRange rangeTmp= [[TestItemParse CheckUnitSNExist:strDevice:strTmp:command] rangeOfString:@"PASS"];
        if (rangeTmp.length <= 0) {
            return FALSE;
        } else
        {
            return TRUE;
        }
    }
    if ([command isEqualToString:@"GET START2\r"])
    {
        strTmp= [NSString stringWithFormat:@"%d",UnitStatus_FOR_FIXTURE];//Modified for P105 4-up fixture
        NSString *rr=[TestItemParse CheckUnitSNExist:strDevice:strTmp:command];
        NSRange rangeTmp= [[TestItemParse CheckUnitSNExist:strDevice:strTmp:command] rangeOfString:@"PASS"];
        NSLog(@"back result %@",rr);
        if (rangeTmp.length <= 0) {
            return FALSE;
        } else {
            return TRUE;
        }
    }
    else
    {
        strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_FIXTURE];
        [TestItemParse CheckUnitSNExist:strDevice:strTmp:command] ;
        return true;
	}
}
//end

@end
