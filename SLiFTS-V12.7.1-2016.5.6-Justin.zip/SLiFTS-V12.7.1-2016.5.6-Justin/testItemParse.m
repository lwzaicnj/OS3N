//
//  testItemParse.m
//  qt_simulator
//
//  Created by diags on 2/28/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "testItemParse.h"
#import "scriptParse.h"
extern NSString* const TSName ; 
CommManage *commManageTestParse= nil ;
NSLock  *testItemLock=nil ; //it is used to synchitecture amount multiThread .

@implementation TestItemParse
+(bool)testItemParseInit
{
	NSDictionary *dictDeviceTmp = [ScriptParse getDeviceInfo] ;
	if (dictDeviceTmp==nil)
		return false;
	
	if ([self checkDeviceNumber]==false)
	{
		[ToolFun setAPPInitLog:@"Serial port number aren't enough"]  ;
		return false ;
	}
	
	if (testItemLock!=nil)
		[testItemLock release] ;
	testItemLock = [[NSLock alloc] init] ;
	if (testItemLock==nil)
		return false ;
	
	
	if (commManageTestParse!=nil)
	{
		[commManageTestParse release] ;
		commManageTestParse = nil ;
	}
	
	commManageTestParse = [[CommManage alloc] init];
	for(int i=0;i<[dictDeviceTmp count] ;i++)
	{
		NSDictionary* dictTmp=[dictDeviceTmp objectForKey:[[dictDeviceTmp allKeys] objectAtIndex:i]] ;
		if (dictTmp==nil)
			return false ;
		NSString *strDeviceID=[[dictDeviceTmp allKeys] objectAtIndex:i] ;
		NSString *strPortName=[dictTmp objectForKey:@"DeviceFile"] ;
		NSString *strBaudRate=[dictTmp objectForKey:@"BaudRate"] ;
		NSString *strDataBit=[dictTmp objectForKey:@"DataBit"] ;
		NSString *strStopBit=[dictTmp objectForKey:@"StopBit"] ;
		NSString *strParity=[dictTmp objectForKey:@"Parity"] ;
		NSString *strFlowControl=nil ;
        //NSString *strDeviceType=[dictTmp objectForKey:@"DeviceType"];
	
		NSMutableDictionary *mutDictKey=[[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictKey setObject:@":-)" forKey:@"EndString"] ;
        
		//SCRID:23
		//Description:Change  BaudRate according to appconfig setting
		//modified by caijunbo on 2010-11-27
		/*
		bool bResult = [commManageTestParse OpenPort:strDeviceID PortName
													:strPortName BaudRate
													:[CommManage strBaudRateToEnum:strBaudRate] DataBits
													:[CommManage strDataBitToEnum:strDataBit] StopBit
													:[CommManage strStopBitToEnum:strStopBit] Parity
													:[CommManage strParityToEnum:strParity] FlowControl
													:[CommManage strFlowControlToEnum:strFlowControl] KeysDefine
													:mutDictKey] ;
		 */
		bool bResult = [commManageTestParse OpenPort	:strDeviceID 
											PortName	:strPortName 
											BaudRate	:[strBaudRate intValue] 
											DataBits	:[CommManage strDataBitToEnum:strDataBit]	
											StopBit		:[CommManage strStopBitToEnum:strStopBit] 
											Parity		:[CommManage strParityToEnum:strParity] 
											FlowControl	:[CommManage strFlowControlToEnum:strFlowControl] 
											KeysDefine	:mutDictKey] ;
		 //end modified by caijunbo on 2010-11-27
        
        
		if (bResult==false)
		{
			[ToolFun setAPPInitLog:[NSString stringWithFormat:@"open port [%@] fail",strPortName]]  ;
            NSRunAlertPanel(@"WARNNING", @"Open port fail, Please check the port or reopen iFTS", @"exit", nil, nil) ;
            exit(0);
			return false ;
		}
	}
	
	return true ;
};

+(void)testItemParseRelease
{
	if (commManageTestParse!=nil)
	{	
		[commManageTestParse release] ;
		commManageTestParse = nil ;
	}
	
	if (testItemLock!=nil)
	{
		[testItemLock release] ;
		testItemLock = nil ;
	}
	
	return ;
}

+(bool)checkDeviceNumber 
{
	NSDictionary *dictDeviceTmp = [ScriptParse getDeviceInfo] ;
	if (dictDeviceTmp==nil)
		return true ;
	NSArray *arrayTmp = [UartComm ScanPort] ;
	if (arrayTmp==nil)
		return false ;
	
	if ([arrayTmp count]<[dictDeviceTmp count])
		return false ;
	
	return true ;
};

+(bool)performParseFunction:(NSDictionary*)dictParam
{
	NSAutoreleasePool* pool=[[NSAutoreleasePool alloc] init];
	if (dictParam==nil)
	{
		[pool release] ; //add by giga 
		return false ;
	}
	
	NSString *strName = [dictParam objectForKey:TSName] ;
	if (strName==nil)
	{
		[pool release] ; //add by giga 
		return false ;
	}
    
    if ([self checkWhetherByPassWithMesa:dictParam] || [self UseBarcodeToCheckWhetherByPassMesa:dictParam])
    {
        [TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_BYPASS :@"No Mesa, ByPass"];
        [pool release] ; 
		return true ;
    }
	//check whether by pass 
	if ([self checkWhetherByPass:dictParam]) //no test ,by pass
	{
		//2010-09-03 joko add
		/*SCRID-122: byPass depending on boardid but not SFC HWConfig. joko 2011-08-02*/
		/*
		NSString *strHwconfig = [TestItemManage getSFCValue:dictParam :STRKEYHWCOIG] ;
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue] && (strHwconfig == nil || [strHwconfig length] <=0))
		{
			[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_FAIL :@"No HWConfig which get from SFC"];
			[pool release] ; //add by giga
			return true ;
		}*/
		/*SCRID-122:end*/
		//2010-09-03 joko add end
		
		NSString *strProjectType = [dictParam objectForKey:STRKEYPROJECTTYPE];
		if ([strProjectType isEqualToString:@"SL7"])
		{
			strProjectType=@"SL7";
		}
		else if ([strProjectType isEqualToString:@"SL8"])
		{
			strProjectType=@"SL8";
		}
		
		//joko, let byPass fail if cann't not get board id
		NSString *strGetCheckBoardID=[TestItemManage getUnitValue:dictParam:STRKEYBOARDID];
        //Annie debug
        //strGetCheckBoardID=@"Board Id: 0x08";
        //Annie debug
		if([strGetCheckBoardID rangeOfString: @"boareID unexpected or can not get boardID"].length > 0)
		{
			[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_FAIL :@"byPass Fail, boareID unexpected or can not get boardID"];
		}
		else
		{
			NSString *strTmp = [NSString stringWithFormat:@"Only for %@",strProjectType] ;
			[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_BYPASS :strTmp];
		}
		//joko add end
		[pool release] ; //add by giga 
		return true ;
	}
	
	//added by caijunbo on 2011-05-26
	NSString* strKey=nil;
	NSString* strNeedSkip=nil;
	for(int i=0 ;i<[dictParam count] ;i++)
	{
		strKey=[[dictParam allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"NeedSkip"])
		{
			strNeedSkip =  [dictParam objectForKey:strKey];
		}
	}
	
	if (([strNeedSkip isEqualToString:@"yes"])&&([[TestItemManage getBufferValue:dictParam :@"IfNeedToSkip"] isEqualToString:@"yes"]) )//no test ,by pass
	{
		NSString *strTmp =@"Skip Test!" ;
		[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_BYPASS :strTmp];
		[pool release] ; //add by giga 
		return true ;
	}
	
	//added end by caijunbo on 2011-05-26
	
	if ([TestItemParse respondsToSelector:NSSelectorFromString([NSString stringWithFormat:@"%@:",strName])])
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		//check before call function .
		NSString *strTmp = [dictParam objectForKey:@"WhetherLock"] ;
		if(strTmp==nil)
			strTmp = @"no" ;
	
		if ([strTmp boolValue])
		{
#if 1
			@try 
			{
				[testItemLock lock] ;
				[[TestItemParse class] performSelector:NSSelectorFromString([NSString stringWithFormat:@"%@:",strName]) withObject:dictParam] ;
				[testItemLock unlock] ;
			}
			@catch (NSException * e) 
			{
				[testItemLock unlock] ;
				NSString *strTmp = [NSString stringWithFormat:@"Exception Error: %@",strName] ;
				[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_FAIL :strTmp];
			}
#else			
			[testItemLock lock] ;
			[[TestItemParse class] performSelector:NSSelectorFromString([NSString stringWithFormat:@"%@:",strName]) withObject:dictParam] ;
			[testItemLock unlock] ;
#endif			
		}else
		{
#if 1			
			@try
			{
				[[TestItemParse class] performSelector:NSSelectorFromString([NSString stringWithFormat:@"%@:",strName]) withObject:dictParam] ;
			}@catch (NSException * e) 
			{
				NSString *strTmp = [NSString stringWithFormat:@"Exception Error : %@",strName] ;
				[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_FAIL :strTmp];
			}
#else
			[[TestItemParse class] performSelector:NSSelectorFromString([NSString stringWithFormat:@"%@:",strName]) withObject:dictParam] ;
#endif
		}
		
		[pool release] ;
	}else
	{
		NSString *strTmp = [NSString stringWithFormat:@"No exist the parse function : %@",strName] ;
		[TestItemParse SetResultAndUIInfo:dictParam :RESULT_FOR_OTHER :strTmp];
		//NSRunAlertPanel(@"WARNNING", strTmp , @"Prompt", nil, nil) ;
	}
	[pool release];
	return true ;
} ;

+(NSString*)getDeviceID:(NSString*)mDeviceType :(NSDictionary*)dictParam
{
	if (mDeviceType==nil ||
		dictParam==nil
		)
		return nil ;
	
	NSString *strUnit=[dictParam objectForKey:@"UNITDevice"] ;
	NSArray  *arrayTmp=[dictParam objectForKey:@"FixtureDevice"];
	
	NSRange rangTmp ;
	if (strUnit!=nil)
	{
		rangTmp = [strUnit rangeOfString:mDeviceType] ;
		if (rangTmp.length > 0)
			return strUnit ;
	}
	if (arrayTmp!=nil)
	{
		for(int i=0;i<[arrayTmp count];i++)
		{
			rangTmp = [[arrayTmp objectAtIndex:i] rangeOfString:mDeviceType] ;
			if (rangTmp.length > 0)
				return [arrayTmp objectAtIndex:i] ;
		}
	}
	return nil ;
}

+(CommManage*)getCommManage
{
	if (commManageTestParse==nil)
		return nil ;
	NSLog(@"commManageTestParse=%@",commManageTestParse);
	return commManageTestParse ;
}

+(bool)SendData:(NSDictionary*)dictKeyDefined:(NSString*)sendBuffer:(NSString*)strEndString
{
	if (dictKeyDefined==nil ||
		sendBuffer==nil)
		return false ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		return false ;
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil ||
		mDevice==nil )
	{
		//set Log info
		[TestItemManage setUnitLogInfo:dictKeyDefined :@"No Exist DeviceID":true];
		return false ;
	}
    NSMutableData *mutabledataTmp =[[[NSMutableData alloc] initWithBytes:[sendBuffer cStringUsingEncoding:NSASCIIStringEncoding] length:[sendBuffer length]] autorelease];
		
	NSMutableDictionary* mutableDict = [[[NSMutableDictionary alloc] init] autorelease] ;
	if (strEndString==nil)
		[mutableDict setObject:@":-)" forKey:@"EndString"] ;
	else
		[mutableDict setObject:strEndString forKey:@"EndString"] ;
	
	bool bTmp = [commTmp WriteData:mDevice DataBuffer
								  :mutabledataTmp :mutableDict] ;
	
	if (bTmp)
	{
		//set Log info
		NSString *strLoginfo = [NSString stringWithFormat:@"send[Success]: %@",sendBuffer] ;
		strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true];
		[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true];
	}else
	{
		NSString *strLoginfo = [NSString stringWithFormat:@"send[Fail]: %@",sendBuffer] ;
		strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true];
		[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true] ;
	}
	return bTmp ;
};

/*SCRID:62 add by giga for new CB write*/
+(bool)SendDataAsNSData:(NSDictionary*)dictKeyDefined:(NSData*)sendBuffer:(NSString*)strEndString
{
	if (dictKeyDefined==nil ||
		sendBuffer==nil)
		return false ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		return false ;
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil ||
		mDevice==nil )
	{
		//set Log info
		[TestItemManage setUnitLogInfo:dictKeyDefined :@"No Exist DeviceID":true];
		return false ;
	}
   
	NSMutableData *mutabledataTmp =[[[NSMutableData alloc] initWithData:sendBuffer] autorelease];
	
	
	NSMutableDictionary* mutableDict = [[[NSMutableDictionary alloc] init] autorelease] ;
	if (strEndString==nil)
		[mutableDict setObject:@":-)" forKey:@"EndString"] ;
	else
		[mutableDict setObject:strEndString forKey:@"EndString"] ;
	
	bool bTmp = [commTmp WriteData:mDevice DataBuffer
								  :mutabledataTmp :mutableDict] ;
	
	if (bTmp)
	{
		//set Log info
		NSString *strLoginfo = [NSString stringWithFormat:@"send[Success]: %@",sendBuffer] ;
		strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true];
		[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true];
	}else
	{
		NSString *strLoginfo = [NSString stringWithFormat:@"send[Fail]: %@",sendBuffer] ;
		strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true];
		[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true] ;
	}
	return bTmp ;
};
/*SCRID:62 end*/

+(bool)CheckReceDataIsComplete:(NSDictionary*)dictKeyDefined
{
	if (dictKeyDefined==nil )
		return false ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		return false ;
	
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return false ;

	return [commTmp CheckISCompleteDataUsingCurrKey:mDevice] ;	
};

+(NSString*)ReceData:(NSDictionary*)dictKeyDefined
{
	if (dictKeyDefined==nil )
		return nil ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
    NSString *mDeleteID=[dictKeyDefined objectForKey:@"DeleteID"] ;
    if (mDeleteID == nil)
        mDeleteID=@"yes";
	if (mDevice==nil)
		return nil ;
	
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return nil ;
	NSData* dataTmp= [commTmp ReadData:mDevice] ;
	if (dataTmp==nil)
		return nil ;
	if ([dataTmp length]<=0)
		return nil ;
	
	NSString *strRtn=[[[NSString alloc] initWithData:dataTmp encoding:NSASCIIStringEncoding] autorelease];
	/*SCRID-18:Grape test log no need chagne, remain their regulation.*/
	/*Joko Modify,2010-10-21*/
	/*
	if(!([strRtn rangeOfString: @"device -k Touch"].length > 0 || [strRtn rangeOfString: @"device --key Touch"].length > 0))
	{
		strRtn = [strRtn stringByReplacingOccurrencesOfString:@"\n" withString:@" "];
		strRtn = [strRtn stringByReplacingOccurrencesOfString:@"\r" withString:@" "];
	}
	*/
	/*SCRID-18:Modify end*/
	
		/************************dengshouxiu 2010-03-30********begin*****************/
	if( [[dictKeyDefined objectForKey:@"AudioDecodeFlag"] boolValue])
	{
           NSRange Location = [strRtn rangeOfString:@":-)"];
		   if (Location.length <= 0)
		   	strRtn = @"TimeOut";

	}
		/************************dengshouxiu 2010-03-30********end*****************/
	NSString *strLoginfo = [NSString stringWithFormat:@"receive: %@",strRtn] ;
	strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true]; 
	[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true];
    //joko add for new diag 2012-04-27
    //Rick add for judge if delete the info before the :-) 2012-09-21
    if([mDeleteID boolValue])
    {
        if(strRtn!=nil && ([strRtn rangeOfString:@":-)"].length > 0) && 
           ([strRtn rangeOfString:@"["].length > 0) && ([strRtn rangeOfString:@"]"].length > 0))
        {
            NSString *tmp = [ToolFun getStrFromPrefixAndPostfix:strRtn Prefix
                                                               :@"[" Postfix
                                                               :@"]"] ;
            NSArray *arrTmp = [tmp componentsSeparatedByString:@":"];
            
            if((17 == [tmp length]) && ([tmp rangeOfString:@":"].length > 0) && ([[arrTmp objectAtIndex:0] length] == 8) && ([[arrTmp objectAtIndex:1] length] == 8))
            {
                strRtn = [strRtn substringToIndex:[strRtn rangeOfString:@"["].location];
                strRtn = [strRtn stringByAppendingString:@":-)"];
            }
        }
    }
    NSString *mTestItemName = [dictKeyDefined objectForKey:@"TestItemName"];
    NSString *mWriteCommand = [dictKeyDefined objectForKey:@"WriteCmd"];
	//add end 2012-04-27
	/*SCRID-18:Grape test log no need chagne, remain their regulation.*/
    if(![mWriteCommand isEqualToString:@"camisp --cameraconfig"]) //change by justin
//    if(![mTestItemName isEqualToString:@"Check Front Camera Stable"] && ![mTestItemName isEqualToString:@"Check Back Camera Stable"])
    {
        if([strRtn rangeOfString:@"/private/var/logs/"].length <= 0 && [strRtn rangeOfString:@"syscfg print GYTT"].length <= 0)
        {
            strRtn = [strRtn stringByReplacingOccurrencesOfString:@"\n" withString:@" "];//DSX 2010-12-07
            strRtn = [strRtn stringByReplacingOccurrencesOfString:@"\r" withString:@" "];
        }
    }
	/*SCRID-18:Modify end*/
	return strRtn ;
}

/*SCRID:62 add by giga for new CB Write*/
+(NSData*)ReceDataAsNSData:(NSDictionary*)dictKeyDefined 
{
	if (dictKeyDefined==nil )
		return nil ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		return nil ;
	
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return nil ;
	NSData* dataTmp= [commTmp ReadData:mDevice] ;
	NSLog(@"the raw data:",[dataTmp description]);
	if (dataTmp==nil)
		return nil ;
	if ([dataTmp length]<=0)
		return nil ;
	
	//NSString *strRtn=[[[NSString alloc] initWithData:dataTmp encoding:NSASCIIStringEncoding] autorelease];
	
	NSString *strLoginfo = [NSString stringWithFormat:@"receive: %@",dataTmp] ;
	strLoginfo = [ToolFun allTrimFromString:strLoginfo trimStr:@"\n" leftTrim:true rightTrim:true]; 
	[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo:true];
	//return strRtn ;
	return dataTmp ;
}
/*SCRID:62 end*/

+(bool)closeCurrPort:(NSDictionary*)dictKeyDefined 
{
	if (dictKeyDefined==nil)
		return false ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		mDevice = [dictKeyDefined objectForKey:@"UNITDevice"] ;
	else
		mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	if (mDevice==nil)
		return FALSE ;
	
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return false ;
	
	[commTmp ClosePort:mDevice] ;
	return true ;
};

+(bool)openCurrPort:(NSDictionary*)dictKeyDefined 
{
	if (dictKeyDefined==nil)
		return false ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	
	if (mDevice==nil)
		mDevice = [dictKeyDefined objectForKey:@"UNITDevice"] ;
	else
		mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	if (mDevice==nil)
		return false ;
	mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;

	if (commManageTestParse==nil)
		return false ;
	
	if ([commManageTestParse IsOpen:mDevice])
		return true ;
	//reopen 
	NSDictionary *dictDeviceTmp = [ScriptParse getDeviceInfo] ;
	if (dictDeviceTmp==nil)
		return false;
	
	for(int i=0;i<[dictDeviceTmp count] ;i++)
	{
		NSDictionary* dictTmp=[dictDeviceTmp objectForKey:[[dictDeviceTmp allKeys] objectAtIndex:i]] ;
		if (dictTmp==nil)
			return false ;
		NSString *strDeviceID=[[dictDeviceTmp allKeys] objectAtIndex:i] ;
		NSString *strPortName=[dictTmp objectForKey:@"DeviceFile"] ;
		NSString *strBaudRate=[dictTmp objectForKey:@"BaudRate"] ;
		NSString *strDataBit=[dictTmp objectForKey:@"DataBit"] ;
		NSString *strStopBit=[dictTmp objectForKey:@"StopBit"] ;
		NSString *strParity=[dictTmp objectForKey:@"Parity"] ;
		NSString *strFlowControl=nil ;
		
		NSMutableDictionary *mutDictKey=[[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictKey setObject:@":-)" forKey:@"EndString"] ;
		
		if ([strDeviceID isEqualToString:mDevice])
		{
			bool bResult = [commManageTestParse OpenPort:strDeviceID PortName
													:strPortName BaudRate
													:[CommManage strBaudRateToEnum:strBaudRate] DataBits
													:[CommManage strDataBitToEnum:strDataBit] StopBit
													:[CommManage strStopBitToEnum:strStopBit] Parity
													:[CommManage strParityToEnum:strParity] FlowControl
													:[CommManage strFlowControlToEnum:strFlowControl] KeysDefine
													:mutDictKey] ;
			return bResult;
		}
	}
	return false ;
};

//add by giga 10.9.2010
+(NSString*)getCurrPort:(NSDictionary*)dictKeyDefined 
{
	if (dictKeyDefined==nil)
		return nil ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"Device"] ;
	if (mDevice==nil)
		mDevice = [dictKeyDefined objectForKey:@"UNITDevice"] ;
	else
		mDevice = [self getDeviceID:mDevice :dictKeyDefined] ;
	
	if (mDevice==nil)
		return nil ;

	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return nil ;
	
	return [commTmp getPortName:mDevice] ;

};
//end add 

+(NSString*)getCurrUnitDeviceName:(NSDictionary*)dictKeyDefined
{
	if (dictKeyDefined==nil)
		return nil ;
	
	NSString *mDevice = [dictKeyDefined objectForKey:@"UNITDevice"] ;
	if (mDevice==nil)
		return nil ;
	
	//by the DeviceID to get the device name .
	NSDictionary *dictDeviceTmp = [ScriptParse getDeviceInfo] ;
	if (dictDeviceTmp==nil)
		return nil;
	NSDictionary *dictTmp = [dictDeviceTmp objectForKey:mDevice] ;
	if (dictTmp==nil)
		return nil ;
	return [dictTmp objectForKey:@"DeviceFile"] ;	
}

+(NSString*)CheckUnitSNExist:(NSString*)strDevice :(NSString*)strStatus :(NSString*)command
{
	if (strStatus==nil)
		return FALSE ;
	
//	enum UnitStatus enumStatus =[strStatus intValue] ; 
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return false ;
	
	NSString *sendBuffer = command;//[NSString stringWithFormat:@"sn\n\r"];
    NSMutableData *mutabledataTmp =[[[NSMutableData alloc] initWithBytes:[sendBuffer cStringUsingEncoding:NSASCIIStringEncoding] length:[sendBuffer length]] autorelease];
	
	NSMutableDictionary* mutableDict = [[[NSMutableDictionary alloc] init] autorelease] ;
	//if (enumStatus==UnitStatus_FOR_DIAGS)
		[mutableDict setObject:@":-)" forKey:@"EndString"] ;
	//else
	//	[mutableDict setObject:@"\r\n]" forKey:@"EndString"] ;
	
	//clear current Device data received before send data .
	[commTmp clearData:strDevice] ;
	bool bTmp = [commTmp WriteData:strDevice DataBuffer
								  :mutabledataTmp :mutableDict] ;
	if (bTmp==false)
		return false ;
	
	usleep(500000);
	
	return [commTmp CheckISCompleteDataUsingCurrKeyAndGetSN:strDevice] ;
};

+(bool)CheckUnitExist:(NSString*)strDevice :(NSString*)strStatus
{
	if (strStatus==nil)
		return FALSE ;
	
	enum UnitStatus enumStatus =[strStatus intValue] ; 
	CommManage *commTmp=[self getCommManage] ;
	if (commTmp==nil)
		return false ;
	
	NSString *sendBuffer = [NSString stringWithFormat:@"\n\r"];
    NSMutableData *mutabledataTmp =[[[NSMutableData alloc] initWithBytes:[sendBuffer cStringUsingEncoding:NSASCIIStringEncoding] length:[sendBuffer length]] autorelease];
	
	NSMutableDictionary* mutableDict = [[[NSMutableDictionary alloc] init] autorelease] ;
	if (enumStatus==UnitStatus_FOR_DIAGS)
		[mutableDict setObject:@":-)" forKey:@"EndString"] ;
	else
		[mutableDict setObject:@"\r\n]" forKey:@"EndString"] ;

	//clear current Device data received before send data .
	[commTmp clearData:strDevice] ;
	bool bTmp = [commTmp WriteData:strDevice DataBuffer
								  :mutabledataTmp :mutableDict] ;
	if (bTmp==false)
		return false ;
	
	usleep(500000);
	return [commTmp CheckISCompleteDataUsingCurrKey:strDevice] ;
};

+(int)GetCurrDUTID:(NSDictionary*)dictKeyDefined 
{
	if (dictKeyDefined==nil)
		return -1 ;
	
	NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return -1 ;
	else
		return [strDUTID intValue] ;
}

//public function
+(void)SetResultAndUIInfo:(NSDictionary*)dictKeyDefined :(enum TestResutStatus)enumResult :(NSString *)strTestResultForUIinfo 
{
	if (dictKeyDefined==nil ||
		strTestResultForUIinfo ==nil 
		)
		return ;
	
	//Write the result and test value to log
	NSString *strResult ;

	switch (enumResult) 
	{
		case RESULT_FOR_PASS:
		case RESULT_FOR_BYPASS:
			strResult = @"Pass";
			break;
		default:
			strResult = @"Fail" ;
	}
	NSString *strLoginfo = [NSString stringWithFormat:@"%@ , %@",strResult,strTestResultForUIinfo];
	[TestItemManage setUnitLogInfo:dictKeyDefined :strLoginfo :false] ;
   //write log end
	
	//set test action result
	NSString *strDUTID,*strTestItemIndex ;
	strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	strTestItemIndex = [dictKeyDefined objectForKey:@"TestItemIndex"] ;
	[TestItemManage setTestActionResult:[strDUTID intValue] :[strTestItemIndex intValue] :enumResult ];
	
	NSString *mTestItemName = [dictKeyDefined objectForKey:@"TestItemName"] ;
    if (mTestItemName==nil)
		return ;
		
	[TestItemManage setTestItemResult:[strDUTID intValue] :[strTestItemIndex intValue] :enumResult ] ;
	[TestItemManage setTestItemResultForUI:[strDUTID intValue] :[strTestItemIndex intValue] :strTestResultForUIinfo :enumResult] ;
}

+(bool)checkWhetherByPassWithMesa:(NSDictionary*)dictKeyDefined
{
    NSString *strProjectTypeList = [dictKeyDefined objectForKey:@"CheckMesaByPass"];
    if([strProjectTypeList boolValue])
    {
        NSString *HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
        if([HWCofig rangeOfString:@"Mesa=0"].length > 0)
        {
            return true;
        }
        
        else
        {
            return false;
        }
        
    }
    return false;
}

+(bool)UseBarcodeToCheckWhetherByPassMesa:(NSDictionary*)dictKeyDefined
{
    NSString *strProjectTypeList = [dictKeyDefined objectForKey:@"ByPassMesa"];
    if([strProjectTypeList boolValue])
    {
        if([[ScriptParse getValueFromSummary:@"NeedBarcode"] boolValue])
		{
			NSString *barcode = [TestItemManage getScanValue:dictKeyDefined :@"strBarcodeSn"];
			if([barcode isEqualToString:@"1_1_1"])
			{
		 		return false;
			}
			else if([barcode isEqualToString:@"0_0_0"])
			{
		 		return true;
			}
            else
			{
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    return false;
}


+(bool)checkWhetherByPass:(NSDictionary*)dictKeyDefined  //return true ,By pass .
{
    //only for dry run, don't know boardid now, need change after know boardid. JianSheng add on 2013-12-12; also need change the boarid
    //return false ;
    //JianSheng add end; 0x0D
    
	if (dictKeyDefined==nil)
		return false ;
	NSString *strProjectTypeList = [dictKeyDefined objectForKey:STRKEYPROJECTTYPE];
	if (strProjectTypeList==nil)
		return false ;
	//----------------
	NSArray* arrayProjTypes = [strProjectTypeList componentsSeparatedByString:@","];
	
	//for (NSString *strProjectType in arrayProjTypes)
	for (int i=0;i<[arrayProjTypes count] ;i++)	
	{	
		NSString *strProjectType = [arrayProjTypes objectAtIndex:i];
		if ([strProjectType isEqualToString:@"K48M"]) //k48M
		{
			NSString *strHwconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG] ; //first to get hwconfig from SFC
			if (strHwconfig==nil) //if empty ,get hwconfig from SCRIPT PARSE MODEL
			{
				NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN] ;
				if (strSN==nil)
					return false ;
				strHwconfig = [ScriptParse getValueFromHWConfig:[ToolFun getStrFromLen:strSN length:3 Option:false]] ;
				if (strHwconfig==nil)
					return false ;
			} ;
			
			//NSLog(@"\n strHwconfig = %@\n",strHwconfig);
			NSRange rangTmp1 = [strHwconfig rangeOfString:@"3G"] ;
			NSRange rangTmp2 = [strHwconfig rangeOfString:@"UMTS"];
			

			if (rangTmp1.length <= 0 &&
				rangTmp2.length <= 0)    //no exist 3G,UMTS ,It meaning unit =K48
			{
				if ((i+1)>=[arrayProjTypes count]) //No exist other project list
					return true ;
				else
					continue ;
			}else
				return false ;
		}
        //modified by Annie for SL 2015.3.28
		else if([strProjectType isEqualToString:@"SL8"])
        {
            
			NSString *strBoardID=[TestItemManage getUnitValue:dictKeyDefined:STRKEYBOARDID];
            //Annie debug
            //strBoardID=@"Board Id: 0x08";
            //Annie debug
            
            if(([strBoardID rangeOfString:@"0x0A"].length <= 0) && ([strBoardID rangeOfString:@"0x08"].length <= 0))
			{
				[TestItemManage setUnitValue:dictKeyDefined :STRKEYBOARDID : @"boareID unexpected or can not get boardID"];
				return true;
			}
            
			if ([strBoardID rangeOfString:@"0x0A"].length<=0)
                return true;

		}
		else if([strProjectType isEqualToString:@"SL7"])
		{
            
			NSString *strBoardID=[TestItemManage getUnitValue:dictKeyDefined:STRKEYBOARDID];
            //Annie debug
            //strBoardID=@"Board Id: 0x0A";
            //Annie debug
            if(([strBoardID rangeOfString:@"0x0A"].length <= 0) && ([strBoardID rangeOfString:@"0x08"].length <= 0))
			{
				[TestItemManage setUnitValue:dictKeyDefined :STRKEYBOARDID : @"boareID unexpected or can not get boardID"];
				return true;
			}
            
			if ([strBoardID rangeOfString:@"0x08"].length<=0)
				return true;

		}

		else if ([strProjectType isEqualToString:@"UMTS"])
		{
			NSString *strHwconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG] ; //first to get hwconfig from SFC
			if (strHwconfig==nil) //if empty ,get hwconfig from SCRIPT PARSE MODEL
			{
				NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN] ;
				if (strSN==nil)
					return false ;
				strHwconfig = [ScriptParse getValueFromHWConfig:[ToolFun getStrFromLen:strSN length:3 Option:false]] ;
				if (strHwconfig==nil)
					return false ;
			} ;
			
			//NSLog(@"\n strHwconfig = %@\n",strHwconfig);
			//NSRange rangTmp1 = [strHwconfig rangeOfString:@"3G"] ;
			NSRange rangTmp2 = [strHwconfig rangeOfString:@"UMTS"];
			
			
			if (rangTmp2.length <= 0)    //no exist 3G,UMTS ,It meaning unit =K48
			{
				if ((i+1)>=[arrayProjTypes count]) //No exist other project list
					return true ;
				else
					continue ;
			}else
				return false ;
		}
		else if ([strProjectType isEqualToString:@"CDMA2000"])
		{
			NSString *strHwconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG] ; //first to get hwconfig from SFC
			if (strHwconfig==nil) //if empty ,get hwconfig from SCRIPT PARSE MODEL
			{
				NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN] ;
				if (strSN==nil)
					return false ;
				strHwconfig = [ScriptParse getValueFromHWConfig:[ToolFun getStrFromLen:strSN length:3 Option:false]] ;
				if (strHwconfig==nil)
					return false ;
			} ;
			
			//NSLog(@"\n strHwconfig = %@\n",strHwconfig);
			//NSRange rangTmp1 = [strHwconfig rangeOfString:@"3G"] ;
			NSRange rangTmp2 = [strHwconfig rangeOfString:@"CDMA2000"];
			
			
			if (rangTmp2.length <= 0)    //no exist 3G,UMTS ,It meaning unit =K48
			{
				if ((i+1)>=[arrayProjTypes count]) //No exist other project list
					return true ;
				else
					continue ;
			}else
				return false ;
		}
		else if ([strProjectType isEqualToString:@"WFBT"])//XIUXIU -2010-10-07 One tesItem only test for K93
		{
			NSString *strHwconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG] ; //first to get hwconfig from SFC
			if (strHwconfig==nil) //if empty ,get hwconfig from SCRIPT PARSE MODEL
			{
				NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN] ;
				if (strSN==nil)
					return false ;
				strHwconfig = [ScriptParse getValueFromHWConfig:[ToolFun getStrFromLen:strSN length:3 Option:false]] ;
				if (strHwconfig==nil)
					return false ;
			} ;
			
			//NSLog(@"\n strHwconfig = %@\n",strHwconfig);
			//NSRange rangTmp1 = [strHwconfig rangeOfString:@"3G"] ;
			NSRange rangTmp2 = [strHwconfig rangeOfString:@"WFBT"];
			
			
			if (rangTmp2.length <= 0)    //no exist 3G,UMTS ,It meaning unit =K48
			{
				if ((i+1)>=[arrayProjTypes count]) //No exist other project list
					return true ;
				else
					continue ;
			}else
				return false ;
		}
		else
			return false ;
	} ;
	return false ;
}
@end
