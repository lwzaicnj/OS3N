
/*
 +--------------------------------------------------------------------+--------------
 | PROJECT: QT-Cocoa                     $Workfile:: WriteControlBitAndPosionBit.h  $|
 | $Author:: Dengshouxiu                 $Revision::  1                             $|
 | CREATED: 2010-03-29                   $Modtime:: 2.03.00 15:24                   $|
 | STATE  : Beta                                                                     |
 +--------------------------------------------------------------------+---------------
 
 $History:: WriteControlBitAndPosionBit.h                                              $
 * *****************  Version 1  *****************
 * User: Dengshouxiu          Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "WriteControlBitAndPosionBit.h"

@implementation TestItemParse(WriteControlBitAndPosionBit)

extern BOOL bSetFailCB5Times ;

//SCRID:151 Ray add for writeCB three times in Magnetic station
+(void)RS232WriteControlAndPosionBitPassWordV2_3times:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	
	NSString *mBufferName=nil    ;
	
	NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mReferenceBufferName2=nil;
	NSString *mReferenceBufferName3=nil;
	
	//SCRID:39 change -:) to :-) 
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	NSString *mControlOrPosionBit = @"yes";
	NSString *mReferenceBufferName=nil ;
	NSString *mCBCmd=nil;
	NSString *mStationName =@"";
	
	//Ray add
	int mRetestTimes;
	//End
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}		
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*--------dengshouxiu-----------------*/
		else if ([strKey isEqualToString:@"ControlOrPosionBit"])
		{
			mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCBCmd"])
		{
			mCBCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StationName"])
		{
			mStationName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}		
		else if ([strKey isEqualToString:@"ReferenceBufferName3"])
		{
			mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"RetestTimes"])
		{
			mRetestTimes = [[dictKeyDefined objectForKey:strKey] intValue];
		}
	}
	
	for(int i=1; i<=mRetestTimes; i++)
	{
		/*SCRID-132: Add check SN before write CB. Ray 2011-08-22*/
		NSString *mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
		NSString *mReferenceBufferValue3=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3];
		if(mReferenceBufferValue2==nil||mReferenceBufferValue3==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, no sn"];
			continue;
			//return;
		}
		else
		{
			if([mReferenceBufferValue2 rangeOfString:mReferenceBufferValue3].length<=0)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, sn change"];
				continue;
				//return;
			}
		}
		/*SCRID-132: end*/
		
		//2011-01-12 for new CB
		//change the string back to network byte order
		
		BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
		if(!flag)
		{
			NSString *dataResultFail = @"fail";
			mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
			bool bTmp = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
			if (bTmp==FALSE)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
				continue;
				//return ;	
			}
			
			{
				NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
				mTimeOut = @"5";
				int iTmp = [mTimeOut intValue] ;
				int timeInterval = - [dateTmp timeIntervalSinceNow] ;
				while (timeInterval<=iTmp)
				{
					timeInterval = -[dateTmp timeIntervalSinceNow] ;
					
					if ([self CheckReceDataIsComplete:dictKeyDefined]) 
						break ;
					else
						usleep(500000) ; //delay 500
				}
				//read data
				dataResultFail = [self ReceData:dictKeyDefined] ;
				
				if (dataResultFail==nil)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
					continue;
					//return ;
				}
				NSLog(@"\n after send fg return :%@",dataResultFail);
			}
			if(mBufferName !=nil)
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResultFail] ;
			
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
			return;
			
		}
		
		//step 1 : set cmd :getnonce .
		mWriteCmd = @"getnonce\n" ;
		bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			continue;
			//return ;
		}
		
		if (mCBCmd==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
			continue;
			//return ;
		}
		
		//step 2 :check receivd data 
		unsigned char *charNonce =NULL;
		unsigned char cTempNonce[20];
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
				usleep(500000) ; //delay 500
		}
		//read data
		//NSString *dataResult = [self ReceData:dictKeyDefined] ;
		
		NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
		if (dataReceTmp==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			continue;
			//return ;
		}
		
		if ([dataReceTmp length] < 35)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive error data"] ;
			continue;
			//return ;	
		}
		charNonce = (void*)[dataReceTmp bytes] ;
		NSLog(@"\n receive data length is :%d n string is %s",[dataReceTmp length],charNonce) ;
		
		for(int x=0;x<35;x++)
			printf("0x%02x ",charNonce[x]);
		printf("\n");
		
		memcpy(cTempNonce, charNonce+10, 20);
		for(int x=0;x<20;x++)
			printf("0x%02x ",cTempNonce[x]);
		
		
		/************************** do SHA1 ************************/
		/*	unsigned char cStatinPassword[20]={
		 0x97 ,0x6a ,0xe1 ,0xf6 ,0x8f ,0xe5 ,0xbb, 0xb3 ,0xa8 ,0xcf,
		 0x92 ,0xe2 ,0x11 ,0x80 ,0x84 ,0x3d ,0x19 ,0x17 ,0xe9 ,0x5c
		 };
		 */	
		//Password changed for J1J2 by Henry 2011-03-03
		unsigned char cStatinPassword[20];
		unsigned char GROUNDING[20]=
        {0xF6 ,0xD6 ,0xD7 ,0x92 ,0x46 ,0x1C ,0x24 ,0x0A ,0x35 ,0x0D ,0xD7 ,0xC1 ,0x46 ,0x68 ,0x32 ,0x9D ,0xC4 ,0x26 ,0xB4 ,0x82
        }; //0xF6D6D792, 0x461C240A, 0x350DD7C1, 0x4668329D, 0xC426B482 //2012-05-30 JianSheng Modify
        unsigned char HEFFEFFECT[20]=
        {0x31 ,0xFB ,0x55 ,0x56 ,0x29 ,0x7B ,0x94 ,0xF8 ,0x1A ,0xD1 ,0x91 ,0xC7 ,0xC9 ,0xD8 ,0x28 ,0xBA ,0x90 ,0x26 ,0x17 ,0x3E
        }; //0x31FB5556, 0x297B94F8, 0x1AD191C7, 0xC9D828BA, 0x9026173E //2012-05-30 JianSheng Modify
        unsigned char GRAPEOFFSET[20]=
        {0xA6 ,0x3C ,0xCF ,0x9D ,0x2B ,0x3A ,0x5D ,0xE1 ,0x53 ,0x42 ,0x33 ,0x6E ,0x89 ,0xDE ,0x96 ,0x22 ,0xBF ,0x51 ,0xE1 ,0xAC
        }; //0xA63CCF9D, 0x2B3A5DE1, 0x5342336E, 0x89DE9622, 0xBF51E1AC //2012-05-30 JianSheng Modify
        unsigned char QT1[20]=
        {0x2C ,0x0E ,0x55 ,0x86 ,0x48 ,0x54 ,0x22 ,0xC4 ,0x14 ,0xB6 ,0xA2 ,0xB4 ,0x4B ,0x85 ,0x89 ,0x62 ,0x0E ,0xEB ,0x12 ,0x59
        };//0xE087E15C, 0x0224F1EB, 0xFC3D259C, 0xD7CB4424, 0x576A0EBD  //2012-05-30 JianSheng Modify
        //0x2C0E5586, 0x485422C4, 0x14B6A2B4, 0x4B858962, 0x0EEB1259   20150314 By Kevin Modified
        unsigned char CONNECTIVITY1[20]=
        {0xf6 ,0x4a ,0xd8 ,0xeb ,0x52 ,0xf1 ,0xab ,0x94 ,0x36 ,0xe5 ,0x85 ,0xe8 ,0x33 ,0x37 ,0xb6 ,0x4c ,0x10 ,0x1a ,0x27 ,0x86
        };//0xF64AD8EB, 0x52F1AB94, 0x36E585E8, 0x3337B64C, 0x101A2786 //Ray Modify for P108
        
        //SCRID:133 Change Connectivity2 CB password.
        unsigned char CONNECTIVITY2[20]=
        {0xea ,0x93 ,0x3a ,0x8a ,0x43 ,0xf1 ,0x0d ,0x84 ,0x87 ,0x3d ,0x5a ,0xb6 ,0xab ,0xd3 ,0xb9 ,0x3c ,0x17 ,0x61 ,0xaa ,0x14
        };//ea 93 3a 8a 43 f1 0d 84 87 3d 5a b6 ab d3 b9 3c 17 61 aa 14 20120210 judith modify
        
        unsigned char QT0A[20]=
        {0xcc ,0x69 ,0x05 ,0xf5 ,0x10 ,0x25 ,0x36 ,0xad ,0x5b ,0xed ,0x09 ,0x88 ,0xd6 ,0x86 ,0x29 ,0x53 ,0x12 ,0x2f ,0xd7 ,0x83
        };//0xCC6905F5, 0x102536AD, 0x5BED0988, 0xD6862953, 0x122FD783 //Ray Modify for P108
        
        unsigned char QT0B[20]=
        {0xe3 ,0x5c ,0x0a ,0x9a ,0x0d ,0x38 ,0x6a ,0x43 ,0xcc ,0x1b ,0x70 ,0xa8 ,0x1f ,0x97 ,0x70 ,0x45 ,0xaa ,0xed ,0x76 ,0xf7
        };//e3 5c 0a 9a 0d 38 6a 43 cc 1b 70 a8 1f 97 70 45 aa ed 76 f7  20120210 judith modify
        
        unsigned char PROXCAL[20]=
        {0xDD ,0xE2 ,0x80 ,0x8A ,0xA6 ,0x2B ,0x39 ,0x66 ,0x65 ,0x52 ,0xD7 ,0x92 ,0xF6 ,0x30 ,0x48 ,0xD4 ,0x7F ,0x7C ,0xF3 ,0x3D
        };//0xDDE28D8AA6 0x2B39666552 0xD792F63048 0xD47F7CF33D Modify by kenshin on 2012-02-10
        
        unsigned char MAGCOVER[20]=
        {0x06 ,0x21 ,0x07 ,0xB9 ,0xFC ,0x75 ,0x2D ,0x62 ,0xA9 ,0x03 ,0xF2 ,0x20 ,0xDA ,0x2A ,0xA7 ,0x88 ,0xA6 ,0x09 ,0xD1 ,0x48
        };//0x062107B9, 0xFC752D62, 0xA903F220, 0xDA2AA788, 0xA609D148  //2012-05-30 JianSheng Modify
        
        unsigned char MAGSPINE[20]=
        {0x50 ,0xCE ,0xAD ,0x2C ,0x65 ,0x4D ,0x4A ,0xFF ,0xCE ,0x39 ,0xCE ,0x26 ,0xA5 ,0x0D ,0x75 ,0x4C ,0xB2 ,0x9F ,0x63 ,0x06
        };//0x50CEAD2C, 0x654D4AFF, 0xCE39CE26, 0xA50D754C, 0xB29F6306  //2012-05-30 JianSheng Modify
        
        unsigned char IPAD1[20]=
        {0x47 ,0xF5 ,0xF3 ,0x4C ,0xA1 ,0x10 ,0xA8 ,0x05 ,0x98 ,0x34 ,0x3F ,0xFF ,0x2D ,0xCD ,0x6E ,0x10 ,0x12 ,0x32 ,0x8D ,0xC2
        };//0x46F309B4, 0x49EAA631, 0xBEE6503C, 0x6050B8C1, 0x3031257E
        ////0x47F5F34C, 0xA110A805, 0x98343FFF, 0x2DCD6E10, 0x12328DC2 Modefied by Kevin on 2015-03-12
        
        unsigned char IPAD2[20]=
        {0x0D ,0x1C ,0x9B ,0x72, 0xE5 ,0x56 ,0xD5 ,0x78 ,0xEB ,0x22 ,0x78 ,0x37 ,0xE1 ,0x76 ,0xEC ,0x79 ,0x8E ,0x83 ,0xCC ,0xA7
        };//0x0D1C9B72, 0xE556D578, 0xEB227837, 0xE176EC79, 0x8E83CCA7
        
        //SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
        /*
         unsigned char CURRENTPOST[20] = {
         0x3D ,0x6A ,0x7B ,0x4D ,0x6D ,0x39 ,0x35 ,0xBC ,0xED ,0xE1 ,0x45 ,0xC2 ,0x54 ,0x26 ,0x2E ,0x19 ,0x0B ,0x92 ,0x3B ,0xC9
         };
         */
        //change Current Test Post-burn CB to 0x85 and change password.
        //change by caijunbo on 2011-10-05
        unsigned char CURRENTPOST[20] = {
            0x11 ,0xee ,0xf9 ,0x37 ,0x4c ,0x98 ,0x1d ,0xc7 ,0x72 ,0xaf ,0xa9 ,0x9e ,0x50 ,0xf6 ,0x27 ,0x14 ,0x66 ,0x73 ,0x8b ,0xd8
        };//11 ee f9 37 4c 98 1d c7 72 af a9 9e 50 f6 27 14 66 73 8b d8  20120210 judith modify
        //change by caijunbo on 2011-10-05
        //end
        
        //SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
        unsigned char V8PRESS[20] = {
            0x35 ,0x80 ,0xDE ,0xDE ,0x5D ,0xB1 ,0xFC ,0x4B ,0x10 ,0xC3 ,0xAE ,0xFE ,0xBA ,0x4A ,0xB2 ,0x1C ,0x41 ,0x46 ,0x57 ,0x05
        };//0x3580DEDE5D 0xB1FC4B10C3 0xAEFEBA4AB2 0x1C41465705  Modify by kenshin on 2012-02-10
        
        unsigned char SIMTRAY[20] = {
            0x0F ,0x92 ,0x58 ,0xB9 ,0x59 ,0xA0 ,0xC2 ,0x30 ,0xF8 ,0xEC ,0x26 ,0x9E ,0x94 ,0x2F ,0x42 ,0x21 ,0x29 ,0xE7 ,0x92 ,0xA2
        };//0x0F9258B959 0xA0C230F8EC 0x269E942F42 0x2129E792A2   Modify by kenshin on 2012-02-10
        //end
        
        if([mStationName isEqualToString: @"GROUNDING"]) // Ready
            memcpy(cStatinPassword,GROUNDING,20);
        
        if([mStationName isEqualToString: @"HEFFEFFECT"]) // Ready
            memcpy(cStatinPassword,HEFFEFFECT,20);
        
        if([mStationName isEqualToString: @"GRAPEOFFSET"]) // Ready
            memcpy(cStatinPassword,GRAPEOFFSET,20);
		
		if([mStationName isEqualToString: @"QT1"]) // Ready
			memcpy(cStatinPassword,QT1,20);
		
		if([mStationName isEqualToString: @"CONNECTIVITY1"])
			memcpy(cStatinPassword, CONNECTIVITY1,20);
		
		if([mStationName isEqualToString: @"CONNECTIVITY2"])
			memcpy(cStatinPassword, CONNECTIVITY2,20);
		
		if([mStationName isEqualToString: @"QT0A"])
			memcpy(cStatinPassword, QT0A,20);
		
		if([mStationName isEqualToString: @"QT0B"])
			memcpy(cStatinPassword, QT0B,20);
		
		if([mStationName isEqualToString: @"QT3"])
			memcpy(cStatinPassword, PROXCAL,20);
		
		if([mStationName isEqualToString: @"MAGNETCOVER"])
			memcpy(cStatinPassword, MAGCOVER,20);
		
		if([mStationName isEqualToString: @"MAGNETSPINE"])
			memcpy(cStatinPassword, MAGSPINE,20);
		
		if([mStationName isEqualToString: @"IPAD1"])
			memcpy(cStatinPassword, IPAD1,20);
		
		if([mStationName isEqualToString: @"IPAD2"])
			memcpy(cStatinPassword, IPAD2,20);
		
		//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
		if([mStationName isEqualToString: @"CURRENTPOST"])
			memcpy(cStatinPassword, CURRENTPOST,20);
		
		//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
		if([mStationName isEqualToString: @"V8PRESS"])
			memcpy(cStatinPassword, V8PRESS,20);
		
		if([mStationName isEqualToString: @"SIMTRAY"])
			memcpy(cStatinPassword, SIMTRAY,20);
		//end
		
		printf("printing password");
		unsigned char *charSHA1Return = CreateSHA1(cStatinPassword, cTempNonce);
		
		for(int i = 0; i < 20; i++) 
			printf("0x%02x ", charSHA1Return[i]);
		printf("\n");
		
		
		/************************** send fg 0x34 0 ************************/
		NSString *endFlag = @">";
		//NSString* strFg = @"fg 0x34 0\n";
		
		if(flag)
			mCBCmd = [mCBCmd stringByAppendingString:@" pass\n"];
		else 
			mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
		bTmp = [self SendData:dictKeyDefined :mCBCmd :endFlag] ;
		
		if (bTmp==FALSE)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
			continue;
			//return ;	
		}
		
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			mTimeOut = @"5";
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
					break ;
				else
					usleep(500000) ; //delay 500
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
			
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
				continue;
				//return ;
			}
			NSLog(@"\n after send fg return :%@",dataResult);
		} 
		
		//step 3 send the new password to unit 
		bTmp = [self SendDataAsNSData:dictKeyDefined :[NSData dataWithBytes:charSHA1Return length:20] :@":-)"] ;
		
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			continue;
			//return ;
		}
		
		
		//step 5 : check the responding data .
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
					break ;
				else
					usleep(500000) ; //delay 500
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
				continue;
				//return ;
			}
			
			NSLog(@"\n after received data is :%@",dataResult) ;
			if(mBufferName !=nil)
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
		}
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
		return ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;	
	return ;
		
}
//SCRID:151 End

//Added by Annie for CB erasing password 2014.10.7
+(void)RS232ControlBitErasePassWord:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	
	NSString *mBufferName=nil    ;
	
	NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mReferenceBufferName2=nil;
	//NSString *mReferenceBufferName3=nil;
	
	//SCRID:39 change -:) to :-)
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	NSString *mControlOrPosionBit = @"yes";
	NSString *mReferenceBufferName=nil ;
	NSString *mCBCmd=nil;
	NSString *mStationName =@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*--------dengshouxiu-----------------*/
		else if ([strKey isEqualToString:@"ControlOrPosionBit"])
		{
			mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCBCmd"])
		{
			mCBCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StationName"])
		{
			mStationName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName3"])
//		{
//			mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
//		}
	}
	
	/*SCRID-132: Add check SN before write CB. Ray 2011-08-22*/
	NSString *mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
//	NSString *mReferenceBufferValue3=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3];
	if(mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, no sn"];
		return;
	}
//	else
//	{
//		if([mReferenceBufferValue2 rangeOfString:mReferenceBufferValue3].length<=0)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, sn change"];
//			return;
//		}
//	}
	/*SCRID-132: end*/
	
	//2011-01-12 for new CB
	//change the string back to network byte order
	
//	BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
//	if(!flag)
//	{
//		NSString *dataResultFail = @"fail";
//		mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
//        
//        //JianSheng Add 2013-11-07 : If still fail with the second limits, write fail CB 5 times
//        if(bSetFailCB5Times)
//        {
//            for(int i=1; i<5; i++)
//            {
//                bool bTmp_KK = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
//                if (bTmp_KK==FALSE)
//                {
//                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
//                    return ;
//                }
//                
//                NSDate *dateTmpKK=[[[NSDate alloc] init] autorelease] ;
//                mTimeOut = @"5";
//                int iTmpKK = [mTimeOut intValue] ;
//                int timeIntervalKK = - [dateTmpKK timeIntervalSinceNow] ;
//                while (timeIntervalKK<=iTmpKK)
//                {
//                    timeIntervalKK = -[dateTmpKK timeIntervalSinceNow] ;
//                    
//                    if ([self CheckReceDataIsComplete:dictKeyDefined])
//                        break ;
//                    else
//                        usleep(50000) ; //delay 50
//                }
//                //read data
//                dataResultFail = [self ReceData:dictKeyDefined] ;
//                
//            }
//        }
//        //JianSheng Add end 2013-11-07 
//        
//		bool bTmp = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
//		if (bTmp==FALSE)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
//			return ;
//		}
//		
//		{
//			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
//			mTimeOut = @"5";
//			int iTmp = [mTimeOut intValue] ;
//			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
//			while (timeInterval<=iTmp)
//			{
//				timeInterval = -[dateTmp timeIntervalSinceNow] ;
//				
//				if ([self CheckReceDataIsComplete:dictKeyDefined])
//					break ;
//				else
//					usleep(50000) ; //delay 50
//			}
//			//read data
//			dataResultFail = [self ReceData:dictKeyDefined] ;
//			
//			if (dataResultFail==nil)
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
//				return ;
//			}
//			NSLog(@"\n after send fg return :%@",dataResultFail);
//		}
//		if(mBufferName !=nil)
//			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResultFail] ;
//		
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
//		return;
//		
//	}
	
	//step 1 : set cmd :getnonce .
	mWriteCmd = @"getnonce\n" ;
	bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	if (mCBCmd==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
		return ;
	}
	
	//step 2 :check receivd data
	unsigned char *charNonce =NULL;
	unsigned char cTempNonce[20];
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = [mTimeOut intValue] ;
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:dictKeyDefined])
			break ;
		else
			usleep(50000) ; //delay 50
	}
	//read data
	//NSString *dataResult = [self ReceData:dictKeyDefined] ;
	
	NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
	if (dataReceTmp==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
		return ;
	}
	
	if ([dataReceTmp length] < 35)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive error data"] ;
		return ;
	}
	charNonce = (void*)[dataReceTmp bytes] ;
	NSLog(@"\n receive data length is :%d n string is %s",[dataReceTmp length],charNonce) ;
	
	for(int x=0;x<35;x++)
		printf("0x%02x ",charNonce[x]);
	printf("\n");
	
	memcpy(cTempNonce, charNonce+10, 20);
	for(int x=0;x<20;x++)
		printf("0x%02x ",cTempNonce[x]);
	
	
	/************************** do SHA1 ************************/
	/*	unsigned char cStatinPassword[20]={
	 0x97 ,0x6a ,0xe1 ,0xf6 ,0x8f ,0xe5 ,0xbb, 0xb3 ,0xa8 ,0xcf,
	 0x92 ,0xe2 ,0x11 ,0x80 ,0x84 ,0x3d ,0x19 ,0x17 ,0xe9 ,0x5c
	 };
	 */
	//Password changed for J1J2 by Henry 2011-03-03
	unsigned char cStatinPassword[20];
    
    unsigned char CG_Button[20]=
	{0xBA ,0xDB ,0xD7 ,0xDB ,0xE8 ,0x68 ,0x1B ,0x32 ,0xC4 ,0xD5 ,0x89 ,0xEC ,0xC5 ,0xE8 ,0x70 ,0x72 ,0xEB ,0xCA ,0xFB ,0x38
	};//0xBADBD7DB, 0xE8681B32, 0xC4D589EC, 0xC5E87072, 0xEBCAFB38 //2014-07-11 Annie Added
    unsigned char GROUNDING[20]=
	{0xF6 ,0xD6 ,0xD7 ,0x92 ,0x46 ,0x1C ,0x24 ,0x0A ,0x35 ,0x0D ,0xD7 ,0xC1 ,0x46 ,0x68 ,0x32 ,0x9D ,0xC4 ,0x26 ,0xB4 ,0x82
	}; //0xF6D6D792, 0x461C240A, 0x350DD7C1, 0x4668329D, 0xC426B482 //2012-05-30 JianSheng Modify
    unsigned char HEFFEFFECT[20]=
	{0x4E ,0xD5 ,0x7B ,0x7E ,0x4D ,0x93 ,0xB8 ,0xF9 ,0x99 ,0x6A ,0x9F ,0x31 ,0x5A ,0x47 ,0xA2 ,0x0C ,0x35 ,0x92 ,0xAB ,0x4D
	}; //0x4ED57B7E, 0x4D93B8F9, 0x996A9F31, 0x5A47A20C, 0x3592AB4D //Modified by JianSheng on 2013-12-18
    
    unsigned char GRAPEOFFSET[20]=
	{0xA6 ,0x3C ,0xCF ,0x9D ,0x2B ,0x3A ,0x5D ,0xE1 ,0x53 ,0x42 ,0x33 ,0x6E ,0x89 ,0xDE ,0x96 ,0x22 ,0xBF ,0x51 ,0xE1 ,0xAC
	}; //0xA63CCF9D, 0x2B3A5DE1, 0x5342336E, 0x89DE9622, 0xBF51E1AC //2012-05-30 JianSheng Modify
	unsigned char CONNECTIVITY1[20]=
	{0x00 ,0xEB ,0xCF ,0x4E ,0x6D ,0x09 ,0xE3 ,0xC7 ,0x24 ,0x0E ,0xB4 ,0x10 ,0x59 ,0xF2 ,0x74 ,0x3E ,0x51 ,0xF3 ,0x37 ,0x78
	};//0xD88CB098, 0x6961A540, 0x7265F6F8, 0x1047251D, 0xBD6AF254  //Modified by Annie on 2014-07-11
    //0x00EBCF4E, 0x6D09E3C7, 0x240EB410, 0x59F2743E, 0x51F33778  Modified by kevin on 2015-03-12
    
	unsigned char QT1[20]=
	{0x2C ,0x0E ,0x55 ,0x86 ,0x48 ,0x54 ,0x22 ,0xC4 ,0x14 ,0xB6 ,0xA2 ,0xB4 ,0x4B ,0x85 ,0x89 ,0x62 ,0x0E ,0xEB ,0x12 ,0x59
    };//0x032327C5, 0xD19909D6, 0x3C1B11D6, 0x967E2733, 0x6C6E3B5E //Modified by Annie on 2014-07-11
    //0x2C0E5586, 0x485422C4, 0x14B6A2B4, 0x4B858962, 0x0EEB1259   20150314 By Kevin Modified
    
	//SCRID:133 Change Connectivity2 CB password.
	unsigned char CONNECTIVITY2[20]=
	{0xA2 ,0x1C ,0x4F ,0xC7 ,0xB2 ,0xE8 ,0xA8 ,0xCC ,0x4B ,0xFB ,0x8B ,0xDE ,0xC2 ,0x5F ,0x55 ,0x17 ,0x47 ,0xE7 ,0xAB ,0x6F
	};//0xAEB692B3, 0x644AD4DB, 0xFA033442, 0x8C4A8B3B, 0xB7D2A795 //Modified by Annie on 2014-07-11
    //0xA21C4FC7, 0xB2E8A8CC, 0x4BFB8BDE, 0xC25F5517, 0x47E7AB6F  Modified by kevin on 2015-03-12
    
    unsigned char FOS[20]=
	{0x67 ,0x1B ,0xD3 ,0x31 ,0x34 ,0x41 ,0x82 ,0xC9 ,0x92 ,0xF9 ,0x31 ,0xDD ,0x3D ,0x33 ,0x59 ,0x71 ,0xE0 ,0x46 ,0xB8 ,0x54
	};//0xDEFC8B2F, 0xC3DC0A95, 0x428E95BB, 0xDF0FEFD8, 0xC61498A2 //Modified by Annie on 2014-07-11
    //0x671BD331, 0x344182C9, 0x92F931DD, 0x3D335971, 0xE046B854   Modified bu kevin on 2015-03-12
    
	unsigned char QT0A[20]=
	{0x9C ,0xAA ,0xC6 ,0x5B ,0x47 ,0x29 ,0xC0 ,0x94 ,0x24 ,0x0B ,0xBF ,0xB5 ,0x0E ,0xC1 ,0x2C ,0xA4 ,0x9E ,0x72 ,0x60 ,0x3E
	};//0xF6A503E4, 0xC5A80200, 0x5303C3EF, 0xC353BB70, 0xEAD576FB //Modified by Annie on 2014-07-11
    //0x9CAAC65B, 0x4729C094, 0x240BBFB5, 0x0EC12CA4, 0x9E72603E  Modified by kevin on 2015-03-12
    
	unsigned char QT0B[20]=
    {0x94 ,0x8E ,0x7D ,0xE7 ,0xBC ,0xBA ,0x56 ,0x23 ,0x0E ,0x75 ,0x8B ,0x0D ,0x67 ,0xD7 ,0xDD ,0x02 ,0x88 ,0xDB ,0x2F ,0xF0
	};//0xB665F876, 0x7BADE463, 0xA97C523A, 0x2A6CCA3F, 0xEBE5C698 //Modified by Annie on 2014-07-11
    //0x948E7DE7, 0xBCBA5623, 0x0E758B0D, 0x67D7DD02, 0x88DB2FF0  Modified by Kevin on 2015-03-12
    
	unsigned char PROXCAL[20]=
	{0x63 ,0x79 ,0xC2 ,0x31 ,0xCA ,0x5A ,0x67 ,0x8E ,0xDB ,0xDE ,0xB8 ,0xAA ,0x6E ,0xD9 ,0xA0 ,0x38 ,0x91 ,0x28 ,0x7E ,0x0E
	};//0x6379C231, 0xCA5A678E, 0xDBDEB8AA, 0x6ED9A038, 0x91287E0E //Modified by JianSheng on 2013-12-18
	
	unsigned char MAGCOVER[20]=
	{0xCE ,0x52 ,0x53 ,0xd4 ,0x23 ,0x04 ,0x40 ,0xb5 ,0xFB ,0xF7 ,0x4A ,0x3e ,0x36 ,0x7A ,0xDE ,0xe5 ,0x0A ,0x20 ,0x9B ,0xe5
	};//CE5253d4230440b5FBF74A3e367ADEe50A209Be5 modified by Lucky on 2013-4-9
    
	unsigned char MAGSPINE[20]=
	{0xD5 ,0x4B ,0x4D ,0xa7 ,0xB3 ,0x9A ,0x8A ,0x26 ,0xAB ,0x9A ,0xD3 ,0x30 ,0x43 ,0xD0 ,0x5F ,0x9f ,0xB4 ,0x74 ,0x30 ,0xd2
	};//D54B4Da7B39A8A26AB9AD33043D05F9fB47430d2 modified by Lucky on 2013-4-9
    
    unsigned char MAGRETMAP[20]=
	{0xC8 ,0x4B ,0xD2 ,0xE4 ,0x01 ,0x2D ,0x99 ,0x95 ,0x96 ,0x08 ,0xFA ,0xB5 ,0x09 ,0x93 ,0x2C ,0xF6 ,0x98 ,0xD0 ,0x74 ,0x1A
	};//0xB08DA58D, 0xDC4F46F7, 0x7C73B62A, 0xAA00AF8D, 0x21451320 //Modified by Annie on 2014-07-11
    //0xC84BD2E4, 0x012D9995, 0x9608FAB5, 0x09932CF6, 0x98D0741A  Modified by kevin on 2015-03-12
    
	unsigned char IPAD1[20]=
	{0x47 ,0xF5 ,0xF3 ,0x4C ,0xA1 ,0x10 ,0xA8 ,0x05 ,0x98 ,0x34 ,0x3F ,0xFF ,0x2D ,0xCD ,0x6E ,0x10 ,0x12 ,0x32 ,0x8D ,0xC2
	};//0x1D0FD206, 0x5C402F5F, 0x67D34A39, 0xD0C37C6D, 0x69ECAA0A //Modified by JianSheng on 2013-12-18
    ////0x47F5F34C, 0xA110A805, 0x98343FFF, 0x2DCD6E10, 0x12328DC2 Modefied by Kevin on 2015-03-12
    
	unsigned char IPAD2[20]=
	{0x0D ,0x1C ,0x9B ,0x72, 0xE5 ,0x56 ,0xD5 ,0x78 ,0xEB ,0x22 ,0x78 ,0x37 ,0xE1 ,0x76 ,0xEC ,0x79 ,0x8E ,0x83 ,0xCC ,0xA7
	};//0x0D1C9B72, 0xE556D578, 0xEB227837, 0xE176EC79, 0x8E83CCA7
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	/*
     unsigned char CURRENTPOST[20] = {
     0x3D ,0x6A ,0x7B ,0x4D ,0x6D ,0x39 ,0x35 ,0xBC ,0xED ,0xE1 ,0x45 ,0xC2 ,0x54 ,0x26 ,0x2E ,0x19 ,0x0B ,0x92 ,0x3B ,0xC9
     };
	 */
	//change Current Test Post-burn CB to 0x85 and change password.
	//change by caijunbo on 2011-10-05
	unsigned char CURRENTPOST[20] = {
		0x11 ,0xee ,0xf9 ,0x37 ,0x4c ,0x98 ,0x1d ,0xc7 ,0x72 ,0xaf ,0xa9 ,0x9e ,0x50 ,0xf6 ,0x27 ,0x14 ,0x66 ,0x73 ,0x8b ,0xd8
	};//11 ee f9 37 4c 98 1d c7 72 af a9 9e 50 f6 27 14 66 73 8b d8  20120210 judith modify
	//change by caijunbo on 2011-10-05
	//end
	
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	unsigned char V8PRESS[20] = {
		0x35 ,0x80 ,0xDE ,0xDE ,0x5D ,0xB1 ,0xFC ,0x4B ,0x10 ,0xC3 ,0xAE ,0xFE ,0xBA ,0x4A ,0xB2 ,0x1C ,0x41 ,0x46 ,0x57 ,0x05
	};//0x3580DEDE5D 0xB1FC4B10C3 0xAEFEBA4AB2 0x1C41465705  Modify by kenshin on 2012-02-10
	
	unsigned char SIMTRAY[20] = {
		0x11 ,0xFE ,0x7D ,0xB1 ,0x95 ,0xB2 ,0xBE ,0xED ,0x9A ,0x92 ,0x16 ,0xD1 ,0xFE ,0xBD ,0xF6 ,0xB2 ,0xE6 ,0x21 ,0xD1 ,0x33
	};//0x11FE7DB1, 0x95B2BEED, 0x9A9216D1, 0xFEBDF6B2, 0xE621D133   Modify by JianSheng on 2015-08-01
	//end
    
    unsigned char AUTOBOOT[20] = {
		0xFB ,0x3B ,0x22 ,0x4B ,0xBF ,0xB4 ,0x8C ,0xB5 ,0x70 ,0x97 ,0xDE ,0x78 ,0xAB ,0xF3 ,0x5D ,0xDD ,0xB1 ,0x58 ,0xA5 ,0xFC
	};//0xFB3B224B, 0xBFB48CB5, 0x7097DE78, 0xABF35DDD, 0xB158A5FC
    unsigned char QT4[20] = {
		0x0F ,0xBE ,0x94 ,0xF2 ,0x92 ,0xD7 ,0xD3 ,0x8C ,0x61 ,0x44 ,0x68 ,0xD4 ,0x14 ,0xFA ,0x97 ,0xDA ,0x5C ,0x2A ,0xD3 ,0x60
	}; //0x0FBE94F2, 0x92D7D38C, 0x614468D4, 0x14FA97DA, 0x5C2AD360 //Modified by JianSheng on 2013-12-18
    
    unsigned char DEVICEID[20] = {
		0x6C ,0xB5 ,0x38 ,0xAF ,0xD2 ,0xB9 ,0xFD ,0x58 ,0xD0 ,0x95 ,0x55 ,0xD4 ,0x2D ,0x81 ,0x09 ,0x93 ,0x0A ,0xF4 ,0xB0 ,0x8C
	};//6CB538AFD2B9FD58D09555D42D8109930AF4B08C
    
    unsigned char PHOSPHORUS[20] = {
		0x4E ,0x94 ,0x4B ,0xE7 ,0xAC ,0x36 ,0xB5 ,0x6D ,0xE9 ,0x6D ,0x4F ,0x6B ,0xC2 ,0xC3 ,0x5E ,0x7B ,0xC1 ,0xE2 ,0x0B ,0x1D
	};//0x4E944BE7, 0xAC36B56D, 0xE96D4F6B, 0xC2C35E7B, 0xC1E20B1D  //Modified by JianSheng on 2013-12-18
    
    
	unsigned char CONNECTIVITY3[20]={
        0x08 ,0xBF ,0x20 ,0x81 ,0x85 ,0x26 ,0x70 ,0x1B ,0x48 ,0x7D ,0x5B ,0x67 ,0x49 ,0x55 ,0xA0 ,0x96 ,0xEB ,0x99 ,0xA7 ,0x33
	};//0xA87B0F0E, 0xD2443845, 0xE72C01C2, 0xFC98A275, 0x42C8D2D1 //Modified by JianSheng on 2013-12-18
    //0x08BF2081, 0x8526701B, 0x487D5B67, 0x4955A096, 0xEB99A733   Modified by kevin on 20150-03-12
    
	unsigned char GRAPE_1[20]={
        0x9F ,0xFF ,0x4F ,0x2B ,0xF3 ,0x83 ,0x5D ,0x17 ,0x89 ,0x0F ,0xC9 ,0x3E ,0x48 ,0x74 ,0xF2 ,0x59 ,0x87 ,0xA4 ,0x15 ,0x22
	};//0x2A7F8E21, 0x5042F450, 0x1566BB6C, 0xC2CDDCFB, 0xB4859F9E //Modified by JianSheng on 2013-12-18
    //0x9FFF4F2B, 0xF3835D17, 0x890FC93E, 0x4874F259, 0x87A41522  //Modified by Kevin on 2015-03-12
    
    if([mStationName isEqualToString: @"CG_Button"]) // Ready
		memcpy(cStatinPassword,CG_Button,20);
    
	if([mStationName isEqualToString: @"GROUNDING"]) // Ready
		memcpy(cStatinPassword,GROUNDING,20);
    
    if([mStationName isEqualToString: @"QT4"]) // Ready
		memcpy(cStatinPassword,QT4,20);
    
    if([mStationName isEqualToString: @"HEFFEFFECT"]) // Ready
		memcpy(cStatinPassword,HEFFEFFECT,20);
    
    if([mStationName isEqualToString: @"GRAPEOFFSET"]) // Ready
		memcpy(cStatinPassword,GRAPEOFFSET,20);
    
	if([mStationName isEqualToString: @"QT1"]) // Ready
		memcpy(cStatinPassword,QT1,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY1"])
		memcpy(cStatinPassword, CONNECTIVITY1,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY2"])
		memcpy(cStatinPassword, CONNECTIVITY2,20);
    
    if([mStationName isEqualToString: @"FOS"])
		memcpy(cStatinPassword, FOS,20);
	
	if([mStationName isEqualToString: @"QT0A"])
		memcpy(cStatinPassword, QT0A,20);
	
	if([mStationName isEqualToString: @"QT0B"])
		memcpy(cStatinPassword, QT0B,20);
	
	if([mStationName isEqualToString: @"QT3"])
		memcpy(cStatinPassword, PROXCAL,20);
	
	if([mStationName isEqualToString: @"MAGNETCOVER"])
		memcpy(cStatinPassword, MAGCOVER,20);
	
	if([mStationName isEqualToString: @"MAGNETSPINE"])
		memcpy(cStatinPassword, MAGSPINE,20);
    
    //ADD by JianSheng on 2012-10-17
    if([mStationName isEqualToString: @"MAGRETMAP"])
		memcpy(cStatinPassword, MAGRETMAP,20);
	//ADD by JianSheng on 2012-10-17 end
    
	if([mStationName isEqualToString: @"IPAD1"])
		memcpy(cStatinPassword, IPAD1,20);
	
	if([mStationName isEqualToString: @"IPAD2"])
		memcpy(cStatinPassword, IPAD2,20);
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	if([mStationName isEqualToString: @"CURRENTPOST"])
		memcpy(cStatinPassword, CURRENTPOST,20);
	
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	if([mStationName isEqualToString: @"V8PRESS"])
		memcpy(cStatinPassword, V8PRESS,20);
	
	if([mStationName isEqualToString: @"SIMTRAY"])
		memcpy(cStatinPassword, SIMTRAY,20);
	//end
    if([mStationName isEqualToString: @"AUTOBOOT"])
		memcpy(cStatinPassword, AUTOBOOT,20);
    
    if([mStationName isEqualToString: @"DEVICEID"])
		memcpy(cStatinPassword, DEVICEID,20);
    
    if([mStationName isEqualToString: @"CONNECTIVITY3"])
		memcpy(cStatinPassword, CONNECTIVITY3,20);
    
    if([mStationName isEqualToString: @"PHOSPHORUS"])
		memcpy(cStatinPassword, PHOSPHORUS,20);
    
    if([mStationName isEqualToString: @"GRAPE-1"])
		memcpy(cStatinPassword, GRAPE_1,20);
    
    
    
	
	printf("printing password");
	unsigned char *charSHA1Return = CreateSHA1(cStatinPassword, cTempNonce);
	
	for(int i = 0; i < 20; i++)
		printf("0x%02x ", charSHA1Return[i]);
	printf("\n");
	
	
	/************************** send fg 0x34 0 ************************/
	NSString *endFlag = @">";
	//NSString* strFg = @"fg 0x34 0\n";
	
//	if(flag)
//		mCBCmd = [mCBCmd stringByAppendingString:@" pass\n"];
//	else
//		mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
	bTmp = [self SendData:dictKeyDefined :mCBCmd :endFlag] ;
	
	if (bTmp==FALSE)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
		return ;
	}
	
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		mTimeOut = @"5";
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
				usleep(50000) ; //delay 50
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		NSLog(@"\n after send fg return :%@",dataResult);
	}
	
	//step 3 send the new password to unit
	bTmp = [self SendDataAsNSData:dictKeyDefined :[NSData dataWithBytes:charSHA1Return length:20] :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	
	//step 5 : check the responding data .
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
				usleep(50000) ; //delay 50
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		
		NSLog(@"\n after received data is :%@",dataResult) ;
		if(mBufferName !=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	return ;
}

/*SCRID-111: add by Joko to add a parser for new CB write*/
+(void)RS232WriteControlAndPosionBitPassWordV2:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;// write cmd
    
    NSString *mBufferName=nil    ;
    
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mWhetherRead = @"yes" ;
    NSString *mReferenceBufferName2=nil;
    NSString *mReferenceBufferName3=nil;
    
    //SCRID:39 change -:) to :-)
    NSString *mPostfix =@":-)";
    NSString *mTestItemName=nil     ;
    
    NSString *mControlOrPosionBit = @"yes";
    NSString *mReferenceBufferName=nil ;
    NSString *mCBCmd=nil;
    NSString *mStationName =@"";
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WhetherRead"])
        {
            mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        /*--------dengshouxiu-----------------*/
        else if ([strKey isEqualToString:@"ControlOrPosionBit"])
        {
            mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCBCmd"])
        {
            mCBCmd = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"StationName"])
        {
            mStationName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName3"])
        {
            mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    /*SCRID-132: Add check SN before write CB. Ray 2011-08-22*/
    NSString *mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    NSString *mReferenceBufferValue3=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3];
    if(mReferenceBufferValue2==nil||mReferenceBufferValue3==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, no sn"];
        return;
    }
    else
    {
        if([mReferenceBufferValue2 rangeOfString:mReferenceBufferValue3].length<=0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, sn change"];
            return;
        }
    }
    /*SCRID-132: end*/
    
    //2011-01-12 for new CB
    //change the string back to network byte order
    
    BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
    if(!flag)
    {
        NSString *dataResultFail = @"fail";
        mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
        
        //JianSheng Add 2013-11-07 : If still fail with the second limits, write fail CB 5 times  || 20160114 Tiffany remove
//        if(bSetFailCB5Times)
//        {
//            for(int i=1; i<5; i++)
//            {
//                bool bTmp_KK = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
//                if (bTmp_KK==FALSE)
//                {
//                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
//                    return ;
//                }
//                
//                NSDate *dateTmpKK=[[[NSDate alloc] init] autorelease] ;
//                mTimeOut = @"5";
//                int iTmpKK = [mTimeOut intValue] ;
//                int timeIntervalKK = - [dateTmpKK timeIntervalSinceNow] ;
//                while (timeIntervalKK<=iTmpKK)
//                {
//                    timeIntervalKK = -[dateTmpKK timeIntervalSinceNow] ;
//                    
//                    if ([self CheckReceDataIsComplete:dictKeyDefined])
//                        break ;
//                    else
//                        usleep(50000) ; //delay 50
//                }
//                //read data
//                dataResultFail = [self ReceData:dictKeyDefined] ;
//                
//            }
//        }
        //JianSheng Add end 2013-11-07  ||  20160114 Tiffany remove
        
        bool bTmp = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
        if (bTmp==FALSE)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
            return ;
        }
        
        {
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            mTimeOut = @"5";
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                    usleep(50000) ; //delay 50
            }
            //read data
            dataResultFail = [self ReceData:dictKeyDefined] ;
            
            if (dataResultFail==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
                return ;
            }
            NSLog(@"\n after send fg return :%@",dataResultFail);
        }
        if(mBufferName !=nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResultFail] ;
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
        return;
        
    }
    
    //step 1 : set cmd :getnonce .
    mWriteCmd = @"getnonce\n" ;
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    if (mCBCmd==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
        return ;
    }
    
    //step 2 :check receivd data
    unsigned char *charNonce =NULL;
    unsigned char cTempNonce[20];
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
            usleep(50000) ; //delay 50
    }
    //read data
    //NSString *dataResult = [self ReceData:dictKeyDefined] ;
    
    NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
    if (dataReceTmp==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
        return ;
    }
    
    if ([dataReceTmp length] < 35)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive error data"] ;
        return ;
    }
    charNonce = (void*)[dataReceTmp bytes] ;
    NSLog(@"\n receive data length is :%d n string is %s",[dataReceTmp length],charNonce) ;
    
    for(int x=0;x<35;x++)
        printf("0x%02x ",charNonce[x]);
    printf("\n");
    
    memcpy(cTempNonce, charNonce+10, 20);
    for(int x=0;x<20;x++)
        printf("0x%02x ",cTempNonce[x]);
    
    
    /************************** do SHA1 ************************/
    /*	unsigned char cStatinPassword[20]={
     0x97 ,0x6a ,0xe1 ,0xf6 ,0x8f ,0xe5 ,0xbb, 0xb3 ,0xa8 ,0xcf,
     0x92 ,0xe2 ,0x11 ,0x80 ,0x84 ,0x3d ,0x19 ,0x17 ,0xe9 ,0x5c
     };
     */
    //Password changed for J1J2 by Henry 2011-03-03
    unsigned char cStatinPassword[20];
    
    unsigned char CG_Button[20]=
    {0xBA ,0xDB ,0xD7 ,0xDB ,0xE8 ,0x68 ,0x1B ,0x32 ,0xC4 ,0xD5 ,0x89 ,0xEC ,0xC5 ,0xE8 ,0x70 ,0x72 ,0xEB ,0xCA ,0xFB ,0x38
    };//0xBADBD7DB, 0xE8681B32, 0xC4D589EC, 0xC5E87072, 0xEBCAFB38 //2014-07-11 Annie Added
    unsigned char GROUNDING[20]=
    {0xF6 ,0xD6 ,0xD7 ,0x92 ,0x46 ,0x1C ,0x24 ,0x0A ,0x35 ,0x0D ,0xD7 ,0xC1 ,0x46 ,0x68 ,0x32 ,0x9D ,0xC4 ,0x26 ,0xB4 ,0x82
    }; //0xF6D6D792, 0x461C240A, 0x350DD7C1, 0x4668329D, 0xC426B482 //2012-05-30 JianSheng Modify
    unsigned char HEFFEFFECT[20]=
    {0x4E ,0xD5 ,0x7B ,0x7E ,0x4D ,0x93 ,0xB8 ,0xF9 ,0x99 ,0x6A ,0x9F ,0x31 ,0x5A ,0x47 ,0xA2 ,0x0C ,0x35 ,0x92 ,0xAB ,0x4D
    }; //0x4ED57B7E, 0x4D93B8F9, 0x996A9F31, 0x5A47A20C, 0x3592AB4D //Modified by JianSheng on 2013-12-18
    
    unsigned char GRAPEOFFSET[20]=
    {0xA6 ,0x3C ,0xCF ,0x9D ,0x2B ,0x3A ,0x5D ,0xE1 ,0x53 ,0x42 ,0x33 ,0x6E ,0x89 ,0xDE ,0x96 ,0x22 ,0xBF ,0x51 ,0xE1 ,0xAC
    }; //0xA63CCF9D, 0x2B3A5DE1, 0x5342336E, 0x89DE9622, 0xBF51E1AC //2012-05-30 JianSheng Modify
    unsigned char CONNECTIVITY1[20]=
    {0x2B ,0x0C ,0x6C ,0xCD ,0xC7 ,0x15 ,0x14 ,0x99 ,0xE6 ,0x37 ,0x8C ,0xA0 ,0x7F ,0x7E ,0x81 ,0x0B ,0x34 ,0x58 ,0xE7 ,0x9E
    };//0xD88CB098, 0x6961A540, 0x7265F6F8, 0x1047251D, 0xBD6AF254  //Modified by Annie on 2014-07-11
    //0x00EBCF4E, 0x6D09E3C7, 0x240EB410, 0x59F2743E, 0x51F33778  Modified by kevin on 2015-03-12
    
    //{0x2B0C6CCD, 0xC7151499, 0xE6378CA0, 0x7F7E810B, 0x3458E79E}  Modified by Jack on 2015-11-12
    
    unsigned char QT1[20]=
    {0x9D ,0x22 ,0xC1 ,0x4E ,0xC8 ,0x1C ,0xCA ,0xD6 ,0x3B ,0x4B ,0x59 ,0xEA ,0x8D ,0xCA ,0x78 ,0xA1 ,0x3A ,0xD4 ,0x5D ,0x35
    };//0x032327C5, 0xD19909D6, 0x3C1B11D6, 0x967E2733, 0x6C6E3B5E //Modified by Annie on 2014-07-11
    //0x2C0E5586, 0x485422C4, 0x14B6A2B4, 0x4B858962, 0x0EEB1259   20150314 By Kevin Modified
    
    //{0x9D22C14E, 0xC81CCAD6, 0x3B4B59EA, 0x8DCA78A1, 0x3AD45D35} Modified by Jack on 2015-11-12
    
    //SCRID:133 Change Connectivity2 CB password.
    unsigned char CONNECTIVITY2[20]=
    {0x8D ,0x5D ,0x46 ,0x6B ,0xB9 ,0xDC ,0x3B ,0xBA ,0xDE ,0x47 ,0x40 ,0x9F ,0x84 ,0x1D ,0x68 ,0xDB ,0x5C ,0x65 ,0x23 ,0x2B
    };//0xAEB692B3, 0x644AD4DB, 0xFA033442, 0x8C4A8B3B, 0xB7D2A795 //Modified by Annie on 2014-07-11
    //0xA21C4FC7, 0xB2E8A8CC, 0x4BFB8BDE, 0xC25F5517, 0x47E7AB6F  Modified by kevin on 2015-03-12
    
    // {0x8D5D466B, 0xB9DC3BBA, 0xDE47409F, 0x841D68DB, 0x5C65232B}Modified by Jack on 2015-11-12
    
    unsigned char FOS[20]=
    {0xAD ,0xE5 ,0x69 ,0x4F ,0xF2 ,0x45 ,0x57 ,0x8D ,0x17 ,0x02 ,0xBB ,0xB9 ,0x6B ,0x0C ,0xDF ,0x68 ,0xD8 ,0x5D ,0xC1 ,0x77
    };//0xDEFC8B2F, 0xC3DC0A95, 0x428E95BB, 0xDF0FEFD8, 0xC61498A2 //Modified by Annie on 2014-07-11
    //0x671BD331, 0x344182C9, 0x92F931DD, 0x3D335971, 0xE046B854   Modified bu kevin on 2015-03-12
    
    // {0xADE5694F, 0xF245578D, 0x1702BBB9, 0x6B0CDF68, 0xD85DC177}Modified bu Jack on 2015-03-12
    
    unsigned char QT0A[20]=
    {0xB1 ,0xF0 ,0x21 ,0x47 ,0xB9 ,0xC7 ,0x19 ,0xFF ,0x91 ,0x1A ,0x4D ,0x11 ,0xF2 ,0x71 ,0x7E ,0xE2 ,0x4F ,0xE8 ,0xC4 ,0x34
    };//0xF6A503E4, 0xC5A80200, 0x5303C3EF, 0xC353BB70, 0xEAD576FB //Modified by Annie on 2014-07-11
    //0x9CAAC65B, 0x4729C094, 0x240BBFB5, 0x0EC12CA4, 0x9E72603E  Modified by kevin on 2015-03-12
    
    //{0xB1F02147, 0xB9C719FF, 0x911A4D11, 0xF2717EE2, 0x4FE8C434}//Modified by Jack on 2015-11-12
    
    unsigned char QT0B[20]=
    {0x94 ,0xA1 ,0x81 ,0xAC ,0x0B ,0x41 ,0x27 ,0x95 ,0x7E ,0xE9 ,0xD1 ,0xF8 ,0x78 ,0x80 ,0xB5 ,0xA3 ,0xA5 ,0x88 ,0x75 ,0x90
    };//0xB665F876, 0x7BADE463, 0xA97C523A, 0x2A6CCA3F, 0xEBE5C698 //Modified by Annie on 2014-07-11
    //0x948E7DE7, 0xBCBA5623, 0x0E758B0D, 0x67D7DD02, 0x88DB2FF0  Modified by Kevin on 2015-03-12
    
    //{0x94A181AC, 0x0B412795, 0x7EE9D1F8, 0x7880B5A3, 0xA5887590}  Modified by Jack on 2015-11-12
    
    
    
    unsigned char PROXCAL[20]=
    {0x63 ,0x79 ,0xC2 ,0x31 ,0xCA ,0x5A ,0x67 ,0x8E ,0xDB ,0xDE ,0xB8 ,0xAA ,0x6E ,0xD9 ,0xA0 ,0x38 ,0x91 ,0x28 ,0x7E ,0x0E
    };//0x6379C231, 0xCA5A678E, 0xDBDEB8AA, 0x6ED9A038, 0x91287E0E //Modified by JianSheng on 2013-12-18
    
    unsigned char MAGCOVER[20]=
    {0xCE ,0x52 ,0x53 ,0xd4 ,0x23 ,0x04 ,0x40 ,0xb5 ,0xFB ,0xF7 ,0x4A ,0x3e ,0x36 ,0x7A ,0xDE ,0xe5 ,0x0A ,0x20 ,0x9B ,0xe5
    };//CE5253d4230440b5FBF74A3e367ADEe50A209Be5 modified by Lucky on 2013-4-9
    
    unsigned char MAGSPINE[20]=
    {0xD5 ,0x4B ,0x4D ,0xa7 ,0xB3 ,0x9A ,0x8A ,0x26 ,0xAB ,0x9A ,0xD3 ,0x30 ,0x43 ,0xD0 ,0x5F ,0x9f ,0xB4 ,0x74 ,0x30 ,0xd2
    };//D54B4Da7B39A8A26AB9AD33043D05F9fB47430d2 modified by Lucky on 2013-4-9
    
    unsigned char MAGRETMAP[20]=
    {0x8B ,0x22 ,0xF5 ,0x3B ,0x33 ,0x04 ,0x3A ,0xB8 ,0xF2 ,0x60 ,0x54 ,0xED ,0xCE ,0xC4 ,0xD4 ,0x11 ,0x89 ,0x14 ,0x8B ,0x92
    };//0xB08DA58D, 0xDC4F46F7, 0x7C73B62A, 0xAA00AF8D, 0x21451320 //Modified by Annie on 2014-07-11
    //0xC84BD2E4, 0x012D9995, 0x9608FAB5, 0x09932CF6, 0x98D0741A  Modified by kevin on 2015-03-12
    
    //{0x8B22F53B, 0x33043AB8, 0xF26054ED, 0xCEC4D411, 0x89148B92}//Modified by Jack on 2015-11-12
    
    
    unsigned char IPAD1[20]=
    {0x47 ,0xF5 ,0xF3 ,0x4C ,0xA1 ,0x10 ,0xA8 ,0x05 ,0x98 ,0x34 ,0x3F ,0xFF ,0x2D ,0xCD ,0x6E ,0x10 ,0x12 ,0x32 ,0x8D ,0xC2
    };//0x1D0FD206, 0x5C402F5F, 0x67D34A39, 0xD0C37C6D, 0x69ECAA0A //Modified by JianSheng on 2013-12-18
    //0x47F5F34C, 0xA110A805, 0x98343FFF, 0x2DCD6E10, 0x12328DC2 Modefied by Kevin on 2015-03-12
    
    unsigned char IPAD2[20]=
    {0x0D ,0x1C ,0x9B ,0x72, 0xE5 ,0x56 ,0xD5 ,0x78 ,0xEB ,0x22 ,0x78 ,0x37 ,0xE1 ,0x76 ,0xEC ,0x79 ,0x8E ,0x83 ,0xCC ,0xA7
    };//0x0D1C9B72, 0xE556D578, 0xEB227837, 0xE176EC79, 0x8E83CCA7
    
    //SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
    /*
     unsigned char CURRENTPOST[20] = {
     0x3D ,0x6A ,0x7B ,0x4D ,0x6D ,0x39 ,0x35 ,0xBC ,0xED ,0xE1 ,0x45 ,0xC2 ,0x54 ,0x26 ,0x2E ,0x19 ,0x0B ,0x92 ,0x3B ,0xC9
     };
     */
    //change Current Test Post-burn CB to 0x85 and change password.
    //change by caijunbo on 2011-10-05
    unsigned char CURRENTPOST[20] = {
        0x11 ,0xee ,0xf9 ,0x37 ,0x4c ,0x98 ,0x1d ,0xc7 ,0x72 ,0xaf ,0xa9 ,0x9e ,0x50 ,0xf6 ,0x27 ,0x14 ,0x66 ,0x73 ,0x8b ,0xd8
    };//11 ee f9 37 4c 98 1d c7 72 af a9 9e 50 f6 27 14 66 73 8b d8  20120210 judith modify
    //change by caijunbo on 2011-10-05
    //end
    
    //SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
    unsigned char V8PRESS[20] = {
        0x35 ,0x80 ,0xDE ,0xDE ,0x5D ,0xB1 ,0xFC ,0x4B ,0x10 ,0xC3 ,0xAE ,0xFE ,0xBA ,0x4A ,0xB2 ,0x1C ,0x41 ,0x46 ,0x57 ,0x05
    };//0x3580DEDE5D 0xB1FC4B10C3 0xAEFEBA4AB2 0x1C41465705  Modify by kenshin on 2012-02-10
    
    unsigned char SIMTRAY[20] = {
        0x25 ,0x91 ,0x19 ,0x7A ,0xCB ,0x9A ,0x4B ,0x09 ,0x04 ,0x65 ,0x1B ,0xF7 ,0xF1 ,0xAD ,0x40 ,0x07 ,0x9A ,0x44 ,0xF6 ,0x2B
    };//0xD5, {0x2591197A, 0xCB9A4B09, 0x04651BF7, 0xF1AD4007, 0x9A44F62B} modified by Annie 2015.11.26
    
    
    unsigned char AUTOBOOT[20] = {
        0xFB ,0x3B ,0x22 ,0x4B ,0xBF ,0xB4 ,0x8C ,0xB5 ,0x70 ,0x97 ,0xDE ,0x78 ,0xAB ,0xF3 ,0x5D ,0xDD ,0xB1 ,0x58 ,0xA5 ,0xFC
    };//0xFB3B224B, 0xBFB48CB5, 0x7097DE78, 0xABF35DDD, 0xB158A5FC
    unsigned char QT4[20] = {
        0x0F ,0xBE ,0x94 ,0xF2 ,0x92 ,0xD7 ,0xD3 ,0x8C ,0x61 ,0x44 ,0x68 ,0xD4 ,0x14 ,0xFA ,0x97 ,0xDA ,0x5C ,0x2A ,0xD3 ,0x60
    }; //0x0FBE94F2, 0x92D7D38C, 0x614468D4, 0x14FA97DA, 0x5C2AD360 //Modified by JianSheng on 2013-12-18
    
    unsigned char DEVICEID[20] = {
        0x6C ,0xB5 ,0x38 ,0xAF ,0xD2 ,0xB9 ,0xFD ,0x58 ,0xD0 ,0x95 ,0x55 ,0xD4 ,0x2D ,0x81 ,0x09 ,0x93 ,0x0A ,0xF4 ,0xB0 ,0x8C
    };//6CB538AFD2B9FD58D09555D42D8109930AF4B08C
    
    unsigned char PHOSPHORUS[20] = {
        0x4E ,0x94 ,0x4B ,0xE7 ,0xAC ,0x36 ,0xB5 ,0x6D ,0xE9 ,0x6D ,0x4F ,0x6B ,0xC2 ,0xC3 ,0x5E ,0x7B ,0xC1 ,0xE2 ,0x0B ,0x1D
    };//0x4E944BE7, 0xAC36B56D, 0xE96D4F6B, 0xC2C35E7B, 0xC1E20B1D  //Modified by JianSheng on 2013-12-18
    
    
    unsigned char CONNECTIVITY3[20]={
        0x08 ,0xBF ,0x20 ,0x81 ,0x85 ,0x26 ,0x70 ,0x1B ,0x48 ,0x7D ,0x5B ,0x67 ,0x49 ,0x55 ,0xA0 ,0x96 ,0xEB ,0x99 ,0xA7 ,0x33
    };//0xA87B0F0E, 0xD2443845, 0xE72C01C2, 0xFC98A275, 0x42C8D2D1 //Modified by JianSheng on 2013-12-18
    //0x08BF2081, 0x8526701B, 0x487D5B67, 0x4955A096, 0xEB99A733   Modified by kevin on 20150-03-12
    
    
    unsigned char GRAPE_1[20]={
        0x9F ,0xFF ,0x4F ,0x2B ,0xF3 ,0x83 ,0x5D ,0x17 ,0x89 ,0x0F ,0xC9 ,0x3E ,0x48 ,0x74 ,0xF2 ,0x59 ,0x87 ,0xA4 ,0x15 ,0x22
    };//0x2A7F8E21, 0x5042F450, 0x1566BB6C, 0xC2CDDCFB, 0xB4859F9E //Modified by JianSheng on 2013-12-18
    //0x9FFF4F2B, 0xF3835D17, 0x890FC93E, 0x4874F259, 0x87A41522  //Modified by Kevin on 2015-03-12
    
    unsigned char SIMDETECT[20]={
        0x8E ,0x70 ,0xDB ,0x37 ,0xD2 ,0xA4 ,0x85 ,0x8E ,0x24 ,0xF4 ,0xCD ,0x08 ,0x5F ,0x15 ,0x64 ,0xD8 ,0xF0 ,0xF1 ,0x0C ,0xDF
    }; //0x8E70DB37, 0xD2A4858E, 0x24F4CD08, 0x5F1564D8, 0xF0F10CDF  //Modified by Jack on 2015-04-07
    
    unsigned char ADR[20]={
        0xDC ,0x1D ,0xBC ,0x24 ,0x29 ,0x26 ,0x02 ,0x52 ,0x93 ,0xB3 ,0x8A ,0x10 ,0x12 ,0x20 ,0xB2 ,0x29 ,0xC4 ,0xB0 ,0xB7 ,0x7D
    }; //0xDC 1D BC 24, 0x29 26 02 52, 0x93 B3 8A 10, 0x12 20 B2 29, 0xC4 B0 B7 7D  //Modified by Andy on 2016-03-04
    
    if([mStationName isEqualToString: @"AbnormalDisplayRecovery"])
        memcpy(cStatinPassword,ADR,20);
    
    if([mStationName isEqualToString: @"CG_Button"]) // Ready
        memcpy(cStatinPassword,CG_Button,20);
    
    if([mStationName isEqualToString: @"GROUNDING"]) // Ready
        memcpy(cStatinPassword,GROUNDING,20);
    
    if([mStationName isEqualToString: @"QT4"]) // Ready
        memcpy(cStatinPassword,QT4,20);
    
    if([mStationName isEqualToString: @"HEFFEFFECT"]) // Ready
        memcpy(cStatinPassword,HEFFEFFECT,20);
    
    if([mStationName isEqualToString: @"GRAPEOFFSET"]) // Ready
        memcpy(cStatinPassword,GRAPEOFFSET,20);
    
    if([mStationName isEqualToString: @"QT1"]) // Ready
        memcpy(cStatinPassword,QT1,20);
    
    if([mStationName isEqualToString: @"CONNECTIVITY1"])
        memcpy(cStatinPassword, CONNECTIVITY1,20);
    
    if([mStationName isEqualToString: @"CONNECTIVITY2"])
        memcpy(cStatinPassword, CONNECTIVITY2,20);
    
    if([mStationName isEqualToString: @"FOS"])
        memcpy(cStatinPassword, FOS,20);
    
    if([mStationName isEqualToString: @"QT0A"])
        memcpy(cStatinPassword, QT0A,20);
    
    if([mStationName isEqualToString: @"QT0B"])
        memcpy(cStatinPassword, QT0B,20);
    
    if([mStationName isEqualToString: @"QT3"])
        memcpy(cStatinPassword, PROXCAL,20);
    
    if([mStationName isEqualToString: @"MAGNETCOVER"])
        memcpy(cStatinPassword, MAGCOVER,20);
    
    if([mStationName isEqualToString: @"MAGNETSPINE"])
        memcpy(cStatinPassword, MAGSPINE,20);
    
    //ADD by JianSheng on 2012-10-17
    if([mStationName isEqualToString: @"MAGRETMAP"])
        memcpy(cStatinPassword, MAGRETMAP,20);
    //ADD by JianSheng on 2012-10-17 end
    
    if([mStationName isEqualToString: @"IPAD1"])
        memcpy(cStatinPassword, IPAD1,20);
    
    if([mStationName isEqualToString: @"IPAD2"])
        memcpy(cStatinPassword, IPAD2,20);
    
    //SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
    if([mStationName isEqualToString: @"CURRENTPOST"])
        memcpy(cStatinPassword, CURRENTPOST,20);
    
    //SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
    if([mStationName isEqualToString: @"V8PRESS"])
        memcpy(cStatinPassword, V8PRESS,20);
    
    if([mStationName isEqualToString: @"SIMTRAY"])
        memcpy(cStatinPassword, SIMTRAY,20);
    //end
    if([mStationName isEqualToString: @"AUTOBOOT"])
        memcpy(cStatinPassword, AUTOBOOT,20);
    
    if([mStationName isEqualToString: @"DEVICEID"])
        memcpy(cStatinPassword, DEVICEID,20);
    
    if([mStationName isEqualToString: @"CONNECTIVITY3"])
        memcpy(cStatinPassword, CONNECTIVITY3,20);
    
    if([mStationName isEqualToString: @"PHOSPHORUS"])
        memcpy(cStatinPassword, PHOSPHORUS,20);
    
    if([mStationName isEqualToString: @"GRAPE-1"])
        memcpy(cStatinPassword, GRAPE_1,20);
    
    if ([mStationName isEqualToString:@"SIMDETECT"]) {
        memcpy(cStatinPassword, SIMDETECT, 20 );
    }//Modified by Jack on 2015-04-07
    
    
    printf("printing password");
    unsigned char *charSHA1Return = CreateSHA1(cStatinPassword, cTempNonce);
    
    for(int i = 0; i < 20; i++)
        printf("0x%02x ", charSHA1Return[i]);
    printf("\n");
    
    
    /************************** send fg 0x34 0 ************************/
    NSString *endFlag = @">";
    //NSString* strFg = @"fg 0x34 0\n";
    
    if(flag)
        mCBCmd = [mCBCmd stringByAppendingString:@" pass\n"];
    else
        mCBCmd = [mCBCmd stringByAppendingString:@" fail\n"];
    bTmp = [self SendData:dictKeyDefined :mCBCmd :endFlag] ;
    
    if (bTmp==FALSE)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
        return ;
    }
    
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        mTimeOut = @"5";
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
                usleep(50000) ; //delay 50
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
            return ;
        }
        NSLog(@"\n after send fg return :%@",dataResult);
    }
    
    //step 3 send the new password to unit
    bTmp = [self SendDataAsNSData:dictKeyDefined :[NSData dataWithBytes:charSHA1Return length:20] :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    
    //step 5 : check the responding data .
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        mTimeOut = @"30";// mTimeOut = @"5" Updated by Andy, 20160311.
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
                usleep(50000) ; //delay 50
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
            return ;
        }
        
        NSLog(@"\n after received data is :%@",dataResult) ;
        if(mBufferName !=nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    return ;
}
/*SCRID-111: end*/

/*SCRID:63 add by Joko to add a parser for new CB write*/
+(void)RS232WriteControlAndPosionBitPassWord:(NSDictionary*)dictKeyDefined 
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	
	NSString *mBufferName=nil    ;
	
	NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	
	//SCRID:39 change -:) to :-)
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	NSString *mControlOrPosionBit = @"yes";
	NSString *mReferenceBufferName=nil ;
	NSString *mCBCmd=nil;
	NSString *mStationName =@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}		
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*--------dengshouxiu-----------------*/
		else if ([strKey isEqualToString:@"ControlOrPosionBit"])
		{
			mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCBCmd"])
		{
			mCBCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StationName"])
		{
			mStationName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	//2011-01-12 for new CB
	//change the string back to network byte order
	
	BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
	if(!flag)
	{
		NSString *dataResultFail = @"fail";
		mCBCmd = [mCBCmd stringByAppendingString:@" 2\n"];
		bool bTmp = [self SendData:dictKeyDefined :mCBCmd :@":-)"] ;
		if (bTmp==FALSE)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
			return ;	
		}
		
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			mTimeOut = @"5";
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
					break ;
				else
					usleep(500000) ; //delay 500
			}
			//read data
			dataResultFail = [self ReceData:dictKeyDefined] ;
			
			if (dataResultFail==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
				return ;
			}
			NSLog(@"\n after send fg return :%@",dataResultFail);
		}
		if(mBufferName !=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResultFail] ;
		
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		return;
		
	}
	
	//step 1 : set cmd :getnonce .
	mWriteCmd = @"getnonce\n" ;
	bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	if (mCBCmd==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
		return ;
	}
	
	//step 2 :check receivd data 
	unsigned char *charNonce =NULL;
	unsigned char cTempNonce[20];
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = [mTimeOut intValue] ;
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:dictKeyDefined]) 
			break ;
		else
			usleep(500000) ; //delay 500
	}
	//read data
	//NSString *dataResult = [self ReceData:dictKeyDefined] ;
	
	NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
	if (dataReceTmp==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
		return ;
	}
	
	if ([dataReceTmp length] < 35)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive error data"] ;
		return ;	
	}
	charNonce = (void*)[dataReceTmp bytes] ;
	NSLog(@"\n receive data length is :%d n string is %s",[dataReceTmp length],charNonce) ;
	
	for(int x=0;x<35;x++)
		printf("0x%02x ",charNonce[x]);
	printf("\n");
	
	memcpy(cTempNonce, charNonce+10, 20);
	for(int x=0;x<20;x++)
		printf("0x%02x ",cTempNonce[x]);

	
/************************** do SHA1 ************************/
/*	unsigned char cStatinPassword[20]={
	0x97 ,0x6a ,0xe1 ,0xf6 ,0x8f ,0xe5 ,0xbb, 0xb3 ,0xa8 ,0xcf,
	0x92 ,0xe2 ,0x11 ,0x80 ,0x84 ,0x3d ,0x19 ,0x17 ,0xe9 ,0x5c
};
*/	
	//Password changed for J1J2 by Henry 2011-03-03
	unsigned char cStatinPassword[20];
	unsigned char QT1[20]=
	{0x40 ,0xaa ,0x12 ,0xf9 ,0x9b ,0x24 ,0x92, 0x1e ,0x4d ,0x55 ,0xf5 ,0x6f ,0x80 ,0xbe ,0x17 ,0xa1 ,0xf5 ,0x1f ,0x44 ,0xb5
	};//40 aa 12 f9 9b 24 92 1e 4d 55 f5 6f 80 be 17 a1 f5 1f 44 b5
	unsigned char GATEKEEPER[20]=
	{0x09 ,0xdb ,0xf9 ,0xbd ,0xd9 ,0x64 ,0x57 ,0x26 ,0x53 ,0xfc ,0x1a ,0x09 ,0x71 ,0x55 ,0x8c ,0x9a ,0x51 ,0x84 ,0xb9 ,0x00
	};
	unsigned char CONNECTIVITY1[20]=
	{0x48 ,0x25 ,0x5b ,0xef ,0xb0 ,0xcc ,0xdd ,0x76 ,0x43 ,0x17 ,0xe6 ,0x39 ,0xe0 ,0x11 ,0x7e ,0x06 ,0x89 ,0xc8 ,0x60 ,0x7a
	};//48 25 5b ef b0 cc dd 76 43 17 e6 39 e0 11 7e 06 89 c8 60 7a
	
	unsigned char CONNECTIVITY2[20]=
	{0x4e ,0x07 ,0x9e ,0xc6 ,0x77 ,0x86 ,0x9c ,0xf1 ,0x1d ,0x0e ,0x09 ,0x32 ,0x48 ,0x31 ,0xe1 ,0x36 ,0xc9 ,0x65 ,0x7d ,0xed
	};//4e 07 9e c6 77 86 9c f1 1d 0e 09 32 48 31 e1 36 c9 65 7d ed
	
	unsigned char QT0A[20]=
	{0x17 ,0x90 ,0x4b ,0x7b ,0x73 ,0x6b ,0x10 ,0xc3 ,0x95 ,0x8b ,0x4c ,0x2c ,0xbb ,0xe1 ,0xc8 ,0x35 ,0x05 ,0x3b ,0xa6 ,0x72
	};//17 90 4b 7b 73 6b 10 c3 95 8b 4c 2c bb e1 c8 35 05 3b a6 72
	
	unsigned char QT0B[20]=
	{0x9c ,0x9b ,0x2f ,0x2b ,0x9a ,0x32 ,0x7c ,0xac ,0xa5 ,0xd2 ,0x1a ,0xf6 ,0x1a ,0x6c ,0xe5 ,0xa0 ,0x34 ,0xc7 ,0x6a ,0x52
	};//9c 9b 2f 2b 9a 32 7c ac a5 d2 1a f6 1a 6c e5 a0 34 c7 6a 52
	
	unsigned char PROXCAL[20]=
	{0xb8 ,0x79 ,0xa3 ,0x78 ,0x02 ,0xbd ,0x94 ,0x3b ,0xd1 ,0x79 ,0x13 ,0x2e ,0xcf ,0x01 ,0x4a ,0xa9 ,0xf6 ,0x08 ,0xf4 ,0x02
	};//b8 79 a3 78 02 bd 94 3b d1 79 13 2e cf 01 4a a9 f6 08 f4 02
	
	unsigned char MAGCOVER[20]=
	{0xcf ,0x6a ,0x60 ,0x1f ,0xf4 ,0xed ,0x2e ,0x74 ,0x59 ,0x2c ,0x27 ,0x3d ,0x49 ,0x13 ,0x73 ,0x24 ,0x2a ,0x87 ,0x8b ,0xe1
	};//cf 6a 60 1f f4 ed 2e 74 59 2c 27 3d 49 13 73 24 2a 87 8b e1
	
	unsigned char MAGSPINE[20]=
	{0x36 ,0x24 ,0xfc ,0x8a ,0x16 ,0xe3 ,0xc9 ,0x58 ,0x12 ,0xde ,0x00 ,0xc8 ,0x13 ,0x0d ,0x14 ,0x7a ,0x54 ,0x26 ,0xd1 ,0x22
	};//36 24 fc 8a 16 e3 c9 58 12 de 00 c8 13 0d 14 7a 54 26 d1 22
	
	unsigned char IPAD1[20]=
	{0xfa ,0xfc ,0xa4 ,0xef ,0xd4 ,0x8c ,0x49 ,0x92 ,0x9a ,0x08 ,0xf7 ,0xee ,0xb3 ,0xad ,0x64 ,0x8e ,0x5a ,0xb6 ,0x2e ,0xce
	};//fa fc a4 ef d4 8c 49 92 9a 08 f7 ee b3 ad 64 8e 5a b6 2e ce
	
	unsigned char IPAD2[20]=
	{0xc8 ,0xa3 ,0x8e ,0x98 ,0x9a ,0x26 ,0x4e ,0xa7 ,0xd2 ,0x3f ,0xc1 ,0x4a ,0xc5 ,0xd4 ,0xcd ,0xe5 ,0xb9 ,0x68 ,0x17 ,0x08
	};//c8 a3 8e 98 9a 26 4e a7 d2 3f c1 4a c5 d4 cd e5 b9 68 17 08
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	/*
	 unsigned char CURRENTPOST[20] = {
	 0x3D ,0x6A ,0x7B ,0x4D ,0x6D ,0x39 ,0x35 ,0xBC ,0xED ,0xE1 ,0x45 ,0xC2 ,0x54 ,0x26 ,0x2E ,0x19 ,0x0B ,0x92 ,0x3B ,0xC9
	 };
	 */
	//change Current Test Post-burn CB to 0x85 and change password.
	//change by caijunbo on 2011-10-05
	unsigned char CURRENTPOST[20] = {
		0xB6 ,0x5C ,0x11 ,0x49 ,0x83 ,0xD3 ,0xC9 ,0x53 ,0x20 ,0xDA ,0x9A ,0x57 ,0xCB ,0x1E ,0x67 ,0x10 ,0xF0 ,0xDF ,0xCF ,0x6F
	};
	//change by caijunbo on 2011-10-05
	//end
	unsigned char QT4[20] = {
		0x43,0xE1,0x58,0xA7,0x19,0xB5,0x49,0xB5,0xF7,0x23,0xD2,0x86,0x0A,0xE2,0xE2,0xDC,0x9F,0x7B,0x1C,0xA9
	};
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	unsigned char V8PRESS[20] = {
		0x1C ,0x95 ,0x67 ,0xC2 ,0x85 ,0x11 ,0xDB ,0xF2 ,0xF7 ,0x13 ,0x37 ,0x3F ,0x45 ,0x06 ,0x5A ,0xCC ,0x10 ,0x1D ,0xD8 ,0x6D
	};
	
	unsigned char SIMTRAY[20] = {
		0x32 ,0x02 ,0x63 ,0x19 ,0xFB ,0xFB ,0xDD ,0x76 ,0xE8 ,0xB3 ,0xD7 ,0x50 ,0x7A ,0xB9 ,0xDA ,0x2F ,0x3B ,0x3B ,0x1C ,0x7B
	};
	//end
	
	
	if([mStationName isEqualToString: @"QT1"]) // Ready
		memcpy(cStatinPassword,QT1,20);
	
    if([mStationName isEqualToString: @"QT4"]) // Ready
		memcpy(cStatinPassword,QT4,20);
    
	if([mStationName isEqualToString: @"GATEKEEPER"]) // Ready
		memcpy(cStatinPassword,GATEKEEPER,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY1"])
		memcpy(cStatinPassword, CONNECTIVITY1,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY2"])
		memcpy(cStatinPassword, CONNECTIVITY2,20);
	
	if([mStationName isEqualToString: @"QT0A"])
		memcpy(cStatinPassword, QT0A,20);
	
	if([mStationName isEqualToString: @"QT0B"])
		memcpy(cStatinPassword, QT0B,20);
	
	if([mStationName isEqualToString: @"QT3"])
		memcpy(cStatinPassword, PROXCAL,20);
	
	if([mStationName isEqualToString: @"MAGNETCOVER"])
		memcpy(cStatinPassword, MAGCOVER,20);
	
	if([mStationName isEqualToString: @"MAGNETSPINE"])
		memcpy(cStatinPassword, MAGSPINE,20);
	
	if([mStationName isEqualToString: @"IPAD1"])
		memcpy(cStatinPassword, IPAD1,20);
	
	if([mStationName isEqualToString: @"IPAD2"])
		memcpy(cStatinPassword, IPAD2,20);
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	if([mStationName isEqualToString: @"CURRENTPOST"])
		memcpy(cStatinPassword, CURRENTPOST,20);
	
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	if([mStationName isEqualToString: @"V8PRESS"])
		memcpy(cStatinPassword, V8PRESS,20);
	
	if([mStationName isEqualToString: @"SIMTRAY"])
		memcpy(cStatinPassword, SIMTRAY,20);
	//end
	
	printf("printing password");
	unsigned char *charSHA1Return = CreateSHA1(cStatinPassword, cTempNonce);
	
	 for(int i = 0; i < 20; i++) 
	 printf("0x%02x ", charSHA1Return[i]);
	printf("\n");

	
/************************** send fg 0x34 0 ************************/
	NSString *endFlag = @">";
	//NSString* strFg = @"fg 0x34 0\n";
	
	if(flag)
		mCBCmd = [mCBCmd stringByAppendingString:@" 0\n"];
	else 
		mCBCmd = [mCBCmd stringByAppendingString:@" 2\n"];
	bTmp = [self SendData:dictKeyDefined :mCBCmd :endFlag] ;
	
	if (bTmp==FALSE)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
		return ;	
	}

	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		mTimeOut = @"5";
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
				usleep(500000) ; //delay 500
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		NSLog(@"\n after send fg return :%@",dataResult);
	} 
	
	//step 3 send the new password to unit 
	bTmp = [self SendDataAsNSData:dictKeyDefined :[NSData dataWithBytes:charSHA1Return length:20] :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	
//step 5 : check the responding data .
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
				usleep(500000) ; //delay 500
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		
		NSLog(@"\n after received data is :%@",dataResult) ;
		if(mBufferName !=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
	}	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;
}
/*SCRID:63 end*/

+(void)RS232WriteControlAndPosionBit:(NSDictionary*)dictKeyDefined 
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	
	NSString *mBufferName=nil    ;
	
        NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	
	//SCRID:39 change -:) to :-)
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	NSString *mControlOrPosionBit = @"yes";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}		
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*--------dengshouxiu-----------------*/
		else if ([strKey isEqualToString:@"ControlOrPosionBit"])
		{
			mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	BOOL flag = YES;
	
	NSMutableString *strMutSendBuffer = nil;
	
	if ([mControlOrPosionBit boolValue])
	{
		flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
		if(flag)
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 0"];
		else {
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 2"];
		}
		strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
		if (mWriteCmdEnd!=nil)
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
	}
	else
	{
		flag = [TestItemManage checkPriorTestItemResult:dictKeyDefined];
		if (flag)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;//joko add
			return;			
		}
		else
		{
			strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
			if (mWriteCmdEnd!=nil)
				[strMutSendBuffer appendString:mWriteCmdEnd] ;
		}			
	}
	
	bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	if ([mWhetherRead boolValue])
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
				usleep(500000) ; //delay 500
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		//dataResult=@"fg 0x0D 0:-)";
		//joko add 20100730
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		if(mBufferName !=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
	
		if([mControlOrPosionBit boolValue])
		{
			NSRange rangTmp;
			NSString *spec = @"";
			spec = [spec stringByAppendingString: mWriteCmd];
			spec = [spec stringByAppendingString: @" :-)"];
			rangTmp = [dataResult rangeOfString: spec];
			if(mBufferName !=nil)
			{
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
			}	
			
			if(rangTmp.length > 0)
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
			else
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
			return ;
		}
	//joko add end

		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;
}

// add by Paul 09042014 read file:/White List.csv
+(void)ParseWhitList:(NSDictionary*)dictKeyDefined
{
    NSString *fileContent = [NSString stringWithContentsOfFile:@"/White List.csv" encoding:NSASCIIStringEncoding error:nil] ;
    
	if (fileContent==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Exist file :/White List.csv"];
		return ;
	}
    
    fileContent = [fileContent stringByReplacingOccurrencesOfString:@" " withString:@""];
    fileContent = [fileContent stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    NSArray *arrayDeviceIDAll = (NSArray*)[fileContent componentsSeparatedByString:@"\r"];
    
    NSString* unitSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
    
    if([unitSN length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no Unit SN"];
        return;
    }
    
    if([fileContent rangeOfString:unitSN].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"the Unit SN is not in White List"] ;
    }
}
// end by Paul 09042014

+(void)ParseDeviceID:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	
	//NSString *mBuffferName=nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}
        
	}
    
    if(mReferenceBufferName==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    
    NSString *mReferenceBufferValue;
    
    //mReferenceBufferValue = @"Read 5 bytes:	 0x01  0x08  0x58  0xC3  0xCA :-)";
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
                                                     Prefix:mPrefix
                                                    Postfix:mPostfix] ;	
    
    strFind = [strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
    strFind = [strFind stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    strFind = [strFind stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    strFind = [strFind stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    strFind = [strFind stringByReplacingOccurrencesOfString:@"0x" withString:@""];
    
    if (strFind==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
        return  ;
    }
    
    NSString *fileContent = [NSString stringWithContentsOfFile:@"/Anya_scantestXYDeviceID.csv" encoding:NSASCIIStringEncoding error:nil] ;
    
    //NSString *fileContent = [NSString stringWithContentsOfFile:@"/Anya_scantestXYDeviceID.xlsx" encoding:NSASCIIStringEncoding error:nil] ;
    
	if (fileContent==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Exist file :/Anya_scantestXYDeviceID.csv"];
		return ;
	}
    
    fileContent = [fileContent stringByReplacingOccurrencesOfString:@" " withString:@""];
    fileContent = [fileContent stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    NSArray *arrayDeviceIDAll = (NSArray*)[fileContent componentsSeparatedByString:@"\r"];
    
    //BOOL isFail = false;
    
    if ([arrayDeviceIDAll count] < 2)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"1 file :/Anya_scantestXYDeviceID.csv"];
		return ;
	}
    
    for(int i=0; i<[arrayDeviceIDAll count]; i++)
    {
        NSArray *arrayDeviceID1List = (NSArray*)[[arrayDeviceIDAll objectAtIndex:i] componentsSeparatedByString:@","];
        if ([arrayDeviceID1List count] < 2)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"2 file :/Anya_scantestXYDeviceID.csv"];
            return ;
        }
        NSString *tmp = @"";
        for(int n=0; n<[arrayDeviceID1List count]; n++)
        {
            if([[arrayDeviceID1List objectAtIndex:n] length] == 1)
            {
                tmp = [tmp stringByAppendingString:@"0"];
                tmp = [tmp stringByAppendingString:[arrayDeviceID1List objectAtIndex:n]];
            }
            else
                tmp = [tmp stringByAppendingString:[arrayDeviceID1List objectAtIndex:n]];
        }
        
        if([tmp rangeOfString:strFind].length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFind];
            return ;
        }
        
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind];
    
}
//justin add 20141031
+(void)RS232EraseControlAndPosionBitPassWord:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	
	NSString *mBufferName=nil    ;
	
	NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mReferenceBufferName2=nil;
	NSString *mReferenceBufferName3=nil;
	
	//SCRID:39 change -:) to :-)
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	NSString *mControlOrPosionBit = @"yes";
	NSString *mReferenceBufferName=nil ;
	NSString *mCBCmd=nil;
	NSString *mStationName =@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*--------dengshouxiu-----------------*/
		else if ([strKey isEqualToString:@"ControlOrPosionBit"])
		{
			mControlOrPosionBit = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCBCmd"])
		{
			mCBCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StationName"])
		{
			mStationName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName3"])
		{
			mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	/*SCRID-132: Add check SN before write CB. Ray 2011-08-22*/
	NSString *mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
	NSString *mReferenceBufferValue3=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3];
	if(mReferenceBufferValue2==nil||mReferenceBufferValue3==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, no sn"];
		return;
	}
	else
	{
		if([mReferenceBufferValue2 rangeOfString:mReferenceBufferValue3].length<=0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail, sn change"];
			return;
		}
	}
	/*SCRID-132: end*/
	
	//step 1 : set cmd :getnonce .
	mWriteCmd = @"getnonce\n" ;
	bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	if (mCBCmd==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
		return ;
	}
	
	//step 2 :check receivd data
	unsigned char *charNonce =NULL;
	unsigned char cTempNonce[20];
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = [mTimeOut intValue] ;
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:dictKeyDefined])
			break ;
		else
			usleep(50000) ; //delay 50
	}
	//read data
	//NSString *dataResult = [self ReceData:dictKeyDefined] ;
	
	NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
	if (dataReceTmp==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
		return ;
	}
	
	if ([dataReceTmp length] < 35)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive error data"] ;
		return ;
	}
	charNonce = (void*)[dataReceTmp bytes] ;
	NSLog(@"\n receive data length is :%lu n string is %s",(unsigned long)[dataReceTmp length],charNonce) ;
	
	for(int x=0;x<35;x++)
		printf("0x%02x ",charNonce[x]);
	printf("\n");
	
	memcpy(cTempNonce, charNonce+10, 20);
	for(int x=0;x<20;x++)
		printf("0x%02x ",cTempNonce[x]);
	
	/************************** do SHA1 ************************/
	/*	unsigned char cStatinPassword[20]={
	 0x97 ,0x6a ,0xe1 ,0xf6 ,0x8f ,0xe5 ,0xbb, 0xb3 ,0xa8 ,0xcf,
	 0x92 ,0xe2 ,0x11 ,0x80 ,0x84 ,0x3d ,0x19 ,0x17 ,0xe9 ,0x5c
	 };
	 */
	unsigned char cStatinPassword[20];
    
    unsigned char CG_Button[20]=
	{0xBA ,0xDB ,0xD7 ,0xDB ,0xE8 ,0x68 ,0x1B ,0x32 ,0xC4 ,0xD5 ,0x89 ,0xEC ,0xC5 ,0xE8 ,0x70 ,0x72 ,0xEB ,0xCA ,0xFB ,0x38
	};//0xBADBD7DB, 0xE8681B32, 0xC4D589EC, 0xC5E87072, 0xEBCAFB38 //2014-07-11 Annie Added
    unsigned char GROUNDING[20]=
	{0xF6 ,0xD6 ,0xD7 ,0x92 ,0x46 ,0x1C ,0x24 ,0x0A ,0x35 ,0x0D ,0xD7 ,0xC1 ,0x46 ,0x68 ,0x32 ,0x9D ,0xC4 ,0x26 ,0xB4 ,0x82
	}; //0xF6D6D792, 0x461C240A, 0x350DD7C1, 0x4668329D, 0xC426B482 //2012-05-30 JianSheng Modify
    unsigned char HEFFEFFECT[20]=
	{0x4E ,0xD5 ,0x7B ,0x7E ,0x4D ,0x93 ,0xB8 ,0xF9 ,0x99 ,0x6A ,0x9F ,0x31 ,0x5A ,0x47 ,0xA2 ,0x0C ,0x35 ,0x92 ,0xAB ,0x4D
	}; //0x4ED57B7E, 0x4D93B8F9, 0x996A9F31, 0x5A47A20C, 0x3592AB4D //Modified by JianSheng on 2013-12-18
    
    unsigned char GRAPEOFFSET[20]=
	{0xA6 ,0x3C ,0xCF ,0x9D ,0x2B ,0x3A ,0x5D ,0xE1 ,0x53 ,0x42 ,0x33 ,0x6E ,0x89 ,0xDE ,0x96 ,0x22 ,0xBF ,0x51 ,0xE1 ,0xAC
	}; //0xA63CCF9D, 0x2B3A5DE1, 0x5342336E, 0x89DE9622, 0xBF51E1AC //2012-05-30 JianSheng Modify
	unsigned char CONNECTIVITY1[20]=
	{0x00 ,0xEB ,0xCF ,0x4E ,0x6D ,0x09 ,0xE3 ,0xC7 ,0x24 ,0x0E ,0xB4 ,0x10 ,0x59 ,0xF2 ,0x74 ,0x3E ,0x51 ,0xF3 ,0x37 ,0x78
	};//0xD88CB098, 0x6961A540, 0x7265F6F8, 0x1047251D, 0xBD6AF254  //Modified by Annie on 2014-07-11
    //0x00EBCF4E, 0x6D09E3C7, 0x240EB410, 0x59F2743E, 0x51F33778  Modified by kevin on 2015-03-12
    
	unsigned char QT1[20]=
	{0x2C ,0x0E ,0x55 ,0x86 ,0x48 ,0x54 ,0x22 ,0xC4 ,0x14 ,0xB6 ,0xA2 ,0xB4 ,0x4B ,0x85 ,0x89 ,0x62 ,0x0E ,0xEB ,0x12 ,0x59
    };//0x032327C5, 0xD19909D6, 0x3C1B11D6, 0x967E2733, 0x6C6E3B5E //Modified by Annie on 2014-07-11
    //0x2C0E5586, 0x485422C4, 0x14B6A2B4, 0x4B858962, 0x0EEB1259   20150314 By Kevin Modified
    
	//SCRID:133 Change Connectivity2 CB password.
	unsigned char CONNECTIVITY2[20]=
	{0xA2 ,0x1C ,0x4F ,0xC7 ,0xB2 ,0xE8 ,0xA8 ,0xCC ,0x4B ,0xFB ,0x8B ,0xDE ,0xC2 ,0x5F ,0x55 ,0x17 ,0x47 ,0xE7 ,0xAB ,0x6F
	};//0xAEB692B3, 0x644AD4DB, 0xFA033442, 0x8C4A8B3B, 0xB7D2A795 //Modified by Annie on 2014-07-11
    //0xA21C4FC7, 0xB2E8A8CC, 0x4BFB8BDE, 0xC25F5517, 0x47E7AB6F  Modified by kevin on 2015-03-12
    
    
    unsigned char RAT[20]=
    {0x0C ,0x7C ,0x90 ,0x66 ,0x8E ,0x84 ,0x1C ,0x4B ,0x02 ,0xFB ,0x41 ,0xEF ,0x70 ,0x1D ,0x80 ,0xEA ,0x95 ,0xA5 ,0x4F ,0x19
    };
    //0x78, {0x0C7C9066, 0x8E841C4B, 0x02FB41EF, 0x701D80EA, 0x95A54F19}  Add by Jack on 2015-12-15
    
    unsigned char CGOffSet[20]=
    {0x6A ,0x68 ,0x9C ,0x31 ,0x85 ,0x91 ,0xAE ,0x9F ,0x73 ,0xB7 ,0x0F ,0xAD ,0xCB ,0x2F ,0x84 ,0xAF ,0x8B ,0xEB ,0x3E ,0x75
    };
    //0x7C, {0x6A689C31, 0x8591AE9F, 0x73B70FAD, 0xCB2F84AF, 0x8BEB3E75}  Add by Jack on 2015-12-15

    unsigned char FOS[20]=
	{0x67 ,0x1B ,0xD3 ,0x31 ,0x34 ,0x41 ,0x82 ,0xC9 ,0x92 ,0xF9 ,0x31 ,0xDD ,0x3D ,0x33 ,0x59 ,0x71 ,0xE0 ,0x46 ,0xB8 ,0x54
	};//0xDEFC8B2F, 0xC3DC0A95, 0x428E95BB, 0xDF0FEFD8, 0xC61498A2 //Modified by Annie on 2014-07-11
    //0x671BD331, 0x344182C9, 0x92F931DD, 0x3D335971, 0xE046B854   Modified bu kevin on 2015-03-12
    
//	unsigned char QT0A[20]=
//	{0x9C ,0xAA ,0xC6 ,0x5B ,0x47 ,0x29 ,0xC0 ,0x94 ,0x24 ,0x0B ,0xBF ,0xB5 ,0x0E ,0xC1 ,0x2C ,0xA4 ,0x9E ,0x72 ,0x60 ,0x3E
//	};//0xF6A503E4, 0xC5A80200, 0x5303C3EF, 0xC353BB70, 0xEAD576FB //Modified by Annie on 2014-07-11
    //0x9CAAC65B, 0x4729C094, 0x240BBFB5, 0x0EC12CA4, 0x9E72603E  Modified by kevin on 2015-03-12
    unsigned char QT0A[20]=
    {0xB1 ,0xF0 ,0x21 ,0x47 ,0xB9 ,0xC7 ,0x19 ,0xFF ,0x91 ,0x1A ,0x4D ,0x11 ,0xF2 ,0x71 ,0x7E ,0xE2 ,0x4F ,0xE8 ,0xC4 ,0x34
    };//0xF6A503E4, 0xC5A80200, 0x5303C3EF, 0xC353BB70, 0xEAD576FB //Modified by Annie on 2014-07-11
    //0x9CAAC65B, 0x4729C094, 0x240BBFB5, 0x0EC12CA4, 0x9E72603E  Modified by kevin on 2015-03-12
    //{0xB1F02147, 0xB9C719FF, 0x911A4D11, 0xF2717EE2, 0x4FE8C434}//Modified by Jack on 2015-11-12

//	unsigned char QT0B[20]=
//    {0x94 ,0x8E ,0x7D ,0xE7 ,0xBC ,0xBA ,0x56 ,0x23 ,0x0E ,0x75 ,0x8B ,0x0D ,0x67 ,0xD7 ,0xDD ,0x02 ,0x88 ,0xDB ,0x2F ,0xF0
//	};//0xB665F876, 0x7BADE463, 0xA97C523A, 0x2A6CCA3F, 0xEBE5C698 //Modified by Annie on 2014-07-11
    ////0x948E7DE7, 0xBCBA5623, 0x0E758B0D, 0x67D7DD02, 0x88DB2FF0  Modified by Kevin on 2015-03-12
    
    unsigned char QT0B[20]=
    {0x94 ,0xA1 ,0x81 ,0xAC ,0x0B ,0x41 ,0x27 ,0x95 ,0x7E ,0xE9 ,0xD1 ,0xF8 ,0x78 ,0x80 ,0xB5 ,0xA3 ,0xA5 ,0x88 ,0x75 ,0x90
    };//0xB665F876, 0x7BADE463, 0xA97C523A, 0x2A6CCA3F, 0xEBE5C698 //Modified by Annie on 2014-07-11
    //0x948E7DE7, 0xBCBA5623, 0x0E758B0D, 0x67D7DD02, 0x88DB2FF0  Modified by Kevin on 2015-03-12
    //{0x94A181AC, 0x0B412795, 0x7EE9D1F8, 0x7880B5A3, 0xA5887590}  Modified by Jack on 2015-11-12
    
	unsigned char PROXCAL[20]=
	{0x63 ,0x79 ,0xC2 ,0x31 ,0xCA ,0x5A ,0x67 ,0x8E ,0xDB ,0xDE ,0xB8 ,0xAA ,0x6E ,0xD9 ,0xA0 ,0x38 ,0x91 ,0x28 ,0x7E ,0x0E
	};//0x6379C231, 0xCA5A678E, 0xDBDEB8AA, 0x6ED9A038, 0x91287E0E //Modified by JianSheng on 2013-12-18
	
	unsigned char MAGCOVER[20]=
	{0xCE ,0x52 ,0x53 ,0xd4 ,0x23 ,0x04 ,0x40 ,0xb5 ,0xFB ,0xF7 ,0x4A ,0x3e ,0x36 ,0x7A ,0xDE ,0xe5 ,0x0A ,0x20 ,0x9B ,0xe5
	};//CE5253d4230440b5FBF74A3e367ADEe50A209Be5 modified by Lucky on 2013-4-9
    
	unsigned char MAGSPINE[20]=
	{0xD5 ,0x4B ,0x4D ,0xa7 ,0xB3 ,0x9A ,0x8A ,0x26 ,0xAB ,0x9A ,0xD3 ,0x30 ,0x43 ,0xD0 ,0x5F ,0x9f ,0xB4 ,0x74 ,0x30 ,0xd2
	};//D54B4Da7B39A8A26AB9AD33043D05F9fB47430d2 modified by Lucky on 2013-4-9
    
    unsigned char MAGRETMAP[20]=
	{0xC8 ,0x4B ,0xD2 ,0xE4 ,0x01 ,0x2D ,0x99 ,0x95 ,0x96 ,0x08 ,0xFA ,0xB5 ,0x09 ,0x93 ,0x2C ,0xF6 ,0x98 ,0xD0 ,0x74 ,0x1A
	};//0xB08DA58D, 0xDC4F46F7, 0x7C73B62A, 0xAA00AF8D, 0x21451320 //Modified by Annie on 2014-07-11
    //0xC84BD2E4, 0x012D9995, 0x9608FAB5, 0x09932CF6, 0x98D0741A  Modified by kevin on 2015-03-12
    
	unsigned char IPAD1[20]=
	{0x47 ,0xF5 ,0xF3 ,0x4C ,0xA1 ,0x10 ,0xA8 ,0x05 ,0x98 ,0x34 ,0x3F ,0xFF ,0x2D ,0xCD ,0x6E ,0x10 ,0x12 ,0x32 ,0x8D ,0xC2
	};//0x1D0FD206, 0x5C402F5F, 0x67D34A39, 0xD0C37C6D, 0x69ECAA0A //Modified by JianSheng on 2013-12-18
    ////0x47F5F34C, 0xA110A805, 0x98343FFF, 0x2DCD6E10, 0x12328DC2 Modefied by Kevin on 2015-03-12
    
	unsigned char IPAD2[20]=
	{0x0D ,0x1C ,0x9B ,0x72, 0xE5 ,0x56 ,0xD5 ,0x78 ,0xEB ,0x22 ,0x78 ,0x37 ,0xE1 ,0x76 ,0xEC ,0x79 ,0x8E ,0x83 ,0xCC ,0xA7
	};//0x0D1C9B72, 0xE556D578, 0xEB227837, 0xE176EC79, 0x8E83CCA7
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	/*
     unsigned char CURRENTPOST[20] = {
     0x3D ,0x6A ,0x7B ,0x4D ,0x6D ,0x39 ,0x35 ,0xBC ,0xED ,0xE1 ,0x45 ,0xC2 ,0x54 ,0x26 ,0x2E ,0x19 ,0x0B ,0x92 ,0x3B ,0xC9
     };
	 */
	//change Current Test Post-burn CB to 0x85 and change password.
	//change by caijunbo on 2011-10-05
	unsigned char CURRENTPOST[20] = {
		0x11 ,0xee ,0xf9 ,0x37 ,0x4c ,0x98 ,0x1d ,0xc7 ,0x72 ,0xaf ,0xa9 ,0x9e ,0x50 ,0xf6 ,0x27 ,0x14 ,0x66 ,0x73 ,0x8b ,0xd8
	};//11 ee f9 37 4c 98 1d c7 72 af a9 9e 50 f6 27 14 66 73 8b d8  20120210 judith modify
	//change by caijunbo on 2011-10-05
	//end
	
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	unsigned char V8PRESS[20] = {
		0x35 ,0x80 ,0xDE ,0xDE ,0x5D ,0xB1 ,0xFC ,0x4B ,0x10 ,0xC3 ,0xAE ,0xFE ,0xBA ,0x4A ,0xB2 ,0x1C ,0x41 ,0x46 ,0x57 ,0x05
	};//0x3580DEDE5D 0xB1FC4B10C3 0xAEFEBA4AB2 0x1C41465705  Modify by kenshin on 2012-02-10
	
	unsigned char SIMTRAY[20] = {
		0x11 ,0xFE ,0x7D ,0xB1 ,0x95 ,0xB2 ,0xBE ,0xED ,0x9A ,0x92 ,0x16 ,0xD1 ,0xFE ,0xBD ,0xF6 ,0xB2 ,0xE6 ,0x21 ,0xD1 ,0x33
	};//0x11FE7DB1, 0x95B2BEED, 0x9A9216D1, 0xFEBDF6B2, 0xE621D133   Modify by JianSheng on 2015-08-01
	//end
    
    unsigned char AUTOBOOT[20] = {
		0xFB ,0x3B ,0x22 ,0x4B ,0xBF ,0xB4 ,0x8C ,0xB5 ,0x70 ,0x97 ,0xDE ,0x78 ,0xAB ,0xF3 ,0x5D ,0xDD ,0xB1 ,0x58 ,0xA5 ,0xFC
	};//0xFB3B224B, 0xBFB48CB5, 0x7097DE78, 0xABF35DDD, 0xB158A5FC
    unsigned char QT4[20] = {
		0x0F ,0xBE ,0x94 ,0xF2 ,0x92 ,0xD7 ,0xD3 ,0x8C ,0x61 ,0x44 ,0x68 ,0xD4 ,0x14 ,0xFA ,0x97 ,0xDA ,0x5C ,0x2A ,0xD3 ,0x60
	}; //0x0FBE94F2, 0x92D7D38C, 0x614468D4, 0x14FA97DA, 0x5C2AD360 //Modified by JianSheng on 2013-12-18
    
    unsigned char DEVICEID[20] = {
		0x6C ,0xB5 ,0x38 ,0xAF ,0xD2 ,0xB9 ,0xFD ,0x58 ,0xD0 ,0x95 ,0x55 ,0xD4 ,0x2D ,0x81 ,0x09 ,0x93 ,0x0A ,0xF4 ,0xB0 ,0x8C
	};//6CB538AFD2B9FD58D09555D42D8109930AF4B08C
    
    unsigned char PHOSPHORUS[20] = {
		0x4E ,0x94 ,0x4B ,0xE7 ,0xAC ,0x36 ,0xB5 ,0x6D ,0xE9 ,0x6D ,0x4F ,0x6B ,0xC2 ,0xC3 ,0x5E ,0x7B ,0xC1 ,0xE2 ,0x0B ,0x1D
	};//0x4E944BE7, 0xAC36B56D, 0xE96D4F6B, 0xC2C35E7B, 0xC1E20B1D  //Modified by JianSheng on 2013-12-18
    
    
	unsigned char CONNECTIVITY3[20]={
        0x08 ,0xBF ,0x20 ,0x81 ,0x85 ,0x26 ,0x70 ,0x1B ,0x48 ,0x7D ,0x5B ,0x67 ,0x49 ,0x55 ,0xA0 ,0x96 ,0xEB ,0x99 ,0xA7 ,0x33
	};//0xA87B0F0E, 0xD2443845, 0xE72C01C2, 0xFC98A275, 0x42C8D2D1 //Modified by JianSheng on 2013-12-18
    //0x08BF2081, 0x8526701B, 0x487D5B67, 0x4955A096, 0xEB99A733   Modified by kevin on 20150-03-12
    
	unsigned char GRAPE_1[20]={
        0x9F ,0xFF ,0x4F ,0x2B ,0xF3 ,0x83 ,0x5D ,0x17 ,0x89 ,0x0F ,0xC9 ,0x3E ,0x48 ,0x74 ,0xF2 ,0x59 ,0x87 ,0xA4 ,0x15 ,0x22
	};//0x2A7F8E21, 0x5042F450, 0x1566BB6C, 0xC2CDDCFB, 0xB4859F9E //Modified by JianSheng on 2013-12-18
    //0x9FFF4F2B, 0xF3835D17, 0x890FC93E, 0x4874F259, 0x87A41522  //Modified by Kevin on 2015-03-12
    
    unsigned char WAT[20]={
        0xA6,0xF1,0x32,0x40,0x45,0x68,0x6D,0xB6,0xE1,0x97,0x65,0x42,0xA8,0x8E,0x06,0x33,0x98,0x46,0x7D,0x74
	};
    
    if([mStationName isEqualToString: @"CG_Button"]) // Ready
		memcpy(cStatinPassword,CG_Button,20);
    
	if([mStationName isEqualToString: @"GROUNDING"]) // Ready
		memcpy(cStatinPassword,GROUNDING,20);
    
    if([mStationName isEqualToString: @"QT4"]) // Ready
		memcpy(cStatinPassword,QT4,20);
    
    if([mStationName isEqualToString: @"HEFFEFFECT"]) // Ready
		memcpy(cStatinPassword,HEFFEFFECT,20);
    
    if([mStationName isEqualToString: @"GRAPEOFFSET"]) // Ready
		memcpy(cStatinPassword,GRAPEOFFSET,20);
    
	if([mStationName isEqualToString: @"QT1"]) // Ready
		memcpy(cStatinPassword,QT1,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY1"])
		memcpy(cStatinPassword, CONNECTIVITY1,20);
	
	if([mStationName isEqualToString: @"CONNECTIVITY2"])
		memcpy(cStatinPassword, CONNECTIVITY2,20);
    
    if([mStationName isEqualToString: @"FOS"])
		memcpy(cStatinPassword, FOS,20);
	
	if([mStationName isEqualToString: @"QT0A"])
		memcpy(cStatinPassword, QT0A,20);
	
	if([mStationName isEqualToString: @"QT0B"])
		memcpy(cStatinPassword, QT0B,20);
	
	if([mStationName isEqualToString: @"QT3"])
		memcpy(cStatinPassword, PROXCAL,20);
	
	if([mStationName isEqualToString: @"MAGNETCOVER"])
		memcpy(cStatinPassword, MAGCOVER,20);
	
	if([mStationName isEqualToString: @"MAGNETSPINE"])
		memcpy(cStatinPassword, MAGSPINE,20);
    
    //ADD by JianSheng on 2012-10-17
    if([mStationName isEqualToString: @"MAGRETMAP"])
		memcpy(cStatinPassword, MAGRETMAP,20);
	//ADD by JianSheng on 2012-10-17 end
    
	if([mStationName isEqualToString: @"IPAD1"])
		memcpy(cStatinPassword, IPAD1,20);
	
	if([mStationName isEqualToString: @"IPAD2"])
		memcpy(cStatinPassword, IPAD2,20);
	
	//SCRID-119:Add write Current Post Burn CB. 2011-07-26, Tony
	if([mStationName isEqualToString: @"CURRENTPOST"])
		memcpy(cStatinPassword, CURRENTPOST,20);
	
	//SCRID-143:Add write V8 and SimTray CB. 2011-10-31, Tony
	if([mStationName isEqualToString: @"V8PRESS"])
		memcpy(cStatinPassword, V8PRESS,20);
	
	if([mStationName isEqualToString: @"SIMTRAY"])
		memcpy(cStatinPassword, SIMTRAY,20);
	//end
    if([mStationName isEqualToString: @"AUTOBOOT"])
		memcpy(cStatinPassword, AUTOBOOT,20);
    
    if([mStationName isEqualToString: @"DEVICEID"])
		memcpy(cStatinPassword, DEVICEID,20);
    
    if([mStationName isEqualToString: @"CONNECTIVITY3"])
		memcpy(cStatinPassword, CONNECTIVITY3,20);
    
    if([mStationName isEqualToString: @"PHOSPHORUS"])
		memcpy(cStatinPassword, PHOSPHORUS,20);
    
    if([mStationName isEqualToString: @"GRAPE-1"])
		memcpy(cStatinPassword, GRAPE_1,20);
    
    if([mStationName isEqualToString: @"WAT"])
		memcpy(cStatinPassword, WAT,20);
    
    if([mStationName isEqualToString: @"RAT"])
        memcpy(cStatinPassword, RAT,20);
    
    if([mStationName isEqualToString: @"CGOffset"])
        memcpy(cStatinPassword, CGOffSet,20);
    
	printf("printing password");
	unsigned char *charSHA1Return = CreateSHA1(cStatinPassword, cTempNonce);
	
	for(int i = 0; i < 20; i++)
		printf("0x%02x ", charSHA1Return[i]);
	printf("\n");
	
	
	/************************** send fg 0x34 0 ************************/
	NSString *endFlag = @">";
    
    mCBCmd = [mCBCmd stringByAppendingString:@"\n"];
    
	bTmp = [self SendData:dictKeyDefined :mCBCmd :endFlag] ;
	if (bTmp==FALSE)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Send data error"] ;
		return ;
	}
	
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		mTimeOut = @"5";
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
				usleep(50000) ; //delay 50
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		NSLog(@"\n after send fg return :%@",dataResult);
	}
	
	//step 3 send the new password to unit
	bTmp = [self SendDataAsNSData:dictKeyDefined :[NSData dataWithBytes:charSHA1Return length:20] :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		return ;
	}
	
	
	//step 5 : check the responding data .
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
				usleep(50000) ; //delay 50
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		if (dataResult==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Receive data is nil"] ;
			return ;
		}
		
		NSLog(@"\n after received data is :%@",dataResult) ;
		if(mBufferName !=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	return ;
}
//justin add end

@end
