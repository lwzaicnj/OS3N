/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: CheckNandSizeFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :Check SFC and Unit Nand Size function.
 
 $History:: CheckNandSizeFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.31   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "CheckNandSizeFunction.h"


@implementation TestItemParse(CheckNandSizeFunction)

+(void)CheckNandSize:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mReferenceBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	int iNandSizeFromSFC=0;
	int iNandSizeFromUnit=0;

	NSString *HWCofig = @"";
	HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
	if(HWCofig == nil || [HWCofig length] < 4)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWCofig is nil or The format of HWCofig from SFC invalid"] ; 
		return;
	}
	//HWCofig =@"ASU=WIFI&BT/NAND,SIZE=64G/RAM,SIZE=256M";
	HWCofig = [HWCofig stringByReplacingOccurrencesOfString:@" " withString:@""];
	HWCofig = [HWCofig stringByReplacingOccurrencesOfString:@"	" withString:@""];
	NSString *speStr = @"NAND,SIZE=";
	
	NSRange rangeTmp=[HWCofig rangeOfString:speStr];
	if(rangeTmp.length<=0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The format of HWCofig from SFC invalid"] ; 
		return;
	}

	NSString *postSubStr = @"";
	postSubStr = [HWCofig substringFromIndex:rangeTmp.location];
	postSubStr = [postSubStr stringByReplacingOccurrencesOfString:speStr withString:@""];
	NSRange rangeTmpG = [postSubStr rangeOfString:@"G"];
	if(rangeTmpG.length<=0)             
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The format of HWCofig from SFC invalid"] ; 
		return;
	}

	iNandSizeFromSFC = [[postSubStr substringToIndex:rangeTmpG.location] integerValue];

	NSRange range0 = [mReferenceBufferValue rangeOfString:@"0x"];
	NSRange range1 = [mReferenceBufferValue rangeOfString:@"0X"];
	if(range0.length>0 || range1.length>0)
	{
		char* stopEnd = "";
		iNandSizeFromUnit = (int)strtol([mReferenceBufferValue UTF8String], &stopEnd, 16);
		iNandSizeFromUnit  = iNandSizeFromUnit/1000000;
		
		
		if ((iNandSizeFromUnit>(iNandSizeFromSFC-10)) && (iNandSizeFromUnit<(iNandSizeFromSFC+10)))
		//if ((iNandSizeFromUnit>(iNandSizeFromSFC-5)) && (iNandSizeFromUnit<(iNandSizeFromSFC+5)))/*joko extend on 2010-11-27*/
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue] ; 
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Unit's Nand Size is not equal the SFC HWConfig's Nand Size"] ; 
		}		
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diags received Data is not a Hex value"] ; 
	}
	
	return;
	
}
//add by judith 20130129
+(void)CheckNandSizeifReleaseBlock:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName1=nil;
	NSString *mReferenceBufferName2=nil;
    NSString *mBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName1==nil||mReferenceBufferName2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
	NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];
    //mReferenceBufferValue1 = @"0xEE6B28";
    
	if (mReferenceBufferValue1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    //mReferenceBufferValue2 = @"0xF42400";
	if (mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	int iNandSizeFromBlock=0;
	int iNandSizeFromUnit=0;
    
	mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"	" withString:@""];
    mReferenceBufferValue1 = [mReferenceBufferValue1 stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue1 = [mReferenceBufferValue1 stringByReplacingOccurrencesOfString:@"	" withString:@""];
    
	NSRange range1 = [mReferenceBufferValue1 rangeOfString:@"0x"];
	NSRange range2 = [mReferenceBufferValue2 rangeOfString:@"0x"];
	if(range1.length>0 && range2.length>0)
	{
		char* stopEnd = "";
		iNandSizeFromUnit = (int)strtol([mReferenceBufferValue1 UTF8String], &stopEnd, 16);
		iNandSizeFromUnit  = iNandSizeFromUnit/1000000;
		
        iNandSizeFromBlock = (int)strtol([mReferenceBufferValue2 UTF8String], &stopEnd, 16);
		iNandSizeFromBlock  = iNandSizeFromBlock/1000000;
        
        if (mBufferName != nil) 
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%d G",iNandSizeFromBlock]];
        }
		if (iNandSizeFromBlock == 64) 
        {
            if ((iNandSizeFromUnit>=(iNandSizeFromBlock -3)) && (iNandSizeFromUnit<=(iNandSizeFromBlock +1)))
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d G",iNandSizeFromBlock]] ; 
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d G != %d G",iNandSizeFromBlock,iNandSizeFromUnit]] ; 
            }
            
        }
        else{
            
            if ((iNandSizeFromUnit>=(iNandSizeFromBlock-1)) && (iNandSizeFromUnit<=(iNandSizeFromBlock+1)))
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d G",iNandSizeFromBlock]] ;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d G != %d G",iNandSizeFromBlock,iNandSizeFromUnit]] ; 
            }
        }
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diags received Data is not a Hex value"] ; 
	}
	
	return;
	
}
//add end
@end

