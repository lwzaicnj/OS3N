//
//  ProximityFunction.h
//  qt_simulator
//
//  Created by Serin on 3/30/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ProximityDOE)

+(int)DOECalculateStdDev:(NSArray*) AdjProxArray
					 :(NSInteger) AdjProxAvg
					 :(NSInteger) CalCnt;

+(int)DOECalculateStageStdDev:(NSArray*) AdjProxArray1
						  :(NSInteger) AdjProxAvg1
						  :(NSInteger) CalCnt1;

+(void)ParseProxDOE:(NSDictionary*)dictKeyDefined ;

@end
