/*
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa					$Workfile:: ProximityFunction.h		$|
 | $Author:: Serin Yeh					$Revision::  1						$|
 | CREATED: 2010-03-31					$Modtime:: 2.03.00 15:24			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 $History:: ProximityFunction.h                                           $
 * *****************  Version 1  *****************
 * User: Serin Yeh					Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "ProxDOE.h"
#import "Pudding.h"
#import "toolFun.h"

@implementation TestItemParse(ProximityDOE)

int mBaseCntDOE = 100;


NSString *strKeys=@"SN,Base_Prox,Base_Centerpoint,Base_Temp,Base_Adj_Prox,Base_Adj_SD,Base_Adj_Temp,Stage_1 average,Stage_1 SD,Stage_2 average,Stage_2 SD,Stage_3 average,Stage_3 SD,Stage_4 average,Stage_4 SD,Stage_5 average,Stage_5 SD,Stage_6 average,Stage_6 SD,Stage_7 average,Stage_7 SD,Stage_8 average,Stage_8 SD,Stage_9 average,Stage_9 SD,Stage_10 average,Stage_10 SD,Stage_11 average,Stage_11 SD,Stage_12 average,Stage_12 SD,RearCamera_Temp,FrontCamera_Temp,RearEnclosure_Temp,TimeStamp,\r\n";
NSString *DoefileName1=@"";
NSString *DoefileName2=@"";
NSString *DoefileName3=@"";
NSString *DoefileName4=@"";
BOOL isNeedCreateFile1=YES;
BOOL isNeedCreateFile2=YES;
BOOL isNeedCreateFile3=YES;
BOOL isNeedCreateFile4=YES;

+(void)ParseProxDOE:(NSDictionary*)dictKeyDefined
{
	
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; //20100727
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	enum TestResutStatus enumResult ;
	//end
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mReferenceBufferSN=nil;
	NSString *mProjectType = nil;
	
	NSString *mBase_prox_low = nil;
	NSString *mBase_prox_up = nil;
	NSString *mBase_centerpoint_low = nil;
	NSString *mBase_centerpoint_up = nil;
	NSString *mBase_temp_low = nil;
	NSString *mBase_temp_up = nil;
	NSString *mBase_adj_prox_low = nil;
	NSString *mBase_adj_prox_up = nil;
	NSString *mBase_adj_SD_up = nil;
	
	NSString *fileData=@"";
	NSString *strStage=@"";
	NSString *strAttribute=@"";
	//NSString * fileName=@"";
	//BOOL isNeedCreateFile=YES;

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;

		else if ([strKey isEqualToString:@"Base_Prox_Lowlimit"])
			mBase_prox_low = [dictKeyDefined objectForKey:strKey] ;
			
		else if ([strKey isEqualToString:@"Base_Prox_Upperlimit"])
			mBase_prox_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Lowlimit"])
			mBase_centerpoint_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Upperlimit"])
			mBase_centerpoint_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Temp_Lowlimit"])
			mBase_temp_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Temp_Upperlimit"])
			mBase_temp_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Lowlimit"])
			mBase_adj_prox_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Upperlimit"])
			mBase_adj_prox_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Adj_SD_Upperlimit"])
			mBase_adj_SD_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferSN"])
			mReferenceBufferSN=[dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"LoopTimes"])
			mBaseCntDOE=[[dictKeyDefined objectForKey:strKey] intValue];
		
		}
	
	/*
	 :-) prox --stage all --loops 10 --measure
	 0	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16415, 32767, 16291, 62268, 47795, 29115, 32322, 31401, 32038, 48013, 7868 - Prox: 44396, Centerpoint: 32767, Temp: 47795, Adjusted_Prox: 11629
	 1	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32869, 16416, 32771, 16295, 62274, 47794, 29114, 32314, 31397, 32041, 48009, 7876 - Prox: 44394, Centerpoint: 32771, Temp: 47794, Adjusted_Prox: 11623
	 2	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16414, 32771, 16294, 62268, 47797, 29115, 32319, 31400, 32038, 48020, 7870 - Prox: 44401, Centerpoint: 32771, Temp: 47797, Adjusted_Prox: 11630
	 3	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16410, 32758, 16289, 62265, 47797, 29117, 32305, 31398, 32037, 48011, 7875 - Prox: 44403, Centerpoint: 32758, Temp: 47797, Adjusted_Prox: 11645
	 4	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16414, 32768, 16293, 62266, 47792, 29112, 32317, 31400, 32039, 48000, 7870 - Prox: 44391, Centerpoint: 32768, Temp: 47792, Adjusted_Prox: 11623
	 5	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16417, 32768, 16298, 62263, 47795, 29117, 32310, 31400, 32039, 48012, 7867 - Prox: 44391, Centerpoint: 32768, Temp: 47795, Adjusted_Prox: 11623
	 6	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16418, 32768, 16291, 62274, 47796, 29113, 32315, 31405, 32035, 48027, 7876 - Prox: 44403, Centerpoint: 32768, Temp: 47796, Adjusted_Prox: 11635
	 7	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32868, 16410, 32768, 16293, 62269, 47798, 29115, 32322, 31401, 32041, 48007, 7871 - Prox: 44395, Centerpoint: 32768, Temp: 47798, Adjusted_Prox: 11627
	 8	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16412, 32768, 16292, 62274, 47797, 29111, 32315, 31400, 32039, 48011, 7866 - Prox: 44394, Centerpoint: 32768, Temp: 47797, Adjusted_Prox: 11626
	 9	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16419, 32770, 16294, 62252, 47792, 29116, 32320, 31400, 32039, 48010, 7865 - Prox: 44389, Centerpoint: 32770, Temp: 47792, Adjusted_Prox: 11619
	 */
	
	NSMutableArray *BaseProx = nil;
	NSMutableArray *BaseCenterpoint = nil;
	NSMutableArray *BaseTemp = nil;
	NSMutableArray *BaseAdjProx = nil;
	
	// serin 20100720
	NSMutableArray *StageValue = nil;
	NSMutableArray *arrayEachStageValue = [[NSMutableArray alloc] init];
	
	NSString *mReferenceBufferValue ;
	NSString *strUnitSN;
	//mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//joko add 2010-10-04
	NSString *proxFileName = [TestItemManage getBufferValue:dictKeyDefined :@"ProxDoeLogFileName"]; 
	mReferenceBufferValue = [NSString stringWithContentsOfFile:proxFileName encoding:NSASCIIStringEncoding error:nil];
	//joko add 2010-10-04 end
	strUnitSN			  = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferSN] ;
	if (mReferenceBufferValue==nil||strUnitSN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	strUnitSN=[strUnitSN stringByAppendingString:@","];
	
	// serin 0620 add some criteria
	NSRange rangeCenterpoint = [mReferenceBufferValue rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValue rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		return ;
	}
	// end
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	BaseProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"- Prox: "];
	BaseCenterpoint = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Centerpoint: "];
	BaseTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	BaseAdjProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Adjusted_Prox: "];
	
	// serin 20100720
	StageValue = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Sensor Reading: "];
	//end
	
	NSRange BaseProxRange = NSMakeRange(0, 5);
	NSRange BaseCenterpointRange = NSMakeRange(0, 5);
	NSRange BaseTempRange = NSMakeRange(0, 5);
	NSRange BaseAdjProxRange = NSMakeRange(0, 5);
	
	// serin 20100720
	NSRange stageLen = [[StageValue objectAtIndex:1] rangeOfString:@" - Prox: "];
	
	NSInteger BaseProxValue=0;
	NSInteger BaseCenterpointValue=0;
	NSInteger BaseTempValue=0;
	NSInteger BaseAdjProxValue=0;
	
	//joko add 2010-10-04 add end
	/*
	NSMutableArray *BaseStages = nil;
	BaseStages = [mReferenceBufferValue componentsSeparatedByString:@"Stage"];
	if([BaseProx count] < mBaseCntDOE)
		mBaseCntDOE =  [BaseProx count];
	if([BaseCenterpoint count] < mBaseCntDOE)
		mBaseCntDOE =  [BaseCenterpoint count];
	if([BaseTemp count] < mBaseCntDOE)
		mBaseCntDOE =  [BaseTemp count];
	if([BaseAdjProx count] < mBaseCntDOE)
		mBaseCntDOE =  [BaseAdjProx count];
	if([StageValue count] < mBaseCntDOE)
		mBaseCntDOE =  [StageValue count];
	if([BaseStages count] < mBaseCntDOE)
		mBaseCntDOE =  [BaseStages count];
	*/
	//joko add 2010-10-04 add end
		
	// serin 20100720
	NSMutableString *AllStageValue= [[NSMutableString alloc] init];
	
	
	for(int i=1 ; i<=mBaseCntDOE; i++ )
	{
		[BaseProx replaceObjectAtIndex:i 
							withObject:[[BaseProx objectAtIndex:i] substringWithRange:BaseProxRange]];
		
		[BaseCenterpoint replaceObjectAtIndex:i 
							withObject:[[BaseCenterpoint objectAtIndex:i] substringWithRange:BaseCenterpointRange]];
		
		[BaseTemp replaceObjectAtIndex:i 
							withObject:[[BaseTemp objectAtIndex:i] substringWithRange:BaseTempRange]];
		
		[BaseAdjProx replaceObjectAtIndex:i 
							withObject:[[BaseAdjProx objectAtIndex:i] substringWithRange:BaseAdjProxRange]];
		
		// serin 20100720
		NSRange StageValueRange = NSMakeRange(0,stageLen.location);
		[StageValue replaceObjectAtIndex:i 
							withObject:[[StageValue objectAtIndex:i] substringWithRange:StageValueRange]];
		
		BaseProxValue			= BaseProxValue + [[BaseProx objectAtIndex:i]integerValue];
		BaseCenterpointValue	= BaseCenterpointValue + [[BaseCenterpoint objectAtIndex:i]integerValue];
		BaseTempValue			= BaseTempValue + [[BaseTemp objectAtIndex:i]integerValue];
		BaseAdjProxValue		= BaseAdjProxValue + [[BaseAdjProx objectAtIndex:i]integerValue];
		
		// serin 20100720
		[AllStageValue appendString:[StageValue objectAtIndex:i]];
		[AllStageValue appendString:@","];
	}
	
	// ~~~~~~caijunbo 20100721~~~~~~~~~
	NSArray *arrayAllStageValue=nil;
	arrayAllStageValue =[AllStageValue componentsSeparatedByString:@","];
	
	int iAverageValue = 0;
	int StageSD = 0;
	for (int i=0;i<12;i++)
	{
		iAverageValue = 0;
		[arrayEachStageValue removeAllObjects];
		for(int j=0;j<mBaseCntDOE;j++)
		{
			iAverageValue+=[[arrayAllStageValue objectAtIndex:(i+j*12)] intValue];
			[arrayEachStageValue addObject:[arrayAllStageValue objectAtIndex:(i+j*12)]];
		}
		
		iAverageValue= iAverageValue/mBaseCntDOE;
		StageSD = [self DOECalculateStageStdDev: arrayEachStageValue: iAverageValue:mBaseCntDOE];
		
		/*
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d average",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",iAverageValue]:nil:IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d SD",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",StageSD]:nil:IP_NA:nil];
		 */
		strStage=[strStage stringByAppendingString:[NSString stringWithFormat:@"%d,",iAverageValue]];
		strStage=[strStage stringByAppendingString:[NSString stringWithFormat:@"%d,",StageSD]];
		
	}
	[AllStageValue release];
	[arrayEachStageValue release];
	
	NSInteger BaseProxAvg			= BaseProxValue / mBaseCntDOE;
	NSInteger BaseCenterpointAvg	= BaseCenterpointValue / mBaseCntDOE;
	NSInteger BaseTempAvg			= BaseTempValue / mBaseCntDOE;
	NSInteger BaseAdjProxAvg		= BaseAdjProxValue / mBaseCntDOE;
	NSInteger BaseAdjSD				= [self DOECalculateStdDev: BaseAdjProx: BaseAdjProxAvg:mBaseCntDOE];

	// serin 20100720 delete
	//NSInteger BaseTrueTemp = 0;
	
	strTestResultForUIinfo = @"";
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
//	NSInteger BaseResCnt = 0;
		//end
	// serin 20100720 delete
	/*
	BaseTrueTemp = BaseTempAvg;
	
	if( (BaseTempAvg < [mBase_temp_low integerValue]) || (BaseTempAvg > [mBase_temp_up integerValue]) )
	{
		BaseResCnt++;
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Temp Value ;";
	}
	else if(BaseTempAvg > [mBase_temp_clip_up integerValue] && BaseTempAvg < [mBase_temp_up integerValue])
	{
		//BaseTrueTemp = BaseTempAvg;
		BaseTempAvg = [mBase_temp_clip_up integerValue] - 10;
	}
	else if(BaseTempAvg < [mBase_temp_clip_low integerValue] && BaseTempAvg > [mBase_temp_low integerValue])
	{
		//BaseTrueTemp = BaseTempAvg;
		BaseTempAvg = [mBase_temp_clip_low integerValue] + 10;
	}
	else if((BaseTempAvg >= [mBase_temp_clip_low integerValue]) && (BaseTempAvg <= [mBase_temp_clip_up integerValue]))
	{
		BaseTrueTemp = BaseTempAvg;
	}
	// end
	*/
	// end
	
	NSInteger BaseAdjTemp = BaseTempAvg - BaseCenterpointAvg;
	
	
	
	///remarked by caijunbo on 2010-10-02
	/*
	
	if( BaseProxAvg < [mBase_prox_low integerValue] || BaseProxAvg > [mBase_prox_up integerValue])
	{
		BaseResCnt++;
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Prox Value ;"];
	}
	if( BaseCenterpointAvg < [mBase_centerpoint_low integerValue] || BaseCenterpointAvg > [mBase_centerpoint_up integerValue]) 
	{
		BaseResCnt++;
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Centerpoint Value ;"];
	}
	
	if( BaseTempAvg < [mBase_temp_low integerValue] || BaseTempAvg > [mBase_temp_up integerValue]) 
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Temp Value ;"];
	}
	
	if( BaseAdjProxAvg < [mBase_adj_prox_low integerValue] || BaseAdjProxAvg > [mBase_adj_prox_up integerValue]) 
	{
		BaseResCnt++;
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Adj Prox Value ;"];
	}
	if( BaseAdjSD > [mBase_adj_SD_up integerValue]) 
	{
		BaseResCnt++;
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"SD Value ;"];
	}
	 
	*/
	
	
	
	// remarked by caijunbo on 2010-10-02
	/*
	if(BaseResCnt == 0) 
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
		
		// set prox param that write back into sysconfig
		[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%d",BaseProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%d",BaseCenterpointAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%d",BaseTempAvg]];
		
		// serin 20100721 delete
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxTrueTemp Value":[NSString stringWithFormat:@"%d",BaseTrueTemp]];
		
		// for ParseProx
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%d",BaseAdjTemp]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%d",BaseAdjProxAvg]];
	}
	 */
	
	// set pudding data
	/*
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Prox":nil:mBase_prox_low:mBase_prox_up:[NSString stringWithFormat:@"%d",BaseProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Centerpoint":nil:mBase_centerpoint_low:mBase_centerpoint_up:[NSString stringWithFormat:@"%d",BaseCenterpointAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Temp":nil:mBase_temp_low:mBase_temp_up:[NSString stringWithFormat:@"%d",BaseTempAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Prox":nil:mBase_adj_prox_low:mBase_adj_prox_up:[NSString stringWithFormat:@"%d",BaseAdjProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_SD":nil:nil:mBase_adj_SD_up:[NSString stringWithFormat:@"%d",BaseAdjSD]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",BaseAdjTemp]:nil:IP_NA:nil];
	*/
	// serin 20100721 delete
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_True_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",BaseTrueTemp]:nil:IP_NA:nil];
	
	
	//joko add 2010-10-07 add
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable

	NSMutableArray *rearCameraTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"RearCamera --get temperature"];
	NSMutableArray *frontCameraTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"FrontCamera --get temperature"];
	NSMutableArray *rearEnclosureTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"RearEnclosure --get temperature"];
	//end
	NSString *CameraTempFileData = @"";
	
	for(int i=1; i<[rearCameraTemp count]; i++)
	{
		NSString *tmp = [rearCameraTemp objectAtIndex:i];
		if([tmp rangeOfString:@"degC"].length > 0)
		{
			tmp = [tmp substringToIndex:[tmp rangeOfString:@"degC"].location];
			CameraTempFileData = [CameraTempFileData stringByAppendingString:tmp];
			CameraTempFileData = [CameraTempFileData stringByAppendingString:@","];
		}
		else
		{
			CameraTempFileData = [CameraTempFileData stringByAppendingString:@"Data Format Invalid,"];
		}
		if([frontCameraTemp count] >= i)
		{
			tmp = [frontCameraTemp objectAtIndex:i];
			if([tmp rangeOfString:@"degC"].length > 0)
			{
				tmp = [tmp substringToIndex:[tmp rangeOfString:@"degC"].location];
				CameraTempFileData = [CameraTempFileData stringByAppendingString:tmp];
				CameraTempFileData = [CameraTempFileData stringByAppendingString:@","];
			}
			else
			{
				CameraTempFileData = [CameraTempFileData stringByAppendingString:@"Data Format Invalid,"];
			}
		}
		if([rearEnclosureTemp count] >= i)
		{
			tmp = [rearEnclosureTemp objectAtIndex:i];
			if([tmp rangeOfString:@"degC"].length > 0)
			{
				tmp = [tmp substringToIndex:[tmp rangeOfString:@"degC"].location];
				CameraTempFileData = [CameraTempFileData stringByAppendingString:tmp];
				CameraTempFileData = [CameraTempFileData stringByAppendingString:@","];
			}
			else
			{
				CameraTempFileData = [CameraTempFileData stringByAppendingString:@"Data Format Invalid,"];
			}
		}
	}
	/*
	for(int i=0; i<[frontCameraTemp count]; i++)
	{
		NSString *tmp = [frontCameraTemp objectAtIndex:i];
		if([tmp rangeOfString:@"degC"].length > 0)
		{
			tmp = [tmp substringToIndex:[tmp rangeOfString:@"degC"].location];
			frontCameraTempFileData = [frontCameraTempFileData stringByAppendingString:tmp];
			frontCameraTempFileData = [frontCameraTempFileData stringByAppendingString:@",\n"];
		}
		else
		{
			frontCameraTempFileData = [frontCameraTempFileData stringByAppendingString:@"Data Format Invalid,\n"];
		}
	}
	for(int i=0; i<[rearEnclosureTemp count]; i++)
	{
		NSString *tmp = [rearEnclosureTemp objectAtIndex:i];
		if([tmp rangeOfString:@"degC"].length > 0)
		{
			tmp = [tmp substringToIndex:[tmp rangeOfString:@"degC"].location];
			rearEnclosureTempFileData = [rearEnclosureTempFileData stringByAppendingString:tmp];
			rearEnclosureTempFileData = [rearEnclosureTempFileData stringByAppendingString:@",\n"];
		}
		else
		{
			rearEnclosureTempFileData = [rearEnclosureTempFileData stringByAppendingString:@"Data Format Invalid,\n"];
		}
	}
	*/
	//joko add 2010-10-07 add end
	
	
	
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseProxAvg]];
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseCenterpointAvg]];
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseTempAvg]];
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseAdjProxAvg]];
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseAdjSD]];
	strAttribute=[strAttribute stringByAppendingString:[NSString stringWithFormat:@"%d,",BaseAdjTemp]];
	
	//write test value to log file added by caijunbo on 2010-10-02

	NSString*currentDate		= [NSDate date];
	NSString*strCurrentTime	= [currentDate description];
	
	strCurrentTime	= [strCurrentTime substringToIndex:(NSUInteger)19];
	
	/*Owner:Henry DATE :10.22.2010
	 SCRID :009
	 Desc  :Modify ProxDOE to change name character from "/" to "_".
	 */
	strCurrentTime = [strCurrentTime stringByReplacingOccurrencesOfString:@":" withString:@"-"];
	strCurrentTime = [strCurrentTime stringByReplacingOccurrencesOfString:@" " withString:@"_"];
	//end Henry 10.22.2010
	
	/*Owner:Henry DATE :11.23.2010
	 SCRID :020
	 Desc  :Modify ProxDOE csv file name and time stamp.
	 */
	NSString *strTempTime =[strCurrentTime  substringFromIndex:11];
	NSString *strTempYear =[strCurrentTime substringToIndex:4];
	//NSString *strTempMonth =[strCurrentTime  substringWithRange:NSMakeRange(5, 2)];
	NSString *strTempDay =[strCurrentTime  substringWithRange:NSMakeRange(8, 2)];
	strCurrentTime = [strCurrentTime  substringWithRange:NSMakeRange(5, 2)];
	strCurrentTime = [strCurrentTime stringByAppendingString:@"-"];
	strCurrentTime = [strCurrentTime stringByAppendingString:strTempDay];
	strCurrentTime = [strCurrentTime stringByAppendingString:@"-"];
	strCurrentTime = [strCurrentTime stringByAppendingString:strTempYear];
	strCurrentTime = [strCurrentTime stringByAppendingString:@"_"];
	strCurrentTime = [strCurrentTime stringByAppendingString:strTempTime];
	//end Henry 10.23.2010
	
	NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];
	
	NSString *time = [ToolFun getCurrentDateTime];
	NSString *tmpT = [time substringToIndex:8];
	tmpT = [tmpT stringByAppendingString:@"-"];
	NSString *pp=[time substringFromIndex:8];
	tmpT = [tmpT stringByAppendingString:pp];
	tmpT = [tmpT stringByAppendingString:@","];
	/*Owner:Henry DATE :11.22.2010
	 SCRID :020
	 Desc  :Modify ProxDOE csv file name and time stamp.
	 */
//	NSString *strYear=[tmpT substringToIndex:4];
	NSString *strMonth=[tmpT substringWithRange:NSMakeRange(4, 2)];
	NSString *strDay=[tmpT substringWithRange:NSMakeRange(6, 2)];
	NSString *strHour=[tmpT substringWithRange:NSMakeRange(9, 2)];
	NSString *strMiniut=[tmpT substringWithRange:NSMakeRange(11, 2)];
	NSString *strSecond=[tmpT substringWithRange:NSMakeRange(13, 2)];

	tmpT=[tmpT substringToIndex:4];
	tmpT = [tmpT stringByAppendingString:@"-"];
	tmpT = [tmpT stringByAppendingString:[NSString stringWithFormat:@"%@-",strMonth]];
	tmpT = [tmpT stringByAppendingString:[NSString stringWithFormat:@"%@_",strDay]];
	tmpT = [tmpT stringByAppendingString:[NSString stringWithFormat:@"%@_",strHour]];
	tmpT = [tmpT stringByAppendingString:[NSString stringWithFormat:@"%@_",strMiniut]];
	tmpT = [tmpT stringByAppendingString:[NSString stringWithFormat:@"%@",strSecond]];
	

	//end Henry 11.22.2010
	
	if ([strDUTID isEqualToString:@"1"])
	{
		if (isNeedCreateFile1)
		{
			isNeedCreateFile1=NO;
			/*Owner:Henry DATE :11.22.2010
			 SCRID :020
			 Desc  :Modify ProxDOE csv file name and time stamp.
			 */
//			DoefileName1=[DoefileName1 stringByAppendingString:@"/vault/DOETest1_"];
			DoefileName1=[DoefileName1 stringByAppendingString:@"/vault/MacDOE-Prox-UUT1_"];
			//end
			DoefileName1=[DoefileName1 stringByAppendingString:strCurrentTime];
			DoefileName1=[DoefileName1 stringByAppendingString:@".csv"];
			[DoefileName1 retain];
			
			FILE* fp=NULL;
			fp=fopen([DoefileName1 UTF8String],"wr");
			fclose(fp);
			
			
			NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:DoefileName1];
			if (filehandTmp!=nil)
			{
				[filehandTmp seekToEndOfFile] ;
				[filehandTmp writeData:[NSData dataWithData:[strKeys dataUsingEncoding:NSASCIIStringEncoding]]] ;
				[filehandTmp closeFile] ;
			}
		}
		
		fileData=[fileData stringByAppendingString:strUnitSN];
		fileData=[fileData stringByAppendingString:strAttribute];
		fileData=[fileData stringByAppendingString:strStage];
		fileData=[fileData stringByAppendingString:CameraTempFileData];
		fileData=[fileData stringByAppendingString:tmpT];
		
		NSLog(strStage);
		
		/*Owner:Henry DATE :11.22.2010
		 SCRID :020
		 Desc  :Modify ProxDOE csv file name and time stamp.
		 */
		//int len=[fileData length];
		//fileData=[fileData substringToIndex:len-1];
		//end
		
		fileData=[fileData stringByAppendingString:@"\n"];
		
		NSFileHandle *filehand = [NSFileHandle fileHandleForWritingAtPath:DoefileName1];
		if (filehand!=nil)
		{
			[filehand seekToEndOfFile] ;
			[filehand writeData:[NSData dataWithData:[fileData dataUsingEncoding:NSASCIIStringEncoding]]] ;
			[filehand closeFile] ;
		}
		
	
	}
	else if ([strDUTID isEqualToString:@"2"])
	{
		if (isNeedCreateFile2)
		{
			isNeedCreateFile2=NO;
			/*Owner:Henry DATE :11.22.2010
			 SCRID :020
			 Desc  :Modify ProxDOE csv file name and time stamp.
			 */
//			DoefileName2=[DoefileName2 stringByAppendingString:@"/vault/DOETest2_"];
			DoefileName2=[DoefileName2 stringByAppendingString:@"/vault/MacDOE-Prox-UUT2_"];
			//end
			DoefileName2=[DoefileName2 stringByAppendingString:strCurrentTime];
			DoefileName2=[DoefileName2 stringByAppendingString:@".csv"];
			[DoefileName2 retain];
			FILE* fp=NULL;
			fp=fopen([DoefileName2 UTF8String],"wr");
			fclose(fp);
			
			
			NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:DoefileName2];
			if (filehandTmp!=nil)
			{
				[filehandTmp seekToEndOfFile] ;
				[filehandTmp writeData:[NSData dataWithData:[strKeys dataUsingEncoding:NSASCIIStringEncoding]]] ;
				[filehandTmp closeFile] ;
			}
		}
		
		fileData=[fileData stringByAppendingString:strUnitSN];
		fileData=[fileData stringByAppendingString:strAttribute];
		fileData=[fileData stringByAppendingString:strStage];
		fileData=[fileData stringByAppendingString:CameraTempFileData];
		fileData=[fileData stringByAppendingString:tmpT];
		
		NSLog(strStage);
		
		/*Owner:Henry DATE :11.22.2010
		 SCRID :020
		 Desc  :Modify ProxDOE csv file name and time stamp.
		 */
		//int len=[fileData length];
		//fileData=[fileData substringToIndex:len-1];
		//end

		fileData=[fileData stringByAppendingString:@"\n"];
		
		NSFileHandle *filehand = [NSFileHandle fileHandleForWritingAtPath:DoefileName2];
		if (filehand!=nil)
		{
			[filehand seekToEndOfFile] ;
			[filehand writeData:[NSData dataWithData:[fileData dataUsingEncoding:NSASCIIStringEncoding]]] ;
			[filehand closeFile] ;
		}
		
	
	}
	else if ([strDUTID isEqualToString:@"3"])
	{
		if (isNeedCreateFile3)
		{
			isNeedCreateFile3=NO;
			/*Owner:Henry DATE :11.22.2010
			 SCRID :020
			 Desc  :Modify ProxDOE for file name.
			 */
//			DoefileName3=[DoefileName3 stringByAppendingString:@"/vault/DOETest3_"];
			DoefileName3=[DoefileName3 stringByAppendingString:@"/vault/MacDOE-Prox-UUT3_"];
			//end
			DoefileName3=[DoefileName3 stringByAppendingString:strCurrentTime];
			DoefileName3=[DoefileName3 stringByAppendingString:@".csv"];
			[DoefileName3 retain];
			FILE* fp=NULL;
			fp=fopen([DoefileName3 UTF8String],"wr");
			fclose(fp);
			
			
			NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:DoefileName3];
			if (filehandTmp!=nil)
			{
				[filehandTmp seekToEndOfFile] ;
				[filehandTmp writeData:[NSData dataWithData:[strKeys dataUsingEncoding:NSASCIIStringEncoding]]] ;
				[filehandTmp closeFile] ;
			}
		}
		
		fileData=[fileData stringByAppendingString:strUnitSN];
		fileData=[fileData stringByAppendingString:strAttribute];
		fileData=[fileData stringByAppendingString:strStage];
		fileData=[fileData stringByAppendingString:CameraTempFileData];
		fileData=[fileData stringByAppendingString:tmpT];
		
		NSLog(strStage);
		
		/*Owner:Henry DATE :11.22.2010
		 SCRID :020
		 Desc  :Modify ProxDOE csv file name and time stamp.
		 */
		//int len=[fileData length];
		//fileData=[fileData substringToIndex:len-1];
		//end

		fileData=[fileData stringByAppendingString:@"\n"];
		
		NSFileHandle *filehand = [NSFileHandle fileHandleForWritingAtPath:DoefileName3];
		if (filehand!=nil)
		{
			[filehand seekToEndOfFile] ;
			[filehand writeData:[NSData dataWithData:[fileData dataUsingEncoding:NSASCIIStringEncoding]]] ;
			[filehand closeFile] ;
		}
		
	
	}
	else if ([strDUTID isEqualToString:@"4"])
	{
		if (isNeedCreateFile4)
		{
			isNeedCreateFile4=NO;
			/*Owner:Henry DATE :11.22.2010
			 SCRID :020
			 Desc  :Modify ProxDOE for file name.
			 */
//			DoefileName4=[DoefileName4 stringByAppendingString:@"/vault/DOETest4_"];
			DoefileName4=[DoefileName4 stringByAppendingString:@"/vault/MacDOE-Prox-UUT4_"];
			//end
			DoefileName4=[DoefileName4 stringByAppendingString:strCurrentTime];
			DoefileName4=[DoefileName4 stringByAppendingString:@".csv"];
			[DoefileName4 retain];
			FILE* fp=NULL;
			fp=fopen([DoefileName4 UTF8String],"wr");
			fclose(fp);
			
			
			NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:DoefileName4];
			if (filehandTmp!=nil)
			{
				[filehandTmp seekToEndOfFile] ;
				[filehandTmp writeData:[NSData dataWithData:[strKeys dataUsingEncoding:NSASCIIStringEncoding]]] ;
				[filehandTmp closeFile] ;
			}
		}
		
		fileData=[fileData stringByAppendingString:strUnitSN];
		fileData=[fileData stringByAppendingString:strAttribute];
		fileData=[fileData stringByAppendingString:strStage];
		fileData=[fileData stringByAppendingString:CameraTempFileData];
		fileData=[fileData stringByAppendingString:tmpT];
		
		NSLog(strStage);
		
		/*Owner:Henry DATE :11.22.2010
		 SCRID :020
		 Desc  :Modify ProxDOE csv file name and time stamp.
		 */
		//int len=[fileData length];
		//fileData=[fileData substringToIndex:len-1];
		//end
		fileData=[fileData stringByAppendingString:@"\n"];
		
		NSFileHandle *filehand = [NSFileHandle fileHandleForWritingAtPath:DoefileName4];
		if (filehand!=nil)
		{
			[filehand seekToEndOfFile] ;
			[filehand writeData:[NSData dataWithData:[fileData dataUsingEncoding:NSASCIIStringEncoding]]] ;
			[filehand closeFile] ;
		}
		
	
	}
	
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No such thread!"] ; ///write test result and uiinfo.
		return ;
	}
	
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Complete Testing!"] ;
	
	return ;
	
}


+(int)DOECalculateStdDev:(NSArray*) AdjProxArray
					  :(NSInteger) AdjProxAvg
					  :(NSInteger) CalCnt
{
	double sqrtSum=0;
	for(int j=1; j<=CalCnt; j++)
	{
		int tmpVal = [[AdjProxArray objectAtIndex:j] integerValue] - AdjProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/CalCnt);
	return (pow(tmpAvg,0.5));
}

// serin 20100721
+(int)DOECalculateStageStdDev:(NSArray*) AdjProxArray1
					 :(NSInteger) AdjProxAvg1
					 :(NSInteger) CalCnt1
{
	double sqrtSum=0;
	for(int j=0; j<CalCnt1; j++)
	{
		int tmpVal = [[AdjProxArray1 objectAtIndex:j] integerValue] - AdjProxAvg1;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/CalCnt1);
	return (pow(tmpAvg,0.5));
}
// end

@end



