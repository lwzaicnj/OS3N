//
//  SerialCommFunction.h
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"

@interface TestItemParse(SerialCommFunction)
+(void)RS232WriteAndReadStr:(NSDictionary*)dictKeyDefined ;
+(void)SensorCheck:(NSDictionary*)dictKeyDefined;
+(void)RS232WriteAndReadStrForSLOrion:(NSDictionary*)dictKeyDefined;
//RL PVT write WMac,BMac,EMac bypass when Wmac value did not contain "0x00000000 0x00000000 0x00000000 0x00000000", modified by Annie 2014.12.15
+(void)RS232WriteMacAddress:(NSDictionary*)dictKeyDefined ;
+(void)RS232WriteAndReadStrForMBT:(NSDictionary*)dictKeyDefined;//Annie add 2012-11-23

+(void)RS232WriteAndReadStrMikeyBoard:(NSDictionary*)dictKeyDefined ; //2011-05-26 joko
/*SCRID-106: fix the condition that the value returned from fixture didn't contain ok. Annie 2014-02-13*/
+(void)RS232WriteAndReadStrMikeyBoardNoOk:(NSDictionary*)dictKeyDefined ; //2014-02-12 Annie

+(void)RS232WriteAndReadStrIniOSMode:(NSDictionary*)dictKeyDefined;
+(void)RS232WriteAndReadStrIniOSMode2Times:(NSDictionary*)dictKeyDefined;
//SCRID:126 add Parser RS232WriteAndReadStrAccelAndCompass by Jack 2011-08-03.
+(void)RS232WriteAndReadStrAccelAndCompass:(NSDictionary*)dictKeyDefined;
//SCRID:126 end
+(void)Delay:(NSDictionary*)dictKeyDefined ;

+(void)SendAndReceiveDataToOrFromEthernetBySocket:(NSDictionary*)dictKeyDefined;//joko add 2012-7-27
+(void)DisconnectEthernetBySocket:(NSDictionary*)dictKeyDefined;//joko add 2012-7-27
+(void)ConnectEthernetBySocket:(NSDictionary*)dictKeyDefined;//joko add 2012-7-27

//SCRID:137 add parser ParserV8Timing by Tony 2011-09-28.
+(void)ParserV8Timing:(NSDictionary*)dictKeyDefined;
//SCRID:137 end

+(void)MessageBox:(NSDictionary*)dictKeyDefined ;

+(void)ParseStrWithControlBit:(NSDictionary*)dictKeyDefined;
+(void)ParseMultiSpecStrPostfixWithConditions:(NSDictionary*)dictKeyDefined;

+(void)ParseControlUSBBySendCommandToComputer:(NSDictionary*)dictKeyDefined ;
+(void)RS232WriteAndReadStrEnterDiags:(NSDictionary*)dictKeyDefined;//add by judith 2012-04-23
+(void) RS485ReadSnMotor: (NSDictionary *)dictKeyDefined;//add by judith 2012-05-17
+(NSString *) dataToString: (NSData *) _data;
+ (void)ParseSendCommandToComputer:(NSDictionary*)dictKeyDefined;
+(void)RS232WriteAndReadStrForHES:(NSDictionary*)dictKeyDefined;//add by judith 2012-09-10
+(void)EEPROM:(NSDictionary*)dictKeyDefined;
+(void)EEPROMV2:(NSDictionary*)dictKeyDefined;
+(void)ParseCheckUnitProcess: (NSDictionary *)dictKeyDefined;
+(void)RS232WriteAndReadStrAICI:(NSDictionary*)dictKeyDefined;

+(void)RS232WriteAndReadTwoStrAndCondition:(NSDictionary*)dictKeyDefined;//add by kevin for SL CT1 accel sensor judge different sensor different diag command 20150316

+(void)ParseUsb3Test:(NSDictionary*) DictionaryPtr;//add from RX SMT by kevin on 20150318 for A-1 Sation Testitem "usb3 Test"
+ (NSString *)stringFromHexString:(NSString *)hexString;
+(void)RS232WriteAndReadStrForCL200A:(NSDictionary*)dictKeyDefined;
@end