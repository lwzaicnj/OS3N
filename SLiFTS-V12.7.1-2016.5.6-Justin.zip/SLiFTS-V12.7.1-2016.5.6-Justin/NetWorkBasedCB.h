//
//  CurrentAutoTest.h
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(NetWorkBasedCBFunction)

+(void)CBCheckAndInit:(NSDictionary*)dictKeyDefined;
+(void)HandleFataErrorAndCBToClear:(NSDictionary*)dictKeyDefined;

+(BOOL)SetSelectedStationCBFail:(NSDictionary*)dictKeyDefined:(NSString*)selectedStationCB;


@end
