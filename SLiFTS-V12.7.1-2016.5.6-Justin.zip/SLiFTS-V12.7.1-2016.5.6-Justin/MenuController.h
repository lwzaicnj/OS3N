//
//  MenuController.h
//  iLIB
//
//  Created by MAC008 on 10-7-12.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemManage.h"
#import "UIWinManage.h"

@interface MenuController : NSObject {
	IBOutlet NSWindow *mainWin;
	IBOutlet NSButton *btnStart;
	IBOutlet NSButton *btnPause;
	IBOutlet NSButton *btnTabViewMaxMin;
	IBOutlet NSTabView *tabView;
	IBOutlet NSTextField* textLabelRemark;

}
-(IBAction) CloseWindow:(id)sender;
-(IBAction) StartTest:(id)sender;
-(IBAction) PauseTest:(id)sender;
-(IBAction) MinimizeWindow:(id)sender;
-(IBAction) MaxmizeWindow:(id)sender;
-(IBAction) ShowResult:(id)sender;
-(IBAction) ShowAllLog:(id)sender;
-(IBAction) ShowItemLog:(id)sender;
-(IBAction) MaxMinTabView:(id)sender;
-(NSString *) getRemark;
@end
