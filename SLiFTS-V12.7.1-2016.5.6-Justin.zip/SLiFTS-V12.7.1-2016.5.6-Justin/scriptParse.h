//
//  scriptParse.h
//  qt_simulator
//
//  Created by diags on 2/22/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "toolFun.h"
#import "SocketManage.h"

#define    Client_StationID              @"StationID"
#define    Client_IP                     @"IP"
#define    Client_PortID                 @"PortID"
#define    Client_TimeOut                @"TimeOut"
#define    Client_ScriptVersion          @"ScriptVersion"
#define    Client_Version                @"VersionID"
#define    Client_TimeOut				 @"TimeOut"

@interface ScriptParse : NSObject {

}
//public function
+(bool)parseAppConfig:(NSString*)strPath ;
+(bool)parseTestScript:(NSString*)strPath ;
+(bool)parseHWConfig:(NSString*)strPath ;
+(NSString*)getValueFromSummary:(NSString*)strKey;
+(NSString*)getValueFromHWConfig:(NSString*)strKey ;
+(NSArray*)getTestItems ;

+(NSString*)getUILabel1;
+(NSString*)getUILabel2;
+(NSArray*)getDeviceIDList ;
+(NSDictionary*)getDeviceInfo ;

+(NSString*)getSWVerision ;
+(NSString*)getStationID ;
//inner function
+(bool)parseSummary:(NSString*)strSummary ;
+(bool)parseLogService:(NSString*)strLogService ;
+(bool)parseDeviceService:(NSString*)strDeviceService ;
+(NSDictionary*)genDisctionaryFromStr:(NSString*)strParameter;
+(NSString*)DeletePostfixInvisableChar:(NSString*)strSource; //specifal handle
+(NSString*)getVisableStr:(NSString*)strSource ;
+(bool)parseDeviceParameter ; //get the device 's parameter

+(bool)convertScriptToPlist:(NSString*)strPath ;
+(bool)parsePlistTestScript:(NSString*)strPath ;
+(NSString*)getSubstrFromPlist:(NSString*)strSource Prefix:(NSString*)strPrefix Postfix:(NSString*)strPostfix isContain:(bool)bContain;
+(NSMutableDictionary*)genDisctionaryFromStrPlist:(NSString*)strParameter;


+(NSString*)setHidCharOfScript:(NSString*)strSource ; //set hid char \r \n
+(NSArray*)getTestScript;

+(bool)AppInitFromCloud:(NSString*)strPath ; //add by giga
+(NSString*)getCL200ADeviceFile; //add by Justin Shang @20151019
@end
