//
//  PreSWDLFunction.h
//  iFTS
//
//  Created by MAC008 on 10-12-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
//SCRID:46
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"
#import "WritePDCA.h"


@interface TestItemParse(PreSWDLFunction)
+(void)ParseSWDL:(NSDictionary*) DictionaryPtr;
@end

//end
