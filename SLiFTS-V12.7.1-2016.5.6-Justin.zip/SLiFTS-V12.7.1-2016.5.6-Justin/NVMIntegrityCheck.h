//
//  NVMIntegrityCheck.h
//  iFTS
//
//  Created by Ray Hsu on 2012/2/8.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(NVMIntegrityCheckFun)

//For Polar Light
+(void)FrontCameraNVMIntegrityCheck:(NSDictionary*)dictKeyDefined;
+(void)BackCameraNVMIntegrityCheck:(NSDictionary*)dictKeyDefined;
//For Polar Light

//For Pole Star 2012-05-11
+(void)FrontCameraNVMIntegrityCheckForPS:(NSDictionary*)dictKeyDefined;
+(void)BackCameraNVMIntegrityCheckForPS:(NSDictionary*)dictKeyDefined;
//End 2012-05-11

//Camera NVM Check for QL 2012-11-25
+(void)FrontCameraNVMIntegrityCheckForQL:(NSDictionary*)dictKeyDefined;
+(void)BackCameraNVMIntegrityCheckForQL:(NSDictionary*)dictKeyDefined;
//End

+(void)ParseNVItem:(NSDictionary*)dictKeyDefined; //add by fred 2012-04-27
@end
