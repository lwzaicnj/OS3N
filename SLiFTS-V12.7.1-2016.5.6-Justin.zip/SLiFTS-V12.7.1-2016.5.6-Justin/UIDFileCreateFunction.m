/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: UIDFileCreateFunction.m 
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010..04.08                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Create UID File
 
 PURPOSE :Create UID File function.
 
 $History:: UIDFileCreateFunction.m                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.04.08   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "UIDFileCreateFunction.h"

@implementation TestItemParse(UIDFileCreateFunction)

/*SCRID-109: Change UID File Parser. joko 2011-06-01*/
+(void)k48UIDFileCreate:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mPath=nil;
	NSString *mBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Path"])
		{
			mPath = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mPath==nil|| [mPath length]<=0)
	{
		mPath = @"/vault/pudding/uid/";
	}
	NSString * folderPath =@"mkdir -p ";
	folderPath = [folderPath stringByAppendingString:mPath];
	system([folderPath UTF8String]); //create folder "/vault/pudding/uid/"
	
	NSString *sysSn = [TestItemManage getUnitValue:dictKeyDefined :@"strSysSn"];
	//sysSn =@"1239TK1";
	if([sysSn length] < 4)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SysSN Invalid"] ;
		return ;
	}

	NSString *mBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mBufferName] ;
	//mBufferValue = @"MLBSN678";
	
	if(mBufferValue==nil || [mBufferValue length]<=0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Buffer Value is Null"] ;
		return ;
	}
	
	NSCalendarDate *now;
	now = [NSCalendarDate calendarDate];
	NSString *dateTime = [now description];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@"-" withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@":" withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@" " withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@"	" withString:@""];
	if([dateTime length] < 14)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Get Date and Time Fail"] ;
		return ;
	}
	else
	{
		dateTime = [dateTime substringToIndex:14];
	}
	
	NSString *fileName =@"";
	NSString *fileContent =@"";
	//char hj='q';
	fileName =@"";
	fileName = [fileName stringByAppendingString:mPath];
	fileName = [fileName stringByAppendingString:mBufferValue];
	fileName = [fileName stringByAppendingString:@"_"];
	fileName = [fileName stringByAppendingString:dateTime];
	fileName = [fileName stringByAppendingString:@".uid"];
	fileContent =@"";
	fileContent = [fileContent stringByAppendingString:mBufferValue];
	fileContent = [fileContent stringByAppendingString:@"\n"];
	fileContent = [fileContent stringByAppendingString:@"FG_SN:"];
	fileContent = [fileContent stringByAppendingString:sysSn];
	fileContent = [fileContent stringByAppendingString:@"\n"];
	fileContent = [fileContent stringByAppendingString:@"END_OF_FILE"];
	FILE *fp1;
	fp1 = fopen([fileName UTF8String], "wr");
	if(fp1!=NULL)
	{
		int ll = [fileContent length];
		fwrite([fileContent UTF8String], ll*sizeof(char), 1, fp1);
	}
	fclose(fp1);
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	return ;
}
/*SCRID-109: end*/

@end
