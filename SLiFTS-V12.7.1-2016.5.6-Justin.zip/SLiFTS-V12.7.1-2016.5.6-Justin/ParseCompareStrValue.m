/*
 SCRID:12
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseCompareStrValue.m 
 | $Author::Caijunbo                    $Revision:: 1               
 | CREATED: 2010.11.09                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to compare two string buffer to see if they are the same.
 
 
*/

#import "ParseCompareStrValue.h"


@implementation TestItemParse(ParseCompareStrValueFunction)

+(void)ParseCompareStrValue:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName1=nil;
	NSString *mReferenceBufferName2=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName1==nil||mReferenceBufferName2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}

	NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];
	if (mReferenceBufferValue1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
	if (mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mReferenceBufferValue1 = [mReferenceBufferValue1 stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue2 = [mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	if ([mReferenceBufferValue1 isEqualToString:mReferenceBufferValue2])
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ; 
	}
	
	return;
	
}

@end

