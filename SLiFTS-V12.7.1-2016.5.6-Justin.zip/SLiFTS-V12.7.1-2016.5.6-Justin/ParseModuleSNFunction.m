//
//  ParseStrWithBetweenNumberFunction.m
//  qt_simulator
//
//  Created by joko on 7/16/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseModuleSNFunction.h"
#import "UIWinManage.h"

@implementation TestItemParse(ParseModuleSNFunction)


+(void)ParseModuleSN:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mTestItemName			= nil    ;
    NSString *mBufferName			= nil    ;
    NSString *mSubSNLength			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"SubSNLength"])
		{
			mSubSNLength = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	NSString *strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYMODULESN];
	if (strSN==nil)
		strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYSYSSN];
	//Get the checked length from appconfig
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    NSInteger checkLen2=0 ;
    NSInteger checkLen3=0 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
        if([strlen rangeOfString:@"|"].length > 0)
        {
            NSArray *tmpSN = [strlen componentsSeparatedByString:@"|"];
            if([tmpSN count] == 2)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
            }
            else if([tmpSN count] == 3)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
                checkLen3 = [[tmpSN objectAtIndex:2] intValue];
            }
            
        }
	}
    
	//end
	if([strSN length]!= checkLen && [strSN length] != checkLen2 && [strSN length] != checkLen3)
	{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The Scan Module SN Length is not invalid !"] ;
			return;
	}
	else
	{
        NSString *strTestStation= [ScriptParse getValueFromSummary:@"TestStation"];
        //if ([strTestStation isEqualToString:@"iQC RGBW"]&&[strSN length]> 17)
        if ([strSN length]> 17)
        {
            strSN = [strSN substringToIndex:17];
        }
        
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strSN];
        if([mSubSNLength length] > 0 && [mSubSNLength intValue] < [strSN length])
        {
            strSN = [strSN substringToIndex:[mSubSNLength intValue]];
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strSN];
        }
	}
    
    if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:DictionaryPtr :mBufferName :strSN] ;
	}
}


+(void)ParseTopModuleSN:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mTestItemName	= nil;
    NSString *mBufferName	= nil;
    NSString *mSNSeperateType	= nil;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"SNSeperateType"])
		{
			mSNSeperateType = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	NSString *strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYMODULESN];
	if (strSN==nil)
		strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYSYSSN];
	
    if ([strSN length] < 17)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The length of the Scan Module SNis less than 17 !"] ;
        return;
    }
	NSString *UISN = @"";
    if([mSNSeperateType isEqualToString:@"SN"])
    {
		UISN = [strSN substringToIndex:17];
	}
    else if([mSNSeperateType isEqualToString:@"LCM_FULL_SN"])
    {
		UISN = strSN;
	}
    else if([mSNSeperateType isEqualToString:@"LCM_CFG"])
    {
        if ([strSN length] < 20)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:17];
            UISN = [UISN substringToIndex:3];
        }
	}
    else if([mSNSeperateType isEqualToString:@"BLU_SN"])
    {
        if ([strSN length] < 50)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:26];
            UISN = [UISN substringToIndex:24];
        }
	}
    else if([mSNSeperateType isEqualToString:@"CG_SN"] || [mSNSeperateType isEqualToString:@"CGS_SN"])
    {
        if ([strSN length] < 67)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:50];
            UISN = [UISN substringToIndex:17];
        }
	}
    else if([mSNSeperateType isEqualToString:@"CG_CFG"] || [mSNSeperateType isEqualToString:@"CGS_CFG"])
    {
        if ([strSN length] < 70)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:67];
            UISN = [UISN substringToIndex:3];
        }
	}
    else
	{
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The Scan Module SN Length is not invalid !"] ;
        return;
	}
    
    [TestItemManage setBufferValue:DictionaryPtr :mBufferName :UISN] ;
    
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :UISN] ;
    return;

	
}

+(void)ParseTopModuleSNFromSFC:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mTestItemName	= nil;
    NSString *mBufferName	= nil;
    NSString *mSNSeperateType	= nil;
    NSString *mReferenceBufferName=nil;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"SNSeperateType"])
		{
			mSNSeperateType = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
    NSString *mReferenceBufferValue=[TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Cann't get tom module sn (lcm full sn) from SFC"];
		return;
	}
    
    NSString *strSN = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"lcm_sn=" Postfix:@"\n"];
    
	
	if ([strSN length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Cann't get tom module sn (lcm full sn) from SFC 2"];
        return;
    }
	
    if ([strSN length] < 17)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The length of the Scan Module SNis less than 17 !"] ;
        return;
    }
	NSString *UISN = @"";
    if([mSNSeperateType isEqualToString:@"SN"])
    {
		UISN = [strSN substringToIndex:70];//17->70 Peter 2015.8.5
	}
    else if([mSNSeperateType isEqualToString:@"LCM_SN"])
    {
        UISN = [strSN substringToIndex:17];//70->17 Annie 2015.9.9
    }
    else if([mSNSeperateType isEqualToString:@"LCM_FULL_SN"])
    {
		UISN = strSN;
	}
    else if([mSNSeperateType isEqualToString:@"LCM_CFG"])
    {
        if ([strSN length] < 20)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:17];
            UISN = [UISN substringToIndex:3];
        }
	}
    else if([mSNSeperateType isEqualToString:@"BLU_SN"])
    {
        if ([strSN length] < 50)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:26];
            UISN = [UISN substringToIndex:24];
        }
	}
    else if([mSNSeperateType isEqualToString:@"CG_SN"])
    {
        if ([strSN length] < 67)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:50];
            UISN = [UISN substringToIndex:17];
        }
	}
    else if([mSNSeperateType isEqualToString:@"CG_CFG"])
    {
        if ([strSN length] < 70)
        {
            UISN = @"ByPass";
        }
        else
        {
            UISN = [strSN substringFromIndex:67];
            UISN = [UISN substringToIndex:3];
        }
	}
    else
	{
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The Scan Module SN Length is not invalid !"] ;
        return;
	}
    
    [TestItemManage setBufferValue:DictionaryPtr :mBufferName :UISN] ;
    
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :UISN] ;
    return;
    
	
}


//Added by Annie 2014.01.10 for 70 digital SN
+(void)ParseEntireSN:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mTestItemName	= nil ;
    NSString *mBufferName = nil;
    
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	NSString *strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYMODULESN];
	if (strSN==nil)
		strSN = [TestItemManage getScanValue:DictionaryPtr :STRKEYSYSSN];
	//Get the checked length from appconfig
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    NSInteger checkLen2=0 ;
    NSInteger checkLen3=0 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
        if([strlen rangeOfString:@"|"].length > 0)
        {
            NSArray *tmpSN = [strlen componentsSeparatedByString:@"|"];
            if([tmpSN count] == 2)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
            }
            else if([tmpSN count] == 3)
            {
                checkLen = [[tmpSN objectAtIndex:0] intValue];
                checkLen2 = [[tmpSN objectAtIndex:1] intValue];
                checkLen3 = [[tmpSN objectAtIndex:2] intValue];
            }
            
        }
	}
    
	//end
	if([strSN length]!= checkLen && [strSN length] != checkLen2 && [strSN length] != checkLen3)
	{
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The Scan Module SN Length is not invalid !"] ;
        return;
	}
	else
	{
        /*
         NSString *strTestStation= [ScriptParse getValueFromSummary:@"TestStation"];
         //if ([strTestStation isEqualToString:@"iQC RGBW"]&&[strSN length]> 17)
         if ([strSN length]> 17)
         {
         strSN = [strSN substringToIndex:17];
         }
         */
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName :strSN];
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strSN];
	}
}
//
+(void)ParseBattery3xBarcode:(NSDictionary*) DictionaryPtr
{
    NSString *mTestItemName	= nil ;
    NSString *mBufferName = nil;
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
    NSString *strBatteryZH = [TestItemManage getScanValue:DictionaryPtr :STRBATTERYZH];
    NSString *strBatteryH = [TestItemManage getScanValue:DictionaryPtr :STRBATTERYH];
    NSString *strBatteryL = [TestItemManage getScanValue:DictionaryPtr :STRBATTERYL];
    
    if(strBatteryZH.length<1 || strBatteryH.length<1 || strBatteryL.length<1)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"The Scan Battery 3x Barcode is Null!"] ;
        return;
    }
    if ([mTestItemName isEqualToString:@"Battery ZH"])
    {
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName :strBatteryZH] ;
        [TestItemParse  SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strBatteryZH];
    }
    else if ([mTestItemName isEqualToString:@"Battery H"])
    {
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName :strBatteryH] ;
        [TestItemParse  SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strBatteryH];
    }
    if ([mTestItemName isEqualToString:@"Battery L"])
    {
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName :strBatteryL] ;
        [TestItemParse  SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strBatteryL];
    }
}



@end
