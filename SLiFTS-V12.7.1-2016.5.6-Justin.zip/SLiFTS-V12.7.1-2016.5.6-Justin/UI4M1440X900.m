/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UIFor4Unit.m  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 MODULE  : 
 PURPOSE : 
 
 $History:: UIFor4Unit.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 14.05.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */

#import "UI4M1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"
#import "testItemParse.h"

//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGTEXTMIN   = {432,  72,	 960,	149};
static const UI_INFOR LOGTEXTMAX   = {21 ,	72,	 1360,	660};
static const UI_INFOR LOGBUTTONMAX = {20 ,	733, 51,	17};
static const UI_INFOR LABEL1	   = {283,  780, 627,	51};
static const UI_INFOR LABEL2       = {956,  789, 284,	17};

#define TIMERINTERVEL			1  //for check if unit plug in
#define TIMERINTERVEL_REFRESH  0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"
#define TIMERINTERVEL5			5  //for check if Fixture plug in

BOOL bFirstRefresh = TRUE;

@implementation UI4M1440X900
-(id)init
{
    self = [super init] ;
	initTableFlag =FALSE;
	tableViewCnt =0;
	refreshTimeCnt=0;
	tableViewForCnt = nil;
//	for(NSInteger i=0; i<MaxUnitFlag; i++)
//		mTestStartFlag[i] = FALSE;
	for(NSInteger i=1; i<5; i++)
        mTestStartFlag[i] = FALSE;
    
	stringModuleSn1 = [[NSMutableString alloc] init] ;
	stringModuleSn2 = [[NSMutableString alloc] init] ;
	stringModuleSn3 = [[NSMutableString alloc] init] ;
	stringModuleSn4 = [[NSMutableString alloc] init] ;
    
    dicScanData1 = nil ;
	dicScanData2 = nil ;
	dicScanData3 = nil ;
	dicScanData4 = nil ;

    //[speechSynth attributeforvoice];
    //NSDictionary *attributes = [NSSpeechSynthesizer attributesForVoice:[speechSynth voice]];
//    scanSN1 = FALSE;
//    scanSN2 = FALSE;
//    scanSN3 = FALSE;
//    scanSN4 = FALSE;
    
	return self ;
}

-(void)dealloc
{
	
	[stringModuleSn1  release] ;
	[stringModuleSn2  release] ;
	[stringModuleSn3  release] ;
	[stringModuleSn4  release] ;
    [dicScanData1  release] ;
	[dicScanData2  release] ;
	[dicScanData3  release] ;
	[dicScanData4  release] ;
//    [speechSynth      release] ;
//    [speechLock       release] ;
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1Copy  setStringValue:[ScriptParse getUILabel1]];
		[textLabel1 setFrame:(NSMakeRect(LABEL1.x, LABEL1.y, LABEL1.width, LABEL1.height))];
		[textLabel1Copy setFrame:(NSMakeRect(LABEL1.x+1, LABEL1.y+1, LABEL1.width, LABEL1.height))];
	}
	
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
	}
	[window setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:1.0 blue:0.94 alpha:1.0]];
	[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
	[textLabel2 setTextColor:[NSColor blueColor]] ;
	[self initUIScanLabelAndText];
	//[textLog setHidden:TRUE];
	//[btnLogClose setHidden:TRUE];
	[self showInitLog];
    //add by kevin
    mTestStartFlag[1]=YES;
    mTestStartFlag[2]=YES;
    mTestStartFlag[3]=YES;
    mTestStartFlag[4]=YES;
    //add by kevin
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
    NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
                                                                            :self selector
                                                                            :@selector(timerRefreshTableViewMethod:) userInfo
                                                                            :TIMERFORUNITPLUGINCHECK repeats
                                                                            :YES ] retain] ;
	[timerRefreshTableView release] ;
    [labelSN1 setEditable:YES];
    [labelSN2 setEditable:YES];
    [labelSN3 setEditable:YES];
    [labelSN4 setEditable:YES];
	[labelSN1 becomeFirstResponder];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor1:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor2:) name:@"SET_UI_BGD_COLOR2" object:nil ] ; 
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor3:) name:@"SET_UI_BGD_COLOR3" object:nil ] ;	
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setTableBgdColor4:) name:@"SET_UI_BGD_COLOR4" object:nil ] ; 
	
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	//DLX2312000XF5702C
    if (bFirstRefresh) 
    {
        bFirstRefresh = FALSE;
        for(int i=0;i<4;i++)
        {
            
            if(tableViewArray[i] != nil)
            {
                [tableViewArray[i] reloadData];
                //[tableViewArray[i] display];//20120813//Commented by Julian 20120907
            }
        }
    }
//    for(int i=0;i<4;i++)
//    {
//        [self setTableBgdColor:i];
//	}
	refreshTimeCnt++ ;
	if (refreshTimeCnt>5)
	{
			NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL5 target
																	   :self selector
																	   :@selector(timerUnitCheckFireMethod:) userInfo
																	   :TIMERFORUNITPLUGINCHECK repeats
																	   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
        refreshTimeCnt = 0;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	
    //	NSInteger totalUnit = 8;//[UIWinManage getTotalUnitNumber];
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
    
    NSLog(@"timerUnitCheckFireMethod");
   mTestStartFlag[1]=YES;
    //if(![UIWinManage isCheckDUTID:1] && mTestStartFlag[1])
    if(![UIWinManage isCheckDUTID:1] && mTestStartFlag[1])
    {
        NSLog(@"ready send command to fixture!");
        //if(1)
          NSLog(@"start send cmd to robot...");
        if([UIWinManage sendCMDtoFixture: 1 :@"GET START1\r"] )
        {
             NSLog(@"send command(GET START1) to fixture success!");
        // if(1)
           if([UIWinManage sendCMDtoFixture: 1 :@"GET START2\r"] )
               {
                   NSLog(@"send command(GET START2) to fixture success!");
                   [UIWinManage startTest:1 :testInforTableview1 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:dicScanData1] ;
                    [labelSN1 setStringValue:@""];
                    mTestStartFlag[1]=NO ;

               }
        }
    }
    // mTestStartFlag[2]=YES;
    if(![UIWinManage isCheckDUTID:2] && mTestStartFlag[2])
    {
        if([UIWinManage sendCMDtoFixture: 2 :@"GET START1\r"] )
        {
            if([UIWinManage sendCMDtoFixture: 2 :@"GET START2\r"] )
            {
                [UIWinManage startTest:2 :testInforTableview2 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:dicScanData2] ;
                [labelSN3 setStringValue:@""];
                mTestStartFlag[2]=NO ;
                
            }
        }
    }
     // mTestStartFlag[3]=YES;
    if(![UIWinManage isCheckDUTID:3] && mTestStartFlag[3])
    {
        if([UIWinManage sendCMDtoFixture: 3 :@"GET START1\r"] )
        {
            if([UIWinManage sendCMDtoFixture: 3 :@"GET START2\r"] )
            {
                [UIWinManage startTest:3 :testInforTableview3 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:dicScanData3] ;
                [labelSN3 setStringValue:@""];
                mTestStartFlag[3]=NO ;
                
            }
        }
    }
     // mTestStartFlag[4]=YES;
    if(![UIWinManage isCheckDUTID:4] && mTestStartFlag[4])
    {
        if([UIWinManage sendCMDtoFixture: 4 :@"GET START1\r"] )
        {
            if([UIWinManage sendCMDtoFixture: 4 :@"GET START2\r"] )
            {
                [UIWinManage startTest:4 :testInforTableview4 :textItemTime4 :textTotalTime4:textTestResult4:NO ScanData:dicScanData4] ;
                [labelSN4 setStringValue:@""];
                mTestStartFlag[4 ]=NO ;
            }
        }
    }
                 //                [UIWinManage startTest:2 :testInforTableview2 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:dicScanData2] ;
//                [labelSN2 setStringValue:@""];
//                mTestStartFlag[2]=NO ;
//            }
//            if(mTestStartFlag[3])
//            {
//                [UIWinManage startTest:3 :testInforTableview3 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:dicScanData3] ;
//                [labelSN3 setStringValue:@""];
//                mTestStartFlag[3]=NO ;
//            }
//            if(mTestStartFlag[4])
//            {
//                [UIWinManage startTest:4 :testInforTableview4 :textItemTime4 :textTotalTime4:textTestResult4:NO ScanData:dicScanData4] ;
//                [labelSN4 setStringValue:@""];
//                mTestStartFlag[4]=NO ;
//            }
//            
//            [btnStartCancel setTitle:@"Stop"];
//        }
//    }
	return ;
}


-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	if(initTableFlag == FALSE)
	{
		if(tableViewForCnt ==nil)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[0]=aTableView;
		}
		else if(tableViewForCnt!= aTableView)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[tableViewCnt-1]=aTableView;
		}
		
		if(tableViewCnt >= 4)
			initTableFlag = TRUE;
		else
			return nil ;
		return nil ;
	}
	NSInteger resultRowIdx =0;
	for (int j=0; j<4; j++) 
	{
		if(tableViewArray[j]==aTableView)
			resultRowIdx = j+1;
	}
	
	/*SCRID:61 on 2011-01-08 Henry modified to add @try @catch @ finally for exception*/
	id retValue ;
	@try {
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			retValue = [UIWinManage getTestItemUIName:rowIndex] ;
		else
			retValue = [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex] ;
	}
	@catch (NSException * e) {
		retValue = @"test item name or result error !";
	}
	@finally {
		return retValue ;
	}
	/*SCRID:61 end */
}

//20100727 add for set box background color for Pass/fail
-(void)setTableBgdColor:(NSInteger)uiIndex
{
	switch (uiIndex) 
	{
		case 0:
			if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
			{
				//[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
                [boxStatus1 setBoxType:NSBoxCustom];
                [boxStatus1 setBorderType:NSLineBorder];
                [boxStatus1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
                
//                if (mTestStartFlag[1])
//                {
//                    [UIWinManage startTest:1 :testInforTableview1 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:dicScanData1] ;
//                    
//                    [labelSN1 setStringValue:@""];
//                    //dicScanData1 = nil;
//                    mTestStartFlag[1]=FALSE;
//                }

			}
			else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
			{
				//[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
                [boxStatus1 setBoxType:NSBoxCustom];
                [boxStatus1 setBorderType:NSLineBorder];
                [boxStatus1 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
                
                mTestStartFlag[1]=YES;
			}
			else 
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 1:
			if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
			{
				//[testInforTableview2 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
                [boxStatus2 setBoxType:NSBoxCustom];
                [boxStatus2 setBorderType:NSLineBorder];
                [boxStatus2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
			{
				//[testInforTableview2 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
                [boxStatus2 setBoxType:NSBoxCustom];
                [boxStatus2 setBorderType:NSLineBorder];
                [boxStatus2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview2 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 2:
			if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
			{
				//[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
                [boxStatus3 setBoxType:NSBoxCustom];
                [boxStatus3 setBorderType:NSLineBorder];
                [boxStatus3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
			{
				//[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
                [boxStatus3 setBoxType:NSBoxCustom];
                [boxStatus3 setBorderType:NSLineBorder];
                [boxStatus3 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview3 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 3:
			if([[textTestResult4 stringValue] isEqualToString:@"Fail"])
			{
				//[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
                [boxStatus4 setBoxType:NSBoxCustom];
                [boxStatus4 setBorderType:NSLineBorder];
                [boxStatus4 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult4 stringValue] isEqualToString:@"PASS"])
			{
				//[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
				//[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
                [boxStatus4 setBoxType:NSBoxCustom];
                [boxStatus4 setBorderType:NSLineBorder];
                [boxStatus4 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview4 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		default:
			break;
	}
}

- (IBAction)btnStartCancel:(id)sender
{
    if([[btnStartCancel title] isEqualToString:@"Start"])
    {
//        for(int i=0;i<4;i++)
//        {
//            if(tableViewArray[i] != nil)
//            {
//                [tableViewArray[i] reloadData];
//                //[tableViewArray[i] display];//20120813//Commented by Julian 20120907
//            }
//        }
        
        if ([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])
        {
            return;
        }
        
        
        
        if ([self checkSN]==FALSE) 
        {
            return;
        }
        [btnStartCancel setTitle:@"Stop"];
        [UIWinManage sendCMDtoFixture: 1 :@"in down on\r"];
        
        for (int i=1; i<=4; i++) 
        {
            switch (i) 
            {
                case 1:
                    if (mTestStartFlag[1]) 
                    {
                        [UIWinManage startTest:1 :testInforTableview1 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:dicScanData1] ;
                        
                        [labelSN1 setStringValue:@""];
                        //dicScanData1 = nil;
                        mTestStartFlag[1]=FALSE;
                    }
                    break;
                case 2:
                    if (mTestStartFlag[2]) 
                    {
                        [UIWinManage startTest:2 :testInforTableview2 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:dicScanData2] ;
                        [labelSN2 setStringValue:@""];
                        //dicScanData2 = nil;
                        mTestStartFlag[2]=FALSE;
                    }
                    break;
                case 3:
                    if (mTestStartFlag[3]) 
                    {  
                        [UIWinManage startTest:3 :testInforTableview3 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:dicScanData3] ;
                        [labelSN3 setStringValue:@""];
                        //dicScanData3 = nil;
                        
                        mTestStartFlag[3]=FALSE;
                    }
                    break;
                case 4:
                    if (mTestStartFlag[4]) 
                    {
                        [UIWinManage startTest:4 :testInforTableview4 :textItemTime4 :textTotalTime4:textTestResult4:NO ScanData:dicScanData4] ;
                        [labelSN4 setStringValue:@""];
                        //dicScanData4 = nil;
                        
                        mTestStartFlag[4]=FALSE;
                    }
                    break;
                default:
                    break;
            }
        }        [labelSN1 becomeFirstResponder];
        //[btnStartCancel becomeFirstResponder];
    }
    else if([[btnStartCancel title] isEqualToString:@"Stop"])
    {
        [UIWinManage stopTest:1] ;
        if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
        {
            [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
            [btnStartCancel setTitle:@"Start"];
            [labelSN1 becomeFirstResponder];
        } 
    }
}

- (IBAction)btnCancel2_Click:(id)sender
{
    [UIWinManage stopTest:2];
    if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
    {
       // [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
        [btnStartCancel setTitle:@"Start"];
        [labelSN1 becomeFirstResponder];
        
    } 
}

- (IBAction)btnCancel3_Click:(id)sender 
{
    [UIWinManage stopTest:3];
    if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
    {
       // [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
        [btnStartCancel setTitle:@"Start"];
        [labelSN1 becomeFirstResponder];
        
    } 
}

- (IBAction)btnCancel4_Click:(id)sender 
{
    [UIWinManage stopTest:4];
    if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
    {
        //[UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
        [btnStartCancel setTitle:@"Start"];
        [labelSN1 becomeFirstResponder];
        
    } 
}
-(void)showInitLog
{
	NSString *temStr=[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
	{	
		//[[[[textLog documentView] textStorage] mutableString] appendString:temStr] ;
		NSRunAlertPanel(@"init log info", temStr, @"prompt", nil, nil) ;
	}
}
-(void)initUIScanLabelAndText
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;

	[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel1Copy setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel2 setTextColor:[NSColor blackColor]];
	[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
	[textLabel1Copy setFont:[NSFont userFontOfSize:28]] ;

	NSArray *arrayUnitInfo = [UIWinManage getTotalUnitInfo];
	if(arrayUnitInfo ==nil)
		NSLog(@"Load Unit Infor error");

	[[textLog documentView]setEditable:false] ;	[textLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];

	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[ NSBundle mainBundle];
	NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	[imageAppleLogo release];
	[imageBgd release];
}

- (IBAction)labelSN1Change:(id)sender {
    if (stringModuleSn1) {
        [stringModuleSn1 release];
        stringModuleSn1 = nil;
    }
    stringModuleSn1 = [[NSMutableString alloc] init];
    [stringModuleSn1 setString:@""];
	[stringModuleSn1 appendString:[labelSN1 stringValue]];
	if (stringModuleSn1==nil)
		return ;
	[stringModuleSn1 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
	[stringModuleSn1 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
	[stringModuleSn1 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
	
	NSInteger len= [stringModuleSn1 length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[labelSN1 setStringValue:@""];
		[labelSN1 becomeFirstResponder];
	}
	else
	{
        if (dicScanData1)
        {
            [dicScanData1 release] ;
            dicScanData1 = nil ;
        }
        
//        dicScanData1 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn1,STRKEYMODULESN,nil];
//        mTestStartFlag[1] = TRUE;
        dicScanData1 =[[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn1,STRKEYMODULESN,nil] ; 
//        //[NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn1,STRKEYMODULESN,nil];
		[labelSN2 becomeFirstResponder];
       mTestStartFlag[1] = TRUE;
    }
}

- (IBAction)labelSN2Change:(id)sender {
    if (stringModuleSn2) {
        [stringModuleSn2 release];
        stringModuleSn2 = nil;
    }
    stringModuleSn2 = [[NSMutableString alloc] init];
    [stringModuleSn2 setString:@""];
	[stringModuleSn2 appendString:[labelSN2 stringValue]];
	if (stringModuleSn2==nil)
		return ;
	[stringModuleSn2 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	[stringModuleSn2 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	[stringModuleSn2 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
	
	NSInteger len= [stringModuleSn2 length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[labelSN2 setStringValue:@""];
		[labelSN2 becomeFirstResponder];
	}
	else
	{
        if (dicScanData2)
        {
            [dicScanData2 release] ;
            dicScanData2 = nil ;
        }
        
        
        dicScanData2 =[[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn2,STRKEYMODULESN,nil] ; 
        mTestStartFlag[2] = TRUE;
//        dicScanData2 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn2,STRKEYMODULESN,nil];
		[labelSN3 becomeFirstResponder];
//        mTestStartFlag[2] = TRUE;
    }
}

- (IBAction)labelSN3Change:(id)sender {
    if (stringModuleSn3) {
        [stringModuleSn3 release];
        stringModuleSn3 = nil;
    }
    stringModuleSn3 = [[NSMutableString alloc] init];
    [stringModuleSn3 setString:@""];
	[stringModuleSn3 appendString:[labelSN3 stringValue]];
	if (stringModuleSn3==nil)
		return ;
	[stringModuleSn3 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
	[stringModuleSn3 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
	[stringModuleSn3 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
	
	NSInteger len= [stringModuleSn3 length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[labelSN3 setStringValue:@""];
		[labelSN3 becomeFirstResponder];
	}
	else
	{
        if (dicScanData3)
        {
            [dicScanData3 release] ;
            dicScanData3 = nil ;
        }
        
        dicScanData3 =[[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN,nil] ; 
        //dicScanData3 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN,nil];
        mTestStartFlag[3] = TRUE;
//        dicScanData3 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN,nil];
		[labelSN4 becomeFirstResponder];
//        mTestStartFlag[3] = TRUE;
    }
    
}

- (IBAction)labelSN4Change:(id)sender {
    if (stringModuleSn4) {
        [stringModuleSn4 release];
        stringModuleSn4 = nil;
    }
    stringModuleSn4 = [[NSMutableString alloc] init];
    [stringModuleSn4 setString:@""];
	[stringModuleSn4 appendString:[labelSN4 stringValue]];
	if (stringModuleSn4==nil)
		return ;
	[stringModuleSn4 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
	[stringModuleSn4 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
	[stringModuleSn4 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
	
	NSInteger len= [stringModuleSn4 length];
	NSString *strlen= [ScriptParse getValueFromSummary:@"SnLength"];
	NSInteger checkLen=12 ;
    if (strlen!=nil)
	{
		if ([strlen intValue]>0)
			checkLen = [strlen intValue] ;
	}
	
	if(len !=checkLen)
	{
		[labelSN4 setStringValue:@""];
		[labelSN4 becomeFirstResponder];
	}
	else
	{
        if (dicScanData4)
        {
            [dicScanData4 release] ;
            dicScanData4 = nil ;
        }
        
        
        dicScanData4 =[[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn4,STRKEYMODULESN,nil] ; 
        //dicScanData4 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn4,STRKEYMODULESN,nil];
        mTestStartFlag[4] = TRUE;
//        dicScanData4 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn1,STRKEYMODULESN,nil];
		[btnStartCancel becomeFirstResponder];
//        mTestStartFlag[4] = TRUE;
    }
}

-(BOOL)checkSN;
{
    
    NSInteger len;
    NSString *strlen;
    NSInteger checkLen=12 ;
    //Check 1
    if (stringModuleSn1) {
        [stringModuleSn1 release];
        stringModuleSn1 = nil;
    }
    stringModuleSn1 = [[NSMutableString alloc] init];
    [stringModuleSn1 setString:@""];
	[stringModuleSn1 appendString:[labelSN1 stringValue]];
	if (stringModuleSn1!=nil)
    {
        [stringModuleSn1 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
        [stringModuleSn1 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
        [stringModuleSn1 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn1 length])];
        
        len= [stringModuleSn1 length];
        strlen= [ScriptParse getValueFromSummary:@"SnLength"];
        checkLen=12 ;
        if (strlen!=nil)
        {
            if ([strlen intValue]>0)
                checkLen = [strlen intValue] ;
        }
        
        if(len !=checkLen)
        {
            [labelSN1 setStringValue:@""];
            //[labelSN1 becomeFirstResponder];
        }
        else
        {
            if (dicScanData1)
            {
                [dicScanData1 release] ;
                dicScanData1 = nil ;
            }
            
            dicScanData1 = [[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn1,STRKEYMODULESN, nil] ;
            mTestStartFlag[1] = TRUE;
        }
    }
    //check 2
    if (stringModuleSn2) {
        [stringModuleSn1 release];
        stringModuleSn1 = nil;
    }
    stringModuleSn2 = [[NSMutableString alloc] init];
    [stringModuleSn2 setString:@""];
	[stringModuleSn2 appendString:[labelSN2 stringValue]];
	if (stringModuleSn2!=nil)
    {
        [stringModuleSn2 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
        [stringModuleSn2 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
        [stringModuleSn2 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn2 length])];
        
        len= [stringModuleSn2 length];
        strlen= [ScriptParse getValueFromSummary:@"SnLength"];
        checkLen=12 ;
        if (strlen!=nil)
        {
            if ([strlen intValue]>0)
                checkLen = [strlen intValue] ;
        }
        
        if(len !=checkLen)
        {
            [labelSN2 setStringValue:@""];
            //[labelSN2 becomeFirstResponder];
        }
        else
        {
            if (dicScanData2)
            {
                [dicScanData2 release] ;
                dicScanData2 = nil ;
            }
            dicScanData2 = [[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn2,STRKEYMODULESN, nil] ;
           // dicScanData2 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn2,STRKEYMODULESN,nil];
            mTestStartFlag[2] = TRUE;
//            dicScanData2 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn2,STRKEYMODULESN,nil];
//            mTestStartFlag[2] = TRUE;
        }
    }
    //check 3
    if (stringModuleSn3) {
        [stringModuleSn3 release];
        stringModuleSn3 = nil;
    }
    stringModuleSn3 = [[NSMutableString alloc] init];
    [stringModuleSn3 setString:@""];
	[stringModuleSn3 appendString:[labelSN3 stringValue]];
	if (stringModuleSn3!=nil)
    {
        [stringModuleSn3 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
        [stringModuleSn3 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
        [stringModuleSn3 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn3 length])];
        
        len= [stringModuleSn3 length];
        strlen= [ScriptParse getValueFromSummary:@"SnLength"];
        checkLen=12 ;
        if (strlen!=nil)
        {
            if ([strlen intValue]>0)
                checkLen = [strlen intValue] ;
        }
        
        if(len !=checkLen)
        {
            [labelSN3 setStringValue:@""];
            //[labelSN3 becomeFirstResponder];
        }
        else
        {
            if (dicScanData3)
            {
                [dicScanData3 release] ;
                dicScanData3 = nil ;
            }
            
            dicScanData3 = [[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN, nil] ;
            //dicScanData3 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN,nil];
            mTestStartFlag[3] = TRUE;
//            dicScanData3 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn3,STRKEYMODULESN,nil];
//            mTestStartFlag[3] = TRUE;
        }
    }
    //Check 4
    if (stringModuleSn4) {
        [stringModuleSn4 release];
        stringModuleSn4 = nil;
    }
    stringModuleSn4 = [[NSMutableString alloc] init];
    [stringModuleSn4 setString:@""];
	[stringModuleSn4 appendString:[labelSN4 stringValue]];
	if (stringModuleSn4!=nil)
    {
        [stringModuleSn4 replaceOccurrencesOfString:@"\n" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
        [stringModuleSn4 replaceOccurrencesOfString:@"\r" withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
        [stringModuleSn4 replaceOccurrencesOfString:@" " withString:@"" options:NSBackwardsSearch range:NSMakeRange(0, [stringModuleSn4 length])];
        
        len= [stringModuleSn4 length];
        strlen= [ScriptParse getValueFromSummary:@"SnLength"];
        checkLen=12 ;
        if (strlen!=nil)
        {
            if ([strlen intValue]>0)
                checkLen = [strlen intValue] ;
        }
        
        if(len !=checkLen)
        {
            [labelSN4 setStringValue:@""];
            //[labelSN4 becomeFirstResponder];
        }
        else
        {
            if (dicScanData4)
            {
                [dicScanData4 release] ;
                dicScanData4 = nil ;
            }
            dicScanData4 = [[NSDictionary alloc] initWithObjectsAndKeys:stringModuleSn4,STRKEYMODULESN, nil] ;

                   // dicScanData4 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn4,STRKEYMODULESN,nil];
            mTestStartFlag[4] = TRUE;
//            dicScanData4 = [NSDictionary dictionaryWithObjectsAndKeys:stringModuleSn4,STRKEYMODULESN,nil];
//            mTestStartFlag[4] = TRUE;
        }
    }
    
    [btnStartCancel becomeFirstResponder];
     
    if(mTestStartFlag[1]||mTestStartFlag[2]||mTestStartFlag[3]||mTestStartFlag[4])
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//-(void)showUnitSN:(NSNotification*)notification ;
//{
//	NSDictionary *temDic= [notification userInfo];
//	NSString *strSN = [temDic objectForKey:@"UnitSN"];
//	
//	if([[notification name] isEqualToString:@"SHOW_UNIT_SN1"])
//	{
//		[labelSN1 setStringValue:strSN];
//	}
//	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN2"])
//	{
//		[labelSN2 setStringValue:strSN];
//	}
//	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN3"])
//	{
//		[labelSN3 setStringValue:strSN];
//	}
//	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN4"])
//	{
//		[labelSN4 setStringValue:strSN];
//	}
//}
-(void)setTableBgdColor1:(NSNotification*)notification
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
	{
		if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
		{
            //			[testInforTableview1 setUsesAlternatingRowBackgroundColors:YES];
			[boxStatus1 setBoxType:NSBoxCustom];
            [boxStatus1 setBorderType:NSLineBorder];
            [boxStatus1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            usleep(5000000) ;  //delay 5s
			//For COF
			//[boxTestState2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
            }
            
		}
		else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
		{
            //			[testInforTableview1 setUsesAlternatingRowBackgroundColors:YES];
			[boxStatus1 setBoxType:NSBoxCustom];
            [boxStatus1 setBorderType:NSLineBorder];
            [boxStatus1 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            usleep(5000000) ;  //delay 5s
            if (!([UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                NSLog(@"1 end pass\n");
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
//                while(![speechSynth isSpeaking])
//                {
//                    [speechLock lock];
//                    [speechSynth startSpeakingString:@"1 PASS"];
//                    [speechLock unlock];
//                    break;
//                }
            }
            
		}
		else 
		{
			//	[boxTestState2 setBoxType:NSBoxPrimary];
			[boxStatus1 setBoxType:NSBoxCustom];
			[boxStatus1 setBorderType:NSLineBorder];
			[boxStatus1 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
		}
        
	}	
	//NSLog(@"set bgd color1\n");
}

-(void)setTableBgdColor2:(NSNotification*)notification
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR2"])
	{
		if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
		{
//			[testInforTableview2 setUsesAlternatingRowBackgroundColors:YES];
//            [testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			//For COF
			//[boxTestState2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            
			[boxStatus2 setBoxType:NSBoxCustom];
            [boxStatus2 setBorderType:NSLineBorder];
            [boxStatus2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
            }
		}
		else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
		{
//			[testInforTableview2 setUsesAlternatingRowBackgroundColors:YES];
//            [testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            
			[boxStatus2 setBoxType:NSBoxCustom];
            [boxStatus2 setBorderType:NSLineBorder];
            [boxStatus2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:3]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                NSLog(@"2 end pass\n");
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
//                while(![speechSynth isSpeaking])
//                {
//                    [speechLock lock];
//                    [speechSynth startSpeakingString:@"2 PASS"];
//                    [speechLock unlock];
//                    break;
//                }
            }
		}
		else 
		{
            //			//	[boxTestState2 setBoxType:NSBoxPrimary];
			[boxStatus2 setBoxType:NSBoxCustom];
			[boxStatus2 setBorderType:NSLineBorder];
			[boxStatus2 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
			//[testInforTableview2 setUsesAlternatingRowBackgroundColors:YES];
		}
	}	
	//NSLog(@"set bgd color2\n");
}
-(void)setTableBgdColor3:(NSNotification*)notification
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR3"])
	{
		if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
		{
//			[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
//            [testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			//For COF
			//[boxTestState2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            
			[boxStatus3 setBoxType:NSBoxCustom];
            [boxStatus3 setBorderType:NSLineBorder];
            [boxStatus3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
            }
		}
		else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
		{
//			[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
            //            [testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            
			[boxStatus3 setBoxType:NSBoxCustom];
            [boxStatus3 setBorderType:NSLineBorder];
            [boxStatus3 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:4])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                NSLog(@"3 end pass\n");
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
//                while(![speechSynth isSpeaking])
//                {
//                    [speechLock lock];
//                    [speechSynth startSpeakingString:@" 3 PASS"];
//                    [speechLock unlock];
//                    break;
//                }
            }
		}
		else 
		{
            //			//	[boxTestState2 setBoxType:NSBoxPrimary];
			[boxStatus3 setBoxType:NSBoxCustom];
			[boxStatus3 setBorderType:NSLineBorder];
			[boxStatus3 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
			//[testInforTableview3 setUsesAlternatingRowBackgroundColors:YES];
		}
	}	
	//NSLog(@"set bgd color3\n");
}
-(void)setTableBgdColor4:(NSNotification*)notification
{
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR4"])
	{
		if([[textTestResult4 stringValue] isEqualToString:@"Fail"])
		{
//			[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
//            [testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			//For COF
			//[boxTestState2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            
			[boxStatus4 setBoxType:NSBoxCustom];
            [boxStatus4 setBorderType:NSLineBorder];
            [boxStatus4 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
            }
		}
		else if([[textTestResult4 stringValue] isEqualToString:@"PASS"])
		{
//			[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
            //            [testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            
			[boxStatus4 setBoxType:NSBoxCustom];
            [boxStatus4 setBorderType:NSLineBorder];
            [boxStatus4 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
            if (!([UIWinManage isCheckDUTID:1]||[UIWinManage isCheckDUTID:2]||[UIWinManage isCheckDUTID:3])) 
            {
                [UIWinManage sendCMDtoFixture: 1 :@"up out on\r"];
                NSLog(@"4 end pass\n");
                [btnStartCancel setTitle:@"Start"];
                //[labelSN1 becomeFirstResponder];
//                if(![speechSynth isSpeaking])
//                {
//                    [speechLock lock];
//                    [speechSynth startSpeakingString:@"4 PASS"];
//                    [speechLock unlock];
//                }
            }
		}
		else 
		{
            ////				[boxTestState2 setBoxType:NSBoxPrimary];
			[boxStatus4 setBoxType:NSBoxCustom];
			[boxStatus4 setBorderType:NSLineBorder];
			[boxStatus4 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
			//[testInforTableview4 setUsesAlternatingRowBackgroundColors:YES];
		}
	}	
	//NSLog(@"set bgd color4\n");
}

@end
