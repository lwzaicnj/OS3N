//
//  SerialCommFunction.m
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "RS232BurnSnFunction.h"
#import "toolFun.h"

@implementation TestItemParse(RS232BurnSnFunction)


+(void)RS232BurnSn:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil;
	NSString *mWriteCmd=nil;// write cmd
	
	NSString *mBufferName=nil;
	NSString *mTimeOut=@"6";
	NSString *mWriteCmdEnd=@"\n";
	NSString *mWhetherRead = @"yes";
	NSString *mEndString =@":-)";
	NSString *mTestItemName=nil;
	NSString *mBurnSNType=nil;
	NSString *mSNLength=@"";
	NSString *mForceBurnUnitSN=@"no";
	
	NSString *mReferenceBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"EndString"])
		{
			mEndString = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BurnSNType"])
		{
			mBurnSNType = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"SNLength"])
		{
			mSNLength = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ForceBurnUnitSN"])
		{
			mForceBurnUnitSN = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	//if (mDevice==nil ||
	//	mWriteCmd==nil
	if (mDevice==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"];
		return ;
	}
	if(mWriteCmd==nil)
		mWriteCmd = @"";

	if ([mBurnSNType isEqualToString: @"BURN SYS SN"])
	{
        
		/* SCRID-111: if the unit SN and the scan SN are equal, no need burn SN. Helen 2011-07-12 */
		BOOL bSnTmp = [self SendData:dictKeyDefined :@"sn\n" :mEndString]; 
		if(!bSnTmp)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return;
		}
		
		NSDate* dateSnTmp = [[[NSDate alloc] init] autorelease];
		int timeSnInterval = -[dateSnTmp timeIntervalSinceNow];
		while(timeSnInterval <= [mTimeOut intValue])
		{
			if([self CheckReceDataIsComplete:dictKeyDefined])
				break;
			else
				usleep(100000);
		}
		NSString* snResult = [self ReceData:dictKeyDefined];
		if(snResult == nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
			return;
		}
		//Blake change for UI2 Burn SN 20140318=====start=============
		NSString *sysSN = nil;
		NSString *SwitchUI = [ScriptParse getValueFromSummary:@"SwitchUI"];
        if ([SwitchUI isEqualToString:@"UI2"])
            sysSN = [TestItemManage getScanValue:dictKeyDefined :@"strMouleSn"];
		else
            sysSN = [TestItemManage getScanValue:dictKeyDefined :@"strSysSn"];
		//Blake change for UI2 Burn SN 20140318=====end=============
		if(![mForceBurnUnitSN boolValue])
		{
			if([snResult rangeOfString:@"Serial:"].length > 0)//unit have sn.
			{
				NSString* strSn = [ToolFun getStrFromPrefixAndPostfix:snResult Prefix:@"Serial: " Postfix:@":-)"];
				strSn = [ToolFun allTrimFromString:strSn trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
				sysSN = [ToolFun allTrimFromString:sysSN trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
				if([strSn isEqualToString:sysSN])//unit sn = scaned sn.
				{
					[TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
					return;
				}
			}
		}
		
		//unit have no sn or unit sn != scaned sn
		if([sysSN length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Sys SN is Null"] ;
			return ;
		}
		
		mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
		mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		mWriteCmd = [mWriteCmd stringByAppendingString:sysSN];
		/* SCRID-111:end */
	}
	else if([mBurnSNType isEqualToString: @"BURN BATTERY SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *batterySN = [TestItemManage getSFCValue:dictKeyDefined :@"strBatterySn"];  
			if([batterySN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Battery SN is Null"] ;
		 		return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:batterySN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn batterySN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" C010286005ADCMX58"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN MATRIX AND SPECIAL BUILDS"])
	{
        NSString *barcode = [TestItemManage getSFCValue:dictKeyDefined :@"strBarcodeSn"];
        if([barcode length] < 1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Barcode is Null"] ;
            return ;
        }
        else
        {
            //SCRID:58
            //modified by Henry on 2011-01-05 for avoiding warning initia variable
            //				NSMutableArray * mutArrayTemp = [barcode componentsSeparatedByString:@"_"];
            NSArray * mutArrayTemp = [barcode componentsSeparatedByString:@"_"];
            //end
            
            //SCRID-155: avoid the right sn but wrong barcode(J1 use J2 or J2a barcode etc).Judith.2012-01-04.
            NSString *dataResultBoardId =[TestItemManage getUnitValue:dictKeyDefined:STRKEYBOARDID];
            if([dataResultBoardId length] > 0)
            {
//                if([dataResultBoardId rangeOfString:@"0A"].length > 0)  //0x0A == P105
//                {
//                    if(([barcode rangeOfString:@"J81"].length>0) || ([barcode rangeOfString:@"j81"].length>0));
//                    else
//                    {
//                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not RL1 Barcode"] ;
//                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not RL1 Barcode"] ;
//                        return;
//                    }
//                }
//                else if([dataResultBoardId rangeOfString:@"0C"].length > 0) //0x0C == P106
//                {
//                    //modifeid by Henry 2012-02-13
//                    //modifeid by Ray 2012-03-06
//                    if(([barcode rangeOfString:@"J82"].length>0) || ([barcode rangeOfString:@"j82"].length>0) || ([barcode rangeOfString:@"J81"].length>0) || ([barcode rangeOfString:@"j81"].length>0));
//                    else
//                    {
//                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not RL2 Barcode"] ;
//                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not RL2 Barcode"] ;
//                        return;
//                    }
//                }
//                
//                else if([dataResultBoardId rangeOfString:@"0E"].length > 0) //0x0E == P107
//                {
//                    if(([barcode rangeOfString:@"J83"].length>0) || ([barcode rangeOfString:@"j83"].length>0));
//                    else
//                    {
//                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not RL3 Barcode"] ;
//                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not RL3 Barcode"] ;
//                        return;
//                    }
//                }
//                
//                //start 20140228 Justin add RL1 boardid:0x06 RL2 boardID:0x02
//                else if([dataResultBoardId rangeOfString:@"06"].length > 0) //0x0E == J81
//                {
//                    if(([barcode rangeOfString:@"J81"].length>0) || ([barcode rangeOfString:@"j81"].length>0));
//                    else
//                    {
//                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not RL1 Barcode"] ;
//                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not RL1 Barcode"] ;
//                        return;
//                    }
//                }
//                else if([dataResultBoardId rangeOfString:@"02"].length > 0) //0x02 == J82
//                {
//                    if(([barcode rangeOfString:@"J82"].length>0) || ([barcode rangeOfString:@"j82"].length>0));
//                    else
//                    {
//                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not RL2 Barcode"] ;
//                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not RL2 Barcode"] ;
//                        return;
//                    }
//                }
                //Justin add end
                
                //start 20150127 Kevin add SL1 boardid:0x0A SL2 boardID:0x0C
                if([dataResultBoardId rangeOfString:@"0A"].length > 0) //0x0A == J128
                {
                    if(([barcode rangeOfString:@"J128"].length>0) || ([barcode rangeOfString:@"j128"].length>0));
                    else
                    {
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not SL1 Barcode"] ;
                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not SL1 Barcode"] ;
                        return;
                    }
                }
               // else if([dataResultBoardId rangeOfString:@"0C"].length > 0) //0x0C == J127
                else if([dataResultBoardId rangeOfString:@"08"].length > 0) //0x08 == J127
                {
                    if(([barcode rangeOfString:@"J127"].length>0) || ([barcode rangeOfString:@"j127"].length>0));
                    else
                    {
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not SL2 Barcode"] ;
                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL,Not SL2 Barcode"] ;
                        return;
                    }
                }
                //Kevin add end
                
                //modified end
                else
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid BoardID"] ;
                    return;
                }
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No BoardID"] ;
                return;
            }
            //SCRID-155:End
            
            // serin 20100720
            //if([mutArrayTemp count] < 4)
            if([mutArrayTemp count] < 3)
                // end
                
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid Barcode"] ;
                return ;
            }
            else
            {
                NSString *MatrixSpecialBuild = @"";
                
                // ======  Barcode  ========
                //
                // K48M_EVT2_MAIN3_0003
                // K94-PROTO1_SOP-01_0001
                //
                // ==========================
                // serin 20100718
                
                MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:0]];
                MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:@"/*/*/"];
                MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
                MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:@"/"];
                MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
                
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:0]];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:@"/"];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:@"/*/*/"];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:3]];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:@"/"];
                //MatrixSpecialBuild = [MatrixSpecialBuild stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
                // end
                
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
                mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
                mWriteCmd = [mWriteCmd stringByAppendingString:MatrixSpecialBuild];
            }
        }
    }
	else if([mBurnSNType isEqualToString: @"BURN HWCONFIG"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
            
            
            BOOL bOptsTmp = [self SendData:dictKeyDefined :@"syscfg print OPTS\n" :mEndString]; 
            if(!bOptsTmp)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return;
            }
            NSDate* dateOptsTmp = [[[NSDate alloc] init] autorelease];
            int timeSnInterval = -[dateOptsTmp timeIntervalSinceNow];
            while(timeSnInterval <= [mTimeOut intValue])
            {
                if([self CheckReceDataIsComplete:dictKeyDefined])
                    break;
                else
                    usleep(100000);
            }
            NSString* OptsResult = [self ReceData:dictKeyDefined];
            if(OptsResult == nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
                return;
            }
            
			NSString *HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
			if([HWCofig length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWCofig is Null"] ;
			 	return ;
			}
            
            //OptsResult = [ToolFun allTrimFromString:OptsResult trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
            //HWCofig = [ToolFun allTrimFromString:HWCofig trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
			NSLog(@"Burn OPts HWCofigSFC = %@", HWCofig);
			NSLog(@"Burn OPts OptsResult = %@", OptsResult);
			
            if([OptsResult rangeOfString:HWCofig].length > 0){
                
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
                return;
            }
            
            
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:HWCofig];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn HWCofig"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" WIFI&BT/LG100MHz/GPS/UMTS/NAND,SIZE=16G/RAM,SIZE=256M"];
		}
	}
	//20110831 add for burn ClrC by Helen.
	//SCRID:134
	//Description:in order to burn device color(like white,black) to syscfg key ClrC
	else if([mBurnSNType isEqualToString: @"BURN ClrC"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
            /*
            BOOL bClrCTmp = [self SendData:dictKeyDefined :@"syscfg print ClrC\n" :mEndString]; 
            if(!bClrCTmp)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return;
            }
            NSDate* dateClrCTmp = [[[NSDate alloc] init] autorelease];
            int timeSnInterval = -[dateClrCTmp timeIntervalSinceNow];
            while(timeSnInterval <= [mTimeOut intValue])
            {
                if([self CheckReceDataIsComplete:dictKeyDefined])
                    break;
                else
                    usleep(100000);
            }
            NSString* ClrCResult = [self ReceData:dictKeyDefined];
            if(ClrCResult == nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
                return;
            }
            NSLog(@"BURN ClrC ClrCResult=%@",ClrCResult);
            
            NSString* ClrC1=nil;
            NSString* ClrC2=nil;
            NSString* ClrC3=nil;
            //ClrCResult = [ToolFun allTrimFromString:ClrCResult trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
            if([ClrCResult rangeOfString:@"0x00000001 0x00000000 0x00000000 0x00000000"].length > 0)
            {
                ClrC1 = @"White";
                ClrC2 = @"WHITE";
                ClrC3 = @"white";
            }
            else if([ClrCResult rangeOfString:@"0x00000000 0x00000000 0x00000000 0x00000000"].length > 0)
            {
                ClrC1 = @"Black";
                ClrC2 = @"BLACK";
                ClrC3 = @"black";
            }
            Ray remove 2012-08-15
            else{
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"receive error data!"] ;
                return;
            }
            */
            
            
            
			NSString *HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
			//HWCofig = @"HWCONFIG:WIFI&BT/LG100MHz/NAND,SIZE=64G/RAM,SIZE=1G/WHITE";
			if([HWCofig length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWCofig is Null"] ;
			 	return ;
			}
			NSArray* arrTmp = [HWCofig componentsSeparatedByString:@"/"];
            
			if([arrTmp count]<1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWConfig format is error!"] ;
				return ;
			}
            
			NSString* strColor = [arrTmp objectAtIndex:([arrTmp count]-1)];
           // strColor = [strColor substringToIndex:5];
            NSLog(@"BURN ClrC strColorSFC=%@",strColor);
            /*
            if([ClrC1 isEqualToString:strColor]||[ClrC2 isEqualToString:strColor]||[ClrC3 isEqualToString:strColor])
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
                return;
            }
            */
                // gray:        000200009B9899003C3B3B0000000000  black
                // gold:        00020000B3C5D400E3E4E10000000000
                // silver:      00020000D8D9D700E3E4E10000000000  white

            //tiffany 20151210
            if ([strColor isEqualToString:@"Black"]||[strColor isEqualToString:@"BLACK"]||[strColor isEqualToString:@"black"])
            {
                strColor=@"0x00000200 0x00B9B7BA 0x00272728 0x00000000";
            }
            else if ([strColor isEqualToString:@"White"]||[strColor isEqualToString:@"WHITE"]||[strColor isEqualToString:@"white"])
            {
                strColor=@"0x00000200 0x00DADCDB 0x00E4E7E8 0x00000000";
            }
            else if ([strColor isEqualToString:@"Cashmere"]||[strColor isEqualToString:@"cashmere"]||[strColor isEqualToString:@"CASHMERE"])
            {
                strColor=@"0x00000200 0x00E1CCB7 0x00E4E7E8 0x00000000";
            }
            else if ([strColor isEqualToString:@"Rose Gold"]||[strColor isEqualToString:@"rose gold"]||[strColor isEqualToString:@"ROSE GOLD"])
            {
                strColor=@"0x00000200 0x00E4C1B9 0x00E4E7E8 0x00000000";
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid Device Color!"] ;
                return ;
            }
            //end
          	
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:strColor];
			NSLog(@"%@",mWriteCmd);
            
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn ClrC"] ;
		 	return ;
		}
	}
	
	//20110831 add for burn ClrC by Helen.
	//SCRID:134
	//end

	else if([mBurnSNType isEqualToString: @"BURN GRAPE SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
            //NSString *grapeSN = [TestItemManage getSFCValue:dictKeyDefined :@"strGrapeSn"];//remove by justin 20140228
            //add by justin 20140228
            NSString *grapeSN = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];//we only can get LCM_FULL_SN value(70 digits) from SFC, need resolve to 5 parts (LCM_SN,LCM_CFG,BLU_SN,CG_SN,CG_CFG(EG:CT1 overlay))
            //add end

			if([grapeSN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Grape SN is Null"] ;
			 	return ;
			}
            
            BOOL bSnTmp = [self SendData:dictKeyDefined :@"syscfg print MtSN\n" :mEndString];
            if(!bSnTmp)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return;
            }
            
            NSDate* dateSnTmp = [[NSDate alloc] init];
            int timeSnInterval = -[dateSnTmp timeIntervalSinceNow];
            while(timeSnInterval <= [mTimeOut intValue])
            {
                timeSnInterval = -[dateSnTmp timeIntervalSinceNow];
                if([self CheckReceDataIsComplete:dictKeyDefined])
                    break;
                else
                    usleep(100000);
            }
            [dateSnTmp release];
            NSString* snResult = [self ReceData:dictKeyDefined];
            if(snResult == nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
                return;
            }
            if(![mForceBurnUnitSN boolValue])
            {
                if([snResult rangeOfString:grapeSN].length > 0)
                {
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need to burn"] ;
                    return;
                }
            }
            
			
			
			/*SCRID-27: Check any length of the grape sn*/
			/*SCRID-27: joko 2010-12-02*/
			if([mSNLength length] > 0)
			{
				if([grapeSN length] != [mSNLength intValue])
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The length of Grape SN is not correct"] ;
					return ;
				}
			}
			else
			{
				if(([grapeSN length] == 17) || ([grapeSN length] == 20))
                    ;
                else
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The length of Grape SN is not 20"] ;
					return ;
				}
			}
			/*SCRID-27: joko 2010-12-02 add end*/
            /*if([[ScriptParse getValueFromSummary:@"NeedBarcode"] boolValue])
            {*/
//**************************************************20130705*****Remove**********************************************************//
//            NSString *scanGrapeSn = [TestItemManage getSFCValue:dictKeyDefined :@"strBarcodeSn"];
//            if(scanGrapeSn == nil)                                                                         
//            {                                                                                                                  
//                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please scann grape SN"] ;        
//                return ;
//            }
//            if(![grapeSN isEqualToString:scanGrapeSn])
//            {
//                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The SFC grape SN is not the same with the  scanning grape SN"] ;
//                return ;
//            }
//*******************************************************************************************************************************//
			//}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:grapeSN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn Grape SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" C43A7801A3DDTM2A1E"];
		}		
	}
	/*SCRID-103: Add Burn Display SN, Kenshin 2011-05-23*/
	else if([mBurnSNType isEqualToString: @"BURN DSPL SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			//setSFCValue
			//20140228 Justin add for getting LCM_SN value from LCM_FULL_SN Buffer value,and remove getting DSPLSN from getSFCValue funtion
			//NSString *DSPLSN = [TestItemManage getSFCValue:dictKeyDefined :STRKEYDSPLSN];
            NSString *DSPLSN = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
            //add end

			if([DSPLSN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"DSPL SN is Null"] ;
			 	return ;
			}
			
            
            BOOL bSnTmp = [self SendData:dictKeyDefined :@"syscfg print LCM#\n" :mEndString];
            if(!bSnTmp)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return;
            }
            
            NSDate* dateSnTmp = [[NSDate alloc] init];
            int timeSnInterval = -[dateSnTmp timeIntervalSinceNow];
            while(timeSnInterval <= [mTimeOut intValue])
            {
                timeSnInterval = -[dateSnTmp timeIntervalSinceNow];
                if([self CheckReceDataIsComplete:dictKeyDefined])
                    break;
                else
                    usleep(100000);
            }
            [dateSnTmp release];
            NSString* snResult = [self ReceData:dictKeyDefined];
            if(snResult == nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
                return;
            }
            if(![mForceBurnUnitSN boolValue])
            {
                if([snResult rangeOfString:DSPLSN].length > 0)
                {
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need to burn"] ;
                    return;
                }
            }
            
			if([mSNLength length] > 0)
			{
				if([DSPLSN length] != [mSNLength intValue])
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The length of DSPL SN is not correct"] ;
					return ;
				}
			}
			if([[ScriptParse getValueFromSummary:@"NeedSN"] boolValue])
            {
                NSString *sysSN = [TestItemManage getScanValue:dictKeyDefined :@"strSysSn"];
                if(sysSN == nil)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please scann LCD SN"] ;
                    return ;
                }
                if(![DSPLSN isEqualToString:sysSN])
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The SFC LCD SN is not the same with the scanning LCD SN"] ;
                    return ;
                }
            }
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:DSPLSN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn Grape SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" DLN1177004WDJP4PA"];
		}		
	}
	/*SCRID-103: end*/
	
	else if([mBurnSNType isEqualToString: @"BURN PROX VAL"])
	{
		NSString *ProxValue = [TestItemManage getUnitValue:dictKeyDefined :@"Prox Value"];
		if([ProxValue length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prox Value is Null"] ;
		 	return ;
		}
		
		if(mWriteCmd==nil || [mWriteCmd length]<1)
			mWriteCmd = @"syscfg add PBCl ";
		else
		{
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		}
		mWriteCmd = [mWriteCmd stringByAppendingString:ProxValue];
	}
	else if([mBurnSNType isEqualToString: @"BURN ProxCenterpoint VAL"])
	{
		NSString *ProxCenterpointValue = [TestItemManage getUnitValue:dictKeyDefined :@"ProxCenterpoint Value"];
		if([ProxCenterpointValue length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ProxCenterpoint Value is Null"] ;
		 	return ;
		}
		
		if(mWriteCmd==nil || [mWriteCmd length]<1)
			mWriteCmd = @"syscfg add PBCb ";
		else
		{
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		}
		mWriteCmd = [mWriteCmd stringByAppendingString:ProxCenterpointValue];
	}
	else if([mBurnSNType isEqualToString: @"BURN ProxTemp VAL"])
	{
		NSString *ProxTempValue = [TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp Value"];
		if([ProxTempValue length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ProxTemp Value is Null"] ;
		 	return ;
		}
		
		if(mWriteCmd==nil || [mWriteCmd length]<1)
			mWriteCmd = @"syscfg add PBTb ";
		else
		{
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		}
		mWriteCmd = [mWriteCmd stringByAppendingString:ProxTempValue];
	}
	
	// serin 20101006
	else if([mBurnSNType isEqualToString: @"BURN ProxTemp1 VAL"])
	{
		NSString *ProxTempValue1 = [TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp1 Value"];
		if([ProxTempValue1 length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ProxTemp Value is Null"] ;
		 	return ;
		}
		
		if(mWriteCmd==nil || [mWriteCmd length]<1)
			mWriteCmd = @"syscfg add PBTa ";
		else
		{
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		}
		mWriteCmd = [mWriteCmd stringByAppendingString:ProxTempValue1];
	}
	
	else if([mBurnSNType isEqualToString: @"BURN Prox Params VAL"])
	{
		NSString *ProxParamsValue = [TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"];
		if([ProxParamsValue length] < 1)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prox Params is Null"] ;
		 	return ;
		}
		
		if(mWriteCmd==nil || [mWriteCmd length] < 1)
			mWriteCmd = @"syscfg add CPCl ";
		else
		{
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
		}
		mWriteCmd = [mWriteCmd stringByAppendingString:ProxParamsValue];
	}
	// end
	
	else if([mBurnSNType isEqualToString: @"BURN MPN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *MPN = [TestItemManage getSFCValue:dictKeyDefined :@"strMpn"];
			
			/* SCRID-28: T39 MPN Use 995-8188,when CustPartNo=995-8188*T39*LL/A  */
			/* SCRID-28: joko 2010-12-02 */
			if([MPN rangeOfString:@"T39"].length > 0 || [MPN rangeOfString:@"t39"].length > 0)
			{
				MPN = [TestItemManage getSFCValue:dictKeyDefined :@"T39MPN"] ;
			}
			/*SCRID-28: joko 2010-12-02 add end*/
			if([MPN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"MPN is Null"] ;
			 	return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:MPN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn MPN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 123"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN REGN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *REGN = [TestItemManage getSFCValue:dictKeyDefined :@"strRegn"];
			if([REGN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"REGN is Null"] ;
			 	return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:REGN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn REGN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 123"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN HWYSN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *HWYSN = [TestItemManage getSFCValue:dictKeyDefined :@"strHwySn"];
			if([HWYSN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWYSN is Null"] ;
				return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:HWYSN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn HWYSN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 123"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN X15SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *X15SN = [TestItemManage getSFCValue:dictKeyDefined :@"strX15Sn"];
			if([X15SN length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"X15SN is Null"] ;
				return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:X15SN];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn X15SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" 123"];
		}
	}
	//caijunbo add on 20100719
	else if([mBurnSNType isEqualToString: @"BURN X23SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{	
			if (mReferenceBufferName==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
				return;
			}
			NSString* X23snstring=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
			if(X23snstring != nil)
			{
				mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
				mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
				mWriteCmd = [mWriteCmd stringByAppendingString:X23snstring];
			}
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn X15SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" DLX029405MHDDTP3M"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN X24SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if (mReferenceBufferName==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
				return;
			}
			NSString* X24snstring=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:X24snstring];
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn X15SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" DLX0294076XDDTQ3F"];
		}
		
	}
	else if([mBurnSNType isEqualToString: @"BURN X25SN"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if (mReferenceBufferName==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
				return;
			}
			NSString* X25snstring=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
			if(X25snstring != nil)
			{
				mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
				mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
				mWriteCmd = [mWriteCmd stringByAppendingString:X25snstring];
			}
		}
		else
		{
			//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn X15SN"] ;
		 	//return ;
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" DLX0294076XDDTQ3F"];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN WiFi W24G"])   //2010-12-04 henry add for burn WiFi W24
	{
		NSString* strWiFiW24G=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
		if(strWiFiW24G != nil)
		{
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:strWiFiW24G];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN WiFi W50G"])   //2010-12-04 henry add for burn WiFi W50G
	{
		NSString* strWiFiW50G=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
		if(strWiFiW50G != nil)
		{
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:strWiFiW50G];
		}
	}
	//SCRID:129 Add burn camera barcode by Helen 20110810
	else if([mBurnSNType isEqualToString: @"BURN FCAMERABARCODE"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *FrontCameraBarcode = [TestItemManage getSFCValue:dictKeyDefined :@"strFCMS"];
			if([FrontCameraBarcode length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Front Camera Barcode is Null"] ;
			 	return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:FrontCameraBarcode];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn FCMS"] ;
		 	return ;
		}
	}	
	else if([mBurnSNType isEqualToString: @"BURN BCAMERABARCODE"])
	{
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			NSString *BackCameraBarcode = [TestItemManage getSFCValue:dictKeyDefined :@"strBCMS"];
			if([BackCameraBarcode length] < 1)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Back Camera Barcode is Null"] ;
			 	return ;
			}
			
			mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:@""];
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:BackCameraBarcode];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"No need SFC, So No Need Burn BCMS"] ;
		 	return ;
		}
	}	
	//SCRID:129 end
	
	//SCRID:130 Add parse "ParseCameraFunction"	
	else if([mBurnSNType isEqualToString: @"BURN FCMB"]) 
	{
		NSString* strFCMB=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
        //add by justin
        strFCMB = [strFCMB stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        strFCMB = [strFCMB stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strFCMB = [strFCMB stringByReplacingOccurrencesOfString:@" " withString:@""];
        strFCMB = [strFCMB stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		if(strFCMB != nil)
		{
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:strFCMB];
		}
	}
	else if([mBurnSNType isEqualToString: @"BURN BCMB"])  
	{
		NSString* strBCMB =[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
        //add by justin
        strBCMB = [strBCMB stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        strBCMB = [strBCMB stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strBCMB = [strBCMB stringByReplacingOccurrencesOfString:@" " withString:@""];
        strBCMB = [strBCMB stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		if(strBCMB != nil)
		{
			mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
			mWriteCmd = [mWriteCmd stringByAppendingString:strBCMB];
		}
	}
	//SCRID:130 end


	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	if (mWriteCmdEnd!=nil)
		[strMutSendBuffer appendString:mWriteCmdEnd] ;

	bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mEndString] ;
	
	 if (bTmp==false)
	 {
		 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
		 return ;
	 }
	
	if ([mWhetherRead boolValue])
	{
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
				usleep(100000) ; //delay 100ms
		}
		//read data
		NSString *dataResult = [self ReceData:dictKeyDefined] ;
		if (dataResult!=nil &&
			mBufferName !=nil
			)
		{
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
			return ;
		}
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;
	

}


+(void)BurnSnWithPrefixAndPostfix:(NSDictionary*)dictKeyDefined
{
	//key parse
    NSString *mWriteHexData=nil;
    NSString *mTestItemName=nil;
	NSString *mDevice=nil;
	NSString *mWriteCmd=nil;// write cmd
	
	NSString *mBufferName=nil;
	NSString *mTimeOut=@"6";
	NSString *mWriteCmdEnd=@"\n";
	NSString *mEndString =@":-)";
	NSString *mSNLength=@"";
    
    NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	
	NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferName2=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"EndString"])
		{
			mEndString = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"SNLength"])
		{
			mSNLength = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteHexData"])
		{
			mWriteHexData = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mDevice==nil || mWriteCmd==nil || mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"];
		return ;
	}
	
    // add by justin to jude mesa_sn is same with Nvsn in unit's module
	if((mReferenceBufferName2==nil) && ([mWriteCmd isEqualToString:@"syscfg add NvSn"]))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"No exist ReferenceBufferName2"] ;
        return;
    }
    NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    if ([mReferenceBufferValue2 isEqualToString:@"Fail"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Compare mesa_sn fail"] ;
        return;
    }
    // justin add end
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"];
		return ;
    }
    
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	
    
	NSString *tmp = strFind;
    //tmp = @"0DB20200 65014800 3001C349 FFA34995 23";
    
	tmp = [tmp stringByReplacingOccurrencesOfString:@" " withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	if (tmp==nil || [tmp length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no valid data"] ;
	    return  ;
	}
	
    mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
    if([mWriteHexData boolValue])
    {
        NSString *hexHead = @"0x";
        NSString *hexData = tmp;
        strFind = @"";
        int loopTimes = [tmp length] / 8;
        if(([tmp length] % 8) > 0)
            loopTimes = loopTimes + 1;
        for(int i=1; i<=loopTimes; i++)
        {
            if((i == loopTimes) && (([tmp length] % 8) > 0))
                strFind = [strFind stringByAppendingString:[hexHead stringByAppendingString:[hexData substringToIndex:([tmp length] % 8)]]];
            else
                strFind = [strFind stringByAppendingString:[hexHead stringByAppendingString:[hexData substringToIndex:8]]];
            strFind = [strFind stringByAppendingString:@" "];
            if((i == loopTimes) && (([tmp length] % 8) > 0))
                hexData = [hexData substringFromIndex:([tmp length] % 8)];
            else
                hexData = [hexData substringFromIndex:8];
        }
    }
    
    mWriteCmd = [mWriteCmd stringByAppendingString:strFind];
	if (mWriteCmdEnd!=nil && mWriteCmd!=nil)
        mWriteCmd = [mWriteCmd stringByAppendingString:mWriteCmdEnd];
    
	bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mEndString] ;
	
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
	
	
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined]) 
            break ;
        else
            usleep(100000) ;
    }
    
    NSString *dataResult = [self ReceData:dictKeyDefined] ;
    
    if (mBufferName!=nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
    
    if (dataResult!=nil)
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data!"] ;
}

@end
