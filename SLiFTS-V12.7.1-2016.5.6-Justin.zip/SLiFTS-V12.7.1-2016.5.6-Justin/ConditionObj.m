/*                                        $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 22 Feb. 2010 
 * first implementation
 * SCRID-66: Change prox cal to three fixtures and three UI.
 */

#import "ConditionObj.h"
#import "testItemParse.h"
#import "testItemManage.h"
#import "UIWinManage.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "UIAlert.h"


extern BOOL gBlinkFlag[3][3];

extern BOOL canTestFixture1;
extern BOOL canTestFixture2;
extern BOOL canTestFixture3;

extern BOOL canDetectFixture1;
extern BOOL canDetectFixture2;
extern BOOL canDetectFixture3;

extern NSInteger testResult[3];

@implementation ConditionObj

-(NSCondition*)getConditionObj
{
	return conditionObj;
}

-(void)initConditionObj
{
	conditionObj=[[NSCondition alloc] init];
	mFailType =FAIL_NONE;
}
-(void)deallocConditionObj
{
	[conditionObj release];
	conditionObj=nil;
}


-(void)CheckUUTPlugin:(NSDictionary*) dictKeyDefined;
{
	//BOOL bIsNextPositonAvailable=FALSE;
	//NSString *strCurrentUUTSN=nil;
	//NSString *strCurrentUUTWrongPositionSN=nil;
	//NSString *strOriginalUUTSN=nil;
	//NSString *mTimeOut=@"5";
	//strOriginalUUTSN=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
	//NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	//bool bIsUnitExist=false;
	
	
	NSString *strDevice =[dictKeyDefined objectForKey:@"Device"];
	NSString *mPosition = [dictKeyDefined objectForKey:@"Position"] ;
	if([strDevice isEqualToString:@"IPad"] || [mPosition isEqualToString:@"0"])
	{
		[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
		sleep(1);
		[conditionObj signal];
		return;
	}
	
	while(TRUE)
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ; //added by Henry  2011-02-22

		sleep(0.1);
		NSString *strDutID = [dictKeyDefined objectForKey:@"DUTID"];
		
		
		/*if([strDevice isEqualToString:@"IPad"] || [mPosition isEqualToString:@"0"])
		{
			[conditionObj signal];
			break;
		}*/
		if(([strDevice isEqualToString:@"UUT"] && canDetectFixture2)
		   ||([strDevice isEqualToString:@"IPad"] && canDetectFixture1)
		   ||([strDevice isEqualToString:@"UART"] && canDetectFixture3))
		{
			NSString *tmpDevice=[strDevice stringByAppendingString:@"11"];
			NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
			
			if([TestItemParse CheckUnitExist:tmpDevice:strTmp])
			{
			 //if(([strDevice isEqualToString:@"UUT"] && canTestFixture2)
			 // ||([strDevice isEqualToString:@"UART"] && canTestFixture3))
			 //{
				NSString *mWriteCmd = @"sn\n" ;
				sleep(0.1);
				
				[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
				BOOL bPassFlag= FALSE;
				NSString *dataResult=nil;
				NSInteger iLoopCnt=0;
				
				while (iLoopCnt <= 3)
				{
					usleep(50000) ; //delay 50ms
					
					if ([TestItemParse CheckReceDataIsComplete:dictKeyDefined]) 
					{
						dataResult = [TestItemParse ReceData:dictKeyDefined] ;
						if (nil==dataResult)
						{
							iLoopCnt++;
							//[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
							continue;
						}
						if(([dataResult rangeOfString:@":-)"].length >0) && ([dataResult rangeOfString:@"Serial:"].length>0))
						{
							bPassFlag = TRUE;
							break;
						}
						[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
					}

					iLoopCnt++;
				}
				
				if(!bPassFlag)
				{
					[pool release];
					continue;
				}
					
				//read data
				NSString *strThreadSN11 = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
				 
				if((dataResult!=nil) && ([dataResult rangeOfString:strThreadSN11].length>0))
				{
					if(([strDevice isEqualToString:@"UUT"] && canTestFixture2)
						 ||([strDevice isEqualToString:@"UART"] && canTestFixture3))
					{
						if([strDevice isEqualToString:@"UUT"])
						{
							if([strDutID isEqualToString:@"1"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar12"] indexBox:0 indexBar:1];
							if([strDutID isEqualToString:@"2"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar22"] indexBox:1 indexBar:1];	
							if([strDutID isEqualToString:@"3"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar32"] indexBox:2 indexBar:1];
						}
						if([strDevice isEqualToString:@"UART"])
						{
							if([strDutID isEqualToString:@"1"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:0 indexBar:2];
							if([strDutID isEqualToString:@"2"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar23"] indexBox:1 indexBar:2];	
							if([strDutID isEqualToString:@"3"])
								[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar33"] indexBox:2 indexBar:2];
						}
						
						[conditionObj signal];
						break;
					}
				}
				else 
				{	//step 1 : check wrong unit.
					NSInteger totalUI=3;
					NSInteger indexOfWindow =1;
					//NSString *strDutIDTmp = [dictKeyDefined objectForKey:@"DUTID"];

					if([strDevice isEqualToString:@"UUT"]) //second coloum windows
					{
						if([strDutID isEqualToString:@"1"] && gBlinkFlag[0][1])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\n ");
							NSLog(@"\njoko###@@@110 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@110 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=2;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error! Edge Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
							
						}
						else if([strDutID isEqualToString:@"2"] && gBlinkFlag[1][1])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\njoko###@@@116 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@116 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=2;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error!  Edge Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
						}
						else if([strDutID isEqualToString:@"3"] && gBlinkFlag[2][1])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\njoko###@@@119 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@119 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=2;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error!  Edge Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
						}
					}
					if([strDevice isEqualToString:@"UART"]) //three coloum windows
					{
						if([strDutID isEqualToString:@"1"] && gBlinkFlag[0][2])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\njoko###@@@1100000 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@1100000 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=3;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error! Bottom Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
						}
						else if([strDutID isEqualToString:@"2"] && gBlinkFlag[1][2])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\njoko###@@@1166666 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@1166666 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=3;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error! Bottom Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
						}
						else if([strDutID isEqualToString:@"3"] && gBlinkFlag[2][2])
						{
							[self setWrongUnitBgdColor:dictKeyDefined];
							NSLog(@"\njoko###@@@1199999 UUT-win12 sedCmdReturnSN11=%@",dataResult);
							NSLog(@"\njoko###@@@1199999 UUT-win12 strThreadSN11=%@",strThreadSN11);
							indexOfWindow=3;
							[UIAlert setInitPosition:totalUI index:indexOfWindow] ; //henry added 2011-02-06
							UIAlert *alert = [[UIAlert alloc] init];
							[alert showWindow:self];
							[alert updatPosition:totalUI index:indexOfWindow];
							[alert setMessageText:@"Error! Bottom Config"];
							[alert setInformativeText:@"Wrong Unit!"];
							[alert addButtonWithTitle:@"OK"];
							[alert runModal];
							[alert release];
						}
					}
				}
			//}
			//else
			//{
			//	continue;
			//}
				[pool release];
				continue;
			
			}
			else
			{
				usleep(1000);
				if(![TestItemParse CheckUnitExist:tmpDevice:strTmp])
				{
					if([strDevice isEqualToString:@"UUT"])
					{
						if([strDutID isEqualToString:@"1"] && !gBlinkFlag[1][1] && !gBlinkFlag[2][1])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar12"] indexBox:0 indexBar:1];
						if([strDutID isEqualToString:@"2"] && !gBlinkFlag[0][1] && !gBlinkFlag[2][1])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar22"] indexBox:1 indexBar:1];
						if([strDutID isEqualToString:@"3"] && !gBlinkFlag[0][1] && !gBlinkFlag[1][1])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar32"] indexBox:2 indexBar:1];
					}
					if([strDevice isEqualToString:@"UART"])
					{
						if([strDutID isEqualToString:@"1"] && !gBlinkFlag[1][2] && !gBlinkFlag[2][2])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:0 indexBar:2];
						if([strDutID isEqualToString:@"2"] && !gBlinkFlag[0][2] && !gBlinkFlag[2][2])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar23"] indexBox:1 indexBar:2];	
						if([strDutID isEqualToString:@"3"] && !gBlinkFlag[0][2] && !gBlinkFlag[1][2])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar33"] indexBox:2 indexBar:2];
					}
				}
				[pool release];
				continue;
			}
		}
		else
		{
			[pool release];
			continue;
		}
		[pool release];
	}
}


-(enum FAILTYPE)getFailType
{
	return mFailType;
}

-(void)setWrongUnitBgdColor:(NSDictionary*)dictKeyDefined //henry added  for set wrong unit screen color 2011-02-09
{
	NSString *mWriteCmd = @"pattern 8\n" ;   //GRAY
	[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
	NSInteger iLoopCnt=0;;
	BOOL bPassFlag= FALSE;
	while (iLoopCnt<=3)
	{
		iLoopCnt++ ;
		
		if ([TestItemParse CheckReceDataIsComplete:dictKeyDefined]) 
		{
			NSString *dataResult = [TestItemParse ReceData:dictKeyDefined] ;
			if([dataResult rangeOfString:@"Finish"].length >0)
			{
				bPassFlag = TRUE;
				break;
			}
		}
		else
		{
			[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
			usleep(50000) ; //delay 500
		}
	}
	if(bPassFlag)
	NSLog(@"Set SCreen color fail !");
}

//henry add end 2011-01-21
@end
