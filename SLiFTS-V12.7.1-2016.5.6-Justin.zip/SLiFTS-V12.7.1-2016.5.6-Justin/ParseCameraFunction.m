/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseCameraFunction.m  $|
 | $Author:: Helen                  $Revision::  1					 $|
 | CREATED: 2011-03-04                $Modtime:: 2011-08-10		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseCameraFunction.m                                       $
 * *****************  Version 1  *****************
 * User: Helen           Date: 2011-08-10
 * Created in 
 * first implementation
 */

#import "ParseCameraFunction.h"
#import "Pudding.h"
#import "toolFun.h"

@implementation TestItemParse(ParseCameraFunction)

//Ray modified for QL 2012-11-25
//Ray seperate writing FCMB & BCMB into two functions for PS
+(void)FrontParseCamera:(NSDictionary*)dictKeyDefined
{	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mBufferName = nil;
    NSString *mStrSpec = @"NVM Data 512 bytes :";//add by judith 20130129
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
        else if ([strKey isEqualToString:@"StrSpec"])//add by judith 20130129
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"] ;
		return ;
	}
	
    NSRange rangeFront = [mReferenceBufferValue rangeOfString:mStrSpec];//Modified by judith 20130129
    
	if(rangeFront.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error!"];
		return;
	}
	
	//front
	//NVM Data 512 bytes : 
    //0x0 : 0x62 0x68 0x61 0xEA 0x52 0x11 0x4 0x7C 
    //0x8 : 0x35 0x48 0x50 0x32 0xC9 0x0 0x0 0x0 
    //0x10 : 0x0 0x0F 0x02 0x41 0x31 0xB 0x24 0x00 
    //0x18 : 0xEA 0x8 0x23 0x6C 0x82 0x96 0xA7 0xB4 
    //0x20 :
	
    NSString* strFront = [mReferenceBufferValue substringFromIndex:rangeFront.location+rangeFront.length];
	
	NSArray* arrayFront = [strFront componentsSeparatedByString:@":"];
	
    NSString* FCMB=@"";
    
	NSString* strExtend = @"0";
	
	//front
	for(int i=1; i<5; i++)
	{
		NSString* strFTmp = [arrayFront objectAtIndex:i];
		NSArray* arrayFTmp = [strFTmp componentsSeparatedByString:@"0x"];
		for(int j=1; j<=8; j++)
		{
			NSString* strFrontCamera = [arrayFTmp objectAtIndex:j];
//			strFrontCamera = [ToolFun allTrimFromString:strFrontCamera trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
//			strFrontCamera = [ToolFun allTrimFromString:strFrontCamera trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
            strFrontCamera = [strFrontCamera stringByReplacingOccurrencesOfString:@" " withString:@""];
            strFrontCamera = [strFrontCamera stringByReplacingOccurrencesOfString:@"\n" withString:@""];//change by justin
			if([strFrontCamera length]<2)
			{
				strFrontCamera = [strExtend stringByAppendingString:strFrontCamera];
			}
			FCMB = [FCMB stringByAppendingString:strFrontCamera];
		}
	}

	NSLog(@"%@",FCMB);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :FCMB] ;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
	return ;
}

+(void)BackParseCamera:(NSDictionary*)dictKeyDefined
{	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mBufferName = nil;
    NSString *mStrSpec = @"NVM Data 512 bytes :";//add by judith 20130129
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
        else if ([strKey isEqualToString:@"StrSpec"])//add by judith 20130129
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
	}
    
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"] ;
		return ;
	}
	
    NSRange rangeBack = [mReferenceBufferValue rangeOfString:mStrSpec];//Modified by judith 20130129
    
	if(rangeBack.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error!"];
		return;
	}
	
	//back
	//NVM Data 512 bytes : 
    //0x0 : 0x93 0x32 0xA8 0x43 0xC 0x62 0xB8 0xB0 
    //0x8 : 0x0 0x0 0x0 0x0 0x0 0x0 0x0 0x0 
    //0x10 : 0x52 0x26 0x22 0xBF 0xC7 0x0 0x1 0x7E 
    //0x18 : 0x36 0x48 0x4E 0x35 0xEC 0x0 0x0 0x0 
    //0x20 : 0x0 0x0 0x0 0x31 0x71 0x18 0x10 0x73 
    //0x28 :
	
    NSString* strBack = [mReferenceBufferValue substringFromIndex:rangeBack.location+rangeBack.length];
	
    NSArray* arrayBack = [strBack componentsSeparatedByString:@":"];
	
    NSString* BCMB=@"";
    
	NSString* strExtend = @"0";
	
    //back
    for(int i=3; i<6; i++)
	{
		NSString* strBTmp = [arrayBack objectAtIndex:i];
		NSArray* arrayBTmp = [strBTmp componentsSeparatedByString:@"0x"];
		for(int j=1; j<=8; j++)
		{
			NSString* strBackCamera = [arrayBTmp objectAtIndex:j];
//			strBackCamera = [ToolFun allTrimFromString:strBackCamera trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
//			strBackCamera = [ToolFun allTrimFromString:strBackCamera trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
            strBackCamera = [strBackCamera stringByReplacingOccurrencesOfString:@" " withString:@""];//change by justin
            strBackCamera = [strBackCamera stringByReplacingOccurrencesOfString:@"\n" withString:@""];//change by justin
			if([strBackCamera length]<2)
			{
				strBackCamera = [strExtend stringByAppendingString:strBackCamera];
			}
			BCMB = [BCMB stringByAppendingString:strBackCamera];
		}
	}
    
    NSLog(@"%@",BCMB);
	
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :BCMB] ;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
	return ;
}
//Ray modified for QL 2012-11-25
+(void)ParseStrWithStrSpecForCameraDli:(NSDictionary*)dictKeyDefined
{
    NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
    NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferName1=nil;
	NSString *mTestItemName=nil        ;
    NSString *mStrSpec=nil;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    if (mStrSpec==nil ||
        mReferenceBufferName1==nil
        ||mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    NSString *mReferenceBufferValue ;
    NSString *mReferenceBufferValue1;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    
    NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
    NSRange rangeTmp1=[mReferenceBufferValue1 rangeOfString:mStrSpec] ;
    if (rangeTmp.length==0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"CameraPick Fail"] ;
	    return  ;
    }
    else if(rangeTmp.length>0 && rangeTmp1.length>0)
    {
        strTestResultForUIinfo = @"Pass" ;
        enumResult = RESULT_FOR_PASS;
        
    }
    else
    {
        strTestResultForUIinfo = @"Fail";
        enumResult = RESULT_FOR_FAIL;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
    return ;
    
}

@end



