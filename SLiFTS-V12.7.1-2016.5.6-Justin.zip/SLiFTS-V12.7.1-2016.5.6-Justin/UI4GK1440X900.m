/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UIFor4Unit.m  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 MODULE  : 
 PURPOSE : 
 
 $History:: UIFor4Unit.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 14.05.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */

#import "UI4GK1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"

//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGTEXTMIN   = {432,  72,	 960,	149};
static const UI_INFOR LOGTEXTMAX   = {21 ,	72,	 1360,	660};
static const UI_INFOR LOGBUTTONMAX = {20 ,	733, 51,	17};
static const UI_INFOR LABEL1	   = {283,  780, 627,	51};
static const UI_INFOR LABEL2       = {956,  789, 284,	17};

#define TIMERINTERVEL			1  //for check if unit plug in
#define TIMERINTERVEL_REFRESH  0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"
BOOL bReloadTableViewOnceBeforeTest2 = TRUE;

@implementation UI4GK1440X900
-(id)init
{
	initTableFlag =FALSE;
	tableViewCnt =0;
	refreshTimeCnt=0;
	tableViewForCnt = nil;
	for(NSInteger i=0; i<MaxUnitFlag; i++)
		mTestStartFlag[i] = TRUE;
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	fixtureIdPanelController = nil;
	//end
	
	self = [super init] ;
	return self ;
}

-(void)dealloc
{
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	if(fixtureIdPanelController)
	{
		[fixtureIdPanelController release];
		fixtureIdPanelController =nil ;
	}
	//end
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1Copy  setStringValue:[ScriptParse getUILabel1]];
		[textLabel1 setFrame:(NSMakeRect(LABEL1.x, LABEL1.y, LABEL1.width, LABEL1.height))];
		[textLabel1Copy setFrame:(NSMakeRect(LABEL1.x+1, LABEL1.y+1, LABEL1.width, LABEL1.height))];
	}
	
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
	}
	[window setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:1.0 blue:0.94 alpha:1.0]];
	[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
	[textLabel2 setTextColor:[NSColor blueColor]] ;
	[self initUIScanLabelAndText];
	[textLog setHidden:TRUE];
	[btnLogClose setHidden:TRUE];
	[self showInitLog];
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
															   :self selector
															   :@selector(timerRefreshTableViewMethod:) userInfo
															   :TIMERFORUNITPLUGINCHECK repeats
															   :YES ] retain] ;
	[timerRefreshTableView release] ;
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];
	}
	
	[btnCancel1 setHidden:TRUE];
	[btnCancel2 setHidden:TRUE];
	[btnCancel3 setHidden:TRUE];
	[btnCancel4 setHidden:TRUE];
	
	//henry add for show Unit SN 2011-03-07
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN1" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN2" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN3" object:nil ] ;
	//SCRID:92 Henry added 2011-03-22 Fixed Gatekeeper SN cannot show problem .
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN4" object:nil ] ;
	//SCRID:92 end
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR2" object:nil ] ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR3" object:nil ] ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR4" object:nil ] ;
    
	
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	if(bReloadTableViewOnceBeforeTest2)
	{
		bReloadTableViewOnceBeforeTest2 = FALSE;
		for(int i=0;i<4;i++)
		{
			if(tableViewArray[i] != nil)
				[tableViewArray[i] reloadData];
		}
	}
	
	refreshTimeCnt++ ;
	if (refreshTimeCnt>5)
	{
			NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL target
																	   :self selector
																	   :@selector(timerUnitCheckFireMethod:) userInfo
																	   :TIMERFORUNITPLUGINCHECK repeats
																	   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	
	NSInteger totalUnit = 4;//[UIWinManage getTotalUnitNumber];
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
	//Henry add for check Fixture ID
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if([UICommon getFixtureIDScanedFlag] ==NO)
		{
			if(![UICommon getShowFixtureIDPanelFlag])
			{
				NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
				if(!fixtureIdPanelController)
					fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
				[fixtureIdPanelController showWindow:self];
				[UICommon setShowFixtureIDPanelFlag:YES];
				return ;
			}
			return ;
		}
	}
	
	for(int i=0;i<totalUnit;i++)
	{ 
		if([UIWinManage isCheckDUTID:i+1])
		{
			continue;
		}
		else 
		{
			if([UIWinManage getUnit:i+1])
         //   if(1)
			{
				switch(i+1)
				{
					case 1:
					if(mTestStartFlag[i])
                    //    if(1)
						{
							[UIWinManage startTest:1 :testInforTableview1 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
							[labelSN1 setStringValue:@""];
							mTestStartFlag[i]=NO ;
						}
						break;
					case 2:
						if(mTestStartFlag[i])
						{
							[UIWinManage startTest:2 :testInforTableview2 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
							[labelSN2 setStringValue:@""];
							mTestStartFlag[i]=NO ;
						}
						break;
					case 3:
						if(mTestStartFlag[i])
						{
							[UIWinManage startTest:3 :testInforTableview3 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
							[labelSN3 setStringValue:@""];
							mTestStartFlag[i]=NO ;
						}
						break;
					case 4:
						if(mTestStartFlag[i])
						{
							[UIWinManage startTest:4 :testInforTableview4 :textItemTime4 :textTotalTime4:textTestResult4:NO ScanData:nil] ;
							[labelSN4 setStringValue:@""];
							mTestStartFlag[i]=NO ;
						}
						break;
					default:
						break;
				}
			}else
			{
				if (i<MaxUnitFlag)
					mTestStartFlag[i] = YES;
			};
		}
	}
	return ;
}


-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	if(initTableFlag == FALSE)
	{
		if(tableViewForCnt ==nil)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[0]=aTableView;
		}
		else if(tableViewForCnt!= aTableView)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[tableViewCnt-1]=aTableView;
		}
		
		if(tableViewCnt >= 4)
			initTableFlag = TRUE;
		else
			return nil ;
		return nil ;
	}
	NSInteger resultRowIdx =0;
	for (int j=0; j<4; j++) 
	{
		if(tableViewArray[j]==aTableView)
			resultRowIdx = j+1;
	}
	
	/*SCRID:61 on 2011-01-08 Henry modified to add @try @catch @ finally for exception*/
	id retValue ;
	@try {
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			retValue = [UIWinManage getTestItemUIName:rowIndex] ;
		else
			retValue = [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex] ;
	}
	@catch (NSException * e) {
		retValue = @"test item name or result error !";
	}
	@finally {
		return retValue ;
	}
	/*SCRID:61 end */
}

//20100727 add for set box background color for Pass/fail
-(void)setTableBgdColor:(NSInteger)uiIndex
{
	switch (uiIndex) 
	{
		case 0:
			if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 1:
			if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
			{
				[testInforTableview2 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
			{
				[testInforTableview2 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview2 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview2 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 2:
			if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
			{
				[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
			{
				[testInforTableview3 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview3 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview3 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		case 3:
			if([[textTestResult4 stringValue] isEqualToString:@"Fail"])
			{
				[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult4 stringValue] isEqualToString:@"PASS"])
			{
				[testInforTableview4 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview4 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview4 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		default:
			break;
	}
}

-(IBAction)btnOpenLog1_Click:(id)sender
{
	
	if([btnLog1 title] == @"log"){
		[btnLog1 setTitle:@"close"];
		[self showLog:1 isDisable:TRUE];
	}
	else {
		[textLog setHidden:TRUE];
		[btnLog1 setTitle:@"log"];
		[self showLog:0 isDisable:FALSE];
	}
}
-(IBAction)btnOpenLog2_Click:(id)sender
{
	if([btnLog2 title] == @"log"){
		[btnLog2 setTitle:@"close"];
		[self showLog:2 isDisable:TRUE];
	}
	else {
		[textLog setHidden:TRUE];
		[btnLog2 setTitle:@"log"];
		[self showLog:0 isDisable:FALSE];
	}
}
-(IBAction)btnOpenLog3_Click:(id)sender
{
	if([btnLog3 title] == @"log"){
		[btnLog3 setTitle:@"close"];
		[self showLog:3 isDisable:TRUE];
	}
	else {
		[textLog setHidden:TRUE];
		[btnLog3 setTitle:@"log"];
		[self showLog:0 isDisable:FALSE];
	}
}
-(IBAction)btnOpenLog4_Click:(id)sender
{
	if([btnLog4 title] == @"log"){
		[btnLog4 setTitle:@"close"];
		[self showLog:4 isDisable:TRUE];
	}
	else {
		[textLog setHidden:TRUE];
		[btnLog4 setTitle:@"log"];
		[self showLog:0 isDisable:FALSE];
	}
}
-(void)logBtnReset
{
	[btnLog1 setTitle:@"log"];
	[btnLog2 setTitle:@"log"];
	[btnLog3 setTitle:@"log"];
	[btnLog4 setTitle:@"log"];
}
-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag
{
	
	[[[[textLog documentView] textStorage] mutableString] setString:@""] ;
	NSString *temStr = [TestItemManage getUnitLogInfo:logIndex];
	
	if(temStr ==nil)
	{
		NSRunAlertPanel(@"WARNNING", @"Can't find the log file !", @"prompt", nil, nil) ;
		[self logBtnReset];
	}
	else
	{
		if(iShowFlag == FALSE)
			return TRUE;
		else
		{
			[boxTestItem setHidden:TRUE];
			[textLog setHidden:FALSE];
			[btnLogClose setHidden:FALSE];
			[btnLogClose setFrame:NSMakeRect(LOGBUTTONMAX.x, LOGBUTTONMAX.y, LOGBUTTONMAX.width, LOGBUTTONMAX.height)];
			[textLog setFrame:NSMakeRect(LOGTEXTMAX.x, LOGTEXTMAX.y, LOGTEXTMAX.width, LOGTEXTMAX.height)];
		}
		[[[[textLog documentView] textStorage] mutableString] appendString:temStr] ;
	}
	return TRUE;
}
-(void)showInitLog
{
	NSString *temStr=[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
	{	
		//[[[[textLog documentView] textStorage] mutableString] appendString:temStr] ;
		NSRunAlertPanel(@"init log info", temStr, @"prompt", nil, nil) ;
	}
}
-(IBAction)closeLog_Click:(id)sender;
{
	if([btnLog1 title] == @"close"){
		[boxTestItem setHidden:FALSE];
		[textLog setHidden:TRUE];
		[btnLog1 setTitle:@"log"];
		[btnLogClose setHidden:TRUE];
		[self showLog:1 isDisable:FALSE];
	}
	else if([btnLog2 title] == @"close"){
		[boxTestItem setHidden:FALSE];
		[textLog setHidden:TRUE];
		[btnLog2 setTitle:@"log"];
		[btnLogClose setHidden:TRUE];
		[self showLog:2 isDisable:FALSE];
	}
	else if([btnLog3 title] == @"close"){
		[boxTestItem setHidden:FALSE];
		[textLog setHidden:TRUE];
		[btnLog3 setTitle:@"log"];
		[btnLogClose setHidden:TRUE];
		[self showLog:3 isDisable:FALSE];
	}
	else if([btnLog4 title] == @"close"){
		[boxTestItem setHidden:FALSE];
		[textLog setHidden:TRUE];
		[btnLog4 setTitle:@"log"];
		[btnLogClose setHidden:TRUE];
		[self showLog:4 isDisable:FALSE];
	}
}

-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}

-(void)initUIScanLabelAndText
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;

	[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel1Copy setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel2 setTextColor:[NSColor blackColor]];
	[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
	[textLabel1Copy setFont:[NSFont userFontOfSize:28]] ;

	NSArray *arrayUnitInfo = [UIWinManage getTotalUnitInfo];
	if(arrayUnitInfo ==nil)
		NSLog(@"Load Unit Infor error");

	[[textLog documentView]setEditable:false] ;
	[btnLog1 setTitle:@"log"];
	[btnLog2 setTitle:@"log"];
	[btnLog3 setTitle:@"log"];
	[btnLog4 setTitle:@"log"];
	[textLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];

	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[ NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}

//Henry added 2011-03-03
-(IBAction)btnCancel1_Click:(id)sender
{
	[UIWinManage stopTest:1] ;
}

-(IBAction)btnCancel2_Click:(id)sender
{
	[UIWinManage stopTest:2] ;
}

-(IBAction)btnCancel3_Click:(id)sender
{
	[UIWinManage stopTest:3] ;
}

-(IBAction)btnCancel4_Click:(id)sender
{
	[UIWinManage stopTest:4] ;
}

-(void)showUnitSN:(NSNotification*)notification ;
{
	NSDictionary *temDic= [notification userInfo];
	NSString *strSN = [temDic objectForKey:@"UnitSN"];
	
	if([[notification name] isEqualToString:@"SHOW_UNIT_SN1"])
	{
		[labelSN1 setStringValue:strSN];
	}
	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN2"])
	{
		[labelSN2 setStringValue:strSN];
	}
	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN3"])
	{
		[labelSN3 setStringValue:strSN];
	}
	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN4"])
	{
		[labelSN4 setStringValue:strSN];
	}
}


-(void)setBoxBgdColor:(NSNotification*)notification ; //henry added 2011-02-28 for set box background color for Pass/fail
{
    
	if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
	{

        if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
        {
            [boxTestState1 setBoxType:NSBoxCustom];
            [boxTestState1 setBorderType:NSLineBorder];
            [boxTestState1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
            //For COF
            //[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
        }
        else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
        {
            [boxTestState1 setBoxType:NSBoxCustom];
            [boxTestState1 setBorderType:NSLineBorder];
            [boxTestState1 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
        }
        else
        {
            //	[boxTestState setBoxType:NSBoxPrimary];
            [boxTestState1 setBoxType:NSBoxCustom]; //20100727 added by henry
            [boxTestState1 setBorderType:NSLineBorder];
            [boxTestState1 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
        }
    }
	//[boxTestState display];
 if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR2"])
 {
    
    if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
	{
		[boxTestState2 setBoxType:NSBoxCustom];
		[boxTestState2 setBorderType:NSLineBorder];
		[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		//For COF
		//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
	}
	else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
	{
		[boxTestState2 setBoxType:NSBoxCustom];
		[boxTestState2 setBorderType:NSLineBorder];
		[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
	}
	else
	{
		//	[boxTestState setBoxType:NSBoxPrimary];
		[boxTestState2 setBoxType:NSBoxCustom]; //20100727 added by henry
		[boxTestState2 setBorderType:NSLineBorder];
		[boxTestState2 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
 	}
 }
 
if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR3"])
{
        
    if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
	{
		[boxTestState3 setBoxType:NSBoxCustom];
		[boxTestState3 setBorderType:NSLineBorder];
		[boxTestState3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		//For COF
		//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
	}
	else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
	{
		[boxTestState3 setBoxType:NSBoxCustom];
		[boxTestState3 setBorderType:NSLineBorder];
		[boxTestState3 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
	}
	else
	{
		//	[boxTestState setBoxType:NSBoxPrimary];
		[boxTestState3 setBoxType:NSBoxCustom]; //20100727 added by henry
		[boxTestState3 setBorderType:NSLineBorder];
		[boxTestState3 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
 	}
}
    
if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR4"])
{
    if([[textTestResult4 stringValue] isEqualToString:@"Fail"])
	{
		[boxTestState4 setBoxType:NSBoxCustom];
		[boxTestState4 setBorderType:NSLineBorder];
		[boxTestState4 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		//For COF
		//[boxTestState setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
	}
	else if([[textTestResult4 stringValue] isEqualToString:@"PASS"])
	{
		[boxTestState4 setBoxType:NSBoxCustom];
		[boxTestState4 setBorderType:NSLineBorder];
		[boxTestState4 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
	}
	else
	{
		//	[boxTestState setBoxType:NSBoxPrimary];
		[boxTestState4 setBoxType:NSBoxCustom]; //20100727 added by henry
		[boxTestState4 setBorderType:NSLineBorder];
		[boxTestState4 setFillColor:[NSColor colorWithCalibratedRed:0.906 green:0.937 blue:0.937 alpha:0.9]];
 	}
}
    
}

@end
