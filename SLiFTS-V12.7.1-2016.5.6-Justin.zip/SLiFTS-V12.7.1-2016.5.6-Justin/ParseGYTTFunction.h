/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseGYTTFunction.h	 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 05 Oct. 2010            $Modtime:: 09 Oct 2010 15:24	 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseGYTTFunction.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 05 Oct. 2010   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseGYTTFunction)
+(void)ParseGYTT:(NSDictionary*) DictionaryPtr;

+(void)ParseGYTTV2:(NSDictionary*) DictionaryPtr ;

@end