//
//  DCR.m
//  iFTS
//
//  Created by Foxconn001 on 10-9-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DCR.h"

ViStatus status;
ViSession defaultRM,instr;
ViFindList findList;
unsigned char buffer[100];
char stringinput[512];
ViUInt32 retCount,writeCount,numinstrs;
char instrDescriptor[VI_FIND_BUFLEN];

@implementation TestItemParse(DCR)

+(void)GPIBInitialDevice:(NSDictionary*)dictKeyDefined
{
	status = viOpenDefaultRM(&defaultRM);
	if (status < VI_SUCCESS)
	{
		printf("Could not open a session to the VISA Resource Manager!\n");
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Could not open a session to the VISA Resource Manager!"] ;
		return;
		//exit (EXIT_FAILURE);
	}  
	status = viFindRsrc(defaultRM, "GPIB[0-9]*::?*INSTR", &findList, &numinstrs, instrDescriptor);
	printf("%d instruments, serial ports, and other resources found:\n\n",numinstrs);
	printf("%s \n",instrDescriptor);
	if (status<VI_SUCCESS)
	{
	  [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Could not find a device!"] ;
	  return;
	}
	status = viOpen(defaultRM, instrDescriptor, VI_NULL, VI_NULL, &instr);
	if (status < VI_SUCCESS)
	{
		printf ("An error occurred opening a session to %s\n",instrDescriptor);
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Could not open a device!"] ;
		return;
	}
	strcpy(stringinput,"*CLS\n");
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	
    status = viSetAttribute (instr, VI_ATTR_TMO_VALUE, 15000);
	/*
	strcpy(stringinput,"CONF:LRES\n");
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	if(status<VI_SUCCESS)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Reset Device Fail"] ;
		return;
	}
	 */
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
	NSLog(@"InitDevice");
}
+(void)GPIBSwitchToLowResistance:(NSDictionary*)dictKeyDefined
{
	NSString *mSetRange	= nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"SetRange"])
		{
			mSetRange = [dictKeyDefined objectForKey:strKey] ;
		}
	}	
	if(mSetRange==nil)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
		return;
	}
	//char Range[100];
	//Range =[mSetRange UTF8String];
    strcpy(stringinput,[mSetRange UTF8String]);
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	if(status<VI_SUCCESS)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Set Range fail"] ;
		return;
	}
	
	strcpy(stringinput,"TRIG:SOUR IMM\r");
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
	
}


+(void)WhetherPressRightButton:(NSDictionary*)dictKeyDefined
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	NSString *mLimit= nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Limit"])
		{
			mLimit = [dictKeyDefined objectForKey:strKey] ;
		}
	}	
	
	strcpy(stringinput,"READ?\n");
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);

	status = viRead (instr, buffer, 100, &retCount);
	if(status < VI_SUCCESS)
	{
		strcpy(stringinput,"*CLS\n");
		status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	}
	
	NSString* ret = [NSString stringWithCString:(const char*)buffer];
	double dRes =  atof((const char*)buffer);
	dRes =dRes*1000;
	if(dRes>[mLimit doubleValue])
	{
		NSAlert * alert = [NSAlert alertWithMessageText:@""
										  defaultButton:@"OK" 
										alternateButton:nil 
											otherButton:nil 
							  informativeTextWithFormat:[NSString stringWithFormat:@"Do you press the right point\n"]];
		
			[alert runModal];
	}
	
	NSLog(@"cv mode res************%@\n",ret);
	
    ret = [NSString stringWithFormat:@"%.6lf",dRes];
	
	enumResult=RESULT_FOR_PASS;
	strTestResultForUIinfo=ret;
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	 

}
+(void)GPIBReadResistance:(NSDictionary*)dictKeyDefined 
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//usleep(1000000) ; //delay 100ms
	
	strcpy(stringinput,"READ?\n");
	//strcpy(stringinput,"MEAS:LRES? MIN\n");
	status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
	if(status < VI_SUCCESS)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Write data fail"] ;
		return;
	}
	
	usleep(10000) ; //delay 100ms
	status = viRead (instr, buffer, 100, &retCount);
	if(status < VI_SUCCESS)
	{
		strcpy(stringinput,"*CLS\n");
		status = viWrite(instr, (ViBuf)stringinput, (ViUInt32)strlen(stringinput), &writeCount);
		
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Read data fail"] ;
		return;
	}
	double dRes = atof((const char*)buffer);
	dRes =dRes*1000;
	NSString* ret = [NSString stringWithFormat:@"%.6lf",dRes];
	NSLog(@" real res================%@\n",ret);
	enumResult=RESULT_FOR_PASS;
	strTestResultForUIinfo=ret;
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	
	//[[ret retain]autorelease];
}

+(void)GPIBReleaseDevice:(NSDictionary*)dictKeyDefined 
{
	//NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	status = viClose (instr);
	status = viClose (defaultRM);
	NSLog(@"ReleaseDevice");
	enumResult=RESULT_FOR_PASS;
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"Pass"] ;
	
}

@end
