/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa         $Workfile:: UIAlert.m					 $|
 | $Author:: Henry           $Revision::  1							 $|
 | CREATED: 06.09.10         $Modtime:: 2011-02-22				 $|
 | STATE  : Alpha                                                     |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UIAlert.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 06.09.10   Time: 15:58
 * Created in 
 * first implementation
 */


#import "UIAlert.h"
//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
#import "UICommon.h"
#import "testItemParse.h"
//SCRID:101

@implementation UIAlert
- (id)init
{
	if(![super initWithWindowNibName:@"UIAlert"])
		return nil;
	return self;
}

-(void)awakeFromNib
{
	bntReturnValue = 0 ;
	btnPressedFlag = NO ;
	
	if((nil !=button1)&&(nil !=button2)&&(nil !=button3))
	{
		[button1 setHidden:YES];
		[button2 setHidden:YES];
		[button3 setHidden:YES];
	}

	NSBundle * mainBundle =[NSBundle mainBundle];
	NSString * pathOfAppLogo = [mainBundle pathForResource:@"appIcon" ofType:@"jpg"];
	NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppLogo];
	if((nil != imageViewBgd)&&(nil !=imageAppleLogo))
	{
		[imageViewBgd setImage:imageAppleLogo];
		[imageAppleLogo release];
	}
	
	if(win != nil)
	{
		[win setTitle:@""] ;
		NSPoint alertInitPos =  [UIAlert getInitPosition];
		if(alertInitPos.x)
		{
			[win setFrameOrigin:initPosition];
		}
	}
    [labelTime setHidden:YES];
}

- (void)windowDidLoad
{
	NSLog(@"Nib UIAlert is loaded !");
}


- (void)setMessageText:(NSString *)messageText
{
	if((messageText != nil)&&(labelTitle != nil))
	{
		[labelTitle setTitleWithMnemonic:messageText];
		[labelTitle setFont:[NSFont userFontOfSize:16]] ;
		//add for refresh display 2011-02-22
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		[labelTitle display];
		[pool release];
	}
}

- (void)setInformativeText:(NSString *)informativeText
{
	if((informativeText != nil)&&(labelMessage != nil))
	{
		[labelMessage setTitleWithMnemonic:informativeText];
		//add for refresh display 2011-02-22
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		[labelMessage display];
		[pool release];
	}
}

// customize the buttons in the alert panel
// buttons are added from right to left (for left to right languages)
- (NSButton *)addButtonWithTitle:(NSString *)title
{
	NSInteger intRet ;
	
	if(nil==title)
		return nil;
	
	if([button1 isHidden] == YES)
	{
		[button1 setHidden:NO];
		[button1 setTitle:title];
	}
	else if([button2 isHidden] == YES)
	{
		[button2 setHidden:NO];
		[button2 setTitle:title];
	}
	else if([button3 isHidden] == YES)
	{
		[button3 setHidden:NO];
		[button3 setTitle:title];
	}
	if([button1 isHidden] == NO)
	{
		//	[button1 highlight:YES] ;
		[win becomeKeyWindow];
		intRet = [button1 state] ;
		[button1 setState:NSOnState] ;
		[button1 becomeFirstResponder];
	}
	//add for refresh display 2011-02-22
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	if([button1 isHidden] == NO)
		[button1 display];
	if([button2 isHidden] == NO)
		[button2 display];
	if([button3 isHidden] == NO)
		[button3 display];
	[pool release];
	
	return nil ;
}

// get the buttons, where the rightmost button is at index 0
- (NSArray *)buttons
{
	NSMutableArray *btnArray = [[[NSMutableArray alloc] init] autorelease];
	if([button1 isHidden] == NO)
		[btnArray addObject:button1] ;
	if([button2 isHidden] == NO)
		[btnArray addObject:button2] ;
	if([button3 isHidden] == NO)
		[btnArray addObject:button3] ;
	return btnArray; 
}

// Run the alert as an application-modal panel and return the result
- (NSInteger)runModal
{
	//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
	NSInteger waitTime = [UICommon getMessageBoxWaitTime];
	NSDate *dateTmp = [[[NSDate alloc] init] autorelease];
	NSInteger timeInterval = -[dateTmp timeIntervalSinceNow];
	if(waitTime > 0 )
	{
		while (timeInterval < waitTime) 
		{
			timeInterval = -[dateTmp timeIntervalSinceNow];
			[button1 setEnabled:NO];
			[button2 setEnabled:NO];
			[button3 setEnabled:NO];
		}
		[button1 setEnabled:YES];
		[button2 setEnabled:YES];
		[button3 setEnabled:YES];		
	}
	//SCRID:101 end.	
	while (!bntReturnValue) 
	{
		usleep(10000); //10ms
	}
	[win performClose:self];
	return bntReturnValue ;
}
- (NSInteger)runModalV2:(NSDictionary*)dictKeyDefined
{
    [labelTime setHidden:NO];
    
    NSLog(@"runModalV2");
    NSString *mTestItemName=nil;
    NSString *mWaitTime=nil;
    NSString *mWriteCmd=nil;
    NSString *mStrSpec=nil;
    NSString *mTitle=nil;
    NSString *mBufferName=nil;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WaitTime"])
		{
			mWaitTime = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Title"])
		{
			mTitle = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
    }
    if([mTestItemName isEqualToString:@"Disconnect the kong cable"])
    {
        int i=0;
        int delay = [mWaitTime intValue];
        BOOL flag=FALSE;
        //SCRID:101 end.
        while (i!=delay)
        {
            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
            i++;
            [TestItemParse SendData:dictKeyDefined :@"\n" :@":-)"];
            usleep(100000);//100ms;
            NSString *result = [TestItemParse ReceData:dictKeyDefined];
            if([result rangeOfString:@":-)"].length <= 0)
            {
                [win performClose:self];
                return 1;
            }
            
            usleep(1000000); //1s
        }
        if(flag == FALSE)
        {
            [labelTime setStringValue:@"Time out"];
            [win performClose:self];
            return 0;
        }
    }
    else if([mTestItemName isEqualToString:@"Connect the kong cable"])
    {
        int i=0;
        int delay = [mWaitTime intValue];
        BOOL flag=FALSE;
        //SCRID:101 end.
        while (i!=delay)
        {
            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
            i++;
            [TestItemParse SendData:dictKeyDefined :@"\n" :@":-)"];
            usleep(100000);//100ms;
            NSString *result = [TestItemParse ReceData:dictKeyDefined];
            if([result rangeOfString:@":-)"].length > 0)
            {
                [win performClose:self];
                return 1;
            }
            usleep(1000000); //1s
        }
        if(flag == FALSE)
        {
            [labelTime setStringValue:@"Time out"];
            [win performClose:self];
            return 0;
        }
    }
    //    else if([mTitle isEqualToString:@"Please plug in the kong cable!"])
    //    {
    //        int i=0;
    //        int delay = [mWaitTime intValue];
    //        BOOL flag=FALSE;
    //        //SCRID:101 end.
    //        while (i!=delay)
    //        {
    //            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
    //            i++;
    //            [TestItemParse SendData:dictKeyDefined :@"\n" :@":-)"];
    //            usleep(100000);//100ms;
    //            NSString *result = [TestItemParse ReceData:dictKeyDefined];
    //            if([result rangeOfString:@":-)"].length > 0)
    //            {
    //                [win performClose:self];
    //                return 1;
    //            }
    //            usleep(1000000); //1s
    //        }
    //        if(flag == FALSE)
    //        {
    //            [labelTime setStringValue:@"Time out"];
    //            [win performClose:self];
    //            return 0;
    //        }
    //    }
    
    else if([mTitle isEqualToString:@"Please plug in the kong cable!"])
    {
        NSString* strDevice=nil;
        if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"]) {
            strDevice= @"IPad11";
        }
        else
        {
            strDevice= @"IPad12";
        };
        
        int i=0;
        int delay = [mWaitTime intValue];
        //BOOL flag=FALSE;
        //SCRID:101 end.
        
        while (i < delay)
        {
            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
            if ([TestItemParse CheckUnitExist:strDevice:@"1"]) {
                [win performClose:self];
                return 1;
            }
            else
            {
                
                [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
                i++;
                usleep(1000000);
            }
        }
        
        if(i >= delay)
        {
            [labelTime setStringValue:@"Time out"];
            [win performClose:self];
            return 0;
        }
    }
    
    mWriteCmd = [mWriteCmd stringByAppendingString:@"\n"];
    if(mWaitTime != nil)
    {
        int i=0;
        int delay = [mWaitTime intValue];
        
        //SCRID:101 end.
        
        NSString *result = @"";
        NSString *resultTmp = nil;
        while (i!=delay)
        {
            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
            i++;
            resultTmp = [TestItemParse ReceData:dictKeyDefined];
            if(resultTmp != nil)
                result =[result stringByAppendingString:resultTmp];
            [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"];
            usleep(500000);//500ms;
             resultTmp = [TestItemParse ReceData:dictKeyDefined];
            if(resultTmp != nil)
                result =[result stringByAppendingString:resultTmp];
            if([result rangeOfString:mStrSpec].length > 0)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :result];
                return 1;
            }
            usleep(500000); //500ms;
        }
        [labelTime setStringValue:@"Time out"];
        [win performClose:self];
        return 0;
    }
    [self addButtonWithTitle:@"是"];
    [button2 setEnabled:YES];
    
    if([mTitle isEqualToString:@"Please put the magnet on the hall sensor!"])
    {
        
        while (!bntReturnValue)
        {
            [labelTime setHidden:YES];
            // usleep(1000000);//1s;
            [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"];
            while (!bntReturnValue)
			{
                if ([TestItemParse CheckReceDataIsComplete:dictKeyDefined])
					break ;
				else
				{
					usleep(100000) ; //delay 100ms
				}
				
			}
            NSString *result = [TestItemParse ReceData:dictKeyDefined];
            //  result = [TestItemParse ReceData:dictKeyDefined];
            //  result = @"measuring irq index #0 (pmu gpio 11)\n0: detect intr (pin = 0x0) ";
            if([result rangeOfString:mStrSpec].length > 0)
            {
                [win performClose:self];
                return 1;
                
            }
            //  usleep(500000); //0.5s
        }
        
        [win performClose:self];
        return 0;
    }
    
    
    while (!bntReturnValue)
    {
        [labelTime setHidden:YES];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"];
        //usleep(1000000);//1s;
        
        while (!bntReturnValue)
        {
            if ([TestItemParse CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        NSString *result = [TestItemParse ReceData:dictKeyDefined];
        // result = [TestItemParse ReceData:dictKeyDefined];
        // result = @" mikey --detectheadphone\n\nHeadphone detected!";
        if([result rangeOfString:mStrSpec].length > 0)
        {
            [win performClose:self];
            return 1; 
        }
        //usleep(1000000); //1s
    } 
    [win performClose:self];
    return 0; 
}
//add by kevin at 2014.10.31 for RX CG-Button
- (NSInteger)runModalV3:(NSDictionary*)dictKeyDefined
{
    [labelTime setHidden:NO];
    
    NSLog(@"runModalV3");
    NSString *mTestItemName=nil;
    NSString *mWaitTime=nil;
    NSString *mWriteCmd=nil;
    NSString *mStrSpec=nil;
    NSString *mTitle=nil;
    NSString *mBufferName=nil;
    NSString *mDevice=nil;
    NSString *mIsPressButtonPass=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WaitTime"])
		{
			mWaitTime = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Title"])
		{
			mTitle = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"IsPressButtonPass"])
		{
			mIsPressButtonPass = [dictKeyDefined objectForKey:strKey] ;
		}
        
        
    }
    
    if ([mIsPressButtonPass isEqualToString:@"Yes"])
    {
        int i=0;
        int delay = [mWaitTime intValue];
        BOOL flag=false;
        NSString *resultTmp = nil;
        
        while (i!=delay)
        {
            [labelTime setStringValue:[NSString stringWithFormat:@"%d",delay-i]];
            i++;
            NSLog(@"io++ %d",i);
            
            usleep(1000000);
            if(i==1)
            {
                resultTmp = [TestItemParse ReceData:dictKeyDefined];
                NSLog(@"resultTmp(i==1) = %@",resultTmp);
            }
            else
            {
                NSString *newResult=[TestItemParse ReceData:dictKeyDefined];
                NSLog(@"newResult = %@",newResult);
                if(newResult != nil)
                {
                    if (resultTmp == nil) {
                        resultTmp = @"1";
                    }
                    resultTmp = [resultTmp stringByAppendingString:newResult];
                    NSLog(@"resultTmp(i!=1) = %@",resultTmp);
                }
            }
            if([resultTmp rangeOfString:mStrSpec].length > 0 || [resultTmp rangeOfString:@"Pass"].length > 0 || [resultTmp rangeOfString:@"pass"].length > 0 || [resultTmp rangeOfString:@"PASS"].length > 0)
            {
                NSLog(@"resultTmp(result==pass) = %@",resultTmp);
                NSLog(@"mStrSpec = %@",mStrSpec);
                [win performClose:self];
                return 1;
            }else if([resultTmp rangeOfString:mStrSpec].length > 0 || [resultTmp rangeOfString:@"fail"].length > 0 || [resultTmp rangeOfString:@"Fail"].length > 0 || [resultTmp rangeOfString:@"FAIL"].length > 0)
            {
                NSLog(@"resultTmp(result==fail) = %@",resultTmp);
                [win performClose:self];
                return -1;
            }
            else   //no result send to test software
            {
                if(i==delay)
                {
                    [win performClose:self];
                    return 0;
                }
            }
        }
        if(flag == false)
        {
            [labelTime setStringValue:@"Time out"];
            [win performClose:self];
            return 0;
        }
    }
    
    
    [win performClose:self];
    return 0; 
}
//add by kevin at 2014.10.31 for RX CG-Button
-(IBAction)button1_Click:(id)sender 
{
	bntReturnValue = NSAlertFirstButtonReturn;
	btnPressedFlag = YES ;
}
-(IBAction)button2_Click:(id)sender 
{
	bntReturnValue = NSAlertSecondButtonReturn;
	btnPressedFlag = YES ;
}
-(IBAction)button3_Click:(id)sender 
{
	bntReturnValue = NSAlertThirdButtonReturn;
	btnPressedFlag = YES ;
}
-(void)updatPosition:(NSInteger)totalMessageBox index:(NSInteger)indexOfMessage 
{
	NSScreen *screen = [NSScreen mainScreen];
	NSRect rec = [screen frame] ;
	NSRect alertRec =  NSMakeRect(0, 0, 421, 136) ;
	NSPoint orignPoint ;
	
	//modified by henry 2011-01-24 for new prox cal
	if((totalMessageBox > 9)||(totalMessageBox < 1)||(indexOfMessage > 9)||(indexOfMessage < 1))
	{
		NSAlert * alert = [NSAlert alertWithMessageText:@""
										  defaultButton:@"OK" 
										alternateButton:nil 
											otherButton:nil 
							  informativeTextWithFormat:[NSString stringWithFormat:@"Script UI alert occur error !\n"]];
		
		[alert runModal];
	}
	
	if(totalMessageBox == 9)
	{
		orignPoint = NSMakePoint(((rec.size.width/6)*(2*((indexOfMessage-1)%3+1)-1) -alertRec.size.width/2), ((rec.size.height/6)*(2*(3-(indexOfMessage-1)/3)-1) -alertRec.size.height/2)) ;
	}
	else if(totalMessageBox == 4)
	{
		orignPoint = NSMakePoint(((rec.size.width/4)*(2*((indexOfMessage-1)%2+1)-1) -alertRec.size.width/2), ((rec.size.height/4)*(2*(2-(indexOfMessage-1)/2)-1) -alertRec.size.height/2)) ;
	}
	else if(totalMessageBox == 3)//20110214 Henry add for ProxCal
	{
		switch (indexOfMessage) 
		{
			case 1:
				orignPoint = NSMakePoint((rec.size.width/6 -alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 2:
				orignPoint = NSMakePoint((3*(rec.size.width/6)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 3:
				orignPoint = NSMakePoint((5*(rec.size.width/6)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			default:
				orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
		}
	}
	else if(totalMessageBox == 2) //20101127 Henry add for iPad-1
	{
		switch (indexOfMessage) 
		{
			case 1:
				orignPoint = NSMakePoint((rec.size.width/4 -alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 2:
				orignPoint = NSMakePoint((3*(rec.size.width/4)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			default:
				orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
		}
	}
	else
	{
		orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
	}
	
	NSLog(@"indexOfMessage= %d ,orignPoint.x=%f orignPoint.y=%f ",indexOfMessage,orignPoint.x,orignPoint.y);
	if(orignPoint.x != 0)
		[win setFrameOrigin:orignPoint] ;
}

//set position of the alert box
+(void)setInitPosition:(NSInteger)totalMessageBox index:(NSInteger)indexOfMessage 
{
	NSScreen *screen = [NSScreen mainScreen];
	NSRect rec = [screen frame] ;
	NSRect alertRec =  NSMakeRect(0, 0, 421, 136) ;
	NSPoint orignPoint ;
	
	//modified by henry 2011-01-24 for new prox cal
	if((totalMessageBox > 9)||(totalMessageBox < 1)||(indexOfMessage > 9)||(indexOfMessage < 1))
	{
		NSAlert * alert = [NSAlert alertWithMessageText:@""
										  defaultButton:@"OK" 
										alternateButton:nil 
											otherButton:nil 
							  informativeTextWithFormat:[NSString stringWithFormat:@"Script UI alert occur error !\n"]];
		
		[alert runModal];
	}
	
	if(totalMessageBox == 9)
	{
		orignPoint = NSMakePoint(((rec.size.width/6)*(2*((indexOfMessage-1)%3+1)-1) -alertRec.size.width/2), ((rec.size.height/6)*(2*(3-(indexOfMessage-1)/3)-1) -alertRec.size.height/2)) ;
	}
	else if(totalMessageBox == 4)
	{
		orignPoint = NSMakePoint(((rec.size.width/4)*(2*((indexOfMessage-1)%2+1)-1) -alertRec.size.width/2), ((rec.size.height/4)*(2*(2-(indexOfMessage-1)/2)-1) -alertRec.size.height/2)) ;
	}
	else if(totalMessageBox == 3)//20110214 Henry add for ProxCal
	{
		switch (indexOfMessage) 
		{
			case 1:
				orignPoint = NSMakePoint((rec.size.width/6 -alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 2:
				orignPoint = NSMakePoint((3*(rec.size.width/6)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 3:
				orignPoint = NSMakePoint((5*(rec.size.width/6)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			default:
				orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
		}
	}
	else if(totalMessageBox == 2)//20101127 Henry add for iPad-1
	{
		switch (indexOfMessage) 
		{
			case 1:
				orignPoint = NSMakePoint((rec.size.width/4 -alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			case 2:
				orignPoint = NSMakePoint((3*(rec.size.width/4)-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
			default:
				orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
				break;
		}
	}
	else
	{
		orignPoint = NSMakePoint((rec.size.width/2-alertRec.size.width/2), (rec.size.height/2 -alertRec.size.height/2)) ;
	}
	initPosition = orignPoint ;
}

+(NSPoint)getInitPosition
{
	return initPosition ;
}
/***********************************************************
 **SCRID:50  delete [1] when only show one UI **
 ***********************************************************/
-(void)setWindowTitle:(NSString*)title 
{
	if(title == nil)
		return;
	[win setTitle:title];
}
/** SCRID:50 end**/

@end
