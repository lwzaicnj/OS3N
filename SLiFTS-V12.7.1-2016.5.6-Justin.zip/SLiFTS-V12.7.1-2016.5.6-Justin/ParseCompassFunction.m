//
//  ParseCompassFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseCompassFunction.h"


@implementation TestItemParse(ParseCompassFunction)

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 1               
 | CREATED: 2010.03.26                  $Modtime::  2010.03.27.16:40     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Special Parser Method
 
 PURPOSE :Get compass related datas and analysis them to estimate it pass or fail.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.03.27   Time: 16:40
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

/*SCRID-117: add Parser ParseDOECompas.joko 2011-07-22*/
+(void)ParseDOECompass:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mTestItemName			= nil	;
	NSString *mReferenceBufferName	= nil	;
	NSString *mBufferXAverageValue			= nil	;
	NSString *mBufferYAverageValue			= nil	;
	NSString *mBufferZAverageValue			= nil	;
	NSString *mLoop			= nil	;
	NSString *mBufferCompassInit	= nil	;
	NSString *mIsNorthOn	= nil	;
	NSString *mIsSouthOn	= nil	;
	NSString *mCompassTestType		= nil	;
	
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferXAverageValue"])
		{
			mBufferXAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferYAverageValue"])
		{
			mBufferYAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferZAverageValue"])
		{
			mBufferZAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferCompassInit"])
		{
			mBufferCompassInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"IsNorthOn"])
		{
			mIsNorthOn = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"IsSouthOn"])
		{
			mIsSouthOn = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"CompassTestType"])
		{
			mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	NSString *mBufferCompassInitValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferCompassInit] ;
	mBufferCompassInitValue=[ToolFun getStrFromPrefixAndPostfix:mBufferCompassInitValue Prefix:@"Sensitivity" Postfix:@"("];
	if (mBufferCompassInitValue==nil || [mBufferCompassInitValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@"\""withString:@""];
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferCompassInitValue	= [mBufferCompassInitValue stringByReplacingOccurrencesOfString:@"="withString:@""];
	NSMutableArray *arryInitValue = (NSMutableArray*)[mBufferCompassInitValue componentsSeparatedByString:@","];
	if([arryInitValue count] < 3)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	float initX = [[arryInitValue objectAtIndex:0] floatValue];
	float initY = [[arryInitValue objectAtIndex:1] floatValue];
	float initZ = [[arryInitValue objectAtIndex:2] floatValue];
	float Adj_x,Adj_y,Adj_z;
	Adj_x=(float)((initX-128)*0.5)/128 +1;
	Adj_y=(float)((initY-128)*0.5)/128 +1;
	Adj_z=(float)((initZ-128)*0.5)/128 +1;
	
	NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	mReferenceBufferNameValue=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferNameValue Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mReferenceBufferNameValue==nil || [mReferenceBufferNameValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	//NSMutableArray *temp = (NSMutableArray*)[mReferenceBufferNameValue componentsSeparatedByString:@","];
	NSMutableArray *temp = (NSMutableArray*)[mReferenceBufferNameValue componentsSeparatedByString:@" "];
	
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	
	float averageXValue = totalXValue / [mLoop intValue];
	float averageYValue = totalYValue / [mLoop intValue];
	float averageZValue = totalZValue / [mLoop intValue];
	
	if([mCompassTestType isEqualToString:@"south field"])//([mIsSouthOn boolValue])
	{
		[TestItemManage setBufferValue:DictionaryPtr :@"SouthXValue" :[NSString stringWithFormat:@"%f",averageXValue]];
		[TestItemManage setBufferValue:DictionaryPtr :@"SouthYValue" :[NSString stringWithFormat:@"%f",averageYValue]];
		[TestItemManage setBufferValue:DictionaryPtr :@"SouthZValue" :[NSString stringWithFormat:@"%f",averageZValue]];
	}
	if([mCompassTestType isEqualToString:@"north field"])//([mIsNorthOn boolValue])
	{
		float southXValue = [[TestItemManage getBufferValue:DictionaryPtr :@"SouthXValue"] floatValue];
		float southYValue = [[TestItemManage getBufferValue:DictionaryPtr :@"SouthYValue"] floatValue];
		float southZValue = [[TestItemManage getBufferValue:DictionaryPtr :@"SouthZValue"] floatValue];
		//North - South
		float northMinusSouthX = (averageXValue - southXValue) * Adj_x * 0.3 * 10;
		float northMinusSouthY = (averageYValue - southYValue) * Adj_y * 0.3 * 10;
		float northMinusSouthZ = (averageZValue - southZValue) * Adj_z * 0.3 * 10;
		
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X (mG)":nil:nil:nil:[NSString stringWithFormat:@"%f",northMinusSouthX]:@"mG":IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y (mG)":nil:nil:nil:[NSString stringWithFormat:@"%f",northMinusSouthY]:@"mG":IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z (mG)":nil:nil:nil:[NSString stringWithFormat:@"%f",northMinusSouthZ]:@"mG":IP_NA:nil];
	}
	
	averageXValue = averageXValue * Adj_x * 0.3 * 10;
	averageYValue = averageYValue * Adj_y * 0.3 * 10;
	averageZValue = averageZValue * Adj_z * 0.3 * 10;
	
	NSString *strAverageXValue = [NSString stringWithFormat:@"%f",averageXValue];
	NSString *strAverageYValue = [NSString stringWithFormat:@"%f",averageYValue];
	NSString *strAverageZValue = [NSString stringWithFormat:@"%f",averageZValue];
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:[mCompassTestType stringByAppendingString:@" X (mG)"]:nil:nil:nil:strAverageXValue:@"mG":IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:[mCompassTestType stringByAppendingString:@" Y (mG)"]:nil:nil:nil:strAverageYValue:@"mG":IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:[mCompassTestType stringByAppendingString:@" Z (mG)"]:nil:nil:nil:strAverageZValue:@"mG":IP_NA:nil];
	
	NSString *testResult = @"X(mG):";
	testResult = [testResult stringByAppendingString:strAverageXValue];
	testResult = [testResult stringByAppendingString:@"; Y(mG):"];
	testResult = [testResult stringByAppendingString:strAverageYValue];
	testResult = [testResult stringByAppendingString:@"; Z(mG):"];
	testResult = [testResult stringByAppendingString:strAverageZValue];
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :testResult] ;
	return  ;
}
/*SCRID-117:end*/

+(void)ParseCompassV2:(NSDictionary*) DictionaryPtr
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	NSString *mTestItemName			= nil	;
	NSString *mUpLimit				= nil	;
	NSString *mLowLimit				= nil	;
	NSString *mBufferInit			= nil	;
	NSString *mBufferRaw			= nil	;
	NSString *mBufferNorth			= nil	;
	NSString *mBufferSouth			= nil	;
	NSString *mCompassTestType		= nil	;
	NSString *mLoop			= nil	;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferRaw"])
		{
			mBufferRaw = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNorth"])
		{
			mBufferNorth = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferSouth"])
		{
			mBufferSouth = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"CompassTestType"])
		{
			mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mBufferInit==nil||mBufferRaw==nil||mBufferNorth==nil||mBufferSouth==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	// declare int variable to store Uplimit and Lowlimit
	float x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit;
	float x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit;
	NSArray *Uplimit	= nil;
	NSArray *Lowlimit	= nil;
	
	// get Upper limit
	Uplimit = [ mUpLimit componentsSeparatedByString:@","];
	if ([Uplimit count]!=3)
	{
		
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
		
	}
	x_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 0 ] doubleValue ];
	y_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 1 ] doubleValue ];
	z_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 2 ] doubleValue ];
	
	// get Lower limit
	Lowlimit = [ mLowLimit componentsSeparatedByString:@","];
	if ([Lowlimit count]!=3)
	{
		
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
		
	}
	x_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 0 ] doubleValue ];
	y_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 1 ] doubleValue ];
	z_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 2 ] doubleValue ];
	
	
    //NSString* mBufferNorthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0x31, Y: 0xAC, Z: 0x30";
    //	 NSString* mBufferSouthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0xC9, Y: 0x52, Z: 0xDC";
    //	 NSString* mBufferRawValue   =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x77, X: 0x77, Y: 0x81, Z: 0x82";
    //	 NSString* mBufferInitValue  =@"Initial DAC offsets : (+0, +0, +0)Final DAC offsets : (+132, +133, +1) (0:0x1E) - DacX: 0x84, DacY: 0x85, DacZ:0x01";
	 
	NSString *mBufferInitValue	= nil;
	NSString *mBufferRawValue	= nil;
	NSString *mBufferNorthValue	= nil;
	NSString *mBufferSouthValue	= nil;
	
	
	mBufferInitValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ;
	mBufferRawValue		= [TestItemManage getBufferValue:DictionaryPtr :mBufferRaw] ;
	mBufferNorthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferNorth] ;
	mBufferSouthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferSouth] ;
	
	if (mBufferInitValue==nil||mBufferRawValue==nil||mBufferNorthValue==nil||mBufferSouthValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\""withString:@""];
	//mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	
	//mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	
	//mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\r"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\n"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\t"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@":-)"withString:@" "];
	
	//mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	
	
	// Get Data from responding buffer value
	NSRange	range;
	range =[mBufferRawValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferRawValue = [ mBufferRawValue substringFromIndex:(NSUInteger)range.location ];
	
	range =[mBufferNorthValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferNorthValue = [ mBufferNorthValue substringFromIndex:(NSUInteger)range.location ];
	
	range =[mBufferSouthValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferSouthValue = [ mBufferSouthValue substringFromIndex:(NSUInteger)range.location ];
	
	
	
	range = [mBufferInitValue rangeOfString:@"Sensitivity"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferInitValue =[ mBufferInitValue substringFromIndex:(range.location+12) ];
	
	range =[mBufferInitValue rangeOfString:@"("];
	if (range.length<=0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	
	mBufferInitValue = [mBufferInitValue substringToIndex:range.location];
	
	//split data to Array
	
	NSArray *initdata	= nil;
	NSArray *rawdata	= nil;
	NSArray *northData	= nil;
	NSArray *southData	= nil;
	
	initdata	= [mBufferInitValue  componentsSeparatedByString:@","];
	rawdata		= [mBufferRawValue   componentsSeparatedByString:@","];
	northData	= [mBufferNorthValue componentsSeparatedByString:@","];
	southData	= [mBufferSouthValue componentsSeparatedByString:@","];
	
	// set subtest items info to PDCA
	NSString *strTestValue = nil;
	if([mCompassTestType isEqualToString:@"pureCompass"])
	{
		strTestValue =[initdata objectAtIndex:(NSUInteger)0];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Sensitivity":@"X":nil:nil:strTestValue:nil:IP_NA:nil];
		strTestValue =[initdata objectAtIndex:(NSUInteger)1];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Sensitivity":@"Y":nil:nil:strTestValue:nil:IP_NA:nil];
		strTestValue =[initdata objectAtIndex:(NSUInteger)2];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Sensitivity":@"Z":nil:nil:strTestValue:nil:IP_NA:nil];
		
		strTestValue = [northData objectAtIndex:(NSUInteger)4];
		strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"Z+" withString:@""];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"North":@"Temp":nil:nil:strTestValue:nil:IP_NA:nil];
		
		strTestValue = [southData objectAtIndex:(NSUInteger)4];
		strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"Z+" withString:@""];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"South":@"Temp":nil:nil:strTestValue:nil:IP_NA:nil];
		
		mCompassTestType = nil;
	}
	
	mBufferRawValue		= [TestItemManage getBufferValue:DictionaryPtr :mBufferRaw] ;
	mBufferNorthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferNorth] ;
	mBufferSouthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferSouth] ;
	
	mBufferRawValue=[ToolFun getStrFromPrefixAndPostfix:mBufferRawValue Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferRawValue==nil || [mBufferRawValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferNorthValue=[ToolFun getStrFromPrefixAndPostfix:mBufferNorthValue Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferNorthValue==nil || [mBufferNorthValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferSouthValue=[ToolFun getStrFromPrefixAndPostfix:mBufferSouthValue Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferSouthValue==nil || [mBufferSouthValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	
	NSMutableArray *temp = (NSMutableArray*)[mBufferRawValue componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageRawXValue = totalXValue / [mLoop intValue];
	float averageRawYValue = totalYValue / [mLoop intValue];
	float averageRawZValue = totalZValue / [mLoop intValue];
	
	
	temp = (NSMutableArray*)[mBufferNorthValue componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageNorthXValue = totalXValue / [mLoop intValue];
	float averageNorthYValue = totalYValue / [mLoop intValue];
	float averageNorthZValue = totalZValue / [mLoop intValue];
	
	
	temp = (NSMutableArray*)[mBufferSouthValue componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageSouthXValue = totalXValue / [mLoop intValue];
	float averageSouthYValue = totalYValue / [mLoop intValue];
	float averageSouthZValue = totalZValue / [mLoop intValue];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageRawXValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Initial Offset X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageRawYValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Initial Offset Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageRawZValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Initial Offset Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageNorthXValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"North X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageNorthYValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"North Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageNorthZValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"North Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	
	strTestValue = [NSString stringWithFormat:@"%f",averageSouthXValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"South X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageSouthYValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"South Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [NSString stringWithFormat:@"%f",averageSouthZValue];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"South Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	
	BOOL flag =YES;
	float x_InitData,y_InitData,z_InitData;
	x_InitData=[[initdata objectAtIndex:(NSUInteger)0] intValue];
	y_InitData=[[initdata objectAtIndex:(NSUInteger)1] intValue];
	z_InitData=[[initdata objectAtIndex:(NSUInteger)2] intValue];
	
	float H_Adj_x,H_Adj_y,H_Adj_z;
	H_Adj_x=(float)((x_InitData-128)*0.5)/128 +1;
	H_Adj_y=(float)((y_InitData-128)*0.5)/128 +1;
	H_Adj_z=(float)((z_InitData-128)*0.5)/128 +1;
	
	float xrange = (averageNorthXValue - averageSouthXValue) * H_Adj_x;
	float yrange = (averageNorthYValue - averageSouthYValue) * H_Adj_y;
	float zrange = (averageNorthZValue - averageSouthZValue) * H_Adj_z;
	
	if (xrange<x_Diff_lowLimit || xrange>x_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%f",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%f",x_Diff_lowLimit]:[NSString stringWithFormat:@"%f",x_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%f",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%f",x_Diff_lowLimit]:[NSString stringWithFormat:@"%f",x_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (yrange<y_Diff_lowLimit || yrange>y_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%f",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%f",y_Diff_lowLimit]:[NSString stringWithFormat:@"%f",y_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%f",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%f",y_Diff_lowLimit]:[NSString stringWithFormat:@"%f",y_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (zrange<z_Diff_lowLimit || zrange>z_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%f",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%f",z_Diff_lowLimit]:[NSString stringWithFormat:@"%f",z_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%f",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%f",z_Diff_lowLimit]:[NSString stringWithFormat:@"%f",z_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (flag)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
	}
	
	strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@", X=%f[%f,%f];Y=%f[%f,%f];Z=%f[%f,%f]",xrange,x_Diff_lowLimit,x_Diff_UpLimit,yrange,y_Diff_lowLimit,y_Diff_UpLimit,zrange,z_Diff_lowLimit,z_Diff_UpLimit];
	
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	
	return ;
	
}

+(void)ParseCompassV3:(NSDictionary*) DictionaryPtr
{
	
    NSString *mBufferInit			= nil	;
	NSString *mBufferRaw			= nil	;
	NSString *mBufferNorth			= nil	;
	NSString *mBufferSouth			= nil	;
	//NSString *mCompassTestType		= nil	;
	NSString *mLoop			= nil	;
    NSString *mLoopStd			= nil	;
    
    NSString *mBufferNameSx=nil;
    NSString *mBufferNameSy=nil;
    NSString *mBufferNameSz=nil;
    
    NSString *mBufferNameRavex=nil;
    NSString *mBufferNameRavey=nil;
    NSString *mBufferNameRavez=nil;
    
    NSString *mBufferNameNavex=nil;
    NSString *mBufferNameNavey=nil;
    NSString *mBufferNameNavez=nil;
    
    NSString *mBufferNameSavex=nil;
    NSString *mBufferNameSavey=nil;
    NSString *mBufferNameSavez=nil;
    
    NSString *mBufferNameStdx=nil;
    NSString *mBufferNameStdy=nil;
    NSString *mBufferNameStdz=nil;
    
    
    NSString *mBufferName1x=nil;
    NSString *mBufferName1y=nil;
    NSString *mBufferName1z=nil;
    NSString *mBufferName1Nx=nil;
    NSString *mBufferName1Ny=nil;
    NSString *mBufferName1Nz=nil;
    NSString *mBufferName1Sx=nil;
    NSString *mBufferName1Sy=nil;
    NSString *mBufferName1Sz=nil;
    
    NSString *mBufferName1NM=nil;
    NSString *mBufferName1SM=nil;
    
    NSString *mBufferNameNMSX=nil;
    NSString *mBufferNameNMSY=nil;
    NSString *mBufferNameNMSZ=nil;
    NSString *mBufferNameNMSM0=nil;
    NSString *mBufferNameNMSM=nil;
    NSString *mBufferNameNMSM1=nil;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"LoopStd"])
		{
			mLoopStd = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferRaw"])
		{
			mBufferRaw = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNorth"])
		{
			mBufferNorth = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferSouth"])
		{
			mBufferSouth = [DictionaryPtr objectForKey:strKey] ;
		}
		//else if ([strKey isEqualToString:@"CompassTestType"])
		//{
		//	mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		//}
        else if ([strKey isEqualToString:@"BufferNameSx"])
		{
			mBufferNameSx = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSy"])
		{
			mBufferNameSy = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSz"])
		{
			mBufferNameSz = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRavex"])
		{
			mBufferNameRavex = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRavey"])
		{
			mBufferNameRavey = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRavez"])
		{
			mBufferNameRavez = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNavex"])
		{
			mBufferNameNavex = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNavey"])
		{
			mBufferNameNavey = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNavez"])
		{
			mBufferNameNavez = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSavex"])
		{
			mBufferNameSavex = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSavey"])
		{
			mBufferNameSavey = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSavez"])
		{
			mBufferNameSavez = [DictionaryPtr objectForKey:strKey] ;
		}
        
        
        else if ([strKey isEqualToString:@"BufferName1x"])
		{
			mBufferName1x = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1y"])
		{
			mBufferName1y = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1z"])
		{
			mBufferName1z = [DictionaryPtr objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"BufferName1Nx"])
		{
			mBufferName1Nx = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1Ny"])
		{
			mBufferName1Ny = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1Nz"])
		{
			mBufferName1Nz = [DictionaryPtr objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"BufferName1Sx"])
		{
			mBufferName1Sx = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1Sy"])
		{
			mBufferName1Sy = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1Sz"])
		{
			mBufferName1Sz = [DictionaryPtr objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"BufferName1NM"])
		{
			mBufferName1NM = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName1SM"])
		{
			mBufferName1SM = [DictionaryPtr objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"BufferNameNMSX"])
		{
			mBufferNameNMSX = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNMSY"])
		{
			mBufferNameNMSY = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNMSZ"])
		{
			mBufferNameNMSZ = [DictionaryPtr objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferNameNMSM0"])
		{
			mBufferNameNMSM0 = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNMSM"])
		{
			mBufferNameNMSM = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNMSM1"])
		{
			mBufferNameNMSM1 = [DictionaryPtr objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferNameStdX"])
		{
			mBufferNameStdx = [DictionaryPtr objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferNameStdY"])
		{
			mBufferNameStdy = [DictionaryPtr objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferNameStdZ"])
		{
			mBufferNameStdz = [DictionaryPtr objectForKey:strKey] ;
        }
		
	}
	
	if (mBufferRaw==nil||mBufferNorth==nil||mBufferSouth==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
    
    //delete by Annie for new request by AA Chia Fang, 2014.3.14
	/*
    
	NSString *mBufferInitValue	= nil;
	
	mBufferInitValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ; 
    
    
	NSLog(@"hhhhh mBufferInitValue=%@",mBufferInitValue);
	if (mBufferInitValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data -mBufferInitValue"] ;
		return ;
	}
	
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	NSLog(@"hhhhh mBufferInitValue2=%@",mBufferInitValue);
    
    NSString *strSensitivityX=[ToolFun getStrFromPrefixAndPostfix:mBufferInitValue Prefix:@"0x10=" Postfix:@"0x11"];
    NSString *strSensitivityY=[ToolFun getStrFromPrefixAndPostfix:mBufferInitValue Prefix:@"0x11=" Postfix:@"0x12"];
    NSString *strSensitivityZ=[ToolFun getStrFromPrefixAndPostfix:mBufferInitValue Prefix:@"0x12=" Postfix:@"OK"];
	
	NSLog(@"hhhhh strSensitivityX=%@",strSensitivityX);
	NSLog(@"hhhhh strSensitivityY=%@",strSensitivityY);
	NSLog(@"hhhhh strSensitivityZ=%@",strSensitivityZ);
    
    if(strSensitivityX == nil || strSensitivityY == nil || strSensitivityZ == nil)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"can not get sensitivity value"] ;
		return ;
    }
    float floatSensitivityX = (int)strtol([strSensitivityX UTF8String], NULL, 16);
    float floatSensitivityY = (int)strtol([strSensitivityY UTF8String], NULL, 16);
    float floatSensitivityZ = (int)strtol([strSensitivityZ UTF8String], NULL, 16);
	
	NSLog(@"hhhhh floatSensitivityX=%f",floatSensitivityX);
	NSLog(@"hhhhh floatSensitivityY=%f",floatSensitivityY);
	NSLog(@"hhhhh floatSensitivityZ=%f",floatSensitivityZ);
    
	
	//NSString *strTestValue = nil;
    
	
    if (mBufferNameSx!=nil)
    {
        
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSx :[NSString stringWithFormat:@"%f",floatSensitivityX]] ;
    }
    
    if (mBufferNameSy!=nil)
    {
        
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSy :[NSString stringWithFormat:@"%f",floatSensitivityY]] ;
    }
    
    if (mBufferNameSz!=nil)
    {
        
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSz :[NSString stringWithFormat:@"%f",floatSensitivityZ]] ;
    }
	*/
    
    
	NSString *mBufferRawValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferRaw] ;
	NSString *mBufferSouthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferSouth] ;
    NSString *mBufferNorthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferNorth] ;
    mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\r"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\n"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\t"withString:@" "];
	
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
    
	
	mBufferRawValue=[ToolFun getStrFromPrefixAndPostfix:mBufferRawValue Prefix:@"compass:" Postfix:@"OK"];
	if (mBufferRawValue==nil || [mBufferRawValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferNorthValue=[ToolFun getStrFromPrefixAndPostfix:mBufferNorthValue Prefix:@"compass:" Postfix:@"OK"];
	if (mBufferNorthValue==nil || [mBufferNorthValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferSouthValue=[ToolFun getStrFromPrefixAndPostfix:mBufferSouthValue Prefix:@"compass:" Postfix:@"OK"];
	if (mBufferSouthValue==nil || [mBufferSouthValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	
	NSMutableArray *temp = (NSMutableArray*)[mBufferRawValue componentsSeparatedByString:@"="];
	
	if([temp count] != ([mLoopStd intValue] + 3))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
    
//    double field_x = 0;
//    double field_y = 0;
//    double field_z = 0;
//    
//    double totalfield_x = 0;
//    double totalfield_y = 0;
//    double totalfield_z = 0;
    NSMutableArray *totalXArray = [[NSMutableArray alloc] init];
    NSMutableArray *totalYArray = [[NSMutableArray alloc] init];
    NSMutableArray *totalZArray = [[NSMutableArray alloc] init];
    
	for(int i=3; i<[temp count]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
        
        if([oneTimeValue rangeOfString:@"compass:"].length > 0)
            oneTimeValue = [oneTimeValue substringToIndex:[oneTimeValue rangeOfString:@"compass:"].location];
        
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
        
		if([arrayValue count] != 4)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:0];
        [totalXArray addObject:testValue];
        totalXValue += [testValue floatValue];
//        
//        field_x = (((floatSensitivityX-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_x += field_x;
        
		testValue=[arrayValue objectAtIndex:1];
        [totalYArray addObject:testValue];
		totalYValue += [testValue floatValue];
//        field_y = (((floatSensitivityY-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_y += field_y;
        
		testValue=[arrayValue objectAtIndex:2];
        [totalZArray addObject:testValue];
		totalZValue += [testValue floatValue];
//        field_z = (((floatSensitivityZ-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_z += field_z;
	}
	float averageRawXValue = totalXValue / [mLoopStd intValue];
	float averageRawYValue = totalYValue / [mLoopStd intValue];
	float averageRawZValue = totalZValue / [mLoopStd intValue];
//    float averageRawXValue2 = totalfield_x / [mLoop intValue];
//	float averageRawYValue2 = totalfield_y / [mLoop intValue];
//	float averageRawZValue2 = totalfield_z / [mLoop intValue];
    float totalXDeviationValue=0;
    float totalYDeviationValue=0;
    float totalZDeviationValue=0;
    
    for(int i=0; i<([temp count]-3); i++)
	{
		totalXDeviationValue+=([[totalXArray objectAtIndex:i] floatValue]-averageRawXValue)*([[totalXArray objectAtIndex:i] floatValue]-averageRawXValue);
        totalYDeviationValue+=([[totalYArray objectAtIndex:i] floatValue]-averageRawYValue)*([[totalYArray objectAtIndex:i] floatValue]-averageRawYValue);
        totalZDeviationValue+=([[totalZArray objectAtIndex:i] floatValue]-averageRawZValue)*([[totalZArray objectAtIndex:i] floatValue]-averageRawZValue);
	}
    float standardDivationXValue;
    float standardDivationYValue;
    float standardDivationZValue;
    
    standardDivationXValue = sqrt(totalXDeviationValue/([mLoopStd intValue]-1));//devide by 99 instead 100,so mLoopStd-1
    standardDivationYValue = sqrt(totalYDeviationValue/([mLoopStd intValue]-1));
    standardDivationZValue = sqrt(totalZDeviationValue/([mLoopStd intValue]-1));
    
    if (mBufferNameRavex!=nil)
    {
        NSString *averx = [NSString stringWithFormat:@"%f",averageRawXValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameRavex :averx] ;
    }
    if (mBufferNameRavey!=nil)
    {
        NSString *avery = [NSString stringWithFormat:@"%f",averageRawYValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameRavey :avery] ;
    }
    if (mBufferNameRavez!=nil)
    {
        NSString *averz = [NSString stringWithFormat:@"%f",averageRawZValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameRavez :averz] ;
    }
    if (mBufferNameStdx!=nil)
    {
        NSString *stdx = [NSString stringWithFormat:@"%f",standardDivationXValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameStdx :stdx] ;
    }
    if (mBufferNameStdy!=nil)
    {
        NSString *stdy = [NSString stringWithFormat:@"%f",standardDivationYValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameStdy :stdy] ;
    }
    if (mBufferNameStdz!=nil)
    {
        NSString *stdz = [NSString stringWithFormat:@"%f",standardDivationZValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameStdz :stdz] ;
    }
    
    [totalXArray release];
    [totalYArray release];
    [totalZArray release];
	
	
	temp = (NSMutableArray*)[mBufferNorthValue componentsSeparatedByString:@"="];
	if([temp count] != ([mLoop intValue] + 1))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!!!"] ;
		return;
	}
    
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
    
//    field_x = 0;
//    field_y = 0;
//    field_z = 0;
//    
//    totalfield_x = 0;
//    totalfield_y = 0;
//    totalfield_z = 0;
    
    for(int i=1; i<[temp count]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
        if([oneTimeValue rangeOfString:@"compass:"].length > 0)
            oneTimeValue = [oneTimeValue substringToIndex:[oneTimeValue rangeOfString:@"compass:"].location];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 4)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!!!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:0];
		totalXValue += [testValue floatValue];
//        field_x = (((floatSensitivityX-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_x += field_x;
		
		testValue=[arrayValue objectAtIndex:1];
		totalYValue += [testValue floatValue];
//        field_y = (((floatSensitivityY-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_y += field_y;
        
		
		testValue=[arrayValue objectAtIndex:2];
		totalZValue += [testValue floatValue];
//        field_z = (((floatSensitivityZ-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_z += field_z;
        
	}
	float averageNorthXValue = totalXValue / [mLoop intValue];
	float averageNorthYValue = totalYValue / [mLoop intValue];
	float averageNorthZValue = totalZValue / [mLoop intValue];
//	float averageNorthXValue2 = totalfield_x / [mLoop intValue];
//	float averageNorthYValue2 = totalfield_y / [mLoop intValue];
//	float averageNorthZValue2 = totalfield_z / [mLoop intValue];   
    
	if (mBufferNameNavex!=nil)
    {
        NSString *avenx = [NSString stringWithFormat:@"%f",averageNorthXValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNavex :avenx] ;
    }
    if (mBufferNameNavey!=nil)
    {
        NSString *aveny = [NSString stringWithFormat:@"%f",averageNorthYValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNavey :aveny] ;
    }
    if (mBufferNameNavez!=nil)
    {
        NSString *avenz = [NSString stringWithFormat:@"%f",averageNorthZValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNavez :avenz] ;
    }
    
	
	temp = (NSMutableArray*)[mBufferSouthValue componentsSeparatedByString:@"="];
	if([temp count] != ([mLoop intValue] + 1))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!!!!!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
    
//    field_x = 0;
//    field_y = 0;
//    field_z = 0;
//    totalfield_x = 0;
//    totalfield_y = 0;
//    totalfield_z = 0;
	for(int i=1; i<[temp count]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
        if([oneTimeValue rangeOfString:@"compass:"].length > 0)
            oneTimeValue = [oneTimeValue substringToIndex:[oneTimeValue rangeOfString:@"compass:"].location];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 4)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:0];
		totalXValue += [testValue floatValue];
//        field_x = (((floatSensitivityX-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_x += field_x;
		
		testValue=[arrayValue objectAtIndex:1];
		totalYValue += [testValue floatValue];
//        field_y = (((floatSensitivityY-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_y += field_y;
      		
		testValue=[arrayValue objectAtIndex:2];
		totalZValue += [testValue floatValue];
//        field_z = (((floatSensitivityZ-128)*0.5)/128+1)*0.15*[testValue floatValue];
//        totalfield_z += field_z;
        
	}
	float averageSouthXValue = totalXValue / [mLoop intValue];
	float averageSouthYValue = totalYValue / [mLoop intValue];
	float averageSouthZValue = totalZValue / [mLoop intValue];
//    float averageSouthXValue2 = totalfield_x / [mLoop intValue];
//	float averageSouthYValue2 = totalfield_y / [mLoop intValue];
//	float averageSouthZValue2 = totalfield_z / [mLoop intValue];
    
    if (mBufferNameSavex!=nil)
    {
        NSString *avesx = [NSString stringWithFormat:@"%f",averageSouthXValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSavex :avesx] ;
    }
    if (mBufferNameSavey!=nil)
    {
        NSString *avesy = [NSString stringWithFormat:@"%f",averageSouthYValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSavey :avesy] ;
    }
    if (mBufferNameSavez!=nil)
    {
        NSString *avesz = [NSString stringWithFormat:@"%f",averageSouthZValue];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameSavez :avesz] ;
    }
	
	
//	float xrange = averageRawXValue2;
//	float yrange = averageRawYValue2;
//	float zrange = averageRawZValue2;
    float xrange = averageRawXValue;
	float yrange = averageRawYValue;
	float zrange = averageRawZValue;

    if (mBufferName1x!=nil)
    {
        NSString *xraw = [NSString stringWithFormat:@"%f",xrange];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1x :xraw] ;
    }
    if (mBufferName1y!=nil)
    {
        NSString *yraw = [NSString stringWithFormat:@"%f",yrange];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1y :yraw] ;
    }
    if (mBufferName1z!=nil)
    {
        NSString *zraw = [NSString stringWithFormat:@"%f",zrange];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1z :zraw] ;
    }
    
    
    
//    float xrangen = averageNorthXValue2;
//	float yrangen = averageNorthYValue2;
//	float zrangen = averageNorthZValue2;
    float xrangen = averageNorthXValue;
	float yrangen = averageNorthYValue;
	float zrangen = averageNorthZValue;
    float mrangen = sqrt((xrangen * xrangen) + (yrangen * yrangen)+(zrangen * zrangen));
    
    
    if (mBufferName1Nx!=nil)
    {
        NSString *xnor = [NSString stringWithFormat:@"%f",xrangen];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Nx :xnor] ;
    }
    if (mBufferName1Ny!=nil)
    {
        NSString *ynor = [NSString stringWithFormat:@"%f",yrangen];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Ny :ynor] ;
    }
    if (mBufferName1Nz!=nil)
    {
        NSString *znor = [NSString stringWithFormat:@"%f",zrangen];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Nz :znor] ;
    }
    if (mBufferName1NM!=nil)
    {
        NSString *mnor = [NSString stringWithFormat:@"%f",mrangen];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1NM :mnor] ;
    }
    
    
    
//    float xranges = averageSouthXValue2;
//	float yranges = averageSouthYValue2;
//	float zranges = averageSouthZValue2;
    float xranges = averageSouthXValue;
	float yranges = averageSouthYValue;
	float zranges = averageSouthZValue;
    float mranges = sqrt((xranges * xranges) + (yranges * yranges)+(zranges * zranges));
    
    
    if (mBufferName1Sx!=nil)
    {
        NSString *xsou = [NSString stringWithFormat:@"%f",xranges];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Sx :xsou] ;
    }
    if (mBufferName1Sy!=nil)
    {
        NSString *ysou = [NSString stringWithFormat:@"%f",yranges];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Sy :ysou] ;
    }
    if (mBufferName1Sz!=nil)
    {
        NSString *zsou = [NSString stringWithFormat:@"%f",zranges];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1Sz :zsou] ;
    }
    if (mBufferName1SM!=nil)
    {
        NSString *msou = [NSString stringWithFormat:@"%f",mranges];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferName1SM :msou] ;
    }
    
    
    
    
    float xrangeNMS = xrangen - xranges;
	float yrangeNMS = yrangen - yranges;
	float zrangeNMS = zrangen - zranges;
    if (mBufferNameNMSX!=nil)
    {
        NSString *xnms = [NSString stringWithFormat:@"%f",xrangeNMS];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSX :xnms] ;
    }
    if (mBufferNameNMSY!=nil)
    {
        NSString *ynms = [NSString stringWithFormat:@"%f",yrangeNMS];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSY :ynms] ;
    }
    if (mBufferNameNMSZ!=nil)
    {
        NSString *znms = [NSString stringWithFormat:@"%f",zrangeNMS];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSZ :znms] ;
    }
    
    
    double rangeNMSM0 = mrangen-mranges;
	double rangeNMSM = mrangen+mranges;
	double rangeNMSM1 = sqrt((xrangeNMS * xrangeNMS) + (yrangeNMS * yrangeNMS)+(zrangeNMS * zrangeNMS));
    
    
    if (mBufferNameNMSM0!=nil)
    {
        NSString *nmsmM0 = [NSString stringWithFormat:@"%f",rangeNMSM0];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSM0 :nmsmM0] ;
    }
    if (mBufferNameNMSM!=nil)
    {
        NSString *nmsM = [NSString stringWithFormat:@"%f",rangeNMSM];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSM :nmsM] ;
    }
    if (mBufferNameNMSM1!=nil)
    {
        NSString *znmsM1 = [NSString stringWithFormat:@"%f",rangeNMSM1];
        [TestItemManage setBufferValue:DictionaryPtr :mBufferNameNMSM1 :znmsM1] ;
    }
    
	
	return ;
	
}

+(void)ParseCompass:(NSDictionary*) DictionaryPtr
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//Parser Attributes
	
	NSString *mTestItemName			= nil	;
	NSString *mUpLimit				= nil	;
	NSString *mLowLimit				= nil	;
	NSString *mPDCAWrite			=@"no"	;
	NSString *mBufferInit			= nil	;
	NSString *mBufferRaw			= nil	;
	NSString *mBufferNorth			= nil	;
	NSString *mBufferSouth			= nil	;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferRaw"])
		{
			mBufferRaw = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNorth"])
		{
			mBufferNorth = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferSouth"])
		{
			mBufferSouth = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mBufferInit==nil||mBufferRaw==nil||mBufferNorth==nil||mBufferSouth==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	// declare int variable to store Uplimit and Lowlimit
	int x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit;
	int x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit;
	NSArray *Uplimit	= nil;
	NSArray *Lowlimit	= nil;
	
	// get Upper limit
	Uplimit = [ mUpLimit componentsSeparatedByString:@","];
	if ([Uplimit count]!=3)
	{
		
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	
	}
	x_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	y_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	z_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	// get Lower limit
	Lowlimit = [ mLowLimit componentsSeparatedByString:@","];
	if ([Lowlimit count]!=3)
	{
		
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
		
	}
	x_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	y_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	z_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	/*
	
		NSString* mBufferNorthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0x31, Y: 0xAC, Z: 0x30";
		NSString* mBufferSouthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0xC9, Y: 0x52, Z: 0xDC";
		NSString* mBufferRawValue   =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x77, X: 0x77, Y: 0x81, Z: 0x82";
		NSString* mBufferInitValue  =@"Initial DAC offsets : (+0, +0, +0)Final DAC offsets : (+132, +133, +1) (0:0x1E) - DacX: 0x84, DacY: 0x85, DacZ:0x01";
	*/
	NSString *mBufferInitValue	= nil;
	NSString *mBufferRawValue	= nil;
	NSString *mBufferNorthValue	= nil;
	NSString *mBufferSouthValue	= nil;
	
	
	mBufferInitValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ;
	mBufferRawValue		= [TestItemManage getBufferValue:DictionaryPtr :mBufferRaw] ;
	mBufferNorthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferNorth] ;
	mBufferSouthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferSouth] ;
	
	if (mBufferInitValue==nil||mBufferRawValue==nil||mBufferNorthValue==nil||mBufferSouthValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\""withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\r"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\n"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"\t"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@":-)"withString:@" "];
	
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@" "withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\r"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\n"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"\t"withString:@""];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@":-)"withString:@""];
	 
	
	// Get Data from responding buffer value
	NSRange	range;
	range =[mBufferRawValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferRawValue = [ mBufferRawValue substringFromIndex:(NSUInteger)range.location ];
	
	
	range =[mBufferNorthValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferNorthValue = [ mBufferNorthValue substringFromIndex:(NSUInteger)range.location ];
	
	range =[mBufferSouthValue rangeOfString:@"Temperature"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferSouthValue = [ mBufferSouthValue substringFromIndex:(NSUInteger)range.location ];
	
	
	range = [mBufferInitValue rangeOfString:@"Sensitivity"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferInitValue =[ mBufferInitValue substringFromIndex:(range.location+12) ];
	
	range =[mBufferInitValue rangeOfString:@"("];
	if (range.length<=0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	
	mBufferInitValue = [mBufferInitValue substringToIndex:range.location];
	
	
	
	
	//split data to Array
	
	NSArray *initdata	= nil;
	NSArray *rawdata	= nil;
	NSArray *northData	= nil;
	NSArray *southData	= nil;
	
	initdata	= [mBufferInitValue  componentsSeparatedByString:@","];
	rawdata		= [mBufferRawValue   componentsSeparatedByString:@","];
	northData	= [mBufferNorthValue componentsSeparatedByString:@","];
	southData	= [mBufferSouthValue componentsSeparatedByString:@","];

	// set subtest items info to PDCA
	//int		itemp = -1;
	NSString *strTestValue = nil;
	/** SCRID:76 Modify the methord to calculate the compass x,y,z value  and the description on PDCA by Henry on 2011-02-13 **/
	strTestValue =[initdata objectAtIndex:(NSUInteger)0];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSensitivity":@"X":nil:nil:strTestValue:nil:IP_NA:nil];
	strTestValue =[initdata objectAtIndex:(NSUInteger)1];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSensitivity":@"Y":nil:nil:strTestValue:nil:IP_NA:nil];
	strTestValue =[initdata objectAtIndex:(NSUInteger)2];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSensitivity":@"Z":nil:nil:strTestValue:nil:IP_NA:nil];
	
	
	strTestValue = [rawdata objectAtIndex:(NSUInteger)5];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];//delete + befor positive value
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassInitialOffset":@"X":nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [rawdata objectAtIndex:(NSUInteger)6];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassInitialOffset":@"Y":nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [rawdata objectAtIndex:(NSUInteger)7];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassInitialOffset":@"Z":nil:nil:strTestValue:nil:IP_NA:nil];
	

	
	strTestValue = [northData objectAtIndex:(NSUInteger)3];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"Z+" withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassNorth":@"Temp":nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [northData objectAtIndex:(NSUInteger)5];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassNorth":@"X":nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [northData objectAtIndex:(NSUInteger)6];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassNorth":@"Y":nil:nil:strTestValue:nil:IP_NA:nil];
	
	strTestValue = [northData objectAtIndex:(NSUInteger)7];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassNorth":@"Z":nil:nil:strTestValue:nil:IP_NA:nil];
	
	
	
	strTestValue = [southData objectAtIndex:(NSUInteger)3];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"Z+" withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSouth":@"Temp":nil:nil:strTestValue:nil:IP_NA:nil];
	strTestValue = [southData objectAtIndex:(NSUInteger)5];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSouth":@"X":nil:nil:strTestValue:nil:IP_NA:nil];
	strTestValue = [southData objectAtIndex:(NSUInteger)6];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSouth":@"Y":nil:nil:strTestValue:nil:IP_NA:nil];
	strTestValue = [southData objectAtIndex:(NSUInteger)7];
	strTestValue = [strTestValue stringByReplacingOccurrencesOfString:@"+"withString:@""];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassSouth":@"Z":nil:nil:strTestValue:nil:IP_NA:nil];
	/** SCRID:76 Modify end**/

	
	// get North raw data
	int	x_Rawdata_North,y_Rawdata_North,z_Rawdata_North;
	int	x_Rawdata_South,y_Rawdata_South,z_Rawdata_South;
	
	x_Rawdata_North=[ [northData objectAtIndex:(NSUInteger)5] intValue];
	y_Rawdata_North=[ [northData objectAtIndex:(NSUInteger)6] intValue];
	z_Rawdata_North=[ [northData objectAtIndex:(NSUInteger)7] intValue];
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	// get South raw data
	x_Rawdata_South=[ [southData objectAtIndex:(NSUInteger)5] intValue];
	y_Rawdata_South=[ [southData objectAtIndex:(NSUInteger)6] intValue];
	z_Rawdata_South=[ [southData objectAtIndex:(NSUInteger)7] intValue];
	
	
	BOOL flag =YES;
	/** SCRID:76 Modify the methord to calculate the compass x,y,z value  and the description on PDCA by Henry on 2011-02-13 **/
	int	x_InitData,y_InitData,z_InitData;
	x_InitData=[[initdata objectAtIndex:(NSUInteger)0] intValue];
	y_InitData=[[initdata objectAtIndex:(NSUInteger)1] intValue];
	z_InitData=[[initdata objectAtIndex:(NSUInteger)2] intValue];
	
	float H_Adj_x,H_Adj_y,H_Adj_z;
	H_Adj_x=(float)((x_InitData-128)*0.5)/128 +1;
	H_Adj_y=(float)((y_InitData-128)*0.5)/128 +1;
	H_Adj_z=(float)((z_InitData-128)*0.5)/128 +1;
	
	int xrange = (x_Rawdata_North-x_Rawdata_South)*H_Adj_x;
	int yrange = (y_Rawdata_North-y_Rawdata_South)*H_Adj_y;
	int zrange = (z_Rawdata_North-z_Rawdata_South)*H_Adj_z;
	
	if (xrange<x_Diff_lowLimit || xrange>x_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%d",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"X":[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"X":[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (yrange<y_Diff_lowLimit || yrange>y_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%d",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"Y":[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"Y":[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (zrange<z_Diff_lowLimit || zrange>z_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%d",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"Z":[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"CompassRange":@"Z":[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	/** SCRID:76 Modify end  2011-02-13 **/
	

	/*
	int therawtemp	= -1;
	therawtemp		= strtol([[rawdata objectAtIndex:(NSUInteger)2] UTF8String],NULL,16);
	
	if( therawtemp<100 || therawtemp>180 )
	{
		strTestValue = [NSString stringWithFormat:@"%d",therawtemp];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x0E":@"RAWSetuptemp":[NSString stringWithFormat:@"%d",100]:[NSString stringWithFormat:@"%d",180]:strTestValue:nil:IP_FAIL:@"FAIL"];
		
	}
	else
	{
		strTestValue = [NSString stringWithFormat:@"%d",therawtemp];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x0E":@"RAWSetuptemp":[NSString stringWithFormat:@"%d",100]:[NSString stringWithFormat:@"%d",180]:strTestValue:nil:IP_PASS:@"PASS"];
		
	}
	*/
	
	if (flag)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
		//strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@"\n Test Value is:[ %d,%d,%d ]\n Spec Are:     [ %d,%d,%d ]\n               [ %d,%d,%d ]",xrange,yrange,zrange,x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit,x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit];
		
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
		//strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@"\n Test Value is:[ %d,%d,%d ]\n Spec Are:     [ %d,%d,%d ]\n               [ %d,%d,%d ]",xrange,yrange,zrange,x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit,x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit];
		
	}
	
	strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@", X=%d[%d,%d];Y=%d[%d,%d];Z=%d[%d,%d]",xrange,x_Diff_lowLimit,x_Diff_UpLimit,yrange,y_Diff_lowLimit,y_Diff_UpLimit,zrange,z_Diff_lowLimit,z_Diff_UpLimit];
	
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	
	return ;
	
}

/*SCRID-125: add Parser ParseCompassWithCamera. joko 2011-08-03*/
+(void)ParseCompassWithCamera:(NSDictionary*) DictionaryPtr
{
	NSString *mTestItemName			= nil	;
	NSString *mUpLimit				= nil	;
	NSString *mLowLimit				= nil	;
	NSString *mBufferInit			= nil	;
	NSString *mBufferNameFocus0			= nil	;
	NSString *mBufferNameFocus127			= nil	;
	NSString *mBufferNameFocus255			= nil	;
	NSString *mCompassTestType		= nil	;
	NSString *mLoop			= nil	;
	NSString *mBufferNameCameraOff	= nil	;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus0"])
		{
			mBufferNameFocus0 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus127"])
		{
			mBufferNameFocus127 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus255"])
		{
			mBufferNameFocus255 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"CompassTestType"])
		{
			mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameCameraOff"])
		{
			mBufferNameCameraOff = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mBufferInit==nil||mBufferNameFocus0==nil||mBufferNameFocus127==nil||mBufferNameFocus255==nil||mBufferNameCameraOff==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	/*
	 // declare int variable to store Uplimit and Lowlimit
	 int x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit;
	 int x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit;
	 NSArray *Uplimit	= nil;
	 NSArray *Lowlimit	= nil;
	 
	 // get Upper limit
	 
	 Uplimit = [ mUpLimit componentsSeparatedByString:@","];
	 if ([Uplimit count]!=3)
	 {
	 
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	 return  ;
	 
	 }
	 
	 x_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	 y_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	 z_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	 
	 // get Lower limit
	 Lowlimit = [ mLowLimit componentsSeparatedByString:@","];
	 
	 if ([Lowlimit count]!=3)
	 {
	 
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	 return  ;
	 
	 }
	 x_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	 y_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	 z_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	 */
	
	/*
	 NSString* mBufferNorthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0x31, Y: 0xAC, Z: 0x30";
	 NSString* mBufferSouthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0xC9, Y: 0x52, Z: 0xDC";
	 NSString* mBufferRawValue   =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x77, X: 0x77, Y: 0x81, Z: 0x82";
	 NSString* mBufferInitValue  =@"Initial DAC offsets : (+0, +0, +0)Final DAC offsets : (+132, +133, +1) (0:0x1E) - DacX: 0x84, DacY: 0x85, DacZ:0x01";
	 */
	
	NSString *mBufferInitValue = [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ;
	NSString *mBufferValueCameraOff = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameCameraOff] ;
	NSString *mBufferValueFocus0 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus0] ;
	NSString *mBufferValueFocus127 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus127] ;
	NSString *mBufferValueFocus255 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus255] ;
	
	//mBufferInitValue = @"DATA: Sensitivity=\"102, 103, 112\"  (1:0x0E)";
	//mBufferValueCameraOff = @"- readCount, Temperature, X, Y, Z +0,+0,-86,+124,-332 +1,+0,-86,+120,-324 +2,+0,-83,+123,-329 :-)";
	//mBufferValueFocus0 = @"- readCount, Temperature, X, Y, Z +0,+0,-84,+120,-320 +1,+0,-81,+117,-325 +2,+0,-86,+122,-326 :-)";
	//mBufferValueFocus127 = @"- readCount, Temperature, X, Y, Z +0,+0,-81,+115,-319 +1,+0,-74,+116,-316 +2,+0,-79,+119,-317 :-)";
	//mBufferValueFocus255 = @"- readCount, Temperature, X, Y, Z +0,+0,-77,+121,-315 +1,+0,-71,+123,-319 +2,+0,-72,+114,-310 :-)";
	
	
	
	
	if (mBufferInitValue==nil||mBufferValueFocus0==nil||mBufferValueFocus127==nil||mBufferValueFocus255==nil||mBufferValueCameraOff==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mBufferInitValue=[ToolFun getStrFromPrefixAndPostfix:mBufferInitValue Prefix:@"Sensitivity=\"" Postfix:@"\""];
	if (mBufferInitValue==nil || [mBufferInitValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueCameraOff=[ToolFun getStrFromPrefixAndPostfix:mBufferValueCameraOff Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueCameraOff==nil || [mBufferValueCameraOff length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus0=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus0 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus0==nil || [mBufferValueFocus0 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus127=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus127 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus127==nil || [mBufferValueFocus127 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus255=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus255 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus255==nil || [mBufferValueFocus255 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	NSArray *initdata = [mBufferInitValue  componentsSeparatedByString:@","];
	int	x_InitData,y_InitData,z_InitData;
	x_InitData=[[initdata objectAtIndex:(NSUInteger)0] intValue];
	y_InitData=[[initdata objectAtIndex:(NSUInteger)1] intValue];
	z_InitData=[[initdata objectAtIndex:(NSUInteger)2] intValue];
	
	float H_Adj_x,H_Adj_y,H_Adj_z;
	H_Adj_x=(float)((x_InitData-128)*0.5)/128 +1;
	H_Adj_y=(float)((y_InitData-128)*0.5)/128 +1;
	H_Adj_z=(float)((z_InitData-128)*0.5)/128 +1;
	
	/*
	 NSMutableArray *temp = (NSMutableArray*)[mBufferValueCameraOff componentsSeparatedByString:@" "];
	 if([temp count] != ([mLoop intValue] + 2))
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
	 //return;
	 }
	 double totalXValue = 0;
	 double totalYValue = 0;
	 double totalZValue = 0;
	 for(int i=1; i<=[mLoop intValue]; i++)
	 {
	 NSString *oneTimeValue = [temp objectAtIndex:i];
	 NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
	 if([arrayValue count] != 5)
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
	 return;
	 }
	 NSString *testValue = @"0";
	 testValue=[arrayValue objectAtIndex:2];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalXValue += [testValue intValue];
	 
	 dataCollection = @"\n\ncameraOff";
	 dataCollection = [dataCollection stringByAppendingString:@"\t(stoped)\t"]; //
	 dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:3];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalYValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:4];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalZValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 }
	 //float averageCameraOffXValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	 //float averageCameraOffYValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	 //float averageCameraOffZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	 
	 
	 temp = (NSMutableArray*)[mBufferValueFocus0 componentsSeparatedByString:@" "];
	 if([temp count] != ([mLoop intValue] + 2))
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
	 //return;
	 }
	 totalXValue = 0;
	 totalYValue = 0;
	 totalZValue = 0;
	 for(int i=1; i<=[mLoop intValue]; i++)
	 {
	 NSString *oneTimeValue = [temp objectAtIndex:i];
	 NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
	 if([arrayValue count] != 5)
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
	 return;
	 }
	 NSString *testValue = @"0";
	 testValue=[arrayValue objectAtIndex:2];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalXValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	 dataCollection = [dataCollection stringByAppendingString:@"\tFocus0--\t"];
	 dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:3];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalYValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:4];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalZValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 }
	 //float averageFocus0XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	 //float averageFocus0YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	 //float averageFocus0ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	 
	 
	 temp = (NSMutableArray*)[mBufferValueFocus127 componentsSeparatedByString:@" "];
	 if([temp count] != ([mLoop intValue] + 2))
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
	 //return;
	 }
	 totalXValue = 0;
	 totalYValue = 0;
	 totalZValue = 0;
	 for(int i=1; i<=[mLoop intValue]; i++)
	 {
	 NSString *oneTimeValue = [temp objectAtIndex:i];
	 NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
	 if([arrayValue count] != 5)
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
	 return;
	 }
	 NSString *testValue = @"0";
	 
	 testValue=[arrayValue objectAtIndex:2];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalXValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	 dataCollection = [dataCollection stringByAppendingString:@"\tFocus127\t"];
	 dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:3];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalYValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:4];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalZValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 }
	 //float averageFocus127XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	 //float averageFocus127YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	 //float averageFocus127ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	 
	 
	 temp = (NSMutableArray*)[mBufferValueFocus255 componentsSeparatedByString:@" "];
	 if([temp count] != ([mLoop intValue] + 2))
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
	 //return;
	 }
	 totalXValue = 0;
	 totalYValue = 0;
	 totalZValue = 0;
	 for(int i=1; i<=[mLoop intValue]; i++)
	 {
	 NSString *oneTimeValue = [temp objectAtIndex:i];
	 NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
	 if([arrayValue count] != 5)
	 {
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
	 return;
	 }
	 NSString *testValue = @"0";
	 
	 testValue=[arrayValue objectAtIndex:2];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalXValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	 dataCollection = [dataCollection stringByAppendingString:@"\tFocus255\t"];
	 dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:3];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalYValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 
	 testValue=[arrayValue objectAtIndex:4];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	 testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
	 totalZValue += [testValue intValue];
	 
	 dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
	 dataCollection = [dataCollection stringByAppendingString:testValue];
	 dataCollection = [dataCollection stringByAppendingString:@"\n"];
	 }
	 //float averageFocus255XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	 //float averageFocus255YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	 //float averageFocus255ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	 */
	
	//////////////////////////////////////////////////////////////////////////////////////////
	NSString *dataCollection = @""; //
	float afterAdjustValue = 0;
	NSString *strAfterAdjustValue = @"";
	
	float standardDeviationFocus0X = 0;
	float standardDeviationFocus0Y = 0;
	float standardDeviationFocus0Z = 0;
	float standardDeviationFocus127X = 0;
	float standardDeviationFocus127Y = 0;
	float standardDeviationFocus127Z = 0;
	float standardDeviationFocus255X = 0;
	float standardDeviationFocus255Y = 0;
	float standardDeviationFocus255Z = 0;
	
	dataCollection = [dataCollection stringByAppendingString: @"\n\nSensitivity="];
	dataCollection = [dataCollection stringByAppendingString: mBufferInitValue];
	dataCollection = [dataCollection stringByAppendingString: @"\n\nAfter Adjust ----multiply [((sensitivity-128)*0.5)/128 +1]   --- X=Y,Y=-X\n"];
	
	NSMutableArray *temp = (NSMutableArray*)[mBufferValueCameraOff componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		//testValue=[arrayValue objectAtIndex:2];
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		dataCollection = [dataCollection stringByAppendingString: @"cameraOff"];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\(stopped)\tX:"];
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalXValue += afterAdjustValue;
		
		//testValue=[arrayValue objectAtIndex:3];
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalYValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
		totalZValue += afterAdjustValue;
	}
	float averageCameraOffXValue = (totalXValue / [mLoop intValue]);
	float averageCameraOffYValue = (totalYValue / [mLoop intValue]);
	float averageCameraOffZValue = (totalZValue / [mLoop intValue]);
	
	
	temp = (NSMutableArray*)[mBufferValueFocus0 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
		dataCollection = [dataCollection stringByAppendingString:@"\tFocus0--\t"];
		dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalXValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalYValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		totalZValue += afterAdjustValue;
	}
	float averageFocus0XValue = (totalXValue / [mLoop intValue]);
	float averageFocus0YValue = (totalYValue / [mLoop intValue]);
	float averageFocus0ZValue = (totalZValue / [mLoop intValue]);
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		NSString *testValue = @"0";
		//testValue=[arrayValue objectAtIndex:2];
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		standardDeviationFocus0X = afterAdjustValue - averageFocus0XValue;
		standardDeviationFocus0X = standardDeviationFocus0X * standardDeviationFocus0X;
		standardDeviationFocus0X += standardDeviationFocus0X;
		
		//testValue=[arrayValue objectAtIndex:3];
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		standardDeviationFocus0Y = afterAdjustValue - averageFocus0YValue;
		standardDeviationFocus0Y = standardDeviationFocus0Y * standardDeviationFocus0Y;
		standardDeviationFocus0Y += standardDeviationFocus0Y;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		standardDeviationFocus0Z = afterAdjustValue - averageFocus0ZValue;
		standardDeviationFocus0Z = standardDeviationFocus0Z * standardDeviationFocus0Z;
		standardDeviationFocus0Z += standardDeviationFocus0Z;
	}
	
	
	
	temp = (NSMutableArray*)[mBufferValueFocus127 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
		dataCollection = [dataCollection stringByAppendingString:@"\tFocus127\t"];
		dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalXValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalYValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		
		
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		totalZValue += afterAdjustValue;
	}
	float averageFocus127XValue = (totalXValue / [mLoop intValue]);
	float averageFocus127YValue = (totalYValue / [mLoop intValue]);
	float averageFocus127ZValue = (totalZValue / [mLoop intValue]);
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		NSString *testValue = @"0";
		//testValue=[arrayValue objectAtIndex:2];
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		standardDeviationFocus127X = afterAdjustValue - averageFocus127XValue;
		standardDeviationFocus127X = standardDeviationFocus127X * standardDeviationFocus127X;
		standardDeviationFocus127X += standardDeviationFocus127X;
		
		//testValue=[arrayValue objectAtIndex:3];
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		standardDeviationFocus127Y = afterAdjustValue - averageFocus127YValue;
		standardDeviationFocus127Y = standardDeviationFocus127Y * standardDeviationFocus127Y;
		standardDeviationFocus127Y += standardDeviationFocus127Y;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		standardDeviationFocus127Z = afterAdjustValue - averageFocus127ZValue;
		standardDeviationFocus127Z = standardDeviationFocus127Z * standardDeviationFocus127Z;
		standardDeviationFocus127Z += standardDeviationFocus127Z;
	}
	
	
	
	
	temp = (NSMutableArray*)[mBufferValueFocus255 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
		dataCollection = [dataCollection stringByAppendingString:@"\tFocus255\t"];
		dataCollection = [dataCollection stringByAppendingString:@"X:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalXValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tY:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		totalYValue += afterAdjustValue;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		strAfterAdjustValue = [NSString stringWithFormat:@"%f",afterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\tZ:"]; //
		dataCollection = [dataCollection stringByAppendingString:strAfterAdjustValue];
		dataCollection = [dataCollection stringByAppendingString:@"\n"];
		totalZValue += afterAdjustValue;
	}
	float averageFocus255XValue = (totalXValue / [mLoop intValue]);
	float averageFocus255YValue = (totalYValue / [mLoop intValue]);
	float averageFocus255ZValue = (totalZValue / [mLoop intValue]);
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		NSString *testValue = @"0";
		//testValue=[arrayValue objectAtIndex:2];
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_y * 0.3;
		standardDeviationFocus255X = afterAdjustValue - averageFocus255XValue;
		standardDeviationFocus255X = standardDeviationFocus255X * standardDeviationFocus255X;
		standardDeviationFocus255X += standardDeviationFocus255X;
		
		//testValue=[arrayValue objectAtIndex:3];
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = -1 * [testValue intValue] * H_Adj_x * 0.3;
		standardDeviationFocus255Y = afterAdjustValue - averageFocus255YValue;
		standardDeviationFocus255Y = standardDeviationFocus255Y * standardDeviationFocus255Y;
		standardDeviationFocus255Y += standardDeviationFocus255Y;
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		afterAdjustValue = [testValue intValue] * H_Adj_z * 0.3;
		standardDeviationFocus255Z = afterAdjustValue - averageFocus255ZValue;
		standardDeviationFocus255Z = standardDeviationFocus255Z * standardDeviationFocus255Z;
		standardDeviationFocus255Z += standardDeviationFocus255Z;
	}
	
	
	dataCollection = [dataCollection stringByAppendingString:@"\nAverage Value\n"];
	dataCollection = [dataCollection stringByAppendingString:@"cameraOff"];
	dataCollection = [dataCollection stringByAppendingString:@"\(stopped)\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageCameraOffXValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageCameraOffYValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageCameraOffZValue]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse0--\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0ZValue]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse127\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127ZValue]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse255\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255ZValue]];
	
	
	standardDeviationFocus0X = pow((standardDeviationFocus0X/[mLoop intValue]), 0.5);
	standardDeviationFocus0Y = pow((standardDeviationFocus0Y/[mLoop intValue]), 0.5);
	standardDeviationFocus0Z = pow((standardDeviationFocus0Z/[mLoop intValue]), 0.5);
	
	standardDeviationFocus127X = pow((standardDeviationFocus127X/[mLoop intValue]), 0.5);
	standardDeviationFocus127Y = pow((standardDeviationFocus127Y/[mLoop intValue]), 0.5);
	standardDeviationFocus127Z = pow((standardDeviationFocus127Z/[mLoop intValue]), 0.5);
	
	standardDeviationFocus255X = pow((standardDeviationFocus255X/[mLoop intValue]), 0.5);
	standardDeviationFocus255Y = pow((standardDeviationFocus255Y/[mLoop intValue]), 0.5);
	standardDeviationFocus255Z = pow((standardDeviationFocus255Z/[mLoop intValue]), 0.5);
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\nStandard Deviation\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse0--\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus0X]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus0Y]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus0Z]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse127\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus127X]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus127Y]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus127Z]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse255\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus255X]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus255Y]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",standardDeviationFocus255Z]];
	
	
	
	//use delta
	averageFocus0XValue = averageFocus0XValue - averageCameraOffXValue;
	averageFocus0YValue = averageFocus0YValue - averageCameraOffYValue;
	averageFocus0ZValue = averageFocus0ZValue - averageCameraOffZValue;
	
	averageFocus127XValue = averageFocus127XValue - averageCameraOffXValue;
	averageFocus127YValue = averageFocus127YValue - averageCameraOffYValue;
	averageFocus127ZValue = averageFocus127ZValue - averageCameraOffZValue;
	
	averageFocus255XValue = averageFocus255XValue - averageCameraOffXValue;
	averageFocus255YValue = averageFocus255YValue - averageCameraOffYValue;
	averageFocus255ZValue = averageFocus255ZValue - averageCameraOffZValue;
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\nDelta Value\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse0--\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0ZValue]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse127\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus127ZValue]];
	
	dataCollection = [dataCollection stringByAppendingString:@"\n\n"];
	dataCollection = [dataCollection stringByAppendingString:mCompassTestType];
	dataCollection = [dataCollection stringByAppendingString:@"\tFocuse255\tX:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255XValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tY:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255YValue]];
	dataCollection = [dataCollection stringByAppendingString:@"\tZ:"];
	dataCollection = [dataCollection stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus255ZValue]];
	//use delta --end
	
	//translate Diags Value to OS value.
	/*
	 float tmpTranslate = averageFocus0XValue;
	 averageFocus0XValue = averageFocus0YValue ;
	 averageFocus0YValue = -1 * tmpTranslate;
	 
	 tmpTranslate = averageFocus127XValue;
	 averageFocus127XValue = averageFocus127YValue ;
	 averageFocus127YValue = -1 * tmpTranslate;
	 
	 tmpTranslate = averageFocus255XValue;
	 averageFocus255XValue = averageFocus255YValue ;
	 averageFocus255YValue = -1 * tmpTranslate;
	 //translate Diags Value to OS value --end.
	 */
	
	float slopeX = ((averageFocus0XValue + averageFocus127XValue + averageFocus255XValue) * (0 + 127 + 255) - 3 * (averageFocus0XValue * 0 + averageFocus127XValue * 127 + averageFocus255XValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	float slopeY = ((averageFocus0YValue + averageFocus127YValue + averageFocus255YValue) * (0 + 127 + 255) - 3 * (averageFocus0YValue * 0 + averageFocus127YValue * 127 + averageFocus255YValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	float slopeZ = ((averageFocus0ZValue + averageFocus127ZValue + averageFocus255ZValue) * (0 + 127 + 255) - 3 * (averageFocus0ZValue * 0 + averageFocus127ZValue * 127 + averageFocus255ZValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	
	float interceptX = ((averageFocus0XValue * 0 + averageFocus127XValue * 127 + averageFocus255XValue * 255) - (slopeX * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	float interceptY = ((averageFocus0YValue * 0 + averageFocus127YValue * 127 + averageFocus255YValue * 255) - (slopeY * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	float interceptZ = ((averageFocus0ZValue * 0 + averageFocus127ZValue * 127 + averageFocus255ZValue * 255) - (slopeZ * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope X":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeX]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope Y":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeY]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope Z":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeZ]:nil:IP_NA:nil];
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept X":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptX]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept Y":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptY]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept Z":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptZ]:nil:IP_NA:nil];
	
	NSString *strTestResultForUIinfo = @"slopX:";
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeX]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; slopY:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeY]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; slopZ:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeZ]];
	
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptX:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",interceptX]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptY:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",interceptY]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptZ:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",interceptZ]];
	
	NSString *tmpSlopeIntercept = strTestResultForUIinfo;
	
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"\n\n"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:dataCollection];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"\n\n"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:tmpSlopeIntercept];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"\n\n"];
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strTestResultForUIinfo] ;
	
	/*
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 BOOL flag =YES;
	 
	 
	 int xrange = (averageNorthXValue - averageSouthXValue) * H_Adj_x;
	 int yrange = (averageNorthYValue - averageSouthYValue) * H_Adj_x;
	 int zrange = (averageNorthZValue - averageSouthZValue) * H_Adj_x;
	 
	 if (xrange<x_Diff_lowLimit || xrange>x_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",xrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",xrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (yrange<y_Diff_lowLimit || yrange>y_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",yrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",yrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (zrange<z_Diff_lowLimit || zrange>z_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",zrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",zrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (flag)
	 {
	 enumResult				= RESULT_FOR_PASS;
	 strTestResultForUIinfo	= @"PASS";
	 }
	 else
	 {
	 enumResult				= RESULT_FOR_FAIL;
	 strTestResultForUIinfo	= @"FAIL";
	 }
	 
	 strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@", X=%d[%d,%d];Y=%d[%d,%d];Z=%d[%d,%d]",xrange,x_Diff_lowLimit,x_Diff_UpLimit,yrange,y_Diff_lowLimit,y_Diff_UpLimit,zrange,z_Diff_lowLimit,z_Diff_UpLimit];
	 */
	
}
/*SCRID-125: end*/


/*SCRID-125: add Parser ParseCompassWithCamera. joko 2011-08-03*/
+(void)ParseCompassWithCameraOld:(NSDictionary*) DictionaryPtr
{
	NSString *mTestItemName			= nil	;
	NSString *mUpLimit				= nil	;
	NSString *mLowLimit				= nil	;
	NSString *mBufferInit			= nil	;
	NSString *mBufferNameFocus0			= nil	;
	NSString *mBufferNameFocus127			= nil	;
	NSString *mBufferNameFocus255			= nil	;
	NSString *mCompassTestType		= nil	;
	NSString *mLoop			= nil	;
	NSString *mBufferNameCameraOff	= nil	;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus0"])
		{
			mBufferNameFocus0 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus127"])
		{
			mBufferNameFocus127 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFocus255"])
		{
			mBufferNameFocus255 = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"CompassTestType"])
		{
			mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameCameraOff"])
		{
			mBufferNameCameraOff = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mBufferInit==nil||mBufferNameFocus0==nil||mBufferNameFocus127==nil||mBufferNameFocus255==nil||mBufferNameCameraOff==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	/*
	 // declare int variable to store Uplimit and Lowlimit
	 int x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit;
	 int x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit;
	 NSArray *Uplimit	= nil;
	 NSArray *Lowlimit	= nil;
	 
	 // get Upper limit
	 
	 Uplimit = [ mUpLimit componentsSeparatedByString:@","];
	 if ([Uplimit count]!=3)
	 {
	 
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	 return  ;
	 
	 }
	 
	 x_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	 y_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	 z_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	 
	 // get Lower limit
	 Lowlimit = [ mLowLimit componentsSeparatedByString:@","];
	 
	 if ([Lowlimit count]!=3)
	 {
	 
	 [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	 return  ;
	 
	 }
	 x_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	 y_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	 z_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	 */
	
	/*
	 NSString* mBufferNorthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0x31, Y: 0xAC, Z: 0x30";
	 NSString* mBufferSouthValue =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x78, X: 0xC9, Y: 0x52, Z: 0xDC";
	 NSString* mBufferRawValue   =@"Gains  (0:0x1E) - GainX: 0xB7, GainY: 0x16, GainZ: 0x58Offsets(0:0x1E) - DacX : 0x84, DacY : 0x85, DacZ : 0x01Raw data (0:0x1E) - Temp: 0x77, X: 0x77, Y: 0x81, Z: 0x82";
	 NSString* mBufferInitValue  =@"Initial DAC offsets : (+0, +0, +0)Final DAC offsets : (+132, +133, +1) (0:0x1E) - DacX: 0x84, DacY: 0x85, DacZ:0x01";
	 */
	
	NSString *mBufferInitValue = [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ;
	NSString *mBufferValueCameraOff = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameCameraOff] ;
	NSString *mBufferValueFocus0 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus0] ;
	NSString *mBufferValueFocus127 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus127] ;
	NSString *mBufferValueFocus255 = [TestItemManage getBufferValue:DictionaryPtr :mBufferNameFocus255] ;
	
	
	if (mBufferInitValue==nil||mBufferValueFocus0==nil||mBufferValueFocus127==nil||mBufferValueFocus255==nil||mBufferValueCameraOff==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mBufferInitValue=[ToolFun getStrFromPrefixAndPostfix:mBufferInitValue Prefix:@"Sensitivity=\"" Postfix:@"\""];
	if (mBufferInitValue==nil || [mBufferInitValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueCameraOff=[ToolFun getStrFromPrefixAndPostfix:mBufferValueCameraOff Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueCameraOff==nil || [mBufferValueCameraOff length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus0=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus0 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus0==nil || [mBufferValueFocus0 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus127=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus127 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus127==nil || [mBufferValueFocus127 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	mBufferValueFocus255=[ToolFun getStrFromPrefixAndPostfix:mBufferValueFocus255 Prefix:@"X, Y, Z" Postfix:@":-)"];
	if (mBufferValueFocus255==nil || [mBufferValueFocus255 length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	NSArray *initdata = [mBufferInitValue  componentsSeparatedByString:@","];
	int	x_InitData,y_InitData,z_InitData;
	x_InitData=[[initdata objectAtIndex:(NSUInteger)0] intValue];
	y_InitData=[[initdata objectAtIndex:(NSUInteger)1] intValue];
	z_InitData=[[initdata objectAtIndex:(NSUInteger)2] intValue];
	
	float H_Adj_x,H_Adj_y,H_Adj_z;
	H_Adj_x=(float)((x_InitData-128)*0.5)/128 +1;
	H_Adj_y=(float)((y_InitData-128)*0.5)/128 +1;
	H_Adj_z=(float)((z_InitData-128)*0.5)/128 +1;
	
	NSMutableArray *temp = (NSMutableArray*)[mBufferValueCameraOff componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageCameraOffXValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	float averageCameraOffYValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	float averageCameraOffZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	
	
	temp = (NSMutableArray*)[mBufferValueFocus0 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageFocus0XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	float averageFocus0YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	float averageFocus0ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	
	
	temp = (NSMutableArray*)[mBufferValueFocus127 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageFocus127XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	float averageFocus127YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	float averageFocus127ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	
	
	temp = (NSMutableArray*)[mBufferValueFocus255 componentsSeparatedByString:@" "];
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	totalXValue = 0;
	totalYValue = 0;
	totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	float averageFocus255XValue = (totalXValue / [mLoop intValue]) * H_Adj_x * 0.3;// * 10;
	float averageFocus255YValue = (totalYValue / [mLoop intValue]) * H_Adj_y * 0.3;// * 10;
	float averageFocus255ZValue = (totalZValue / [mLoop intValue]) * H_Adj_z * 0.3;// * 10;
	
	//use delta
	averageFocus0XValue = averageFocus0XValue - averageCameraOffXValue;
	averageFocus0YValue = averageFocus0YValue - averageCameraOffYValue;
	averageFocus0ZValue = averageFocus0ZValue - averageCameraOffZValue;
	
	averageFocus127XValue = averageFocus127XValue - averageCameraOffXValue;
	averageFocus127YValue = averageFocus127YValue - averageCameraOffYValue;
	averageFocus127ZValue = averageFocus127ZValue - averageCameraOffZValue;
	
	averageFocus255XValue = averageFocus255XValue - averageCameraOffXValue;
	averageFocus255YValue = averageFocus255YValue - averageCameraOffYValue;
	averageFocus255ZValue = averageFocus255ZValue - averageCameraOffZValue;
	//use delta --end
	
	//translate Diags Value to OS value.
	float tmpTranslate = averageFocus0XValue;
	averageFocus0XValue = averageFocus0YValue ;
	averageFocus0YValue = -1 * tmpTranslate;
	
	tmpTranslate = averageFocus127XValue;
	averageFocus127XValue = averageFocus127YValue ;
	averageFocus127YValue = -1 * tmpTranslate;
	
	tmpTranslate = averageFocus255XValue;
	averageFocus255XValue = averageFocus255YValue ;
	averageFocus255YValue = -1 * tmpTranslate;
	//translate Diags Value to OS value --end.
	
	float slopeX = ((averageFocus0XValue + averageFocus127XValue + averageFocus255XValue) * (0 + 127 + 255) - 3 * (averageFocus0XValue * 0 + averageFocus127XValue * 127 + averageFocus255XValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	float slopeY = ((averageFocus0YValue + averageFocus127YValue + averageFocus255YValue) * (0 + 127 + 255) - 3 * (averageFocus0YValue * 0 + averageFocus127YValue * 127 + averageFocus255YValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	float slopeZ = ((averageFocus0ZValue + averageFocus127ZValue + averageFocus255ZValue) * (0 + 127 + 255) - 3 * (averageFocus0ZValue * 0 + averageFocus127ZValue * 127 + averageFocus255ZValue * 255))
	/ ((0 + 127 + 255) * (0 + 127 + 255) - 3 * (0 * 0 + 127 * 127 + 255 * 255));
	
	float interceptX = ((averageFocus0XValue * 0 + averageFocus127XValue * 127 + averageFocus255XValue * 255) - (slopeX * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	float interceptY = ((averageFocus0YValue * 0 + averageFocus127YValue * 127 + averageFocus255YValue * 255) - (slopeY * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	float interceptZ = ((averageFocus0ZValue * 0 + averageFocus127ZValue * 127 + averageFocus255ZValue * 255) - (slopeZ * (0 * 0 + 127 * 127 + 255 * 255))) / (0 + 127 + 255);
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope X":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeX]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope Y":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeY]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Slope Z":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",slopeZ]:nil:IP_NA:nil];
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept X":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptX]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept Y":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptY]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Intercept Z":mCompassTestType:nil:nil:[NSString stringWithFormat:@"%f",interceptZ]:nil:IP_NA:nil];
	
	NSString *strTestResultForUIinfo = @"slopX:";
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeX]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; slopY:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeY]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; slopZ:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",slopeZ]];
	
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptX:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0XValue]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptY:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0YValue]];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"; interceptZ:"];
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%f",averageFocus0ZValue]];
	
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :strTestResultForUIinfo] ;
	
	/*
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus0ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus127ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255XValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255YValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 strTestValue = [NSString stringWithFormat:@"%f",averageFocus255ZValue];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z":mCompassTestType:nil:nil:strTestValue:nil:IP_NA:nil];
	 
	 BOOL flag =YES;
	 
	 
	 int xrange = (averageNorthXValue - averageSouthXValue) * H_Adj_x;
	 int yrange = (averageNorthYValue - averageSouthYValue) * H_Adj_x;
	 int zrange = (averageNorthZValue - averageSouthZValue) * H_Adj_x;
	 
	 if (xrange<x_Diff_lowLimit || xrange>x_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",xrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",xrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range X":mCompassTestType:[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (yrange<y_Diff_lowLimit || yrange>y_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",yrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",yrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Y":mCompassTestType:[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (zrange<z_Diff_lowLimit || zrange>z_Diff_UpLimit)
	 {
	 strTestValue = [NSString stringWithFormat:@"%d",zrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
	 flag = NO;
	 }
	 else
	 {	
	 strTestValue = [NSString stringWithFormat:@"%d",zrange];
	 [TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Range Z":mCompassTestType:[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	 }
	 
	 if (flag)
	 {
	 enumResult				= RESULT_FOR_PASS;
	 strTestResultForUIinfo	= @"PASS";
	 }
	 else
	 {
	 enumResult				= RESULT_FOR_FAIL;
	 strTestResultForUIinfo	= @"FAIL";
	 }
	 
	 strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@", X=%d[%d,%d];Y=%d[%d,%d];Z=%d[%d,%d]",xrange,x_Diff_lowLimit,x_Diff_UpLimit,yrange,y_Diff_lowLimit,y_Diff_UpLimit,zrange,z_Diff_lowLimit,z_Diff_UpLimit];
	 */
	
}
/*SCRID-125: end*/

+(void)CompareValueWithTwoBuffer:(NSDictionary*) DictionaryPtr
{
    NSString *mBufferName = nil	;
	NSString *mTestItemName = nil	;
	NSString *mCompassTestType	= nil	;
    NSString *mReferenceBufferName = nil;
	NSString *mReferenceBufferName2 = nil;
	NSString *mBufferVale = nil;
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CompassTestType"])
		{
			mCompassTestType = [DictionaryPtr objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
    }
    
    if (mReferenceBufferName == nil || mReferenceBufferName2 ==nil)
    {
        
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Script Error"] ;
        [TestItemManage  setBufferValue:DictionaryPtr :mBufferName :@"Fail"] ;
        return;
    }
    // default CompassTestType is  string type
    NSString *mReferenBuffValue1 = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
    NSString *mReferenBuffValue2 = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName2];
    
    mReferenBuffValue1 = [mReferenBuffValue1 stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenBuffValue1 = [mReferenBuffValue1 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenBuffValue1 = [mReferenBuffValue1 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenBuffValue1 = [mReferenBuffValue1 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    mReferenBuffValue2 = [mReferenBuffValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenBuffValue2 = [mReferenBuffValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenBuffValue2 = [mReferenBuffValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenBuffValue2 = [mReferenBuffValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if ((mCompassTestType == nil) ||[ mCompassTestType isEqualToString:@"Str"])
    {
        if ([mReferenBuffValue1 isEqualToString:mReferenBuffValue2])
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"Pass"] ;
            mBufferName = @"Pass" ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Fail"] ;
            mBufferName = @"Fail" ;
        }
    }
    if ([ mCompassTestType isEqualToString:@"int"]||[ mCompassTestType isEqualToString:@"Hex"])
    {
        
        if ([mReferenBuffValue1 intValue] >[mReferenBuffValue2 intValue])
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"ReferenBuffValue1 > ReferenBuffValue2"] ;
        }
        else if([mReferenBuffValue1 intValue] < [mReferenBuffValue2 intValue])
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"ReferenBuffValue1 < ReferenBuffValue2"] ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"ReferenBuffValue1 = ReferenBuffValue2"] ;
        }
    }
    [TestItemManage  setBufferValue:DictionaryPtr :mBufferName :mBufferVale] ;
    return;
    
}

@end
