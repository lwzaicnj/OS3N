/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI4DOE1440X900.h		 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI4DOE1440X900.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 21.03.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"

#define MaxUnitFlag    10

//extern NSString* getAPPInitLog() ;
@interface UI4DOE1440X900 : NSObject  {
	//iboutlet variable
	IBOutlet NSWindow *window;
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSBox *boxTestItem ;
	
	IBOutlet NSTableView *testInforTableview1 ;
	IBOutlet NSTableView *testInforTableview2 ;
	IBOutlet NSTableView *testInforTableview3 ;
	IBOutlet NSTableView *testInforTableview4 ;
	IBOutlet NSScrollView* scrollView1 ;
	IBOutlet NSScrollView* scrollView2 ;
	IBOutlet NSScrollView* scrollView3 ;
	IBOutlet NSScrollView* scrollView4 ;
	IBOutlet NSScrollView* textLog ;
	
	IBOutlet NSTextField *textTotalTime1;
	IBOutlet NSTextField *textTotalTime2;
	IBOutlet NSTextField *textTotalTime3;
	IBOutlet NSTextField *textTotalTime4;
	IBOutlet NSTextField *textItemTime1;
	IBOutlet NSTextField *textItemTime2;
	IBOutlet NSTextField *textItemTime3;
	IBOutlet NSTextField *textItemTime4;
	IBOutlet NSTextField *textTestResult1;
	IBOutlet NSTextField *textTestResult2;
	IBOutlet NSTextField *textTestResult3;
	IBOutlet NSTextField *textTestResult4;

	IBOutlet NSButton* btnLog1;
	IBOutlet NSButton* btnLog2;
	IBOutlet NSButton* btnLog3;
	IBOutlet NSButton* btnLog4;
	IBOutlet NSButton* btnLogClose;
	IBOutlet NSButton* btnSimulator;

	IBOutlet NSTextField *textLabelTimes1 ;
	IBOutlet NSTextField *textLabelTimes2 ;
	IBOutlet NSTextField *textLabelTimes3 ;
	IBOutlet NSTextField *textLabelTimes4 ;

	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	
	int tableViewCnt;
	NSTableView *tableViewForCnt;
	NSTableView *tableViewArray[4];
	BOOL initTableFlag;
	BOOL mTestStartFlag[MaxUnitFlag];
	BOOL mTestFlag;
	int refreshTimeCnt;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
	NSInteger mLoopTimes[4];
	NSInteger mTotalLoopTimes ;
}

-(IBAction)btnOpenLog1_Click:(id)sender;
-(IBAction)btnOpenLog2_Click:(id)sender;
-(IBAction)btnOpenLog3_Click:(id)sender;
-(IBAction)btnOpenLog4_Click:(id)sender;
-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)closeLog_Click:(id)sender;
-(IBAction)setFixtureID:(id)sender;

-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer ;
-(void)timerUnitCheckFireMethod:(NSTimer*)theTimer ;
-(void)initUIScanLabelAndText;
-(void)showInitLog;
-(void)setTableBgdColor:(NSInteger)uiIndex;
-(IBAction)CallEditScriptUI:(id)sender ;
@end

