//
//  StringParseFuncation.h
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"
#import "UICommon.h"

@interface TestItemParse(GetFixtureIDFunction)
+(void)GetFixtureID:(NSDictionary*)dictKeyDefined ;
@end