/*
 
SCRID:11
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: CheckNandSizeFunction.h
 | $Author::caijunbo                    $Revision:: 1               
 | CREATED: 2010.11.08                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :Check  Nand Size between syscfg and that from hardware.
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CheckNandSizeWithSyscfgFunction)

+(void)CheckNandSizeWithSyscfg:(NSDictionary*)dictKeyDefined;

@end
