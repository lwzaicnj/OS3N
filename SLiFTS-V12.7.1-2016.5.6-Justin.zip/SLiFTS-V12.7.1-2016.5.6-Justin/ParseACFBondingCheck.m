//
//  ParseACFBondingCheck.m
//  iFTS
//	SCRID-36
//  Created by Shou-xiu on 2010-12-13.
//

#import "Pudding.h"
#import "ParseACFBondingCheck.h"


@implementation TestItemParse(ParseACFBondingCheck)

+(void)ParseACFBondingCheck:(NSDictionary*) DictionaryPtr
{
	NSString *mReferenceBufferName = nil;
	NSString *mTestItemName		   = nil;
	NSString *mBufferValue        = nil;
	NSString *HWConfig			   = nil;
	NSString *BoardType			   = nil;
	NSString *mPrefix			   = nil;
	NSString *mPostfix			   = nil;
	
	NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
	NSInteger FailCount			   = 0;
	bool      Is46PinFail		   = false;
	
	for(int i=0;i<[DictionaryPtr count];i++)
	{
		NSString* strKey = [[DictionaryPtr allKeys] objectAtIndex:i];
		
		if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[DictionaryPtr objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[DictionaryPtr objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr:RESULT_FOR_OTHER:@"Script Occur Error"];
		return ;
	}

	//
	HWConfig=[TestItemManage getSFCValue:DictionaryPtr :STRKEYHWCOIG];
	if([HWConfig length]<=0)
	{	
	    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"No HWConfig"] ;
	    return  ;
	}
	else if([HWConfig rangeOfString:@"UMTS"].length>0)
	{
		BoardType =@"K94";
	}
	else if([HWConfig rangeOfString:@"CDMA2000"].length>0)
	{
		BoardType =@"K95";
	}
	
	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName];
	NSLog(@"showing %@",mBufferValue);
	//mBufferValue = @"testacf  Platform baseband is X24  Testing pins: 13 Testing pins: 11 Testing pins: 20 Testing pins: 12 Testing pins: 10, 27, 28 Testing pins: 9 Testing pins: 21 Testing pins: 30, 29 Testing pins: 23, 24, 25 Testing pins: 15, 16, 17, 18, 19 Testing pins: 34, 37, 38, 43 Testing pins: 40, 39 Testing pins: 35, 36 Testing pins: 41 Testing pins: 45, 46, 47, 48, 49  Scoreboard:  1[-]   11[P]   21[P]   31[X]   41[P]   Legend:            2[-]   12[P]   22[-]   32[X]   42[X]            Pass [P]  3[-]   13[P]   23[P]   33[-]   43[P]            Fail [F]  4[-]   14[-]   24[P]   34[P]   44[-]      No results [?]  5[-]   15[P]   25[P]   35[P]   45[?]   Test disabled [X]  6[-]   16[P]   26[-]   36[P]   46[F]          Ignore [-]  7[-]   17[P]   27[P]   37[P]   47[?]     8[-]   18[P]   28[P]   38[P]   48[?]     9[P]   19[P]   29[P]   39[P]   49[?]    10[P]   20[P]   30[P]   40[P]   50[-]     Faulty pins: 46 SIM_DET  Pins omitted due to disabled tests: 31 UART_AP_2_RXD 32 UART_AP_2_TXD 42 IRQ_GPS_INT_L  Untested pins: 45 PPVSIM 47 SIM_RST 48 SIM_CLK 49 SIM_IO  Result: 29 pins tested 28 pins passed  3 pins omitted  4 pins untested  FAIL  testacf returned Device Error error :-) ";
	
	if(mBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"];
		return;
	}
	
	if([mBufferValue rangeOfString:@"46[F]"].length>0)
	{
		Is46PinFail = true;
	}
	
	NSMutableString *mutStrTmp = [NSMutableString stringWithString:mBufferValue];
	NSRange rangTmp ;
	
	rangTmp = [mutStrTmp rangeOfString:@"[F]"] ;
	while(rangTmp.length>0)
	{
		FailCount++;
		[mutStrTmp replaceCharactersInRange:rangTmp withString:@""];
		rangTmp = [mutStrTmp rangeOfString:@"[F]"] ;
	}
	
	NSLog(@"showing %@",mutStrTmp);
//	if([mBufferValue rangeOfString:@"[F]"].length>0)
//	{
//		FailCount++;
//		[mBufferValue stringByReplacingOccurrencesOfString:@"[F]" withString:@""];
//	}
//	NSLog(@"showing %@",mBufferValue);
//	if([mBufferValue rangeOfString:@"[F]"].length>0)
//	{
//		FailCount++;
//		[mBufferValue stringByReplacingOccurrencesOfString:@"[F]" withString:@""];
//	}
//	NSLog(@"showing %@",mBufferValue);
	
	if([mBufferValue rangeOfString:@"PASS"].length>0)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
		if((FailCount == 2) && (Is46PinFail == true) && ([BoardType isEqualToString:@"K94"]))
		{
			strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@" 46[F]"];
		}
		else
		{
			strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:[ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix
																														:mPrefix Postfix
																														:mPostfix]];
		}
	}
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	
	return ;
}

@end
