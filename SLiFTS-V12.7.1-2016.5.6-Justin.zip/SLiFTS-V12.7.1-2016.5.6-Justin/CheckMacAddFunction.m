//
//  CheckMacAddFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "CheckMacAddFunction.h"


@implementation TestItemParse(SpecialParseMK)


+(void)CheckMacAdd:(NSDictionary*) DictionaryPtr
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil||mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\n"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\r"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\t"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@" " ] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\""] ;
	
	BOOL flag =NO;
	NSRange range;
	int iContain=-1;
	NSString *dataResult=@"";
	
	if ([mReferenceBufferValue length] <= 0)
	{
		dataResult=@"STOP";
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"invalid value"] ;
		[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
		return;
	}
	
	range=[mReferenceBufferValue rangeOfString:@":"];
	if (range.length <= 0)
	{
		
		dataResult=@"STOP";
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"invalid value"] ;
		[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
		return;
	}
	
	dataResult=mReferenceBufferValue;
	
	range=[mReferenceBufferValue rangeOfString:@"00:00:00:00:00:00"];
	if (range.length > 0)
	{
		dataResult=@"STOP";
		iContain=1;
		flag=NO;
	
	}
	
	range=[mReferenceBufferValue rangeOfString:@"11:11:11:11:11:11"];
	if (range.length > 0)
	{
		dataResult=@"STOP";
		iContain=1;
		flag=NO;
		
	}
	
	range=[mReferenceBufferValue rangeOfString:@"?"];
	if (range.length > 0)
	{
		dataResult=@"STOP";
		iContain=1;
		flag=NO;
		
	}
	
	[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
	
	if (1==iContain)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	
	}
	
	
}

@end
