/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseBERFunction.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 2011-03-04                $Modtime:: 2011-03-04		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseBERFunction.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 2011-03-04
 * Created in 
 * first implementation
 */

#import "ParseBERFunction.h"
#import "Pudding.h"
#import "toolFun.h"

@implementation TestItemParse(ParseBERFunction)

+(void)ParseBERMeasureValue:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	//key parse
	NSInteger mCount=0;
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mSpecValue = nil;
	NSString *mAppearCnt = nil;
	NSString *mSeperateString = nil;

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"SpecString"])
			mSpecValue = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"AppearCount"])
			mAppearCnt = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"SeperateString"])
			mSeperateString = [dictKeyDefined objectForKey:strKey] ;
		
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	if((nil ==mSpecValue)||(nil == mAppearCnt)||(nil== mSeperateString))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"script occur error"] ;
		return ;
	}
	
	NSArray *tmpArray=[mReferenceBufferValue componentsSeparatedByString:mSeperateString];
	
	for(NSInteger i=0;i<[tmpArray count];i++)
	{
		NSString *strValue=[tmpArray objectAtIndex:i];
		if([strValue rangeOfString:mSpecValue].length>0 )
			mCount++;
	}
	
	if(mCount ==[mAppearCnt intValue])
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
	else
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"LANE FAIL";
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo];
	return ;
}

@end



