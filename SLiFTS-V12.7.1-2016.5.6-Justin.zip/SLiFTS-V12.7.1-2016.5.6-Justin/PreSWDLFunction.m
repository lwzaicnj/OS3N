//
//  PreSWDLFunction.m
//  iFTS
//
//  Created by MAC008 on 10-12-17.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//SCRID:46

#import "Pudding.h"
#import "PreSWDLFunction.h"


@implementation TestItemParse(PreSWDLFunction)

+(void)ParseSWDL:(NSDictionary*) DictionaryPtr
{
	NSString *HWConfig	 = nil;	
	NSString *strTimeOut = nil ;
	enum TestResutStatus enumResult ;
	enumResult = RESULT_FOR_FAIL;
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TimeOut"])
		{
			strTimeOut =  [DictionaryPtr objectForKey:strKey];
		}
	}
	
	
	//Step0: first to check whether enter iBoot mode 
	NSString *strUnit=[DictionaryPtr objectForKey:@"UNITDevice"] ;
	if (![self CheckUnitExist:strUnit :@"0"])
	{	
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Unit isn't in IBoot mode!"] ;
		return  ;
	}
	
	//Step1 :First to check whether exist SN . 
	if ([TestItemManage getUnitValue:DictionaryPtr :STRKEYSYSSN]==nil)
	{
		NSString *strUISN = [TestItemManage getScanValue:DictionaryPtr :STRKEYSYSSN] ;
		if (strUISN==nil)
		{	
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"NO SN"] ;
			return  ;
		}
		[TestItemManage setUnitValue:DictionaryPtr :STRKEYSYSSN :strUISN];
	}
	
	//Step2: then perform query oracle .
	NSMutableDictionary* mutdictTmp = [NSMutableDictionary dictionaryWithDictionary:DictionaryPtr] ;
	[mutdictTmp removeObjectForKey:@"TestItemName"];
	[TestItemParse QueryOracle:DictionaryPtr] ;
	
	HWConfig=[TestItemManage getSFCValue:DictionaryPtr :STRKEYHWCOIG];
	if([HWConfig length]<=0)
	{	
	    [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"No HWConfig ,Can't check Unit Type"] ;
	    return  ;
	}
	
	NSString* strExecScript=nil ;
	NSString* BoardType =nil ;
	if([HWConfig rangeOfString:@"UMTS"].length>0) //it meaning K94 ;
	{
		BoardType =@"K94";
		strExecScript = @"exec /usbget_K94";
	}else if([HWConfig rangeOfString:@"CDMA2000"].length>0)
	{
		BoardType =@"K95";
		strExecScript = @"exec /usbget_K95";
	}
	else
	{
		BoardType =@"K93";
		strExecScript = @"exec /usbget_K93";
	}
		
	system([strExecScript UTF8String]);
	
	if (strTimeOut==nil)
		strTimeOut =@"5" ; //default value
	
	sleep([strTimeOut intValue]);//delay 5 second
	
	//step 3 :check whether enter to diags .
	if ([self CheckUnitExist:strUnit :@"1"])
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"SWDL Success!"] ;
	else
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"SWDL Fail !"] ;
	
	return ;
}

@end

//end
