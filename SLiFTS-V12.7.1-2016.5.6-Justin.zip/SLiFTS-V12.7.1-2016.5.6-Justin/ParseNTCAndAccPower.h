//
//  ParseNTCAndAccPower.h
//  qt_simulator
//
//  Created by QTeam on 4/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseNTCAndAccPower)

+(void)ParseNTCAndAccPower:(NSDictionary*)dictKeyDefined ;

@end
