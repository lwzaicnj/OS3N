//
//  CheckMacAddFunction.h
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ConfirmMacAddFunction)

+(void)ConfirmMacAdd:(NSDictionary*) DictionaryPtr;

@end