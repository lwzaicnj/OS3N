//
//  serialTest.m
//  qt_simulator
//
//  Created by diags on 12/17/09.
//  Copyright 2009 Foxconn. All rights reserved.
//

#import "serialTest.h"

@implementation serialTest
-(id)init
{
	comm = nil ;
	commManager = nil ;
	iSendTotal =0 ;
	iReceTotal = 0 ;
	if (self=[super init])
	{
		comm = [[UartComm alloc] init] ;
	}

	
	/*notification test start*/
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(myNotificationHandle:) name:nil object:comm] ;
	/*notification test end*/

	//script parse  FUnction test
	[ScriptParse parseAppConfig:[NSHomeDirectory()stringByAppendingString:@"/AppConfig.txt"]] ;
	[ScriptParse parseTestScript:[NSHomeDirectory()stringByAppendingString:@"/QT1.txt"]] ;
	return self ;
}

- (void)awakeFromNib
{
	[btn_Open setTitle:@"Open Port"] ;
	bPortOpen = false ;
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	//initialize serial port
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSMutableArray *maTmp = (NSMutableArray*)[UartComm ScanPort]  ;
	//end
	[cbSerialPort addItemsWithObjectValues:maTmp] ;
	if ([maTmp count])
		[cbSerialPort selectItemAtIndex:0] ;
	
	//set baudrate
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSMutableArray *maBaudRate = (NSMutableArray*)[UartComm ScanBaudRate];
	//end
	[cbBaudRate removeAllItems] ;
	[cbBaudRate addItemsWithObjectValues:maBaudRate] ;
	[cbBaudRate selectItemAtIndex:4] ;
								  
	//set data bit
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
    NSMutableArray *maDataBit = (NSMutableArray*)[UartComm ScanDataBit] ;
	//end
	[cbDataBit removeAllItems] ;
	[cbDataBit addItemsWithObjectValues:maDataBit];
	[cbDataBit selectItemAtIndex:3] ;
								  
	//set stop bit
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSMutableArray *maStopBit = (NSMutableArray*)[UartComm ScanStopBit] ;
	//end
	[cbStopBit removeAllItems] ;
	[cbStopBit addItemsWithObjectValues:maStopBit] ;							  
	[cbStopBit selectItemAtIndex:0] ;
								 
	//set flow control bit
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSMutableArray *maFlowControl = (NSMutableArray*)[UartComm ScanFlowControl] ;
	//end
	[cbFlowControl removeAllItems] ;
	[cbFlowControl addItemsWithObjectValues:maFlowControl] ;									 
	[cbFlowControl selectItemAtIndex:2] ;
								  
   //set parity bit
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
   NSMutableArray *maParity = (NSMutableArray*)[UartComm ScanParity] ;
	//end
   [cbParityBit removeAllItems] ;
	[cbParityBit addItemsWithObjectValues:maParity]	;								 
   [cbParityBit selectItemAtIndex:2] ;
	
	[pool release] ;
	
	
	[textviewRece setEditable:false] ;
	[[textviewSend documentView]setEditable:false] ;
	

		
}

-(void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObject:self] ;
	[commManager release] ;
	[comm release] ;
	[super dealloc] ;
}

/*get configration value*/
-(NSString*) getPortValue
{
	return [cbSerialPort objectValueOfSelectedItem] ;
}

-(enum BaudRate) getBaudRate
{
	switch ([cbBaudRate indexOfSelectedItem]) {
		case 0:
			return BAUDRATE_9600 ;
		case 1:	
			return BAUDRATE_19200 ;
		case 2:
			return BAUDRATE_38400 ;
		case 3:
			return BAUDRATE_76800 ;
		case 4:	
			return BAUDRATE_115200 ;
		case 5:
			return BAUDRATE_230400 ;	
		default:
			return BAUDRATE_DEFAULT ;
	} 
}

-(enum DataBits) getDataBit
{
	switch ([cbDataBit indexOfSelectedItem]) {
		case 0:
			return DATA_BITS_5 ;
		case 1:	
			return DATA_BITS_6 ;
		case 2:
			return DATA_BITS_7 ;
		case 3:	
			return DATA_BITS_8 ;	
		default:
			return DATA_BITS_DEFAULT ;
	} 
}

-(enum StopBit) getStopBit
{
	switch ([cbStopBit indexOfSelectedItem]) {
		case 0:
			return STOP_BITS_1 ;
		case 1:	
			return STOP_BITS_2 ;
		default:
			return STOP_BITS_DEFAULT ;
	} 
}

-(enum Parity) getParity
{
	switch ([cbParityBit indexOfSelectedItem]) {
		case 0:
			return PARITY_EVEN ;
		case 1:	
			return PARITY_ODD ;
		case 2:
			return PARITY_NONE ;
		default:
			return PARITY_DEFAULT ;
	} 
}

-(enum FlowControl) getFlowControl
{
	switch ([cbFlowControl indexOfSelectedItem]) {
		case 0:
			return FLOW_CONTROL_HANDWARE ;
		case 1:	
			return FLOW_CONTROL_SOFTWARE ;
		case 2:
			return FLOW_CONTROL_NONE ;
		default:
			return FLOW_CONTROL_DEFAULT ;
	} 
}


-(IBAction) btn_start:(id)sender
{
	[self getPortValue] ;
	
	if (!bPortOpen)
	{
		
		[comm OpenPort:[self getPortValue] BaudRate
		              :[self getBaudRate] DataBits
		              :[self getDataBit]  StopBit
		              :[self getStopBit] Parity
		              :[self getParity]   FlowControl
		              :[self getFlowControl]
		 ] ;
		
		
		/*[commManager OpenPort:@"myDeviceID" PortName 
		              :[self getPortValue] BaudRate
		              :[self getBaudRate] DataBits
		              :[self getDataBit]  StopBit
		              :[self getStopBit] Parity
		              :[self getParity]   FlowControl
		              :[self getFlowControl]  KeysDefine
					  :nil
		 ] ;
		 */
		[comm setPortID:@"myDeviceID"] ;
		/*
		[comm OpenPort:[self getPortValue] BaudRate
		              :BAUDRATE_115200 DataBits
		              :DATA_BITS_8  StopBit
		              :STOP_BITS_1 Parity
		              :PARITY_NONE   FlowControl
		              :FLOW_CONTROL_NONE
		 ] ;
		*/
	}else
	{
		[comm ClosePort] ;
	}

}

-(IBAction)btn_send:(id)sender ;
{
   if (bPortOpen)
   {
	   NSString *strTmp ;
	   if ([chkBtn_SendAsNewLine state])
	   {
		   //strTmp = [[[textfieldInput stringValue] stringByAppendingFormat:@"\n"] retain] ;
		   strTmp = [[[NSString stringWithString:@"\n"] stringByAppendingFormat:@"%@",[textfieldInput stringValue]] retain] ;
	   }else
	   {
		   strTmp = [[textfieldInput stringValue]  retain] ;
	   }
	   //NSLog(@"\n send data is :%@ , length is %d\n",strTmp,[strTmp lengthOfBytesUsingEncoding:NSUTF8StringEncoding]) ;
	   NSMutableDictionary * mutDictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
	   [mutDictTmp setValue:@":-)" forKey:@"EndString"] ;
	   [mutDictTmp setValue:@"3" forKey:@"TimeOut"] ;
	   
	   NSMutableData *nsdataTmp = [[NSData alloc] initWithBytes:[strTmp cStringUsingEncoding: NSUTF8StringEncoding] length:[strTmp lengthOfBytesUsingEncoding:NSUTF8StringEncoding]] ;
	   /*
	   [commManager WriteData:@"myDeviceID" DataBuffer
							:nsdataTmp
							:nil];
	   */
	   [comm SendData:nsdataTmp] ;
	   [nsdataTmp release] ;
	   [strTmp  release] ;
   }
}

- (void)myNotificationHandle:(NSNotification*)notification  ;
{	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	//NSDictionary *dictTmp = [notification userInfo] ;
	
	if ([[notification name] isEqualToString:MACOS_COMM_CONNECT_SUCCESS])
	{
		[textfieldStatus setStringValue:@"serial port connect success"] ;
		[textfieldStatus setTextColor:[NSColor blackColor]] ;
		[btn_Open setTitle:@"Close Port"] ;
		bPortOpen = true ;
	}else if([[notification name] isEqualToString:MACOS_COMM_CONNECT_FAIL])
	{
		[textfieldStatus setStringValue:@"serial port connect disable"] ;
		[textfieldStatus setTextColor:[NSColor redColor]] ;
		[btn_Open setTitle:@"Open Port"] ;
		bPortOpen = false ;
	}else if([[notification name] isEqualToString:MACOS_COMM_RECV_CHAR] )
	{
		NSString *strTmp = [[NSString alloc] initWithData:[comm ReceiveData] encoding:NSASCIIStringEncoding] ;
		//[textviewRece insertText:strTmp] ;
		if (strTmp!=nil)
		{
			[[[textviewRece textStorage] mutableString] appendString:strTmp] ;
			iReceTotal += [strTmp length] ;
			[strTmp release] ;
		
			[textfieldSendandRece setStringValue:[NSString stringWithFormat:@" received bytes: %d         sended bytes :%d" ,iReceTotal,iSendTotal]] ;
		}
	}else if([[notification name] isEqualToString:MACOS_COMM_CONNECT_ABOUT])
	{
		[textfieldStatus setStringValue:@"serial port connect about"] ;
		[textfieldStatus setTextColor:[NSColor redColor]] ;
		[btn_Open setTitle:@"Open Port"] ;
		bPortOpen = false ;
	}else if ([[notification name] isEqualToString:MACOS_COMM_SEND_CHAR])
	{
		NSString *strTmp = [[NSString alloc] initWithData:[[notification userInfo] objectForKey:@"SENDDATA"] encoding:NSUTF8StringEncoding] ;
        [[[[textviewSend documentView] textStorage] mutableString] appendString:strTmp] ;
		iSendTotal += [strTmp length] ;
		[strTmp release] ;
		
		[textfieldSendandRece setStringValue:[NSString stringWithFormat:@" received bytes: %d         sended bytes :%d" ,iReceTotal,iSendTotal]] ;
		//scroll to the renew position
		//[textviewSend scrollLineDown:textviewSend] ;
	}
	[pool release] ;
}

@end
