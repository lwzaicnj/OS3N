//
//  ParseWriteDateAndTimeFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseWriteDateAndTimeFunction.h"


@implementation TestItemParse(ParseWriteDateAndTimeFunction)

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 2               
 | CREATED: 2010.03.24                  $Modtime:: 2010.04.08 10:07     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Special Parser Method
 
 PURPOSE :Read back Date from unit and compare it with the previous one that write into it.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.03.24   Time: 20:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


+(void)ParseWriteDateAndTime:(NSDictionary*) DictionaryPtr
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//Parser Attributes
	
	NSString *mTestItemName			= nil	;
	NSString *mReferenceBufferName	= nil	;
	NSString *mBufferName			= nil	;
	NSString *mPDCAWrite			=@"no"	;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	//mReferenceBufferValue	=@"rtc --set 20090927160723 20090927160725:-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	

	NSString	*strdateWrite	= nil;
	NSString	*strdateRead	= nil;
	NSDate		*dateWrite		= nil;
	NSDate		*dateRead		= nil;
	NSString	*strTemp		= nil;
	
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\n"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\r"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\t"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\""] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@" "] ;
	
	strTemp			= [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"set" Postfix:@":-)"];
	if (strTemp==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Diag returning string Error!"] ;
		return;
	
	}
	strdateWrite	= [strTemp substringToIndex:(NSUInteger)14];
	strdateRead		= [strTemp substringFromIndex:(NSUInteger)14];
	
	if (strdateRead.length!=14||strdateWrite.length!=14)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Diag returning string Error!"] ;
		return;
	}
	
	//copy date and time to strTestResultForUIinfo and show it in UI
	strTestResultForUIinfo = [NSString stringWithString:strdateWrite];
	
	
	strdateWrite	= [ToolFun getInternationalStr:strdateWrite offset:@"+0800"];
	strdateRead		= [ToolFun getInternationalStr:strdateRead	offset:@"+0800"];
	if (strdateWrite==nil ||strdateRead==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Time format translate Error!"] ;
	    return  ;
	}
	
	
	dateWrite	= [NSDate dateWithString:strdateWrite];
	dateRead	= [NSDate dateWithString:strdateRead];
	
	if (dateWrite==nil ||dateRead==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Error in translating Date!"] ;
		return;
	
	}
	
	
	NSTimeInterval timeInterval = 100;
	timeInterval = [dateRead timeIntervalSinceDate:dateWrite];
	
	if (timeInterval>-5&&timeInterval<5)
	{
		enumResult =RESULT_FOR_PASS ;
		//strTestResultForUIinfo = @"Pass" ;
	}
	
	else 
	{
		enumResult =RESULT_FOR_FAIL ;
		//strTestResultForUIinfo = @"Fail" ;
	
	}
	
	
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	return ;
	
	
}


@end
