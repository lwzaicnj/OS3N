//
//  ParseStrWithBetweenNumberFunction.h
//  qt_simulator
//
//  Created by joko 7/16/10.
//  Copyright 2010 0000000000. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseModuleSNFunction)

+(void)ParseModuleSN:(NSDictionary*) DictionaryPtr;
+(void)ParseTopModuleSNFromSFC:(NSDictionary*) DictionaryPtr;
//Added by Annie 2014.01.10 for 70 digital SN
+(void)ParseEntireSN:(NSDictionary*) DictionaryPtr;
+(void)ParseBattery3xBarcode:(NSDictionary*) DictionaryPtr;
@end