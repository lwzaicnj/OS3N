/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseBERFunction.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 2011-03-04                $Modtime:: 2011-03-04		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseBERFunction.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 2011-03-04
 * Created in 
 * first implementation
 */
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseBERFunction)

+(void)ParseBERMeasureValue:(NSDictionary*)dictKeyDefined ;

@end
