//
//  CurrentAutoTest.h
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CurrentAutoTestFunction)

+(void)GetCurrentTestLog:(NSDictionary*)dictKeyDefined;
+(void)GetCurrentValue:(NSDictionary*)dictKeyDefined;
+(void)GetVoltageValue:(NSDictionary*)dictKeyDefined;
+(void)GetTargetSettingCurrentForHigh:(NSDictionary*)dictKeyDefined;

@end
