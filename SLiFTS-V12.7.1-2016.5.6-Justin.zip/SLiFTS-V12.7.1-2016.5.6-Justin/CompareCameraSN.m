//
//  CompareCameraSN.m
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

//#import "NetWorkBasedCB.h"
//#import "CBAuth_API.h"
//#import "InstantPudding_API.h"
#import "CompareCameraSN.h"
#import "toolFun.h"

@implementation TestItemParse(CompareCameraSNFun)

+(void)CompareCameraSN:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
	NSString *mIsFrontCamera = @"no";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"IsFrontCamera"])
		{
			mIsFrontCamera = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    NSString *cameraSN = @"";
    
    if([mIsFrontCamera boolValue])
		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strFCMS"];
	else
		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strBCMS"];
    
   
    //front
	//cameraSN = @"DNM201107ZDF9V85F";
	//back
	//NSString *cameraSN = @"DN51483013KDJG154";
    //cameraSN = @"DN82124361FF0TH3H";
	if([cameraSN length] < 17)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"The Length of Camera SN is Error"];
		return;
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];

	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	NSString *cameraBufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([cameraBufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
		return;
	}
	
	//Add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc] initWithString:cameraBufferValue] autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0)
    {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//End added
    
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
    //Ray Modify for QL 2012-11-25
    if([arrayNVM count] <= 24)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 24"];
        return;
    }
    //Modify End
	
	int failCounter = 0;
	/************************************************************************************************/
	/*************** Camera SN Format: PPPYWWDSSSSEEEERX, like DNM1375100QDJG57G ********************/
	/************************************* PPP YWWD SSSS EEEER X ***********************************************************/
	
	NSString *faiMsg = @"Fail: ";
	
    //Ray modify for QL 2012-11-25
	if([mIsFrontCamera boolValue])
	{
        /************* 1. Check PPP EEEER ****************/
        //Get the PPP hex value from NVM 0x002[7:0]
        NSString *hexPPP = [arrayNVM objectAtIndex:3];
        
        //Get the EEEE hex value from NVM 0x002[7:4] and transfer to EEEE
        NSString *hexEEEE = [arrayNVM objectAtIndex:3];
        hexEEEE = [hexEEEE substringToIndex:1];
        
        NSString *EEEE = @"";
        NSString *EEEE2 = @"";
        if([hexEEEE isEqualToString:@"6"])
        {
            EEEE = @"F9V8";
            EEEE2 = @"FNQW";
        }
        else if([hexEEEE isEqualToString:@"5"])
        {
            EEEE = @"F9V9";
            EEEE2 = @"FNQY";
        }
        //Get the R hex value from NVM 0x011[7:0] and transfer to R
        NSString *hexR = [arrayNVM objectAtIndex:18];
        int decR = (int)strtol([hexR UTF8String], NULL, 16);
        NSString *R = [NSString stringWithFormat:@"%d",decR];
        R = [R substringFromIndex:[R length]-1];
        
        //Compose the EEEER by EEEE and R
        NSString *EEEER = [EEEE stringByAppendingString:R];
        NSString *EEEER2 = [EEEE2 stringByAppendingString:R];
        
        //Get the PPP and EEEER of the camera SN that OP scan into SFC
        NSString *ppp =[cameraSN substringToIndex:3];
        NSString *eeeer =[cameraSN substringFromIndex:11];
        eeeer =[eeeer substringToIndex:5];
        
        if([hexPPP isEqualToString:@"61"])//0x61 DNM
        {
            if([hexEEEE isEqualToString:@"6"]) //DNM F9V8R
            {
                if([ppp isNotEqualTo:@"DNM"] || ([eeeer isNotEqualTo:EEEER] && [eeeer isNotEqualTo:EEEER2]))
                {
                        failCounter++;
                        NSLog(@"Check Camera SN, PPP or EEEER Fail");
                        faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else if([hexPPP isEqualToString:@"51"])//0x51 F0W
        {
            if([hexEEEE isEqualToString:@"5"]) //F0W F9V9R
            {

                if([ppp isNotEqualTo:@"F0W"] || ([eeeer isNotEqualTo:EEEER2] && [eeeer isNotEqualTo:EEEER]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                    
                }
            }
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else
        {
            failCounter++;
        }
        
        /************* 2. Check Year Week Day ****************/
        //Get the Year binary value
        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
        binaryYear = [binaryYear substringFromIndex:4];
        
        //Get the Week binary value
        NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
        binaryWeek = [binaryWeek substringFromIndex:2];
        
        //Get the Day binary value
        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
        binaryDay = [binaryDay substringFromIndex:5];
        
        //Change the year, weeek, day binary value to decimal value and combine them to a string
        int intYear=strtol([binaryYear UTF8String], NULL, 2);
        int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
        int intDay=strtol([binaryDay UTF8String], NULL, 2);
        NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
        //If week only one digit, add one zero in front of the digit
        NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
        if([tmpStringWeek length] < 2)
        {
            NSString *tmpZeroStringWeek = @"0";
            tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
        }
        yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
        yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
        
        NSString *yearWeekDaySN = [cameraSN substringFromIndex:3];
        yearWeekDaySN = [yearWeekDaySN substringToIndex:4];
        
        if(![yearWeekDaySN isEqualToString:yearWeekDay])
        {
            failCounter++;
            NSLog(@"Check Camera SN, Year-Week-Day Fail");
            faiMsg = [faiMsg stringByAppendingString:@"; Year-Week-Day"];
        }
        
        /************* 3. Check SSSS, 3 ID value ****************/
        NSString *ssss = [arrayNVM objectAtIndex:24];
        ssss = [ssss stringByAppendingString:[arrayNVM objectAtIndex:23]];
        ssss = [ssss stringByAppendingString:[arrayNVM objectAtIndex:22]];
        int intSsss=strtol([ssss UTF8String], NULL, 16);
        
        NSString *ssssSN = [cameraSN substringFromIndex:7];
        ssssSN = [ssssSN substringToIndex:4];
        int intSsssSN=[ToolFun change34BasedtoDecimal:ssssSN];
        
        if(intSsss != intSsssSN)
        {
            failCounter++;
            NSLog(@"Check Camera SN, SSSS Fail");
            faiMsg = [faiMsg stringByAppendingString:@"; SSSS Fail"];
        }
        
        /********************************************************************************/
        /*DCRID-140: convert Unit NVM Data to Camera SN. Judith 2011-10-24*/
        
        NSString *UnitSSSS=@"";
        NSString *UnitSSSS1 = @"";
        NSString *UnitSSSS2 = @"";
        NSString *UnitSSSS3 = @"";
        NSString *UnitSSSS4 = @"";
        
        int intTmpChar4 = intSsss / 39304;	//39304=34*34*34
        if(intTmpChar4 > 33)
        {
            UnitSSSS4 = @"&";
            UnitSSSS3 = @"&";
            UnitSSSS2 = @"&";
            UnitSSSS1 = @"&";
        }
        else
        {
            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
            int intYuShuChar3 = intSsss % 39304;		//39304=34*34*34
            int intShangChar3 = intYuShuChar3 / 1156;	//1156 =34*34
            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
            
            int intYuShuChar2 = intYuShuChar3 % 1156;
            int intShangChar2 = intYuShuChar2 / 34;
            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
            
            int intYuShuChar1 = intYuShuChar2 % 34;
            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
        }
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS4];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS3];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS2];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS1];
        
        NSString *UnitPPP = @"";
        NSString *UnitEEEER = @"";
        NSString *UnitEEEER2 = @"";
        
        //NSString *UnitPPP2 = @"";
        //NSString *UnitEEEER2 = @"";
        
        //NSString *UnitPPP3 = @"";
        //NSString *UnitEEEER3 = @"";
        
        //===============================================================================================
        if([hexPPP isEqualToString:@"61"]&&[hexEEEE isEqualToString:@"6"])//DNM F9V8R
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNM"];
            UnitEEEER = [UnitEEEER stringByAppendingString:EEEER];
            UnitEEEER2 = [UnitEEEER2 stringByAppendingString:EEEER2];
        }
        //===============================================================================================
        else if([hexPPP isEqualToString:@"51"]&&[hexEEEE isEqualToString:@"5"])//F0W F9V9R
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F0W"];
            UnitEEEER = [UnitEEEER stringByAppendingString:EEEER];
            UnitEEEER2 = [UnitEEEER2 stringByAppendingString:EEEER2];
        }
        //===============================================================================================
        else
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"There is no corresponding PPP and EEEER "];
        
        NSString *NunitSN=@". UnitCameraSN:";
        NSString *NunitSN1=@"";
        NSString *NunitSN2=@"";
        NunitSN = [NunitSN stringByAppendingString:UnitPPP];
        NunitSN = [NunitSN stringByAppendingString:yearWeekDay];
        NunitSN = [NunitSN stringByAppendingString:UnitSSSS];
        NunitSN1 = [NunitSN1 stringByAppendingString:NunitSN];
        NunitSN1 = [NunitSN1 stringByAppendingString:UnitEEEER];
        NunitSN2 = [NunitSN2 stringByAppendingString:NunitSN];
        NunitSN2 = [NunitSN2 stringByAppendingString:UnitEEEER2];
        
        /*SCRID-142: Add Checksum to Camera SN. 2011-10-26 Lucky*/
        NSString *tmp1 = [NunitSN1 stringByReplacingOccurrencesOfString:@". UnitCameraSN:" withString:@""];
        NunitSN1 = [NunitSN1 stringByAppendingString: [self getCheckSum:tmp1]];
        NSString *tmp2 = [NunitSN2 stringByReplacingOccurrencesOfString:@". UnitCameraSN:" withString:@""];
        NunitSN2 = [NunitSN2 stringByAppendingString: [self getCheckSum:tmp2]];
        /*SCRID-142:end*/
        
        faiMsg = [faiMsg stringByAppendingString:NunitSN1];
        faiMsg = [faiMsg stringByAppendingString:@"||"];
        faiMsg = [faiMsg stringByAppendingString:NunitSN2];
        /*
         NSString *NunitSN2=@" | ";
         if([UnitPPP2 length] > 0)
         {
         NunitSN2 = [NunitSN2 stringByAppendingString:UnitPPP2];
         NunitSN2 = [NunitSN2 stringByAppendingString:yearWeekDay];
         NunitSN2 = [NunitSN2 stringByAppendingString:UnitSSSS];
         NunitSN2 = [NunitSN2 stringByAppendingString:UnitEEEER2];
         
         //SCRID-142: Add Checksum to Camera SN. 2011-10-26 Lucky
         NSString *tmp2 = [NunitSN2 stringByReplacingOccurrencesOfString:@" | " withString:@""];
         NunitSN2 = [NunitSN2 stringByAppendingString: [self getCheckSum:tmp2]];
         //SCRID-142:end
         
         faiMsg = [faiMsg stringByAppendingString:NunitSN2];
         }
         
         NSString *NunitSN3=@" | ";
         if([UnitPPP3 length] > 0)
         {
         NunitSN3 = [NunitSN3 stringByAppendingString:UnitPPP3];
         NunitSN3 = [NunitSN3 stringByAppendingString:yearWeekDay];
         NunitSN3 = [NunitSN3 stringByAppendingString:UnitSSSS];
         NunitSN3 = [NunitSN3 stringByAppendingString:UnitEEEER3];
         
         //SCRID-142: Add Checksum to Camera SN. 2011-10-26 Lucky
         NSString *tmp3 = [NunitSN3 stringByReplacingOccurrencesOfString:@" | " withString:@""];
         NunitSN3 = [NunitSN3 stringByAppendingString: [self getCheckSum:tmp3]];
         //SCRID-142:end
         
         faiMsg = [faiMsg stringByAppendingString:NunitSN3];
         }
         */
        NSString *passLog = @"Pass. ";
        passLog = [passLog stringByAppendingString:NunitSN1];
        passLog = [passLog stringByAppendingString:@"||"];
        passLog = [passLog stringByAppendingString:NunitSN2];
        
        // add by justin to compare unit cameraSN  which get from SFC of front camera 2013-11-11
        if([passLog rangeOfString:cameraSN].length <= 0)
        {
            failCounter++;
        }
        // justin end
        /*
         if([UnitPPP2 length] > 0)
         {
         passLog = [passLog stringByAppendingString:NunitSN2];
         }
         if([UnitPPP3 length] > 0)
         {
         passLog = [passLog stringByAppendingString:NunitSN3];
         }
         */
        if(failCounter >= 1)
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :faiMsg];
        else
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :passLog];
    }
    else
    {
		/************* 1. Check PPP EEEER ****************/
		NSString *binaryIntegrator = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:18]];
        binaryIntegrator = [binaryIntegrator substringToIndex:4];
        
        NSString *hexConfig =[arrayNVM objectAtIndex:41];
        hexConfig = [hexConfig substringToIndex:1];
        
        //Get the PPP and EEEER of the camera SN that OP scan into SFC
		NSString *ppp =[cameraSN substringToIndex:3];
		NSString *eeeer =[cameraSN substringFromIndex:11];
		eeeer =[eeeer substringToIndex:5];
        
		if([binaryIntegrator isEqualToString:@"0010"])//Integrator=2(LGIT)
        {
            if([hexConfig isEqualToString:@"1"]) //DN8 F9V61
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V61"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"2"]) //DN8 F9V62
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V62"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"3"]) //DN8 F9V63
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V63"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"4"]) //DN8 F9V64
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V64"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"5"]) //DN8 F9V65
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V65"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"6"]) //DN8 F9V66
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V66"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"7"]) //DN8 F9V67
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V67"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"8"]) //DN8 F9V68
            {
                if((![ppp isEqualToString:@"DN8"]) || (![eeeer isEqualToString:@"F9V68"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else if([binaryIntegrator isEqualToString:@"0011"])//Integrator=3(VPT)
        {
            if([hexConfig isEqualToString:@"1"]) //DN3 F9V61
            {
                if((![ppp isEqualToString:@"DN3"]) || (![eeeer isEqualToString:@"F9V61"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"2"]) //DN3 F9V62
            {
                if((![ppp isEqualToString:@"DN3"]) || (![eeeer isEqualToString:@"F9V62"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"3"]) //DN3 F9V63
            {
                if((![ppp isEqualToString:@"DN3"]) || (![eeeer isEqualToString:@"F9V63"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else if([binaryIntegrator isEqualToString:@"0100"])//Integrator=4(SHARP SSTEC)
        {
            if([hexConfig isEqualToString:@"1"]) //DNL FF9L1
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L1"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"2"]) //DNL FF9L2
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L2"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"3"]) //DNL FF9L3
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L3"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"4"]) //DNL FF9L4
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L4"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"5"]) //DNL FF9L5
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L5"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"6"]) //DNL FF9L6
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L6"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"7"]) //DNL FF9L7
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L7"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"8"]) //DNL FF9L8
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L8"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
        /********************************add by bruce begin 2013-06-20********************************/        
            else if([hexConfig isEqualToString:@"9"]) //DNL FF9L9
            {
                if((![ppp isEqualToString:@"DNL"]) || (![eeeer isEqualToString:@"FF9L9"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
         /********************************add by bruce end 2013-06-20********************************/       
            
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else if([binaryIntegrator isEqualToString:@"0101"])//Integrator=5(SHARP WSE)
        {
            if([hexConfig isEqualToString:@"1"]) //DNL FF9L1
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L1"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"2"]) //DNL FF9L2
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L2"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"3"]) //DNL FF9L3
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L3"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"4"]) //DNL FF9L4
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L4"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"5"]) //DNL FF9L5
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L5"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"6"]) //DNL FF9L6
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L6"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"7"]) //DNL FF9L7
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L7"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
            else if([hexConfig isEqualToString:@"8"]) //DNL FF9L8
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L8"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
        /********************************add by bruce begin 2013-06-20********************************/  
            else if([hexConfig isEqualToString:@"9"]) //DNL FF9L9
            {
                if((![ppp isEqualToString:@"F6D"]) || (![eeeer isEqualToString:@"FF9L9"]))
                {
                    failCounter++;
                    NSLog(@"Check Camera SN, PPP or EEEER Fail");
                    faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
                }
            }
        /********************************add by bruce end 2013-06-20********************************/  
            else
            {
                failCounter++;
                NSLog(@"Check Camera SN, PPP or EEEER Fail");
                faiMsg = [faiMsg stringByAppendingString:@"; PPP or EEEER Fail"];
            }
        }
        else
        {
            failCounter++;
        }
		
		/************* 2. Check Year Week Day ****************/
        //Get the Year binary value
        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:17]];
        binaryYear = [binaryYear substringFromIndex:4];
        
        //Get the Week binary value
		NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
        binaryWeek = [binaryWeek substringFromIndex:2];
        
		//Get the Day binary value
        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:18]];
        binaryDay = [binaryDay substringFromIndex:4];
        
        //Change the year, weeek, day binary value to decimal value and combine them to a string
		int intYear=strtol([binaryYear UTF8String], NULL, 2);
		int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
		int intDay=strtol([binaryDay UTF8String], NULL, 2);
		NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
		//SCRID-156: Resoled the issue of transfer the week, for example, should transfer "1" to "01". joko 2012-01-05
		NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
		if([tmpStringWeek length] < 2)
		{
			NSString *tmpZeroStringWeek = @"0";
			tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
		}
		yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
		//SCRID-156:end
		yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
		
		NSString *yearWeekDaySN = [cameraSN substringFromIndex:3];
		yearWeekDaySN = [yearWeekDaySN substringToIndex:4];
		
		if(![yearWeekDaySN isEqualToString:yearWeekDay])
		{
			failCounter++;
			NSLog(@"Check Camera SN, Year-Week-Day Fail");
			faiMsg = [faiMsg stringByAppendingString:@"; Year-Week-Day"];
		}
        
        /************* 3. Check SSSS, 3 ID value ****************/
        NSString *ssss = [arrayNVM objectAtIndex:22];
        ssss = [ssss stringByAppendingString:[arrayNVM objectAtIndex:21]];
        ssss = [ssss stringByAppendingString:[arrayNVM objectAtIndex:20]];
        int intSsss=strtol([ssss UTF8String], NULL, 16);
        
        NSString *ssssSN = [cameraSN substringFromIndex:7];
        ssssSN = [ssssSN substringToIndex:4];
        int intSsssSN=[ToolFun change34BasedtoDecimal:ssssSN];
        
        if(intSsss != intSsssSN)
        {
            failCounter++;
            NSLog(@"Check Camera SN, SSSS Fail");
            faiMsg = [faiMsg stringByAppendingString:@"; SSSS Fail"];
        }
        
        /********************************************************************************/
        /*DCRID-140: convert Unit NVM Data to Camera SN. Judith 2011-10-24*/
        
        NSString *UnitSSSS=@"";
        NSString *UnitSSSS1 = @"";
        NSString *UnitSSSS2 = @"";
        NSString *UnitSSSS3 = @"";
        NSString *UnitSSSS4 = @"";
        
        int intTmpChar4 = intSsss / 39304;	//39304=34*34*34
        if(intTmpChar4 > 33)
        {
            UnitSSSS4 = @"&";
            UnitSSSS3 = @"&";
            UnitSSSS2 = @"&";
            UnitSSSS1 = @"&";
        }
        else
        {
            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
            int intYuShuChar3 = intSsss % 39304;		//39304=34*34*34
            int intShangChar3 = intYuShuChar3 / 1156;	//1156 = 34*34
            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
            
            int intYuShuChar2 = intYuShuChar3 % 1156;
            int intShangChar2 = intYuShuChar2 / 34;
            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
            
            int intYuShuChar1 = intYuShuChar2 % 34;
            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
        }
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS4];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS3];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS2];
        UnitSSSS = [UnitSSSS stringByAppendingString:UnitSSSS1];
        
        NSString *UnitPPP = @"";
        NSString *UnitEEEER = @"";
        
        if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"1"])//DN8 F9V61
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V61"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"2"])//DN8 F9V62
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V62"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"3"])//DN8 F9V63
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V63"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"4"])//DN8 F9V64
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V64"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"5"])//DN8 F9V65
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V65"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"6"])//DN8 F9V66
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V66"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"7"])//DN8 F9V67
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V67"];
        }
        else if([binaryIntegrator isEqualToString:@"0010"]&&[hexConfig isEqualToString:@"8"])//DN8 F9V68
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN8"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V68"];
        }
        //==============================================================================================
        else if([binaryIntegrator isEqualToString:@"0011"]&&[hexConfig isEqualToString:@"1"])//DN3 F9V61
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN3"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V61"];
        }
        else if([binaryIntegrator isEqualToString:@"0011"]&&[hexConfig isEqualToString:@"2"])//DN3 F9V62
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN3"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V62"];
        }
        else if([binaryIntegrator isEqualToString:@"0011"]&&[hexConfig isEqualToString:@"3"])//DN3 F9V63
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DN3"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"F9V63"];
        }
        //==============================================================================================
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"1"])//DNL FF9L1
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L1"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"2"])//DNL FF9L2
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L2"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"3"])//DNL FF9L3
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L3"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"4"])//DNL FF9L4
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L4"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"5"])//DNL FF9L5
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L5"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"6"])//DNL FF9L6
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L6"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"7"])//DNL FF9L7
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L7"];
        }
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"8"])//DNL FF9L8
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L8"];
        }
    /********************************add by bruce begin 2013-06-20********************************/   
        else if([binaryIntegrator isEqualToString:@"0100"]&&[hexConfig isEqualToString:@"9"])//DNL FF9L9
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"DNL"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L9"];
        }
    /********************************add by bruce end 2013-06-20********************************/   
        //==============================================================================================
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"1"])//F6D FF9L1
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L1"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"2"])//F6D FF9L2
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L2"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"3"])//F6D FF9L3
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L3"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"4"])//F6D FF9L4
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L4"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"5"])//F6D FF9L5
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L5"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"6"])//F6D FF9L6
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L6"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"7"])//F6D FF9L7
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L7"];
        }
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"8"])//F6D FF9L8
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L8"];
        }
          /********************************add by bruce begin 2013-06-20********************************/  
        else if([binaryIntegrator isEqualToString:@"0101"]&&[hexConfig isEqualToString:@"9"])//F6D FF9L9
        {
            UnitPPP = [UnitPPP stringByAppendingString:@"F6D"];
            UnitEEEER = [UnitEEEER stringByAppendingString:@"FF9L9"];
        }
          /********************************add by bruce end 2013-06-20********************************/  
        else
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"There is no corresponding PPP and EEEER "];
        
        
        NSString *NunitSN=@". UnitCameraSN:";
        NunitSN = [NunitSN stringByAppendingString:UnitPPP];
        NunitSN = [NunitSN stringByAppendingString:yearWeekDay];
        NunitSN = [NunitSN stringByAppendingString:UnitSSSS];
        NunitSN = [NunitSN stringByAppendingString:UnitEEEER];
        
        /*SCRID-142: Add Checksum to Camera SN. 2011-10-26 Lucky*/
        NSString *tmp1 = [NunitSN stringByReplacingOccurrencesOfString:@". UnitCameraSN:" withString:@""];
        NunitSN = [NunitSN stringByAppendingString: [self getCheckSum:tmp1]];
        /*SCRID-142:end*/
        
        faiMsg = [faiMsg stringByAppendingString:NunitSN];
        
        
        NSString *passLog = @"Pass. ";
        passLog = [passLog stringByAppendingString:NunitSN];
        
        // add by justin to compare unit cameraSN which get from SFC of back camera 2013-11-11
        if([passLog rangeOfString:cameraSN].length <= 0)
        {
            failCounter++;
        }
        // justin end
        if(failCounter >= 1)
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :faiMsg];
        else
            [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :passLog];
    }
	/*DCRID-140:end*/
	
}


//update by kevin 0331 start
+(void)CompareCameraSN2:(NSDictionary *)dictKeyDefined
{
    NSString *mReferenceBufferName = nil;
    NSString *mPrefix = nil;
    NSString *mPostfix = nil;
    NSString *mIsFrontCamera = @"No";
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"IsFrontCamera"])
		{
			mIsFrontCamera = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    NSString *cameraSN = @"";
    
    if([mIsFrontCamera boolValue])
		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strFCMS"];
	else
		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strBCMS"];
    
    //cameraSN = @"DN83515AZ92FQPT3Z";
    
	if([cameraSN length] < 17)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"The Length of Camera SN is Error"];
		return;
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	NSString *cameraBufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([cameraBufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
		return;
	}
    
    NSMutableString *mutaBufferValue = [NSMutableString stringWithString:cameraBufferValue];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0)
    {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//End added
    
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
    if([arrayNVM count] <= 24)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 24"];
        return;
    }
    if([mIsFrontCamera boolValue])
    {
        NSDictionary *cameraDic = [[NSDictionary dictionaryWithContentsOfFile:@"/camera.plist"] objectForKey:@"frontCamera"];
        NSString *hexPPP = [arrayNVM objectAtIndex:3]; //0x02
        NSString *hexEEEE = [arrayNVM objectAtIndex:3];
        hexEEEE = [hexEEEE substringToIndex:1];
        /*******PPP & EEEE *******/
        if([[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP] == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"PPP value fail,can't find the PPP value in the spec"];
            return;
        }
        if([[cameraDic objectForKey:@"EEEE"] objectForKey:hexEEEE] == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"EEEE value fail,can't find the EEEE value in the spec"];
            return;
        }
        NSArray *EEEE = [[cameraDic objectForKey:@"EEEE"] objectForKey:hexEEEE];
        NSArray *PPP = [[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP];
        
        NSString *hexR = [arrayNVM objectAtIndex:18];
        int decR = (int)strtol([hexR UTF8String], NULL, 16);
        //add by kevin 20140429
        if(decR==6)
        {
            hexR=4;
        }
        //add by kevin 20140429
        NSString *R = [NSString stringWithFormat:@"%d",decR];
        R = [R substringFromIndex:[R length]-1];
        
        /*******Year & Week & Day*******/
        //Get the Year binary value
        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
        binaryYear = [binaryYear substringFromIndex:4];
        
        //Get the Week binary value
        NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
        binaryWeek = [binaryWeek substringFromIndex:2];
        
        //Get the Day binary value
        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
        binaryDay = [binaryDay substringFromIndex:5];
        
        //Change the year, weeek, day binary value to decimal value and combine them to a string
        int intYear=strtol([binaryYear UTF8String], NULL, 2);
        int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
        int intDay=strtol([binaryDay UTF8String], NULL, 2);
        NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
        //If week only one digit, add one zero in front of the digit
        NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
        if([tmpStringWeek length] < 2)
        {
            NSString *tmpZeroStringWeek = @"0";
            tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
        }
        yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
        yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
        
        /*******SSSS*******/
        NSString *hexSSSS = [arrayNVM objectAtIndex:24];
        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:23]];
        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:22]];
        int intSSSS=strtol([hexSSSS UTF8String], NULL, 16);
        
        NSString *SSSS=@"";
        NSString *UnitSSSS1 = @"";
        NSString *UnitSSSS2 = @"";
        NSString *UnitSSSS3 = @"";
        NSString *UnitSSSS4 = @"";
        
        int intTmpChar4 = intSSSS / 39304;	//39304=34*34*34
        if(intTmpChar4 > 33)
        {
            UnitSSSS4 = @"&";
            UnitSSSS3 = @"&";
            UnitSSSS2 = @"&";
            UnitSSSS1 = @"&";
        }
        else
        {
            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
            int intYuShuChar3 = intSSSS % 39304;		//39304=34*34*34
            int intShangChar3 = intYuShuChar3 / 1156;	//1156 =34*34
            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
            
            int intYuShuChar2 = intYuShuChar3 % 1156;
            int intShangChar2 = intYuShuChar2 / 34;
            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
            
            int intYuShuChar1 = intYuShuChar2 % 34;
            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
        }
        SSSS = [SSSS stringByAppendingString:UnitSSSS4];
        SSSS = [SSSS stringByAppendingString:UnitSSSS3];
        SSSS = [SSSS stringByAppendingString:UnitSSSS2];
        SSSS = [SSSS stringByAppendingString:UnitSSSS1];
        
        /****get the SN from NVM data*****/
        
        NSMutableArray * NVMCameraSN = [NSMutableArray array];
        NSString *strNVMCameraSN = @"";
        NSString *strEEEE = nil;
        NSString *strPPP = nil;
        NSString *checkSum = nil;
        
        for(int i = 0; i < [EEEE count]; i++)
        {
            strEEEE = [EEEE objectAtIndex:i];
            for(int j = 0; j < [PPP count]; j++)
            {
                strPPP = [PPP objectAtIndex:j];
                strNVMCameraSN = [strNVMCameraSN stringByAppendingFormat:@"%@%@%@%@%@",strPPP,yearWeekDay,SSSS,strEEEE,R];
                checkSum = [self getCheckSum:strNVMCameraSN];
                strNVMCameraSN = [strNVMCameraSN stringByAppendingString:checkSum];
                [NVMCameraSN addObject:strNVMCameraSN];
                strNVMCameraSN = @"";
            }
        }
        if([NVMCameraSN containsObject:cameraSN])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:cameraSN];
            return;
        }
        else
        {
            NSString *failMes = @"";
            for(int i = 0; i < [NVMCameraSN count]; i++)
            {
                failMes = [failMes stringByAppendingString:[NVMCameraSN objectAtIndex:i]];
                failMes = [failMes stringByAppendingString:@","];
            }
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:failMes];
            return;
        }
    }
    else
    {
        NSDictionary *cameraDic = [[NSDictionary dictionaryWithContentsOfFile:@"/camera.plist"] objectForKey:@"backCamera"];
        NSString *hexPPP = [arrayNVM objectAtIndex:3]; //0x2
        //NSString *hexEEEER = [arrayNVM objectAtIndex:18];//0x11
        NSString *hexEEEER = [arrayNVM objectAtIndex:19];//Update by kevin 20150331 base on SL BC ERS 0x12
        // hexPPP = [hexPPP substringToIndex:1];
        hexEEEER = [hexEEEER substringFromIndex:1];
        /*******PPP & EEEE *******/
        if([[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP] == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"PPP value fail,can't find the PPP value in the spec"];
            return;
        }
        NSString *PPP = [[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP];
        if([[cameraDic objectForKey:@"EEEER"] objectForKey:PPP] == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"No EEEER value for this PPP value"];
            return;
        }
        NSString *EEEER = [[[cameraDic objectForKey:@"EEEER"] objectForKey:PPP] objectForKey:hexEEEER];
        if(EEEER == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"EEEER value fail,can't find the EEEER value in the spec"];
            return;
        }
        
        /****Year & Week & Day ****/
        //NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
        binaryYear = [binaryYear substringFromIndex:4];
        //NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
        NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
        binaryWeek = [binaryWeek substringFromIndex:2];
        //NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:22]];
        binaryDay = [binaryDay substringFromIndex:4];
		int intYear=strtol([binaryYear UTF8String], NULL, 2);
		int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
		int intDay=strtol([binaryDay UTF8String], NULL, 2);
		NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
		NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
		if([tmpStringWeek length] < 2)
		{
			NSString *tmpZeroStringWeek = @"0";
			tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
		}
		yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
		yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
        
        /****SSSS****/
        //        NSString *hexSSSS = [arrayNVM objectAtIndex:24];
        //        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:23]];
        //        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:22]];
        NSString *hexSSSS = [arrayNVM objectAtIndex:25];
        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:24]];
        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:23]];
        int intSsss=strtol([hexSSSS UTF8String], NULL, 16);
        
        NSString *SSSS=@"";
        NSString *UnitSSSS1 = @"";
        NSString *UnitSSSS2 = @"";
        NSString *UnitSSSS3 = @"";
        NSString *UnitSSSS4 = @"";
        
        int intTmpChar4 = intSsss / 39304;	//39304=34*34*34
        if(intTmpChar4 > 33)
        {
            UnitSSSS4 = @"&";
            UnitSSSS3 = @"&";
            UnitSSSS2 = @"&";
            UnitSSSS1 = @"&";
        }
        else
        {
            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
            int intYuShuChar3 = intSsss % 39304;		//39304=34*34*34
            int intShangChar3 = intYuShuChar3 / 1156;	//1156 = 34*34
            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
            
            int intYuShuChar2 = intYuShuChar3 % 1156;
            int intShangChar2 = intYuShuChar2 / 34;
            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
            
            int intYuShuChar1 = intYuShuChar2 % 34;
            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
        }
        SSSS = [SSSS stringByAppendingString:UnitSSSS4];
        SSSS = [SSSS stringByAppendingString:UnitSSSS3];
        SSSS = [SSSS stringByAppendingString:UnitSSSS2];
        SSSS = [SSSS stringByAppendingString:UnitSSSS1];
        /****get the SN from NVM data*****/
        NSString *NVMCameraSN = [NSString stringWithFormat:@"%@%@%@%@",PPP,yearWeekDay,SSSS,EEEER];
        NSString *checkSum = [self getCheckSum:NVMCameraSN];
        NVMCameraSN = [NVMCameraSN stringByAppendingString:checkSum];
        
        if([NVMCameraSN isEqualToString:cameraSN])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:NVMCameraSN];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:NVMCameraSN];
            return;
        }
    }
    
}
//update by kevin 0331 end
//End
//+(void)CompareCameraSN2:(NSDictionary *)dictKeyDefined
//{
//    NSString *mReferenceBufferName = nil;
//    NSString *mPrefix = nil;
//    NSString *mPostfix = nil;
//    NSString *mIsFrontCamera = @"No";
//    for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//        
//		if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"Prefix"])
//		{
//			mPrefix = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"Postfix"])
//		{
//			mPostfix = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"IsFrontCamera"])
//		{
//			mIsFrontCamera = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//    
//    NSString *cameraSN = @"";
//    
//    if([mIsFrontCamera boolValue])
//		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strFCMS"];
//	else
//		cameraSN = [TestItemManage getSFCValue:dictKeyDefined :@"strBCMS"];
//    
//    //cameraSN = @"DN83515AZ92FQPT3Z";
//    
//	if([cameraSN length] < 17)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"The Length of Camera SN is Error"];
//		return;
//	}
//	
//	if (mReferenceBufferName==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
//		return;
//	}
//	
//	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//	if (mReferenceBufferValue==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
//		return;
//	}
//	
//	NSString *cameraBufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
//	if([cameraBufferValue length] <= 0)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
//		return;
//	}
//    
//    NSMutableString *mutaBufferValue = [NSMutableString stringWithString:cameraBufferValue];
//    
//    NSRange preRange ;
//    NSRange postRange ;
//    do
//    {
//        preRange = [mutaBufferValue rangeOfString:@"\n"];
//        postRange = [mutaBufferValue rangeOfString:@":"];
//        if(postRange.location >2529) //delete the last
//        {
//            [mutaBufferValue deleteCharactersInRange:preRange];
//            break;
//        }
//        preRange.length = postRange.location - preRange.location+1;
//        [mutaBufferValue deleteCharactersInRange:preRange];
//    }while (preRange.length >0);
//    
//    while ([mutaBufferValue rangeOfString:@" "].length > 0)
//    {
//        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
//    }
//    
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
//	//End added
//    
//	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
//	
//	NSString *oneZero = @"0";
//	for(int i=0; i<[arrayNVM count]; i++)
//	{
//		NSString * tmp = [arrayNVM objectAtIndex:i];
//		if([tmp length] < 2)
//		{
//			tmp = [oneZero stringByAppendingString:tmp];
//			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
//		}
//	}
//	NSLog(@"after add 0, NVM =%@", arrayNVM);
//	
//    if([arrayNVM count] <= 24)
//    {
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 24"];
//        return;
//    }
//    if([mIsFrontCamera boolValue])
//    {
//        NSDictionary *cameraDic = [[NSDictionary dictionaryWithContentsOfFile:@"/camera.plist"] objectForKey:@"frontCamera"];
//        NSString *hexPPP = [arrayNVM objectAtIndex:3]; //0x02
//        NSString *hexEEEE = [arrayNVM objectAtIndex:3];
//        hexEEEE = [hexEEEE substringToIndex:1];
//        /*******PPP & EEEE *******/
//        if([[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP] == nil)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"PPP value fail,can't find the PPP value in the spec"];
//            return;
//        }
//        if([[cameraDic objectForKey:@"EEEE"] objectForKey:hexEEEE] == nil)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"EEEE value fail,can't find the EEEE value in the spec"];
//            return;
//        }
//        NSArray *EEEE = [[cameraDic objectForKey:@"EEEE"] objectForKey:hexEEEE];
//        NSArray *PPP = [[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP];
//        
//        NSString *hexR = [arrayNVM objectAtIndex:18];
//        int decR = (int)strtol([hexR UTF8String], NULL, 16);
//        //add by kevin 20140429
//        if(decR==6)
//        {
//            hexR=4;
//        }
//        //add by kevin 20140429
//        NSString *R = [NSString stringWithFormat:@"%d",decR];
//        R = [R substringFromIndex:[R length]-1];
//        
//        /*******Year & Week & Day*******/
//        //Get the Year binary value
//        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
//        binaryYear = [binaryYear substringFromIndex:4];
//        
//        //Get the Week binary value
//        NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
//        binaryWeek = [binaryWeek substringFromIndex:2];
//        
//        //Get the Day binary value
//        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
//        binaryDay = [binaryDay substringFromIndex:5];
//        
//        //Change the year, weeek, day binary value to decimal value and combine them to a string
//        int intYear=strtol([binaryYear UTF8String], NULL, 2);
//        int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
//        int intDay=strtol([binaryDay UTF8String], NULL, 2);
//        NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
//        //If week only one digit, add one zero in front of the digit
//        NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
//        if([tmpStringWeek length] < 2)
//        {
//            NSString *tmpZeroStringWeek = @"0";
//            tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
//        }
//        yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
//        yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
//        
//        /*******SSSS*******/
//        NSString *hexSSSS = [arrayNVM objectAtIndex:24];
//        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:23]];
//        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:22]];
//        int intSSSS=strtol([hexSSSS UTF8String], NULL, 16);
//        
//        NSString *SSSS=@"";
//        NSString *UnitSSSS1 = @"";
//        NSString *UnitSSSS2 = @"";
//        NSString *UnitSSSS3 = @"";
//        NSString *UnitSSSS4 = @"";
//        
//        int intTmpChar4 = intSSSS / 39304;	//39304=34*34*34
//        if(intTmpChar4 > 33)
//        {
//            UnitSSSS4 = @"&";
//            UnitSSSS3 = @"&";
//            UnitSSSS2 = @"&";
//            UnitSSSS1 = @"&";
//        }
//        else
//        {
//            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
//            int intYuShuChar3 = intSSSS % 39304;		//39304=34*34*34
//            int intShangChar3 = intYuShuChar3 / 1156;	//1156 =34*34
//            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
//            
//            int intYuShuChar2 = intYuShuChar3 % 1156;
//            int intShangChar2 = intYuShuChar2 / 34;
//            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
//            
//            int intYuShuChar1 = intYuShuChar2 % 34;
//            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
//        }
//        SSSS = [SSSS stringByAppendingString:UnitSSSS4];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS3];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS2];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS1];
//        
//        /****get the SN from NVM data*****/
//        
//        NSMutableArray * NVMCameraSN = [NSMutableArray array];
//        NSString *strNVMCameraSN = @"";
//        NSString *strEEEE = nil;
//        NSString *strPPP = nil;
//        NSString *checkSum = nil;
//        
//        for(int i = 0; i < [EEEE count]; i++)
//        {
//            strEEEE = [EEEE objectAtIndex:i];
//            for(int j = 0; j < [PPP count]; j++)
//            {
//                strPPP = [PPP objectAtIndex:j];
//                strNVMCameraSN = [strNVMCameraSN stringByAppendingFormat:@"%@%@%@%@%@",strPPP,yearWeekDay,SSSS,strEEEE,R];
//                checkSum = [self getCheckSum:strNVMCameraSN];
//                strNVMCameraSN = [strNVMCameraSN stringByAppendingString:checkSum];
//                [NVMCameraSN addObject:strNVMCameraSN];
//                strNVMCameraSN = @"";
//            }
//        }
//        if([NVMCameraSN containsObject:cameraSN])
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:cameraSN];
//            return;
//        }
//        else
//        {
//            NSString *failMes = @"";
//            for(int i = 0; i < [NVMCameraSN count]; i++)
//            {
//                failMes = [failMes stringByAppendingString:[NVMCameraSN objectAtIndex:i]];
//                failMes = [failMes stringByAppendingString:@","];
//            }
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:failMes];
//            return;
//        }
//    }
//    else
//    {
//        NSDictionary *cameraDic = [[NSDictionary dictionaryWithContentsOfFile:@"/camera.plist"] objectForKey:@"backCamera"];
//        NSString *hexPPP = [arrayNVM objectAtIndex:3]; //0x2
//        NSString *hexEEEER = [arrayNVM objectAtIndex:18];
//       // hexPPP = [hexPPP substringToIndex:1];
//        hexEEEER = [hexEEEER substringFromIndex:1];
//        /*******PPP & EEEE *******/
//        if([[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP] == nil)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"PPP value fail,can't find the PPP value in the spec"];
//            return;
//        }
//        NSString *PPP = [[cameraDic objectForKey:@"PPP"] objectForKey:hexPPP];
//        if([[cameraDic objectForKey:@"EEEER"] objectForKey:PPP] == nil)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"No EEEER value for this PPP value"];
//            return;
//        }
//        NSString *EEEER = [[[cameraDic objectForKey:@"EEEER"] objectForKey:PPP] objectForKey:hexEEEER];
//        if(EEEER == nil)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"EEEER value fail,can't find the EEEER value in the spec"];
//            return;
//        }
//        
//        /****Year & Week & Day ****/
//        NSString *binaryYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
//        binaryYear = [binaryYear substringFromIndex:4];
//        NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
//        binaryWeek = [binaryWeek substringFromIndex:2];
//        NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
//        binaryDay = [binaryDay substringFromIndex:4];
//		int intYear=strtol([binaryYear UTF8String], NULL, 2);
//		int intWeek=strtol([binaryWeek UTF8String], NULL, 2);
//		int intDay=strtol([binaryDay UTF8String], NULL, 2);
//		NSString *yearWeekDay = [NSString stringWithFormat:@"%d",intYear];
//		NSString *tmpStringWeek = [NSString stringWithFormat:@"%d",intWeek];
//		if([tmpStringWeek length] < 2)
//		{
//			NSString *tmpZeroStringWeek = @"0";
//			tmpStringWeek = [tmpZeroStringWeek stringByAppendingString:tmpStringWeek];
//		}
//		yearWeekDay = [yearWeekDay stringByAppendingString:tmpStringWeek];
//		yearWeekDay = [yearWeekDay stringByAppendingString:[NSString stringWithFormat:@"%d",intDay]];
//        
//        /****SSSS****/
//        NSString *hexSSSS = [arrayNVM objectAtIndex:24];
//        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:23]];
//        hexSSSS = [hexSSSS stringByAppendingString:[arrayNVM objectAtIndex:22]];
//        int intSsss=strtol([hexSSSS UTF8String], NULL, 16);
//        
//        NSString *SSSS=@"";
//        NSString *UnitSSSS1 = @"";
//        NSString *UnitSSSS2 = @"";
//        NSString *UnitSSSS3 = @"";
//        NSString *UnitSSSS4 = @"";
//        
//        int intTmpChar4 = intSsss / 39304;	//39304=34*34*34
//        if(intTmpChar4 > 33)
//        {
//            UnitSSSS4 = @"&";
//            UnitSSSS3 = @"&";
//            UnitSSSS2 = @"&";
//            UnitSSSS1 = @"&";
//        }
//        else
//        {
//            UnitSSSS4 = [ToolFun changeDecimalto34:intTmpChar4];
//            int intYuShuChar3 = intSsss % 39304;		//39304=34*34*34
//            int intShangChar3 = intYuShuChar3 / 1156;	//1156 = 34*34
//            UnitSSSS3 = [ToolFun changeDecimalto34:intShangChar3];
//            
//            int intYuShuChar2 = intYuShuChar3 % 1156;
//            int intShangChar2 = intYuShuChar2 / 34;
//            UnitSSSS2 = [ToolFun changeDecimalto34:intShangChar2];
//            
//            int intYuShuChar1 = intYuShuChar2 % 34;
//            UnitSSSS1 = [ToolFun changeDecimalto34:intYuShuChar1];
//        }
//        SSSS = [SSSS stringByAppendingString:UnitSSSS4];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS3];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS2];
//        SSSS = [SSSS stringByAppendingString:UnitSSSS1];
//        /****get the SN from NVM data*****/
//        NSString *NVMCameraSN = [NSString stringWithFormat:@"%@%@%@%@",PPP,yearWeekDay,SSSS,EEEER];
//        NSString *checkSum = [self getCheckSum:NVMCameraSN];
//        NVMCameraSN = [NVMCameraSN stringByAppendingString:checkSum];
//        
//        if([NVMCameraSN isEqualToString:cameraSN])
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:NVMCameraSN];
//            return;
//        }
//        else
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:NVMCameraSN];
//            return;
//        }
//    }
//    
//}
/*SCRID-142: Add Checksum to Camera SN. 2011-10-26 Lucky*/
+(NSString *)getCheckSum:(NSString *)unitSN
{
	int oddSum = 0;
	int evenSum = 0;
	int sum = 0;
	int remainder = 0;
	NSString *checkSum = @"";
	
	for(int i=0; i<[unitSN length]; i+=2)
	{
		evenSum+=[ ToolFun change34BasedtoDecimalByCharacter:[ [ unitSN substringFromIndex:i] substringToIndex:1 ] ];
	}
	
	for(int i=1; i<[unitSN length]; i+=2)
	{
		oddSum+=[ ToolFun change34BasedtoDecimalByCharacter:[ [ unitSN substringFromIndex:i] substringToIndex:1 ] ];
	}
	
	sum = evenSum + oddSum * 3;
	remainder = sum % 34;
	
	if( remainder == 0)
		checkSum = [NSString stringWithFormat:@"%d",remainder];
    else
        checkSum = [ToolFun changeDecimalto34BasedBydata:(34-remainder)];
	
	return checkSum;
}
/*SCRID-142:end*/

+(void)CompareGrapeColWithHSG:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
    NSString *mPrefix=nil ;
    NSString *mPostfix=nil ;
    
    NSString *mReferenceBufferName1=nil ;
    NSString *mReferenceBufferName2=nil ;
    
    
    NSString *mBufferName=nil    ;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
        {
            mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName1==nil ||mReferenceBufferName2==nil||
        mPrefix==nil ||
        mPostfix==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    
    NSString *mReferenceBufferValue1, *mReferenceBufferValue2;
    
    mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    if (mReferenceBufferValue1==nil||mReferenceBufferValue2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    NSString *strFindHsgSN = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue1 Prefix
                                                                :mPrefix Postfix
                                                                :mPostfix] ;
    
    strFindHsgSN=[strFindHsgSN stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (strFindHsgSN==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue1] ;
        return  ;
    }
    
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strFindHsgSN] ;
    
    
    //1.get SFC HSG_SN COl
    
    NSRange hsgSNRange={11,4};
    NSString* hsgColStr=[strFindHsgSN substringWithRange:hsgSNRange];//get from
    
    
    NSString* hsgWhiteEEEECode=@"GJJJ,GJJF";
    NSString* hsgBlackEEEECode=@"GK9H,GK57";
    NSString* hsgRoseGoldEEEECode=@"GY6T,GY6R";
    NSString* hsgCashMereEEECode=@"GJJG,GJJK";
    
    
    NSString* tmWhiteEEEECode=@"GCPG,GR1C,GJJL,H1D9,H1DD";//added H1D9 H1DD
    NSString* tmBlackEEEECode=@"GR1D,GL7P,GL7Q,H1DC,H1DF";//added H1DC H1DF
    
    
    NSRange tmColRange={11,4};
    NSString* tmColStr=[mReferenceBufferValue2 substringWithRange:tmColRange];
    
    
    //    NSString* tmColStr=@"GCPG";
    
    //2 TM SN COl
    if ([hsgWhiteEEEECode rangeOfString:hsgColStr].length>0)//white
    {
        if ([tmWhiteEEEECode rangeOfString:tmColStr].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
        }
    }
    else if ([hsgBlackEEEECode rangeOfString:hsgColStr].length>0)//black
    {
        if ([tmBlackEEEECode rangeOfString:tmColStr].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]]  ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL: [NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
        };
    }
    else  if ([hsgRoseGoldEEEECode rangeOfString:hsgColStr].length>0)//Rose Gold
    {
        if ([tmWhiteEEEECode rangeOfString:tmColStr].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
        };
    }
    
    else  if ([hsgCashMereEEECode rangeOfString:hsgColStr].length>0)//CASH MERE
    {
        if ([tmWhiteEEEECode rangeOfString:tmColStr].length>0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]]  ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]]  ;
        };
    }
    else
    {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"hsgColEEEE:%@ : tmColEEEE:%@",hsgColStr,tmColStr]] ;
    }
    
    
}

+(void)ParseCompareHSGColorWithDCLr:(NSDictionary*)dictKeyDefined
{
    //key parse
    NSString *mTestItemName=nil        ;
    NSString *mPrefix=nil ;
    NSString *mPostfix=nil ;
    
    NSString *mReferenceBufferName1=nil ;
    NSString *mReferenceBufferName2=nil ;
    
    
    NSString *mBufferName=nil    ;
    
    
    NSString* hsgWhiteEEEECode=@"GJJJ,GJJF";
    NSString* hsgBlackEEECode=@"GK9H,GK57";
    
    NSString* hsgRoseGoldEEECode=@"GY6T,GY6R";
    
    NSString* hsgCashMereEEECode=@"GJJG,GJJK";
    
    
    
    if (dictKeyDefined==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
        return ;
    }
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
        {
            mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName1==nil ||mReferenceBufferName2==nil||
        mPrefix==nil ||
        mPostfix==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    NSString *mReferenceBufferValue1 ,*mReferenceBufferValue2;
    mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    
    
    
    if (mReferenceBufferValue1==nil || mReferenceBufferValue2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue2 Prefix
                                                           :mPrefix Postfix
                                                           :mPostfix] ;
    
    if (strFind==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue2] ;
        return  ;
    }
    
    
    NSRange hsgSNRange={11,4};
    NSString* hsgColStr=[mReferenceBufferValue1 substringWithRange:hsgSNRange];
    if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
    {
        //       NSString* hsgColStr = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];//get hsg sn
        //        NSString* hsgColStr =@"GJJF";
        
        if(([strFind rangeOfString:@"0x00000200 0x00DADCDB 0x00E4E7E8 0x00000000"].length > 0) &&//white
           ([hsgWhiteEEEECode rangeOfString:hsgColStr].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00B9B7BA 0x00272728 0x00000000"].length > 0) &&//black
                ([hsgBlackEEECode rangeOfString:hsgColStr].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00E1CCB7 0x00E4E7E8 0x00000000"].length > 0) && //cashmrere
                ([hsgCashMereEEECode rangeOfString:hsgColStr].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00E4C1B9 0x00E4E7E8 0x00000000"].length > 0) &&//rose gold
                ([hsgRoseGoldEEECode rangeOfString:hsgColStr].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
        }
    }
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"DCLr:%@,hsgColEEE:%@",strFind,hsgColStr]] ;
    
}

@end
