//
//  NVMIntegrityCheck.h
//  iFTS
//
//  Created by Ray Hsu on 2012/2/8.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ControlCAS140Fun)

+(void)ParseGetCurrentTime:(NSDictionary*)dictKeyDefined;
+(void)ControlCAS140CT:(NSDictionary*)dictKeyDefined;
+(int)setCasDeviceParameterString:(NSString *)aString withDPID:(int)dpid;
+(int)checkCASError:(int)error causedByAction:(NSString *)action;
+(void)fillDeviceTypes;
+(void)fillDeviceOptions;

+(void)debugLog:(NSString *)debugMsg;
+(void)useFirstConfigCalibFilePair:(NSURL *)dirURL;
+(NSString *)casDeviceParameterStringWithDPID:(int)dpid;

+(void)btnGetInfoClicked:(NSDictionary*)dictKeyDefined;
+(int)btnPrepareMeasurement:(NSDictionary*)dictKeyDefined;

+(int)btnPrepareMeasurement_time:(NSDictionary*)dictKeyDefined;
// make integration time can be adjusted --->add by annie on 2013.7.12
+(int)PrepareMeasurement_IntergrTimer:(NSDictionary*)dictKeyDefined :(NSString *)ExpoTimer;

+(int)btnMeasure:(NSDictionary*)dictKeyDefined;
+(void)ParseDivideTwoBuffer:(NSDictionary*)dictKeyDefined;

@end
