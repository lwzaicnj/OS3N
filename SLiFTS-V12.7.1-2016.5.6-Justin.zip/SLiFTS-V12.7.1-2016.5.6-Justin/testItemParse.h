//
//  testItemParse.h
//  qt_simulator
//
//  Created by diags on 2/28/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CommManage.h"
#import "UartComm.h"
#import "keysDefine.h"
#import "testItemManage.h"
#import "toolFun.h"
#import "scriptParse.h"


/*
enum TestResutStatus
{
	RESULT_FOR_FAIL =0,
	RESULT_FOR_PASS =1,
	RESULT_FOR_COF= 2 ,
	RESULT_FOR_BYPASS=3 ,
	RESULT_FOR_OTHER=4,
	RESULT_FOR_DEFINE =RESULT_FOR_PASS , 
} ; 

enum UnitStatus
{
	UnitStatus_FOR_IBOOT,
	UnitStatus_FOR_DIAGS,
};
*/

@interface TestItemParse : NSObject {

}
+(bool)testItemParseInit ;
+(void)testItemParseRelease;
+(bool)checkDeviceNumber ; //check script unit count is equal to nandkdp count.
+(bool)performParseFunction:(NSDictionary*)dictParam ;
+(NSString*)getDeviceID:(NSString*)mDeviceType :(NSDictionary*)dictParam ;
+(bool)checkWhetherByPassWithMesa:(NSDictionary*)dictKeyDefined ;
+(bool)UseBarcodeToCheckWhetherByPassMesa:(NSDictionary*)dictKeyDefined ;
+(CommManage*)getCommManage ;
//comm function list
+(bool)SendData:(NSDictionary*)dictKeyDefined:(NSString*)sendBuffer:(NSString*)strPostFix;
+(bool)CheckReceDataIsComplete:(NSDictionary*)dictKeyDefined;
+(NSString*)ReceData:(NSDictionary*)dictKeyDefined ;

+(bool)closeCurrPort:(NSDictionary*)dictKeyDefined ;
+(bool)openCurrPort:(NSDictionary*)dictKeyDefined ;
//add by giga 10.9.2010
+(NSString*)getCurrPort:(NSDictionary*)dictKeyDefined ;
//end add 

+(NSString*)getCurrUnitDeviceName:(NSDictionary*)dictKeyDefined ;

+(NSString*)CheckUnitSNExist:(NSString*)strDevice :(NSString*)strStatus :(NSString*)command ;
+(bool)CheckUnitExist:(NSString*)strDevice :(NSString*)strStatus;
+(int)GetCurrDUTID:(NSDictionary*)dictKeyDefined ;
//public function
+(void)SetResultAndUIInfo:(NSDictionary*)dictKeyDefined :(enum TestResutStatus)enumResult :(NSString *)strTestResultForUIinfo  ;
+(bool)checkWhetherByPass:(NSDictionary*)dictKeyDefined ;
/*SCRID:62 add by Giga for new CB write*/
+(NSData*)ReceDataAsNSData:(NSDictionary*)dictKeyDefined ;
+(bool)SendDataAsNSData:(NSDictionary*)dictKeyDefined:(NSData*)sendBuffer:(NSString*)strEndString ;
/*SCRID:62 end*/
@end
