//
//  CheckHwyX15Function.h
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CheckHwyX15Function)

+(void)CheckHwyX15:(NSDictionary*)dictKeyDefined;

@end
