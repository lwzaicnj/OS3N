/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseMagnetFunction.h 
 | $Author: Evan						$Revision:: 1               
 | CREATED: 2010.12.10                  $Modtime::  08:43     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
  
 */
//add by Helen for get config 2011-01-28
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

#import "StringParseFuncation.h"
#import "Pudding.h"

@interface TestItemParse(ParseConfig)

+(void)ParseConfig:(NSDictionary*)dictKeyDefined ;

@end
