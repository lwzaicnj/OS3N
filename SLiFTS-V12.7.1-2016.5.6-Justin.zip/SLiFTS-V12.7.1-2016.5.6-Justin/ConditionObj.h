/*                                        $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 22 Feb. 2010 
 * first implementation
 * SCRID-66: Change prox cal to three fixtures and three UI.
 */

#import <Cocoa/Cocoa.h>
#import "UICommon.h"


@interface ConditionObj : NSObject {
	NSCondition* conditionObj;
	enum FAILTYPE mFailType;

}
-(NSCondition*)getConditionObj;
-(void)initConditionObj;
-(void)deallocConditionObj;

-(void)CheckUUTPlugin:(NSDictionary*) dictKeyDefined;
//henry add 2011-01-21
-(enum FAILTYPE)getFailType; //henry added 2011-01-22
-(void)setWrongUnitBgdColor:(NSDictionary*)dictKeyDefined; //henry added 2011-02-09

@end
