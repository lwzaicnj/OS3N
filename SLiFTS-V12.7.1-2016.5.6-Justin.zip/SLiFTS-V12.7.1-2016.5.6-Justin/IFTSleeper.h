//
//  IFTSleeper.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 10/5/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface IFTSleeper : NSObject {
}

//returns an autoreleased sleeper instance
+(IFTSleeper*)sleeper;
-(void)sleep:(int)timeInuSeconds;
-(void)sendCommand:(NSString*)duration;

@end
