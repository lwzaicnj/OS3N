//
//  Bounding Module Check.h
//  iFTS
//
//  Created by Foxconn001 on 09-7-21.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(BoundingModuleCheck)

+(void)ParseBoardId:(NSDictionary*)dictKeyDefined ;
+(void)ParseModuleSFCUnit:(NSDictionary*)dictKeyDefined ;
+(void)ParseModuleRecord:(NSDictionary*)dictKeyDefined;
+(void)ParseModulePing:(NSDictionary*)dictKeyDefined;
+(void)ParseMikey:(NSDictionary*)dictKeyDefined;//add by dsh on 2011-03-17
+(void)ParseModuleBonding:(NSDictionary*)dictKeyDefined;//julian 2011-07-14
+(void)ParseModuleMatch:(NSDictionary*)dictKeyDefined;//julian 2011-07-14
+(void)ParseDMIC:(NSDictionary*)dictKeyDefined;//julian 2012-12-15
@end
