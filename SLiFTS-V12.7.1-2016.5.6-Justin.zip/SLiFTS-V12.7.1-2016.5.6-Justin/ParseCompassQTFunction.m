//
//  ParseCompassQTFunction.h
//  qt
//
//  Created by Henry on 7/19/10.
//  Copyright 2010-2020 . All rights reserved.
//
#import "Pudding.h"
#import "ParseCompassQTFunction.h"


@implementation TestItemParse(ParseCompassQTFunction)

+(void)ParseCompassQT:(NSDictionary*) DictionaryPtr
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//Parser Attributes
	NSString *mTestItemName			= nil	;
	NSString *mUpLimit				= nil	;
	NSString *mLowLimit				= nil	;
	NSString *mPDCAWrite			=@"no"	;
	NSString *mBufferInit			= nil	;
	NSString *mBufferRaw			= nil	;
	NSString *mBufferNorth			= nil	;
	NSString *mBufferSouth			= nil	;
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferInit"])
		{
			mBufferInit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferRaw"])
		{
			mBufferRaw = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNorth"])
		{
			mBufferNorth = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferSouth"])
		{
			mBufferSouth = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mBufferInit==nil||mBufferRaw==nil||mBufferNorth==nil||mBufferSouth==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	// declare int variable to store Uplimit and Lowlimit
	NSInteger x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit;
	NSInteger x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit;
	NSArray *Uplimit	= nil;
	NSArray *Lowlimit	= nil;
	
	// get Upper limit
	Uplimit = [ mUpLimit componentsSeparatedByString:@","];
	if ([Uplimit count]!=3)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Uplimit Occur Error"] ;
	    return  ;
	
	}
	x_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	y_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	z_Diff_UpLimit = [ [Uplimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	// get Lower limit
	Lowlimit = [ mLowLimit componentsSeparatedByString:@","];
	if ([Lowlimit count]!=3)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Lowlimit Occur Error"] ;
	    return  ;
	}
	x_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 0 ] intValue ];
	y_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 1 ] intValue ];
	z_Diff_lowLimit = [ [Lowlimit objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	NSString *mBufferInitValue	= nil;
	NSString *mBufferRawValue	= nil;
	NSString *mBufferNorthValue	= nil;
	NSString *mBufferSouthValue	= nil;
	
	mBufferInitValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferInit] ;
	mBufferRawValue		= [TestItemManage getBufferValue:DictionaryPtr :mBufferRaw] ;
	mBufferNorthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferNorth] ;
	mBufferSouthValue	= [TestItemManage getBufferValue:DictionaryPtr :mBufferSouth] ;
	
	if (mBufferInitValue==nil||mBufferRawValue==nil||mBufferNorthValue==nil||mBufferSouthValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@":"withString:@" "];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@","withString:@" "];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@")"withString:@" "];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"("withString:@" "];
	mBufferInitValue	= [mBufferInitValue stringByReplacingOccurrencesOfString:@"\""withString:@" "];
	
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@":"withString:@" "];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@","withString:@" "];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@")"withString:@" "];
	mBufferRawValue		= [mBufferRawValue stringByReplacingOccurrencesOfString:@"("withString:@" "];
	
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@":"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@","withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@")"withString:@" "];
	mBufferNorthValue	= [mBufferNorthValue stringByReplacingOccurrencesOfString:@"("withString:@" "];
	
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@":"withString:@" "];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@","withString:@" "];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@")"withString:@" "];
	mBufferSouthValue	= [mBufferSouthValue stringByReplacingOccurrencesOfString:@"("withString:@" "];
	
	// Get Data from init buffer value
	NSRange	range;
	range = [mBufferInitValue rangeOfString:@"Sensitivity="];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferInitValue =[ mBufferInitValue substringFromIndex:(NSUInteger)range.location ];
	
	// Get Data from raw buffer value
	range =[mBufferRawValue rangeOfString:@"Z"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferRawValue = [ mBufferRawValue substringFromIndex:(NSUInteger)range.location ];
	
	// Get Data from North buffer value
	range =[mBufferNorthValue rangeOfString:@"Z"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferNorthValue = [ mBufferNorthValue substringFromIndex:(NSUInteger)range.location ];
	
	// Get Data from South buffer value
	range =[mBufferSouthValue rangeOfString:@"Z"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Value from Diag Error!"] ;
		return ;
	}
	mBufferSouthValue = [ mBufferSouthValue substringFromIndex:(NSUInteger)range.location ];
	
	//split data to Array
	
	NSArray *initdata	= nil;
	NSArray *rawdata	= nil;
	NSArray *northData	= nil;
	NSArray *southData	= nil;
	
	initdata	= [mBufferInitValue  componentsSeparatedByString:@" "];
	rawdata		= [mBufferRawValue   componentsSeparatedByString:@" "];
	northData	= [mBufferNorthValue componentsSeparatedByString:@" "];
	southData	= [mBufferSouthValue componentsSeparatedByString:@" "];

	// set subtest items info to PDCA
	int		itemp = -1;
	NSString *strTestValue = nil;
	itemp = strtol([[initdata objectAtIndex:(NSUInteger)1] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_DAC_0x1E":@"DACXsetup":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[initdata objectAtIndex:(NSUInteger)3] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_DAC_0x1E":@"DACYsetup":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[initdata objectAtIndex:(NSUInteger)5] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_DAC_0x1E":@"DACZsetup":nil:nil:strTestValue:nil:IP_NA:nil];
	
	itemp = strtol([[rawdata objectAtIndex:(NSUInteger)5] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x1E":@"RAWSetupx":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[rawdata objectAtIndex:(NSUInteger)7] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x1E":@"RAWSetupy":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[rawdata objectAtIndex:(NSUInteger)9] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x1E":@"RAWSetupz":nil:nil:strTestValue:nil:IP_NA:nil];

	itemp = strtol([[northData objectAtIndex:(NSUInteger)5] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Field_RAW_0x1E":@"RAWtemp1":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[northData objectAtIndex:(NSUInteger)7] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Field_RAW_0x1E":@"RAWx1":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[northData objectAtIndex:(NSUInteger)9] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Field_RAW_0x1E":@"RAWy1":nil:nil:strTestValue:nil:IP_NA:nil];
	
	itemp = strtol([[southData objectAtIndex:(NSUInteger)5] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_OppositeField_RAW_0x1E":@"RAWtemp2":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[southData objectAtIndex:(NSUInteger)7] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_OppositeField_RAW_0x1E":@"RAWx2":nil:nil:strTestValue:nil:IP_NA:nil];
	itemp = strtol([[southData objectAtIndex:(NSUInteger)9] UTF8String],NULL,16);
	strTestValue = [NSString stringWithFormat:@"%d",itemp];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_OppositeField_RAW_0x1E":@"RAWy2":nil:nil:strTestValue:nil:IP_NA:nil];
	
	//get raw data of North and south
	
	int	x_Rawdata_North,y_Rawdata_North,z_Rawdata_North;
	int	x_Rawdata_South,y_Rawdata_South,z_Rawdata_South;
	 
	//this is not good way, better way must to be found 
	NSString *temStrX1, *temStrY1,*temStrZ1,*temStrX2,*temStrY2,*temStrZ2;
	NSInteger iFlagX1=0;
	NSInteger iFlagY1=0;
	NSInteger iFlagZ1=0;
	NSInteger iFlagX2=0;
	NSInteger iFlagY2=0;
	NSInteger iFlagZ2=0;
	
	NSString *ttStr1 =[northData objectAtIndex:(NSUInteger)5];
	NSRange iRange1 = [ttStr1 rangeOfString:@"F" ];
	if(iRange1.location == 2)
	{
		temStrX1	= [[northData objectAtIndex:(NSUInteger)5] stringByReplacingOccurrencesOfString:@"F"withString:@"0"];
		iFlagX1=1;
	}
	else
	{
		temStrX1	= [northData objectAtIndex:(NSUInteger)5];
	}
	
	NSString *ttStr3 =[northData objectAtIndex:(NSUInteger)7];
	NSRange iRange3 = [ttStr3 rangeOfString:@"F" ];
	if(iRange3.location == 2)
	{
		temStrY1	= [[northData objectAtIndex:(NSUInteger)7] stringByReplacingOccurrencesOfString:@"F"withString:@"0"];
		iFlagY1=1;
	}
	else
	{
		temStrY1	= [northData objectAtIndex:(NSUInteger)7];
	}
	
	NSString *ttStr2 =[northData objectAtIndex:(NSUInteger)9];
	NSRange iRange2 = [ttStr2 rangeOfString:@"F" ];
	if(iRange2.location == 2)
	{
		temStrZ1	= [[northData objectAtIndex:(NSUInteger)9] stringByReplacingCharactersInRange:NSMakeRange(2, 4) withString:@"0"];
		iFlagZ1=1;
	}
	else
	{
		temStrZ1	= [northData objectAtIndex:(NSUInteger)9];
	}
	
	NSString *ttStrX2 =[southData objectAtIndex:(NSUInteger)5];
	NSRange iRangeX2 = [ttStrX2 rangeOfString:@"F" ];
	if(iRangeX2.location == 2)
	{
		temStrX2	= [[southData objectAtIndex:(NSUInteger)5] stringByReplacingOccurrencesOfString:@"F"withString:@"0"];
		iFlagX2=1;
	}
	else
	{
		temStrX2	= [southData objectAtIndex:(NSUInteger)5];
	}
	NSString *ttStrY2 =[southData objectAtIndex:(NSUInteger)7];
	NSRange iRangeY2 = [ttStrY2 rangeOfString:@"F" ];
	if(iRangeY2.location == 2)
	{
		temStrY2	= [[southData objectAtIndex:(NSUInteger)7] stringByReplacingOccurrencesOfString:@"F"withString:@"0"];
		iFlagY2=1;
	}
	else
	{
		temStrY2	= [southData objectAtIndex:(NSUInteger)7];
	}
	NSString *ttStrZ2 =[southData objectAtIndex:(NSUInteger)9];
	NSRange iRangeZ2 = [ttStrZ2 rangeOfString:@"F" ];
	if(iRangeZ2.location == 2)
	{
		temStrZ2	= [[southData objectAtIndex:(NSUInteger)9] stringByReplacingCharactersInRange:NSMakeRange(2, 4) withString:@"0"];
		iFlagZ2=1;
	}
	else
	{
		temStrZ2	= [southData objectAtIndex:(NSUInteger)9];
	}
	x_Rawdata_North = strtol([temStrX1 UTF8String],NULL,16);
	y_Rawdata_North = strtol([temStrY1 UTF8String],NULL,16);
	z_Rawdata_North = strtol([temStrZ1 UTF8String],NULL,16);
	x_Rawdata_South = strtol([temStrX2 UTF8String],NULL,16);
	y_Rawdata_South = strtol([temStrY2 UTF8String],NULL,16);
	z_Rawdata_South = strtol([temStrZ2 UTF8String],NULL,16);
	
	BOOL flag =YES;
	int xrange = x_Rawdata_North-x_Rawdata_South;
	int yrange = y_Rawdata_North-y_Rawdata_South;
	int zrange = z_Rawdata_North-z_Rawdata_South;
	if(iFlagX1==1&&iFlagX2==1)
		xrange = x_Rawdata_South-x_Rawdata_North;
	if(iFlagY1==1&&iFlagY2==1)
		yrange = y_Rawdata_South-y_Rawdata_North;
	if(iFlagZ1==1&&iFlagZ2==1)
		zrange = z_Rawdata_South-z_Rawdata_North;
	
	if (xrange<x_Diff_lowLimit || xrange>x_Diff_UpLimit)
	{
		
		strTestValue = [NSString stringWithFormat:@"%d",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_X_Range":@"X_Range":[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",xrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_X_Range":@"X_Range":[NSString stringWithFormat:@"%d",x_Diff_lowLimit]:[NSString stringWithFormat:@"%d",x_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
	}
	
	if (yrange<y_Diff_lowLimit || yrange>y_Diff_UpLimit)
	{
		strTestValue = [NSString stringWithFormat:@"%d",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_Y_Range":@"Y_Range":[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",yrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_Y_Range":@"Y_Range":[NSString stringWithFormat:@"%d",y_Diff_lowLimit]:[NSString stringWithFormat:@"%d",y_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
		
	}
	
	
	if (zrange<z_Diff_lowLimit || zrange>z_Diff_UpLimit)
	{
		
		strTestValue = [NSString stringWithFormat:@"%d",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_Z_Range":@"Z_Range":[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_FAIL:@"FAIL"];
		flag = NO;
	}
	else
	{	
		strTestValue = [NSString stringWithFormat:@"%d",zrange];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_0x1E_Z_Range":@"Z_Range":[NSString stringWithFormat:@"%d",z_Diff_lowLimit]:[NSString stringWithFormat:@"%d",z_Diff_UpLimit]:strTestValue:nil:IP_PASS:@"PASS"];
		
	}

	/*
	int therawtemp	= -1;
	therawtemp		= strtol([[rawdata objectAtIndex:(NSUInteger)2] UTF8String],NULL,16);
	
	if( therawtemp<100 || therawtemp>180 )
	{
		strTestValue = [NSString stringWithFormat:@"%d",therawtemp];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x1E":@"RAWSetuptemp":[NSString stringWithFormat:@"%d",100]:[NSString stringWithFormat:@"%d",180]:strTestValue:nil:IP_FAIL:@"FAIL"];
		
	}
	else
	{
		strTestValue = [NSString stringWithFormat:@"%d",therawtemp];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Compass_Init_0x1E":@"RAWSetuptemp":[NSString stringWithFormat:@"%d",100]:[NSString stringWithFormat:@"%d",180]:strTestValue:nil:IP_PASS:@"PASS"];
		
	}
	*/
	
	if (flag)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
		strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@"\n Test Value is:[ %d,%d,%d ]\n Spec Are:     [ %d,%d,%d ]\n               [ %d,%d,%d ]",xrange,yrange,zrange,x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit,x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit];
		
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
		strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@"\n Test Value is:[ %d,%d,%d ]\n Spec Are:     [ %d,%d,%d ]\n               [ %d,%d,%d ]",xrange,yrange,zrange,x_Diff_UpLimit,y_Diff_UpLimit,z_Diff_UpLimit,x_Diff_lowLimit,y_Diff_lowLimit,z_Diff_lowLimit];
		
	}
	
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	
	return ;
	
}

@end
