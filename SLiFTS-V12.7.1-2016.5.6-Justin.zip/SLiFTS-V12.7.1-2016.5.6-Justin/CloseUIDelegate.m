/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: CloseUIDelegate.h	 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 21.03.10                $Modtime:: 26.03.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: CloseUIDelegate.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 21.03.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */
#import "iFactoryTest/IFTPlugIn.h"
#import "testExecution.h"
#import "CloseUIDelegate.h"
#import "UIWinManage.h"
#import "UI_LockScript.h"
extern BOOL isAdmin;
#define MAINWINDOWNAME @"Test Studio"

// added by caijunbo on 20100916 for Display Port bundle unloading
void unloadBundle(NSBundle* bundle);
extern NSBundle* DPBundle;
// added end by caijunbo on 20100916 for Display Port bundle unloading
@implementation CloseUIDelegate

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication 
{ 
	
    return YES; 
} 

-(BOOL)windowShouldClose:(id)window
{
	
    if(isAdmin)
    {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert setAlertStyle:NSInformationalAlertStyle];
        [alert setMessageText:@"Need to lock the script?"];
        [alert addButtonWithTitle:@"Yes"];
        [alert addButtonWithTitle:@"No"];
        
        char *user=getlogin();
        NSString *userStr=[NSString stringWithUTF8String:user];
        NSString *basePathStr=[NSString stringWithFormat:@"/Users/%@/Documents",userStr];
        
        //NSURL *permissionPath = [NSURL fileURLWithPath:[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Contents"]];
        NSURL *permissionPath = [NSURL URLWithString:basePathStr];
        
        permissionPath = [permissionPath URLByAppendingPathComponent:@"admin.txt"];
        
        NSInteger result = [alert runModal];
        if(result == NSAlertFirstButtonReturn)
        {
            NSData *data = [@"0" dataUsingEncoding:NSUTF8StringEncoding];
            [data writeToFile:[permissionPath path] atomically:YES];
        }
        else
        {
            NSData *data = [@"1" dataUsingEncoding:NSUTF8StringEncoding];
            [data writeToFile:[permissionPath path] atomically:YES];
        }
        [alert release];
    }
    
	//NSLog(@"%@",[window className]) ;
	NSString *windowTitle = [window title];
	NSLog(@"the application is %@",self);
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setAlertStyle:NSInformationalAlertStyle];
	[alert setMessageText:@"Are you sure that you want to quit?"];
	[alert addButtonWithTitle:@"Yes"];
	[alert addButtonWithTitle:@"No"];
	
	NSInteger result = [alert runModal];
	if(result == NSAlertFirstButtonReturn)
	{
		// added by caijunbo on 20100916 for Display Port bundle unloading
		if (DPBundle)
		{
			unloadBundle(DPBundle);
			[DPBundle release];
			DPBundle=nil;
			NSLog(@"bundle unloaded!");
		}
		// added end by caijunbo on 20100916 for Display Port bundle unloading
		
		if([windowTitle isEqualToString:@"UART Debug Tool"])
		{
			if (![UIWinManage OpenAllPort]) 
				NSRunAlertPanel(@"WARNNING", @"reOpen all Port Fail", @"prompt", nil, nil) ;
		}
		else 
		{
			[self powerOffFixture] ;
            [UIWinManage CloseAllPort];
			exit(0);
		}

		
		[alert release];
		return YES;
	}
	
	[alert release];
	return NO;
}

-(void)powerOffFixture
{	
}
@end

// added by caijunbo on 20100916 for Display Port bundle unloading
void unloadBundle(NSBundle* bundle) {
	NSError* e;
    id suiteClass = [bundle principalClass];
    BOOL ret = [suiteClass onUnload:&e];
    if( !ret )
    {
        NSAlert *theAlert = [NSAlert alertWithError:e];
        [theAlert runModal];
    }
}
// added by end caijunbo on 20100916 for Display Port bundle unloading

