//
//  NVMIntegrityCheck.m
//  iFTS
//
//  Created by Ray Hsu on 2012/2/8.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ControlCAS140.h"
#import "toolFun.h"
#import "CAS4.h"
#include <stdio.h>
#include "math.h"
#import "UIAlert.h"

#define dpidDebugLogFile     204
#define dpidDebugLogLevel    205
#define dpidDebugMaxLogSize  206

#define DebugLogLevelErrors 1
#define DebugLogLevelSaturation 2
#define DebugLogLevelHardwareEvents 3
#define DebugLogLevelParameterChanges 4

#define gcfCalibrationTolerance 13
#define gcfTolerancePhotometricIntegral 0
#define gcfToleranceColorCoordinate 1

int _deviceType;
int _deviceOption;
int _CASID;
int number=0;
BOOL _contMeasuring;
NSMutableDictionary *_deviceTypes;
NSMutableDictionary *_deviceOptions;

@implementation TestItemParse(ControlCAS140Fun)

+(void)ParseGetCurrentTime:(NSDictionary*)dictKeyDefined
{
    NSString *mBufferName=nil;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    //NSString  *Time = [ToolFun getCurrentDateTime];
    NSString *Time = [[NSCalendarDate date] description] ;
    if([Time length] > 19)
        Time = [Time substringToIndex:19];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :Time] ;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:Time];
    
}


+(void)ParseLCDSN:(NSDictionary*)dictKeyDefined
{
    
    NSString *mLCDSNPart=nil;
    NSString *mBufferName=nil;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"LCDSNPart"])
		{
			mLCDSNPart = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    NSString* LCDSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
    NSString * externLCDSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYBCSN];
    if ([externLCDSN length] == 0)
    {
        NSString *strTestStation= [ScriptParse getValueFromSummary:@"TestStation"];
        if ([strTestStation isEqualToString:@"iQC RGBW"]&&[LCDSN length] > 17)
        {
            externLCDSN = [LCDSN substringFromIndex:17];
        }
    }
    //LCDSN = @"PPPYWWDSSSSEEEERX COFLEDDL";
    //LCDSN = @"F0YYWWDSSSSEEEERXCOFCEFGL";
    
    if([LCDSN length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"No LCD SN"];
        return;
    }
    else if([LCDSN length] != 17 && [LCDSN length] != 25  && [LCDSN length] != 20 && [LCDSN length] != 70)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"the length of LCD SN is error"];
        return;
    }
    
    NSString *uiValue = @"Error";
    //LCD SN format(25): PPP YWWD SSSS EEEER X COF LEDD L
    //PPPYWWDSSSSEEEERX: 17 digits as defined module SN
    //COF: module config, code == LCD cofig
    //LEDD: 4-digit LED bin information, L=led vendor, E=brightness, DD=color bin
    //L: LGP revision
    if([mLCDSNPart isEqualToString:@"LCDVendor"])
    {
        uiValue = [LCDSN substringToIndex:3];
        if([uiValue isEqualToString:@"F0Y"])
            uiValue = @"LGD";
        else if([uiValue isEqualToString:@"F5G"])
            uiValue = @"Sharp";
        else if([uiValue isEqualToString:@"DLN"])
            uiValue = @"Samsung";
        else
        {
            uiValue = @"Error";
            if(mBufferName != nil)
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :uiValue] ;
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:uiValue];
            return;
        }
        
    }
    else if([mLCDSNPart isEqualToString:@"externLCDSN"])
    {
        if (externLCDSN != nil)
        {
            uiValue = LCDSN ;
            //uiValue = [uiValue stringByAppendingString:externLCDSN];//[NSString stringWithString:externLCDSN];
        }
        else
        {
            uiValue = LCDSN ;
            //uiValue = @"ByPass";
        }
    }
    else if([mLCDSNPart isEqualToString:@"LCDConfig"])
    {
        if([externLCDSN length] >= 3)
        {
            uiValue = [externLCDSN substringFromIndex:0];
            uiValue = [uiValue substringToIndex:3];
        }
        else
            uiValue = @"ByPass";
        
    }
    else if([mLCDSNPart isEqualToString:@"LEDVendor"])
    {
        [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"Error"] ;
        if ([externLCDSN length] !=8)
        {
            uiValue = @"ByPass";
        }
        else
        {
            uiValue = [externLCDSN substringFromIndex:3];
            uiValue = [uiValue substringToIndex:1];
            if([uiValue isEqualToString:@"F"] || [uiValue isEqualToString:@"G"]||[uiValue isEqualToString:@"H"]||[uiValue isEqualToString:@"I"])
            {
                uiValue = @"Nichia";
                [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"Nichia"] ;
            }
            else if([uiValue isEqualToString:@"A"]||[uiValue isEqualToString:@"B"]||[uiValue isEqualToString:@"C"]
                    ||[uiValue isEqualToString:@"J"]||[uiValue isEqualToString:@"K"]||[uiValue isEqualToString:@"L"]
                    ||[uiValue isEqualToString:@"1"]||[uiValue isEqualToString:@"2"]||[uiValue isEqualToString:@"3"]
                    ||[uiValue isEqualToString:@"4"]||[uiValue isEqualToString:@"5"]||[uiValue isEqualToString:@"6"])
            {
                uiValue = @"TG";
                [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"TG"] ;
            }
            else
            {
                uiValue = @"Error";
            }
        }
        
        //        if([LCDSN length] == 25)
        //        {
        //            uiValue = [LCDSN substringFromIndex:20];
        //            uiValue = [uiValue substringToIndex:1];
        //            if([uiValue isEqualToString:@"F"] || [uiValue isEqualToString:@"G"]||[uiValue isEqualToString:@"H"]||[uiValue isEqualToString:@"I"])
        //            {
        //                uiValue = @"Nichia";
        //                [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"Nichia"] ;
        //            }
        //            else if([uiValue isEqualToString:@"A"]||[uiValue isEqualToString:@"B"]||[uiValue isEqualToString:@"C"])
        //            {
        //                uiValue = @"TG";
        //                [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"TG"] ;
        //            }
        //            else
        //            {
        //                uiValue = @"Error";
        //            }
        //
        //        }else if([LCDSN length] == 17 || [LCDSN length] == 20)
        //        {
        //            uiValue = @"ByPass";
        //            /*
        //             uiValue = [LCDSN substringFromIndex:11];
        //             uiValue = [uiValue substringToIndex:4];
        //             if([uiValue isEqualToString:@"FFYR"] || [uiValue isEqualToString:@"FG1L"])
        //             {
        //             uiValue = @"Nichia";
        //             [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"Nichia"] ;
        //             }else if([uiValue isEqualToString:@"FG1K"] || [uiValue isEqualToString:@"FG1M"])
        //             {
        //             uiValue = @"TG";
        //             [TestItemManage setBufferValue:dictKeyDefined :@"LEDVendorInLCDSN" :@"TG"] ;
        //             }
        //             */
        //        }
    }
    else if([mLCDSNPart isEqualToString:@"LEDBrt"])
    {
        NSString *ledVendor = [TestItemManage getBufferValue:dictKeyDefined :@"LEDVendorInLCDSN"] ;
        //        if([LCDSN length] == 25)
        //        {
        if ([externLCDSN length] !=8)
        {
            uiValue = @"ByPass";
        }
        else
        {
            uiValue = [externLCDSN substringFromIndex:4];
            uiValue = [uiValue substringToIndex:1];
            if([ledVendor isEqualToString:@"TG"])
            {
                if([uiValue isEqualToString:@"A"]) uiValue = @"P";
                
                else if([uiValue isEqualToString:@"B"]) uiValue = @"Q";
                
                else if([uiValue isEqualToString:@"C"]) uiValue = @"R";
                
                else if([uiValue isEqualToString:@"D"]) uiValue = @"S";
                
                else if([uiValue isEqualToString:@"E"]) uiValue = @"T";
                
                else if([uiValue isEqualToString:@"F"]) uiValue = @"U";
                
                else if([uiValue isEqualToString:@"G"]) uiValue = @"V";
                
                else if([uiValue isEqualToString:@"H"]) uiValue = @"P+Q";
                
                else if([uiValue isEqualToString:@"J"]) uiValue = @"Q+R";
                
                else if([uiValue isEqualToString:@"K"]) uiValue = @"R+S";
                
                else if([uiValue isEqualToString:@"L"]) uiValue = @"S+T";
                
                else if([uiValue isEqualToString:@"M"]) uiValue = @"T+U";
                
                else if([uiValue isEqualToString:@"N"]) uiValue = @"U+V";
                
                else if([uiValue isEqualToString:@"P"]) uiValue = @"P+R";
                
                else if([uiValue isEqualToString:@"Q"]) uiValue = @"Q+S";
                
                else if([uiValue isEqualToString:@"R"]) uiValue = @"R+T";
                
                else if([uiValue isEqualToString:@"S"]) uiValue = @"S+U";
                
                else if([uiValue isEqualToString:@"T"]) uiValue = @"T+V";
                
                else
                    uiValue = @"Error";
            }
            else if([ledVendor isEqualToString:@"Nichia"])
            {
                if([uiValue isEqualToString:@"A"]) uiValue = @"NW1375";
                
                else if([uiValue isEqualToString:@"9"]) uiValue = @"NW1350";
                
                else if([uiValue isEqualToString:@"B"]) uiValue = @"NW1400";
                
                else if([uiValue isEqualToString:@"C"]) uiValue = @"NW1425";
                
                else if([uiValue isEqualToString:@"D"]) uiValue = @"NW1450";
                
                else if([uiValue isEqualToString:@"E"]) uiValue = @"NW1475";
                
                else if([uiValue isEqualToString:@"F"]) uiValue = @"NW1500";
                
                else if([uiValue isEqualToString:@"G"]) uiValue = @"NW1525";
                
                else if([uiValue isEqualToString:@"H"]) uiValue = @"NW1550";
                
                else if([uiValue isEqualToString:@"J"]) uiValue = @"NW1575";
                
                else if([uiValue isEqualToString:@"K"]) uiValue = @"NW1600";
                
                //else if([uiValue isEqualToString:@"K"]) uiValue = @"NW1400+NW1425";
                
                else if([uiValue isEqualToString:@"L"]) uiValue = @"NW1375+NW1400";
                
                else if([uiValue isEqualToString:@"X"]) uiValue = @"NW1350+NW1400";
                
                else if([uiValue isEqualToString:@"M"]) uiValue = @"NW1400+NW1425";
                
                else if([uiValue isEqualToString:@"N"]) uiValue = @"NW1425+NW1450";
                
                else if([uiValue isEqualToString:@"P"]) uiValue = @"NW1450+NW1475";
                
                else if([uiValue isEqualToString:@"Q"]) uiValue = @"NW1475+NW1500";
                
                else if([uiValue isEqualToString:@"R"]) uiValue = @"NW1500+NW1525";
                
                else if([uiValue isEqualToString:@"S"]) uiValue = @"NW1525+NW1550";
                
                else if([uiValue isEqualToString:@"T"]) uiValue = @"NW1550+NW1575";
                
                else if([uiValue isEqualToString:@"U"]) uiValue = @"NW1575+NW1600";
                
                else if([uiValue isEqualToString:@"V"]) uiValue = @"NW1375+NW1425";
                
                else if([uiValue isEqualToString:@"W"]) uiValue = @"NW1400+NW1450";
                
                else
                    uiValue = @"Error";
            }
            else
                uiValue = @"Error";
        }
        //        }
        //        else
        //            uiValue = @"ByPass";
    }
    else if([mLCDSNPart isEqualToString:@"LEDColor"])
    {
        NSString *ledVendor = [TestItemManage getBufferValue:dictKeyDefined :@"LEDVendorInLCDSN"] ;
        //        if([LCDSN length] == 25)
        //        {
        
        if ([externLCDSN length] !=8)
        {
            uiValue = @"ByPass";
        }
        else
        {
            uiValue = [externLCDSN substringFromIndex:5];
            uiValue = [uiValue substringToIndex:2];
            NSString *firstChar = [uiValue substringToIndex:1];
            NSString *secondChar = [uiValue substringFromIndex:1];
            int loopTime = 0;
            if([firstChar isEqualToString:secondChar])
                loopTime = 1;
            else
                loopTime = 2;
            NSString *LedColor = @"";
            for(int i=0; i<loopTime; i++)
            {
                NSString *tmpLedC = firstChar;
                if(i==1)
                    tmpLedC = secondChar;
                
                if([ledVendor isEqualToString:@"TG"])
                {
                    if([tmpLedC isEqualToString:@"A"]) uiValue = @"3A";
                    
                    else if([tmpLedC isEqualToString:@"B"]) uiValue = @"3B";
                    
                    else if([tmpLedC isEqualToString:@"C"]) uiValue = @"3C";
                    
                    else if([tmpLedC isEqualToString:@"D"]) uiValue = @"3D";
                    
                    else if([tmpLedC isEqualToString:@"E"]) uiValue = @"3E";
                    
                    else if([tmpLedC isEqualToString:@"F"]) uiValue = @"3F";
                    
                    else if([tmpLedC isEqualToString:@"G"]) uiValue = @"3G";
                    
                    else if([tmpLedC isEqualToString:@"H"]) uiValue = @"3H";
                    
                    else if([tmpLedC isEqualToString:@"J"]) uiValue = @"4A";
                    
                    else if([tmpLedC isEqualToString:@"K"]) uiValue = @"4B";
                    
                    else if([tmpLedC isEqualToString:@"L"]) uiValue = @"4C";
                    
                    else if([tmpLedC isEqualToString:@"M"]) uiValue = @"4D";
                    
                    else if([tmpLedC isEqualToString:@"N"]) uiValue = @"4E";
                    
                    else if([tmpLedC isEqualToString:@"P"]) uiValue = @"4F";
                    
                    else if([tmpLedC isEqualToString:@"Q"]) uiValue = @"4G";
                    
                    else if([tmpLedC isEqualToString:@"R"]) uiValue = @"4H";
                    
                    else if([tmpLedC isEqualToString:@"S"]) uiValue = @"5A";
                    
                    else if([tmpLedC isEqualToString:@"T"]) uiValue = @"5B";
                    
                    else if([tmpLedC isEqualToString:@"U"]) uiValue = @"5C";
                    
                    else if([tmpLedC isEqualToString:@"V"]) uiValue = @"5D";
                    
                    else if([tmpLedC isEqualToString:@"W"]) uiValue = @"5E";
                    
                    else if([tmpLedC isEqualToString:@"X"]) uiValue = @"5F";
                    
                    else if([tmpLedC isEqualToString:@"Y"]) uiValue = @"5G";
                    
                    else if([tmpLedC isEqualToString:@"Z"]) uiValue = @"5H";
                    
                    else if([tmpLedC isEqualToString:@"0"]) uiValue = @"6A";
                    
                    else if([tmpLedC isEqualToString:@"1"]) uiValue = @"6B";
                    
                    else if([tmpLedC isEqualToString:@"2"]) uiValue = @"6C";
                    
                    else if([tmpLedC isEqualToString:@"3"]) uiValue = @"6D";
                    
                    else if([tmpLedC isEqualToString:@"4"]) uiValue = @"6E";
                    
                    else if([tmpLedC isEqualToString:@"5"]) uiValue = @"6F";
                    
                    else if([tmpLedC isEqualToString:@"6"]) uiValue = @"6G";
                    
                    else if([tmpLedC isEqualToString:@"7"]) uiValue = @"6H";
                    
                    else
                        uiValue = @"Error";
                }
                else if([ledVendor isEqualToString:@"Nichia"])
                {
                    if([tmpLedC isEqualToString:@"A"]) uiValue = @"ska285";
                    
                    else if([tmpLedC isEqualToString:@"B"]) uiValue = @"ska286";
                    
                    else if([tmpLedC isEqualToString:@"C"]) uiValue = @"Sa5257";
                    
                    else if([tmpLedC isEqualToString:@"D"]) uiValue = @"Sa5258";
                    
                    else if([tmpLedC isEqualToString:@"E"]) uiValue = @"sak287";
                    
                    else if([tmpLedC isEqualToString:@"F"]) uiValue = @"ska288";
                    
                    else if([tmpLedC isEqualToString:@"G"]) uiValue = @"Sa5267";
                    
                    else if([tmpLedC isEqualToString:@"H"]) uiValue = @"Sa5268";
                    
                    else if([tmpLedC isEqualToString:@"J"]) uiValue = @"Sa5275";
                    
                    else if([tmpLedC isEqualToString:@"K"]) uiValue = @"Sa5276";
                    
                    else if([tmpLedC isEqualToString:@"L"]) uiValue = @"Sa5277";
                    
                    else if([tmpLedC isEqualToString:@"M"]) uiValue = @"Sa5278";
                    
                    else if([tmpLedC isEqualToString:@"N"]) uiValue = @"Sa5285";
                    
                    else if([tmpLedC isEqualToString:@"P"]) uiValue = @"Sa5286";
                    
                    else if([tmpLedC isEqualToString:@"Q"]) uiValue = @"Sa5287";
                    
                    else if([tmpLedC isEqualToString:@"R"]) uiValue = @"Sa5288";
                    
                    else if([tmpLedC isEqualToString:@"S"]) uiValue = @"sa5651";
                    
                    else if([tmpLedC isEqualToString:@"T"]) uiValue = @"sa5652";
                    
                    else if([tmpLedC isEqualToString:@"U"]) uiValue = @"sa5661";
                    
                    else if([tmpLedC isEqualToString:@"V"]) uiValue = @"sa5662";
                    
                    else if([tmpLedC isEqualToString:@"W"]) uiValue = @"sa6275";
                    
                    else if([tmpLedC isEqualToString:@"X"]) uiValue = @"sa6276";
                    
                    else if([tmpLedC isEqualToString:@"Y"]) uiValue = @"sa6277";
                    
                    else if([tmpLedC isEqualToString:@"Z"]) uiValue = @"sa6278";
                    
                    else if([tmpLedC isEqualToString:@"0"]) uiValue = @"sa6651";
                    
                    else if([tmpLedC isEqualToString:@"1"]) uiValue = @"sa6652";
                    
                    else if([tmpLedC isEqualToString:@"2"]) uiValue = @"ska661";
                    
                    else if([tmpLedC isEqualToString:@"3"]) uiValue = @"sak662";
                    
                    else if([tmpLedC isEqualToString:@"4"]) uiValue = @"sa6257";
                    
                    else if([tmpLedC isEqualToString:@"5"]) uiValue = @"sa6258";
                    
                    else
                        uiValue = @"Error";
                }
                else
                    LedColor = @"Error";
                if(i==0)
                    LedColor = [LedColor stringByAppendingString:uiValue];
                else if(i==1)
                {
                    LedColor = [LedColor stringByAppendingString:@"+"];
                    LedColor = [LedColor stringByAppendingString:uiValue];
                }
            }
            uiValue = LedColor;
            
        }
        //        }
        //        else
        //            uiValue = @"ByPass";
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
        return;
    }
    
    if(mBufferName != nil)
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :uiValue] ;
    
    //    if([uiValue rangeOfString:@"Error"].length > 0)
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:uiValue];
    //    else
    [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:uiValue];
}


+(void)ControlCAS140CT:(NSDictionary*)dictKeyDefined
{
    
    
    _deviceTypes = [NSMutableDictionary dictionary];
    //[_deviceTypes retain];
    _deviceOptions = [NSMutableDictionary dictionary];
    //[_deviceOptions retain];
    
    //1.==========get lib version============
    unichar buffer[256] = {0};
    casGetDLLFileNameW(buffer, 256);
    NSLog(@"casGetDLLFileNameW =%S",buffer);
    
    //2.==========debug file, CAS4.log============
    casSetDeviceParameter(-1, dpidDebugMaxLogSize, 100*1024); //100kB
    casSetDeviceParameter(-1, dpidDebugLogLevel, DebugLogLevelHardwareEvents);
    NSFileManager *fm = [NSFileManager defaultManager];
    NSURL *dirURL = [[fm URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    dirURL = [dirURL URLByAppendingPathComponent:@"CAS4.log"];
    [self setCasDeviceParameterString:[dirURL path] withDPID:dpidDebugLogFile];
    
    //3.==========get devive type and option============
    [self fillDeviceTypes];
    [self fillDeviceOptions];
    
    
    //4.===========create(init) device ========================
    sleep(1);
    _CASID = casCreateDeviceEx(_deviceType, _deviceOption);
    sleep(2);
    
    //enable the coCheckCalibConfigSerials option, since we need the checks during casInitialize
    casSetOptionsOnOff(_CASID, coCheckCalibConfigSerials, 1);
    int ret = casGetError(_CASID);//= [self checkCASError:casGetError(_CASID) causedByAction:@"enabling coCheckCalibConfigSerials option"];
    if (ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"coCheckCalibConfigSerials fail"];
        return;
    }
    //enable AutoRemeasureDC option
    casSetOptionsOnOff(_CASID, coAutoRemeasureDC, 1);
    ret = casGetError(_CASID);//ret = [self checkCASError:casGetError(self.CASID) causedByAction:@"enabling coAutoRemeasureDC option"];
    if (ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"cAutoRemeasureDC fail"];
        return;
    }
    //set DC remeasure interval to 10 minutes
    ret = casSetMeasurementParameter(_CASID, mpidRemeasureDCInterval, 10*60*1000); //[self checkCASError:casSetMeasurementParameter(self.CASID, mpidRemeasureDCInterval, 10*60*1000) causedByAction:@"setting mpidRemeasureDCInterval"];
    if (ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"set DC remeasure interval fail"];
        return;
    }
    
    //enable acqstate on
    ret = casSetMeasurementParameter(_CASID, mpidTriggerOptions, toShowACQState); //[self checkCASError:casSetMeasurementParameter(self.CASID, mpidTriggerOptions, toShowACQState) causedByAction:@"setting mpidTriggerOptions"];
    if (ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"enable acqstate on - fail"];
        return;
    }
    
    fm = [NSFileManager defaultManager];
    dirURL = [[fm URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    dirURL = [dirURL URLByAppendingPathComponent:@"CASCalibDir"];
    [self useFirstConfigCalibFilePair:dirURL];
    
    
    ret = casInitialize(_CASID, InitForced);
    sleep(1);
    if(ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"casInitialize - fail"];
        return;
    }
    NSString *serial = [self casDeviceParameterStringWithDPID:dpidSerialNo];
    NSLog(@"\n serial=%@",serial);
    NSString *configFileName =[self casDeviceParameterStringWithDPID:dpidConfigFileName];
    NSLog(@"\n serial=%@",configFileName);
    NSString *calibFileName =[self casDeviceParameterStringWithDPID:dpidCalibFileName];
    NSLog(@"\n serial=%@",calibFileName);
    
    
    
    //5.===========get info ========================
    [self btnGetInfoClicked:dictKeyDefined];
    
    //6.===========prepare measure ========================
    ret = -1;
    ret = [self btnPrepareMeasurement:dictKeyDefined];
    sleep(1);
    if(ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"PrepareMeasurement - fail"];
        return;
    }
    
    //7.===========measure ========================
    ret = -1;
    ret = [self btnMeasure:dictKeyDefined];
    if(ret < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"measure - fail"];
        return;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:@"Finish"];
}

+(int)setCasDeviceParameterString:(NSString *)aString withDPID:(int)dpid
{
    int ret = 0;
    unichar* stringPointer = (unichar*) [aString cStringUsingEncoding:NSUTF16LittleEndianStringEncoding];
    ret = casSetDeviceParameterStringW(_CASID, dpid, stringPointer);
    [self checkCASError:ret causedByAction:[NSString stringWithFormat:@"casSetDeviceParameterStringW with AWhat %d", dpid]];
    return ret;
}

+(int)checkCASError:(int)error causedByAction:(NSString *)action
{
    if (error < 0) {
        
        unichar msgBuffer[256] = {0};
        casGetErrorMessageW(error, msgBuffer, 256);
        NSString *errMsg = [NSString stringWithFormat:@"%S", (const unichar*)msgBuffer];
        //        if (action) {
        //            [self debugLog:[NSString stringWithFormat:@"Error: %@ returned %@ (%d)", action, errMsg, error]];
        //        } else
        //            [self debugLog:[NSString stringWithFormat:@"Error: CAS4 lib returned %@ (%d)", errMsg, error]];
    }
    NSLog(@"\n ....error=%d, %@",error,action);
    return error;
}

+(void)fillDeviceTypes
{
    [_deviceTypes removeAllObjects];
    int count = casGetDeviceTypes();
    NSString *devTypeName;
    
    for (int i = 0; i<count; i++) {
        unichar buffer[256] = {0};
        casGetDeviceTypeNameW(i, buffer, 255);
        devTypeName = [NSString stringWithFormat:@"%S", (const unichar*)buffer];
        if ([devTypeName length]>0) {
            
            if([devTypeName isEqualToString:@"CAS140CT-USB"])
            {
                _deviceType = i;  //=[self udpateDeviceType];
                NSLog(@"\n _deviceType=%d, deviceTypeName=%@",_deviceType,devTypeName);
            }
            
            [_deviceTypes setObject:[NSNumber numberWithInt:i] forKey:devTypeName];
        }
        //NSLog(@"\n _deviceType=%d, deviceTypeName=%@",_deviceType,devTypeName);
    }
    NSLog(@"...");
    /*
     [self.cbDeviceType removeAllItems];
     [self.cbDeviceType addItemsWithObjectValues:[self.deviceTypes keysSortedByValueUsingSelector:@selector(compare:)]];
     [self.cbDeviceType setEnabled:(self.cbDeviceType.numberOfItems>1)];
     if (self.cbDeviceType.numberOfItems > 0) {
     [self.cbDeviceType selectItemAtIndex:0];
     [self udpateDeviceType];
     } else {
     [self.cbDeviceType setObjectValue:nil];
     }*/
}

+(void)fillDeviceOptions
{
    [_deviceOptions removeAllObjects];
    int count = casGetDeviceTypeOptions(_deviceType);
    [self checkCASError:count causedByAction:@"casGetDeviceTypeOptions"];
    NSString *devOptionName;
    
    int option;
    
    for (int i = 0; i<count; i++) {
        option = casGetDeviceTypeOption(_deviceType, i);
        [self checkCASError:option causedByAction:@"casGetDeviceTypeOption"];
        unichar buffer[256] = {0};
        casGetDeviceTypeOptionNameW(_deviceType, i, buffer, 255);
        devOptionName = [NSString stringWithFormat:@"%S", (const unichar *)buffer];
        if ([devOptionName length]>0) {
            [_deviceOptions setObject:[NSNumber numberWithInt:option] forKey:devOptionName];
            
            _deviceOption = option; //=[self updateDeviceOption];
            NSLog(@"\n option=%d devOptionName=%@",option,devOptionName);
            
        }
        //NSLog(@"\n option=%d devOptionName=%@",option,devOptionName);
    }
    
    //[self.cbDeviceOption removeAllItems];
    //[self.cbDeviceOption addItemsWithObjectValues:[self.deviceOptions keysSortedByValueUsingSelector:@selector(compare:)]];
    //[self.cbDeviceOption setEnabled:(self.cbDeviceOption.numberOfItems>1)];
    //if (self.cbDeviceOption.numberOfItems > 0) {
    //    [self.cbDeviceOption selectItemAtIndex:0];
    //[self updateDeviceOption];
    //} else {
    //    [self.cbDeviceOption setObjectValue:nil];
    //}
}

+(void)useFirstConfigCalibFilePair:(NSURL *)dirURL
{
    //clear any previously used files
    [self setCasDeviceParameterString:@"" withDPID:dpidConfigFileName];
    [self setCasDeviceParameterString:@"" withDPID:dpidCalibFileName];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    [self debugLog:[NSString stringWithFormat:@"Looking for config/calib files in %@", dirURL]];
    
    NSArray *dirFiles = [fm contentsOfDirectoryAtURL:dirURL includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    for (NSURL *configFileURL in dirFiles) {
        if ([[configFileURL pathExtension] caseInsensitiveCompare:@"ini"] == NSOrderedSame) {
            if ([fm fileExistsAtPath:[configFileURL path]]) {
                NSURL *calibFileURL = [[configFileURL URLByDeletingPathExtension] URLByAppendingPathExtension:@"isc"];
                if ([fm fileExistsAtPath:[calibFileURL path]]) {
                    [self debugLog:[NSString stringWithFormat:@"Found file pair %@", [configFileURL lastPathComponent]]];
                    [self setCasDeviceParameterString:[configFileURL path] withDPID:dpidConfigFileName];
                    [self setCasDeviceParameterString:[calibFileURL path] withDPID:dpidCalibFileName];
                    break;
                }
            }
        }
    }
}

+(void)debugLog:(NSString *)debugMsg
{
    return;
    /*
     //NSTextStorage *txt = self.tvDebug.textStorage;
     NSTextStorage *txt = self.tvDebug.textStorage;
     NSString *stringToAppend;
     if ([txt length]) {
     stringToAppend = [NSString stringWithFormat:@"\n%@", debugMsg];
     } else {
     stringToAppend = debugMsg;
     }
     [txt replaceCharactersInRange:NSMakeRange([txt length], 0) withString:stringToAppend];
     [self.tvDebug scrollToEndOfDocument:self];
     [self.tvDebug display];
     */
}

+(NSString *)casDeviceParameterStringWithDPID:(int)dpid
{
    unichar buffer[256] = {0};
    int ret = casGetDeviceParameterStringW(_CASID, dpid, buffer, 255);
    [self checkCASError:ret causedByAction:[NSString stringWithFormat:@"casGetDeviceParameterStringW with AWhat %d", dpid]];
    
    if (ret<0) {
        return nil;
    } else {
        return [NSString stringWithFormat:@"%S", (const unichar *)buffer];
    }
}

+(void)btnGetInfoClicked:(NSDictionary*)dictKeyDefined
{
    //ideally the return values of casGetDeviceParameter should be checked too
    //(or passed to self checkCASError!). Skipped here for brevity.
    long pixels = roundtol(casGetDeviceParameter(_CASID, dpidPixels));
    long deadPixels = roundtol(casGetDeviceParameter(_CASID, dpidDeadPixels));
    long visiblePixels = roundtol(casGetDeviceParameter(_CASID, dpidVisiblePixels));
    NSLog(@"pixels=%ld, deadPixels=%ld, visiblePixels=%ld",pixels,deadPixels,visiblePixels);
    
    [self debugLog:[NSString stringWithFormat:@"%ld pixels, %ld visible, %ld dead", pixels, visiblePixels, deadPixels]];
    
    double TolerancePhotInt = casGetCalibrationFactors(_CASID, gcfCalibrationTolerance, 0, gcfTolerancePhotometricIntegral);
    double ToleranceColor = casGetCalibrationFactors(_CASID, gcfCalibrationTolerance, 0, gcfToleranceColorCoordinate);
    [self debugLog:[NSString stringWithFormat:@"Calibration tolerances: Photometric: %g %%, Color Coordinate +/- %g", TolerancePhotInt, ToleranceColor]];
    NSLog(@"TolerancePhotInt=%f, ToleranceColor=%f",TolerancePhotInt,ToleranceColor);
    
    //demo code for checking for TOP150 and extracting camera OEM serial #
    long topType = roundtol(casGetDeviceParameter(_CASID, dpidTOPType));
    if (topType == ttTOP150) {
        NSString *topSerial = [self casDeviceParameterStringWithDPID:dpidTOPSerialEx];
        NSArray *topSerialParts = [topSerial componentsSeparatedByString:@";"];
        if (topSerialParts.count == 2) {
            [self debugLog:[NSString stringWithFormat:@"TOP150 with serial %@ configured. Camera serial is %@", [topSerialParts objectAtIndex:0], topSerialParts.lastObject]];
        } else
            [self debugLog:[NSString stringWithFormat:@"Unexpected TOP150 serial %@. Camera serial cannot be extracted", topSerial]];
        
    } else
        [self debugLog:@"No TOP150 configured"];
}
// make integration time can be adjusted --->add by annie on 2013.7.12
+(int)PrepareMeasurement_IntergrTimer:(NSDictionary*)dictKeyDefined :(NSString *)ExpoTimer
{
    //check if initialized, if not abort
    //    int ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidInitialized) causedByAction:@"getting dpidInitialized"];
    //
    //    //here 0 is also considered an abort criteria, since it means that the device hasn't been initialized!
    //    if (ret <= 0)
    //    {
    //        [self debugLog:[NSString stringWithFormat:@"Aborting, device not initialized, dpidInitialized returned %d!", ret]];
    //        return ret;
    //    }
    //
    //    //explicitely check if required accessory (i.e. ident key) is present
    //    ret = [self checkCASError:casPerformAction(_CASID, paCheckAccessories) causedByAction:@"checking ident key"];
    //    if (ret < 0) return ret;
    
    int ret;
    //setting integration time
    //make sure to verify against allowed range, otherwise undefined behaviour may occur
    int intTimeMin = casGetDeviceParameter(_CASID, dpidIntTimeMin);
    NSLog(@"the CAID's Min integration time is %d",intTimeMin);
    [self checkCASError:intTimeMin causedByAction:@"getting dpidIntTimeMin"];
    if (intTimeMin < 0)
    {
        ret = -1; return ret;
    }
    
    int intTimeMax = casGetDeviceParameter(_CASID, dpidIntTimeMax);
    NSLog(@"the CAID's Max integration time is %d",intTimeMax);
    [self checkCASError:intTimeMax causedByAction:@"getting dpidIntTimeMax"];
    if (intTimeMax < 0)
    {
        ret = -1; return ret;
    }
    
    //                if ([mGeneralIntegrationTimer isEqualToString:@"auto"]) {
    //                    casSetOptionsOnOff(_CASID, coAutorangeFilter, 1);
    //                    casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 1);
    //                }else
    //                {
    //                    casSetOptionsOnOff(_CASID, coAutorangeFilter, 0);
    //                    casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 0);
    //    NSString *integraTimer=ExpoTimer;
    //    if ([integraTimer isEqualToString:@"auto"]) {
    //        casSetOptionsOnOff(_CASID, coAutorangeFilter, 1);
    //        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 1);
    ////        [self debugLog:@"Prepare auto integration time successfully finished!"];
    ////        ret=1;
    ////        return ret;
    //    }else
    //    {
    //        casSetOptionsOnOff(_CASID, coAutorangeFilter, 0);
    //        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 0);
    //    }
    int intTimeNew = [ExpoTimer intValue];
    NSLog(@"the CAID integration time is setting to %d",intTimeMin);
    if (intTimeNew < intTimeMin) intTimeNew = intTimeMin;
    if (intTimeNew > intTimeMax) intTimeMax = intTimeMax;
    [self debugLog:[NSString stringWithFormat:@"setting IntTime = %dms", intTimeNew]];
    ret = [self checkCASError:casSetMeasurementParameter(_CASID, mpidIntegrationTime, intTimeNew) causedByAction:@"setting mpidIntegrationTime"];
    if (ret < 0) return ret;
    NSLog(@"integrationTimeMin=%ld, integratioTimeMax=%ld, integratioTimeNew=%ld",intTimeMin,intTimeMax,intTimeNew);
    
    //checking for necessary filter change
    ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDensityFilterChange) causedByAction:@"getting dpidNeedDensityFilterChange"];
    if (ret < 0) return ret;
    
    if (ret != 0) { //we need a filter change!
        [self debugLog:@"changing density filter!"];
        ret = [self checkCASError:casGetMeasurementParameter(_CASID, mpidNewDensityFilter) causedByAction:@"getting mpidNewDensityFilter"];
        if (ret < 0) return ret;
        
        ret = [self checkCASError:casSetMeasurementParameter(_CASID, mpidDensityFilter, ret) causedByAction:@"setting mpidDensityFilter"];
        if (ret < 0) return ret;
    }
    
    //checking for required dark current measurement
    ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDarkCurrent) causedByAction:@"getting dpidNeedDarkCurrent"];
    if (ret < 0) return ret;
    
    if (ret != 0) { //we need a dark current measurement!
        [self debugLog:@"Measuring dark current"];
        
        casSetShutter(_CASID, 1);
        if ([self checkCASError:casGetError(_CASID) causedByAction:@"closing shutter"] < 0) return ret;
        
        ret = [self checkCASError:casMeasureDarkCurrent(_CASID) causedByAction:@"casMeasureDarkCurrent"];
        
        casSetShutter(_CASID, 0);
        if ([self checkCASError:casGetError(_CASID) causedByAction:@"opening shutter"] < 0) return ret;
        
        //here ret is still from casMeasureDarkCurrent!
        if (ret < 0) return ret;
    }
    [self debugLog:@"Prepare successfully finished!"];
    return ret;
}


+(int)btnPrepareMeasurement:(NSDictionary*)dictKeyDefined
{
    //check if initialized, if not abort
    int ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidInitialized) causedByAction:@"getting dpidInitialized"];
    
    //here 0 is also considered an abort criteria, since it means that the device hasn't been initialized!
    if (ret <= 0)
    {
        [self debugLog:[NSString stringWithFormat:@"Aborting, device not initialized, dpidInitialized returned %d!", ret]];
        return ret;
    }
    
    //explicitely check if required accessory (i.e. ident key) is present
    ret = [self checkCASError:casPerformAction(_CASID, paCheckAccessories) causedByAction:@"checking ident key"];
    if (ret < 0) return ret;
    
    //setting integration time
    //make sure to verify against allowed range, otherwise undefined behaviour may occur
    int intTimeMin = casGetDeviceParameter(_CASID, dpidIntTimeMin);
    [self checkCASError:intTimeMin causedByAction:@"getting dpidIntTimeMin"];
    if (intTimeMin < 0)
    {
        ret = -1; return ret;
    }
    
    int intTimeMax = casGetDeviceParameter(_CASID, dpidIntTimeMax);
    [self checkCASError:intTimeMax causedByAction:@"getting dpidIntTimeMax"];
    if (intTimeMax < 0)
    {
        ret = -1; return ret;
    }
    
    int intTimeNew = 20;
    if (intTimeNew < intTimeMin) intTimeNew = intTimeMin;
    if (intTimeNew > intTimeMax) intTimeMax = intTimeMax;
    [self debugLog:[NSString stringWithFormat:@"setting IntTime = %dms", intTimeNew]];
    ret = [self checkCASError:casSetMeasurementParameter(_CASID, mpidIntegrationTime, intTimeNew) causedByAction:@"setting mpidIntegrationTime"];
    if (ret < 0) return ret;
    NSLog(@"integrationTimeMin=%ld, integratioTimeMax=%ld, integratioTimeNew=%ld",intTimeMin,intTimeMax,intTimeNew);
    
    //checking for necessary filter change
    ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDensityFilterChange) causedByAction:@"getting dpidNeedDensityFilterChange"];
    if (ret < 0) return ret;
    
    if (ret != 0) { //we need a filter change!
        [self debugLog:@"changing density filter!"];
        ret = [self checkCASError:casGetMeasurementParameter(_CASID, mpidNewDensityFilter) causedByAction:@"getting mpidNewDensityFilter"];
        if (ret < 0) return ret;
        
        ret = [self checkCASError:casSetMeasurementParameter(_CASID, mpidDensityFilter, ret) causedByAction:@"setting mpidDensityFilter"];
        if (ret < 0) return ret;
    }
    
    //checking for required dark current measurement
    ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDarkCurrent) causedByAction:@"getting dpidNeedDarkCurrent"];
    if (ret < 0) return ret;
    
    if (ret != 0) { //we need a dark current measurement!
        [self debugLog:@"Measuring dark current"];
        
        casSetShutter(_CASID, 1);
        if ([self checkCASError:casGetError(_CASID) causedByAction:@"closing shutter"] < 0) return ret;
        
        ret = [self checkCASError:casMeasureDarkCurrent(_CASID) causedByAction:@"casMeasureDarkCurrent"];
        
        casSetShutter(_CASID, 0);
        if ([self checkCASError:casGetError(_CASID) causedByAction:@"opening shutter"] < 0) return ret;
        
        //here ret is still from casMeasureDarkCurrent!
        if (ret < 0) return ret;
    }
    [self debugLog:@"Prepare successfully finished!"];
    return ret;
}

+(int)btnMeasure:(NSDictionary*)dictKeyDefined
{
    bool autoExplodeFlag=FALSE;
    NSString *mDevice = nil;
    NSString *mBufferName=nil;
    NSString *mUSleepTime = @"100";
    NSString *mGeneralIntegrationTimer=@"20";
    NSString *mBlackPatternIntegraTimer=@"20";
	//NSString *mWriteCmdSetDefaultLedCurrentLGD = nil;
    //NSString *mWriteCmdSetDefaultLedCurrentSharp = nil;
    NSString *mWriteCmdSetDefaultLedCurrent = nil;
    
    NSString *mWriteCmdSetFullLedCurrent = nil;
    NSString *mDefaultLedCurrent = nil;
    NSString *mFullLedCurrent = nil;
    NSString *mWriteCmdToRedPattern = nil;
    NSString *mWriteCmdToGreenPattern = nil;
    NSString *mWriteCmdToBluePattern = nil;
    NSString *mWriteCmdToCyanPattern = nil;
    NSString *mWriteCmdToMagentaPattern = nil;
    NSString *mWriteCmdToYellowPattern = nil;
    NSString *mWriteCmdToWhitePattern = nil;
    NSString *mWriteCmdToBlackPattern = nil;
    NSString *mWriteCmdSetGrayLevel = nil;
    NSString *mListGrayLevel = nil;
    NSArray  *arrayGrayLevel = nil;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mTimeOut=@"6" ;
    
    NSString *mWriteCmdSetLedCurrent = nil;
    NSString *mWriteCmdSetPattern = nil;
    NSString *mPostfix =@":-)";
    NSString *mBufferNameFullBlackY =nil;
    NSString *mBufferNameFullWY =nil;
    
    NSString *mBufferNameGeneralTimer =nil;
    NSString *mBufferNameBlackPatternTimer =nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"GeneralIntegrationTimer"])
		{
			mGeneralIntegrationTimer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BlackPatternIntegraTimer"])
		{
			mBlackPatternIntegraTimer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"USleepTime"])
		{
			mUSleepTime = [dictKeyDefined objectForKey:strKey] ;
		}
//		else if ([strKey isEqualToString:@"WriteCmdSetDefaultLedCurrentLGD"])
//		{
//			mWriteCmdSetDefaultLedCurrentLGD = [dictKeyDefined objectForKey:strKey] ;
//            mWriteCmdSetDefaultLedCurrentLGD = [mWriteCmdSetDefaultLedCurrentLGD stringByAppendingString:@"\n"];
//		}
//        else if ([strKey isEqualToString:@"WriteCmdSetDefaultLedCurrentSharp"])
//		{
//			mWriteCmdSetDefaultLedCurrentSharp = [dictKeyDefined objectForKey:strKey] ;
//            mWriteCmdSetDefaultLedCurrentSharp = [mWriteCmdSetDefaultLedCurrentSharp stringByAppendingString:@"\n"];
//		}
        else if ([strKey isEqualToString:@"WriteCmdSetDefaultLedCurrent"])
        {
            mWriteCmdSetDefaultLedCurrent = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdSetDefaultLedCurrent = [mWriteCmdSetDefaultLedCurrent stringByAppendingString:@"\n"];
        }
        else if ([strKey isEqualToString:@"WriteCmdSetFullLedCurrent"])
		{
			mWriteCmdSetFullLedCurrent = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdSetFullLedCurrent = [mWriteCmdSetFullLedCurrent stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"DefaultLedCurrent"])
		{
			mDefaultLedCurrent = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"FullLedCurrent"])
		{
			mFullLedCurrent = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdToRedPattern"])
		{
			mWriteCmdToRedPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToRedPattern = [mWriteCmdToRedPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToGreenPattern"])
		{
			mWriteCmdToGreenPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToGreenPattern = [mWriteCmdToGreenPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToBluePattern"])
		{
			mWriteCmdToBluePattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToBluePattern = [mWriteCmdToBluePattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToCyanPattern"])
		{
			mWriteCmdToCyanPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToCyanPattern = [mWriteCmdToCyanPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToMagentaPattern"])
		{
			mWriteCmdToMagentaPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToMagentaPattern = [mWriteCmdToMagentaPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToYellowPattern"])
		{
			mWriteCmdToYellowPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToYellowPattern = [mWriteCmdToYellowPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToWhitePattern"])
		{
			mWriteCmdToWhitePattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToWhitePattern = [mWriteCmdToWhitePattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdToBlackPattern"])
		{
			mWriteCmdToBlackPattern = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdToBlackPattern = [mWriteCmdToBlackPattern stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmdSetGrayLevel"])
		{
			mWriteCmdSetGrayLevel = [dictKeyDefined objectForKey:strKey] ;
            mWriteCmdSetGrayLevel = [mWriteCmdSetGrayLevel stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"ListGrayLevel"])
		{
			mListGrayLevel = [dictKeyDefined objectForKey:strKey] ;
            mListGrayLevel = [mListGrayLevel stringByReplacingOccurrencesOfString:@" " withString:@""];
            mListGrayLevel = [mListGrayLevel stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mListGrayLevel = [mListGrayLevel stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            mListGrayLevel = [mListGrayLevel stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            arrayGrayLevel = [mListGrayLevel componentsSeparatedByString:@","];
		}
        else if ([strKey isEqualToString:@"BufferNameFullWY"])
		{
			mBufferNameFullWY = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFullBlackY"])
		{
			mBufferNameFullBlackY = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameGeneralTimer"])
		{
			mBufferNameGeneralTimer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameBlackPatternTimer"])
		{
			mBufferNameBlackPatternTimer = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameFullWY :@"-1"];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameFullBlackY :@"-1"];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameGeneralTimer :mGeneralIntegrationTimer];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBlackPatternTimer :mBlackPatternIntegraTimer];
    
    
    //check if initialized, if not abort
    int ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidInitialized) causedByAction:@"getting dpidInitialized"];
    
    //here 0 is also considered an abort criteria, since it means that the device hasn't been initialized!
    if (ret <= 0)
    {
        [self debugLog:[NSString stringWithFormat:@"Aborting, device not initialized, dpidInitialized returned %d!", ret]];
        return ret;
    }
    //checking for necessary filter change
    //CAS 140 CT always returns NeedFilterChange because of automatically enabled ForceFilter option
    //ret = [self checkCASError:casGetDeviceParameter(self.CASID, dpidNeedDensityFilterChange) causedByAction:@"getting dpidNeedDensityFilterChange"];
    //if (ret != 0) {
    //    [self debugLog:[NSString stringWithFormat:@"Aborting, dpidNeedFilterChange did not return 0, but %d! Prepare measurement first", ret]];
    //    return;
    //}
    //checking for required dark current measurement
    ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDarkCurrent) causedByAction:@"getting dpidNeedDarkCurrent"];
    if (ret != 0) {
        [self debugLog:[NSString stringWithFormat:@"Aborting, dpidNeedDarkCurrent did not return 0, but %d! Prepare measurement first", ret]];
        return ret;
    }
    
    NSString *luminance = @"";
    NSString *luminanceUnit = @"";
    NSString *colorCoordinates = @"";
    NSArray *arrayColorCoordinates = nil;
    NSString *subItemName = @"";
    
    //NSString* LCDSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
    //1.===================set Led current,==============================
    for(int ledCurrent=0; ledCurrent<2; ledCurrent++)
    {
        //==================send command to change led current==========================
//        if(ledCurrent==0&&[[LCDSN substringToIndex:3] isEqualToString:@"F0Y"])
//        {
//            mWriteCmdSetLedCurrent = mWriteCmdSetDefaultLedCurrentLGD;
//        }
//        else if(ledCurrent==0&&[[LCDSN substringToIndex:3] isEqualToString:@"F5G"])
//        {
//            mWriteCmdSetLedCurrent = mWriteCmdSetDefaultLedCurrentSharp;
//        }
//        else if(ledCurrent==0&&[[LCDSN substringToIndex:3] isEqualToString:@"DLN"])
//        {
//            mWriteCmdSetLedCurrent = mWriteCmdSetDefaultLedCurrentLGD;
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Samsung LED defalut Current value now, please check!"];
//            return -1;
//        }
        if(ledCurrent==0)
            mWriteCmdSetLedCurrent = mWriteCmdSetDefaultLedCurrent;
        else
            mWriteCmdSetLedCurrent = mWriteCmdSetFullLedCurrent;
        
        
        bool bTmp = [self SendData:dictKeyDefined :mWriteCmdSetLedCurrent :mPostfix] ;
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send command -setLedCurrent fail "] ;
            ret = -1; return ret;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
        }
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        if([dataResult rangeOfString:@":-)"].length <= 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data --setPattern fail "] ;
            ret = -1; return ret;
        }
        
        //2.===================set LCD pattern==============================
        BOOL WYFlag=YES;
        for(int pattern=0; pattern<8; pattern++)
        {
            if(pattern == 0)
            {
                mWriteCmdSetPattern = mWriteCmdToRedPattern;
            }
            else if(pattern == 1)
            {
                mWriteCmdSetPattern = mWriteCmdToGreenPattern;
            }
            else if(pattern == 2)
            {
                mWriteCmdSetPattern = mWriteCmdToBluePattern;
            }
            else if(pattern == 3)
            {
                mWriteCmdSetPattern = mWriteCmdToCyanPattern;
            }
            else if(pattern == 4)
            {
                mWriteCmdSetPattern = mWriteCmdToMagentaPattern;
            }
            else if(pattern == 5)
            {
                mWriteCmdSetPattern = mWriteCmdToYellowPattern;
            }
            //            else if(pattern == 6)
            //            {
            //                mWriteCmdSetPattern = mWriteCmdToWhitePattern;
            //            }
            //            else if(pattern == 7)
            //            {
            //                mWriteCmdSetPattern = mWriteCmdToBlackPattern;
            //            }
            else if(pattern == 6)
            {
                mWriteCmdSetPattern = mWriteCmdToBlackPattern;
            }
            else if(pattern == 7)
            {
                mWriteCmdSetPattern = mWriteCmdToWhitePattern;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"error Pattern in gray level "] ;
                ret = -1; return ret;
            }
            
            // set general integration time====add by annie 2013.7.12=========================
            //------------------------medth1 pass-----------------------------------------------------
            //            if (![mBlackPatternIntegraTimer isEqualToString:@"auto"])
            //            {
            //                if(pattern == 6)
            //                {
            //                        int prepareBlackFlag=[self PrepareMeasurement_IntergrTimer:dictKeyDefined :mBlackPatternIntegraTimer];
            //                        //int prepareBlackFlag=[self btnPrepareMeasurement_time:dictKeyDefined];
            //                        if (prepareBlackFlag < 0) {
            //                            NSLog(@"Prepare black pattern integration time fail");
            //                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prepare black pattern integration time fail "] ;
            //                            return -1;
            //                        }
            //                }
            //                else
            //                {
            //                        int prepareGeneralFlag=  [self PrepareMeasurement_IntergrTimer:dictKeyDefined :mGeneralIntegrationTimer];
            //                        //int prepareGeneralFlag=[self btnPrepareMeasurement_time:dictKeyDefined];
            //                        if (prepareGeneralFlag < 0 )
            //                        {
            //                            NSLog(@"Prepare black pattern integration time fail");
            //                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prepare black pattern integration time fail 2 "] ;
            //                            return -1;
            //                        }
            //                }
            //                //check if initialized, if not abort
            //                int ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidInitialized) causedByAction:@"getting dpidInitialized"];
            //
            //                //here 0 is also considered an abort criteria, since it means that the device hasn't been initialized!
            //                if (ret <= 0)
            //                {
            //                    [self debugLog:[NSString stringWithFormat:@"Aborting, device not initialized, dpidInitialized returned %d!", ret]];
            //                    return ret;
            //                }
            //                //checking for required dark current measurement
            //                ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDarkCurrent) causedByAction:@"getting dpidNeedDarkCurrent"];
            //                if (ret != 0) {
            //                    [self debugLog:[NSString stringWithFormat:@"Aborting, dpidNeedDarkCurrent did not return 0, but %d! Prepare measurement first", ret]];
            //                    return ret;
            //                }
            //
            //            }
            
            //========================================================================================
            // set general integration time====add by annie 2013.7.12=========================
            //------------------------medth2 pass-----------------------------------------------------
            //autoExplodeFlag
            //            if (![mBlackPatternIntegraTimer isEqualToString:@"auto"])
            //            {
            if(pattern == 6)
            {
                if ([mBlackPatternIntegraTimer isEqualToString:@"auto"])
                {
                    if (!autoExplodeFlag)
                    {
                        casSetOptionsOnOff(_CASID, coAutorangeFilter, 1);
                        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 1);
                        [self debugLog:@"Prepare auto integration time successfully ++++ finished!"];
                        autoExplodeFlag=TRUE;
                    }
                    
                }else
                {
                    if (autoExplodeFlag) {
                        autoExplodeFlag=FALSE;
                        casSetOptionsOnOff(_CASID, coAutorangeFilter, 0);
                        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 0);
                    }
                    int prepareBlackFlag=[self PrepareMeasurement_IntergrTimer:dictKeyDefined :mBlackPatternIntegraTimer];
                    //int prepareBlackFlag=[self btnPrepareMeasurement_time:dictKeyDefined];
                    if (prepareBlackFlag < 0)
                    {
                        NSLog(@"Prepare black pattern integration time fail");
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prepare black pattern integration time fail "] ;
                        return -1;
                    }
                }
            }
            else
            {
                if ([mGeneralIntegrationTimer isEqualToString:@"auto"])
                {
                    if (!autoExplodeFlag)
                    {
                        casSetOptionsOnOff(_CASID, coAutorangeFilter, 1);
                        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 1);
                        [self debugLog:@"Prepare auto integration time successfully finished!"];
                        autoExplodeFlag=TRUE;
                    }
                    
                }else
                {
                    if (autoExplodeFlag) {
                        autoExplodeFlag=FALSE;
                        casSetOptionsOnOff(_CASID, coAutorangeFilter, 0);
                        casSetOptionsOnOff(_CASID, coAutorangeMeasurement, 0);
                    }
                    int prepareGeneralFlag=  [self PrepareMeasurement_IntergrTimer:dictKeyDefined :mGeneralIntegrationTimer];
                    //int prepareGeneralFlag=[self btnPrepareMeasurement_time:dictKeyDefined];
                    if (prepareGeneralFlag < 0 )
                    {
                        NSLog(@"Prepare black pattern integration time fail");
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Prepare black pattern integration time fail 2 "] ;
                        return -1;
                    }
                }
            }
            //check if initialized, if not abort
            int ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidInitialized) causedByAction:@"getting dpidInitialized"];
            //
            //here 0 is also considered an abort criteria, since it means that the device hasn't been initialized!
            if (ret <= 0)
            {
                [self debugLog:[NSString stringWithFormat:@"Aborting, device not initialized, dpidInitialized returned %d!", ret]];
                return ret;
            }
            //checking for required dark current measurement
            ret = [self checkCASError:casGetDeviceParameter(_CASID, dpidNeedDarkCurrent) causedByAction:@"getting dpidNeedDarkCurrent"];
            if (ret != 0) {
                [self debugLog:[NSString stringWithFormat:@"Aborting, dpidNeedDarkCurrent did not return 0, but %d! Prepare measurement first", ret]];
                return ret;
            }
            //           }
            
            //========================================================================================
            
            if([mWriteCmdSetLedCurrent isEqualToString:mWriteCmdSetFullLedCurrent]
               && ([mWriteCmdSetPattern isEqualToString:mWriteCmdToCyanPattern]
                   ||[mWriteCmdSetPattern isEqualToString:mWriteCmdToMagentaPattern]
                   ||[mWriteCmdSetPattern isEqualToString:mWriteCmdToYellowPattern]))
                continue;
            
            //jian sheng disable the code for engineer build
            /*else if([mWriteCmdSetLedCurrent isEqualToString:mWriteCmdSetDefaultLedCurrent]
               && ([mWriteCmdSetPattern isEqualToString:mWriteCmdToRedPattern]
                   ||[mWriteCmdSetPattern isEqualToString:mWriteCmdToGreenPattern]
                   ||[mWriteCmdSetPattern isEqualToString:mWriteCmdToBluePattern]
                   ||[mWriteCmdSetPattern isEqualToString:mWriteCmdToBlackPattern]))
                continue;*/
            //jian sheng disable the code for engineer build
            
            //==================send command to change pattern==========================
            
            bTmp = [self SendData:dictKeyDefined :mWriteCmdSetPattern :mPostfix] ;
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send command -setPattern fail "] ;
                ret = -1; return ret;
            }
            dateTmp=[[[NSDate alloc] init] autorelease] ;
            timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
            }
            NSString *dataResult = [self ReceData:dictKeyDefined] ;
            if([dataResult rangeOfString:@"Finish"].length <= 0)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data --setLedCurrent fail "] ;
                ret = -1; return ret;
            }
            
            //================sleep here======================================
            usleep([mUSleepTime intValue]);
            
            
            //==================measure==========================
            [self debugLog:@"Measuring spectrum"];
            ret = [self checkCASError:casMeasure(_CASID) causedByAction:@"casMeasure"];
            if (ret < 0) return ret;
            [self debugLog:@"Spectrum successfully measured"];
            
            int adcMax = [self checkCASError:casGetMeasurementParameter(_CASID, mpidMaxADCValue) causedByAction:@"getting mpidMaxADCValue"];
            if (adcMax < 0)
            {
                ret = -1;
                return ret;
            }
            [self debugLog:[NSString stringWithFormat:@"MaxADC = %d", adcMax]];
            NSLog(@"mpidMaxADCValue=%d",adcMax);
            
            int adcSaturated = [self checkCASError:casGetDeviceParameter(_CASID, dpidADCRange) causedByAction:@"getting dpidADCRange"];
            if (adcSaturated < 0)
            {
                ret = -1;
                return ret;
            }//already covered by checkCASError above
            NSLog(@"dpidADCRange=%d",adcSaturated);
            
            if (adcMax >= adcSaturated) {
                [self debugLog:@"Spectrum saturated - discard measurement!"];
                ret = -1;
                return ret;
            }
            
            ret = [self checkCASError:casColorMetric(_CASID) causedByAction:@"calculating colormetric"];
            if (ret == 0) {
                double integralValue = 0;
                unichar Buffer[256] = {0};
                casGetPhotIntW(_CASID, &integralValue, Buffer, 256);
                ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting PhotInt"];
                if (ret == 0) {
                    //================= PhotInt is Luminance ===============================
                    [self debugLog:[NSString stringWithFormat:@"PhotInt = %g %S", integralValue, (const unichar*)Buffer]];
                    luminance = [NSString stringWithFormat:@"PhotInt=%g%S", integralValue, (const unichar*)Buffer];
                    //luminance format is, PHotInt=0.0149272cd/(m*m)
                    NSLog(@"%@",luminance);
                    luminance = [NSString stringWithFormat:@"%g", integralValue];
                    luminanceUnit = [NSString stringWithFormat:@"%S", (const unichar*)Buffer];
                    
                }
                casGetRadIntW(_CASID, &integralValue, Buffer, 256);
                ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting RadInt"];
                if (ret == 0) {
                    [self debugLog:[NSString stringWithFormat:@"RadInt = %g %S", integralValue, (const unichar*)Buffer]];
                    NSLog(@"%@",[NSString stringWithFormat:@"RadInt = %g %S", integralValue, (const unichar*)Buffer]);
                }
                [self debugLog:[NSString stringWithFormat:@"LambdaDom = %.2f nm", casGetCentroid(_CASID)]];
                
                double colorX, colorY, colorZ, colorU, colorV1976, colorV1960 = 0;
                casGetColorCoordinates(_CASID, &colorX, &colorY, &colorZ, &colorU, &colorV1976, &colorV1960);
                ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting color coordinates"];
                if (ret==0) {
                    colorCoordinates = [NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ];
                    [self debugLog:[NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ]];
                    [self debugLog:[NSString stringWithFormat:@"u;v = (%.4f;%.4f)", colorU, colorV1960]];
                    [self debugLog:[NSString stringWithFormat:@"u';v' = (%.4f;%.4f)", colorU, colorV1976]];
                    NSLog(@"%@",[NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ]);
                    NSLog(@"%@",[NSString stringWithFormat:@"u;v = (%.4f;%.4f)", colorU, colorV1960]);
                    NSLog(@"%@",[NSString stringWithFormat:@"u';v' = (%.4f;%.4f)", colorU, colorV1976]);
                }
                double CCT = casGetCCT(_CASID);
                [self debugLog:[NSString stringWithFormat:@"CCT = %g K", CCT]];
                NSLog(@"CCT=%f",CCT);
                
            }
            else
            {
                ret = -1;
                return ret;
            }
            
            //==================set -write PDCA==========================
            //            colorCoordinates = @"(1;2;3)";
            //            luminance =@"8";
            //            luminanceUnit =@"cd/m*m";
            colorCoordinates = [ToolFun getStrFromPrefixAndPostfix:colorCoordinates Prefix:@"(" Postfix:@")"] ;
            arrayColorCoordinates = [colorCoordinates componentsSeparatedByString:@";"];
            //colorCoordinates format is x;y;z = (0.2345;0.5869;0.1786)
            if([arrayColorCoordinates count] != 3)
            {
                ret = -1; return ret;
            }
            NSString *colorCoordinateX = [arrayColorCoordinates objectAtIndex:0];
            NSString *colorCoordinateY = [arrayColorCoordinates objectAtIndex:1];
            
            
            if([mWriteCmdSetLedCurrent isEqualToString:mWriteCmdSetFullLedCurrent])
                subItemName = mFullLedCurrent;
            else
                subItemName = mDefaultLedCurrent;
            
            if([mWriteCmdSetPattern isEqualToString:mWriteCmdToRedPattern])
                subItemName = [subItemName stringByAppendingString:@"R"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToGreenPattern])
                subItemName = [subItemName stringByAppendingString:@"G"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToBluePattern])
                subItemName = [subItemName stringByAppendingString:@"B"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToCyanPattern])
                subItemName = [subItemName stringByAppendingString:@"C"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToMagentaPattern])
                subItemName = [subItemName stringByAppendingString:@"M"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToYellowPattern])
                subItemName = [subItemName stringByAppendingString:@"Y"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToWhitePattern])
                subItemName = [subItemName stringByAppendingString:@"W"];
            else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToBlackPattern])
                subItemName = [subItemName stringByAppendingString:@"Black"];
            if([subItemName isEqualToString:@"full_W"])
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :luminance];
                if( ([luminance floatValue] < 300) && WYFlag)
                {
                    UIAlert *alert = [[UIAlert alloc] init];
                    [alert showWindow:self];
                    [alert setMessageText:@"Error! Pls take the connection and take again"];
                    //[alert setInformativeText:@"Wrong Unit!"];
                    [alert addButtonWithTitle:@"OK"];
                    [alert runModal];
                    [alert release];
                    
                    pattern = pattern - 1;
                    WYFlag=NO;
                    continue;
                    
                    
                }
                
            }
            
            if([subItemName isEqualToString:@"full_W"])
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferNameFullWY :luminance];
            }
            if([subItemName isEqualToString:@"full_Black"])
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferNameFullBlackY :luminance];
            }
            
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[subItemName stringByAppendingString:@"x"]:nil:nil:nil:colorCoordinateX:nil:RESULT_FOR_PASS:@"PASS"];
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[subItemName stringByAppendingString:@"y"]:nil:nil:nil:colorCoordinateY:nil:RESULT_FOR_PASS:@"PASS"];
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[subItemName stringByAppendingString:@"Y"]:nil:nil:nil:luminance:luminanceUnit:RESULT_FOR_PASS:@"PASS"];
        }
    }
    //return ret;
    
    //3.===================set pattern in gray level==============================
    //if(number%10==0)
    if(1)
    {
        for(int pattern=0; pattern<4; pattern++)
        {
            luminance = @"";
            luminanceUnit = @"";
            colorCoordinates = @"";
            NSString *subItemNameGrayLevel = @"";
            
            
            if(pattern == 0) //rrggbb
            {
                mWriteCmdSetPattern = mWriteCmdToRedPattern;
                
                subItemNameGrayLevel = @"R";
            }
            else if(pattern == 1)
            {
                mWriteCmdSetPattern = mWriteCmdToGreenPattern;
                
                subItemNameGrayLevel = @"G";
            }
            else if(pattern == 2)
            {
                mWriteCmdSetPattern = mWriteCmdToBluePattern;
                
                subItemNameGrayLevel = @"B";
            }
            else if(pattern == 3)
            {
                mWriteCmdSetPattern = mWriteCmdToWhitePattern;
                
                subItemNameGrayLevel = @"W";
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"error Pattern in gray level "] ;
                ret = -1; return ret;
            }
            
            //==================send command to change pattern==========================
            
            bool bTmp = [self SendData:dictKeyDefined :mWriteCmdSetPattern :mPostfix] ;
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send command -setLedCurrent fail, gray level"] ;
                ret = -1; return ret;
            }
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
            }
            NSString *dataResult = [self ReceData:dictKeyDefined] ;
            if([dataResult rangeOfString:@"Finish"].length <= 0)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data --setPattern fail, gray level"] ;
                ret = -1; return ret;
            }
            
            //4.===================set gray level==============================
            //ListGrayLevel=0,8,16,24,32,41,49,57,65,74,82,90,98,106,115,123,131,139,148,156,164,172,180,189,197,205,213,222,230,238,246,255;
            double minLuminace = 54321.0;
            double maxLuminace = 0.0;
            NSString *storeLuminaceValue = @"";
            for(int grayLevel=0; grayLevel<[arrayGrayLevel count]; grayLevel++)
            {
                NSString *tmp = @"";
                tmp = [NSString stringWithFormat:@"%x",[[arrayGrayLevel objectAtIndex:grayLevel] intValue]];
                if([tmp length] < 2)
                {
                    NSString *zero = @"0";
                    tmp = [zero stringByAppendingString:tmp];
                }
                NSString *cmdSetGrayLevel = mWriteCmdSetGrayLevel;
                if([mWriteCmdSetPattern isEqualToString:mWriteCmdToRedPattern]) //rrggbb
                {
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"rr" withString:tmp];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"ggbb" withString:@"0000"];
                }
                else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToGreenPattern])
                {
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"gg" withString:tmp];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"rr" withString:@"00"];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"bb" withString:@"00"];
                }
                else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToBluePattern])
                {
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"bb" withString:tmp];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"rrgg" withString:@"0000"];
                }
                else if([mWriteCmdSetPattern isEqualToString:mWriteCmdToWhitePattern])
                {
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"rr" withString:tmp];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"gg" withString:tmp];
                    cmdSetGrayLevel = [cmdSetGrayLevel stringByReplacingOccurrencesOfString:@"bb" withString:tmp];
                }
                else
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"error Pattern in gray level "] ;
                    ret = -1; return ret;
                }
                
                //==================send command to change gray level==========================
                
                bTmp = [self SendData:dictKeyDefined :cmdSetGrayLevel :mPostfix] ;
                if (bTmp==false)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send command -setGrayLevel fail "] ;
                    ret = -1; return ret;
                }
                dateTmp=[[[NSDate alloc] init] autorelease] ;
                timeInterval = - [dateTmp timeIntervalSinceNow] ;
                while (timeInterval<=iTmp)
                {
                    timeInterval = -[dateTmp timeIntervalSinceNow] ;
                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                        break ;
                    else
                    {
                        usleep(100000) ; //delay 100ms
                    }
                }
                dataResult = [self ReceData:dictKeyDefined] ;
                if([dataResult rangeOfString:@"Finish"].length <= 0)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data --setGrayLevel fail "] ;
                    ret = -1; return ret;
                }
                
                
                //================sleep here======================================
                usleep([mUSleepTime intValue]);
                
                //==================measure==========================
                [self debugLog:@"Measuring spectrum"];
                ret = [self checkCASError:casMeasure(_CASID) causedByAction:@"casMeasure"];
                if (ret < 0) return ret;
                [self debugLog:@"Spectrum successfully measured"];
                
                int adcMax = [self checkCASError:casGetMeasurementParameter(_CASID, mpidMaxADCValue) causedByAction:@"getting mpidMaxADCValue"];
                if (adcMax < 0)
                {
                    ret = -1;
                    return ret;
                }
                [self debugLog:[NSString stringWithFormat:@"MaxADC = %d", adcMax]];
                NSLog(@"mpidMaxADCValue=%d",adcMax);
                
                int adcSaturated = [self checkCASError:casGetDeviceParameter(_CASID, dpidADCRange) causedByAction:@"getting dpidADCRange"];
                if (adcSaturated < 0)
                {
                    ret = -1;
                    return ret;
                }//already covered by checkCASError above
                NSLog(@"dpidADCRange=%d",adcSaturated);
                
                if (adcMax >= adcSaturated) {
                    [self debugLog:@"Spectrum saturated - discard measurement!"];
                    ret = -1;
                    return ret;
                }
                
                ret = [self checkCASError:casColorMetric(_CASID) causedByAction:@"calculating colormetric"];
                if (ret == 0) {
                    double integralValue = 0;
                    unichar Buffer[256] = {0};
                    casGetPhotIntW(_CASID, &integralValue, Buffer, 256);
                    ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting PhotInt"];
                    if (ret == 0) {
                        //================= PhotInt is Luminance ===============================
                        [self debugLog:[NSString stringWithFormat:@"PhotInt = %g %S", integralValue, (const unichar*)Buffer]];
                        luminance = [NSString stringWithFormat:@"PhotInt=%g%S", integralValue, (const unichar*)Buffer];
                        //luminance format is, PHotInt=0.0149272cd/(m*m)
                        NSLog(@"%@",luminance);
                        luminance = [NSString stringWithFormat:@"%g", integralValue];
                        luminanceUnit = [NSString stringWithFormat:@"%S", (const unichar*)Buffer];
                        
                    }
                    casGetRadIntW(_CASID, &integralValue, Buffer, 256);
                    ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting RadInt"];
                    if (ret == 0) {
                        [self debugLog:[NSString stringWithFormat:@"RadInt = %g %S", integralValue, (const unichar*)Buffer]];
                        NSLog(@"%@",[NSString stringWithFormat:@"RadInt = %g %S", integralValue, (const unichar*)Buffer]);
                    }
                    [self debugLog:[NSString stringWithFormat:@"LambdaDom = %.2f nm", casGetCentroid(_CASID)]];
                    
                    double colorX, colorY, colorZ, colorU, colorV1976, colorV1960 = 0;
                    casGetColorCoordinates(_CASID, &colorX, &colorY, &colorZ, &colorU, &colorV1976, &colorV1960);
                    ret = [self checkCASError:casGetError(_CASID) causedByAction:@"getting color coordinates"];
                    if (ret==0) {
                        colorCoordinates = [NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ];
                        [self debugLog:[NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ]];
                        [self debugLog:[NSString stringWithFormat:@"u;v = (%.4f;%.4f)", colorU, colorV1960]];
                        [self debugLog:[NSString stringWithFormat:@"u';v' = (%.4f;%.4f)", colorU, colorV1976]];
                        NSLog(@"%@",[NSString stringWithFormat:@"x;y;z = (%.4f;%.4f;%.4f)", colorX, colorY, colorZ]);
                        NSLog(@"%@",[NSString stringWithFormat:@"u;v = (%.4f;%.4f)", colorU, colorV1960]);
                        NSLog(@"%@",[NSString stringWithFormat:@"u';v' = (%.4f;%.4f)", colorU, colorV1976]);
                    }
                    double CCT = casGetCCT(_CASID);
                    [self debugLog:[NSString stringWithFormat:@"CCT = %g K", CCT]];
                    NSLog(@"CCT=%f",CCT);
                    
                }
                else
                {
                    ret = -1;
                    return ret;
                }
                //            colorCoordinates = @"(1;2;3)";
                //            luminance =@"8";
                //            luminanceUnit =@"cd/m*m";
                //==================set -write PDCA==========================
                colorCoordinates = [ToolFun getStrFromPrefixAndPostfix:colorCoordinates Prefix:@"(" Postfix:@")"] ;
                arrayColorCoordinates = [colorCoordinates componentsSeparatedByString:@";"];
                //colorCoordinates format is x;y;z = (0.2345;0.5869;0.1786)
                if([arrayColorCoordinates count] != 3)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no enough color value"] ;
                    ret = -1; return ret;
                }
                NSString *colorCoordinateX = [arrayColorCoordinates objectAtIndex:0];
                NSString *colorCoordinateY = [arrayColorCoordinates objectAtIndex:1];
                
                
                //gray level
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[[subItemNameGrayLevel stringByAppendingString:@"x-"] stringByAppendingString:[arrayGrayLevel objectAtIndex:grayLevel]]:nil:nil:nil:colorCoordinateX:nil:RESULT_FOR_PASS:@"PASS"];
                
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[[subItemNameGrayLevel stringByAppendingString:@"y-"] stringByAppendingString:[arrayGrayLevel objectAtIndex:grayLevel]]:nil:nil:nil:colorCoordinateY:nil:RESULT_FOR_PASS:@"PASS"];
                
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[[subItemNameGrayLevel stringByAppendingString:@"L-"] stringByAppendingString:[arrayGrayLevel objectAtIndex:grayLevel]]:nil:nil:nil:luminance:luminanceUnit:RESULT_FOR_PASS:@"PASS"];
                
                storeLuminaceValue = [storeLuminaceValue stringByAppendingString:luminance];
                storeLuminaceValue = [storeLuminaceValue stringByAppendingString:@","];
                
                if(grayLevel==0)
                {
                    minLuminace = [luminance doubleValue];
                    maxLuminace = [luminance doubleValue];
                }
                if([luminance doubleValue] < minLuminace)
                    minLuminace = [luminance doubleValue];
                if([luminance doubleValue] > maxLuminace)
                    maxLuminace = [luminance doubleValue];
            }
            
            //=======================calculate gamma=================================
            NSArray *tmpLumArray = [storeLuminaceValue componentsSeparatedByString:@","];
            if([tmpLumArray count] < [arrayGrayLevel count])
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no enough value to calculate gamma"] ;
                ret = -1; return ret;
            }
            
            double sumOf_X_Multiply_Y = 0.0;
            double sumOf_X = 0.0;
            double sumOf_Y = 0.0;
            double sumOf_X_Multiply_X = 0.0;
            
            for(int k=1; k<[arrayGrayLevel count]; k++)
            {
                double X = [[arrayGrayLevel objectAtIndex:k] doubleValue];
                if(X==0)
                    X=0.0000001;
                X = log10(X);
                
                double Y = [[tmpLumArray objectAtIndex:k] doubleValue];
                if(maxLuminace == 0)
                    maxLuminace = 0.0000001;
                Y = (Y - minLuminace) / maxLuminace;
                
                if(Y==0)
                    Y=0.0000001;
                Y = log10(Y);
                
                sumOf_X = sumOf_X + X;
                sumOf_Y = sumOf_Y + Y;
                sumOf_X_Multiply_X = sumOf_X_Multiply_X + X*X;
                sumOf_X_Multiply_Y = sumOf_X_Multiply_Y + X*Y;
            }
            //gamma = slope
            double gamma = (sumOf_Y*sumOf_X - ([arrayGrayLevel count] - 1)*sumOf_X_Multiply_Y) / (sumOf_X*sumOf_X - ([arrayGrayLevel count] - 1)*sumOf_X_Multiply_X);
            
            //        NSLog(@"gamma string =%@",[NSString stringWithFormat:@"%f",gamma]);
            //
            //        NSLog(@"gamma g =%g",gamma);
            //
            //        NSLog(@"gamma f =%f",gamma);
            //
            //NSLog(@"gamma lu =%lu",gamma);
            
            // [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[subItemNameGrayLevel stringByAppendingString:@"-gamma"]:nil:nil:nil:[NSString stringWithFormat:@"%g",gamma]:nil:RESULT_FOR_PASS:@"PASS"];
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[subItemNameGrayLevel stringByAppendingString:@"-gamma"]:nil:nil:nil:[NSString stringWithFormat:@"%f",gamma]:nil:RESULT_FOR_PASS:@"PASS"];
            
            
        }
        
        
        number++;
        
        return ret;
    }
    else
    {
        number++;
    }
    
}

+(void)ParseDivideTwoBuffer:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mReferenceBufferName2=nil;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName2"])//Added by Julian for QL Proto1 dryrun
		{
			mReferenceBufferName2=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
    }
    
    if([mUpperValue isEqualTo:@"NA"])
    {
        mUpperValue = nil;
    }
    if([mLowerValue isEqualTo:@"NA"])
    {
        mLowerValue = nil;
    }
    
    if(mReferenceBufferName==nil || mReferenceBufferName2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    
    
    if (mReferenceBufferValue==nil || mReferenceBufferValue2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
	if([mReferenceBufferValue2 doubleValue] == 0)
        mReferenceBufferValue2 = @"-1";
    double resultValue = [mReferenceBufferValue2 doubleValue] / [mReferenceBufferValue doubleValue];
    
	
    
    if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue doubleValue]))
       && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
    {
        enumResult =RESULT_FOR_PASS ;
    }else 
    {
        enumResult =RESULT_FOR_FAIL ;
    }
    
    strTestResultForUIinfo = [NSString stringWithFormat:@"%0.3f",resultValue] ;
    
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	return;
}

@end
