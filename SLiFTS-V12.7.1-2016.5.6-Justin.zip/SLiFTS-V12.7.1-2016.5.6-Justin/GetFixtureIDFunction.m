//
//  StringParseFuncation.m
//  qt_simulator
//
//  Created by Jun-Bo on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "GetTestTimeFunction.h"
#import "UICommon.h"
#import "Pudding.h"

@implementation TestItemParse(GetFixtureIDFunction)

+(void)GetFixtureID:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	// serin 20100913
	NSString* FixtureID=nil;
	NSArray *FixtureIDArray	= nil;
	FixtureID=[UICommon getFixtureID];
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSString* FixtureIDNum=@"";
	//end
	FixtureIDArray = [FixtureID componentsSeparatedByString:@"_"];
	FixtureIDNum = [FixtureIDArray objectAtIndex:(NSUInteger)1];
	if(FixtureIDNum == nil )
	//if (FixtureID==nil)
	// end 
		
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Get Fixture ID Fail" ;
		
	}
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = FixtureID ;
	}
	if (mBufferName!=nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :FixtureID] ;

	// serin 20100913
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Fixture ID":nil:nil:nil:FixtureIDNum:nil:IP_NA:nil];	

    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

@end
