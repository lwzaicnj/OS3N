//
//  testExecution.h
//  DisplayPort
//
//  Created by Wei on 8/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "iFactoryTest/IFTPlugIn.h"

@interface IFTTestExecution : NSThread {
	NSMutableDictionary* mutDicDPResult;
	IFTestSuite* suite;
	NSArray* testFlow;
	int runCount;
	NSError* e;
	BOOL testResult;
	NSString* firstItemName;
	NSString* HDCPFlag;
}
@property (readonly) IFTestSuite* suite;
@property (readwrite) int runCount;

-(id)initWithSuite:(IFTestSuite*)p_suite;
-(void)main;
-(BOOL)getTestResult;
-(NSMutableDictionary*) getSubItemResult;
/*SCRID:28
//added by caijunbo on 2010-11-29
//Description:Change DisplayPort Test that support freely to add and remove items in Testconfig.plist
*/
-(NSString*)getFirstItemName;
//end

//SCRID:30
//added by caijunbo on 2010-12-10
-(NSString*)getHDCPFlag;
-(void)setHDCPFlag:(NSString*)flag;
//end


@end
