//
//  DCR.h
//  iFTS
//
//  Created by Foxconn001 on 10-9-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import <VISA/VISA.h>

@interface TestItemParse(DCR)
//GPIB Functions
+(void)GPIBInitialDevice:(NSDictionary* )keys;
+(void)GPIBReleaseDevice:(NSDictionary* )keys;
+(void)GPIBSwitchToLowResistance:(NSDictionary*)keys;
+(void)GPIBReadResistance:(NSDictionary*)keys;
+(void)WhetherPressRightButton:(NSDictionary*)keys;

@end
