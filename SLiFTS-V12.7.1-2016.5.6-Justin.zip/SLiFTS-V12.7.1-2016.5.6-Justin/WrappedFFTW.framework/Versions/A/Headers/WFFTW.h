#include <WrappedFFTW/fftw3.h>

namespace WFFTW
{
	void *fftw_malloc(size_t);
	void  fftw_free(void *);

	void fftw_execute(fftw_plan p);
	
	void fftw_destroy_plan(fftw_plan p);

	fftw_plan fftw_plan_dft_c2r_1d(int n, fftw_complex *in, double *out, unsigned flags);
	fftw_plan fftw_plan_dft_r2c_1d(int n, double *in, fftw_complex *out, unsigned flags);
};