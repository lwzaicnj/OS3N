//
//  ParseCL200AData.h
//  iFTS
//
//  Created by justin on 10/16/15.
//
//

#import <Foundation/Foundation.h>

@interface ParseCL200AData : NSObject
+(BOOL)OpenSerialPort;
+(BOOL)CL200AInitialize;
+(BOOL)CL200ASecInitialize;
+(NSString*)CL200APerformMeasurement;
+(void)CloseSerialPort;
+(void)CloseSecSerialPort;
+(NSString*)CL200ASecPerformMeasurement;
+(BOOL)OpenSecSerialPort;
@end
