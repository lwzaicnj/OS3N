//
//  ProxIQCParse.h
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ProxIQCParse)

//For Calculate Average
+(void)ParseProxMult_QL2:(NSDictionary*)dictKeyDefined;
+(void)ParseProxMult_QL3:(NSDictionary*)dictKeyDefined;
//For Calculate Deviation
+(void)ParseProxIQC:(NSDictionary*)dictKeyDefined;

+(void)ParseAccelerometerIntr:(NSDictionary*)dictKeyDefined;
+(void)ParseMultStrSpec:(NSDictionary*)dictKeyDefined;
//Ray add for P105 DVT 2012-07-30
+(void)ParseProxShortAver:(NSDictionary*)dictKeyDefined;
+(void)ParseProxOpenSD:(NSDictionary*)dictKeyDefined;

//add by kevin 20140625 for RL QT0a ALS1 and ALS2 start
+(void)ParseAlsMult_QT0a:(NSDictionary*)dictKeyDefined;
//End
@end
