//
//  ParseVbinScreenFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseVbinScreenFunction.h"


@implementation TestItemParse(ParseVbinScreenFunction)

+(void)ParseVbinScreen:(NSDictionary*) DictionaryPtr
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mStrSpec=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	//upload Vmin,Vmid,Vmax to pdca
	
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\n"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\r"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\t"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@" "] ;
	
	NSString *strVmin;
	NSString *strVmid;
	NSString *strVmax;
	NSRange range;
	
	range = [mReferenceBufferValue rangeOfString:@"Vmin"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"returning string from diag error!"] ;
		return ;
	}
	else 
	{
		range.location=range.location+5;
		range.length=5;
		strVmin=[mReferenceBufferValue substringWithRange:range];
	}
	
	range = [mReferenceBufferValue rangeOfString:@"Vmid"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"returning string from diag error!"] ;
		return ;
	}
	else 
	{
		range.location=range.location+5;
		range.length=5;
		strVmid=[mReferenceBufferValue substringWithRange:range];
	}
	
	range = [mReferenceBufferValue rangeOfString:@"Vmax"];
	if (range.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"returning string from diag error!"] ;
		return ;
	}
	else 
	{
		range.location=range.location+5;
		range.length=5;
		strVmax=[mReferenceBufferValue substringWithRange:range];
	}

	
		
		NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
		
		if (rangeTmp.length > 0)  //PASS  conditional 
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = @"Pass" ;
			
			if (strVmax!=nil && strVmid!=nil && strVmin!=nil)
			{
				
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmin":nil:nil:nil:strVmin:nil:RESULT_FOR_PASS:@"PASS"];
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmid":nil:nil:nil:strVmid:nil:RESULT_FOR_PASS:@"PASS"];
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmax":nil:nil:nil:strVmax:nil:RESULT_FOR_PASS:@"PASS"];
			}
		}
		
		else //failse conditional
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = @"Fail" ;
			
			if (strVmax!=nil && strVmid!=nil && strVmin!=nil)
			{
				
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmin":nil:nil:nil:strVmin:nil:RESULT_FOR_FAIL:@"FAIL"];
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmid":nil:nil:nil:strVmid:nil:RESULT_FOR_FAIL:@"FAIL"];
				[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Vmax":nil:nil:nil:strVmax:nil:RESULT_FOR_FAIL:@"FAIL"];
			}
		}
		
	
    [TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}



@end
