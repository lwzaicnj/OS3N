/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIModuleSN.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIModuleSN.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */


#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"


@interface UISensor1020X640: NSObject {
	
	//iboutlet variable
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelCopy ;
	IBOutlet NSTextField *textLabelIPVersion ;

	IBOutlet NSTextField *textTotalTime;
	IBOutlet NSTextField *textItemTime;
	IBOutlet NSTextField *textModuleSN;
	IBOutlet NSTextField *textTestResult;

	IBOutlet NSButton* btnStart;
	IBOutlet NSButton* btnExit;
	IBOutlet NSButton* btnSimulator;
	IBOutlet NSButton* btnLogMaxMin;
	
	IBOutlet NSTableView *tvTableview ;
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	IBOutlet NSTabView	 *tvTabview ;
	IBOutlet NSScrollView* textTestResultDetail ;
	IBOutlet NSScrollView* textAllLog ;
	IBOutlet NSScrollView* textItemLog ;
	IBOutlet NSScrollView *testItemScroView ;
	IBOutlet NSBox *boxTestState ;
	IBOutlet NSTextField* textLabelModuleSn;
	
	NSMutableString *stringModuleSn;
	IBOutlet NSWindow *window;
	NSDictionary *dicScanData;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
}

-(IBAction)btnStart_Click:(id)sender;
-(IBAction)btnCancel_Click:(id)sender;
-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)textModuleSnChange:(id)sender;
-(IBAction)btnTabViewMaxMin_Click:(id)sender;
-(IBAction)setFixtureID:(id)sender;
-(void)showInitLog;
-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(IBAction)btnSimulator_Click:(id)sender;
-(void)showItemLog;
-(NSString *)getItemClickedString;
-(void)setTableBgdColor:(NSNotification*)notification;
-(void)showItemLog;
-(void)showTestResult;
-(void)tabViewItemUpdate:(NSInteger)index ;
-(IBAction)CallEditScriptUI:(id)sender ;
@end
