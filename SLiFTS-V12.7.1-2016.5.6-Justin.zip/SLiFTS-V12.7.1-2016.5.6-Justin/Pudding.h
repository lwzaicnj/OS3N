//
//  Pudding.h
//  QTPudding
//
//  Created by Kingking on 3/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "InstantPudding_API.h"

#define PUDDING_PASS				0
#define PUDDING_ADD_ATTR_FAIL		-1
#define PUDDING_ADD_BLOB_FAIL		-2
#define PUDDING_UUT_START_FAIL		-3
#define PUDDING_UUT_DONE_FAIL		-4
#define PUDDING_UUT_COMMIT_FAIL		-5
#define PUDDING_ADD_RLT_FAIL		-6




@interface Pudding : NSObject {
	IP_UUTHandle UID;
	bool failedAtLeastOneTest;
	
}
-(NSString * )initPuddingWithSwVersion:(NSString *)SwVersion
						  SwName:(NSString *)SwName
					SerialNumber:(NSString *)SN
				   LimitsVersion:(NSString *)LimitsVersion
			   StationIdentifier:(NSString *)StationIdentifier
                       StartTime:(long)StartTime;

-(int )puddingWithParametricDataForTestItem:(NSString *)testName
							   SubTestItem:(NSString *)SubTestItem
							SubSubTestItem:(NSString *)SubSubTestItem
								  LowLimit:(NSString *)LowLimit
								   UpLimit:(NSString *)UpLimit	
								 TestValue:(NSString *)TestValue
								  TestUnit:(NSString *)TestUnit
								 TestResult:(enum IP_PASSFAILRESULT)TestResult
								   FailMsg:(NSString *)FailMsg
								   Priority:(enum IP_PDCA_PRIORITY)Priority;

-(int )puddingWithParametricDataForTestItem_NoMLB:(NSString *)testName
                                      SubTestItem:(NSString *)SubTestItem
                                   SubSubTestItem:(NSString *)SubSubTestItem
                                         LowLimit:(NSString *)LowLimit
                                          UpLimit:(NSString *)UpLimit	
                                        TestValue:(NSString *)TestValue
                                         TestUnit:(NSString *)TestUnit
                                       TestResult:(enum IP_PASSFAILRESULT)TestResult
                                          FailMsg:(NSString *)FailMsg
                                         Priority:(enum IP_PDCA_PRIORITY)Priority;

-(int )puddingWithoutParametricDataForTestItem:(NSString *)testName
								   SubTestItem:(NSString *)SubTestItem
								SubSubTestItem:(NSString *)SubSubTestItem
									  LowLimit:(NSString *)LowLimit
									   UpLimit:(NSString *)UpLimit	
									// TestValue:(NSString *)TestValue
									  TestUnit:(NSString *)TestUnit
									TestResult:(enum IP_PASSFAILRESULT)TestResult
									   FailMsg:(NSString *)FailMsg
									  Priority:(enum IP_PDCA_PRIORITY)Priority;
-(NSString *)puddingAttributeWithKeyName:(NSString *)KeyName
						andKeyValue:(NSString *)KeyValue;
-(int )puddingBlobWithNameInPDCA:(NSString *)NameInPDCA
						 FilePath:(NSString *)FilePath; 
-(NSString *)puddingCommit;
@end
