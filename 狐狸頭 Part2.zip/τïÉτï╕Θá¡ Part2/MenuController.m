//
//  MenuController.m
//  iLIB
//
//  Created by MAC008 on 10-7-12.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MenuController.h"


@implementation MenuController
-(IBAction) CloseWindow:(id)sender
{
	[mainWin performClose:self ];
}
-(IBAction) StartTest:(id)sender
{
	[btnStart performClick:nil];
//	[self getRemark];
}
-(IBAction) PauseTest:(id)sender
{
	[btnPause performClick:nil];
}
-(IBAction) MinimizeWindow:(id)sender
{
	[mainWin performMiniaturize:self ];
}
-(IBAction) MaxmizeWindow:(id)sender
{
	[mainWin performZoom:self ];
}
-(IBAction) MaxMinTabView:(id)sender
{
	[btnTabViewMaxMin performClick:nil];
}
-(IBAction) ShowResult:(id)sender
{
	NSTabViewItem *tabViewItemResult = [tabView tabViewItemAtIndex:0];
	if(tabViewItemResult != nil)
		[tabView selectTabViewItem:tabViewItemResult];
}
-(IBAction) ShowAllLog:(id)sender
{
	NSTabViewItem *tabViewItemAllLog = [tabView tabViewItemAtIndex:1];
	if(tabViewItemAllLog != nil)
		[tabView selectTabViewItem:tabViewItemAllLog];
}
-(IBAction) ShowItemLog:(id)sender
{
	NSTabViewItem *tabViewItemItemLog = [tabView tabViewItemAtIndex:2];
	if(tabViewItemItemLog != nil)
		[tabView selectTabViewItem:tabViewItemItemLog];
}
-(NSString *) getRemark
{
	NSString * strRemark = @"";
	if(textLabelRemark != nil)
		strRemark = [textLabelRemark stringValue];
	return strRemark ;
}

@end
