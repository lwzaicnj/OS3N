//
//  CurrentAutoTest.m
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

#import "NetWorkBasedCB.h"
#import "CBAuth_API.h"
#import "InstantPudding_API.h"

//SCRID:136
//author:caijunbo on 2011-09-27 SL
//description:Implement Network Based Control bit and test flow

@implementation TestItemParse(NetWorkBasedCBFunction)

+(void)CBCheckAndInit:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mBufferName=nil;
    NSString *mMyStationCB=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ThisStationCB"])
        {
            mMyStationCB = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName==nil||mMyStationCB==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
        return;
    }
    
    // used to get all CB status
    NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
        return;
    }
    
    //Add by Lucky for grab SOCHOT ERROR 2012-03-16
    NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
    NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
    NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
    NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
    NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
    
    if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
        return ;
    }
    //Lucky add end 2012-03-16
    
    NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
    
    //step 1: validate sn
    NSString* strSNToVerify=nil;
    NSString* strFailMSG=@"Fail ";
    
    IP_UUTHandle UID=NULL;
    IP_API_Reply reply = IP_UUTStart(&UID);
    if (IP_success(reply))
    {
        strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
        if (strSNToVerify==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
            return;
        }
        
        reply=IP_validateSerialNumber(UID, [strSNToVerify UTF8String]);
        if (!IP_success(reply))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SN is invalid"];
            const char* DoneError = IP_reply_getError(reply);
            NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
            strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
            NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
            IP_API_Reply cancelreply = IP_UUTCancel(UID);
            IP_reply_destroy(cancelreply);
            IP_reply_destroy(reply);
            IP_UID_destroy(UID);
            return;
        }
        
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to verify SN"];
        const char* DoneError = IP_reply_getError(reply);
        NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
        strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
        NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
        IP_API_Reply cancelreply = IP_UUTCancel(UID);
        IP_reply_destroy(cancelreply);
        IP_reply_destroy(reply);
        IP_UID_destroy(UID);
        
        return ;
        
    }
    
    IP_API_Reply cancelreply = IP_UUTCancel(UID);
    IP_reply_destroy(cancelreply);
    IP_reply_destroy(reply);
    IP_UID_destroy(UID);
    
    
    //step 2: Check all CBs listed
    
    char* p=NULL;
    p=(char *)cbSNGetVersion();
    NSLog(@"%@",[NSString stringWithUTF8String:p]);
    
    
    BOOL bCheckPriorCB=FALSE;
    size_t sLength=0;
    //First call of Control bits to check
    int intCheckPriorCB = GetCountCBsToCheckSN([strSNToVerify UTF8String]);
    int intCheckPriorCBXXXX = ControlBitsToCheckSN([strSNToVerify UTF8String],NULL,&sLength,NULL);
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 0 sLength return = %lu",sLength);
    if(sLength<=0)
        bCheckPriorCB=ControlBitsToCheck(NULL,&sLength,NULL);
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 return = %d",intCheckPriorCB);
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 intCheckPriorCBXXXX return = %d",intCheckPriorCBXXXX);
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 sLength return = %lu",sLength);
    //Second call of Control bits to check
    if (bCheckPriorCB || sLength>0) //old||new API
    {
        int* iControlBitsArray=new int[sLength];
        char** cpControlBitNames=(char**) malloc(sLength* sizeof(char*));
        for (int i=0;i<sLength;i++)
            cpControlBitNames[i]=new char[256];
        int intCheckPriorCB=ControlBitsToCheckSN([strSNToVerify UTF8String],iControlBitsArray,&sLength,cpControlBitNames);
        if(sLength<=0)
            bCheckPriorCB=ControlBitsToCheck(iControlBitsArray,&sLength,cpControlBitNames);
        NSLog(@"\n\nnetwork cb ControlBitsToCheckSN return = %d",intCheckPriorCB);
        NSLog(@"\n\nnetwork cb ControlBitsToCheckSN sLength = %lu",sLength);
        //if (bCheckPriorCB)
        if (bCheckPriorCB ||sLength>0)  //old||new API
        {
            int iControlBitIndex=-1;
            //NSString* strControlBitStatus=nil;
            NSString* strFailMSG=@" CB Check Fail";
            //NSArray* arraySingleStationCBStatus=nil;
            
            for (int j=0;j<sLength;j++)
            {
                NSLog(@"\n\nnetwork cb ControlBitsToCheckSN sLength2 = %lu",sLength);
                iControlBitIndex=iControlBitsArray[j];
                
                //strControlBitStatus=[arrayAllControlBits objectAtIndex:(iControlBitIndex+1)];
                //arraySingleStationCBStatus=[strControlBitStatus componentsSeparatedByString:@" "];
                //if (![[arraySingleStationCBStatus objectAtIndex:1] isEqualToString:@"Passed"])
                
                NSString *needCheckCBAddress = [NSString stringWithFormat:@"0x%X",iControlBitIndex];  //find,like 0xC1
                if([needCheckCBAddress length] < 4)
                {
                    needCheckCBAddress = [needCheckCBAddress stringByReplacingOccurrencesOfString:@"0x" withString:@"0x0"];
                }
                NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:needCheckCBAddress Postfix:@"0x"] ;
                NSLog(@"\n network cb needCheckCBAddress=%@, strFind=%@",needCheckCBAddress,strFind);
                if (!([strFind rangeOfString:@"Passed"].length > 0))
                {
                    NSString* strTemp=[NSString stringWithCString:cpControlBitNames[j] encoding:NSASCIIStringEncoding];
                    strFailMSG=[strTemp stringByAppendingString:strFailMSG];
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFailMSG];
                    //befor return,need to release memory.
                    for (int k=0;k<sLength;k++)
                    {
                        delete [] cpControlBitNames[k];
                    }
                    delete [] cpControlBitNames;
                    delete [] iControlBitsArray;
                    //end release memory
                    return;
                }
            }
            //after check all station CBs,need to release memory.
            
            for (int k=0;k<sLength;k++)
            {
                delete [] cpControlBitNames[k];
            }
            delete [] cpControlBitNames;
            delete [] iControlBitsArray;
            //end release memory
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CBs Check Error"];
            //befor return,need to release memory.
            for (int k=0;k<sLength;k++)
            {
                delete [] cpControlBitNames[k];
            }
            delete [] cpControlBitNames;
            delete [] iControlBitsArray;
            //end release memory
            return;
        }
        
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs Check is not on or no station to check"];
        return;
    }
    
    
    //step 3:check allowed fail count of my station.
    
    int iAllowedFailCount=0;
    int iRealFailCount=0;
    int iMyStationIndex=strtol([mMyStationCB UTF8String], NULL, 16);
    NSString* strMyStationCBStatus=[arrayAllControlBits objectAtIndex:(iMyStationIndex+1)];
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN strMyStationCBStatus = %@",strMyStationCBStatus);
    NSArray* arrayMyStationCBStatus=[strMyStationCBStatus componentsSeparatedByString:@" "];
    iRealFailCount=[[arrayMyStationCBStatus objectAtIndex:2] intValue];
    iAllowedFailCount=StationFailCountAllowed();
    //iAllowedFailCount=StationFailCountAllowedSN([strSNToVerify UTF8String]);
    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN AllowFailCount = %d,iRealFailCount = %d",iAllowedFailCount,iRealFailCount);
    if(iAllowedFailCount < 0)
    {
        [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Network CBs Check is not on, or allow fail count < 0"];
        return;
    }
    if (iRealFailCount>=iAllowedFailCount)
    {
        [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UUT Total Fail Count out of Allowed"];
        return;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
    
}
//+(void)CBCheckAndInit:(NSDictionary*)dictKeyDefined
//{
//	NSString *mTestItemName=nil;
//	NSString *mReferenceBufferName=nil;
//	NSString *mBufferName=nil;
//	NSString *mMyStationCB=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"BufferName"])
//		{
//			mBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ThisStationCB"])
//		{
//			mMyStationCB = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	if (mReferenceBufferName==nil || mMyStationCB==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
//		return;
//	}
//	
//	// used to get all CB status
//	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//	
//	if (mReferenceBufferValue==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
//		return;
//	}
//	
//	//Add by Lucky for grab SOCHOT ERROR 2012-03-16
//	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
//	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
//	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
//	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
//	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
//	
//	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
//		return ;
//	}
//	//Lucky add end 2012-03-16
//	
//	NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
//    
//	//step 1: validate sn
//	NSString* strSNToVerify=nil;
//	NSString* strFailMSG=@"Fail ";
//	IP_UUTHandle UID=NULL;
//	IP_API_Reply reply = IP_UUTStart(&UID);
//	if (IP_success(reply))
//	{
//		if(mBufferName==nil)//Changed for PS Interposer
//        {
//            strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
//            if (strSNToVerify==nil)
//                strSNToVerify = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
//        }
//        else
//        {
//            strSNToVerify=[TestItemManage getBufferValue:dictKeyDefined :mBufferName];//Changed code for iPad-1, get MLB sn to verify----Julian20120725
//        }
//		if (strSNToVerify==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
//			return;
//		}
//		
//		reply=IP_validateSerialNumber(UID, [strSNToVerify UTF8String]);
//		if (!IP_success(reply))
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SN is invalid"];
//			const char* DoneError = IP_reply_getError(reply);
//			NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//			strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//			NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
//			return;
//		}
//        
//	}
//	else
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to verify SN"];
//		const char* DoneError = IP_reply_getError(reply);
//		NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//		strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//		NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//		IP_API_Reply cancelreply = IP_UUTCancel(UID);
//		IP_reply_destroy(cancelreply);
//		IP_reply_destroy(reply);
//		IP_UID_destroy(UID);
//		
//		return ;
//		
//	}
//	
//	IP_API_Reply cancelreply = IP_UUTCancel(UID);
//	IP_reply_destroy(cancelreply);
//	IP_reply_destroy(reply);
//	IP_UID_destroy(UID);
//	
//	
//	//step 2: Check all CBs listed
//	
//	char* p=NULL;
//	p=(char *)cbSNGetVersion();
//	NSLog(@"%@",[NSString stringWithUTF8String:p]);
//	
//	
//	//BOOL bCheckPriorCB=FALSE;
//	size_t sLength=0;
//	//First call of Control bits to check
//    int intCheckPriorCB = GetCountCBsToCheckSN([strSNToVerify UTF8String]);
//	int intCheckPriorCBXXXX = ControlBitsToCheckSN([strSNToVerify UTF8String],NULL,&sLength,NULL);
//    NSLog(@"\nGetCountCBsToCheckSN %d",intCheckPriorCB);
//	NSLog(@"\nControlBitsToCheckSN %d",intCheckPriorCBXXXX);
//	//Second call of Control bits to check
//	//if (bCheckPriorCB&&sLength>0)
//    if ((intCheckPriorCB>0) && (sLength>0))
//	{
//		int* iControlBitsArray=new int[sLength];
//		char** cpControlBitNames=(char**) malloc(sLength* sizeof(char*));
//		for (int i=0;i<sLength;i++)
//			cpControlBitNames[i]=new char[256];
//		//bCheckPriorCB=ControlBitsToCheck(iControlBitsArray,&sLength,cpControlBitNames);
//        int intCheckPriorCB=ControlBitsToCheckSN([strSNToVerify UTF8String],iControlBitsArray,&sLength,cpControlBitNames);
//        NSLog(@"\nControlBitsToCheckSN return = %d",intCheckPriorCB);
//		NSLog(@"\nControlBitsToCheckSN sLength = %lu",sLength);
//		//if (bCheckPriorCB)
//        if (intCheckPriorCB>0)
//		{
//			int iControlBitIndex=-1;
//			NSString* strControlBitStatus=nil;
//			//NSString* strFailMSG=@" CB Check Fail";
//			//NSArray* arraySingleStationCBStatus=nil;
//			
//			for (int j=0;j<sLength;j++)
//			{
//				NSLog(@"\n\nnetwork cb ControlBitsToCheckSN sLength2 = %lu",sLength);
//				iControlBitIndex=iControlBitsArray[j];
//				strControlBitStatus=[arrayAllControlBits objectAtIndex:(iControlBitIndex+1)];
//                //				arraySingleStationCBStatus=[strControlBitStatus componentsSeparatedByString:@" "];
//				if([strControlBitStatus rangeOfString:@"Passed"].length <=0)
//				{
//					NSString* strTemp=[NSString stringWithCString:cpControlBitNames[j] encoding:NSASCIIStringEncoding];
//					//strFailMSG=[strTemp stringByAppendingString:strFailMSG];
//                    strFailMSG=[strTemp stringByAppendingString:strControlBitStatus];
//					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFailMSG];
//					//befor return,need to release memory.
//					for (int k=0;k<sLength;k++)
//					{
//						delete [] cpControlBitNames[k];
//					}
//					delete [] cpControlBitNames;
//					delete [] iControlBitsArray;
//					//end release memory
//					return;
//				}
//			}
//			//after check all station CBs,need to release memory.
//			
//			for (int k=0;k<sLength;k++)
//			{
//				delete [] cpControlBitNames[k];
//			}
//			delete [] cpControlBitNames;
//			delete [] iControlBitsArray;
//			//end release memory
//		}
//		else
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CBs Check Error"];
//			//befor return,need to release memory.
//			for (int k=0;k<sLength;k++)
//			{
//				delete [] cpControlBitNames[k];
//			}
//			delete [] cpControlBitNames;
//			delete [] iControlBitsArray;
//			//end release memory
//			return;
//		}
//		
//	}
//	else
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs Check is not on or no station to check"];
//		return;
//	}
//	
//    
//	//step 3:check allowed fail count of my station.
//	
//	int iAllowedFailCount=0;
//	int iRealFailCount=0;
//	int iMyStationIndex=strtol([mMyStationCB UTF8String], NULL, 16);
//	NSString* strMyStationCBStatus=[arrayAllControlBits objectAtIndex:(iMyStationIndex+1)];
//	NSArray* arrayMyStationCBStatus=[strMyStationCBStatus componentsSeparatedByString:@" "];
//	iRealFailCount=[[arrayMyStationCBStatus objectAtIndex:2] intValue];
//    NSLog(@"iRealFailCount is %d\n",iRealFailCount);
//	iAllowedFailCount=StationFailCountAllowed();
//    NSLog(@"StationFailCountAllowed is %d\n",iAllowedFailCount);
//    //iAllowedFailCount=StationFailCountAllowedSN([strSNToVerify UTF8String]);
//    //NSLog(@"StationFailCountAllowedSN is %d\n",iAllowedFailCount);
//	if(iAllowedFailCount < 0)
//	{
//		[TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Network CBs Check is not on, or allow fail count < 0"];
//		return;
//	}
//	if (iRealFailCount>=iAllowedFailCount)
//	{
//        //		[TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UUT Total Fail Count out of Allowed"];
//        //		return;
//        [TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UUT Total Fail Count out of Allowed"];
//        
//        NSString* sMes= [NSString stringWithFormat:@"Fail count is %d >= %d",iRealFailCount,iAllowedFailCount];
//        NSRunAlertPanel(@"Warning", sMes, @"Stop", nil, nil) ;
//        NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];
//        [TestItemManage StopTest:[strDUTID intValue]];
//		return;
//	}
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//    return;
//	
//}


//+(void)CBCheckAndInit:(NSDictionary*)dictKeyDefined
//{
//	NSString *mTestItemName=nil;
//	NSString *mReferenceBufferName=nil;
//	NSString *mBufferName=nil;
//	NSString *mMyStationCB=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"BufferName"])
//		{
//			mBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ThisStationCB"])
//		{
//			mMyStationCB = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	if (mReferenceBufferName==nil||mMyStationCB==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
//		return;
//	}
//	
//	// used to get all CB status
//	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//	
//	if (mReferenceBufferValue==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
//		return;
//	}
//	
//	//Add by Lucky for grab SOCHOT ERROR 2012-03-16
//	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
//	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
//	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
//	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
//	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
//	
//	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
//		return ;
//	}
//	//Lucky add end 2012-03-16
//	
//	NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
//	
//	//step 1: validate sn
//	NSString* strSNToVerify=nil;
//	NSString* strFailMSG=@"Fail ";
//	IP_UUTHandle UID=NULL;
//	IP_API_Reply reply = IP_UUTStart(&UID);
//	if (IP_success(reply))
//	{
//     //add by keivn on 20150314 start
//        if(mBufferName==nil)//Changed for PS Interposer
//        {
//            strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
//            if (strSNToVerify==nil)
//                strSNToVerify = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
//        }
//        else
//        {
//            strSNToVerify=[TestItemManage getBufferValue:dictKeyDefined :mBufferName];//Changed code for iPad-1, get MLB sn to verify----Julian20120725
//        }
////add by keivn on 20150314 end
//        
//		//strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];//disable by kevin on 20150314
//		if (strSNToVerify==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
//			return;
//		}
//		
//		reply=IP_validateSerialNumber(UID, [strSNToVerify UTF8String]);
//		if (!IP_success(reply))
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SN is invalid"];
//			const char* DoneError = IP_reply_getError(reply);
//			NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//			strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//			NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
//			return;
//		}
//		
//	}
//	else 
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to verify SN"];
//		const char* DoneError = IP_reply_getError(reply);
//		NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//		strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//		NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//		IP_API_Reply cancelreply = IP_UUTCancel(UID);
//		IP_reply_destroy(cancelreply);
//		IP_reply_destroy(reply);
//		IP_UID_destroy(UID);
//		
//		return ;
//		
//	}
//	
//	IP_API_Reply cancelreply = IP_UUTCancel(UID);
//	IP_reply_destroy(cancelreply);
//	IP_reply_destroy(reply);
//	IP_UID_destroy(UID);
//	
//	
//	//step 2: Check all CBs listed
//	
//	char* p=NULL;
//	p=(char *)cbSNGetVersion();
//	NSLog(@"%@",[NSString stringWithUTF8String:p]);
//	
//	
//	BOOL bCheckPriorCB=FALSE;
//	size_t sLength=0;
//	//First call of Control bits to check
//    int intCheckPriorCB = GetCountCBsToCheckSN([strSNToVerify UTF8String]);
//	int intCheckPriorCBXXXX = ControlBitsToCheckSN([strSNToVerify UTF8String],NULL,&sLength,NULL);
//    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 0 sLength return = %lu",sLength);
//    if(sLength<=0)
//		bCheckPriorCB=ControlBitsToCheck(NULL,&sLength,NULL);
//    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 return = %d",intCheckPriorCB);
//	NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 intCheckPriorCBXXXX return = %d",intCheckPriorCBXXXX);
//	NSLog(@"\n\nnetwork cb ControlBitsToCheckSN 1 sLength return = %lu",sLength);
//	//Second call of Control bits to check
//    if (bCheckPriorCB || sLength>0) //old||new API
//	{
//		int* iControlBitsArray=new int[sLength];
//		char** cpControlBitNames=(char**) malloc(sLength* sizeof(char*));
//		for (int i=0;i<sLength;i++)
//			cpControlBitNames[i]=new char[256];
//        int intCheckPriorCB=ControlBitsToCheckSN([strSNToVerify UTF8String],iControlBitsArray,&sLength,cpControlBitNames);
//        if(sLength<=0)
//			bCheckPriorCB=ControlBitsToCheck(iControlBitsArray,&sLength,cpControlBitNames);
//        NSLog(@"\n\nnetwork cb ControlBitsToCheckSN return = %d",intCheckPriorCB);
//		NSLog(@"\n\nnetwork cb ControlBitsToCheckSN sLength = %lu",sLength);
//		//if (bCheckPriorCB)
//        if (bCheckPriorCB ||sLength>0)  //old||new API
//		{
//			int iControlBitIndex=-1;
//			//NSString* strControlBitStatus=nil;
//			NSString* strFailMSG=@" CB Check Fail";
//			//NSArray* arraySingleStationCBStatus=nil;
//			
//			for (int j=0;j<sLength;j++)
//			{
//				NSLog(@"\n\nnetwork cb ControlBitsToCheckSN sLength2 = %lu",sLength);
//				iControlBitIndex=iControlBitsArray[j];
//                
//                //strControlBitStatus=[arrayAllControlBits objectAtIndex:(iControlBitIndex+1)];
//				//arraySingleStationCBStatus=[strControlBitStatus componentsSeparatedByString:@" "];
//				//if (![[arraySingleStationCBStatus objectAtIndex:1] isEqualToString:@"Passed"])
//                
//                NSString *needCheckCBAddress = [NSString stringWithFormat:@"0x%X",iControlBitIndex];  //find,like 0xC1
//                if([needCheckCBAddress length] < 4)
//                {
//                    needCheckCBAddress = [needCheckCBAddress stringByReplacingOccurrencesOfString:@"0x" withString:@"0x0"];
//                }
//                NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:needCheckCBAddress Postfix:@"0x"] ;
//                NSLog(@"\n network cb needCheckCBAddress=%@, strFind=%@",needCheckCBAddress,strFind);
//                if (!([strFind rangeOfString:@"Passed"].length > 0))
//                {
//					NSString* strTemp=[NSString stringWithCString:cpControlBitNames[j] encoding:NSASCIIStringEncoding];
//					strFailMSG=[strTemp stringByAppendingString:strFailMSG];
//					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFailMSG];
//					//befor return,need to release memory.
//					for (int k=0;k<sLength;k++)
//					{
//						delete [] cpControlBitNames[k];
//					}
//					delete [] cpControlBitNames;
//					delete [] iControlBitsArray;
//					//end release memory
//					return;
//				}
//			}
//			//after check all station CBs,need to release memory.
//			
//			for (int k=0;k<sLength;k++)
//			{
//				delete [] cpControlBitNames[k];
//			}
//			delete [] cpControlBitNames;
//			delete [] iControlBitsArray;
//			//end release memory
//		}
//		else 
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CBs Check Error"];
//			//befor return,need to release memory.
//			for (int k=0;k<sLength;k++)
//			{
//				delete [] cpControlBitNames[k];
//			}
//			delete [] cpControlBitNames;
//			delete [] iControlBitsArray;
//			//end release memory
//			return;
//		}
//		
//	}
//	else 
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs Check is not on or no station to check"];
//		return;
//	}
//	
//	
//	//step 3:check allowed fail count of my station.
//	
//	int iAllowedFailCount=0;
//	int iRealFailCount=0;
//	int iMyStationIndex=strtol([mMyStationCB UTF8String], NULL, 16);
//	NSString* strMyStationCBStatus=[arrayAllControlBits objectAtIndex:(iMyStationIndex+1)];
//    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN strMyStationCBStatus = %@",strMyStationCBStatus);
//	NSArray* arrayMyStationCBStatus=[strMyStationCBStatus componentsSeparatedByString:@" "];
//	iRealFailCount=[[arrayMyStationCBStatus objectAtIndex:2] intValue];
//	iAllowedFailCount=StationFailCountAllowed();
//    //iAllowedFailCount=StationFailCountAllowedSN([strSNToVerify UTF8String]);
//    NSLog(@"\n\nnetwork cb ControlBitsToCheckSN AllowFailCount = %d,iRealFailCount = %d",iAllowedFailCount,iRealFailCount);
//	if(iAllowedFailCount < 0)
//	{
//		[TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Network CBs Check is not on, or allow fail count < 0"];
//		return;
//	}
//	if (iRealFailCount>=iAllowedFailCount)
//	{
//		[TestItemParse	SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UUT Total Fail Count out of Allowed"];
//		return;
//	}
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//	
//}


//+(void)HandleFataErrorAndCBToClear:(NSDictionary*)dictKeyDefined
//{
//	NSString *mTestItemName=nil;
//	NSString *mReferenceBufferName=nil;
//	NSString *mBufferName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"BufferName"])
//		{
//			mBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	/*
//	 if (mReferenceBufferName==nil)
//	 {
//	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error!"];
//	 return;
//	 }
//	 
//	 // used to get all CB status
//	 NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//	 if (mReferenceBufferValue==nil)
//	 {
//	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
//	 return;
//	 }
//	 
//	 NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
//	 */
//	
//	//step 1:Call IP_amIOkay to Check Fatal Error.
//	NSString* strSNToVerify=nil;
//	NSString* strFailMSG=@"Fail ";
//	IP_UUTHandle UID=NULL;
//	IP_API_Reply reply = IP_UUTStart(&UID);
//	if (IP_success(reply))
//	{
//		strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
//		if (strSNToVerify==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
//			return;
//		}
//		
//		reply=IP_amIOkay(UID, [strSNToVerify UTF8String]);
//		if (!IP_success(reply))
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fatal Error"];
//			const char* DoneError = IP_reply_getError(reply);
//			NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//			strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//			NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
//			return;
//		}
//		
//	}
//	else 
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to start Fata Error Check"];
//		const char* DoneError = IP_reply_getError(reply);
//		NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//		strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//		NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//		IP_API_Reply cancelreply = IP_UUTCancel(UID);
//		IP_reply_destroy(cancelreply);
//		IP_reply_destroy(reply);
//		IP_UID_destroy(UID);
//		
//		return ;
//		
//	}
//	IP_API_Reply cancelreply = IP_UUTCancel(UID);
//	IP_reply_destroy(cancelreply);
//	IP_reply_destroy(reply);
//	IP_UID_destroy(UID);
//	
//	BOOL bCheckPriorAllItemResult=FALSE;
//	BOOL bCheckPriorCB=FALSE;
//	bCheckPriorAllItemResult=[TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
//	
//	
//	
//	//call CBs to clear on pass
//	if (bCheckPriorAllItemResult)
//	{
//		size_t iLength=0;
//		//First call of Control bits to clear on pass
//		//bCheckPriorCB=ControlBitsToClearOnPass(NULL,&iLength);
//        int intCheckPriorCB=GetCountCBsToClearOnPassSN([strSNToVerify UTF8String]);
//		int intCheckPriorCBZZZZ=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],NULL,&iLength);
//        if(iLength <= 0)
//			bCheckPriorCB=ControlBitsToClearOnPass(NULL,&iLength);
//        NSLog(@"\n\nnetwork cb GetCountCBsToClearOnPassSN return = %d",intCheckPriorCB);
//		NSLog(@"\n\nnetwork cb GetCountCBsToClearOnPassSN intCheckPriorCBZZZZ = %d",intCheckPriorCBZZZZ);
//		//Second call of Control bits to check
//        if ((bCheckPriorCB && iLength>0) || (intCheckPriorCBZZZZ>0 && iLength>0))   //old||new API
//		{
//			int* iControlBitsArray=new int[iLength];
//			//bCheckPriorCB=ControlBitsToClearOnPass(iControlBitsArray,&iLength);
//            int intCheckPriorCB=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
//            NSLog(@"\n\nnetwork cb ControlBitsToClearOnPassSN return = %d",intCheckPriorCB);
//            if(iLength <= 0)
//				bCheckPriorCB=ControlBitsToClearOnPass(iControlBitsArray,&iLength);
//			if (bCheckPriorCB || (iLength > 0)) // old||new API
//			{
//				for (int j=0;j<iLength;j++)//do something to clear CBs on Pass.
//				{
//					printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
//				}
//				
//				//release memory of iControlBitsArray
//				delete []iControlBitsArray;
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//				
//			}
//			
//			else 
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Pass"];
//				//release memory of iControlBitsArray
//				delete []iControlBitsArray;
//				return;
//			}
//			
//			
//		}
//		
//		else 
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Clear CBs On Pass is off or no station to clear"];
//		}
//		
//		
//	}
//	
//	//call CBs to clear on Fail
//	else 
//	{
//		size_t iLength=0;
//		//First call of Control bits to clear on pass
//		//bCheckPriorCB=ControlBitsToClearOnFail(NULL,&iLength);
//        int intCheckPriorCB=GetCountCBsToClearOnFailSN([strSNToVerify UTF8String]);
//		int intCheckPriorCBYYYY=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],NULL,&iLength);
//		NSLog(@"\n\nnetwork cb GetCountCBsToClearOnFailSN return = %d",intCheckPriorCB);
//		NSLog(@"\n\nnetwork cb GetCountCBsToClearOnFailSN intCheckPriorCBYYYY = %d",intCheckPriorCBYYYY);
//        if(iLength <= 0)
//			bCheckPriorCB=ControlBitsToClearOnFail(NULL,&iLength);
//		//Second call of Control bits to check
//		if ((bCheckPriorCB && iLength>0) || (intCheckPriorCBYYYY>0 && iLength>0 ))
//		{
//			int* iControlBitsArray=new int[iLength];
//			//bCheckPriorCB=ControlBitsToClearOnFail(iControlBitsArray,&iLength);
//            int intCheckPriorCB=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
//            
//            if(iLength <= 0)
//				bCheckPriorCB=ControlBitsToClearOnFail(iControlBitsArray,&iLength);
//            NSLog(@"\n\nnetwork cb ControlBitsToClearOnFailSN return = %d",intCheckPriorCB);
//            if (bCheckPriorCB || (iLength > 0))
//			{
//				NSString* strStationCBAddress=nil;
//				int iStationCBIndex=-1;
//				BOOL bSendCommandSuccessful;
//				for (int j=0;j<iLength;j++)//do someting to clear CBs on Fail
//				{
//					/*
//					 printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
//					 */
//					iStationCBIndex=iControlBitsArray[j];
//					strStationCBAddress=[NSString stringWithFormat:@"0x%02x",iStationCBIndex];
//					bSendCommandSuccessful=[self SetSelectedStationCBFail:dictKeyDefined :strStationCBAddress];
//					
//					if (!bSendCommandSuccessful)
//					{
//						strFailMSG=[strFailMSG stringByAppendingString:strStationCBAddress];
//						[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:strFailMSG];
//						//release memory 
//						delete []iControlBitsArray;
//						//end
//						return;
//					}
//					
//				}
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//				//release memory 
//				delete []iControlBitsArray;
//				//end
//			}
//			
//			else 
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Fail"];
//				//release memory 
//				delete []iControlBitsArray;
//				//end
//				return;
//			}
//		}
//		
//		else 
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs to clear on fail is off or no station to clear"];
//		}
//		
//		
//	}
//	
//	
//	//step 3:Check if need to set my station CB
//	BOOL bNeedToSetCB=FALSE;
//	bNeedToSetCB=StationSetControlBit();
//    int intNeedToSetCB=StationSetControlBitSN([strSNToVerify UTF8String]);
//	NSLog(@"\n\nnetwork cb StationSetControlBitSN return = %d",intNeedToSetCB);
//    
//	if (!bNeedToSetCB)
//		//if (intNeedToSetCB <= 0)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Don't need to set CB"];
//		return;
//	}
//	
//}

+(void)HandleFataErrorAndCBToClear:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mBufferName=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    /*
     if (mReferenceBufferName==nil)
     {
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error!"];
     return;
     }
     
     // used to get all CB status
     NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
     if (mReferenceBufferValue==nil)
     {
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
     return;
     }
     
     NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
     */
    
    //step 1:Call IP_amIOkay to Check Fatal Error.
    NSString* strSNToVerify=nil;
    NSString* strFailMSG=@"Fail ";
    IP_UUTHandle UID=NULL;
    IP_API_Reply reply = IP_UUTStart(&UID);
    if (IP_success(reply))
    {
        strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
        if (strSNToVerify==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
            return;
        }
        
        reply=IP_amIOkay(UID, [strSNToVerify UTF8String]);
        if (!IP_success(reply))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fatal Error"];
            const char* DoneError = IP_reply_getError(reply);
            NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
            strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
            NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
            IP_API_Reply cancelreply = IP_UUTCancel(UID);
            IP_reply_destroy(cancelreply);
            IP_reply_destroy(reply);
            IP_UID_destroy(UID);
            return;
        }
        
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to start Fata Error Check"];
        const char* DoneError = IP_reply_getError(reply);
        NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
        strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
        NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
        IP_API_Reply cancelreply = IP_UUTCancel(UID);
        IP_reply_destroy(cancelreply);
        IP_reply_destroy(reply);
        IP_UID_destroy(UID);
        
        return ;
        
    }
    IP_API_Reply cancelreply = IP_UUTCancel(UID);
    IP_reply_destroy(cancelreply);
    IP_reply_destroy(reply);
    IP_UID_destroy(UID);
    
    BOOL bCheckPriorAllItemResult=FALSE;
    BOOL bCheckPriorCB=FALSE;
    bCheckPriorAllItemResult=[TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
    
    
    
    //call CBs to clear on pass
    if (bCheckPriorAllItemResult)
    {
        size_t iLength=0;
        //First call of Control bits to clear on pass
        //bCheckPriorCB=ControlBitsToClearOnPass(NULL,&iLength);
        int intCheckPriorCB=GetCountCBsToClearOnPassSN([strSNToVerify UTF8String]);
        int intCheckPriorCBZZZZ=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],NULL,&iLength);
        if(iLength <= 0)
            bCheckPriorCB=ControlBitsToClearOnPass(NULL,&iLength);
        NSLog(@"\n\nnetwork cb GetCountCBsToClearOnPassSN return = %d",intCheckPriorCB);
        NSLog(@"\n\nnetwork cb GetCountCBsToClearOnPassSN intCheckPriorCBZZZZ = %d",intCheckPriorCBZZZZ);
        //Second call of Control bits to check
        if ((bCheckPriorCB && iLength>0) || (intCheckPriorCBZZZZ>0 && iLength>0))   //old||new API
        {
            int* iControlBitsArray=new int[iLength];
            //bCheckPriorCB=ControlBitsToClearOnPass(iControlBitsArray,&iLength);
            int intCheckPriorCB=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
            NSLog(@"\n\nnetwork cb ControlBitsToClearOnPassSN return = %d",intCheckPriorCB);
            if(iLength <= 0)
                bCheckPriorCB=ControlBitsToClearOnPass(iControlBitsArray,&iLength);
            if (bCheckPriorCB || (iLength > 0)) // old||new API
            {
                for (int j=0;j<iLength;j++)//do something to clear CBs on Pass.
                {
                    printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
                }
                
                //release memory of iControlBitsArray
                delete []iControlBitsArray;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
                
            }
            
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Pass"];
                //release memory of iControlBitsArray
                delete []iControlBitsArray;
                return;
            }
            
            
        }
        
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Clear CBs On Pass is off or no station to clear"];
        }
        
        
    }
    
    //call CBs to clear on Fail
    else
    {
        size_t iLength=0;
        //First call of Control bits to clear on pass
        //bCheckPriorCB=ControlBitsToClearOnFail(NULL,&iLength);
        int intCheckPriorCB=GetCountCBsToClearOnFailSN([strSNToVerify UTF8String]);
        int intCheckPriorCBYYYY=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],NULL,&iLength);
        NSLog(@"\n\nnetwork cb GetCountCBsToClearOnFailSN return = %d",intCheckPriorCB);
        NSLog(@"\n\nnetwork cb GetCountCBsToClearOnFailSN intCheckPriorCBYYYY = %d",intCheckPriorCBYYYY);
        if(iLength <= 0)
            bCheckPriorCB=ControlBitsToClearOnFail(NULL,&iLength);
        //Second call of Control bits to check
        if ((bCheckPriorCB && iLength>0) || (intCheckPriorCBYYYY>0 && iLength>0 ))
        {
            int* iControlBitsArray=new int[iLength];
            //bCheckPriorCB=ControlBitsToClearOnFail(iControlBitsArray,&iLength);
            int intCheckPriorCB=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
            
            if(iLength <= 0)
                bCheckPriorCB=ControlBitsToClearOnFail(iControlBitsArray,&iLength);
            NSLog(@"\n\nnetwork cb ControlBitsToClearOnFailSN return = %d",intCheckPriorCB);
            if (bCheckPriorCB || (iLength > 0))
            {
                NSString* strStationCBAddress=nil;
                int iStationCBIndex=-1;
                BOOL bSendCommandSuccessful;
                for (int j=0;j<iLength;j++)//do someting to clear CBs on Fail
                {
                    /*
                     printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
                     */
                    iStationCBIndex=iControlBitsArray[j];
                    strStationCBAddress=[NSString stringWithFormat:@"0x%02x",iStationCBIndex];
                    bSendCommandSuccessful=[self SetSelectedStationCBFail:dictKeyDefined :strStationCBAddress];
                    
                    if (!bSendCommandSuccessful)
                    {
                        strFailMSG=[strFailMSG stringByAppendingString:strStationCBAddress];
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:strFailMSG];
                        //release memory 
                        delete []iControlBitsArray;
                        //end
                        return;
                    }
                    
                }
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
                //release memory 
                delete []iControlBitsArray;
                //end
            }
            
            else 
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Fail"];
                //release memory 
                delete []iControlBitsArray;
                //end
                return;
            }
        }
        
        else 
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs to clear on fail is off or no station to clear"];
        }
        
        
    }
    
    
    //step 3:Check if need to set my station CB
    BOOL bNeedToSetCB=FALSE;
    bNeedToSetCB=StationSetControlBit();
    int intNeedToSetCB=StationSetControlBitSN([strSNToVerify UTF8String]);
    NSLog(@"\n\nnetwork cb StationSetControlBitSN return = %d",intNeedToSetCB);
    
    if (!bNeedToSetCB)
        //if (intNeedToSetCB <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Don't need to set CB"];
        return;
    }
    
}

//+(void)HandleFataErrorAndCBToClear:(NSDictionary*)dictKeyDefined
//{
//	NSString *mTestItemName=nil;
//	NSString *mReferenceBufferName=nil;
//	NSString *mBufferName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"BufferName"])
//		{
//			mBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	
//    //	if (mReferenceBufferName==nil)
//    //	{
//    //		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error!"];
//    //		return;
//    //	}
//    //
//    //	// used to get all CB status
//    //	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//    //	if (mReferenceBufferValue==nil)
//    //	{
//    //		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get All CB Status"];
//    //		return;
//    //	}
//	
//	//NSArray* arrayAllControlBits=[mReferenceBufferValue componentsSeparatedByString:@"0x"];
//	
//	
//	//step 1:Call IP_amIOkay to Check Fatal Error.
//	NSString* strSNToVerify=nil;
//	NSString* strFailMSG=@"Fail ";
//	IP_UUTHandle UID=NULL;
//	IP_API_Reply reply = IP_UUTStart(&UID);
//	if (IP_success(reply))
//	{
//        if(mBufferName==nil)//Changed for PS Interposer
//        {
//            strSNToVerify=[TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
//            if (strSNToVerify==nil)
//                strSNToVerify = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
//        }
//        else
//        {
//            strSNToVerify=[TestItemManage getBufferValue:dictKeyDefined :mBufferName];//Changed code for iPad-1, get MLB sn to verify----Julian20120725
//        }
//		if (strSNToVerify==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail To Get SN!"];
//			return;
//		}
//		reply=IP_amIOkay(UID, [strSNToVerify UTF8String]);
//		if (!IP_success(reply))
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fatal Error"];
//			const char* DoneError = IP_reply_getError(reply);
//			NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//			strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//			NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
//			return;
//		}
//		
//	}
//	else
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to start Fatal Error Check"];
//		const char* DoneError = IP_reply_getError(reply);
//		NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
//		strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
//		NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
//		IP_API_Reply cancelreply = IP_UUTCancel(UID);
//		IP_reply_destroy(cancelreply);
//		IP_reply_destroy(reply);
//		IP_UID_destroy(UID);
//		
//		return ;
//		
//	}
//	IP_API_Reply cancelreply = IP_UUTCancel(UID);
//	IP_reply_destroy(cancelreply);
//	IP_reply_destroy(reply);
//	IP_UID_destroy(UID);
//	
//	BOOL bCheckPriorAllItemResult=FALSE;
//	//BOOL bCheckPriorCB=FALSE;
//	bCheckPriorAllItemResult=[TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
//	
//	//call CBs to clear on pass
//	if (bCheckPriorAllItemResult)
//	{
//		size_t iLength=0;
//		//First call of Control bits to clear on pass
//		//bCheckPriorCB=ControlBitsToClearOnPass(NULL,&iLength);
//        int intCheckPriorCB=GetCountCBsToClearOnPassSN([strSNToVerify UTF8String]);
//        NSLog(@"\nGetCountCBsToClearOnPassSN %d",intCheckPriorCB);
//		int intCheckPriorCBZZZZ=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],NULL,&iLength);
//		NSLog(@"\nControlBitsToClearOnPassSN %d",intCheckPriorCBZZZZ);
//        NSLog(@"pass sn ilength is %lu\n",iLength);
//		//Second call of Control bits to check
//		//if (bCheckPriorCB&&iLength>0)
//        if ((intCheckPriorCB>0) && (iLength>0))
//		{
//			int* iControlBitsArray=new int[iLength];
//			//bCheckPriorCB=ControlBitsToClearOnPass(iControlBitsArray,&iLength);
//            int intCheckPriorCB=ControlBitsToClearOnPassSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
//            NSLog(@"\n\nnetwork cb ControlBitsToClearOnPassSN return = %d",intCheckPriorCB);
//			//if (bCheckPriorCB)
//            if(intCheckPriorCB>0)
//			{
//				for (int j=0;j<iLength;j++)//do something to clear CBs on Pass.
//				{
//					printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
//				}
//				
//				//release memory of iControlBitsArray
//				delete []iControlBitsArray;
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//				
//			}
//			
//			else
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Pass"];
//				//release memory of iControlBitsArray
//				delete []iControlBitsArray;
//				return;
//			}
//			
//			
//		}
//		
//		else
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Clear CBs On Pass is off or no station to clear"];
//		}
//        
//        
//	}
//	
//	//call CBs to clear on Fail
//	else
//	{
//		size_t iLength=0;
//		//First call of Control bits to clear on pass
//		//bCheckPriorCB=ControlBitsToClearOnFail(NULL,&iLength);
//        int intCheckPriorCB=GetCountCBsToClearOnFailSN([strSNToVerify UTF8String]);
//		int intCheckPriorCBYYYY=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],NULL,&iLength);
//		NSLog(@"\n GetCountCBsToClearOnFailSN return = %d",intCheckPriorCB);
//		NSLog(@"\n ControlBitsToClearOnFailSN intCheckPriorCBYYYY = %d",intCheckPriorCBYYYY);
//        NSLog(@"fail sn ilength is %lu\n",iLength);
//		//Second call of Control bits to check
//		//if (bCheckPriorCB&&iLength>0)
//        if ((intCheckPriorCB>0) && (iLength>0))
//		{
//			int* iControlBitsArray=new int[iLength];
//			//bCheckPriorCB=ControlBitsToClearOnFail(iControlBitsArray,&iLength);
//            int intCheckPriorCB=ControlBitsToClearOnFailSN([strSNToVerify UTF8String],iControlBitsArray,&iLength);
//            NSLog(@"\n\nnetwork cb ControlBitsToClearOnFailSN return = %d",intCheckPriorCB);
//			//if (bCheckPriorCB)
//            if (intCheckPriorCB > 0)
//			{
//				NSString* strStationCBAddress=nil;
//				int iStationCBIndex=-1;
//				BOOL bSendCommandSuccessful;
//				for (int j=0;j<iLength;j++)//do someting to clear CBs on Fail
//				{
//					/*
//                     printf("%d:%04x====\n",iControlBitsArray[j],iControlBitsArray[j]);
//					 */
//					iStationCBIndex=iControlBitsArray[j];
//					strStationCBAddress=[NSString stringWithFormat:@"0x%02x",iStationCBIndex];
//					bSendCommandSuccessful=[self SetSelectedStationCBFail:dictKeyDefined :strStationCBAddress];
//					
//					if (!bSendCommandSuccessful)
//					{
//						strFailMSG=[strFailMSG stringByAppendingString:strStationCBAddress];
//						[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:strFailMSG];
//						//release memory
//						delete []iControlBitsArray;
//						//end
//						return;
//					}
//					
//				}
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
//				//release memory
//				delete []iControlBitsArray;
//				//end
//			}
//			
//			else
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail Second Call Clear_CB_On_Fail"];
//				//release memory
//				delete []iControlBitsArray;
//				//end
//				return;
//			}
//		}
//		
//		else
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"CBs to clear on fail is off or no station to clear"];
//		}
//		
//		
//	}
//	
//	
//	//step 3:Check if need to set my station CB
//	BOOL bNeedToSetCB=FALSE;
//	bNeedToSetCB=StationSetControlBit();
//    int intNeedToSetCB=StationSetControlBitSN([strSNToVerify UTF8String]);
//	NSLog(@"\nStationSetControlBitSN is %d",intNeedToSetCB);
//    
//	if (!bNeedToSetCB)
//        //if (intNeedToSetCB <= 0)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Don't need to set CB"];
//		return;
//	}
//    
//    return;
//}
+(BOOL)SetSelectedStationCBFail:(NSDictionary*)dictKeyDefined:(NSString*)selectedStationCB
{
	NSString* strTempCommand=@"cbwrite ";
	BOOL bSendDataFlag=FALSE;
	strTempCommand=[strTempCommand stringByAppendingString:selectedStationCB];
	strTempCommand=[strTempCommand stringByAppendingString:@" "];
	strTempCommand=[strTempCommand stringByAppendingString:@"fail"];
	strTempCommand=[strTempCommand stringByAppendingString:@"\n"];
	
	bSendDataFlag=[TestItemParse SendData:dictKeyDefined :strTempCommand :@":-)"];
	return bSendDataFlag;

}

//SCRID:136
//end

@end
