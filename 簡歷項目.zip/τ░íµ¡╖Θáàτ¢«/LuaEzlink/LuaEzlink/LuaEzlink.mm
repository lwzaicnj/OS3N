//
//  LuaEzlink.m
//  LuaEzlink
//
//  Created by admin on 6/21/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#import "LuaEzlink.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "ezlink-host.h"
#import "EzlinkWrapper.h"

typedef struct {
    EzLink_t* ezlink;
} LuaEzlinkInfo;

static int TxData(void *Context, void *Buf, uint32_t NumBytes)
{
    lua_State *L = (lua_State *)Context;
    if (!L) {
        return -1;
    }
    
    lua_getglobal(L, "EzlinkSendCallback");//lua 實現的函數
    if (!lua_isfunction(L, -1)) {
        NSLog(@"onEzlinkTxData function is not define");
        return -1;
    }
    lua_pushlstring(L, (char*)Buf, NumBytes);//傳遞的參數，在函數后壓棧
    
    int nRt = lua_pcall(L, 1, LUA_MULTRET, 0);
    if (nRt!=LUA_OK || !lua_isinteger(L, -1)) {
        if (nRt == LUA_OK) {
            NSLog(@"onEzlinkTxData function return value is not int type");
        } else {
            NSLog(@"%@:%i", @"onEzlinkTxData lua_pcall fail", nRt);
            const char* msg = lua_tostring(L, -1);
            NSLog(@"error: %s", msg);
        }
        return -1;
    }
    
    int result = (int)lua_tointeger(L, -1);
    return result;
}

static int RxData(void *Context, void *Buf, uint32_t NumBytes, int32_t TimeOutInMs)
{
    lua_State *L = (lua_State *)Context;
    if (!L) {
        return -1;
    }
    
    lua_getglobal(L, "EzlinkRecvCallback");
    if (!lua_isfunction(L, -1)) {
        NSLog(@"onEzlinkRxData function is not define");
        return -1;
    }
    lua_pushinteger(L, NumBytes);
    lua_pushinteger(L, TimeOutInMs);//壓進兩個參數
    
    int nRt = lua_pcall(L, 2, LUA_MULTRET, 0);
    if (nRt!=LUA_OK || !lua_isstring(L, -1)) {
        if (nRt == LUA_OK) {
            NSLog(@"onEzlinkRxData function return value is not string type");
        } else {
            NSLog(@"%@:%i", @"onEzlinkRxData lua_pcall fail", nRt);
            const char* msg = lua_tostring(L, -1);
            NSLog(@"error: %s", msg);
        }
        return -1;
    }
    int rt = (int)lua_tointeger(L, -2);
    size_t len = 0;
    const char* data = lua_tolstring(L, -1, &len);
    memcpy(Buf, data, len);
    return rt;//(int)len;
}

/********************************************************************************/
static int Lua_EzlinkVersion(lua_State *L)
{
    const char*szVersion = PROTOCOL_VERSION;
    lua_pushstring(L, szVersion);
    return 1;
}

static int Lua_EzlinkGC(lua_State *L)
{
    if (lua_isuserdata(L, 1)) {
        LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_touserdata(L, 1);
        if (p->ezlink != NULL) {
            //EzLink_Teardown(p->ezlink);
            free(p->ezlink);
            p->ezlink = NULL;
        }
    }
    return 0;
}

/********************************************************************************/
static int Lua_EzLink_Setup(lua_State *L)
{
    int rt = -1;
    EzLink_t* ezlink = (EzLink_t*)calloc(1, sizeof(EzLink_t));
    if (ezlink == NULL) {
        return 0;
    }
    
    LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_newuserdata(L, sizeof(LuaEzlinkInfo));
    p->ezlink = ezlink;
    
    /*lua_newtable(L); //add __gc metamethod
     lua_pushcfunction(L, Lua_EzlinkGC);
     lua_setfield(L, -2, "__gc");
     lua_setmetatable(L, -2);*/
    
    luaL_getmetatable(L, "ezlink");
    lua_setmetatable(L, -2);
    
    EzLinkTransport_t TransportMethods;
    TransportMethods.RxData = RxData;
    TransportMethods.TxData = TxData;
    
    /*lua_rawgeti(L,  LUA_REGISTRYINDEX, LUA_RIDX_MAINTHREAD);
     lua_State *mL = lua_tothread(L,-1);
     lua_pop(L,1);*/
    
    rt = EzLink_Setup(p->ezlink, &TransportMethods, L);
    if (rt < 0) {
        free(p->ezlink);
        p->ezlink = NULL;
        /*lua_pop(L, 1);
         lua_pushnil(L);*/
        NSLog(@"rt < 0:%i", rt);
        return 0;
    }
    lua_pushinteger(L, rt);
    return 2;
}

static int Lua_EzLink_SendError(lua_State *L)
{
    int rt = -1;
    if (lua_isuserdata(L, 1) && lua_isinteger(L, 2) && lua_isstring(L, 3)) {
        /*LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_touserdata(L, 1);
         int32_t ErrorCode = (int32_t)lua_tointeger(L, 2);
         char* ErrorString = (char*)lua_tostring(L, 3);*/
        //rt = EzLink_SendError(p->ezlink, ErrorCode, ErrorString); //not imp
    }
    lua_pushinteger(L, rt);
    return 1;
}

static int Lua_EzLink_SendData(lua_State *L)
{
    int rt = -1;
    ErrorInfo_t* ErrorInfo = NULL;
    if (lua_isuserdata(L, 1) && lua_isstring(L, 2) && lua_isinteger(L, 3)) {
        LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_touserdata(L, 1);
        size_t NumSendBytes = 0;
        char* SendBuf = (char*)lua_tolstring(L, 2, &NumSendBytes);
        int32_t TimeoutInMs = (int32_t)lua_tointeger(L, 3);
        rt = EzLink_SendData(p->ezlink, SendBuf, (uint32_t)NumSendBytes, TimeoutInMs, &ErrorInfo);
    }
    lua_pushinteger(L, rt);
    if (ErrorInfo) {
        lua_pushinteger(L, ErrorInfo->ErrorCode);
        lua_pushstring(L, ErrorInfo->ErrorString);
        return 3;
    }
    return 1;
}

static int Lua_EzLink_RecvData(lua_State *L)
{
    int rt = -1;
    ErrorInfo_t* ErrorInfo = NULL;
    if (lua_isuserdata(L, 1) && lua_isinteger(L, 2))
    {
        LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_touserdata(L, 1);
        int32_t TimeoutInMs = (int32_t)lua_tointeger(L, 2);
        uint8_t *RecvBuf = NULL;
        uint32_t NumRecvBytes = 0;
        rt = EzLink_RecvData(p->ezlink, (void**)&RecvBuf, &NumRecvBytes, TimeoutInMs, &ErrorInfo);
        lua_pushinteger(L, rt);
        lua_pushlstring(L, (char*)RecvBuf, NumRecvBytes);
    } else {
        lua_pushinteger(L, rt);
        lua_pushnil(L);
    }
    if (ErrorInfo) {
        lua_pushinteger(L, ErrorInfo->ErrorCode);
        lua_pushstring(L, ErrorInfo->ErrorString);
        return 4;
    }
    return 2;
}

static int Lua_EzLink_Teardown(lua_State *L)
{
    int rt = -1;
    if (lua_isuserdata(L, 1)) {
        LuaEzlinkInfo *p = (LuaEzlinkInfo *)lua_touserdata(L, 1);
        rt = EzLink_Teardown(p->ezlink);
    }
    
    lua_pushinteger(L, rt);
    return 1;
}

/********************************************************************************/
static int Lua_EzLinkWork(lua_State *L)
{
    bool bRt = false;
    if (lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3)) {
        const char* szDevicePath = (char*)lua_tostring(L, 1);
        NSString* devicePath = [NSString stringWithFormat:@"%s",szDevicePath?szDevicePath:"NULL"];
        const char* szJmetPath = (char*)lua_tostring(L, 2);
        NSString* jmetPath = [NSString stringWithFormat:@"%s",szJmetPath?szJmetPath:"NULL"];
        const char* szServerIP = (char*)lua_tostring(L, 3);
        NSString* serverIP = [NSString stringWithFormat:@"%s",szServerIP?szServerIP:"NULL"];
        NSMutableString *strResult = [NSMutableString string];
        bRt = EzlinkWork(devicePath, jmetPath, serverIP, strResult);
        lua_pushboolean(L, bRt);
        NSData* data = [strResult dataUsingEncoding:NSUTF8StringEncoding];
        if (data) {
            const char *szData = (const char *)[data bytes];
            lua_pushlstring(L, szData, [data length]);
        } else {
            lua_pushstring(L, "Fail");
        }
    }
    else {
        lua_pushboolean(L, bRt);
        lua_pushstring(L, "Fail");
    }
    
    return 2;
}

/********************************************************************************/
static int Lua_Test(lua_State *L)
{
//    const char* cmd = "It is ok";
//    int rt = TxData(L, (char*)cmd, (uint32_t)strlen(cmd));
//    NSLog(@"TxData return:%i", rt);
//    
//    char Buf[1024] = {0};
//    rt = RxData(L,Buf,10, 3);
//    
//    NSLog(@"RxData return:%i data:%s", rt, Buf);
    
//    NSString* deviceName = @"test";
//    NSMutableString *errorStr = [NSMutableString string];
//    bool bRt = EZLinkParseFunction(deviceName, errorStr);
//    NSLog(@"bRt:%i, errorStr:%@", (int)bRt, errorStr);
    
    return 0;
}

/********************************************************************************/
static const luaL_Reg ezlink_m[] = {
    {"SendData",    Lua_EzLink_SendData},
    {"RecvData",    Lua_EzLink_RecvData},
    {"Teardown",    Lua_EzLink_Teardown},
    
    {"__gc",            Lua_EzlinkGC},
    {NULL, NULL}
};

static const luaL_Reg ezlink_f[] = {
    {"Version",     Lua_EzlinkVersion},
    {"Setup",       Lua_EzLink_Setup},
    {"SendError",   Lua_EzLink_SendError}, // not imp
    {"SendData",    Lua_EzLink_SendData},
    {"RecvData",    Lua_EzLink_RecvData},
    {"Teardown",    Lua_EzLink_Teardown},
    {"work",        Lua_EzLinkWork},
    {"test",        Lua_Test},
    {NULL, NULL}
};

static void createMetatable (lua_State *L, const char* className, const luaL_Reg *reg)
{
    luaL_newmetatable(L, className);//把新创建的元表放在栈顶,並且adds it to the registry with key tname
    lua_pushvalue(L, -1);//把堆栈上给定有效处索引处的元素作一个拷贝压栈,做副本
    
    //設置棧頂的值到 table 中,并把棧頂的值出棧。
    // lua_setfield (lua_State *L, int index, const char *k);做一个等价于 t[k] = v 的操作， 这里 t 是给出的有效索引 index 处的值， 而 v 是栈顶的那个值。这个函数将把这个棧頂的值設置到table 的 k中 這裡就是把 -2的 table(原className a) 的 a[__index]=className的拷貝 ，并把這個拷貝表出棧
    
    lua_setfield(L, -2, "__index");//把key為__index的棧頂值設置到表中，然後棧頂值出棧
    
    luaL_setfuncs(L, reg, 0);//注册函数到栈顶的表中； luaL_register函数已经不再使用，取而代之的是luaL_setfuncs，因为该函数不会创建全局变量
    lua_pop(L, 1);
}


//LUAMOD_API就是extern 供其他文件直接引用.
LUAMOD_API int luaopen_ezlink(lua_State *L)
{
    createMetatable(L, "ezlink", ezlink_m);
    luaL_newlib(L, ezlink_f);//luaL_newlib：这个函数一个宏：创建一个table来保存我们映射数据（key-value值）
    return 1;
}
/********************************************************************************/



