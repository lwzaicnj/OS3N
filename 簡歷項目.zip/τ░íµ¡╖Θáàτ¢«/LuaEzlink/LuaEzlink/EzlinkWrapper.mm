//
//  EzlinkWrapper.m
//  LuaEzlink
//
//  Created by admin on 9/17/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#import "EzlinkWrapper.h"
#import <Foundation/Foundation.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <fstream>
#include <iostream>
#include "ezlink-host.h"

/**************************************************************************/
using namespace std;

typedef struct {
    int Fd;
} SerialContext_t;

/**************************************************************************/
static int Serial_Open (const char *Port, int *Fd, int BaudRate )
{
    struct termios OldTio;
    struct termios NewTio;
    int SerialFd;
    int Ret;
    
    SerialFd = open(Port, O_RDWR | O_NOCTTY);
    if (SerialFd < 0) {
        printf("Could not open serial port: %d\n", errno);
        return -1;
    }
    
    *Fd = SerialFd;
    
    // Get old attributes
    tcgetattr(SerialFd, &OldTio);
    bzero(&NewTio, sizeof(NewTio));
    
    // Setup the serial port attributes
    NewTio.c_cflag = CS8 | CREAD;
    NewTio.c_oflag = 0;
    NewTio.c_iflag = IGNPAR;
    NewTio.c_lflag = 0;
    NewTio.c_cc[VMIN] = 0;
    NewTio.c_cc[VTIME] = 0;
    
    // Mac OS/X requires a special ioctl to set higher baud rates
    if (BaudRate <= 115200) {
        if (cfsetospeed(&NewTio, BaudRate) < 0) {
            printf("Couldn't set speed!\n");
            return -1;
        }
        
        cfmakeraw(&NewTio);
        tcsetattr(SerialFd, TCSANOW, &NewTio);
        Ret = tcflush(SerialFd, TCIOFLUSH);
        if (Ret < 0) {
            printf("Couldn't flush serial port!\n");
            return Ret;
        }
    }
    else {
        tcsetattr(SerialFd, TCSANOW, &NewTio);
        
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 2, speed_t)
#endif
        Ret = ioctl(SerialFd, IOSSIOSPEED, &BaudRate);
        if (Ret < 0) {
            printf("Canot set speed!\n");
            return -1;
        }
    }
    
    // This delay is needed to stabilize the serial port
    usleep(50 * 1000);
    
    return 0;
}

static ssize_t _Serial_Read (int filedes, void *buf, size_t nbytes, unsigned int timeout_ms)
{
    struct timeval tv;
    fd_set fds;
    int ret;
    
    tv.tv_sec = timeout_ms  / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    
    FD_ZERO(&fds);
    FD_SET(filedes, &fds);
    
    // Use select to wait till a read descriptor is set
    ret = select(filedes + 1, &fds, NULL, NULL, &tv);
    
    // We got data - read as much as we can and return to the user
    if (ret > 0) {
        ret = (int)read(filedes, buf, nbytes);
        return ret;
    }
    else {
        return -ETIMEDOUT;
    }
}

static int Serial_ReadBytes (void *Context, void *Buf, uint32_t NumBytes, int32_t TimeOutInMs)
{
    int Ret;
    unsigned char *Ptr = (unsigned char *)Buf;
    unsigned int TotalBytes = 0;
    SerialContext_t *SerialContext = (SerialContext_t *)Context;
    
    while (NumBytes) {
        Ret = (int)_Serial_Read(SerialContext->Fd, Ptr, NumBytes, TimeOutInMs);
        if (Ret < 0) {
            return Ret;
        }
        
        Ptr += Ret;
        NumBytes -= Ret;
        TotalBytes += Ret;
    }
    
    return 0;
}

//static void PrintBytes (void *Buf, uint32_t NumBytes)
//{
//    int i;
//    for (i = 0; i < NumBytes; i++) {
//        printf("0x%02x ", ((uint8_t*)Buf)[i]);
//        if ((i != 0) && (i % 8 == 0)) {
//            printf("\n");
//        }
//    }
//}

static int Serial_WriteBytes (void *Context, void *Buf, uint32_t NumBytes)
{
    if (!Context) return -1;
    
    SerialContext_t *SerialContext = (SerialContext_t *)Context;
    //PrintBytes(Buf, NumBytes);
    return (int)write(SerialContext->Fd, Buf, NumBytes);
}

/**************************************************************************/
static NSArray* gmatch(NSString*string, NSString *pattern)
{
    NSMutableArray* machArray = [NSMutableArray array];
    NSRegularExpressionOptions options = NSRegularExpressionCaseInsensitive|NSRegularExpressionDotMatchesLineSeparators;
    NSRegularExpression* regex = [NSRegularExpression regularExpressionWithPattern:pattern options:options error:nil];
    NSArray *matches = [regex matchesInString:string options:0 range:NSMakeRange(0, [string length])];
    for (NSTextCheckingResult *match in matches) {
        NSString *matchHalfString = [string substringWithRange:[match rangeAtIndex:1]];
        //NSLog(@"matchHalfString:%@", matchHalfString);
        [machArray addObject:matchHalfString];
    }
    return machArray;
}

static void updateJmetFile(NSString* jmetPath, NSString* serverIP)
{
    //NSString* jmetFilePath = [NSHomeDirectory() stringByAppendingString:@"/JMET.py"];
    //NSLog(@"jmet Path:%@", jmetPath);
    NSString *oldJmet = [NSString stringWithContentsOfFile:jmetPath encoding:NSASCIIStringEncoding error:nil] ;
    if (oldJmet == nil) {
        NSLog(@"JMET File is not exist!");
        return ;
    }
    //NSLog(@"old jmet content:%@", oldJmet);
    NSArray* ipArray = gmatch(oldJmet, @"http://(.*?):");
    if (ipArray.count ==0) return;
    NSString* oldIp = [ipArray objectAtIndex:0];
    //NSLog(@"oldIp:%@", oldIp);
    
    NSString* newJmet = [oldJmet stringByReplacingOccurrencesOfString:oldIp withString:serverIP];
    [newJmet writeToFile:jmetPath atomically:YES encoding:NSASCIIStringEncoding error:NULL];
    NSLog(@"new Jmet content:%@", newJmet);
}

/**************************************************************************/
bool EzlinkWork(NSString* devicePath, NSString* jmetPath, NSString* serverIP, NSMutableString *strResult)
{
    static bool haveUpdate = false;
    if (!haveUpdate) {
        updateJmetFile(jmetPath, serverIP);
        haveUpdate = true;
    }
    
    /*******************************************************/
    usleep(80000);
    EzLinkTransport_t Methods;
    SerialContext_t SerialContext;
    SerialContext.Fd = -1;
    EzLink_t EzLinkInfo;
    ErrorInfo_t *ErrorInfo = NULL;
    int Status;
    int i;
    uint8_t *RxBuf;
    uint32_t RxBufSize;
    
    char ReadBuf[2050];
    Methods.TxData = Serial_WriteBytes;
    Methods.RxData = Serial_ReadBytes;
    
    /*******************************************************/
    // 0. Open diag device
    Status = Serial_Open(devicePath.UTF8String, &SerialContext.Fd, 115200);
    usleep(5000);
    
    if (Status < 0) {
        printf("1.Serial_Open():Status(%i) < 0\n",Status);
        [strResult appendFormat:@" 1.Serial_Open():Status %s < 0\n", devicePath.UTF8String];
        if (SerialContext.Fd != -1) {
            close(SerialContext.Fd);
        }
        usleep(5000);
        return false;
    }
    else {
        printf("1.Serial_Open():Successs!\n");
        [strResult appendFormat:@" 1.Serial_Open():Successs!\n"];
    }
    
    const char *arg = "tristar --provision";
    string aa= arg;
    string cmd = "\n" + aa + "\r\n";
    write(SerialContext.Fd, cmd.c_str(), cmd.length());
    usleep(200000);
    read(SerialContext.Fd, ReadBuf, 2050);
    printf("%s", ReadBuf);
    [strResult appendFormat:@"%s\r\n",ReadBuf];
    
    /*******************************************************/
    // 1. Setup the Ezlink with diags
    Status = EzLink_Setup(&EzLinkInfo, &Methods, &SerialContext);
    if (Status < 0) {
        printf("2.EzLink_Setup():Status < 0\r\n");
        [strResult appendFormat:@" 2.EzLink_Setup():Status < 0\n\r"];
        close(SerialContext.Fd);
        usleep(5000);
        return false;
    }
    else {
        printf("2.EzLink_Setup():Successs!\n");
        [strResult appendFormat:@" 2.EzLink_Setup():Successs!\n\r"];
    }
    
    /*******************************************************/
    // Phase 1 - Receive the provisioning request from diags
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf, &RxBufSize, 2000, &ErrorInfo);
    if (Status < 0) {
        printf("3.EzLink_RecvData():Status < 0\n");
        [strResult appendFormat:@" 3.EzLink_RecvData():Status < 0\n\r"];
        close(SerialContext.Fd);
        usleep(5000);
        return false;
    }
    else {
        printf("3.EzLink_RecvData():Successs!\n");
        printf("RxBuf = Received %u bytes = %s\n", RxBufSize, RxBuf);
        [strResult appendFormat:@" 3.EzLink_RecvData():Successs!\n\r"];
        [strResult appendFormat:@"RxBuf = Received %u bytes = %s\n\r", RxBufSize, RxBuf];
    }
    
    /*******************************************************/
    char tx_buf[5000] = {0}; tx_buf[0]='\0';
    NSString *pathStr = [NSString stringWithFormat:@"python %@ '", jmetPath];
    strcat(tx_buf, [pathStr UTF8String]);
    strncat(tx_buf, (char *)RxBuf, RxBufSize);
    strcat(tx_buf, "'\0");
    
    printf("$$$$$$$$$$$$$$$$$$$$\n %s\n\n", tx_buf);
    [strResult appendFormat:@"$$$$$$$$$$$$$$$$$$$$\n %s\n\n\r", tx_buf];
    
    FILE *fp = popen(tx_buf, "r");
    if(fp == NULL) {
        printf("Fail to CALL python");
        [strResult appendFormat:@" Fail to CALL python"];
        close(SerialContext.Fd);
        return false;
    }
    
    char buf[2048] = {0};
    fgets(buf, sizeof(buf), fp);
    printf("buf = B02 %s ####\n", buf);
    [strResult appendFormat:@" buf = B02 %s ####\n\r", buf];
    pclose(fp);
    
    /*******************************************************/
    // Phase 2 - Send the provisioning info from JMET to diags /
    Status = EzLink_SendData(&EzLinkInfo, buf, sizeof(buf), 1000, &ErrorInfo);
    if(Status != 0){ // we should chck the status_code be 0 ?
        printf("4.EzLink_SendData():Status(%i) < 0\n", Status);
        [strResult appendFormat:@" 4.EzLink_SendData():Status(%i) < 0 \n", Status];
        close(SerialContext.Fd);
        usleep(5000);
        return false;
    }
    else {
        printf("4.EzLink_SendData():Successs!\n");
        [strResult appendFormat:@" 4.EzLink_SendData():Successs!\n"];
    }
    
    /*******************************************************/
    // Zero out the tx_buf, so I can see what Diags is handing up.
    for (i = 0; i < RxBufSize; i++) {
        RxBuf[i] = 0;
    }
    
    // Phase 3 - Get the provioning response back from diags
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf, &RxBufSize, 2000, &ErrorInfo);
    if (Status < 0) {
        if (ErrorInfo != NULL) {
            NSString *errorInfo =[NSString stringWithFormat:@"%s",ErrorInfo ->ErrorString];
            NSLog(@"ErrorString: %@",errorInfo);
        }
        printf("5.EzLink_RecvData():Status < 0\n");
        [strResult appendFormat:@" 5.EzLink_RecvData():Status < 0\n\r"];
        close(SerialContext.Fd);
        usleep(5000);
        return false;
    }
    else {
        printf("5.EzLink_RecvData():Successs!\n");
        printf("RxBuf = Received %u bytes = %s\n", RxBufSize, RxBuf);
        [strResult appendFormat:@" 5.EzLink_RecvData():Successs!\n\r"];
        [strResult appendFormat:@"RxBuf = Received %u bytes = %s\n\r", RxBufSize, RxBuf];
    }
    
    /*******************************************************/
    tx_buf[0] = '\0';
    strcat(tx_buf, [pathStr UTF8String]);
    strncat(tx_buf, (char *)RxBuf, RxBufSize);
    strcat(tx_buf, "'\0");
    
    printf("$$$$$$$$$$$$$$$$$$$$\n %s\n\n", tx_buf);
    [strResult appendFormat:@"$$$$$$$$$$$$$$$$$$$$\n %s\n\n", tx_buf];
    
    FILE *fp1=popen(tx_buf, "r");
    if(fp1 == NULL) {
        printf("Fail to CALL python");
        [strResult appendFormat:@"      Fail to CALL python"];
        close(SerialContext.Fd);
        return  false;
    }
    
    char buf1[2048] = {0};
    fgets(buf1, sizeof(buf1), fp1);
    printf("buf1 = B02 %s ####\n", buf);
    [strResult appendFormat:@" buf1 = B02 %s ####\n\r", buf];
    pclose(fp1);
    
    /*******************************************************/
    close(SerialContext.Fd);
    usleep(5000);
    EzLink_Teardown(&EzLinkInfo);
    
    printf("Ezlink Test success!\n");
    [strResult appendFormat:@" Ezlink Test success!\n"];
    
    return true;
}
/**************************************************************************/



