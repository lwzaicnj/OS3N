//
//  EzlinkWrapper.h
//  LuaEzlink
//
//  Created by admin on 9/17/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#ifndef EzlinkWrapper_h
#define EzlinkWrapper_h

#import <Foundation/Foundation.h>

bool EzlinkWork(NSString* devicePath, NSString* jmetPath, NSString* serverIP, NSMutableString *strResult);

#endif /* EzlinkWrapper_h */








