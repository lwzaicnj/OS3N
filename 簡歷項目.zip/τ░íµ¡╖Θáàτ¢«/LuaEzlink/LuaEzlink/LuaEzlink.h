//
//  LuaEzlink.h
//  LuaEzlink
//
//  Created by admin on 6/21/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#ifndef __LuaEzlink__H
#define __LuaEzlink__H

#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif
    
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

#define LUA_EZLINK_LIBNAME	"ezlink"  ///* 告诉Lua，这是一个LIB文件 */  
LUAMOD_API int luaopen_ezlink(lua_State *L);
    
#ifdef __cplusplus
}
#endif

#endif /* defined(__LuaEzlink__H) */
