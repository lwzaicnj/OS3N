//
//  LuaAutomation.m
//  LuaAutomation
//
//  Created by admin on 10/14/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#import "LuaAutomation.h"

/********************************************************************************/
@implementation LuaAutomation

//自動開始傳輸？ 手動點擊那個 start 測試 會調用
- (BOOL)station:(AppleControlledStation *)station startWithTravelers:(NSArray *)travelers
{
    __block BOOL bRt = YES;
    dispatch_queue_t dispatchQueue = dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0);
    dispatch_async(dispatchQueue, ^{
        lua_State *L = (lua_State*)[station.userInfo pointerValue];
        if (L == NULL) {
            bRt = NO;
            return;
        }
        
//        lua_getglobal(L , "onLiwangzhi");
        
        lua_getglobal(L, "onAutomationStart");//調用 lua 函數
        lua_getglobal(L , "onLiwangzhi");
        if (!lua_isfunction(L, -1)) {
            NSLog(@"onAutomationStart function is not define");
            bRt = NO;
            return;
        }
        
        int nRt = lua_pcall(L, 0, LUA_MULTRET, 0);//以保护模式调用一个函数(剛壓棧的函數)。
        if (nRt != LUA_OK) {
            NSLog(@"%@:%i", @"onAutomationStart lua_pcall fail", nRt);//可以這樣使用 nslog
            const char* msg = lua_tostring(L, -1);//如果 lua_pcall 調用出錯，返回0,會把錯誤值壓棧，這裡取出
            NSLog(@"error: %s", msg);
            bRt = NO;
        }
    });
    
    NSLog(@"Automation start status : %i", bRt);
    
    return bRt;
}

- (BOOL)station:(AppleControlledStation *)station abortWithOptions:(NSDictionary *)options
{
    return YES;
}

- (BOOL)station:(AppleControlledStation *)station query:(NSDictionary *)query
{
    return YES;
}

@end

/********************************************************************************/
static AppleControlledStation* g_station = nil;

static AppleControlledStation* createStation(NSString* stationName, NSString* stationClass, NSNumber* numberOfSlots)
{
    static dispatch_once_t predicate;
    //只創建一次
    dispatch_once(&predicate, ^{
        g_station = [AppleControlledStation controlledStationWithName:stationName andClass:stationClass andNumberOfSlots:numberOfSlots];
        g_station.delegate = [[LuaAutomation alloc] init];
    });
    return g_station;
}

/********************************************************************************/
static int Lua_AutomationSetup(lua_State *L)
{
    int bRt = 0;
    if (lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isinteger(L, 3))
    {
        const char* szStationName = lua_tostring(L, 1);
        const char* szStationClass = lua_tostring(L, 2);
        int nNumberOfSlots = (int)lua_tointeger(L, 3);
        if (szStationName != NULL && szStationClass != NULL && nNumberOfSlots!=0)
        {
            NSString* stationName = [NSString stringWithUTF8String:szStationName];
            NSString* stationClass = [NSString stringWithUTF8String:szStationClass];
            NSNumber* numberOfSlots = [NSNumber numberWithInt:nNumberOfSlots];
            AppleControlledStation* station = createStation(stationName, stationClass, numberOfSlots);
            if (station) {
                NSLog(@"Name:%@, class:%@, slots:%@",stationName,stationClass,numberOfSlots);
                station.userInfo = [NSValue valueWithPointer:L];
                [AppleTestStationAutomation registerStation:station];
                bRt = 1;
            }
        }
    }
    lua_pushboolean(L, bRt);
    NSLog(@"AutomationSetup:%i", bRt);
    
    return 1;
}

static int Lua_AutomationTeardown(lua_State *L)
{
    if (g_station) {
        [AppleTestStationAutomation unregisterStation:g_station userInfo:nil];
        NSLog(@"AutomationTeardown");
    }
    
    return 0;
}

/********************************************************************************/
static int Lua_AutomationUpdateResult(lua_State *L)
{
    int bRt = 0;
    if (lua_isboolean(L, 1)) {
        bRt = lua_toboolean(L, 1);
    }
    
    if (g_station == nil) {
        return 0;
    }
    
    NSDictionary* result = nil;
    if (bRt) {
        result = [NSDictionary dictionaryWithObject:eTraveler_TestPassedResult forKey:eTraveler_TestResultKey];
    }
    else {
        result = [NSDictionary dictionaryWithObject:eTraveler_TestFailedResult forKey:eTraveler_TestResultKey];
    }
    [AppleTestStationAutomation testStation:g_station finishedWithResults:[NSArray arrayWithObject:result]];
    
    NSLog(@"AutomationUpdateResult");
    return 0;
}

static int Lua_AutomationEnabled(lua_State *L)
{
    int bRt = [AppleTestStationAutomation automationEnabled]; //不要直接返回 bool
    lua_pushboolean(L, bRt);
    
    return 1;
}


/********************************************************************************/
static const luaL_Reg automation_m[] = {
    {NULL, NULL}
};

static const luaL_Reg automation_f[] = {
    {"setup",        Lua_AutomationSetup},
    {"teardown",     Lua_AutomationTeardown},
    {"updateResult", Lua_AutomationUpdateResult},
    {"enable",       Lua_AutomationEnabled},
    
    {NULL, NULL}
};

static void createMetatable (lua_State *L, const char* className, const luaL_Reg *reg)
{
    luaL_newmetatable(L, className);
    lua_pushvalue(L, -1);
    lua_setfield(L, -2, "__index");
    luaL_setfuncs(L, reg, 0);
    lua_pop(L, 1);
}

LUAMOD_API int luaopen_automation(lua_State *L)
{
    createMetatable(L, LUA_AUTOMATION_LIBNAME, automation_m);
    luaL_newlib(L, automation_f);
    return 1;
}
/********************************************************************************/




