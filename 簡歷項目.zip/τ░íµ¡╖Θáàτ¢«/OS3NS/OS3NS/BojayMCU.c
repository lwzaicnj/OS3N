//
//  BojayMCU.c
//  OS3NS
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#include "BojayMCU.h"
#include "SerialPort.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

int MCUOpen(char *devicePath){

    return openPort(devicePath, B115200, DATABITS_8, StopBits_1, PARITY_NONE, FLOW_CONTROL_NONE);//return 0 means successed
}
int MCUisOpen(){
    return isOpen();//判斷是否連通,0即連通
}

void MCUClose(){
    
    closePort();
}
int MCUWrite(char *buffer){
    
    if (MCUisOpen()) return -1;//未連接
    
    char standardBuffer[BUFFER_SIZE] = {0};//創建一個標準大小的內存
    strcat(standardBuffer, buffer);//把需要寫進 MCU 的內容放進去
    strcat(standardBuffer, LINE_END); //加上 \r\n
    
    return writeData(standardBuffer);//返回實際寫入的字節數或者 -1
    
}

//寫進去然後限時讀取返回值
int MCUWriteForuSeconds(char *buffer,int uSeconds){
    
    if (MCUisOpen()) return -1;
    
    char readBuf[BUFFER_SIZE] = {0};
    MCURead(readBuf, BUFFER_SIZE); //清空 MCU 緩存
    
    int ret = MCUWrite(buffer);//寫，下面讀
    if (ret < 0) return -2;
    
    struct timeval start, end;
    
    gettimeofday(&start, NULL);
    while (1) {
        usleep(DELAY_TIME);
        char dataBuf[BUFFER_SIZE] = {0};
        
        int dret = MCURead(dataBuf, BUFFER_SIZE);
        if (dret < 0) return -1;
        
        char realBuffer[BUFFER_SIZE]={0};
        sprintf(realBuffer, "%s%s%s%s",buffer,LINE_END,OK,LINE_END);//把格式化的数据写入realBuffer
        
        //判斷從 MCU 讀取的字符
        if (strstr(dataBuf, INVALID_COMMAND""LINE_END)) return -3;
        if (strstr(dataBuf, OK""LINE_END)) return 0;
        if (strstr(dataBuf,FAIL""LINE_END)) return -1;
        
        gettimeofday(&end, NULL);
        
        long use_time = (end.tv_sec - start.tv_sec)*1000000 + (end.tv_usec - start.tv_usec);
        if (use_time>uSeconds) return -4;//超時
        
    }
    
    return 0;
}
int MCURead(char *buffer,int size){
    
    return readData(buffer, size);
}

int MCUReadStart(){
    
    if (MCUisOpen()) return -1;
    
    char readbuffer[BUFFER_SIZE] ={0};//清空 MCU 緩存
    MCURead(readbuffer, BUFFER_SIZE);
    
    while (1) {
        int ret = MCUWrite(TEST_START);
        if (ret < 0) return -1;
        usleep(DELAY_TIME);
        
        char dataBuff[BUFFER_SIZE]={0};
        int dret = MCURead(dataBuff, sizeof(dataBuff));//獲取TEST_START命令返回值
        
        if (dret < 0) return -1;
        
        if (strstr(dataBuff, OK""LINE_END)) return 0;//判断字符串str2是否是str1的子串。如果是，则该函数返回str2在str1中首次出现的地址；否则，返回NULL。
        if (MCUisOpen()) return -1;

    }
}






























