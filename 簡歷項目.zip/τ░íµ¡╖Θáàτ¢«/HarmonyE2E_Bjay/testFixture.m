function [] = testFixture()
    
    fixtureCtlPath = '/Users/dhruvguliani/Projects/Apple/HarmonyE2E/deploy/fixturectl';    
    
    
    for i = 1:5
        tic
        disp(cat(2,'Run iteration ', num2str(i))); 
        disp('Testing DUT Initialize')
        hostcommand(cat(2, fixtureCtlPath, ' initialize'));

        disp('Testing DUT positions:')
        for i = 1:3
            disp(cat(2, '    Moving to position ', i));
            moveToPosition(i, fixtureCtlPath); 
            pause(2)
    %         disp('    Check dut');
        end


        disp('Testing Light Array 1:')
        for i = 1:3
            disp(cat(2, '    Moving to bulb ', i));
            selectLightSource(i, fixtureCtlPath); 
            pause(2)
    %         disp('    Check light');
        end

        disp('Testing Light Array 2:')
        for i = 1:3
            disp(cat(2, '    Moving to bulb ', i));
            selectLightSource(i+3, fixtureCtlPath); 
            pause(2)
    %         disp('    Check light');
        end

        disp('Testing shutter for Light array 1:')
        pause(1)
        disp('Opening Shutter'); 
        hostcommand(cat(2, fixtureCtlPath, ' shutter1open'));
        disp('Closing Shutter');
        hostcommand(cat(2, fixtureCtlPath, ' shutter1close'));
        pause(1)

        disp('Testing shutter for Light array 2:')
        disp('    Opening Shutter'); 
        hostcommand(cat(2, fixtureCtlPath, ' shutter2open'));
        pause(1)
        disp('    Closing Shutter');
        hostcommand(cat(2, fixtureCtlPath, ' shutter2close'));
        pause(1)

        disp('Testing pogoping:')
        disp('    Connecting Pogopin');
        hostcommand(cat(2, fixtureCtlPath, ' pogopin1'));
        pause(1)
        disp('    Disconnecting Pogopin'); 
        hostcommand(cat(2, fixtureCtlPath, ' pogopin0'));
        pause(1)
        
        disp(cat(2, 'Run took: ', num2str(toc)));
    end 
end 