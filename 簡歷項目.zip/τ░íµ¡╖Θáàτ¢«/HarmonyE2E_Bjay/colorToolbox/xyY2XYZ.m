function [ out ] = xyY2XYZ( in )
%XYY2XYZ Summary of this function goes here
%   Detailed explanation goes here

X = (in(1,:)./in(2,:)).*in(3,:);
Y = in(3,:);
Z = ((ones(1,size(in,2))-in(1,:)-in(2,:))./in(2,:)).*in(3,:);

out = [X;Y;Z];

end

