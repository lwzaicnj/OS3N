function [ uv ] = XYZ2uvY( XYZ )
%function [ uv ] = XYZ2uv( XYZ )

uv = zeros(3,size(XYZ,2));

uv(1,:) = 4*XYZ(1,:)./(XYZ(1,:)+15*XYZ(2,:)+3*XYZ(3,:));
uv(2,:) = 9*XYZ(2,:)./(XYZ(1,:)+15*XYZ(2,:)+3*XYZ(3,:));
uv(3,:) = XYZ(2,:);

end

