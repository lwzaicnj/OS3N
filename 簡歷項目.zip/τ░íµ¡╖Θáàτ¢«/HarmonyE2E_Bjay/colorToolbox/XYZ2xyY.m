function [ cCoord ] = XYZ2xyY( tValues )
% function [ chromaticityCoordinates ] = XYZ2xyY( tValues )
%   where:
%   cCoord are the chromaticity coordiantes
%   tValues are the tristimulus values

XYZ = sum(tValues);

x = tValues(1,:)./XYZ;
y = tValues(2,:)./XYZ;

cCoord = [ x; y; tValues(2,:)];

end

