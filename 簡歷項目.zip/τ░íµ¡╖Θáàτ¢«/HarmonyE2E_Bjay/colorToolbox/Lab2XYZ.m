function [ XYZ ] = Lab2XYZ( Lab, XYZn )
% function [ XYZ ] = Lab2XYZ( Lab, XYZn )
%   in:
%       Lab: 3-by-n array of CIELAB values
%       XYZn:3-by-1 vector of an illuminant white point
%   out:
%       XYZ:3-by-n array of tristimulus values 

term = (Lab(1,:)+16)/116;

XYZ= [XYZn(1)*(term++Lab(2,:)/500).^3; XYZn(2)*(term).^3; XYZn(3)*(term-Lab(3,:)/200).^3];


end

