function [ cielab ] = XYZ2Lab( XYZ, XYZn )
% function [ cielab ] = XYZ2Lab( XYZ, XYZn )
%   in:
%       XYZ: 3-by-n array of tristimulus values 
%       XYZn: 3-by-1 vector of an illuminant white point
%   out:
%       cielab: 3-by-n array of CIELAB values
%

% compute the ratio
ratio = diag(1./XYZn)*XYZ;

% create a matrix from the same size as XYZ with zeros
y = zeros(size(XYZ));

% get the index of all the values bigger than 0.008856
idx = (ratio > 0.008856);

% compute the cubic root of all those values
y(idx) = ratio(idx).^(1/3);

% compute the other equation for the values less or equal  0.008856
y(~idx) = 7.787*ratio(~idx) + 16/116;
    
% finally, use the computed values to get the input XYZ values in CIELab
cielab = [116.*y(2,:)-16; 500*(y(1,:)-y(2,:)); 200*(y(2,:)-y(3,:))];
