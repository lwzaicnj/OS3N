function [ XYZ ] = uvY2XYZ( uvY )
%function [ XYZ ] = uvY2XYZ( uvY )

XYZ = zeros(3,size(uvY,2));

XYZ(1,:) = 9*uvY(3,:).*uvY(1,:)./(4*uvY(2,:)); %X
XYZ(2,:) = uvY(3,:); %Y
XYZ(3,:) = 9*uvY(3,:)./(3*uvY(2,:))-9*uvY(3,:).*uvY(1,:)./(12*uvY(2,:))-5*uvY(3,:);%Z

end

