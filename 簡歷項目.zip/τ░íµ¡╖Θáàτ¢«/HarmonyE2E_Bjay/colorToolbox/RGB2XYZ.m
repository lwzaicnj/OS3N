function [ out ] = RGB2XYZ( in, varargin )
%RGB2XYZ Summary of this function goes here
%   Detailed explanation goes here

%wikipedia
%m = [0.4124 0.3576 0.1805; 0.2126 0.7152 0.0722; 0.0193 0.1192 0.9505];

%w3
m = [0.4124 0.3576 0.1805; 0.2126 0.7152 0.0722; 0.0193 0.1192 0.9505];


% transform to XYZ
if(size(varargin,1)>0)
    % gamma correction
    
    idx = (in>0.00304);
    
    in(idx) = ((in(idx)+0.055)/1.055).^2.4;
    
    in(~idx) = in(~idx)/12.92;
end

out = m*in;

end

