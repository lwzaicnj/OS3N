import os
import sys
import re
import random
import glob
import tempfile
import shutils

class PDCAItem:
    def __init__(self, name, file, pattern):
        self.name = name
        self.file = file
        self.pattern = pattern

    def lookup(self):
        pass
 
    def __str__(self):
        return ""

class Attribute(PDCAItem):
    def __init__(self, name, file, pattern):
       PDCAItem.__init__(self, name, file, pattern)

    def lookup(self):
        file = glob.glob(self.file)[0]
        with open(file, "r") as textfile:
            text  = textfile.read()
            m = re.search(self.pattern, text)
            self.value = m.groups()[0]

    def __str__(self):
        return "{:15} : {}".format(self.name, self.value)

class ParametricData(PDCAItem):
    def __init__(self, name, file, pattern):
       PDCAItem.__init__(self, name, file, pattern)

    def construct_regex(self):
        return r"""<key>subtestname</key>\n
        \s+<string>{}</string>\n
        \s+<key>testname</key>\n
        \s+<string>HarmonyE2E</string>\n
        \s+<key>upperLimit</key>\n
        \s+<string>([^<]+)</string>\n
        \s+<key>value</key>\n
        \s+<string>([^<]+)</string>""".format(self.pattern)

    def lookup(self):
        file = glob.glob(self.file)[0]
        #print file, self.pattern
        with open(file, "r") as textfile:
            text  = textfile.read()
            m = re.search(self.construct_regex(), text, re.VERBOSE)
            #print m.groups()
            self.limit = float(m.groups()[0])
            self.value = float(m.groups()[1])

    def __str__(self):
        limitstr = " "
        if self.value > self.limit:
            limitstr = "(exp. <= {:8.4f})".format(self.limit)
        return "{0:16} : {1:-10.4f} {2:24} [{3}]".format(self.name, self.value, limitstr, self.pattern)

class Report:
    def __init__(self, folderpath, reportItems):
        self.folderpath = os.path.abspath(folderpath)
        self.reportItems = reportItems

        if not os.path.exists(self.folderpath):
            raise(IOError("Folder {} does not exist".format(self.folderpath)))
        if not os.path.isdir(self.folderpath):
            raise(IOError("{} is not a folder".format(self.folderpath)))


    def validate(self):

        # make sure that all the files needed for the report exist
        necessary_files = { os.path.abspath(item.file) for item in self.reportItems if item.file is not  None }
        for file in necessary_files:
            resolved_files = glob.glob(file)
            if len(resolved_files) == 0:
                raise(IOError("Required file {} does not exist".format(file)))

    def run(self):
        try:
            previousDir = os.getcwd()
            os.chdir(self.folderpath)

            self.validate()
            #with open(self.summaryfilepath, "w+") as outfile:
            (temp, outfilename) = tempfile.mkstemp(text=True)
            outfile = os.fdopen(temp, "w+")
            self.summaryfilepath = outfilename

            outfile.write("Summarizing folder {}\n\n".format(self.folderpath))      
          
            for item in SummaryReportItems:
                item.lookup()
                outfile.write(item.__str__())
                outfile.write("\n")
            os.chdir(previousDir)
        except Exception as err:
            print err
            return

    def save(self):
        newpath = os.path.join(self.folderpath, 'summary.txt')
        shutils.mv(self.summaryfilepath, newpath)
        self.summaryfilepath = newpath



    def show(self):
        """ the 'open' command is specific to OS X"""
        os.system("open " + re.escape(self.summaryfilepath))

SummaryReportItems = [
    Attribute("SERIAL", "mobdev.plist", r"<key>SerialNumber</key>\n\s+<string>([^<]+)</string>"),
    Attribute("STATION_OVERLAY", "*_IP.plist", r"<key>softwareversion</key>\n\s+<string>([^<]+)</string>"),
    Attribute("DUT_SW_BUNDLE", "mobdev.plist", r"<key>BuildVersion</key>\n\s+<string>([^<]+)</string>"),
    PDCAItem("", None, ""),
    ParametricData("L1_ALS_DE_LEFT",   "*_IP.plist", "L1I100Stren0.5BltCur0.5_s6_alsCalDeltaEPlus"),
    ParametricData("L1_ALS_DE_RIGHT",  "*_IP.plist", "L1I100Stren0.5BltCur0.5_s5_alsCalDeltaEPlus"),
    ParametricData("L2_ALS_DE_LEFT",   "*_IP.plist", "L2I100Stren0.5BltCur0.5_s6_alsCalDeltaEPlus"),
    ParametricData("L2_ALS_DE_RIGHT",  "*_IP.plist", "L2I100Stren0.5BltCur0.5_s5_alsCalDeltaEPlus"),
    ParametricData("L3_ALS_DE_LEFT",   "*_IP.plist", "L3I100Stren0.5BltCur0.5_s6_alsCalDeltaEPlus"),
    ParametricData("L3_ALS_DE_RIGHT",  "*_IP.plist", "L3I100Stren0.5BltCur0.5_s5_alsCalDeltaEPlus"),
    PDCAItem("", None, ""),
    ParametricData("L1_DISP_DE_LEFT",  "*_IP.plist", "L1I100Stren0.5BltCur0.5_s6_displDeltaEPlus"),
    ParametricData("L1_DISP_DE_RIGHT", "*_IP.plist", "L1I100Stren0.5BltCur0.5_s5_displDeltaEPlus"),
    ParametricData("L2_DISP_DE_LEFT",  "*_IP.plist", "L2I100Stren0.5BltCur0.5_s6_displDeltaEPlus"),
    ParametricData("L2_DISP_DE_RIGHT", "*_IP.plist", "L2I100Stren0.5BltCur0.5_s5_displDeltaEPlus"),
    ParametricData("L3_DISP_DE_LEFT",  "*_IP.plist", "L3I100Stren0.5BltCur0.5_s6_displDeltaEPlus"),
    ParametricData("L3_DISP_DE_RIGHT", "*_IP.plist", "L3I100Stren0.5BltCur0.5_s5_displDeltaEPlus"),
    PDCAItem("", None, ""),
    ParametricData("L1_E2E_DE_LEFT",   "*_IP.plist", "L1I100Stren0.5BltCur0.5_s6_e2eDeltaEPlus"),
    ParametricData("L1_E2E_DE_RIGHT",  "*_IP.plist", "L1I100Stren0.5BltCur0.5_s5_e2eDeltaEPlus"),
    ParametricData("L2_E2E_DE_LEFT",   "*_IP.plist", "L2I100Stren0.5BltCur0.5_s6_e2eDeltaEPlus"),
    ParametricData("L2_E2E_DE_RIGHT",  "*_IP.plist", "L2I100Stren0.5BltCur0.5_s5_e2eDeltaEPlus"),
    ParametricData("L3_E2E_DE_LEFT",   "*_IP.plist", "L3I100Stren0.5BltCur0.5_s6_e2eDeltaEPlus"),
    ParametricData("L3_E2E_DE_RIGHT",  "*_IP.plist", "L3I100Stren0.5BltCur0.5_s5_e2eDeltaEPlus")
]

if __name__ == "__main__":
    for folder in sys.argv[1:]:
        print "trying {}".format(folder)
        try:
            summaryreport = Report(folder, SummaryReportItems)
            summaryreport.run()
            summaryreport.show()
        except IOError as err:
            print err
            continue
        except Exception as err:
            print err
            exit(1)
