channel = sshfrommatlab('root','localhost',10022,'alpine')

i = 1;
while(1)
    tic
    if(i==1)
        sshfrommatlabissue_dontwait(channel,'gammaLut -b');
        i=2;
    else
        sshfrommatlabissue_dontwait(channel,'gammaLut -l');
        i=1;
    end
    
    toc
end

sshfrommatlabclose(channel)