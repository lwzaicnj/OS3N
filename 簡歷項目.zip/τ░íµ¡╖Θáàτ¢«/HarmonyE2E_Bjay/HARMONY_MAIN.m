% File to test all the individual components under development
function [] = HARMONY_MAIN(fileName)
%     clear all 
	close all
	clc
%     disp(savePath); 
    disp('## Starting Harmony End to End test')
    disp(cat(2,'Save path passed in ', fileName)); 
%% SCRIPT SETUP
    %% Setup script path, etc
    tic
    disp(' ')
    disp(['SCRIPT SETUP AND CONFIGURATION [',datestr(clock,0), ']'])
    % set up paths to necessary files.
    %   - paths may be different if running locally or deployed as an exe
    %   - python should be /usr/bin/python on any Yosemite or El Capitan mac 
    pythonPath = '/usr/bin/python';  
 
    
    if isdeployed()
        javaPath = '/Users/gdlocal/HarmonyE2E/ganymed-ssh2-build250.jar';
        configPath = '/Users/gdlocal/HarmonyE2E/config.csv';
        tcprelayPath = '/Users/gdlocal/HarmonyE2E/tcprelay';
        sendCommandPath = '/Users/gdlocal/HarmonyE2E/sendCommand';
        fixtureCtlPath = '/Users/gdlocal/HarmonyE2E/BJPLCctl';
        cd '/Users/gdlocal/HarmonyE2E/';
        export = 1;
    else
        javaPath = 'sshToolkit/ganymed-ssh2-build250.jar';
        configPath = 'config.csv';
        tcprelayPath = '/usr/local/bin/tcprelay';        
        addpath('utils');
        addpath('colorToolbox');
        addpath('sshToolkit');
        fixtureCtlPath = '/Users/gdlocal/HarmonyE2E/BJPLCctl';
        export = 1; 
    end
    disp(['    Config file             = ', configPath])
    disp(['    Java path additions     = ', javaPath])
    javaaddpath(javaPath);    
    
    
    %3-29
   % hostcommand(cat(2, fixtureCtlPath,' open-door'));
    %hostcommand(cat(2, fixtureCtlPath,' close-door'));

    % Constants 
    alsSamplingTime = 0.25;
    alsSampleSize = 5;
    permsPerLightCap = 2;   % changed from 5 because of rdar://24302512
%     dispIntTime = 70; 
%     specIntTime = 250;
    dispIntTime = 20;%40; 
%     disp(['    ALS Sampling Time       = ', num2str(alsSamplingTime)]);
%     disp(['    ALS Sample Size         = ', num2str(alsSampleSize)]);
    disp(['    Permutations/Light      = ', num2str(permsPerLightCap)]);

    exportHeaders = {}; %summary for pdca 
    exportValues = {}; %summary for pdca 
    namePrefixes = {}; 
    
    %read config file
    config = importdata(configPath);
    numLightCapture = length(config.data);
    
    disp(['    Number of configs       = ', num2str(numLightCapture)]);
    if (numLightCapture <= 0 )
        error('ERROR: No configurations found; chech "config.csv"');
    end
    
    disp(['RIG SETUP AND CONFIGURATION [',datestr(clock,0), ']'])
    
    %delay x sec
    
    %hostcommand(cat(2, fixtureCtlPath,' waittest'));
    
    pause(2);
    moveToPosition(1, fixtureCtlPath);
    hostcommand(cat(2,fixtureCtlPath,' close-door'));
    
    
    timing.scriptSetupTime = toc;
     
%% DEVICE SETUP
    % Setup DUT and ensure harmony enabled
    % TODO How to Set agressive harmony
    tic
    disp(' ')
    disp(['DEVICE SETUP AND CONFIGURATION [',datestr(clock,0), ']'])
    hostcommand(cat(2, tcprelayPath,' --portoffset 10000 22 &'));
        
    timing.devSetupTime = toc;
    
    % Opening communications channel with DUT 
    channel = sshfrommatlab('root','localhost','10022','alpine');
    
    % get some info about the device  (BuildVersion, DeviceColor)
    [devInfoKeys, devInfoValues] = getDeviceInfo(channel); 
    
    sshfrommatlabissue_dontwait(channel, 'BacklightdTester -set ColorAdaptationEnabled 1');
    sshfrommatlabissue_dontwait(channel, 'BacklightdTester -ui');
    sshfrommatlabissue_dontwait(channel, 'BacklightdTester -s 0 0');
    sshfrommatlabissue_dontwait(channel, 'diagstool lcdmura -p3 0,0,0');
    
    isBlack = isDeviceBlack(channel);
    exportHeaders = cat(1, exportHeaders, 'isBlack'); 
    exportValues = cat(1, exportValues, isBlack); 

%% LIGHT CAPTURE
    tic 
    disp(' ')
    disp(['LIGHT CAPTURE [',datestr(clock,0), ']'])
    
    % For each configuration 
    alsXYZNW = [];
    alsXYZNE = [];
    counts = []; 
    for i = 1:numLightCapture%3
        selectLightSource(int8(config.data(i,1)), fixtureCtlPath); 
        setIris(fixtureCtlPath, int8(config.data(i,1)), config.data(i,2));
        
        if(isequal(config.data(i,1),2) | isequal(config.data(i,1),5) )
            specIntTime = 50;
        else 
            specIntTime = 100;
        end
        %moveToPosition(1, fixtureCtlPath); 
        % Get Lux Measurement
        
        %Debug only
        %[status luxLocal] = getLuxReading(pythonPath); 
        %disp(['    # Getting lux measurement: ', num2str(luxLocal)]);
        
        % Get ALS Measurements 
        disp('    # Getting ALS measurement (x2)')
        [status alsXYZNWLuxLocal] = getALSxyz(channel, 5, alsSampleSize, alsSamplingTime); 
        [status alsXYZNELuxLocal] = getALSxyz(channel, 6, alsSampleSize, alsSamplingTime); 
        
%         alsXYZNELuxLocal = result(:,1);
%         alsXYZNWLuxLocal = result(:,2);
        
%         disp(['als XYZ NW Lux: ',mat2str(alsXYZNWLuxLocal)])
%         disp(['als XYZ NE Lux: ',mat2str(alsXYZNELuxLocal)])
           
        %% Capture CAS140 + 2xALS
        % Move spectralon under CAS (position 2)
        
        %moveToPosition(2, fixtureCtlPath);  
        
        [status casSpecxyYRefLocal countsLocal] = getCASxyY(pythonPath, specIntTime, cat(2, ' -s ', fileName, '/Spectra/L', num2str(config.data(i,1)), '/'));
        
        %[status casSpecxyYRefLocal countsLocal] = getCASxyY(pythonPath, specIntTime, cat(2, ' -s ', fileName, '/Spectra/L', config.data(i,1), '/'));
       
        [status alsXYZNWLocal] = getALSxyz(channel, 5, alsSampleSize, alsSamplingTime); 
        [status alsXYZNELocal] = getALSxyz(channel, 6, alsSampleSize, alsSamplingTime); 
        
        
        exportHeaders = cat(1, exportHeaders, cat(2,'L',num2str(config.data(i,1)), 'I', num2str(config.data(i,2)) ,'_casADCcounts')); 
        exportValues = cat(1, exportValues, countsLocal); 
        
%         alsXYZNELocal = result(:,1);
%         alsXYZNWLocal = result(:,2);
        disp(['als XYZ NW: ',mat2str(alsXYZNWLocal)])
        disp(['als XYZ NE: ',mat2str(alsXYZNELocal)])
        
        % Restructure for future permutations
        if (i>1)
            %alsXYZNWLux     = cat(2,alsXYZNWLux, repmat(alsXYZNWLuxLocal,1,permsPerLightCap));
            %alsXYZNELux     = cat(2,alsXYZNELux, repmat(alsXYZNELuxLocal,1,permsPerLightCap));
            alsXYZNWLux     = cat(2,alsXYZNWLux, repmat(alsXYZNWLuxLocal,1,permsPerLightCap));
            alsXYZNELux     = cat(2,alsXYZNELux, repmat(alsXYZNELuxLocal,1,permsPerLightCap));
            alsXYZNW        = cat(2,alsXYZNW, repmat(alsXYZNWLocal,1,permsPerLightCap));
            alsXYZNE        = cat(2,alsXYZNE, repmat(alsXYZNELocal,1,permsPerLightCap));
            casSpecxyYRef   = cat(2,casSpecxyYRef, repmat(casSpecxyYRefLocal, 1, permsPerLightCap));
            %Debug only. Disabled for now
%            lux             = cat(2,lux, repmat(luxLocal, 1, permsPerLightCap)); 
        else
            alsXYZNWLux     = repmat(alsXYZNWLuxLocal,1,permsPerLightCap);
            alsXYZNELux     = repmat(alsXYZNELuxLocal,1,permsPerLightCap);
            alsXYZNW        = repmat(alsXYZNWLocal,1,permsPerLightCap);
            alsXYZNE        = repmat(alsXYZNELocal,1,permsPerLightCap);
            casSpecxyYRef   = repmat(casSpecxyYRefLocal, 1, permsPerLightCap);
            
            %Debug only. Disabled for now
%            lux             = repmat(luxLocal, 1, permsPerLightCap);
        end
    end
    
    selectLightSource(1, fixtureCtlPath);
    hostcommand(cat(2,fixtureCtlPath,' a2-work-place'));
    selectLightSource(5, fixtureCtlPath);
    
    
    alsxyYNW = XYZ2xyY(alsXYZNW); 
    alsxyYNE = XYZ2xyY(alsXYZNE); 
        
    timing.lightCaptureTime = toc;  

    
%% DISPLAY MEASUREMENT
    tic
    disp(' ')
    disp(['DISPLAY MEASUREMENT [',datestr(clock,0), ']'])
    
    % rdar://24116855 Collect "Display Temperature" after light collection
    displayTemperature = getDisplayTemp(channel);
   
    % Turn OFF lights; TODO do we need to do this here? Do we need to
    % force the brightness to 1 because we are in the dark 
    selectLightSource(-1, fixtureCtlPath);
    hostcommand(cat(2,fixtureCtlPath,' a2-reset'));
    
    % Move the DUT to have the CAS140 measuring the center of the display
    % Display White (pos 3)
    % moveToPosition(3, fixtureCtlPath);
    moveToPosition(2, fixtureCtlPath);
    casDisplayxyYNW = [];
    casDisplayxyYNE = [];
    alsDisplayRecxyzNW = [];
    alsDisplayRecxyzNE = [];
    
    % TODO is there room in test time to do more of these?
    % In particular, see <rdar://problem/24079680>
    backlightCurrent = 0.5;
    %Issues commands to a remote computer from within Matlab
    sshfrommatlabissue_dontwait(channel, cat(2, 'BacklightdTester -s ', num2str(backlightCurrent), ' 0'));
    sshfrommatlabissue_dontwait(channel, 'diagstool lcdmura -p3 1023,1023,1023');
    
    for light = 1:numLightCapture %3
        % Forcing the display 
        selectIndex = (light*permsPerLightCap);% permsPerLightCap = 2; 
        
        % Set the backlight and temp compensation flags on the device
        % We only do POR comp settings now (tempComp=1, backlightComp=1) to
        % save cycle time.   See:
        %     <rdar://24302512> Remove Non-POR display readings
        tempComp = 1; 
        backlightComp = 1; 
        setCompensation( channel, [backlightComp tempComp] ); 

        %------------------------------------------------------------------
        % Drive display to ALS 5 and 6 values at strength = 0.5 
        strength = 0.5;
        % disp(cat(2,'Setting harmony rec with strength 0.5 to: ', mat2str(alsxyYNW(:,selectIndex))));
        setHarmonyRec(channel, alsxyYNW(:,selectIndex), strength);
        [status, alsDisplayRecxyzNWLocal] = getHarmonyRecxyY(channel);%3*1
        [status, casDisplayxyYNWLocal] = getCASxyY(pythonPath, dispIntTime);%3*1
        casDisplayxyYNW = cat(2,casDisplayxyYNW, casDisplayxyYNWLocal);
        alsDisplayRecxyzNW = cat(2,alsDisplayRecxyzNW, alsDisplayRecxyzNWLocal);
        
       
        % disp(cat(2,'Setting harmony rec with strength 0.5 to: ', mat2str(alsxyYNE(:,selectIndex))));
        setHarmonyRec(channel, alsxyYNE(:,selectIndex), strength);
        [status, alsDisplayRecxyzNELocal] = getHarmonyRecxyY(channel);
        [status, casDisplayxyYNELocal] = getCASxyY(pythonPath, dispIntTime);
        casDisplayxyYNE = cat(2,casDisplayxyYNE, casDisplayxyYNELocal);
        alsDisplayRecxyzNE = cat(2,alsDisplayRecxyzNE, alsDisplayRecxyzNELocal);

        namePrefix = cat(2,'L',num2str(int8(config.data(light,1))), 'I', num2str(int8(config.data(light,2)))); 
        namePrefix = cat(2, namePrefix,'Stren', num2str(strength,'%1.1f'),'BltCur',num2str(backlightCurrent,'%1.1f')); 
        namePrefixes = cat(1, namePrefixes, namePrefix);

        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_als_x'),cat(2,namePrefix,'_s5_als_y'),cat(2,namePrefix,'_s5_als_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_als_x'),cat(2,namePrefix,'_s6_als_y'),cat(2,namePrefix,'_s6_als_Y')); 
       % exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_lux'));
       % 4.1
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_als_lux'), cat(2,namePrefix,'_s6_als_lux')); 

        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_casDisp_x'),cat(2,namePrefix,'_s5_casDisp_y'),cat(2,namePrefix,'_s5_casDisp_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_casDisp_x'),cat(2,namePrefix,'_s6_casDisp_y'),cat(2,namePrefix,'_s6_casDisp_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_alsDispRec_x'),cat(2,namePrefix,'_s5_alsDispRec_y'),cat(2,namePrefix,'_s5_alsDispRec_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_alsDispRec_x'),cat(2,namePrefix,'_s6_alsDispRec_y'),cat(2,namePrefix,'_s6_alsDispRec_Y')); 

        exportValues = cat(1, exportValues, num2cell(alsxyYNW(:,selectIndex)), num2cell(alsxyYNE(:,selectIndex))); 
        
        %Debug only
      %  exportValues = cat(1, exportValues, num2cell(lux(:,selectIndex)));
        exportValues = cat(1, exportValues, num2cell(alsXYZNWLux(2,selectIndex)), num2cell(alsXYZNELux(2,selectIndex)));
        exportValues = cat(1, exportValues, num2cell(casDisplayxyYNWLocal), num2cell(casDisplayxyYNELocal)); 
        exportValues = cat(1, exportValues, num2cell(alsDisplayRecxyzNWLocal), num2cell(alsDisplayRecxyzNELocal)); 
        
        %------------------------------------------------------------------
        % Drive display to ALS 5 and 6 values at strength = 1.0 
        strength = 1.0;
        % disp(cat(2,'Setting harmony rec with strength 1 to: ', mat2str(alsxyYNW(:,selectIndex))));
        setHarmonyRec(channel, alsxyYNW(:,selectIndex), strength);
        [status, alsDisplayRecxyzNWLocal] = getHarmonyRecxyY(channel);%3*1
        [status, casDisplayxyYNWLocal] = getCASxyY(pythonPath, dispIntTime);%3*1
        casDisplayxyYNW = cat(2,casDisplayxyYNW, casDisplayxyYNWLocal);%3*2
        alsDisplayRecxyzNW = cat(2,alsDisplayRecxyzNW, alsDisplayRecxyzNWLocal);%3*2

        % disp(cat(2,'Setting harmony rec with strength 1 to: ', mat2str(alsxyYNE(:,selectIndex))));
        setHarmonyRec(channel, alsxyYNE(:,selectIndex), strength);
        [status, alsDisplayRecxyzNELocal] = getHarmonyRecxyY(channel);
        [status, casDisplayxyYNELocal] = getCASxyY(pythonPath, dispIntTime);
        casDisplayxyYNE = cat(2,casDisplayxyYNE, casDisplayxyYNELocal);
        alsDisplayRecxyzNE = cat(2,alsDisplayRecxyzNE, alsDisplayRecxyzNELocal);
        
        namePrefix = cat(2,'L',num2str(int8(config.data(light,1))), 'I', num2str(int8(config.data(light,2)))); 
        namePrefix = cat(2, namePrefix,'Stren', num2str(strength,'%1.1f'),'BltCur',num2str(backlightCurrent,'%1.1f')); 
        namePrefixes = cat(1, namePrefixes, namePrefix);%2*1
        
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_als_x'),cat(2,namePrefix,'_s5_als_y'),cat(2,namePrefix,'_s5_als_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_als_x'),cat(2,namePrefix,'_s6_als_y'),cat(2,namePrefix,'_s6_als_Y')); 
        
        %Debug only. Disabled
        %exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_lux')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_als_lux'), cat(2,namePrefix,'_s6_als_lux')); 

        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_casDisp_x'),cat(2,namePrefix,'_s5_casDisp_y'),cat(2,namePrefix,'_s5_casDisp_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_casDisp_x'),cat(2,namePrefix,'_s6_casDisp_y'),cat(2,namePrefix,'_s6_casDisp_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s5_alsDispRec_x'),cat(2,namePrefix,'_s5_alsDispRec_y'),cat(2,namePrefix,'_s5_alsDispRec_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_s6_alsDispRec_x'),cat(2,namePrefix,'_s6_alsDispRec_y'),cat(2,namePrefix,'_s6_alsDispRec_Y')); 

        exportValues = cat(1, exportValues, num2cell(alsxyYNW(:,selectIndex)), num2cell(alsxyYNE(:,selectIndex))); 
        
        
%        exportValues = cat(1, exportValues, num2cell(lux(:,selectIndex)));
        exportValues = cat(1, exportValues, num2cell(alsXYZNWLux(2,selectIndex)), num2cell(alsXYZNELux(2,selectIndex)));
        exportValues = cat(1, exportValues, num2cell(casDisplayxyYNWLocal), num2cell(casDisplayxyYNELocal)); 
        exportValues = cat(1, exportValues, num2cell(alsDisplayRecxyzNWLocal), num2cell(alsDisplayRecxyzNELocal)); 
        
        %------------------------------------------------------------------
        % Drive display to Reference spectralon value at strength = 0.5 
        strength = 0.5;  
        % disp(cat(2,'Setting harmony rec with strength 0.5 to: ', mat2str(casSpecxyYRef(:,selectIndex))));
        setHarmonyRec(channel, casSpecxyYRef(:,selectIndex), strength);
        [status refHarmonyRecxyzLocal] = getHarmonyRecxyY(channel);%3*1
        
        namePrefix = cat(2,'L',num2str(int8(config.data(light,1))), 'I', num2str(int8(config.data(light,2)))); 
        namePrefix = cat(2, namePrefix,'Stren', num2str(strength,'%1.1f'),'BltCur',num2str(backlightCurrent,'%1.1f')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_casSpecRef_x'),cat(2,namePrefix,'_casSpecRef_y'),cat(2,namePrefix,'_casSpecRef_Y')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_refHmnyRec_x'),cat(2,namePrefix,'_refHmnyRec_y'),cat(2,namePrefix,'_refHmnyRec_Y')); 
        
        %------------------------------------------------------------------
        % Drive display to Reference spectralon value at strength = 1.0 
        strength = 1.0;  
        % disp(cat(2,'Setting harmony rec with strength 1 to: ', mat2str(casSpecxyYRef(:,selectIndex))));
        setHarmonyRec(channel, casSpecxyYRef(:,selectIndex), strength);
        [status refHarmonyRecxyzLocalStrong] = getHarmonyRecxyY(channel);
        
        namePrefix = cat(2,'L',num2str(int8(config.data(light,1))), 'I', num2str(int8(config.data(light,2)))); 
        namePrefix = cat(2, namePrefix,'Stren', num2str(strength,'%1.1f'),'BltCur',num2str(backlightCurrent,'%1.1f')); 
        exportHeaders = cat(1, exportHeaders, cat(2,namePrefix,'_refHmnyRec_x'),cat(2,namePrefix,'_refHmnyRec_y'),cat(2,namePrefix,'_refHmnyRec_Y')); 
        
        exportValues = cat(1, exportValues, num2cell(casSpecxyYRef(:,selectIndex))); 
        exportValues = cat(1, exportValues, num2cell(refHarmonyRecxyzLocal)); 
        exportValues = cat(1, exportValues, num2cell(refHarmonyRecxyzLocalStrong)); 
        
        if (light>1)
            refHarmonyRecxyz = cat(2, refHarmonyRecxyz, repmat(refHarmonyRecxyzLocal,1,permsPerLightCap-1)); %permsPerLightCap = 2;
            refHarmonyRecxyz = cat(2, refHarmonyRecxyz, refHarmonyRecxyzLocalStrong); 
        else
            refHarmonyRecxyz = repmat(refHarmonyRecxyzLocal,1,(permsPerLightCap-1));
            refHarmonyRecxyz = cat(2, refHarmonyRecxyz, refHarmonyRecxyzLocalStrong); 
        end
    end

    timing.dispMeasTime = toc;  
%% ERROR CALCULATIONS AND REPORTING
    % xyY
    tic
    disp(' ')
    disp(['dE+ CALCULATIONS AND REPORTING [',datestr(clock,0), ']'])
    
    dut.CASDisplayxyYNW = casDisplayxyYNW;
    dut.CASDisplayxyYNE = casDisplayxyYNE;
    dut.ALSDisplayRecxyzNW = alsDisplayRecxyzNW;
    dut.ALSDisplayRecxyzNE = alsDisplayRecxyzNE;
    dut.CASSpecxyYRef = casSpecxyYRef;
    dut.ALSxyYNE = alsxyYNE; 
    dut.ALSxyYNW = alsxyYNW; 
    dut.RefHarmonyRecxyY = refHarmonyRecxyz; 
    
    %four deltaE+
    ALSCalDeltaEPlus = [ computeDeltaEplus(dut.ALSxyYNW, dut.CASSpecxyYRef) ...
                         computeDeltaEplus(dut.ALSxyYNE, dut.CASSpecxyYRef)];
    
    ALSColorDeltaEPlus = [ computeDeltaEplus(dut.ALSDisplayRecxyzNW, dut.RefHarmonyRecxyY) ...
                           computeDeltaEplus(dut.ALSDisplayRecxyzNE, dut.RefHarmonyRecxyY)];
    
    % fix <rdar://24352205> Change Display dE+ and E2E dE+ calculation to account for WP shift.
    % Need to adjust the white point whenever the display is involved (so
    % not for ALS deltaEPlus calcs. Added calculateAdjustedxyTarget() calls
    % Also, order of arguments matters for dE+ (but not normal dE).
    % The reference measurement should be the second element.
    displayDeltaEPlus =   [ computeDeltaEplus(dut.CASDisplayxyYNW, calculateAdjustedxyTarget(dut.ALSDisplayRecxyzNW)) ...
                            computeDeltaEplus(dut.CASDisplayxyYNE, calculateAdjustedxyTarget(dut.ALSDisplayRecxyzNE)) ];
                  
    endToEndDeltaEPlus =  [ computeDeltaEplus(dut.CASDisplayxyYNW, calculateAdjustedxyTarget(dut.RefHarmonyRecxyY)) ...
                            computeDeltaEplus(dut.CASDisplayxyYNE, calculateAdjustedxyTarget(dut.RefHarmonyRecxyY)) ];
                  
    timing.deltaTime = toc; 
%% Takedown Test: Export and reset device 
    tic
    disp(' ')
    disp(['TEST CLEANUP [',datestr(clock,0), ']'])
    channel = sshfrommatlabclose(channel);
%     disableSensorOverride(); 
    if(export)
        try 
            docNode = com.mathworks.xml.XMLUtils.createDocument('plist');
            docRootNode = docNode.getDocumentElement;
            docRootNode.setAttribute('version','1.0');
            thisElement = docNode.createElement('array');
            docRootNode.appendChild(thisElement);

            % Save the sample XML document.
            pdca_filepath = cat(2,fileName,'/alsParametricData.plist');
            xmlwrite(pdca_filepath,docNode);

        catch err
            if isdeployed()
                disp(cat(2, 'ERROR: error creating alsParametricData.plist: ', err.message));
                exit(6);
            else
                error(err.message)
                return
            end
        end 
        
        disp(cat(2,'Exporting: ', pdca_filepath)); 

        % Export DUT info (BuildVersion, etc) from getDeviceInfo()
        % Commenting this out because of <rdar://problem/24453510>
        %  Non-numeric build numbers cause PDCA parametric data upload fail
        % addAttribute(pdca_filepath, devInfoKeys, devInfoValues)
 
        % Export display temperature (see rdar://24116855)
        addAttribute(pdca_filepath, {'displayTemperature'}, [ {num2str(displayTemperature)}] );
 
        % Export Light capture data and the display measurements. 
        addAttribute(pdca_filepath, exportHeaders, exportValues);

        % Export deltaE+ measurements and limits
        % LIMITS - final word on dE+ limits from Jerry/Blake/OSD (for DVT):
        % Display limit adjusted from 3 to 3.2 per <rdar://24352205>
        %    ALSCAL   : ON AXIS  3.9,        OFF AXIS  NO LIMIT
        %    ALSCOLOR : ON AXIS  NO LIMIT,   OFF AXIS  NO LIMIT
        %    DISP     : ON AXIS  3.2,        OFF AXIS  NO LIMIT
        %    E2E      : ON AXIS  5,          OFF AXIS  NO LIMIT
        
        ALSCalLimit = 3.9
        DispLimit = 3.2
        E2ELimit = 5
        
        for i = 1:numLightCapture
            light =  int8(config.data(i,1))
            for j = 1:2
                alsplacement=j+4
                names = namePrefixes((light-1)*permsPerLightCap+1:light*permsPerLightCap);
                % TODO: Combine On and Off axis blocks below by making
                % addAttribute smarter.  see <rdar://24304247>
                if light <= 3       % Apply Limits for On Axis Lights
                    % Export ALSCal dE+ parametric data with limits
                    tempArray = ALSCalDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    ComponentDeltaLimits = num2cell(repmat(ALSCalLimit, 1, length(deltaUploadArray))); 
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_alsCalDeltaEPlus')), deltaUploadArray, ComponentDeltaLimits);

                    % Export ALSColor dE+ parametric data with limits
                    % NOTE:  No limits on ALSColor for now.
                    tempArray = ALSColorDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_alsColorDeltaEPlus')), deltaUploadArray)
               
                    % Export Display dE+ parametric data with limits
                    tempArray = displayDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    % <rdar://24079384> Remove limits on non-POR disp dE+
                    ComponentDeltaLimits = num2cell(repmat(DispLimit, 1, length(deltaUploadArray))); 
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_displDeltaEPlus')), deltaUploadArray, ComponentDeltaLimits);

                    % Export E2E dE+ parametric data with limits
                    tempArray = endToEndDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    ComponentDeltaLimits = num2cell(repmat(E2ELimit, 1, length(deltaUploadArray))); 
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_e2eDeltaEPlus')), deltaUploadArray, ComponentDeltaLimits);
                else   % Off Axis Lights (no limits at present, so code can be simpler)
                    tempArray = ALSCalDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_alsCalDeltaEPlus')), deltaUploadArray)   
                    tempArray = ALSColorDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_alsColorDeltaEPlus')), deltaUploadArray)
                    tempArray = displayDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_dispDeltaEPlus')), deltaUploadArray)
                    tempArray = endToEndDeltaEPlus(j).deltaE00';
                    deltaUploadArray = num2cell(tempArray((light-1)*permsPerLightCap+1:light*permsPerLightCap));
                    addAttribute(pdca_filepath, strcat(names,cat(2,'_s', num2str(alsplacement),'_e2eDeltaEPlus')), deltaUploadArray)

                end
            end
            
        end 
        
        xmlremoveextralines(pdca_filepath); 

    end    
%     hostcommand('killall tcprelay');
    
    clear channel;
    clear ans;
    clear status; 
    % Clearing variables that dont need to be saved. 
    clear casDisplayxyYNELocal
    clear casDisplayxyYNWLocal
    clear casSpecxyYRefLocal
    clear alsDisplayRecxyYNELocal
    clear alsDisplayRecxyYNWLocal
    clear alsXYZNELocal
    clear alsXYZNELuxLocal
    clear alsXYZNWLocal
    clear alsXYZNWLuxLocal
    clear luxLocal 
    clear refHarmonyRecxyzLocal
    clear refHarmonyRecxyzLocalStrong
    clear javaPath
    clear fixtureCtlPath
    clear pythonPath
    clear tcprelayPath
    clear i
    clear tempArray
    
    save(cat(2,fileName,'/harmonye2e.mat')); 
    disp('End of test'); 
    timing.takeDownTime = toc;
    clear all;
end

