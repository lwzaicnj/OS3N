function [] = specSweep(num, filename)
    tic
    pythonPath = '/usr/bin/python'; 
    %channel = sshfrommatlab('root','localhost',10022,'alpine');
    
	%lastCas = [0.3634;0.4128;100];
    %lastCas = [0.3127;0.3290;100];
    intTime = 10;
    newIntTime = 80;
    cas = [];
    intTimeCol = [];
    for i = 1:num

        disp(cat(2, 'Iteration: ', num2str(i)));
        disp(cat(2, '    Getting cas measurement with int time : ', num2str(intTime))); 
        [st casLocal counts] = getCASxyY(pythonPath, intTime); 
        disp(casLocal); 
        intTimeCol = cat(1, intTimeCol, intTime);
        cas = cat(2, cas, [casLocal; counts]); 
        if counts == -1
          break
        end
        scatter(intTime, counts, 'r'); 
%         scatter(intTime, casLocal(2), 'b'); 
%         scatter(intTime, casLocal(3)/2000, 'g'); 
        hold on; 
%         disp('    Driving display to cas measurement'); 
%         setHarmonyRec(channel, cas, 1); 
%         disp(cat(2, '    Getting cas measurement with int time : ', num2str(newIntTime))); 
%         [st cas] = getCASxyY(pythonPath, newIntTime); 
%         disp(cas); 
%         
%         disp('    Driving display to cas measurement'); 
%         setHarmonyRec(channel, cas, 1); 
        
%         disp('    Delta in measurement: ')
%         disp(casLocal-lastCas); 
%         pause(2);
%         lastCas = cas;
        intTime = intTime + 4; 
        
    end 
    csvwrite(filename, cat(2, intTimeCol,cas'));
    %sshfrommatlabclose(channel); 
    toc
end 

