//
//  main.m
//  fixturectl
//
//  Created by Pete Richardson on 11/25/15.
//  Copyright © 2015 Pete Richardson. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "functions.h"

#define LArray1Axis     0
#define Iris1Axis       1
#define LArray2Axis     2
#define Iris2Axis       3
#define DUTAxis         4


int connectToController(NSString *ip_Addr) {
    char addr[16] = {0};
    NSString *dataGBK = [ip_Addr stringByRemovingPercentEncoding];
    memcpy(addr, [dataGBK cStringUsingEncoding:NSASCIIStringEncoding], [dataGBK length]);
    
    NSLog(@"connecting to addr: %@", ip_Addr);
    int ret =  connectController(addr);
    return ret;
}

int main(int argc, const char * argv[]) {
    int ret = 0;
    double timeoutTime = 60;
   @autoreleasepool {
       NSArray *arguments = [[NSProcessInfo processInfo] arguments];
              
       NSUInteger argc = [arguments count];
       if (argc < 2) {
           printf("usage: fixturectl <command>\n");
           printf("where <command> is one of:\n");
           printf("\tlight11            - move light 1 of light array 1 over the aperture\n");
           printf("\tlight12            - move light 2 of light array 1 over the aperture\n");
           printf("\tlight13            - move light 3 of light array 1 over the aperture\n");
           printf("\tlight21            - move light 1 of light array 2 over the aperture\n");
           printf("\tlight22            - move light 2 of light array 2 over the aperture\n");
           printf("\tlight23            - move light 3 of light array 2 over the aperture\n");
           printf("\thomelightarray1    - (same as light 11.  home position = light 1 position)\n");
           printf("\thomelightarray2    - (same as light 21.  home position = light 1 position)\n");
           printf("\thomeDUT            - move DUT to home position.  (not necessarily the same as position 1)\n");
           printf("\thomeiris1          - move iris 1 to fully open.  (light array 1.  100%% open)\n");
           printf("\thomeiris2          - move iris 1 to fully open.  (light array 2.  100%% open)\n");
           printf("\tmoveDUT1           - move DUT to position 1 (for lux reading)\n");
           printf("\tmoveDUT2           - move DUT to position 2 (for spectralon reading)\n");
           printf("\tmoveDUT3           - move DUT to position 3 (for display reading)\n");
           printf("\tshutter1open       - open shutter 1 (light array 1)\n");
           printf("\tshutter1close      - close shutter 1 (light array 1)\n");
           printf("\tshutter2open       - open shutter 2 (light array 2)\n");
           printf("\tshutter2close      - close shutter 2 (light array 2)\n");
           printf("\tinitialize         - turn on all servos and home all the axes\n");//servos伺服系統
          return 1;
       }
       NSString *arg = [arguments objectAtIndex:1];
//       NSString *arg = @"initialize";
       void (^timeoutFunc)(void(^)(void), int, double) = ^void(void(^selectedCase)(void), int axis, double timeoutTime){
           NSDate *start = [NSDate date];
           selectedCase();
           int checkDone =  0;
           NSTimeInterval executionTime = fabs([start timeIntervalSinceNow]);
           
           while((checkDone != 1) && (executionTime < timeoutTime)) {
               checkDone = axisCheckDone(axis);
               executionTime = fabs([start timeIntervalSinceNow]);
           }
           
           if(checkDone != 1) {
               NSLog(@"\tFunction timed out after %g", timeoutTime);
           } else {
               NSLog(@"\tTask finished in %g s", executionTime);
           }
           return;
       };
       
       //void (^selectedCase)() 定義代碼塊
       //@{} 創建字典
       void (^selectedCase)() = @{
              @"light11" : ^{
                  timeoutFunc(^{ moveLight(1,1); }, LArray1Axis, timeoutTime);
              },
              @"light12" : ^{
                  timeoutFunc(^{ moveLight(1,2);}, LArray1Axis, timeoutTime);
              },
              @"light13" : ^{
                  timeoutFunc(^{ moveLight(1,3);}, LArray1Axis, timeoutTime);
              },
              @"light21" : ^{
                  timeoutFunc(^{ moveLight(2,1);}, LArray2Axis, timeoutTime);
              },
              @"light22" : ^{
                  timeoutFunc(^{ moveLight(2,2);}, LArray2Axis, timeoutTime);
              },
              @"light23" : ^{
                  timeoutFunc(^{ moveLight(2,3);}, LArray2Axis, timeoutTime);
              },
              @"homelightarray1" : ^{
                  timeoutFunc(^{ moveHome(LArray1Axis); }, LArray1Axis, timeoutTime);
              },
              @"homelightarray2" : ^{
                  timeoutFunc(^{ moveHome(LArray2Axis); }, LArray2Axis, timeoutTime);
              },
              @"homeDUT" : ^{
                  timeoutFunc(^{ moveHome(DUTAxis); }, DUTAxis, timeoutTime);
              },
              @"homeiris1" : ^{
                  timeoutFunc(^{ moveHome(Iris1Axis); }, Iris1Axis, timeoutTime);
              },
              @"homeiris2" : ^{
                  timeoutFunc(^{ moveHome(Iris2Axis); }, Iris2Axis, timeoutTime);
              },
              @"moveDUT1" : ^{
                  timeoutFunc(^{ moveDut(1); }, DUTAxis, timeoutTime);
              },
              @"moveDUT2" : ^{
                  timeoutFunc(^{ moveDut(2); }, DUTAxis, timeoutTime);
              },
              @"moveDUT3" : ^{
                  timeoutFunc(^{ moveDut(3); }, DUTAxis, timeoutTime);
              },
              @"shutter1open" : ^{
                  controlShutter(1,0);
              },
              @"shutter1close" : ^{
                  controlShutter(1,1);
              },
              @"shutter2open" : ^{
                  controlShutter(2,0);
              },
              @"shutter2close" : ^{
                  controlShutter(2,1);
              },
              @"pogopin1" : ^{
                  controlPogopin(1);
              },
              @"pogopin0" : ^{
                  controlPogopin(0);
              },
              @"adjustiris2" : ^{
                  if(argc == 3) {
                      float irisVal = [(NSNumber*)[arguments objectAtIndex:2] floatValue];
                      timeoutFunc(^{ moveIris(2, irisVal); }, Iris2Axis, timeoutTime);
                  } else {
                      NSLog(@"Specify a value between 0-100 to set the iris to");
                  }
              },
              @"adjustiris1" : ^{
                  if(argc == 3) {
                      float irisVal = [(NSNumber*)[arguments objectAtIndex:2] floatValue];
                      timeoutFunc(^{ moveIris(1, irisVal); }, Iris1Axis, timeoutTime);
                  } else {
                      NSLog(@"Specify a value between 0-100 to set the iris to");
                  }
              },
              @"checkdoorstate" : ^{
                  int state = doorState();
                  NSLog(@"Door State: %i", state);
              },
              @"initialize" : ^{
                  
                  NSDate *start = [NSDate date];
                  int checkDone =  0;
                  NSTimeInterval executionTime = fabs([start timeIntervalSinceNow]);
                  
                  smc_set_pulse_outmode(0, LArray1Axis, 2);
                  smc_set_pulse_outmode(0, LArray2Axis, 2);
                  smc_set_pulse_outmode(0, Iris1Axis, 2);
                  smc_set_pulse_outmode(0, Iris2Axis, 2);
                  smc_set_pulse_outmode(0, DUTAxis, 2);
                  
                  smc_set_equiv(0, LArray1Axis, 1000);
                  smc_set_equiv(0, LArray2Axis, 1000);
                  smc_set_equiv(0, Iris1Axis, 1667);
                  smc_set_equiv(0, Iris2Axis, 1667);
                  smc_set_equiv(0, DUTAxis, 1000);
                  
                  smc_set_el_mode(0, LArray1Axis, 1, 1, 0);
                  smc_set_el_mode(0, LArray2Axis, 1, 1, 0);
                  smc_set_el_mode(0, Iris1Axis, 1, 1, 0);
                  smc_set_el_mode(0, Iris2Axis, 1, 1, 0);
                  smc_set_el_mode(0, DUTAxis, 1, 1, 0);
                  
                  smc_set_home_pin_logic(0, LArray1Axis, 0, 0);
                  smc_set_home_pin_logic(0, LArray2Axis, 0, 0);
                  smc_set_home_pin_logic(0, Iris1Axis, 0, 0);
                  smc_set_home_pin_logic(0, Iris2Axis, 0, 0);
                  smc_set_home_pin_logic(0, DUTAxis, 0, 0);
                  
                  
                  servoOn(LArray1Axis);
                  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                      NSLog(@"new thread for Larray1");
                      moveHome(LArray1Axis);
                  });
                  servoOn(LArray2Axis);
                  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                      NSLog(@"new thread for Larray2");
                      moveHome(LArray2Axis);
                  });
                  servoOn(Iris1Axis);
                  moveHome(Iris1Axis);
                  servoOn(Iris2Axis);
                  moveHome(Iris2Axis);
                  servoOn(DUTAxis);
                  moveHome(DUTAxis);
                  controlShutter(1,1);
                  controlShutter(2,1);
                  
                  while((checkDone != 1) && (executionTime < timeoutTime)) {
                      checkDone = axisCheckDone(LArray1Axis) & axisCheckDone(LArray2Axis) & axisCheckDone(Iris1Axis) &  axisCheckDone(Iris2Axis) & axisCheckDone(DUTAxis);
                      executionTime = fabs([start timeIntervalSinceNow]);
                  }
                  if(checkDone != 1) {
                      NSLog(@"\tFunction timed out after %g", timeoutTime);
                  } else {
                      NSLog(@"\tTask finished in %g s", executionTime);
                  }
                  return;

              },

       }[arg];

       if (selectedCase == nil) {
           NSLog(@"Unknown command: %@", arg);
           return 1;
       }
       NSLog(@"Executing command: %@", arg);
       ret = connectToController(@"192.168.5.11");
       NSLog(@"Controller connection status %i", ret );
       if( ret == 0 ) {
           selectedCase(); //timeoutFunc((void (^)())selectedCase, timeoutTime);
       } else {
           NSLog(@"Could not connect to controller");
       }
       disconnectController();
    }
    return ret;
}
