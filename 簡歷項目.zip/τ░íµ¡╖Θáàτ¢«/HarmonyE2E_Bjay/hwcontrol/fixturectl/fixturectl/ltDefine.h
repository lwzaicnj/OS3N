//
//  ltDefine.h
//  innotest
//
//  Created by zhaoxq on 15-11-17.
//  Copyright (c) 2015年 jiangzhong. All rights reserved.
//

/*
Error code value:

    ERR_NOERR = 0,              //success
    ERR_UNKNOWN = 1,            //unknown error
    ERR_PARAERR = 2,            //parameter error
    ERR_TIMEOUT = 3,            //timeout error
    ERR_CONTROLLERBUSY = 4,     //controller is busy
    ERR_CONNECT_TOOMANY = 5,    //connect too many
    ERR_CONTILINE = 6,          //continuous interpolation error
    ERR_CANNOT_CONNECTETH = 8,  //can not connect
    ERR_HANDLEERR = 9,          //handle error
    ERR_SENDERR = 10,           //send error
    ERR_FIRMWAREERR = 12,       //firmware error
    ERR_FIRMWAR_MISMATCH = 14,  //firmware mismatch
    
    ERR_FIRMWARE_INVALID_PARA    = 20,  //firmware parameter error
    ERR_FIRMWARE_PARA_ERR    = 20,  //firmware parameter error
    ERR_FIRMWARE_STATE_ERR    = 22, //firmware state error
    ERR_FIRMWARE_LIB_STATE_ERR    = 22, //firmware state error
    ERR_FIRMWARE_CARD_NOT_SUPPORT    = 24,  //firmware not support
    ERR_PASSWORD_ERR = 25,                  //password error
    ERR_PASSWORD_TIMES_OUT = 26,            //number of error password typed
    //文件存取
    
    FileFileNameBUFFSMALL = 0x830,   //读取文件名缓冲区太小
    FileFileNameTOOLONG =  0x831,    //文件名太长
    FileFileNameErr = 0x832,         //文件名错误
    FileFILEOVERSIZE = 0x833,        //文件太长
    FileIDCHANGE = 0x834,            //文件ID改变
    FileDOWNBLOCKNUMERR = 0x835,     //下载文件块号错误
    FileDOWNSIZEMISMTACH = 0x836,    //文件大小不匹配
    FileUPBLOCKNUMERR = 0x837,       //下载文件块号错误
    FileFileNoExist = 0x838,		 //文件不存在
    
    ERR_LIST_NUM_ERR = 50,          //list number error
    ERR_LIST_NOT_OEPN = 51,         //list not open
    ERR_PARA_NOT_VALID = 52,		//parameter not valid
    ERR_LIST_HAS_OPEN = 53,         //list has been open
    ERR_MAIN_LIST_NOT_OPEN = 54,	//main list not initial
    ERR_AXIS_NUM_ERR	= 55,		//axis number error
    ERR_AXIS_MAP_ARRAY_ERR	= 56,	//axis map array error
    ERR_MAP_AXIS_ERR	= 57, 		//map axis error
    ERR_MAP_AXIS_BUSY  = 58, 		//map axis busy
    ERR_PARA_SET_FORBIT = 59,       //parameter set forbid
    ERR_FIFO_FULL	 = 60,          //FIFO full
    ERR_RADIUS_ERR	= 61,           //radius error
    ERR_MAINLIST_HAS_START = 62,	//main list has start
    ERR_ACC_TIME_ZERO = 63,         //accelerate or decelerate is zero
    ERR_MAINLIST_NOT_START = 64     //main list not start
*/

#ifndef innotest_ltDefine_h
#define innotest_ltDefine_h

//HE2E parameter define

#define HOMESTARTSPEED      0
#define HOMERUNSPEED        200
#define HOMETACC            0.1
#define HOMETDEC            0.1

#define RUNSPEEDX           400
#define RUNSPEEDY           400
#define RUNSPEEDZ           400
#define RUNSPEEDU           400
#define RUNSPEEDW           400

#define STARTSPEEDX         10
#define STARTSPEEDY         10
#define STARTSPEEDZ         10
#define STARTSPEEDU         10
#define STARTSPEEDW         10

#define TACCX               0.1
#define TACCY               0.1
#define TACCZ               0.1
#define TACCU               0.1
#define TACCW               0.1

#define TDECX               0.1
#define TDECY               0.1
#define TDECZ               0.1
#define TDECU               0.1
#define TDECW               0.1


#define LIGHT1_X            0
#define LIGHT2_X            140 //機台第一次移動的距離
#define LIGHT3_X            280 //第二次移動的距離
#define LIGHT1_Z            0
#define LIGHT2_Z            140
#define LIGHT3_Z            280

#define T10MA_DIST          197 //display 第一次移動距離
#define WHITE_REF_DIST      147 //display 第二次移動距離
#define SCREEN_DIST         9   //第三次移動， have the CAS140 measuring the center of the display

#define FULL_DIST_Y         130
#define FULL_DIST_U         130



#endif
