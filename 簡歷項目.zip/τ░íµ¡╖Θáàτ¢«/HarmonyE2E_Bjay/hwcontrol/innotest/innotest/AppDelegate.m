//
//  AppDelegate.m
//  innotest
//
//  Created by zhaoxq on 15-11-16.
//  Copyright (c) 2015年 jiangzhong. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

-(void)dealloc{

    [self stopPainting];
  
  //  smc_board_close(m_connect);
    
    //[super dealloc];
}
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    
}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender;
{
    return YES;
}
- (IBAction)m_downoffsetclick:(id)sender {
    
    int iret = 0;
    
    char pdata[4] = {0};
    m_OffsetPos[0] = [m_offsetX floatValue];
    memcpy((uint8*)pdata,(uint8*)&m_OffsetPos[0],  4);
    iret = smc_set_persistent_reg(m_connect, 0, 4, pdata);
    
    m_OffsetPos[2] = [m_offsetZ floatValue];
    memcpy((uint8*)pdata,(uint8*)&m_OffsetPos[2],  4);
    iret = smc_set_persistent_reg(m_connect, 8, 4, pdata);
    
}

- (IBAction)sevonClick0:(id)sender {
    
    int axis = 0;
    short real = smc_read_sevon_pin(0, axis);
    if (real==1) {
        smc_write_sevon_pin(0, axis, 0);
    }
    else if (real==0)
    {
        smc_write_sevon_pin(0, axis, 1);
    }
}

- (IBAction)sevonClick1:(id)sender {
    int axis = 1;
    short real = smc_read_sevon_pin(0, axis);
    if (real==1) {
        smc_write_sevon_pin(0, axis, 0);
    }
    else if (real==0)
    {
        smc_write_sevon_pin(0, axis, 1);
    }
}

- (IBAction)sevonClick2:(id)sender {
    int axis = 2;
    short real = smc_read_sevon_pin(0, axis);
    if (real==1) {
        smc_write_sevon_pin(0, axis, 0);
    }
    else if (real==0)
    {
        smc_write_sevon_pin(0, axis, 1);
    }
}

- (IBAction)sevonClick3:(id)sender {
    int axis = 3;
    short real = smc_read_sevon_pin(0, axis);
    if (real==1) {
        smc_write_sevon_pin(0, axis, 0);
    }
    else if (real==0)
    {
        smc_write_sevon_pin(0, axis, 1);
    }
}

- (IBAction)sevonClick4:(id)sender {
    int axis = 4;
    short real = smc_read_sevon_pin(0, axis);
    if (real==1) {
        smc_write_sevon_pin(0, axis, 0);
    }
    else if (real==0)
    {
        smc_write_sevon_pin(0, axis, 1);
    }
}

- (IBAction)homeallClick:(id)sender {
    
    
    int i = 0;
   
   for( i = 0;i<5;i++ )
    {
      [self moveHome:i];
       // moveHome(i);
    }
    int stopsign = 1;
    //all stop
    while(true)
    {
        for(i = 0;i<5;i++)
        {
            stopsign = smc_check_done(0, i);
           
            if(stopsign ==0 )//如果有一个轴未停，则退出循环
            {
                break;
            }
        }
        if(stopsign == 1)//当所有轴都停止时退出
        {
            break;
        }
    }
    
    // move bias position  m_OffsetPos[0]
    if(m_OffsetPos[0]>0 && m_OffsetPos[0]<100)
    {
        while(true)
        {
            if(smc_check_done(0, 0)==1)
            {
                break;
            }
        }
        smc_pmove_unit(0, 0, m_OffsetPos[0], 0);//设置修正值
    }
    if(m_OffsetPos[2]>0 && m_OffsetPos[2]<100)
    {
        while(true)
        {
            if(smc_check_done(0, 2)==1)
            {
                break;
            }
        }
        smc_pmove_unit(0, 0, m_OffsetPos[2], 0);//设置修正值
    }
    
    while(true)
    {
        if(smc_check_done(0, 0)==1)
        {
            break;
        }
       // sleep(1);
    }
    
    while(true)
    {
        if(smc_check_done(0, 2)==1)
        {
            break;
        }
        // sleep(1);
    }

    
    for(i = 0;i<5;i++)
    {
        smc_set_position_unit(0,i,0);
        smc_set_encoder_unit(0, i, 0);
    }
}

- (IBAction)m_connectclick:(id)sender {
    
    int ret = 0;
    int i;
    NSString * ip_Addr = [_m_ipaddr stringValue];
    m_connect = 0;
    char addr[16] = {0};
    NSString *dataGBK = [ip_Addr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    memcpy(addr, [dataGBK cStringUsingEncoding:NSASCIIStringEncoding], [dataGBK length]);
    
    ret =  connectController(addr);
    
    if (ret == 0)
    {
        [_m_connectBtn setEnabled:NO];
        [_m_disconnectBtn setEnabled:YES];
        
        for (i=0; i<6; i++) {
            char pdata[4] = {0};
            ret = smc_get_persistent_reg(m_connect, i*4, 4, pdata);
            if (ret == 0)memcpy((uint8*)&m_OffsetPos[i], (uint8*)pdata, 4);
        }
        
        [m_offsetX setFloatValue:m_OffsetPos[0]];
        [m_offsetZ setFloatValue:m_OffsetPos[2]];
    }
    
    [self startPainting];// 开始定时器
    
}

- (IBAction)m_disconnectClick:(id)sender {
    int iret = 0;
    
    iret = smc_board_close(m_connect );
    [self stopPainting];
    if(iret!=0)return ;
    m_connect = 0;
    
    [_m_connectBtn setEnabled:YES];
    [_m_disconnectBtn setEnabled:NO];
}


- (IBAction)m_homemoveXclick:(id)sender {
    int axis = 0;
    
    /*************回零 到位后 设置修正值 清零*************/
    moveHome(axis);
    
}

- (IBAction)m_pmoveXclick:(id)sender {
    int axis = 0;
    double startSpeed = [_m_startSpeedX doubleValue];
    double runSpeed = [_m_runSpeedX doubleValue];
    double tacc = [_m_taccX doubleValue];
    double tdec = [_m_tdecX doubleValue];
    double stopSpeed = [_m_startSpeedX doubleValue];
    double dist = [_m_distX doubleValue];
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    smc_pmove_unit(0, axis , dist, 0 );
}

- (IBAction)m_homemoveYclick:(id)sender {
    int axis = 1;
    
    moveHome(axis);
   
}

- (IBAction)m_pmoveYclick:(id)sender {
    int axis = 1;
    double startSpeed = [_m_startSpeedY doubleValue];
    double runSpeed = [_m_runSpeedY doubleValue];
    double tacc = [_m_taccY doubleValue];
    double tdec = [_m_tdecY doubleValue];
    double stopSpeed = [_m_startSpeedY doubleValue];
    double dist = [_m_distY doubleValue];
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    smc_pmove_unit(0, axis , dist, 0 );
}

- (IBAction)m_homemoveZclick:(id)sender {
    int axis = 2;
        /*********************************/
    moveHome(axis);
    
   }

- (IBAction)m_pmoveZclick:(id)sender {
    int axis = 2;
    double startSpeed = [_m_startSpeedZ doubleValue];
    double runSpeed = [_m_runSpeedZ doubleValue];
    double tacc = [_m_taccZ doubleValue];
    double tdec = [_m_tdecZ doubleValue];
    double stopSpeed = [_m_startSpeedZ doubleValue];
    double dist = [_m_distZ doubleValue];
    
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    smc_pmove_unit(0, axis , dist, 0);
}

- (IBAction)m_homemoveU:(id)sender {
    int axis = 3;
   
    moveHome(axis);
  
}

- (IBAction)m_pmoveUclick:(id)sender {
    int axis = 3;
    double startSpeed = [_m_startSpeedU doubleValue];
    double runSpeed = [_m_runSpeedU doubleValue];
    double tacc = [_m_taccU doubleValue];
    double tdec = [_m_tdecU doubleValue];
    double stopSpeed = [_m_startSpeedU doubleValue];
    double dist = [_m_distU doubleValue];
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    smc_pmove_unit(0, axis , dist, 0 );
    
    
}

- (IBAction)m_homemoveW:(id)sender {
    
    int axis = 4;
    
    moveHome(axis);
    
}

- (IBAction)m_pmoveWclick:(id)sender {
    int axis = 4;
    double startSpeed = [_m_startSpeedW doubleValue];
    double runSpeed = [_m_runSpeedW doubleValue];
    double tacc = [_m_taccW doubleValue];
    double tdec = [_m_tdecW doubleValue];
    double stopSpeed = [_m_startSpeedW doubleValue];
    double dist = [_m_distW doubleValue];
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    smc_pmove_unit(0, axis , dist, 0 );
}

- (IBAction)m_stopXclick:(id)sender {
    smc_stop(0, 0 , 0);
}

- (IBAction)m_stopYclick:(id)sender {
    smc_stop(0, 1 , 0);
}

- (IBAction)m_stopZclick:(id)sender {
    smc_stop(0, 2 , 0);
}

- (IBAction)m_stopUclick:(id)sender {
    smc_stop(0, 3 , 0);
}

- (IBAction)m_stopWclick:(id)sender {
    smc_stop(0, 4 , 0);
}





- (void)paint:(NSTimer *)paramTimer{
    
    [self readInput];// 读取输出口
    [self readOutput];// 读取输出口
    [self readSignal];// 读专用输出口
    [self ReadSpecialOutput];
 
    double pos[5] =  {0};
    double encode[5] = {1};
    for(int i = 0; i<5;i++)
    {
        smc_get_position_unit(0, i, &pos[i]);
        smc_get_encoder_unit(0, i, &encode[i]);
    }
    
    [_m_positionX setDoubleValue:pos[0]];
    [_m_positionY setDoubleValue:pos[1]];
    [_m_positionZ setDoubleValue:pos[2]];
    [_m_positionU setDoubleValue:pos[3]];
    [_m_positionW setDoubleValue:pos[4]];
    
    //测试
  /*  [_m_encodeX setDoubleValue:pos[0]];
    [_m_encodeY setDoubleValue:pos[1]];
    [_m_encodeZ setDoubleValue:pos[2]];
    [_m_encodeU setDoubleValue:pos[3]];
    [_m_encodeW setDoubleValue:pos[4]];*/
    
    [_m_encodeX setDoubleValue:encode[0]];
    [_m_encodeY setDoubleValue:encode[1]];
    [_m_encodeZ setDoubleValue:encode[2]];
    [_m_encodeU setDoubleValue:encode[3]];
    [_m_encodeW setDoubleValue:encode[4]];
}

// 开始定时器
- (void) startPainting{
    
    // 定义一个NSTimer
    self.paintingTimer = [NSTimer scheduledTimerWithTimeInterval:0.1                                                          target:self                                                       selector:@selector(paint:)  userInfo:nil                                                         repeats:YES];
}

// 停止定时器
- (void) stopPainting{
    if (self.paintingTimer != nil){
        // 定时器调用invalidate后，就会自动执行release方法。不需要在显示的调用release方法
        [self.paintingTimer invalidate];
    }
}

// 读取输入口
- (void) readInput{
    
    uint iostate;
    
    iostate = smc_read_inport(m_connect, 0);
    
    for(int i = 0; i < 24; i++)
    {
        
        if (i==0)
        {
            if(0 == (iostate & (1 << i)))   // low level input on
            {
                [_IN0 setImage:[NSImage imageNamed:@"led_up.png"]];
                
            }
            
            else                            // high level input off
            {
                [_IN0 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==1){
            if(0 == (iostate & (1 << i)))
            {
                [_IN1 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN1 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==2){
            if(0 == (iostate & (1 << i)))
            {
                [_IN2 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN2 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==3){
            if(0 == (iostate & (1 << i)))
            {
                [_IN3 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN3 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==4){
            if(0 == (iostate & (1 << i)))
            {
                [_IN4 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN4 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==5){
            if(0 == (iostate & (1 << i)))
            {
                [_IN5 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN5 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==6){
            if(0 == (iostate & (1 << i)))
            {
                [_IN6 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN6 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==7){
            if(0 == (iostate & (1 << i)))
            {
                [_IN7 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN7 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==8){
            if(0 == (iostate & (1 << i)))
            {
                [_IN8 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN8 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==9){
            if(0 == (iostate & (1 << i)))
            {
                [_IN9 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN9 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==10){
            if(0 ==(iostate & (1 << i)))
            {
                [_IN10 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN10 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==11){
            if(0 ==(iostate & (1 << i)))
            {
                [_IN11 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN11 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==12){
            if(0 == (iostate & (1 << i)))
            {
                [_IN12 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN12 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==13){
            if(0 == (iostate & (1 << i)))
            {
                [_IN13 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN13 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==14){
            if(0 == (iostate & (1 << i)))
            {
                [_IN14 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN14 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==15){
            if(0 == (iostate & (1 << i)))
            {
                [_IN15 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN15 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==16){
            if(0 == (iostate & (1 << i)))
            {
                [_IN16 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN16 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==17){
            if(0 == (iostate & (1 << i)))
            {
                [_IN17 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN17 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==18){
            if(0 == (iostate & (1 << i)))
            {
                [_IN18 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN18 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==19){
            if(0 == (iostate & (1 << i)))
            {
                [_IN19 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN19 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==20){
            if(0 == (iostate & (1 << i)))
            {
                [_IN20 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN20 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==21){
            if(0 == (iostate & (1 << i)))
            {
                [_IN21 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN21 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==22){
            if(0 == (iostate & (1 << i)))
            {
                [_IN22 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN22 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==23){
            if(0 == (iostate & (1 << i)))
            {
                [_IN23 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_IN23 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        
    }
    
}
- (void) readOutput{
    
    uint iostate = 0;
    
    iostate = smc_read_outport(m_connect, 0);
    
    for(int i = 0; i < 18; i++)
    {
        
        if (i==0)
        {
            
            if(0 == (iostate & (1 << i)))   // low level output on
            {
                [_OUT0 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else            //high level output off
            {
                [_OUT0 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
            
        }
        else if (i==1){
            
            if(0 == (iostate & (1 << i)))
            {
                [_OUT1 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT1 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==2){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT2 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT2 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==3){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT3 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT3 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==4){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT4 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT4 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==5){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT5 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT5 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==6){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT6 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT6 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==7){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT7 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT7 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==8){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT8 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT8 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==9){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT9 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT9 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==10){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT10 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT10 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==11){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT11 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT11 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==12){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT12 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT12 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==13){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT13 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT13 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==14){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT14 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT14 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==15){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT15 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT15 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==16){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT16 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT16 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
        else if (i==17){
            if(0 == (iostate & (1 << i)))
            {
                [_OUT17 setImage:[NSImage imageNamed:@"led_up.png"]];
            }
            else
            {
                [_OUT17 setImage:[NSImage imageNamed:@"led_invalid.png"]];
            }
        }
    }
    
}
- (IBAction)outbtn0:(id)sender {
    WORD ioNum=0;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn1:(id)sender {
    WORD ioNum=1;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn2:(id)sender {
    WORD ioNum=2;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn3:(id)sender {
    WORD ioNum=3;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn4:(id)sender {
    WORD ioNum=4;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn5:(id)sender {
    WORD ioNum=5;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn6:(id)sender {
    WORD ioNum=6;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn7:(id)sender {
    WORD ioNum=7;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn8:(id)sender {
    WORD ioNum=8;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn9:(id)sender {
    WORD ioNum=9;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn10:(id)sender {
    WORD ioNum=10;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn11:(id)sender {
    WORD ioNum=11;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn12:(id)sender {
    WORD ioNum=12;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn13:(id)sender {
    WORD ioNum=13;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn14:(id)sender {
    WORD ioNum=14;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn15:(id)sender {
    WORD ioNum=15;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn16:(id)sender {
    WORD ioNum=16;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

- (IBAction)outbtn17:(id)sender {
    WORD ioNum=17;
    UInt8 real;
    real = smc_read_outbit(m_connect, ioNum);
    if (real==1) {
        smc_write_outbit(m_connect, ioNum, 0);
    }
    else if (real==0)
    {
        smc_write_outbit(m_connect, ioNum, 1);
        
    }
}

// 读取输出口
- (void) ReadSpecialOutput{
    
    WORD axis = 0;
    short sevonstate = 0;
    short ercstate = 0;
    for(axis = 0; axis < 5; axis++)
    {
        sevonstate = smc_read_sevon_pin(0, axis);
        ercstate = smc_read_erc_pin(0, axis);
        switch(axis)
        {
            case 0:
                if(0 != sevonstate)     //servo off high level  grey
                {
                    [_SEVON0 setImage:[NSImage imageNamed:@"I_like_buttons_016_1.png"]];
                }
                else                    //servo on  low levle   green
                {
                    [_SEVON0 setImage:[NSImage imageNamed:@"I_like_buttons_016.png"]];
                }
               
                break;
            case 1:
                if(0 != sevonstate)
                {
                    [_SEVON1 setImage:[NSImage imageNamed:@"I_like_buttons_016_1.png"]];
                }
                else
                {
                    [_SEVON1 setImage:[NSImage imageNamed:@"I_like_buttons_016.png"]];
                }
               
                break;
            case 2:
                if(0 != sevonstate)
                {
                    [_SEVON2 setImage:[NSImage imageNamed:@"I_like_buttons_016_1.png"]];
                }
                else
                {
                    [_SEVON2 setImage:[NSImage imageNamed:@"I_like_buttons_016.png"]];
                }
                
                break;
            case 3:
                if(0 != sevonstate)
                {
                    [_SEVON3 setImage:[NSImage imageNamed:@"I_like_buttons_016_1.png"]];
                }
                else
                {
                    [_SEVON3 setImage:[NSImage imageNamed:@"I_like_buttons_016.png"]];
                }
               
                break;
            case 4:
                if(0 != sevonstate)
                {
                    [_SEVON4 setImage:[NSImage imageNamed:@"I_like_buttons_016_1.png"]];
                }
                else
                {
                    [_SEVON4 setImage:[NSImage imageNamed:@"I_like_buttons_016.png"]];
                }
               
                break;
           
        }
    }
}

// 读专用输出口
- (void) readSignal{
    DWORD dwRet;
    DWORD dwEnable;
    int bitno = 0;
    for(int i = 0; i < 6; i++)
    {
        dwRet = smc_axis_io_status(m_connect, i);
        dwEnable = smc_axis_io_enable_status(m_connect,i);
        if (i==0)
        {
            bitno = 0;
            if(0 == (dwEnable & (1 << bitno)))//未使能ALM  yellow
            {
                [_ALM0 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，ALM green
                {
                    [_ALM0 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else                            //Alarm on red
                {
                    [_ALM0 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 1;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL+
            {
                [_ELP0 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELP0 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELP0 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 2;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL-
            {
                [_ELN0 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELN0 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELN0 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 4;
            if(0 == (dwEnable & (1 << bitno)))//未使能ORG
            {
                [_ORG0 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ORG0 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ORG0 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            
        }
        if (i==1)
        {
            bitno = 0;
            if(0 == (dwEnable & (1 << bitno)))//未使能ALM
            {
                [_ALM1 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，ALM
                {
                    [_ALM1 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ALM1 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 1;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL+
            {
                [_ELP1 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELP1 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELP1 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 2;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL-
            {
                [_ELN1 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELN1 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELN1 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 4;
            if(0 == (dwEnable & (1 << bitno)))//未使能ORG
            {
                [_ORG1 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ORG1 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ORG1 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            
        }
        
        if (i==2)
        {
            bitno = 0;
            if(0 == (dwEnable & (1 << bitno)))//未使能ALM
            {
                [_ALM2 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，ALM
                {
                    [_ALM2 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ALM2 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 1;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL+
            {
                [_ELP2 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELP2 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELP2 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 2;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL-
            {
                [_ELN2 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELN2 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELN2 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 4;
            if(0 == (dwEnable & (1 << bitno)))//未使能ORG
            {
                [_ORG2 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ORG2 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ORG2 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            
        }
        
        if (i==3)
        {
            bitno = 0;
            if(0 == (dwEnable & (1 << bitno)))//未使能ALM
            {
                [_ALM3 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，ALM
                {
                    [_ALM3 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ALM3 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 1;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL+
            {
                [_ELP3 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELP3 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELP3 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 2;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL-
            {
                [_ELN3 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELN3 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELN3 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 4;
            if(0 == (dwEnable & (1 << bitno)))//未使能ORG
            {
                [_ORG3 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ORG3 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ORG3 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            
        }
        
        if (i==4)
        {
            bitno = 0;
            if(0 == (dwEnable & (1 << bitno)))//未使能ALM
            {
                [_ALM4 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，ALM
                {
                    [_ALM4 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ALM4 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 1;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL+
            {
                [_ELP4 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELP4 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELP4 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 2;
            if(0 == (dwEnable & (1 << bitno)))//未使能EL-
            {
                [_ELN4 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ELN4 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ELN4 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            bitno = 4;
            if(0 == (dwEnable & (1 << bitno)))//未使能ORG
            {
                [_ORG4 setImage:[NSImage imageNamed:@"led_alarm.png"]];
            }
            else
            {
                if(0 == (dwRet & (1 << bitno)))//正常，无效，
                {
                    [_ORG4 setImage:[NSImage imageNamed:@"led_up.png"]];
                }
                else
                {
                    [_ORG4 setImage:[NSImage imageNamed:@"led_down.png"]];
                }
            }
            
        }
        
        
    }

}


- (IBAction)m_array1_home_click:(id)sender {
    
    moveHome(0);
}

- (IBAction)m_array1_light1_click:(id)sender {
  
    moveLight(1,1);
}

- (IBAction)m_array1_light2_click:(id)sender {
 
    moveLight(1,2);
}

- (IBAction)m_array1_light3_click:(id)sender {
   
    moveLight(1,3);
}

- (IBAction)m_array1_move_click:(id)sender {
    float percent = [_m_array1_percent floatValue];
   
    moveIris(1, percent);
    
}

- (IBAction)m_array1_on_click:(id)sender {
    
  //servoOn(4);
    controlShutter(1,1);
}

- (IBAction)m_array1_off_click:(id)sender {
    
   //servoOff(4);
    controlShutter(1,0);
}

- (IBAction)m_array2_home_click:(id)sender {
  
    moveHome(2);
}

- (IBAction)m_array2_light1_clikc:(id)sender {
   
    moveLight(2,1);
}

- (IBAction)m_array2_light2_click:(id)sender {
   
    moveLight(2,2);
}

- (IBAction)m_array2_light3_click:(id)sender {
    
    moveLight(2,3);
}

- (IBAction)m_array2_move_click:(id)sender {
    float percent = [_m_array2_percent floatValue];
   
    moveIris(2, percent);
}

- (IBAction)m_array2_on_click:(id)sender {
    
    controlShutter(2,1);
}

- (IBAction)m_array2_off_click:(id)sender {
   
      controlShutter(2,0);
}

- (IBAction)m_dut_home_click:(id)sender {
   
    moveDut(0);
}

- (IBAction)m_dut_t10ma_click:(id)sender {
   
    moveDut(1);
}

- (IBAction)m_dut_white_ref_click:(id)sender {
   
     moveDut(2);
}

- (IBAction)m_dut_screen_click:(id)sender {
   
     moveDut(3);
}

- (IBAction)m_dut_on_click:(id)sender {
     controlPogopin(1);
}

- (IBAction)m_dut_off_click:(id)sender {
     controlPogopin(0);
}


- (int)connectController: (char*) ipaddr
{
    int ret = 0;
    
    ret = smc_board_init(0, 2, ipaddr, 0);
    
    return ret;
}

- (int)moveHome: (int) axis
{
    int ret = 0;
    double startSpeed = [_m_startSpeedX doubleValue];
    double runSpeed = [_m_runSpeedX doubleValue];
    double tacc = [_m_taccX doubleValue];
    double tdec = [_m_tdecX doubleValue];
    double stopSpeed = [_m_startSpeedX doubleValue];
   
    
    switch (axis)
    {
        case 0:
            startSpeed = [_m_startSpeedX doubleValue];
            runSpeed = [_m_homespeedX doubleValue];
            tacc = [_m_taccX doubleValue];
            tdec = [_m_tdecX doubleValue];
            stopSpeed = [_m_startSpeedX doubleValue];
            
            break;
        case 1:
            startSpeed = [_m_startSpeedY doubleValue];
            runSpeed = [_m_homespeedY doubleValue];
            tacc = [_m_taccY doubleValue];
            tdec = [_m_tdecY doubleValue];
            stopSpeed = [_m_startSpeedY doubleValue];
          
            break;
        case 2:
            startSpeed = [_m_startSpeedZ doubleValue];
            runSpeed = [_m_homespeedZ doubleValue];
            tacc = [_m_taccZ doubleValue];
            tdec = [_m_tdecZ doubleValue];
            stopSpeed = [_m_startSpeedZ doubleValue];
            
            break;
        case 3:
            startSpeed = [_m_startSpeedU doubleValue];
            runSpeed = [_m_homespeedU doubleValue];
            tacc = [_m_taccU doubleValue];
            tdec = [_m_tdecU doubleValue];
            stopSpeed = [_m_startSpeedU doubleValue];
         
            break;
        case 4:
            startSpeed = [_m_startSpeedW doubleValue];
            runSpeed = [_m_homespeedW doubleValue];
            tacc = [_m_taccW doubleValue];
            tdec = [_m_tdecW doubleValue];
            stopSpeed = [_m_startSpeedW doubleValue];
            
            break;
        default:
            startSpeed = [_m_startSpeedX doubleValue];
            runSpeed = [_m_homespeedX doubleValue];
            tacc = [_m_taccX doubleValue];
            tdec = [_m_tdecX doubleValue];
            stopSpeed = [_m_startSpeedX doubleValue];
           
            break;
    }
 
     ret = smc_set_home_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec);
    
     ret = smc_set_homemode(0, axis, 0, 1, 2, 0);
    
     ret = smc_home_move(0,axis);
    
    return ret;
}

- (int)moveLight: (int) lightarray :(int) whichlight
{
    int ret = 0;
    int axis = 0;
    double dist = 0;
    
    double startSpeed = 0;
    double runSpeed = 0;
    double tacc = 0;
    double tdec = 0;
    double stopSpeed = 0;
    
    if(lightarray !=1&&lightarray !=2)
    {
        return 2;
    }
    
    if(lightarray ==1)//axis x
    {
        axis = 0;
        startSpeed = [_m_startSpeedX doubleValue];
        runSpeed = [_m_runSpeedX doubleValue];
        tacc = [_m_taccX doubleValue];
        tdec = [_m_tdecX doubleValue];
        stopSpeed = [_m_startSpeedX doubleValue];
        
        switch (whichlight)
        {
            case 1: dist = [_m_light1X doubleValue];
                break;
            case 2: dist = [_m_light2X doubleValue];
                break;
            case 3: dist = [_m_light3X doubleValue];
                break;
            default:dist = [_m_light3X doubleValue];
                break;
        }
        
    }
    if(lightarray ==2)//axis y
    {
        axis = 2;
        startSpeed = [_m_startSpeedZ doubleValue];
        runSpeed = [_m_runSpeedZ doubleValue];
        tacc = [_m_taccZ doubleValue];
        tdec = [_m_tdecZ doubleValue];
        stopSpeed = [_m_startSpeedZ doubleValue];
        switch (whichlight)
        {
            case 1: dist = [_m_light1Z doubleValue];
                break;
            case 2: dist = [_m_light2Z doubleValue];
                break;
            case 3: dist = [_m_light3Z doubleValue];
                break;
            default:dist = [_m_light3Z doubleValue];
                break;
        }
        
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    smc_pmove_unit(0, axis , dist, 1 );
    
    return ret;
    
}

- (int)moveIris: (int)lightarray :(float) percentage
{
    int ret = 0;
    int axis = 0;
    double dist = 0;
    
    double startSpeed = 0;
    double runSpeed = 0;
    double tacc = 0;
    double tdec = 0;
    double stopSpeed = 0;
    
    if(lightarray !=1&&lightarray !=2)
    {
        return 2;
    }
    
    if(lightarray ==1)//axis x
    {
        axis = 1;
        startSpeed = [_m_startSpeedY doubleValue];
        runSpeed = [_m_runSpeedY doubleValue];
        tacc = [_m_taccY doubleValue];
        tdec = [_m_tdecY doubleValue];
        stopSpeed = [_m_startSpeedY doubleValue];
        dist = [_m_fullDistY doubleValue]*percentage/100;
        
    }
    if(lightarray ==2)//axis y
    {
        axis = 3;
        
        startSpeed = [_m_startSpeedU doubleValue];
        runSpeed = [_m_runSpeedU doubleValue];
        tacc = [_m_taccU doubleValue];
        tdec = [_m_tdecU doubleValue];
        stopSpeed = [_m_startSpeedU doubleValue];
        
        dist = [_m_fullDistU doubleValue]*percentage/100;
        
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    smc_pmove_unit(0, axis , dist, 1 );
    return ret;
}

- (int)controlShutter: (int)lightarray :(int) state
{
    int ret = 0;
    if(state==0)
    {
        state = 1;
    }
    else
    {
        state = 0;
    }
    smc_write_outbit(0, lightarray, state);
    return ret;
}
- (int)moveDut: (int) pos
{
    int ret = 0;
    int axis = 4;
    double dist = 0;
    
    double startSpeed = [_m_startSpeedW doubleValue];
    double runSpeed = [_m_runSpeedW doubleValue];
    double tacc = [_m_taccW doubleValue];
    double tdec = [_m_tdecW doubleValue];
    double stopSpeed = [_m_startSpeedW doubleValue];
    
    switch (pos)
    {
        case 0: dist = 0;
            break;
        case 1:
            //dist = [_m_T10MA_dis doubleValue];
            dist = T10MA_DIST;
            break;
        case 2: dist = [_m_white_ref_dis doubleValue];
            break;
        case 3: dist = [_m_screen_dis doubleValue];
            break;
        default:dist = 0;
            break;
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    smc_pmove_unit(0, axis , dist, 1 );
    
    return ret;
}

- (int)doorState
{
    int state = 0;
    state = smc_read_inbit(0, 1);
    if(state)
        state = 0;
    else state = 1;
    return state;
}

- (int)controlOutput:(int)outputnum :(int)state
{
    int ret = 0;
    if(state==0)
    {
        state = 1;
    }
    else
    {
        state = 0;
    }
    smc_write_outbit(0, outputnum, state);
    return ret;
}
@end
