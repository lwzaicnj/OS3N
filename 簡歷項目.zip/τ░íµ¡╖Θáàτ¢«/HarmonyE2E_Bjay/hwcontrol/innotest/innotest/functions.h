//
//  functions.h
//  innotest
//
//  Created by zhaoxq on 15-11-17.
//  Copyright (c) 2015年 jiangzhong. All rights reserved.
//

#ifndef innotest_functions_h
#define innotest_functions_h

#include "LTSMC.h"
#include "ltDefine.h"

/*****************************************************
 Connect Macmini to SMC606 controller through ethernet
 ipaddr:address of controller,default value 192.168.5.11
 return value: error code value    0 - success
******************************************************/
int connectController(char* ipaddr)
{
    int ret = 0;
    
    ret = smc_board_init(0, 2, ipaddr, 0);
    
    return ret;
}


int disconnectController()
{
    int ret = 0;
    
    ret = smc_board_close(0);
    return ret;
}


/*****************************************************
 Enable the specific servo motor axis
 axis: 0~4
 return value: error code value    0 - success
 ******************************************************/
int servoOn(int axis)
{
    int ret = 0;
    ret = smc_write_sevon_pin(0, axis, 0);// 低电平有效
    return ret;
}


/*****************************************************
 Disable the specific servo motor axis
 axis: 0~4
 return value: error code value    0 - success
 ******************************************************/
int servoOff(int axis)
{
    int ret = 0;
    ret = smc_write_sevon_pin(0, axis, 1);
    return ret;
}


/*****************************************************
 Check the specific axis move finish or not
 axis: 0~4
 return value: 0 - axis is moving    1 - axis is stop
 ******************************************************/
int axisCheckDone(int axis)
{
    int ret = 0;
    ret = smc_check_done(0, axis);
    return ret;
}


/*****************************************************
 Move the specific axis to home
 axis: 0~4
 return value: error code value    0 - success
 ******************************************************/
int moveHome(int axis)
{
    int ret = 0;
    double startSpeed = HOMESTARTSPEED;
    double runSpeed = HOMERUNSPEED;
    double tacc = HOMETACC;
    double tdec = HOMETDEC;
    //double stopSpeed = 0;
    double dist = 0;
    char pdata[4] = {0};
    float fdist = 0;

    switch (axis)
    {
        case 0:
            
            //读偏移值x
            ret = smc_get_persistent_reg(0, axis*4, 4, pdata);
            if (ret == 0)memcpy((uint8*)&fdist, (uint8*)pdata, 4);
            dist =fdist;
            break;
        case 2:
            
             //读偏移值z
            ret = smc_get_persistent_reg(0, axis*4, 4, pdata);
            if (ret == 0)memcpy((uint8*)&fdist, (uint8*)pdata, 4);
            dist =fdist;
            break;
        
        default:
            
            break;
    }
    
    ret = smc_set_home_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec);
    
    ret = smc_set_homemode(0, axis, 0, 1, 2, 0);
    
    ret = smc_home_move(0,axis);
    
    //如果有偏移则加入下面一步
    if(dist>0 && dist<100)
    {
        while(true)
        {
            if(smc_check_done(0, axis)==1)
            {
                break;
            }
        }
        
         smc_pmove_unit(0, axis, dist, 0);//设置修正值
    }
    
    
    while(true)
    {
        if(smc_check_done(0, axis)==1)
        {
            break;
        }
        sleep(1);
    }
    //位置清零
    
    smc_set_position_unit(0, axis, 0);
    ret = smc_set_encoder_unit(0, axis, 0);
    return ret;
}


/*****************************************************
 Move light to specific position
 lightarray:1 - lightarray1 ; 2 - lightarray2
 whichlight:1 - light1 ; 2 - light2 ;  3 - light3
 return value: error code value    0 - success
 ******************************************************/
int moveLight(int lightarray, int whichlight)
{
    int ret = 0;
    int axis = 0;
    double dist = 0;
    
    double startSpeed = 0;
    double runSpeed = 0;
    double tacc = 0;
    double tdec = 0;
    double stopSpeed = 0;
    
    if(lightarray !=1&&lightarray !=2)
    {
        return 2;
    }
    
    if(lightarray ==1)//axis x
    {
        axis = 0;
        startSpeed = STARTSPEEDX;
        runSpeed = RUNSPEEDX;
        tacc = TACCX;
        tdec = TDECX;
        stopSpeed = STARTSPEEDX;
        
        switch (whichlight)
        {
            case 1: dist = LIGHT1_X;
                break;
            case 2: dist = LIGHT2_X;
                break;
            case 3: dist = LIGHT3_X;
                break;
            default:dist = LIGHT1_X;
                break;
        }
        
    }
    if(lightarray ==2)//axis z
    {
        axis = 2;
        startSpeed = STARTSPEEDZ;
        runSpeed = RUNSPEEDZ;
        tacc = TACCZ;
        tdec = TDECZ;
        stopSpeed = STARTSPEEDZ;
        switch (whichlight)
        {
            case 1: dist = LIGHT1_Z;
                break;
            case 2: dist = LIGHT2_Z;
                break;
            case 3: dist = LIGHT3_Z;
                break;
            default:dist = LIGHT1_Z;
                break;
        }
        
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    
    ret = smc_pmove_unit(0, axis , dist, 1 );
    
    return ret;
    
}



/*****************************************************
 Move iris between close and full open
 lightarray:1 - lightarray1 ; 2 - lightarray2
 percentage:0~100
 return value: error code value    0 - success
 ******************************************************/
int moveIris(int lightarray, float percentage)
{
    int ret = 0;
    int axis = 0;
    double dist = 0;
    
    double startSpeed = 0;
    double runSpeed = 0;
    double tacc = 0;
    double tdec = 0;
    double stopSpeed = 0;
    
    if(lightarray !=1&&lightarray !=2)
    {
        return 2;
    }
    
    if(percentage>100)
    {
        percentage = 100;
    }
    
    if(percentage<0)
    {
        percentage = 0;
    }
    
    if(lightarray ==1)//axis Y
    {
        axis = 1;
        startSpeed = STARTSPEEDY;
        runSpeed = RUNSPEEDY;
        tacc = TACCY;
        tdec = TDECY;
        stopSpeed = STARTSPEEDY;
        dist = FULL_DIST_Y*(100-percentage)/100;
        
    }
    if(lightarray ==2)//axis U
    {
        axis = 3;
        
        startSpeed = STARTSPEEDU;
        runSpeed = RUNSPEEDU;
        tacc = TACCU;
        tdec = TDECU;
        stopSpeed = STARTSPEEDU;
        
        dist = FULL_DIST_U*(100-percentage)/100;
        
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    ret = smc_pmove_unit(0, axis , dist, 1 );
    return ret;
}



/*****************************************************
 Move shutter close or open
 lightarray:1 - lightarray1 ; 2 - lightarray2
 state: 0 - close aperture hole; 1 - open aperture hole
 return value: error code value    0 - success
 ******************************************************/
int controlShutter(int lightarray,int state)
{
    int ret = 0;
    if(state==0)
    {
        state = 1;
    }
    else
    {
        state = 0;
    }
    ret = smc_write_outbit(0, lightarray, state);
    return ret;
}


/*****************************************************
 Move pogopin connect or disconnect
 state: 0 - disconnect pogopin; 1 - connect pogopin
 return value: error code value    0 - success
 ******************************************************/
int controlPogopin(int state)
{
    int ret = 0;
    if(state==0)
    {
        state = 1;
    }
    else
    {
        state = 0;
    }
    ret = smc_write_outbit(0, 3, state);
    return ret;
}


/*****************************************************
 Move DUT to specific position
 pos: 0 - home ; 1 - T10MA ; 2 - white ref ;  3 - screen
 return value: error code value    0 - success
 ******************************************************/
int moveDut(int pos)
{
    int ret = 0;
    int axis = 4;
    double dist = 0;
    
    double startSpeed = 0;
    double runSpeed = 0;
    double tacc = 0;
    double tdec = 0;
    double stopSpeed = 0;
    
    startSpeed = STARTSPEEDW;
    runSpeed = RUNSPEEDW;
    tacc = TACCW;
    tdec = TDECW;
    stopSpeed = STARTSPEEDW;
    
    switch (pos)
    {
        case 0: dist = 0;
            break;
        case 1:
            dist = T10MA_DIST;
            break;
        case 2: dist = WHITE_REF_DIST;
            break;
        case 3: dist = SCREEN_DIST;
            break;
        default:dist = 0;
            break;
    }
    
    smc_set_profile_unit(0, axis, startSpeed, runSpeed, tacc, tdec, stopSpeed);
    ret = smc_pmove_unit(0, axis , dist, 1 );
    
    return ret;
}


/*****************************************************
 detect door close or not
 return value: 1 - door close ; 0 - door open
 ******************************************************/
int doorState()
{
    int state = 0;
    state = smc_read_inbit(0, 1);
    if(state)
        state = 0;
    else state = 1;
    return state;
}



/*****************************************************
 control general purpose output
 outputnum: 0 -17
 state: 0 - output off; 1 - output on
 return value: error code value    0 - success
 ******************************************************/
int controlOutput(int outputnum,int state)
{
    int ret = 0;
    if(state==0)
    {
        state = 1;
    }
    else
    {
        state = 0;
    }
    ret = smc_write_outbit(0, outputnum, state);
    return ret;
}

#endif

