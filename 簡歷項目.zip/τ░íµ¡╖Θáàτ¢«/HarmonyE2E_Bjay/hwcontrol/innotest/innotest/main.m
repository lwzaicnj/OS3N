//
//  main.m
//  innotest
//
//  Created by zhaoxq on 15-11-16.
//  Copyright (c) 2015年 jiangzhong. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
