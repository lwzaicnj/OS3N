//
//  AppDelegate.h
//  innotest
//
//  Created by zhaoxq on 15-11-16.
//  Copyright (c) 2015年 jiangzhong. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "LTSMC.h"
#import "functions.h"
#import "ltDefine.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    WORD m_connect;
    float m_OffsetPos[6];
    NSTextField *_m_ipaddr;
    
    NSButton *_m_disconnectBtn;
    NSButton *_m_connectBtn;
    NSButton *_m_homeallBtn;
    
    
    NSButton *_m_array1_home;
    NSButton *_m_array1_light1;
    NSButton *_m_array1_light2;
    NSButton *_m_array1_light3;

    NSButton *_m_array1_stopX;
  
    NSTextField *_m_array1_percent;
   
    NSButton *_m_array1_move;
    NSButton *_m_array1_stopY;
    NSButton *_m_array1_on;
    NSButton *_m_array1_off;
    
    NSButton *_m_array2_home;
    NSButton *_m_array2_light1;
    NSButton *_m_array2_light2;
    NSButton *_m_array2_light3;
    NSButton *_m_array2_stopZ;
   
    NSTextField *_m_array2_percent;
    NSButton *_m_array2_move;
    NSButton *_m_array2_stopU;
    NSButton *_m_array2_on;
    NSButton *_m_array2_off;
    
    NSButton *_m_dut_home;
    NSButton *_m_dut_t10ma;
    NSButton *_m_dut_white_ref;
    NSButton *_m_dut_sceen;
    NSButton *_m_dut_stopW;
    
    IBOutlet NSButton *m_dut_on;
    IBOutlet NSButton *m_dut_off;
    NSButton *_m_homeMoveX;
    NSTextField *_m_distX;
    NSButton *_m_pmoveX;
    NSButton *_m_homeMoveY;
    NSTextField *_m_positionX;
    NSTextField *_m_distY;
    NSButton *_m_pmoveY;
    NSTextField *_m_positionY;
    NSButton *_m_homemoveZ;
    NSTextField *_m_distZ;
    NSButton *_m_pmoveZ;
    NSTextField *_m_positionZ;
    NSButton *_m_homemoveU;
    NSTextField *_m_distU;
    NSButton *_m_pmoveU;
    NSTextField *_m_positionU;
    NSButton *_m_homemoveW;
    NSTextField *_m_distW;
    NSButton *_m_pmoveW;
    NSTextField *_m_positionW;
    NSButton *_m_stopX;
    NSButton *_m_stopY;
    NSButton *_m_stopZ;
    NSButton *_m_stopU;
    NSButton *_m_stopW;
    
    NSTextField *_m_startSpeedX;
    NSTextField *_m_startSpeedY;
    NSTextField *_m_startSpeedZ;
    NSTextField *_m_startSpeedU;
    NSTextField *_m_startSpeedW;
    
    
    NSTextField *_m_runSpeedX;
    NSTextField *_m_runSpeedY;
    NSTextField *_m_runSpeedZ;
    NSTextField *_m_runSpeedU;
    NSTextField *_m_runSpeedW;
    
    NSTextField *_m_taccX;
    NSTextField *_m_taccY;
    NSTextField *_m_taccZ;
    NSTextField *_m_taccU;
    NSTextField *_m_taccW;
    
    NSTextField *_m_tdecX;
    NSTextField *_m_tdecY;
    NSTextField *_m_tdecZ;
    NSTextField *_m_tdecU;
    NSTextField *_m_tdecW;
    NSTextField *_m_encodeX;
    NSTextField *_m_encodeY;
    NSTextField *_m_encodeZ;
    NSTextField *_m_encodeU;
    NSTextField *_m_encodeW;
    

    NSImageView *_IN0;
    NSImageView *_IN1;
    NSImageView *_IN2;
    NSImageView *_IN3;
    NSImageView *_IN4;
    NSImageView *_IN5;
    NSImageView *_IN6;
    NSImageView *_IN7;
    NSImageView *_IN8;
    NSImageView *_IN9;
    NSImageView *_IN10;
    NSImageView *_IN11;
    NSImageView *_IN12;
    NSImageView *_IN13;
    NSImageView *_IN14;
    NSImageView *_IN15;
    NSImageView *_IN16;
    NSImageView *_IN17;
    NSImageView *_IN18;
    NSImageView *_IN19;
    NSImageView *_IN20;
    NSImageView *_IN21;
    NSImageView *_IN22;
    NSImageView *_IN23;
    NSButton *_OUT0;
    NSButton *_OUT1;
    NSButton *_OUT2;
    NSButton *_OUT3;
    NSButton *_OUT4;
    NSButton *_OUT5;
    NSButton *_OUT6;
    NSButton *_OUT7;
    NSButton *_OUT8;
    NSButton *_OUT9;
    NSButton *_OUT10;
    NSButton *_OUT11;
    NSButton *_OUT12;
    NSButton *_OUT13;
    NSButton *_OUT14;
    NSButton *_OUT15;
    NSButton *_OUT16;
    NSButton *_OUT17;
    NSImageView *_ORG0;
    NSImageView *_ORG1;
    NSImageView *_ORG2;
    NSImageView *_ORG3;
    NSImageView *_ORG4;
    NSImageView *_ELP0;
    NSImageView *_ELP1;
    NSImageView *_ELP2;
    NSImageView *_ELP3;
    NSImageView *_ELP4;
    NSImageView *_ELN0;
    NSImageView *_ELN1;
    NSImageView *_ELN2;
    NSImageView *_ELN3;
    NSImageView *_ELN4;
    NSImageView *_ALM0;
    NSImageView *_ALM1;
    NSImageView *_ALM2;
    NSImageView *_ALM3;
    NSImageView *_ALM4;
    NSButton *_SEVON0;
    NSButton *_SEVON1;
    NSButton *_SEVON2;
    NSButton *_SEVON3;
    NSButton *_SEVON4;
    
    NSTextField *_m_light1X;
    NSTextField *_m_light2X;
    NSTextField *_m_light3X;
    
    NSTextField *_m_light1Z;
    NSTextField *_m_light2Z;
    NSTextField *_m_light3Z;
    
  
    NSTextField *_m_T10MA_dis;
    NSTextField *_m_white_ref_dis;
    NSTextField *_m_screen_dis;
    NSTextField *_m_fullDistY;
    NSTextField *_m_fullDistU;
    NSTextField *_m_homespeedX;
    NSTextField *_m_homespeedY;
    NSTextField *_m_homespeedZ;
    NSTextField *_m_homespeedU;
    NSTextField *_m_homespeedW;
    IBOutlet NSTextField *m_offsetX;
   
    IBOutlet NSTextField *m_offsetZ;
}

@property (nonatomic, strong) NSTimer *paintingTimer;
- (IBAction)m_downoffsetclick:(id)sender;

- (IBAction)sevonClick0:(id)sender;
- (IBAction)sevonClick1:(id)sender;
- (IBAction)sevonClick2:(id)sender;
- (IBAction)sevonClick3:(id)sender;
- (IBAction)sevonClick4:(id)sender;

- (IBAction)homeallClick:(id)sender;
- (IBAction)m_connectclick:(id)sender;
- (IBAction)m_disconnectClick:(id)sender;
- (IBAction)m_homemoveXclick:(id)sender;
- (IBAction)m_pmoveXclick:(id)sender;
- (IBAction)m_homemoveYclick:(id)sender;
- (IBAction)m_pmoveYclick:(id)sender;
- (IBAction)m_homemoveZclick:(id)sender;
- (IBAction)m_pmoveZclick:(id)sender;
- (IBAction)m_homemoveU:(id)sender;
- (IBAction)m_pmoveUclick:(id)sender;
- (IBAction)m_homemoveW:(id)sender;
- (IBAction)m_pmoveWclick:(id)sender;
- (IBAction)m_stopXclick:(id)sender;
- (IBAction)m_stopYclick:(id)sender;
- (IBAction)m_stopZclick:(id)sender;
- (IBAction)m_stopUclick:(id)sender;
- (IBAction)m_stopWclick:(id)sender;
- (IBAction)m_array1_home_click:(id)sender;
- (IBAction)m_array1_light1_click:(id)sender;
- (IBAction)m_array1_light2_click:(id)sender;
- (IBAction)m_array1_light3_click:(id)sender;
- (IBAction)m_array1_move_click:(id)sender;
- (IBAction)m_array1_on_click:(id)sender;
- (IBAction)m_array1_off_click:(id)sender;
- (IBAction)m_array2_home_click:(id)sender;
- (IBAction)m_array2_light1_clikc:(id)sender;
- (IBAction)m_array2_light2_click:(id)sender;
- (IBAction)m_array2_light3_click:(id)sender;
- (IBAction)m_array2_move_click:(id)sender;
- (IBAction)m_array2_on_click:(id)sender;
- (IBAction)m_array2_off_click:(id)sender;
- (IBAction)m_dut_home_click:(id)sender;
- (IBAction)m_dut_t10ma_click:(id)sender;
- (IBAction)m_dut_white_ref_click:(id)sender;
- (IBAction)m_dut_screen_click:(id)sender;
- (IBAction)m_dut_on_click:(id)sender;
- (IBAction)m_dut_off_click:(id)sender;
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender;
@property (assign) IBOutlet NSWindow *window;

@property (strong) IBOutlet NSTextField *m_ipaddr;
@property (strong) IBOutlet NSButton *m_homeallBtn;
@property (strong) IBOutlet NSButton *m_connectBtn;
@property (strong) IBOutlet NSButton *m_disconnectBtn;
@property (strong) IBOutlet NSButton *m_homeArray1;
@property (strong) IBOutlet NSButton *m_homeMoveX;
@property (strong) IBOutlet NSButton *m_pmoveX;


@property (strong) IBOutlet NSButton *m_homeMoveY;
@property (strong) IBOutlet NSTextField *m_distX;
@property (strong) IBOutlet NSTextField *m_positionX;
@property (strong) IBOutlet NSTextField *m_distY;
@property (strong) IBOutlet NSButton *m_pmoveY;
@property (strong) IBOutlet NSTextField *m_positionY;
@property (strong) IBOutlet NSButton *m_homemoveZ;
@property (strong) IBOutlet NSTextField *m_distZ;
@property (strong) IBOutlet NSButton *m_pmoveZ;
@property (strong) IBOutlet NSTextField *m_positionZ;
@property (strong) IBOutlet NSButton *m_homemoveU;
@property (strong) IBOutlet NSTextField *m_distU;
@property (strong) IBOutlet NSButton *m_pmoveU;
@property (strong) IBOutlet NSTextField *m_positionU;
@property (strong) IBOutlet NSButton *m_homemoveW;
@property (strong) IBOutlet NSTextField *m_distW;
@property (strong) IBOutlet NSButton *m_pmoveW;
@property (strong) IBOutlet NSTextField *m_positionW;
@property (strong) IBOutlet NSButton *m_stopX;
@property (strong) IBOutlet NSButton *m_stopY;
@property (strong) IBOutlet NSButton *m_stopZ;
@property (strong) IBOutlet NSButton *m_stopU;
@property (strong) IBOutlet NSButton *m_stopW;
@property (strong) IBOutlet NSTextField *m_startSpeedX;
@property (strong) IBOutlet NSTextField *m_startSpeedY;
@property (strong) IBOutlet NSTextField *m_startSpeedZ;
@property (strong) IBOutlet NSTextField *m_startSpeedU;
@property (strong) IBOutlet NSTextField *m_startSpeedW;
@property (strong) IBOutlet NSTextField *m_runSpeedX;
@property (strong) IBOutlet NSTextField *m_runSpeedY;
@property (strong) IBOutlet NSTextField *m_runSpeedZ;
@property (strong) IBOutlet NSTextField *m_runSpeedU;
@property (strong) IBOutlet NSTextField *m_runSpeedW;
@property (strong) IBOutlet NSTextField *m_taccX;
@property (strong) IBOutlet NSTextField *m_taccY;
@property (strong) IBOutlet NSTextField *m_taccZ;
@property (strong) IBOutlet NSTextField *m_taccU;
@property (strong) IBOutlet NSTextField *m_taccW;
@property (strong) IBOutlet NSTextField *m_tdecX;
@property (strong) IBOutlet NSTextField *m_tdecY;
@property (strong) IBOutlet NSTextField *m_tdecZ;
@property (strong) IBOutlet NSTextField *m_tdecU;
@property (strong) IBOutlet NSTextField *m_tdecW;
@property (strong) IBOutlet NSTextField *m_encodeX;
@property (strong) IBOutlet NSTextField *m_encodeY;
@property (strong) IBOutlet NSTextField *m_encodeZ;
@property (strong) IBOutlet NSTextField *m_encodeU;
@property (strong) IBOutlet NSTextField *m_encodeW;
@property (strong) IBOutlet NSImageView *IN0;
@property (strong) IBOutlet NSImageView *IN1;
@property (strong) IBOutlet NSImageView *IN2;
@property (strong) IBOutlet NSImageView *IN3;
@property (strong) IBOutlet NSImageView *IN4;
@property (strong) IBOutlet NSImageView *IN5;
@property (strong) IBOutlet NSImageView *IN6;
@property (strong) IBOutlet NSImageView *IN7;
@property (strong) IBOutlet NSImageView *IN8;
@property (strong) IBOutlet NSImageView *IN9;
@property (strong) IBOutlet NSImageView *IN10;
@property (strong) IBOutlet NSImageView *IN11;
@property (strong) IBOutlet NSImageView *IN12;
@property (strong) IBOutlet NSImageView *IN13;
@property (strong) IBOutlet NSImageView *IN14;
@property (strong) IBOutlet NSImageView *IN15;
@property (strong) IBOutlet NSImageView *IN16;
@property (strong) IBOutlet NSImageView *IN17;
@property (strong) IBOutlet NSImageView *IN18;
@property (strong) IBOutlet NSImageView *IN19;
@property (strong) IBOutlet NSImageView *IN20;
@property (strong) IBOutlet NSImageView *IN21;
@property (strong) IBOutlet NSImageView *IN22;
@property (strong) IBOutlet NSImageView *IN23;
@property (strong) IBOutlet NSButton *OUT0;
@property (strong) IBOutlet NSButton *OUT1;
@property (strong) IBOutlet NSButton *OUT2;
@property (strong) IBOutlet NSButton *OUT3;
@property (strong) IBOutlet NSButton *OUT4;
@property (strong) IBOutlet NSButton *OUT5;
@property (strong) IBOutlet NSButton *OUT6;
@property (strong) IBOutlet NSButton *OUT7;
@property (strong) IBOutlet NSButton *OUT8;
@property (strong) IBOutlet NSButton *OUT9;
@property (strong) IBOutlet NSButton *OUT10;
@property (strong) IBOutlet NSButton *OUT11;
@property (strong) IBOutlet NSButton *OUT12;
@property (strong) IBOutlet NSButton *OUT13;
@property (strong) IBOutlet NSButton *OUT14;
@property (strong) IBOutlet NSButton *OUT15;
@property (strong) IBOutlet NSButton *OUT16;
@property (strong) IBOutlet NSButton *OUT17;
- (IBAction)outbtn0:(id)sender;
- (IBAction)outbtn1:(id)sender;
- (IBAction)outbtn2:(id)sender;
- (IBAction)outbtn3:(id)sender;
- (IBAction)outbtn4:(id)sender;
- (IBAction)outbtn5:(id)sender;
- (IBAction)outbtn6:(id)sender;
- (IBAction)outbtn7:(id)sender;
- (IBAction)outbtn8:(id)sender;
- (IBAction)outbtn9:(id)sender;
- (IBAction)outbtn10:(id)sender;
- (IBAction)outbtn11:(id)sender;
- (IBAction)outbtn12:(id)sender;
- (IBAction)outbtn13:(id)sender;
- (IBAction)outbtn14:(id)sender;
- (IBAction)outbtn15:(id)sender;
- (IBAction)outbtn16:(id)sender;
- (IBAction)outbtn17:(id)sender;

@property (strong) IBOutlet NSImageView *ORG0;
@property (strong) IBOutlet NSImageView *ORG1;
@property (strong) IBOutlet NSImageView *ORG2;
@property (strong) IBOutlet NSImageView *ORG3;
@property (strong) IBOutlet NSImageView *ORG4;
@property (strong) IBOutlet NSImageView *ELP0;
@property (strong) IBOutlet NSImageView *ELP1;
@property (strong) IBOutlet NSImageView *ELP2;
@property (strong) IBOutlet NSImageView *ELP3;
@property (strong) IBOutlet NSImageView *ELP4;
@property (strong) IBOutlet NSImageView *ELN0;
@property (strong) IBOutlet NSImageView *ELN1;
@property (strong) IBOutlet NSImageView *ELN2;
@property (strong) IBOutlet NSImageView *ELN3;
@property (strong) IBOutlet NSImageView *ELN4;
@property (strong) IBOutlet NSImageView *ALM0;
@property (strong) IBOutlet NSImageView *ALM1;
@property (strong) IBOutlet NSImageView *ALM2;
@property (strong) IBOutlet NSImageView *ALM3;
@property (strong) IBOutlet NSImageView *ALM4;
@property (strong) IBOutlet NSButton *SEVON0;
@property (strong) IBOutlet NSButton *SEVON1;
@property (strong) IBOutlet NSButton *SEVON2;
@property (strong) IBOutlet NSButton *SEVON3;
@property (strong) IBOutlet NSButton *SEVON4;
@property (strong) IBOutlet NSButton *m_array1_light1;
@property (strong) IBOutlet NSButton *m_array1_home;
@property (strong) IBOutlet NSButton *m_array1_light2;
@property (strong) IBOutlet NSButton *m_array1_light3;


@property (strong) IBOutlet NSButton *m_array1_move;
@property (strong) IBOutlet NSButton *m_array1_stopY;
@property (strong) IBOutlet NSButton *m_array1_on;
@property (strong) IBOutlet NSButton *m_array1_off;
@property (strong) IBOutlet NSButton *m_array2_home;
@property (strong) IBOutlet NSButton *m_array2_light1;
@property (strong) IBOutlet NSButton *m_array2_light2;
@property (strong) IBOutlet NSButton *m_array2_light3;
@property (strong) IBOutlet NSButton *m_array2_stopZ;

@property (strong) IBOutlet NSButton *m_array2_move;
@property (strong) IBOutlet NSButton *m_array2_stopU;
@property (strong) IBOutlet NSButton *m_array2_on;
@property (strong) IBOutlet NSButton *m_array2_off;
@property (strong) IBOutlet NSButton *m_dut_home;
@property (strong) IBOutlet NSButton *m_dut_t10ma;
@property (strong) IBOutlet NSButton *m_dut_white_ref;
@property (strong) IBOutlet NSButton *m_dut_sceen;
@property (strong) IBOutlet NSButton *m_dut_stopW;
@property (strong) IBOutlet NSTextField *m_light1X;
@property (strong) IBOutlet NSTextField *m_light2X;
@property (strong) IBOutlet NSTextField *m_light3X;

@property (strong) IBOutlet NSTextField *m_light1Z;
@property (strong) IBOutlet NSTextField *m_light2Z;
@property (strong) IBOutlet NSTextField *m_light3Z;

@property (strong) IBOutlet NSTextField *m_white_ref_dis;
@property (strong) IBOutlet NSTextField *m_screen_dis;
@property (strong) IBOutlet NSTextField *m_T10MA_dis;
@property (strong) IBOutlet NSTextField *m_fullDistY;
@property (strong) IBOutlet NSTextField *m_fullDistU;

@property (strong) IBOutlet NSButton *m_array1_stopX;
@property (strong) IBOutlet NSTextField *m_array1_percent;
@property (strong) IBOutlet NSTextField *m_array2_percent;
@property (strong) IBOutlet NSTextField *m_homespeedX;
@property (strong) IBOutlet NSTextField *m_homespeedY;
@property (strong) IBOutlet NSTextField *m_homespeedZ;
@property (strong) IBOutlet NSTextField *m_homespeedU;
@property (strong) IBOutlet NSTextField *m_homespeedW;
@end
