function [] = motionTest(command)
    rootPath = '/Users/dhruvguliani/Library/Developer/Xcode/DerivedData/fixturectl-fitmcnqsapyigabwtzsiaaefovmi/Build/Products/Debug/fixturectl ';
    tic
    system(cat(2, rootPath, command));
    disp(toc)
end 