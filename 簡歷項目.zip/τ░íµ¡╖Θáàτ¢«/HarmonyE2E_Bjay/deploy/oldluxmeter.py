from konicameter import T10A

import sys
import glob
import serial


def serial_ports():
    """ Lists serial port names
        :returns:
            A list of the serial ports available on the system
    """
    assert sys.platform.startswith('darwin'), "This script assumes we're running on a mac"
    ports = glob.glob('/dev/tty.usb*')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result


if __name__ == '__main__':
    ports = serial_ports()
    assert len(ports) > 0, "Couldn't find any serial ports like '/dev/tty.usb*'.  Is the Lux meter connected?"
    assert len(ports) < 2, "Found too many serial ports like '/dev/tty.usb*'.  I'm expecting only the T-10A lux meter to be connected via serial"

    meter = T10A(ports[0])
    print meter.sample()


