#!/usr/bin/env python
# requires colormath module to be installed
#   sudo easy_install colormath
# see http://python-colormath.readthedocs.org/en/latest/index.html

from colormath.color_objects import XYZColor, sRGBColor, LuvColor, xyYColor
from colormath.color_conversions import convert_color
hexval = '#6ABE37'
print(hexval)
rgb = sRGBColor.new_from_rgb_hex(hexval)
print(rgb)
xyz = convert_color(rgb, XYZColor, target_illuminant='d65')
print(xyz)
xyY = convert_color(xyz, xyYColor, target_illuminant='d65')
print(xyY)
luv = convert_color(xyz, LuvColor, target_illuminant='d65')
print(luv)
