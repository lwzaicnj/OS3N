#!/usr/bin/env python

import binascii
import sys
import getopt
from os.path import expanduser
from ctypes import*
import os
import time 
import datetime

# -- Register values ---
dpidConfigFileName = 113
dpidCalibFileName = 114
dpidSerialNo = 110
dpidADCRange = 108
dpidVisiblePixels = 104
dpidDeadPixels = 103
dpidNeedDarkCurrent = 130
dpidNeedDensityFilterChange = 131
dpidDCRemeasureReasons = 138
mpidIntegrationTime = 01
mpidMaxADCValue = 11
mpidDensityFilter = 21
mpidCurrentDensityFilter = 22
dforce_initialize = 1

# --- device values ---
device_integration_time = 20 # in milli secs
device_config_path = "/Users/gdlocal/Documents/CASCalibDir/397814213/3978142T1.ini"
device_calib_path = "/Users/gdlocal/Documents/CASCalibDir/397814213/3978142T1.isc"
# device_config_path = "/Users/dhruvguliani/Projects/Apple/HarmonyE2E/CAScal/test/4567142T1.ini"
# device_calib_path = "/Users/dhruvguliani/Projects/Apple/HarmonyE2E/CAScal/test/4567142T1.isc"
 #device_config_path = "/Users/Eric/Documents/Production/Sensor/Harmony_E2E_J111/SW/Tools/HarmonyE2E/CASCal/7831142E1.ini"
 #device_calib_path = "/Users/Eric/Documents/Production/Sensor/Harmony_E2E_J111/SW/Tools/HarmonyE2E/CAScal/7831142E1.isc"

# device_interface_option = 783114215 # TODO:serial no ??

# device_interface_option = 456714213 # TODO:serial no ??

class CASWrapper():
  
  def __init__(self):
    self.casdll = cdll.LoadLibrary('/usr/local/lib/libCAS4.dylib')

  def casGetDeviceTypeOptions(self, interface_type):
    value = self.casdll.casGetDeviceTypeOptions(interface_type);
    return self.checkCASError(value)

  def casGetDeviceTypeOption(self, interface_type, interface_index):
    value = self.casdll.casGetDeviceTypeOption(interface_type, interface_index);
    return self.checkCASError(value)

  def casCreateDevice(self, interface_type, interface_option):
    value = self.casdll.casCreateDeviceEx(interface_type, interface_option)
    return self.checkCASError(value)

  def casInitialize(self, cas_device, option):
    value = self.casdll.casInitialize(cas_device, option)
    return self.checkCASError(value)
    
  def setCasDeviceParameterString(self, cas_device, dpid, file_name):
    str_ptr = c_char_p(file_name)
    value = self.casdll.casSetDeviceParameterString(cas_device,dpid,str_ptr)
    return self.checkCASError(value)
    
  def getDeviceParameterStringWithDPID(self, cas_device, dpid):
    """ returns a string
    """
    buffer = create_string_buffer('\000' * 256)
    self.casdll.casGetDeviceParameterString(cas_device, dpid, buffer, 255)
    return buffer.value
  
  def getDeviceParameterWithDPID(self, cas_device, dpid):
    """ returns a c_double()
    """
    func = self.casdll.casGetDeviceParameter
    func.restype = c_double
    value = func(cas_device, dpid)
    return value
  
  def setMeasurementParameterWithDPID(self, cas_device, dpid, value):
    value = self.casdll.casSetMeasurementParameter(cas_device, dpid, value)
    return self.checkCASError(value)
  
  def prepareMeasurement(self, cas_device):
    integration_time = c_double(device_integration_time)
    value = self.casdll.casSetMeasurementParameter(cas_device, mpidIntegrationTime, integration_time)
    return self.checkCASError(value)
    
  def getMeasurementParameterWithDPID(self, cas_device, dpid):
    func = self.casdll.casGetMeasurementParameter
    func.restype = c_double
    value = func(cas_device, dpid)
    return value
    
  def checkDarkCurrent(self, cas_device):
    needDCMeas = self.getDeviceParameterWithDPID(cas_device, dpidNeedDarkCurrent);
    needFilterChange = self.getDeviceParameterWithDPID(cas_device, dpidNeedDensityFilterChange);

    print needFilterChange
    print needDCMeas
  
    if int(needFilterChange) is not 0:
      print "Need new filter from filter wheel"
      filterParam = self.getMeasurementParameterWithDPID(cas_device, mpidCurrentDensityFilter)
      self.setMeasurementParameterWithDPID(cas_device, mpidDensityFilter, int(filterParam))

    if int(needDCMeas) is not 0:
      print 'Need new dark current measurement'
      self.casdll.casSetShutter(cas_device, 1)
      self.checkCASError(self.casdll.casGetError(cas_device))
      print self.casdll.casMeasureDarkCurrent(cas_device)
      self.casdll.casSetShutter(cas_device, 0)
      self.checkCASError(self.casdll.casGetError(cas_device))
  
  def startMeasurement(self, cas_device):    
    measure = self.casdll.casMeasure(cas_device)
    color = self.casdll.casColorMetric(cas_device)
    if self.checkCASError(measure)==None or self.checkCASError(color)==None:
      return None
  
  def getCCT(self, cas_device):
    func = self.casdll.casGetCCT
    func.restype = c_double
    value = func(cas_device)
    return value
  
  def getTristimulus(self, cas_device):
    X, Y, Z = (c_double(), c_double(), c_double())
    self.casdll.casGetTriStimulus(cas_device, byref(X), byref(Y), byref(Z))
    return (X.value, Y.value, Z.value)
  
  def getColorCoordinates(self, cas_device):
    x, y, z, u, v_1976, v_1960 = (c_double(), c_double(), c_double(), c_double(), c_double(),c_double())
    # self.casdll.casSetOptionsOnOff(cas_device, 256+512,1);
    self.casdll.casGetColorCoordinates(cas_device, byref(x), byref(y), byref(z), byref(u), byref(v_1976), byref(v_1960))
    adcRange = self.getDeviceParameterWithDPID(cas_device, dpidADCRange)
    adcValue = self.getMeasurementParameterWithDPID(cas_device, mpidMaxADCValue)
  
    if adcValue>adcRange:
      adcValue = -1
      # yval = -1
      print 'Measurement Saturated';
    
    return (x.value, y.value, z.value, u.value, v_1976.value, v_1960.value, adcValue)

  def getCasSpectra(self,cas_device, filename):
    self.casdll.casSaveSpectrum(cas_device, filename)      
    
  def getCasMaxADCValue(self, cas_device):
    # print self.casdll.casGetExternalADCValue(cas_device, interface_index);
    adcRange = self.getDeviceParameterWithDPID(cas_device, dpidADCRange)
    value = self.getMeasurementParameterWithDPID(cas_device, mpidMaxADCValue)

    if value>adcRange:
      print 'Measurement Saturated';
    # dest = '';
    # print self.casdll.casGetSerialNumberEx(cas_device, 1, dest, 10);
    # print dest;
    return value; 
  
  def checkCASError(self, cas_error):
    if cas_error < 0:
      #TODO: print the error message
      buffer = create_string_buffer('\000' * 256)
      self.casdll.casGetErrorMessage(cas_error, buffer, 255)
      print "Error:{0}".format(buffer.value)
      return None
    else:return cas_error

class ALSCASDevice():
  def __init__(self, configFile=device_config_path, calibFile=device_calib_path, interface_type=5 ):
    print "INITIALIZING"
    print configFile
    print calibFile
    self.configFile = configFile
    self.calibFile = calibFile
    self.interface_type = c_int(interface_type)
    self.cas_wrapper = CASWrapper()
    self.interface_option = c_int(self.getInterfaceOption())  # serial_no
    
  def Initialize(self):
    self.cas_device = self.cas_wrapper.casCreateDevice(self.interface_type, self.interface_option)
    print "****Initializing: {0}".format(self.cas_device)
    # self.cas_device = 0;
    if self.cas_device == None: 
      print "Error creating device"
      exit()
    is_config_success  = self.cas_wrapper.setCasDeviceParameterString(self.cas_device, dpidConfigFileName, self.configFile)
    is_calib_success   = self.cas_wrapper.setCasDeviceParameterString(self.cas_device, dpidCalibFileName, self.calibFile)
    is_cas_initialized = self.cas_wrapper.casInitialize(self.cas_device, dforce_initialize)
    if is_config_success == None or is_calib_success == None or is_cas_initialized == None:
      print "Error during CAS initialization"
      exit()
#    print "config file loaded successfully: {0}".format(self.cas_wrapper.getDeviceParameterStringWithDPID(self.cas_device, dpidConfigFileName))
#    print "calibration file loaded successfully: {0}".format(self.cas_wrapper.getDeviceParameterStringWithDPID(self.cas_device, dpidCalibFileName))

  def getInterfaceOption(self):
    options = self.cas_wrapper.casGetDeviceTypeOptions(self.interface_type)
    index = c_int(0) # choose the first device by default
    if options > 0:
      print 'device type options:', options 
      device = self.cas_wrapper.casGetDeviceTypeOption(self.interface_type, index)
      print 'device: ', device
      return device
    else:
      print 'Error: Device connection not found'
      exit()

  def findCalFiles(self): # Function written speifically for Harmony E2E
    home_dir = expanduser("~");
    config_dir = home_dir + '/Documents/CASCalibDir/' + str(self.interface_option.value)
    print config_dir
    try:
      for file in os.listdir(config_dir):
        if file.endswith(".isc"):
          print "Cal file", file
          self.calibFile = config_dir + '/' + file
    
        elif file.endswith(".ini"):
          print "Config file", file
          self.configFile = config_dir + '/' + file
    
    except err:
      print 'Error: Could not find config files'
      exit() 

  def getADCValue(self):
    print self.cas_wrapper.getCasMaxADCValue(self.cas_device); 

  def saveSpectra(self, filename):
    print self.cas_wrapper.getCasSpectra(self.cas_device,filename); 

  def prepareToMeasure(self):
    curr_integration_time = self.cas_wrapper.getMeasurementParameterWithDPID(self.cas_device, 1);
    print "Old Integration time: {0}".format(curr_integration_time)
    integration_time = c_double(device_integration_time)
    if curr_integration_time is not integration_time:
      self.cas_wrapper.setMeasurementParameterWithDPID(self.cas_device, mpidIntegrationTime, integration_time)
      self.cas_wrapper.checkDarkCurrent(self.cas_device)
      print "CAS integration time: {0}".format(self.cas_wrapper.getMeasurementParameterWithDPID(self.cas_device, mpidIntegrationTime))
    else:
      print "Integration time need not be changed"
      return;
    # self.startMeasurement()
    # self.cas_wrapper.checkDarkCurrent(self.cas_device)

    
    
  def startMeasurement(self):
    self.cas_wrapper.startMeasurement(self.cas_device)
#    print self.cas_wrapper.getCCT(self.cas_device)
    print self.cas_wrapper.getTristimulus(self.cas_device)
    print self.cas_wrapper.getColorCoordinates(self.cas_device)
  

def main(argv):
  global device_config_path
  global device_calib_path
  global device_integration_time
  findFiles = 0; 
  save = 0; 
  try:
      opts, args = getopt.getopt(argv,"hfi:s:",["intTime=", "savePath="])
  except getopt.GetoptError:
      print 'no arguments passed in'
  for opt, arg in opts:
      if opt == '-h':
         print 'cas.py -f to find cal files , -i <integrationtime>'
         sys.exit()
      elif opt == '-f':
        findFiles = 1;
      elif opt in ("-i", "--intTime"):
        device_integration_time = float(arg)
      elif opt in ("-s", "--savePath"):
        save = 1; 
        savePath = arg
  # print 'integration time is ', device_integration_time

  device = ALSCASDevice(configFile=device_config_path, calibFile=device_calib_path)
  if findFiles == 1:
    print 'Finding cal files'
    device.findCalFiles()
  device.Initialize()
  device.prepareToMeasure()
  device.startMeasurement()
  if save == 1:
    ts = time.time()
    st = datetime.datetime.fromtimestamp(ts).strftime('%d%m%Y%H%M%S');
    if not (os.path.exists(savePath)):
      print "\tcreating directory: "+ savePath
      os.makedirs(savePath)
    device.saveSpectra(savePath+st+'_spectra');
  # device.saveSpectra('test')

if __name__ == "__main__":
   main(sys.argv[1:]) 
    