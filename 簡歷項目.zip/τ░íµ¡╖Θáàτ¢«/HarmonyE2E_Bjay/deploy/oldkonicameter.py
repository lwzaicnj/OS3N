import serial
import sys
from time import sleep

#Instruction in using this module
#(1) import the module by calling           <<from konicameter import T10A>>
#(2) create a meter object                  <<meter = T10A('/dev/tty.usbserial-AL005DAD')
#(4) get sample by calling                  <<lux = meter.sample()

class KonicaMeter:
    def __init__(self, port):
        self.ser = serial.Serial(port = port, timeout = 100, baudrate = 9600)
        self.ser.parity = 'E'
        self.ser.bytesize = 7
        sleep(0.01)
        assert self.ser.isOpen() , "Port is not open, Please check connection or initialize first"

       #1:Set Normal mode ---> PC control mode
        #print "# Setting PC Mode"
        PC_mode = '\x0200541   \x0313\r\n'
        #print "-> [{}]".format(PC_mode.strip())
        self.ser.write(PC_mode)
        #self.ser.read(13)
        #self.ser.flushInput()
        #self.ser.flushOutput()
        #print "pause 500 ms"
        sleep(0.5)
        
    def sample(self):
        """ sample return value depends on specific meter """
        raise NotImplementedError

    @staticmethod
    def convert_raw(raw_string):
        #Convert raw data into int
        if raw_string[0] == '+' :
            return  (1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])
        elif raw_string[0] == '-':
            return -(1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])    
        else:    
            return +(1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])    
            
    @staticmethod
    def get_expo(char):
        #"""This is a helper function for convert_raw"""
        if char == '0':
            return 0.0001
        elif char == '1':
            return 0.001
        elif char == '2':
            return 0.01
        elif char == '3':
            return 0.1
        elif char == '4':
            return 1
        elif char == '5':
            return 10
        elif char == '6':
            return 100
        elif char == '7':
            return 1000
        elif char == '8':
            return 10000
        else :
            return 100000

class CL200A (KonicaMeter):
    """ Konica Minolta CL-200A Chroma Meter

        Sample returns Lux, X, Y """
    def __init__(self, port):
        KonicaMeter.__init__(self, port)


        #2:Set PC control mode ----> HOLD mode
        hold_mode = '\x0299551  0\x0302\r\n'
        self.ser.write(hold_mode)
        sleep(0.6)

        #3:Set HOLD mode ----> EXT mode //EXT mode is need for measurement
        EXT_mode = '\x02004010  \x0306\r\n'
        self.ser.write(EXT_mode)
        self.ser.read(14)
        sleep(0.2)

    def sample(self):
        """ Ev,X,Y = sample()  """
        for j in range(2):
            #Request for 2 samples and discard the first one
            measure_mode = '\x02994021  \x0304\r\n'
            self.ser.write(measure_mode)
            sleep(0.6)

            #Read it
            raw_data = " "
            read_mode = '\x0200021200\x0302\r\n'
            self.ser.write(read_mode)
            raw_data = self.ser.read(32)
            sleep(0.2)
        return KonicaMeter.convert_raw(raw_data[9:15]), KonicaMeter.convert_raw(raw_data[15:21]), KonicaMeter.convert_raw(raw_data[21:27])
 
class T10A (KonicaMeter):
    """ Konica Minolta T-10A Illuminance Meter

        Sample returns Il,dIl,p = sample()  Illuminance, delta Illuminance, Percent """
    def __init__(self, port):
        KonicaMeter.__init__(self, port)
  
    def sample(self):
        """ Il,dIl,p = sample()  Illuminance, delta Illuminance, Percent
        For now, we're only returning the illuminance (first value)"""

        #2:Setting measurement conditions ----> Head 0, Run, CCF Disabled, Range 3 (0-2999)
        #print "# Setting measurement conditions ----> Head 0, Run, CCF Disabled, AutoRange"
        set_measurement_conditions = '\x0200100230\x0303\r\n'
        #print "-> [{}]".format(set_measurement_conditions.strip())
        self.ser.write(set_measurement_conditions)
        #print "# expecting 14 chars back"
        raw_data = self.ser.read(14)
        #print "<- [{}]".format(raw_data.strip())
        #print "inwaiting2 = {}".format(self.ser.inWaiting())
        #print("pause 3")
        sleep(1.0)
        #Read it
        #print "reading data"
        raw_data = " "
        get_data = '\x0200100230\x0303\r\n'
        #print "-> [{}]".format(get_data.strip())
        self.ser.write(get_data)
        #print "inwaiting1 = {}".format(self.ser.inWaiting())
        raw_data = self.ser.read(32)
        #print "have read data"
        #print "[{}]".format(raw_data)
        #print "inwaiting2 = {}".format(self.ser.inWaiting())
        return KonicaMeter.convert_raw(raw_data[9:15])        