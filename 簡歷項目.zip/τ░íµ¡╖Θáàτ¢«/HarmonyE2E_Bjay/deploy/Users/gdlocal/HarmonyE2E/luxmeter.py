from konicameter import T10A

if __name__ == '__main__':
    #meter = T10A("/dev/tty.usbserial-A6041L03")
    meter = T10A("/vault/DMX/luxconfig.txt")
    print "going to sample"
    #meter = T10A()
    print meter.sample()


