""" konicameter - take simple readings from Konica light meters

example usage:
    from konicameter import T10A
    meter = T10A('/dev/tty.usbserial-AL005DAD')
    lux = meter.sample()

When creating the object you can pass 3 different types of port values:
    a. None     e.g.
            meter = T10A()
        This will attempt to enumerate usbserial devices (/dev/tty.usb*)
        and will take the first one and try to connect to it as a Konica light meter.
        If the device doesn't exist this call will raise an exception
    b. A device path  e.g.
            meter = T10A("/dev/tty.usbserial-A6041L03")
        This will try to connect to the specified usb serial device as a Konica light meter.
        If the device doesn't exist, this call will raise an exception.
    c. A config file containing a device path.  e.g.
            meter = T10A("/vault/DMX/luxconfig.txt")
        This will read the device path from the first line of the specified text file.
        If the file doesn't exist, the tool will attempt to generate it by enumerating
        usbserial devices  (e.g. /dev/tty.usb*) and saving them in the file.   It will 
        return the first found device and connect to it as a Konica light meter.
        The next time you use the tool it will find the config file and use it without
        enumerating serial devices.
    
"""

import serial
import sys
from time import sleep
import os.path
import glob


class KonicaMeter:
    def __init__(self, port=None):
        self.port = port
        # port can be a device path (starts with '/dev/') or a config file
        # containing a device path.  
        if self.port is None or not self.port.startswith("/dev/"):
            self.port = KonicaMeter.resolvePort(self.port)

        self.ser = serial.Serial(port = self.port, timeout = 100, baudrate = 9600)
        self.ser.parity = 'E'
        self.ser.bytesize = 7
        sleep(0.01)
        assert self.ser.isOpen() , "Port is not open, Please check connection or initialize first"

       #1:Set Normal mode ---> PC control mode
        #print "# Setting PC Mode"
        PC_mode = '\x0200541   \x0313\r\n'
        #print "-> [{}]".format(PC_mode.strip())
        self.ser.write(PC_mode)
        #self.ser.read(13)
        #self.ser.flushInput()
        #self.ser.flushOutput()
        #print "pause 500 ms"
        sleep(0.5)

    @staticmethod
    def generatePortConfigFile(configFilename):
        """ try to find a serialport that might work and dump it into the config file """
        ports = KonicaMeter.serial_ports()
        assert len(ports) > 0, "Couldn't find any serial ports like '/dev/tty.usb*'.  Is the Lux meter connected and powered on?"
        #assert len(ports) < 2, "Found too many serial ports like '/dev/tty.usb*'.  I'm expecting only the T-10A lux meter to be connected via serial"
        if configFilename is not None:
            with open(configFilename, "w") as config:
                config.write("\n".join(ports))
                config.write("\n")
        return ports[0].strip()

    @staticmethod
    def resolvePort(port):
        """ if port is not a device path ("/dev/..."), then assume it's a config
            file containing a device path.   If it doesn't exist, generate it """

        if port is not None:
            assert not port.startswith("/dev/"), "Internal Error: resolvePort shouldn't be called on a device file"

        # if config file doesn't exist, generate it
        if port is None or not os.path.exists(port):
            resolvedport = KonicaMeter.generatePortConfigFile(port)
        else:
            # if config file exists, just read it and return
            resolvedport = open(port, "rb").readlines()[0].strip()
            if not os.path.exists(resolvedport):
                # might as well remove it and regenerate it next time
                resolvedport = KonicaMeter.generatePortConfigFile(port)
        return resolvedport
   
    @staticmethod
    def serial_ports():
        """ Lists serial port names
        :returns:
            A list of the serial ports available on the system"""
        assert sys.platform.startswith('darwin'), "This script assumes we're running on a mac"
        ports = glob.glob('/dev/cu.usb*')

        result = []
        for port in ports:
            try:
                s = serial.Serial(port)
                s.close()
                result.append(port)
            except (OSError, serial.SerialException):
                pass
        return result
        
    def sample(self):
        """ sample return value depends on specific meter """
        raise NotImplementedError

    @staticmethod
    def convert_raw(raw_string):
        #Convert raw data into int
        if raw_string[0] == '+' :
            return  (1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])
        elif raw_string[0] == '-':
            return -(1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])    
        else:    
            return +(1.0*int(raw_string[1:5]))* KonicaMeter.get_expo(raw_string[5])    
            
    @staticmethod
    def get_expo(char):
        #"""This is a helper function for convert_raw"""
        if char == '0':
            return 0.0001
        elif char == '1':
            return 0.001
        elif char == '2':
            return 0.01
        elif char == '3':
            return 0.1
        elif char == '4':
            return 1
        elif char == '5':
            return 10
        elif char == '6':
            return 100
        elif char == '7':
            return 1000
        elif char == '8':
            return 10000
        else :
            return 100000

class CL200A (KonicaMeter):
    """ Konica Minolta CL-200A Chroma Meter

        Sample returns Lux, X, Y """
    def __init__(self, port=None):
        KonicaMeter.__init__(self, port)


        #2:Set PC control mode ----> HOLD mode
        hold_mode = '\x0299551  0\x0302\r\n'
        self.ser.write(hold_mode)
        sleep(0.6)

        #3:Set HOLD mode ----> EXT mode //EXT mode is need for measurement
        EXT_mode = '\x02004010  \x0306\r\n'
        self.ser.write(EXT_mode)
        self.ser.read(14)
        sleep(0.2)

    def sample(self):
        """ Ev,X,Y = sample()  """
        for j in range(2):
            #Request for 2 samples and discard the first one
            measure_mode = '\x02994021  \x0304\r\n'
            self.ser.write(measure_mode)
            sleep(0.6)

            #Read it
            raw_data = " "
            read_mode = '\x0200021200\x0302\r\n'
            self.ser.write(read_mode)
            raw_data = self.ser.read(32)
            sleep(0.2)
        return KonicaMeter.convert_raw(raw_data[9:15]), KonicaMeter.convert_raw(raw_data[15:21]), KonicaMeter.convert_raw(raw_data[21:27])
 
class T10A (KonicaMeter):
    """ Konica Minolta T-10A Illuminance Meter

        Sample returns Il,dIl,p = sample()  Illuminance, delta Illuminance, Percent """
    def __init__(self, port=None):
        KonicaMeter.__init__(self, port)
  
    def sample(self):
        """ Il,dIl,p = sample()  Illuminance, delta Illuminance, Percent
        For now, we're only returning the illuminance (first value)"""

        #2:Setting measurement conditions ----> Head 0, Run, CCF Disabled, Range 3 (0-2999)
        print "# Setting measurement conditions ----> Head 0, Run, CCF Disabled, AutoRange"
        set_measurement_conditions = '\x0200100230\x0303\r\n'
        #print "-> [{}]".format(set_measurement_conditions.strip())
        self.ser.write(set_measurement_conditions)
        print "# expecting 14 chars back"
        raw_data = self.ser.read(14)
        print "<- [{}]".format(raw_data.strip())
        print "inwaiting2 = {}".format(self.ser.inWaiting())
        print("pause 3")
        sleep(1.0)
        #Read it
        print "reading data"
        raw_data = " "
        get_data = '\x0200100230\x0303\r\n'
        #print "-> [{}]".format(get_data.strip())
        self.ser.write(get_data)
        #print "inwaiting1 = {}".format(self.ser.inWaiting())
        raw_data = self.ser.read(32)
        print "have read data"
        print "[{}]".format(raw_data)
        #print "inwaiting2 = {}".format(self.ser.inWaiting())
        return KonicaMeter.convert_raw(raw_data[9:15])        