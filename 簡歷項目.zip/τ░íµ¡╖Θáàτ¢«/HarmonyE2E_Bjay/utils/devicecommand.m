function [channel, result] = devicecommand(channel, cmd)   
    disp(['    d> ',cmd]);
    [channel result] = sshfrommatlabissue(channel, cmd );
end