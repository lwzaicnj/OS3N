function [] = addAttribute(path, names, vals, varargin) 

    % names should be a cellstr, e.g.  {'foo', 'bar'}
    % vals should be an array of cellarrays  e.g. [ {13} {14} ]
    
    if(~isequal(length(names), length(vals)))
        error('Error adding to pdca uploader plist: key value pair length mismatch'); 
    end 
%     tic
    docNode = xmlread(path);
    allItems = docNode.getElementsByTagName('array');
    len = allItems.getLength();
    array = allItems.item(0);
    docRootNode = docNode.getDocumentElement;
    if(isequal(length(varargin),1))
        upperLimits = varargin{1}; 
    else 
        upperLimits = [];
    end
    
    for i = 1:length(names)
        name = names(i); 
        val = num2str(cell2mat(vals(i)));
        if( isequal(length(upperLimits), length(vals)))
            upperLimitText = num2str(cell2mat(upperLimits(i))); 
        else 
            upperLimitText = 'NA'; 
        end
        dictElement = docNode.createElement('dict');
    
        failMsg = docNode.createElement('key'); 
        failMsg.appendChild(docNode.createTextNode('failure_message')); 
        failMsgString = docNode.createElement('string'); 
        failMsgString.appendChild(docNode.createTextNode('NA'));

        lowerLimit = docNode.createElement('key'); 
        lowerLimit.appendChild(docNode.createTextNode('lowerLimit')); 
        lowerLimitString = docNode.createElement('string'); 
        lowerLimitString.appendChild(docNode.createTextNode('NA'));

        priority = docNode.createElement('key'); 
        priority.appendChild(docNode.createTextNode('priority')); 
        priorityString = docNode.createElement('string'); 
        priorityString.appendChild(docNode.createTextNode('0'));

        result = docNode.createElement('key'); 
        result.appendChild(docNode.createTextNode('result')); 
        resultString = docNode.createElement('string'); 
        resultString.appendChild(docNode.createTextNode('PASS'));

        subTest = docNode.createElement('key'); 
        subTest.appendChild(docNode.createTextNode('subtestname')); 
        subTestString = docNode.createElement('string'); 
        subTestString.appendChild(docNode.createTextNode(name));

        test = docNode.createElement('key'); 
        test.appendChild(docNode.createTextNode('testname')); 
        testString = docNode.createElement('string'); 
        testString.appendChild(docNode.createTextNode('HarmonyE2E'));

        upperLimit = docNode.createElement('key'); 
        upperLimit.appendChild(docNode.createTextNode('upperLimit')); 
        upperLimitString = docNode.createElement('string'); 
        upperLimitString.appendChild(docNode.createTextNode(upperLimitText));

        value = docNode.createElement('key'); 
        value.appendChild(docNode.createTextNode('value')); 
        valueString = docNode.createElement('string'); 
        valueString.appendChild(docNode.createTextNode(val));

        dictElement.appendChild(failMsg); 
        dictElement.appendChild(failMsgString); 
        dictElement.appendChild(lowerLimit); 
        dictElement.appendChild(lowerLimitString); 
        dictElement.appendChild(priority); 
        dictElement.appendChild(priorityString); 
        dictElement.appendChild(result); 
        dictElement.appendChild(resultString); 
        dictElement.appendChild(subTest); 
        dictElement.appendChild(subTestString); 
        dictElement.appendChild(test); 
        dictElement.appendChild(testString); 
        dictElement.appendChild(upperLimit); 
        dictElement.appendChild(upperLimitString); 
        dictElement.appendChild(value); 
        dictElement.appendChild(valueString); 

        array.appendChild(dictElement);
    end
    
    xmlwrite(path,docNode);
%     myXMLwrite(file,xmlread(file));
%     disp(cat(2,'Execution time: ', num2str(toc))); 
end