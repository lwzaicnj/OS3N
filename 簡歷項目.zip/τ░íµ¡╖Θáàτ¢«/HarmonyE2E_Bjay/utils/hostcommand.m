function [status, result] = hostcommand(cmd)   
    disp(['    h> ',cmd]);
    [status, result] = system(cmd);
   % disp(cat(2,'tcprelayResult ',status,result));
end