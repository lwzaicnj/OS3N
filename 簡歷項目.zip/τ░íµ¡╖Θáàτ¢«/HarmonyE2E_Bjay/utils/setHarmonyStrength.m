function [] = setHarmonyStrength(channel, strength)
% Uses BacklightdTester to override the sensor value and set a specific harmony recommendation    
    
    % Enable override mode 
%     commandString = 'BacklightdTester -set AABSensorOverride 1';
%     [status] = sshfrommatlabissue_dontwait( channel, commandString );
    commandString =  cat(2,'BacklightdTester -set ColorAdaptationStrength ', num2str(strength), ' 0');
    [status] = sshfrommatlabissue_dontwait( channel, commandString );
end 