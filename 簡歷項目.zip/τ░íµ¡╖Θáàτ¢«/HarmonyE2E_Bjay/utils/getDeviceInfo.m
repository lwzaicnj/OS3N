function[ keys, values ] = getDeviceInfo(channel) 
    commandString = 'gestalt_query BuildVersion | cut -f 2 -d \"';
    %yi " hua fen qu di 2 duan
    [status vals] = sshfrommatlabissue(channel, commandString); 
    keys = {'BuildVersion'};
    values = vals';
end