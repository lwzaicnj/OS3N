function [result] = setIris(path, light, val) 
    % Make call to the motor controller to move iris to the passed position 
    if (light < 7)
        %array  = 1; 
        disp('Light is normal!');
    else
        disp(cat(2, 'ERROR: cannot set iris for given light. (',num2str(light),').  Expected 0-7. check config file'));
        if isdeployed()
            exit(7);
        else
            result = [];
            return
        end
    end
    %commandStr = cat(2, path, ' adjustiris', num2str(array), ' ', num2str(val)); 
    commandStr = cat(2, path, ' a4-max');
    hostcommand(commandStr);
    result = 1; 
end 