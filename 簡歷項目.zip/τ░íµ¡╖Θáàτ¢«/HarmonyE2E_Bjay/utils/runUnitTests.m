function [ out ] = runUnitTests()
    %RUNUNITTESTS execute all unittests in tests/ folder
    
    import matlab.unittest.TestSuite
    testFolder = fullfile(pwd,'tests/');
    suiteFile = TestSuite.fromFolder(testFolder);
    result = run(suiteFile);
end