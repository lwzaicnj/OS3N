% This script gets a DUT ready for the End 2 End script
% wait until it boots in nonUI, then set the display mode to newLcdMura=RGBW

% TODO for some reason the second argument fails to get added to the boot
% args
[status, msg] = system(cat(2,'./sendCommand 10000 "nvram boot-args="newLcdMura=RGBW debug=0x14e""'));
[status, msg] = system(cat(2,'./sendCommand 10000 "reboot"'));
disp('If the unit doesn''t reboot, check the connection with the unit')