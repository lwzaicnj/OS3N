function [result] = selectLightSource( source, path ) 
    % Call out to expose the passed light  3lights and 1 shutter for bjay
    if( source < 1 )
%         disp('    Turning lights off')
        hostcommand(cat(2, path, ' a4-min'));
        hostcommand(cat(2, path, ' shutter-close'));
    elseif( source < 4 )
        hostcommand(cat(2, path, ' shutter-open'));
        %hostcommand(cat(2, path, ' light1', num2str(source)));
        hostcommand(cat(2, path, ' a3-light', num2str(source)));
    elseif( source < 7 )% 1-3 1Axis  4-7 2Axis
        hostcommand(cat(2, path, ' shutter-open'));
        hostcommand(cat(2, path, ' a3-light', num2str(source-3)));%cfl
    end 
    disp(['    # Selecting light source ', num2str(source)])
    result = 1; 
end 