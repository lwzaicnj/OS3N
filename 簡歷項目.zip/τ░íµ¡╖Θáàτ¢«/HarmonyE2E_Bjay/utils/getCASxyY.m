function [status result counts] = getCASxyY( pythonPath, intTime, varargin )
%     status = 0; 
%     result = [0.3776;0.1;430.0113];
    if ~isempty(varargin)
        argStr = varargin{1};%cell array?
    else
        argStr = ''; 
    end
    
    try
        cmdstr = cat(2,pythonPath, ' deploy/cas.py -f -i ', num2str(intTime), argStr);
        if isdeployed()
            cmdstr = cat(2,pythonPath, ' /Users/gdlocal/HarmonyE2E/cas.py -f -i ', num2str(intTime), argStr);
        end
        [status result] = hostcommand(cmdstr);
%         result = [0.4; 0.4; 300];
%         status = 1; 
%         disp('Faking CAS measurement for now'); 
%         return; 
        
        openIndices = strfind(result,'(');
        closeIndices = strfind(result, ')'); 

        tristimulus = result(openIndices(1)+1:closeIndices(1)-1); 
        colorCoord = result(openIndices(2)+1:closeIndices(2)-1); 
        if( eq(0,length(tristimulus)) | eq(0,length(colorCoord)))
            error('ERROR: Could not get cas measurement'); 
        end
        tristVals = strsplit(tristimulus, ','); 
        coordVals = strsplit(colorCoord, ','); 

        result = [str2num(char(coordVals(1))), str2num(char(coordVals(2))), str2num(char(tristVals(2)))]';
        disp(cat(2, 'Counts: ', char(coordVals(7)))); %Temporary
        counts = str2num(char(coordVals(7)));
        status = 0;
    catch err
        if isdeployed()
            exit(3);
        else
            disp('ERROR: error caught in getCASxyY:')
            disp(err)
            status = 0;
            result = [];
            return
        end        
    end
    
end