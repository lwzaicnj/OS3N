% Confirm that this actually changes the rec directly and not the input to
% the algorithm computing the rec (as the requirements doc suggests) 
function [] = setHarmonyRec(channel, xyYInput, strength)
% Uses BacklightdTester to override the sensor value and set a specific harmony recommendation    
    
    % Enable override mode 
%     commandString = 'BacklightdTester -set AABSensorOverride 1';
%     [status] = sshfrommatlabissue_dontwait( channel, commandString );
    
    pause(2);
    
    commandString = 'BacklightdTester -set ColorAdaptationStrength 0 0 &';
    [status] = sshfrommatlabissue_dontwait( channel, commandString );
    commandString = cat(2,'BacklightdTester -d set AABSensorOverride 0 ' , num2str(xyYInput(3)), ' ',...
                                                                           num2str(xyYInput(1)), ' ',...
                                                                           num2str(xyYInput(2)));
    [status] = sshfrommatlabissue_dontwait( channel, commandString );
    
    pause(2);
    
    commandString =  cat(2,'BacklightdTester -set ColorAdaptationStrength ', num2str(strength), ' 0');
    [status] = sshfrommatlabissue_dontwait( channel, commandString );
end 