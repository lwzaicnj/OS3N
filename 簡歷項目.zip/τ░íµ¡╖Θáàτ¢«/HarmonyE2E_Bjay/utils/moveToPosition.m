function [result] = moveToPosition( pos, path) 
    % Make call to the motor controller to move to the passed position 
%     disp(['    # Moving DUT to position ', num2str(pos)])
    %hostcommand(cat(2, path, ' moveDUT', num2str(pos)));
    hostcommand(cat(2, path, ' a1-work-place', num2str(pos)));
    result = 1; 
end 