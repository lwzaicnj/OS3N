function [ out ] = deltauv( uv1, uv2 )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

out = sqrt((uv1(1,:)-uv2(1,:)).^2+(uv1(2,:)-uv2(2,:)).^2);


end

