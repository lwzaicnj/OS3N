function [xy_target_out] = calculateAdjustedxyTarget(xy_target_in)

% input: 
%       - 2xN matrix of the current x-y target values
% output: 
%       - 2xN matrix of the adjusted x-y target values
%       - 2xN matrix of the delta between the two


%% Msrgb2xyz conversion matrices

xyYwD65 = [.3127 .329 1]';
xyYwA = [.3098 .3291 1]';
XYZw = xyY2XYZ(xyYwD65);
XYZwA = xyY2XYZ(xyYwA);

xr = .64;
yr = .33;
xg = .3;
yg = .6;
xb = .15;
yb = .06;

Xr = xr/yr;
Yr = 1;
Zr = (1-xr-yr)/yr;
Xg = xg/yg;
Yg = 1;
Zg = (1-xg-yg)/yg;
Xb = xb/yb;
Yb = 1;
Zb = (1-xb-yb)/yb;

Srgb = inv([Xr Xg Xb; Yr Yg Yb; Zr Zg Zb]) * XYZw;
Sr = Srgb(1);
Sg = Srgb(2);
Sb = Srgb(3);

SrgbA = inv([Xr Xg Xb; Yr Yg Yb; Zr Zg Zb]) * XYZwA;
SrA = SrgbA(1);
SgA = SrgbA(2);
SbA = SrgbA(3);

MsRGB2XYZ =[ Sr*Xr Sg*Xg Sb*Xb
             Sr*Yr Sg*Yg Sb*Yb
             Sr*Zr Sg*Zg Sb*Zb];
        
MsRGBA2XYZ =[SrA*Xr SgA*Xg SbA*Xb
             SrA*Yr SgA*Yg SbA*Yb
             SrA*Zr SgA*Zg SbA*Zb];

%% Main function

xi = xy_target_in(1,:);
yi = xy_target_in(2,:);
Yi = ones(size(xi));;
Xi = xi.*Yi./yi;
Yi = Yi;
Zi = (1-xi-yi).*Yi./yi;



RGB_H = inv(MsRGB2XYZ) * [Xi;Yi;Zi];   % adjusted RGB values due to Harmony matrix
XYZ_out = MsRGBA2XYZ * RGB_H;
Xo = XYZ_out(1,:);
Yo = XYZ_out(2,:);
Zo = XYZ_out(3,:);
xo = Xo./(Xo + Yo + Zo);
yo = Yo./(Xo + Yo + Zo);


xy_target_out = [xo ; yo];
%delta = xy_target_out - xy_target_in;


%disp('--------------------------- done ---------------------------');














