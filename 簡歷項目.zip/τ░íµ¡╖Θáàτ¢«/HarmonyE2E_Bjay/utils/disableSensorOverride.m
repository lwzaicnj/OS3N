function [] = disableSensorOverride()
    commandString = 'BacklightdTester -set AABSensorOverride -1'; 
    [status output] = system(cat(2,'./sendCommand 10000 "', commandString,'"'));
end 