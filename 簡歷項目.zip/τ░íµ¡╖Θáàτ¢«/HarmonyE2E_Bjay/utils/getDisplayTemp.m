function[ temperature ] = getDisplayTemp(channel) 
    commandString = 'diagstool hwmisc --temperature CG';
    % This command returns a cell array with a single element containing a string like '27.09C'
    [status output] = sshfrommatlabissue(channel, commandString); 
    % extract the value from the cell array
    %temperature = output{1};
    temperature = output{3};
    % remove final C (if it exists)
    temperature(temperature=='C') = [];
    % return a number (not a string)
    temperature = str2num(temperature);
end  