
function [status result] = getHarmonyRecxyY(channel) 
    
%     commandString = 'BacklightdTester -get ColorRamp';
    commandString = 'gamutMatrix -H -o h.txt';
    [status output] = sshfrommatlabissue(channel, commandString); 
    commandString = 'cat h.txt';
    [status output] = sshfrommatlabissue(channel, commandString); 
    Mh = []; 
    for i = 1:3 
        wrkingStr = strtrim(output{i}); 
        splitStr = strsplit(wrkingStr, ' '); 
        Mh(i,1) = str2num(splitStr{1});
        Mh(i,2) = str2num(splitStr{2});
        Mh(i,3) = str2num(splitStr{3});
    end
% 
%     output = strtrim(output); 
%     startInd = find(ismember(output,'{') == 1); 
%     numArray = [];
%     
%     for i = (startInd+3):(startInd+11)
%         try 
%             numArray(end+1) = sscanf(output{i}, '"%f');
%         catch e 
%             error('--- ERROR: Error in parsing Harmony Reccomendation ---')
%         end
%     end
    
    % TODO how to get the below 3*3 into xyY color space 
    % TODO is the below transpose operation correct?
    Msrgb2xyz = [0.412390799265959	0.357584339383878	0.180480788401834;...
                0.212639005871510	0.715168678767756	0.0721923153607337;...
                0.0193308187155918	0.119194779794626	0.950532152249661];
%     Mh = reshape(numArray, 3,3)'; 
    xyz = Msrgb2xyz*Mh*[1;1;1];
    result = XYZ2xyY(xyz); 
    
end 