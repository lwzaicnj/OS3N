function [ status, result ] = getALSxyz( channel, sensor, numSamples, timeInt )
%GETALSXYZ Summary of this function goes here
%   Detailed explanation goes here
    % Request 3* the number of samples as sometimes the placement
    % argument does not work
    numSamples = numSamples*2;
    
    xyz = [];
    numChannels = 11;
    if isDeviceBlack(channel)
        gain = '256'; % black unit 1
    else
        gain = '64';  % white unit 0
    end
    try 
        if( sensor ~= 0 ) 
            commandString = cat(2, 'alsTester -placement ', num2str(sensor), ' -samples ', num2str(numSamples), ' -verbose  -alsTestMode 1 -raw 1 -supportDynamicGain 0 -alsGain ', gain, ' -interval ', num2str(timeInt));
            commandString = cat(2, commandString, ' | grep -A 1 "placement: *', num2str(sensor), '"');
        else 
            commandString = cat(2, 'alsTester -placement 5 ', ' -samples ', num2str(numSamples), ' -verbose -alsTestMode 1 -raw 1 -supportDynamicGain 0 -alsGain ', gain,' -interval ', num2str(timeInt));
        end
        [status output] = sshfrommatlabissue( channel, commandString );
        if(eq(length(output),0))
            disp('Error getting alsTester data')
            return
        end
        disp(commandString);
        disp(char(output));     % Show raw alsTester output to find source of instability
        indices = strmatch('Time', output);

        if (length(indices) < 2)
            error('--- ERROR: Could not get ALS measurement ---');
        end
        numFound = length(indices)-1;
        startInd = indices(2); % Ignore first meausurement due to settling time 
        ALSReadings = [];
        for i = 2:length(indices)
            ALSReadings = [ALSReadings [sscanf(output{indices(i)},'Time: %f Interval: %f secs lux: %f ch0: %d ch1: %d ch2: %d ch3: %d X:%f Y:%f Z:%f  placement: %d\n')]];
        end 
        ALSReadings = reshape(ALSReadings, numChannels, numFound);
        if( sensor ~= 0 )
            validSensorInd = abs(ALSReadings(end,1:end) - sensor) < eps;
            channelReadings = ALSReadings(:, validSensorInd);%validSensorInd 0 or 1
            xyz = channelReadings(8:10,:);
        else
            NWSensorInd = abs(ALSReadings(end,1:end) - 5) < eps;
            NESensorInd = abs(ALSReadings(end,1:end) - 6) < eps;
            NWReadings = ALSReadings(:, NWSensorInd);
            NEReadings = ALSReadings(:, NESensorInd);
            NWxyz = NWReadings(8:10,:); 
            NExyz = NEReadings(8:10,:); 
            NWResult = mean(NWxyz');
            NEResult = mean(NExyz');
            result = cat(2, NWResult, NEResult); 
            result = reshape(result, 3, 2); 
            return
        end


    %     disp(length(xyz(:,1)))
        result = mean(xyz');
        result = result';
    catch err
        disp(cat(2, 'ERROR: error caught in getALSxyz: ', err.message));
        if isdeployed()
            exit(4);
        else
            status = 0;
            result = [];
            return
        end    
    end 
%     commandString = cat(2, 'alsTester -placement ', num2str(sensor), ' -samples ', num2str(numSamples), ' -alsTestMode 1 -raw 1 -supportDynamicGain 0 -alsGain 64 -interval ', num2str(timeInt));
    
end

