function [ curBootArgs ] = deviceSetup()
    cmd = 'nvram boot-args';
    curBootArgs = '';
    channel = sshfrommatlab('root','localhost',10022,'alpine');
    [channel, output] = sshfrommatlabissue( channel, cmd ); 
    if length(output) >= 1
        curBootArgs = output{1}; % TODO Improve
        disp(['    Current Boot Args: ',curBootArgs])
    end
    
    % Don't change the ssh commands in this sequence.   I don't understand why, but if you
	% change it you will get errors saying you can't issue the reboot
	% because the channel is already being shutdown.  sendCommand seems to
	% bypass that.
    tic
    disp('    # changing bootargs and rebooting.');
    commandStr =  'nvram boot-args="newLcdMura=RGBW debug=0x14e"';
    [status] = sshfrommatlabissue_dontwait( channel, commandStr);
    disp('    # Expect a 19 second delay.');
%     disp('  * If the unit doesn''t reboot, check the connection with the unit.')
%     disp('    After 19 seconds, you may see a few "SSHFROMMATLAB could not connect..." messages')
%     disp('    A few is OK.')
    sshfrommatlabclose(channel);
    [status, msg] = system(cat(2,'./sendCommand 10000 "reboot"'));
    
    % after 19 seconds, see if the device is visible.
%     pause(19);
    unitOnline = checkDeviceConnected();
    while( unitOnline ~= 1 )     % TODO:  timeout to avoid infinite loop 
        pause(1);
        unitOnline = checkDeviceConnected();
    end
    timing.rebootTime = toc;
    disp(['    # returned from reboot.  Actual delay was ', num2str(timing.rebootTime), ' sec']);
end

