function [connected] = checkDeviceConnected() 
    try
        channel = sshfrommatlab('root','localhost',10022,'alpine');
    catch err
%         disp(err);
        connected = 0; 
        return;
    end
    connected = 1;
    sshfrommatlabclose(channel);
end 