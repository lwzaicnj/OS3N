function [status result] = getLuxReading( pythonPath )
     try
        cmdstr = [pythonPath, ' deploy/luxmeter.py'];
        if isdeployed()
            cmdstr = [pythonPath, ' luxmeter.py'];
        end
        [status result] = hostcommand(cmdstr);
        result = str2double(result); 
        if (isnan(result))
            error('Error: Lux meter resulted in NAN')
        end
    catch err
        disp(cat(2, 'ERROR: error caught in getLuxReading: ', err.message));
        if isdeployed()
            exit(5);
        else
            status = 0;
            result = [];
            return
        end    
    end
end 
