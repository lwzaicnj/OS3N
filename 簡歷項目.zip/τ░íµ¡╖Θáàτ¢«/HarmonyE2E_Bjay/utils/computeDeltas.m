function [ delta ] = computeDeltas(dataxyY, referencexy)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


        delta = struct();
        delta.originaldataxyY = dataxyY;
        
        dataxyY(3,:) = 100;
        
        XYZdata = xyY2XYZ(dataxyY);
        
        if(size(referencexy,2)==2)
            XYZreference = xyY2XYZ([referencexy 100]');
            XYZreference = repmat(XYZreference,1,size(XYZdata,2));
        else
            referencexy(3,:) = 100;
            XYZreference = xyY2XYZ(referencexy);
        end
            
%         XYZdata(isnan(XYZdata)) = 0;
        
        XYZn = xyY2XYZ([0.3127; 0.3290; 100]);
        
        Labdata = XYZ2Lab(XYZdata,XYZn);
        Labreference = XYZ2Lab(XYZreference,XYZn);
        
        deltae = deltaE00(Labdata,Labreference);
        mdelta = mean(deltae);
        stddelta = std(deltae);
        
        
        delta.dataxyY = dataxyY;
        delta.XYZreference = XYZreference;
        delta.XYZn = XYZn;
        delta.Labdata = Labdata;
        delta.Labreference = Labreference;
        delta.deltaE00 = deltae;
        delta.meanDeltaE00 = mean(deltae);
        delta.stdDeltaE00 = std(deltae);
        delta.maxDeltaE00 = max(deltae);
        delta.threeSigmaDeltaE00 = delta.meanDeltaE00+3*std(deltae);
        
        delta.meanDeltaE00+3*std(deltae);
        
end

