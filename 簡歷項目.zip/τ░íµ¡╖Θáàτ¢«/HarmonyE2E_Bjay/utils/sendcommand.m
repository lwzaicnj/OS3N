function [status, result] = sendCommand(command)
    camtoolstr = sprintf('/usr/local/bin/camtool -a run_command "%s"', command);
    %[status, result] = system(cat(2, '/usr/local/bin/camtool -a run_command "ls -l"'))
    [status, result] = system(camtoolstr);
%     lines = strsplit(result, '\n')';
%     result = lines(2:end,:);
end

