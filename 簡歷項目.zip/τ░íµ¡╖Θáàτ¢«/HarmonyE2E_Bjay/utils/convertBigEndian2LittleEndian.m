function [ out ] = convertBigEndian2LittleEndian( in )
%function [ out ] = covertBigEndian2LittleEndian( in )
%   This function converts Big Endian encoding to Little Endian, to be
%   stored in syscfg.

out = in([7 8 5 6 3 4 1 2]);

end

