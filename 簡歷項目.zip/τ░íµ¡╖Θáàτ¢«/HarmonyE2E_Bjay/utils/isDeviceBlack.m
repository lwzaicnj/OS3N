function [result] = isDeviceBlack(channel)
    commandString = 'memdump -a syscfg -r -k DClr';
    [status dclr] = sshfrommatlabissue(channel, commandString); 
    dclr = dclr{6};
    % 3rd line of output from memdump above is (for example):
    %  DClr: [HEX] 00 02 00 00 BA B7 B9 00 28 27 27 00 00 00 00 00 
    %                                      ^         ^
    % Chars 39:49 hold the little endian hex CG color values (with spaces)
    % Here are the expected values for DVT and EVT J127 in Big Endian form:
    % DVT 127: Black CG = 0x00272728, White CG = 0x00E4E7E8
    % EVT 127: Black CG = 0x003B3B3C, White CG = 0x00E1E4E3
    % see also <rdar://problem/22789845> J127/J128 DClr values
    
    switch (dclr(39:49))
        case {'28 27 27 00', '3C 3B 3B 00'}
            result = 1;    % black unit
        case {'E8 E7 E4 00', 'E3 E4 E1 00'}
            result = 0;   % white unit
        otherwise
            result = -1; 
            if isdeployed()
                disp(cat(2, 'Unit DClr key not recognized: ', dclr));
                exit(8);
            else
                disp('ERROR: unit color not parsed correctly. Assuming white as default:');
                disp(dclr)
                result = 0; 
                return
            end        
    end
end    