function[] = setCompensation( channel, comp )
% comp(1) = backlight compensation bool 
% comp(2) = temperature compensation bool 
    backlightCompCmd = cat(2, 'clcdControl --brightness_compensation_enable=', num2str(comp(1)));
    tempCompCmd = cat(2, 'clcdControl --temperature_compensation_enable=', num2str(comp(2)));
    
    % TODO Should we care about a return variable/flag here for error
    % checking
    sshfrommatlabissue_dontwait(channel, backlightCompCmd);
    sshfrommatlabissue_dontwait(channel, tempCompCmd);
end