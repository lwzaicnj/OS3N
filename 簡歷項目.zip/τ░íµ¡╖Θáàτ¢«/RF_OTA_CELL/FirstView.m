//
//  FirstView.m
//  RF_OTA_CELL
//
//  Created by apple on 12/14/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "FirstView.h"

static FirstView *firstView;

@interface FirstView ()

@end

@implementation FirstView

+(id)shareFirst{
    
    if (firstView == nil) {
        firstView = [[FirstView alloc]init];
    }
    return firstView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(371, 324);
    
    _imageView.image =image;
}

- (IBAction)dailyAndBreakdown:(id)sender {
    
    DailyModel *secondView = [DailyModel shareDailyModel];
    [self.view.window.contentViewController addChildViewController:secondView];
    self.view.window.contentView = secondView.view;
    
}

- (IBAction)stationCalAndVal:(id)sender {
    
    DailyModel *secondView = [DailyModel shareDailyModel];
    [self.view.window.contentViewController addChildViewController:secondView];
    self.view.window.contentView = secondView.view;
}

- (IBAction)dataComparison:(id)sender {
    
    DataComModel *secondView = [DataComModel shareDataModel];
    [self.view.window.contentViewController addChildViewController:secondView];
    self.view.window.contentView = secondView.view;
}

- (IBAction)corralation:(id)sender {
    
    CorralationModel *secondView = [CorralationModel shareCorrModel];
    [self.view.window.contentViewController addChildViewController:secondView];
    self.view.window.contentView = secondView.view;
}


- (IBAction)goldenSelection:(id)sender {
    
    GoldenSelModel *secondView = [GoldenSelModel shareGoldModel];
    [self.view.window.contentViewController addChildViewController:secondView];
    self.view.window.contentView = secondView.view;
}

@end
