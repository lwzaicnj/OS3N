//
//  GoldenSelModel.m
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "GoldenSelModel.h"

static GoldenSelModel *goldenModel;

@interface GoldenSelModel ()

@end

@implementation GoldenSelModel

+(id)shareGoldModel{
    if(goldenModel == nil)
        goldenModel = [[GoldenSelModel alloc]init];
    return goldenModel;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(371, 324);
    
    _imageView.image =image;
    
}

@end
