//
//  DailyModel.h
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FirstView.h"

@interface DailyModel : NSViewController


@property (weak) IBOutlet NSImageView *imageView;


- (IBAction)wifiView:(id)sender;

- (IBAction)ratView:(id)sender;

+(id)shareDailyModel;

@end
