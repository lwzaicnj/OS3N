//
//  DataComModel.m
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "DataComModel.h"

static DataComModel *dataView;

@interface DataComModel ()

@end

@implementation DataComModel

+(id)shareDataModel{
    
    if (dataView == nil) {
        dataView = [[DataComModel alloc]init];
    }
    return dataView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(371, 324);
    
    _imageView.image =image;
    
}

@end
