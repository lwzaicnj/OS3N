//
//  BreakDownModel.m
//  RF_OTA_CELL
//
//  Created by apple on 12/6/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "BreakDownModel.h"

@implementation BreakDownModel

@synthesize vendor;
@synthesize color;
@synthesize wifi;
@synthesize housing;

@end
