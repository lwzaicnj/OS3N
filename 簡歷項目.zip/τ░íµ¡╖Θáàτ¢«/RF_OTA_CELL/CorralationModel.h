//
//  CorralationModel.h
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CorralationModel : NSViewController

@property (weak) IBOutlet NSImageView *imageView;


+(id)shareCorrModel;

@end
