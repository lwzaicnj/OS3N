//
//  BreakDownModel.h
//  RF_OTA_CELL
//
//  Created by apple on 12/6/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BreakDownModel : NSObject{
    
    NSString *vendor;
    NSString *color;
    NSString *wifi;
    NSString *housing;
}

@property (readwrite, copy) NSString *vendor;
@property (readwrite, copy) NSString *color;
@property (readwrite, copy) NSString *wifi;
@property (readwrite, copy) NSString *housing;

@end
