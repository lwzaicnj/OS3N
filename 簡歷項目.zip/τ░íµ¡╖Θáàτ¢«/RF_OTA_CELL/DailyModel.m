//
//  DailyModel.m
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "DailyModel.h"
#import "ChartProcess.h"
#import "OTA_CELL.h"
#import "RatReport.h"


static DailyModel *modeView;

@interface DailyModel ()

@end

@implementation DailyModel


- (IBAction)wifiView:(id)sender {
    
    ChartProcess *firstView = [ChartProcess shareChartProcess];
    [self.view.window.contentViewController addChildViewController:firstView];
    self.view.window.contentView = firstView.view;
}

- (IBAction)ratView:(id)sender {
    
    RatReport *rat = [RatReport shareRat];
    self.view.window.contentView = rat.view;
}

+(id)shareDailyModel{
    
    if (modeView == nil)
        modeView = [[DailyModel alloc]init];
    return modeView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(371, 324);
    
    _imageView.image =image;
    
}


    
   
    
@end
