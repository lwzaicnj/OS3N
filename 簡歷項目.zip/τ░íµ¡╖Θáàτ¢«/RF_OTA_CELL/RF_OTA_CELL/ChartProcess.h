//
//  ChartProcess.h
//  RF_OTA
//
//  Created by apple on 10/6/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ChartProcess : NSViewController<NSTableViewDelegate,NSTableViewDataSource>{
    
    NSMutableArray *tableDataArray;
    IBOutlet NSTableView *tableView;
}

@property (weak) IBOutlet NSTextField *summaryDataPath;
@property (unsafe_unretained) IBOutlet NSTextView *ShowLog;


@property (weak) IBOutlet NSButton *configSelected;

@property (weak) IBOutlet NSPopUpButton *txLimit;
@property (weak) IBOutlet NSPopUpButton *evmLimit;

@property (weak) IBOutlet NSImageView *imageView;


//三個組合
@property (weak) IBOutlet NSPopUpButton *breakdown1;
@property (weak) IBOutlet NSPopUpButton *breakdown2;
@property (weak) IBOutlet NSPopUpButton *breakdown3;
@property (weak) IBOutlet NSPopUpButton *breakdown4;


- (IBAction)breakdownCombine:(id)sender;
- (IBAction)breakDownDelete:(id)sender;

- (IBAction)selectSummPath:(id)sender;
- (IBAction)generate:(id)sender;


- (IBAction)switchView:(id)sender;
- (IBAction)insertView:(id)sender;
+ (instancetype)shareChartProcess;

@end
