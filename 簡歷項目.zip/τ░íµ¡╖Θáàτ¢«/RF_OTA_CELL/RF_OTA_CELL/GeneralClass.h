//
//  GeneralClass.h
//  RF_OTA_CELL
//
//  Created by apple on 10/26/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface GeneralClass : NSObject

+ (NSString *)selectPathType:(NSArray *)fileType;
+ (NSString *)removeSpaceEffect:(NSString *)orignal;
+ (void)showLog:(NSString *)logString inTextView:(NSTextView *)textView;
+ (void)showSheetWindow:(NSString *)message;
+ (NSString *)returnStandardPath:(NSInteger)flag;

@end
