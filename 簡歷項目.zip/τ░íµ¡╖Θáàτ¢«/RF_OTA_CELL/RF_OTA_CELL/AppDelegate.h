//
//  AppDelegate.h
//  RF_OTA_CELL
//
//  Created by apple on 10/22/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate,NSWindowDelegate>
    

@property (weak) IBOutlet NSWindow *window;


@end

