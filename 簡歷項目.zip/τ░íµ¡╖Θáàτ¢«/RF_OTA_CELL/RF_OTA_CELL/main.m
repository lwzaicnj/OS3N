//
//  main.m
//  RF_OTA_CELL
//
//  Created by apple on 10/22/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
