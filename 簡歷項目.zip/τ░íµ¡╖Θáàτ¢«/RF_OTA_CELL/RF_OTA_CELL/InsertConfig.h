//
//  InsertConfig.h
//  RF_OTA
//
//  Created by apple on 10/6/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface InsertConfig : NSViewController

@property (weak) IBOutlet NSTextField *OtaRawPath;
@property (weak) IBOutlet NSTextField *AntenInfoPath;
@property (weak) IBOutlet NSTextField *AddedItem;
@property (unsafe_unretained) IBOutlet NSTextView *ShowLog;


- (IBAction)OtaDataSelect:(id)sender;
- (IBAction)AntenIfoSelect:(id)sender;
- (IBAction)Run:(id)sender;

@property (weak) IBOutlet NSImageView *imageView;

- (IBAction)changView:(id)sender;
- (IBAction)changRat:(id)sender;

+ (instancetype)shareInsertConfig;



@end
