//
//  RatReport.h
//  RF_OTA_CELL
//
//  Created by apple on 12/16/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RatReport : NSViewController<NSTableViewDelegate,NSTableViewDataSource>{
    
    IBOutlet NSTableView *tableView;
    
     NSMutableArray *tableDataArray;
}

+(id)shareRat;

@property (weak) IBOutlet NSTextField *sumamaryPath;
@property (weak) IBOutlet NSTextField *frequnecyPath;
@property (weak) IBOutlet NSPopUpButton *limit;
@property (unsafe_unretained) IBOutlet NSTextView *showLog;

@property (weak) IBOutlet NSImageView *imageView;

- (IBAction)selectSummary:(id)sender;
- (IBAction)selectFrequency:(id)sender;

- (IBAction)generate:(id)sender;

- (IBAction)breakdownCombine:(id)sender;
- (IBAction)breakDownDelete:(id)sender;

- (IBAction)backMain:(id)sender;
- (IBAction)insertView:(id)sender;



@property (weak) IBOutlet NSPopUpButton *breakDown1;
@property (weak) IBOutlet NSPopUpButton *breakDown2;
@property (weak) IBOutlet NSPopUpButton *breakDown3;
@property (weak) IBOutlet NSPopUpButton *breakDown4;

@end
