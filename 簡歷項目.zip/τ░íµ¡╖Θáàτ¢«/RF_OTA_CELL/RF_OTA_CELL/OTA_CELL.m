//
//  OTA_CELL.m
//  RF_OTA_CELL
//
//  Created by apple on 10/22/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "OTA_CELL.h"
#import "InsertConfig.h"
#import "GeneralClass.h"

@interface OTA_CELL ()

@end

static OTA_CELL *thirdView;

@implementation OTA_CELL

+ (id)shareOTA_CELL{
    if (thirdView == nil) {
        thirdView = [[OTA_CELL alloc]init];
    }
    return thirdView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [_showLog setEditable:NO];
    [_limitSelect selectItemAtIndex:0];
}

- (IBAction)changeToInsertConfig:(id)sender {
    
    InsertConfig *firstView = [InsertConfig shareInsertConfig];
    [self.view.window.contentViewController addChildViewController:firstView];
    self.view.window.contentView = firstView.view;
}

- (IBAction)selectConfig:(id)sender {
    
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"xlsx", nil];
    [_configSelect setStringValue:[GeneralClass selectPathType:fileType]];
}

- (IBAction)selectFrequency:(id)sender {
    
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"csv", nil];
    [_frequencySelect  setStringValue:[GeneralClass selectPathType:fileType]];
}

- (IBAction)run:(id)sender {
    
    NSString *sumPath = [_configSelect stringValue];
    NSString *outputPath = [GeneralClass returnStandardPath:0];
    NSString *frePath = [_frequencySelect stringValue];
    
    NSString *limit =  _limitSelect.title;
    
    sumPath = [GeneralClass removeSpaceEffect:sumPath];
    outputPath = [GeneralClass removeSpaceEffect:outputPath];
    frePath = [GeneralClass removeSpaceEffect:frePath];
    
    if ([sumPath isEqualToString:@"\"\""] || [frePath isEqualToString:@"\"\""])
    {
        [GeneralClass showSheetWindow:@"Please complete the path selected!"];
        [GeneralClass showLog:@"Pls set path correctly!!!" inTextView:_showLog];
        return;
    }
    
    NSString *pyPath = [NSHomeDirectory()stringByAppendingString:@"/SWCode/ota_cell.py"];
    
    NSString *errorpath = [GeneralClass returnStandardPath:1];
    
    NSFileHandle  *fileHandle = [NSFileHandle fileHandleForWritingAtPath:errorpath];
    [fileHandle truncateFileAtOffset:0];
    
    NSString *pythonRun=[NSString stringWithFormat:@"python %@ %@ %@ %@ %@",pyPath,sumPath,outputPath,frePath,limit];
    pythonRun = [pythonRun stringByAppendingString:@" 2>"];
    pythonRun = [pythonRun stringByAppendingString:errorpath];
    system([pythonRun UTF8String]);
    
//    NSLog(@"%@",pythonRun);
    
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:errorpath];
    NSData *data;
    if (fh != nil)
        data = [fh readDataToEndOfFile];
    
    NSString *content = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    if(![content isEqualToString:@""])
        [GeneralClass showLog:content inTextView:_showLog];
    else
        [GeneralClass showLog:@"Python produced excel successful!" inTextView:_showLog];

    
}
@end













