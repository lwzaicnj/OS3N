//
//  InsertConfig.m
//  RF_OTA
//
//  Created by apple on 10/6/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "InsertConfig.h"
#import "ChartProcess.h"
#import "OTA_CELL.h"
#import "GeneralClass.h"
#import "RatReport.h"


static InsertConfig *secondView;

@interface InsertConfig ()

@end

@implementation InsertConfig

+ (instancetype)shareInsertConfig{
    if (secondView == nil) {
        secondView = [[InsertConfig alloc]init];
    }
    return secondView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [_ShowLog setEditable:NO];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(576, 382);
    
    _imageView.image =image;
    
    [self creatTmpFile];
}


- (IBAction)changView:(id)sender {
    
    ChartProcess *firstView = [ChartProcess shareChartProcess];
    [self.view.window.contentViewController addChildViewController:firstView];
    self.view.window.contentView = firstView.view;
    
//    ViewController *a = [[ViewController alloc]initWithNibName:@"MainMenu" bundle:nil];
//    [self.view.window.contentViewController addChildViewController:a];
//    self.view.window.contentView = a.view;
    
}

- (IBAction)changRat:(id)sender {
    
    RatReport *rat = [RatReport shareRat];
    self.view.window.contentView = rat.view;
}


- (void)creatTmpFile{
    
    NSString *tmpdir = [NSHomeDirectory() stringByAppendingString:@"/SWCode/suporting_files"];
    NSString *tmpFile = [tmpdir stringByAppendingPathComponent:@"tmpFile.txt"];
    NSFileManager *fm = [NSFileManager defaultManager];
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:tmpFile];
    
    if (![fm fileExistsAtPath:tmpdir])
        [fm createDirectoryAtPath:tmpdir withIntermediateDirectories:YES attributes:nil error:NULL];
    
    if ([fm fileExistsAtPath:tmpFile] == NO)
        [fm createFileAtPath:tmpFile contents:nil attributes:nil];
    else{
        NSData *data;
        if (fileHandle != nil)
            data = [fileHandle readDataToEndOfFile];
        
        NSString *contents = [[NSString alloc]initWithData:data encoding:NSUnicodeStringEncoding];
        
        [_AddedItem setStringValue:contents];
        
        [GeneralClass showLog:@"Show items successful!" inTextView:_ShowLog];
        
    }
}


- (IBAction)OtaDataSelect:(id)sender {
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"csv", nil];
    [_OtaRawPath setStringValue:[GeneralClass selectPathType:fileType]];
    [_OtaRawPath setEditable:NO];
}

- (IBAction)AntenIfoSelect:(id)sender {
    
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"xlsx", nil];
    [_AntenInfoPath setStringValue:[GeneralClass selectPathType:fileType]];
    [_AntenInfoPath setEditable:NO];
}


- (IBAction)Run:(id)sender {
    
    [GeneralClass showLog:@"Start insert items!" inTextView:_ShowLog];
    
    NSString *rawPath = [_OtaRawPath stringValue];
    NSString *infoPath = [_AntenInfoPath stringValue];
    NSString *outputPath = [GeneralClass returnStandardPath:0];
    NSString *addItem = [_AddedItem stringValue];
    
    rawPath = [GeneralClass removeSpaceEffect:rawPath];
    infoPath = [GeneralClass removeSpaceEffect:infoPath];
    outputPath = [GeneralClass removeSpaceEffect:outputPath];
    addItem = [GeneralClass removeSpaceEffect:addItem];
    
    if ([rawPath isEqualToString:@"\"\""] || [infoPath isEqualToString:@"\"\""])
    {
        
        [GeneralClass showSheetWindow:@"Please complete the path selected!"];
        [GeneralClass showLog:@"Pls set path correctly!!!" inTextView:_ShowLog];
        return;
    }
    
    NSString *pyPath = [NSHomeDirectory()stringByAppendingString:@"/SWCode/insertConfig.py"];
    
    NSString *errorpath = [GeneralClass returnStandardPath:1];
    
    NSFileHandle  *fileHandle = [NSFileHandle fileHandleForWritingAtPath:errorpath];
    [fileHandle truncateFileAtOffset:0];
    
    NSString *pythonRun=[NSString stringWithFormat:@"python %@ %@ %@ %@ %@",pyPath,rawPath,infoPath,outputPath,addItem];
    
    pythonRun = [pythonRun stringByAppendingString:@" 2>"];
    pythonRun = [pythonRun stringByAppendingString:errorpath];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) , ^{
        system([pythonRun UTF8String]);
        NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:errorpath];
        NSData *data;
        if (fh != nil)
            data = [fh readDataToEndOfFile];
        
        NSString *content = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if(![content isEqualToString:@""])
                [GeneralClass showLog:content inTextView:_ShowLog];
            else
                [GeneralClass showLog:@"Python insert items successful!" inTextView:_ShowLog];
        });
        
    });
}

- (void)viewDidDisappear{
    
    NSString *content = [_AddedItem stringValue];
    
    NSData *data = [content dataUsingEncoding:NSUnicodeStringEncoding];
    
    NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"SWCode/tmpFile.txt"];
    NSFileHandle  *fileHandle = [NSFileHandle fileHandleForWritingAtPath:path];
    [fileHandle truncateFileAtOffset:0];
    [fileHandle writeData:data];
}





@end
