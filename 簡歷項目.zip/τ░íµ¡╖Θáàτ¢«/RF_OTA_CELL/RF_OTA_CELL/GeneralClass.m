//
//  GeneralClass.m
//  RF_OTA_CELL
//
//  Created by apple on 10/26/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "GeneralClass.h"

@implementation GeneralClass

+ (NSString *)selectPathType:(NSArray *)fileType{
    
    dispatch_queue_t serialQueue = dispatch_queue_create("aSerialQueue", DISPATCH_QUEUE_CONCURRENT);
    
    __block NSString *path=@"";
    
    dispatch_sync(serialQueue, ^(){
        
        NSOpenPanel *panel = [NSOpenPanel openPanel];
        [panel setCanChooseDirectories:NO];
        [panel setCanCreateDirectories:YES];
        [panel setAllowsMultipleSelection:NO];
        [panel setCanChooseFiles:YES];
        if (fileType.count != 0) {
            [panel setAllowedFileTypes:fileType];
        }

        
        NSInteger result = [panel runModal];
        
        if (result == NSFileHandlingPanelOKButton)
        {
            NSArray *select_files = [panel URLs] ;
            path= [[select_files objectAtIndex:0] absoluteString];
            path = [[path substringFromIndex:7] stringByRemovingPercentEncoding];
        }
        else if(result == NSFileHandlingPanelCancelButton) path = @"";
    });
    
    return path;
}

+ (void)showLog:(NSString *)logString inTextView:(NSTextView *)textView{
    NSString *strAppLog = nil;
    NSString* date;
    NSDateFormatter* formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"]; //HH 大寫就是 24進制
    date = [formatter stringFromDate:[NSDate date]];
    
    strAppLog = [NSString stringWithFormat:@"[%@] %@  \n",date,logString];
    
    [[[textView textStorage] mutableString] appendString:strAppLog];
    [textView scrollRangeToVisible:NSMakeRange([[textView string] length], 0)];
}

+ (void)showSheetWindow:(NSString *)message{
    
    NSAlert *alert = [[NSAlert alloc] init];
    [alert setAlertStyle:NSInformationalAlertStyle];
    [alert setMessageText:message];
    [alert addButtonWithTitle:@"OK"];
    [alert runModal];
    
}

+ (NSString *)removeSpaceEffect:(NSString *)orignal{
    
    orignal = [@"\"" stringByAppendingString:orignal];
    orignal = [orignal stringByAppendingString:@"\""];
    return orignal;
}

+ (NSString *)returnStandardPath:(NSInteger)flag{
    
    if(flag == 0)
        return [NSHomeDirectory() stringByAppendingString:@"/Desktop"];
    else
        return [NSHomeDirectory() stringByAppendingString:@"/SWCode/suporting_files/error"];
}

@end