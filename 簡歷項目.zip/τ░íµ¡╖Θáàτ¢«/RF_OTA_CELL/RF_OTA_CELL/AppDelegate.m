//
//  AppDelegate.m
//  RF_OTA_CELL
//
//  Created by apple on 10/22/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "AppDelegate.h"
#import "FirstView.h"


static AppDelegate* home;

@interface AppDelegate ()


@end

@implementation AppDelegate


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
    FirstView *first = [FirstView shareFirst];
    self.window.contentView = first.view;
    
    _window.delegate =self;
    
}

- (BOOL)windowShouldClose:(id)sender{
    
    [[NSApplication sharedApplication] terminate:nil];
    return YES;
}




@end
