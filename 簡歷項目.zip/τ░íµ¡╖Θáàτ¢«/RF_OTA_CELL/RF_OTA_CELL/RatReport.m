//
//  RatReport.m
//  RF_OTA_CELL
//
//  Created by apple on 12/16/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "RatReport.h"
#import "GeneralClass.h"
#import "BreakDownModel.h"
#import "FirstView.h"
#import "InsertConfig.h"

static RatReport *rat;

@interface RatReport ()

@end

@implementation RatReport

+(id)shareRat{
    
    if (rat == nil) {
        rat = [[RatReport alloc]init];
    }
    return rat;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [_breakDown1 selectItemAtIndex:0];
    [_breakDown2 selectItemAtIndex:0];
    [_breakDown3 selectItemAtIndex:0];
    [_breakDown4 selectItemAtIndex:0];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(544, 426);
    
    _imageView.image =image;
    
    [_limit selectItemAtIndex:0];
    
}

- (id) init {
    self = [super init];
    if(self){
        tableDataArray = [NSMutableArray new];
    }
    return self;
}

- (IBAction)breakdownCombine:(id)sender{
    
    BreakDownModel *tableData = [BreakDownModel new];
    NSString *break1 = _breakDown1.title;
    NSString *break2 = _breakDown2.title;
    NSString *break3 = _breakDown3.title;
    NSString *break4 = _breakDown4.title;
    
    if (!break1 || !break2 || !break3 || !break4) {
        
        [GeneralClass showSheetWindow:@"Pls select the BreakDown!"];
        return;
    }
    
    //不添加重複項
    for (NSInteger i=0; i<tableDataArray.count; i++) {
        
        BreakDownModel *data = [tableDataArray objectAtIndex:i];
        if ([data.vendor isEqualToString:break1] && [data.color isEqualToString:break2] && [data.wifi isEqualToString:break3] && [data.housing isEqualToString:break4]) {
            
            return;
        }
//        else if ([data.vendor isEqualToString:break1] && [data.color isEqualToString:break3] && [data.wifi isEqualToString:break2]) {
//            
//            return;
//        }
//        else if ([data.vendor isEqualToString:break2] && [data.color isEqualToString:break1] && [data.wifi isEqualToString:break3]) {
//            
//            return;
//        }
//        else if ([data.vendor isEqualToString:break2] && [data.color isEqualToString:break3] && [data.wifi isEqualToString:break1]) {
//            
//            return;
//        }
//        else if ([data.vendor isEqualToString:break3] && [data.color isEqualToString:break2] && [data.wifi isEqualToString:break1]) {
//            
//            return;
//        }
//        else if ([data.vendor isEqualToString:break3] && [data.color isEqualToString:break1] && [data.wifi isEqualToString:break2]) {
//            
//            return;
//        }
    }
    
    //三個之間重複
    if ((![break1 isEqualToString:@"None"] && [break1 isEqualToString:break3]) || (![break1 isEqualToString:@"None"] && [break1 isEqualToString:break2]) || (![break2 isEqualToString:@"None"] && [break2 isEqualToString:break3]) || (![break1 isEqualToString:@"None"] && [break1 isEqualToString:break4]) || (![break2 isEqualToString:@"None"] && [break2 isEqualToString:break4]) || (![break3 isEqualToString:@"None"] && [break3 isEqualToString:break4])){
        
        [GeneralClass showSheetWindow:@"Repeated selection!"];
        return;
    }
    
    [tableData setVendor:break1];
    [tableData setColor:break2];
    [tableData setWifi:break3];
    [tableData setHousing:break4];
    
    [tableDataArray addObject:tableData];
    [tableView noteNumberOfRowsChanged];

}

- (IBAction)breakDownDelete:(id)sender{
    
    if([tableView selectedRow]>=0){
        [tableDataArray removeObjectAtIndex:[tableView selectedRow]];
        [tableView reloadData];
    }
}

- (IBAction)backMain:(id)sender {
    
    FirstView *firstView = [FirstView shareFirst];
    [self.view.window.contentViewController addChildViewController:firstView];
    self.view.window.contentView = firstView.view;
}

- (IBAction)insertView:(id)sender {
    
//    NSButton *button = (NSButton *)sender;
//    NSLog(@"that is %@",button.title);
    InsertConfig *insertView = [InsertConfig shareInsertConfig];
    self.view.window.contentView = insertView.view;
}

- (IBAction)selectSummary:(id)sender {
    
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"xlsx", nil];
    [_sumamaryPath setStringValue:[GeneralClass selectPathType:fileType]];
}

- (IBAction)selectFrequency:(id)sender {
    
    NSArray* fileType = [[NSArray alloc] initWithObjects:@"xlsx", nil];
    [_frequnecyPath  setStringValue:[GeneralClass selectPathType:fileType]];
}

- (IBAction)generate:(id)sender {
    
    NSString *breakDownList = @"";
    
    for (NSInteger i = 0; i < [tableDataArray count]; i++) {
        
        BreakDownModel *m = [tableDataArray objectAtIndex:i];
        NSString *oneBreakDown = [NSString stringWithFormat:@"%@-%@-%@-%@,",m.vendor,m.color,m.wifi,m.housing];
        breakDownList = [breakDownList stringByAppendingString:oneBreakDown];
    }
    
    [GeneralClass showLog:@"Python start produced excel!" inTextView:_showLog];
    
    NSString *sumPath = [_sumamaryPath stringValue];
    NSString *outputPath = [GeneralClass returnStandardPath:0];
    NSString *frePath = [_frequnecyPath stringValue];
    NSString *limit = _limit.title;
    
    sumPath = [GeneralClass removeSpaceEffect:sumPath];
    outputPath = [GeneralClass removeSpaceEffect:outputPath];
    frePath = [GeneralClass removeSpaceEffect:frePath];
    
    if ([sumPath isEqualToString:@"\"\""])
    {
        [GeneralClass showSheetWindow:@"Please complete the path selected!"];
        [GeneralClass showLog:@"Pls set path correctly!!!" inTextView:_showLog];
        return;
    }
    
    NSString *pyPath = [NSHomeDirectory()stringByAppendingString:@"/SWCode/ota_rat.py"];
    
    NSString *errorpath = [GeneralClass returnStandardPath:1];
    
    NSFileHandle  *fileHandle = [NSFileHandle fileHandleForWritingAtPath:errorpath];
    [fileHandle truncateFileAtOffset:0];
    
    NSString *pythonRun=[NSString stringWithFormat:@"python %@ %@ %@ %@ %@ %@",pyPath,sumPath,outputPath,frePath,limit,breakDownList];
    pythonRun = [pythonRun stringByAppendingString:@" 2>"];
    pythonRun = [pythonRun stringByAppendingString:errorpath];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) , ^{
        system([pythonRun UTF8String]);
        
        NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:errorpath];
        NSData *data;
        if (fh != nil)
            data = [fh readDataToEndOfFile];
        
        NSString *content = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        
        dispatch_async(dispatch_get_main_queue(),^{
            if(![content isEqualToString:@""])
                [GeneralClass showLog:content inTextView:_showLog];
            else
                [GeneralClass showLog:@"Python produced excel successful!" inTextView:_showLog];
        });
    });
}

#pragma mark Table view dataSource methods
- (NSInteger)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [tableDataArray count];
}

//返回對應的行下對應的列(根據 identifier)
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn
            row:(NSInteger)rowIndex
{
    if(![tableDataArray count])
    {
        return nil;
    }
    NSString *identifier = [aTableColumn identifier];
    
    BreakDownModel *td = [tableDataArray objectAtIndex:rowIndex];
    
    return [td valueForKey:identifier];
}

//設置對應行（再拆分列）的值
- (void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
    NSString *identifier = [aTableColumn identifier];
    BreakDownModel *td = [tableDataArray objectAtIndex:rowIndex];
    [td setValue:anObject forKey:identifier];
}

//根據給定排序進行 reload
- (void)tableView:(NSTableView *)theTableView sortDescriptorsDidChange:(NSArray *)oldDescriptors
{
    //[tableView sortDescriptors] :默認當前排序
    [tableDataArray sortUsingDescriptors:[tableView sortDescriptors]];
    [tableView reloadData];
}

-(NSInteger)getRowCount
{
    return [tableDataArray count];
}


@end















