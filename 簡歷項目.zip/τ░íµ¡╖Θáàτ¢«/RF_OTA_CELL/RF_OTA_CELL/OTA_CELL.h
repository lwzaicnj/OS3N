//
//  OTA_CELL.h
//  RF_OTA_CELL
//
//  Created by apple on 10/22/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface OTA_CELL : NSViewController

+ (id)shareOTA_CELL;

@property (weak) IBOutlet NSTextField *configSelect;
@property (weak) IBOutlet NSTextField *frequencySelect;


@property (weak) IBOutlet NSPopUpButton *limitSelect;
@property (unsafe_unretained) IBOutlet NSTextView *showLog;


- (IBAction)selectConfig:(id)sender;
- (IBAction)selectFrequency:(id)sender;
- (IBAction)run:(id)sender;




@end
