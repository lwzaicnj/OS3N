//
//  FirstView.h
//  RF_OTA_CELL
//
//  Created by apple on 12/14/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DailyModel.h"
#import "DataComModel.h"
#import "CorralationModel.h"
#import "GoldenSelModel.h"

@interface FirstView : NSViewController

@property (weak) IBOutlet NSImageView *imageView;

- (IBAction)dailyAndBreakdown:(id)sender;
- (IBAction)stationCalAndVal:(id)sender;
- (IBAction)dataComparison:(id)sender ;
- (IBAction)corralation:(id)sender;
- (IBAction)goldenSelection:(id)sender;

+(id)shareFirst;

@end
