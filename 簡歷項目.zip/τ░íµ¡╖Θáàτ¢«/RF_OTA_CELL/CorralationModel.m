//
//  CorralationModel.m
//  RF_OTA_CELL
//
//  Created by apple on 12/13/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "CorralationModel.h"

static CorralationModel *corrModel;

@interface CorralationModel ()

@end

@implementation CorralationModel

+(id)shareCorrModel{
    
    if (corrModel == nil) {
        corrModel = [[CorralationModel alloc]init];
    }
    return corrModel;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [_imageView  setAlphaValue:0.1];
    
    NSImage *image = [NSImage imageNamed:@"ali.jpg"];
    
    image.size = NSMakeSize(371, 324);
    
    _imageView.image =image;
    
}

@end
