//
//  rootContrller.h
//  DiagFA
//
//  Created by tom on 15/11/21.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Communication.h"
#import "LuaScript.h"


@interface RootContrller : NSViewController<NSTextFieldDelegate,NSTextViewDelegate>

- (void)getStart;

@end
