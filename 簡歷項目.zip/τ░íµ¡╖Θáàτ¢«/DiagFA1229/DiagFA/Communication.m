//
//  Communication.m
//  DiagFA
//
//  Created by tom on 15/11/19.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import "Communication.h"
#import <sys/select.h>

@interface CommunicationCableToken : NSObject

//内部设置
@property (nonatomic) int ptym;
@property (nonatomic) int ptys;
@property (nonatomic) NSFileHandle *fileHandleM;
@property (nonatomic) NSFileHandle *fileHandleS;

@end

@implementation CommunicationCableToken

- (instancetype)init {
    self = [super init];
    if (self) {
        _ptym = posix_openpt(O_RDWR);//O_RDWR，要求打开偽終端主设备进行读、写 成功则返回下一个可用的PTY主设备的文件描述符，出错则返回-1
        grantpt(self.ptym);//将权限设置为：对单个所有者是读写，对组所有者是写。
        unlockpt(_ptym);//unlockpt函数用于准许对伪终端从设备的访问，从而允许应用程序打开该设备
        
        char *ptysName = ptsname(self.ptym);//ptsname函数用于在给定主伪终端设备的文件描述符时，找到 从伪终端设备 的路径名
        //路徑名類似：/dev/tty
        _ptys = open(ptysName, O_RDWR);//打開路徑，返回文件描述符
        
        _fileHandleM = [[NSFileHandle alloc]initWithFileDescriptor:_ptym];
        _fileHandleS = [[NSFileHandle alloc]initWithFileDescriptor:_ptys];
    }
    return self;
}

@end


//單例傳值初始化
Communication *sharedCommunication;

@interface Communication () {
    char buf[1024*4];
}
@property (nonatomic) dispatch_queue_t readQueue;
@property (nonatomic) dispatch_queue_t writeQueue;
@property (nonatomic) NSMutableArray *cableArray;
@property (nonatomic) NSMutableDictionary *tokenArray;
@property (nonatomic) NSMutableDictionary *taskArray;

@end

@implementation Communication

//單例傳值
+ (instancetype)sharedCommunication {
    if (sharedCommunication==nil) { sharedCommunication = [Communication new]; }
    return sharedCommunication;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _readQueue = dispatch_queue_create("Communication_readQueue", DISPATCH_QUEUE_SERIAL);
        _writeQueue = dispatch_queue_create("Communication_writeQueue", DISPATCH_QUEUE_SERIAL);
        _tokenArray = [NSMutableDictionary new];
        _taskArray = [NSMutableDictionary new];
        _cableArray = [NSMutableArray new];
        
    }
    return self;
}

//在後台打開 ，把所有合格的 path 都嘗試
- (void)addCable:(NSString*)cablePah {
    [self.cableArray addObject:cablePah];//存儲下來使用？
    
    CommunicationCableToken *token = [CommunicationCableToken new];//保存用來尋找
    [self.tokenArray setObject:token forKey:cablePah];//存字典
    
    //打開 cable
    NSTask *task = [NSTask new];
    task.standardInput = token.fileHandleS;//輸入是偽終端
    task.standardOutput = token.fileHandleS;//輸出是也是
    task.launchPath = [[NSBundle mainBundle]pathForResource:@"nanokdp" ofType:nil];//使用 NSBundle 獲取項目中的資源 把nanokdp 作為執行的路徑
    task.arguments = [[NSArray alloc] initWithObjects:@"-d", [[NSString alloc]initWithFormat:@"/dev/%@", cablePah, nil], nil];
    /*類似("-d","/dev/tty1")*/
    [self.taskArray setObject:task forKey:cablePah];
    [task launch];//以上就是在 終端運行： nanokdp路徑 ﹣d /dev/cablePah 就會選擇/dev/cablePah這個設備進行連接
}


- (void)write {
    __block int maxFd =-1;
    //key:cablePah obj:token
    [self.tokenArray enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        maxFd = maxFd > [(CommunicationCableToken*)obj ptym] ? maxFd : [(CommunicationCableToken*)obj ptym];
    }];//maxFd 要監視的文件句柄數量
    
    __block fd_set wtFdSet;
    
    while (1) {
        FD_ZERO(&wtFdSet);//将set wtFdSet的所有位置0，如set在内存中占8位则将set置为00000000
        
        [self.cableArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            CommunicationCableToken *token = [self.tokenArray objectForKey:(NSString*)obj];
            FD_SET(token.ptym,&wtFdSet);//向集合添加描述字token.ptym
            //FD_SET(sock,&rfd);     //把sock放入要测试的描述符集 就是说把sock放入了rfd里面 这样下一步调用select对rfd进行测试的时候就会测试sock了(因为我们将sock放入的rdf) 一个描述符集可以包含多个被测试的文件描述符,
        }];
        
        //P1:select监视的文件句柄数，视进程中打开的文件数而定,一般设为你要监视各文件中的最大文件号加一
        //P2:select监视的可读文件句柄集合。
        //P3: select监视的可写文件句柄集合
        //P4:select监视的异常文件句柄集合
        //P5:本次select()的超时结束时间
        //返回准备就绪的描述符数，若超时则返回0，若出错则返回-1。
        select(maxFd+1, NULL, &wtFdSet, NULL, NULL);
        //select(nfds, readfds, writefds, exceptfds, timeout)
        
        
        [self.cableArray enumerateObjectsUsingBlock:^(id cablePath, NSUInteger idx, BOOL *stop) {
            CommunicationCableToken *token = [self.tokenArray objectForKey:(NSString*)cablePath];
            //检查token.ptym是否在这个集合里面,
            if (FD_ISSET(token.ptym,&wtFdSet)) {
                NSString *str = self.stringToDev((NSString*)cablePath);//這裡調用塊，傳進參數
                if (str==nil) usleep(1000*10);
                const char *ven = [str cStringUsingEncoding:NSUTF8StringEncoding];
                //文件描述符token.ptym
                write(token.ptym, ven, [str length]); //int write(int handle, void *buf, int nbyte)
            }
        }];
    }
}

- (void)read {
    __block int maxFd =-1;
    //tokenArray 是字典 setObject:CommunicationCableToken forKey:cablePah];
    [self.tokenArray enumerateKeysAndObjectsUsingBlock:^(id key, id token, BOOL *stop) {
        maxFd = maxFd > [(CommunicationCableToken*)token ptym] ? maxFd : [(CommunicationCableToken*)token ptym]; //獲取文件描述符
    }];
    
    __block fd_set rdFdSet;
    
    while (1) {
        FD_ZERO(&rdFdSet);
        
        [self.cableArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            CommunicationCableToken *token = [self.tokenArray objectForKey:(NSString*)obj];
            FD_SET(token.ptym,&rdFdSet);
        }];
        
        select(maxFd+1, &rdFdSet, NULL, NULL, NULL);
        
        [self.cableArray enumerateObjectsUsingBlock:^(id cablePath, NSUInteger idx, BOOL *stop) {
            CommunicationCableToken *token = [self.tokenArray objectForKey:(NSString*)cablePath];
            if (FD_ISSET(token.ptym,&rdFdSet)) {
                long size_t = read(token.ptym, buf, 1024*4);
                //讀到的返回值
                NSString *dataStr = [[NSString alloc]initWithBytes:buf length:size_t encoding:NSUTF8StringEncoding];
                self.stringFromDev(cablePath, dataStr);//調用塊，實現數據接收
            }
        }];
    }
}

- (void)allCableFire {
    //dispatch_async:异步添加进任务队列，它不会做任何等待
    dispatch_async(self.readQueue, ^{
        [self read];
    });
    dispatch_async(self.writeQueue, ^{
        [self write];
    });
}
@end
