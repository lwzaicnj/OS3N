//
//  main.m
//  DiagFA
//
//  Created by tom on 15/11/10.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
