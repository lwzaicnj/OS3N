//
//  AppDelegate.m
//  DiagFA
//
//  Created by tom on 15/11/10.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import "AppDelegate.h"
#import "RootContrller.h"


@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@property (weak) IBOutlet RootContrller *rootController;

@end


@implementation AppDelegate


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
//    NSString *searchText = @"// Do any additional setup after loading the view, typically after om a nib.";
//    
//    NSRange range = [searchText rangeOfString:@"after" options:NSRegularExpressionSearch];
//    
//    NSLog(@"%ld",range.location);
    
    _window.delegate = self;
    [self.rootController getStart];

}

- (BOOL)windowShouldClose:(id)sender{
    [[NSApplication sharedApplication] terminate:nil];
    return YES;
}

@end

