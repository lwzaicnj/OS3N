//
//  LuaScript.m
//  DiagFA
//
//  Created by tom on 15/11/23.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import "LuaScript.h"
#import "LuaSrc/lapi.h"
#import "LuaSrc/lualib.h"
#import "LuaSrc/lauxlib.h"
#import "LuaSrc/lua.h"

LuaScript *luaScript;

@interface LuaScript ()

@property (nonatomic) NSMutableDictionary *luaStateArray;
@property (nonatomic) NSMutableDictionary *queueArray;
@property (nonatomic) NSMutableArray *identityArray;

@end


@implementation LuaScript

+ (instancetype)sharedLuaScript {
    if (luaScript==nil) { luaScript = [LuaScript new]; }
    return luaScript;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _luaStateArray = [NSMutableDictionary new];
        _queueArray = [NSMutableDictionary new];
        _identityArray = [NSMutableArray new];
    }
    return self;
}

// identity：[token cablePath]
- (void)addLuaerWithIdentity:(NSString *)identity {
    if ([self.identityArray containsObject:identity]) { return; }
    
    [self.identityArray addObject:identity];
    
    lua_State *lState = luaL_newstate();//Creates a new Lua state
    NSValue *lStateValue = [NSValue valueWithPointer:lState];
    [self.luaStateArray setObject:lStateValue forKey:identity];//luaStateArray:每個 cablePath 對應一個 lua 棧
    
    [self setLuaAPI:lState];//每個 lua 棧壓入等量的處理函數
    
    dispatch_queue_t queue = dispatch_queue_create([(NSString*)identity UTF8String], DISPATCH_QUEUE_SERIAL);
    //__bridge_retained（也可以使用CFBridgingRetain）将Objective-C的对象转换为Core Foundation的对象，同时将对象（内存）的管理权交给我们，后续需要使用CFRelease或者相关方法来释放对象；
    NSValue *queueValue = [NSValue valueWithPointer:(CFBridgingRetain)(queue)];
    [self.queueArray setObject:queueValue forKey:identity];
}

//把一个数据送给Lua
- (BOOL)setLuaAPI:(lua_State *)lState {
    luaL_openlibs(lState);//Opens all standard Lua libraries into the given state
    
    //其实就是函数压栈，然后设置为全局变量，这样lua就可以调用它了。
    lua_pushcfunction(lState, sysSendStr);//将一个 C 函数压入堆栈。 这个函数接收一个 C 函数指针，并将一个类型为 function 的 Lua 值 压入堆栈。当这个栈顶的值被调用时，将触发对应的 C 函数。
    lua_setglobal(lState, "sysSendStr"); //把上面函數个栈顶的值 彈出并設為這個全局變量的值
    //兩個函數一起，其实就是函数压栈，然后设置为全局变量，这样lua就可以调用它了 （在 lua 腳本上調用）
    lua_pushcfunction(lState, sysLogStr);
    lua_setglobal(lState, "sysLogStr");
    lua_pushcfunction(lState, sysReadStr);//還有在這裡實現對應的函數，不然只是定義，lua 調用為空
    lua_setglobal(lState, "sysReadStr");
    lua_pushcfunction(lState, sysUpLoadStr);
    lua_setglobal(lState, "sysUpLoadStr");
    lua_pushcfunction(lState, sysUSleep);
    lua_setglobal(lState, "sysUSleep");
    lua_pushcfunction(lState, sysAlertStr);
    lua_setglobal(lState, "sysAlertStr");
    lua_pushcfunction(lState, sysGetTime);
    lua_setglobal(lState, "sysGetTime");
    
    NSString *homeStr= NSHomeDirectory();
    
    lua_pushlstring(lState, [homeStr UTF8String], [homeStr length]);
    lua_setglobal(lState, "homePath");
    
    //luaL_dofile:Loads and runs the given file. It is defined as the following macro(宏):
    //(luaL_loadfile(L, filename) || lua_pcall(L, 0, LUA_MULTRET, 0))
    //It returns 0 if there are no errors or 1 in case of errors.
    if (luaL_dofile(lState, [[homeStr stringByAppendingString:@"/Main.lua"] UTF8String])!=0) return NO;
    return YES;
}

- (void)allLuaFire {

    [self.identityArray enumerateObjectsUsingBlock:^(id identity, NSUInteger idx, BOOL *stop) {
        NSValue *lStateValue = [self.luaStateArray objectForKey:identity];
        NSValue *queueValue = [self.queueArray objectForKey:identity];
        
        dispatch_async([queueValue pointerValue], ^{
            if (luaL_dofile([lStateValue pointerValue], [[NSHomeDirectory() stringByAppendingString:@"/Main.lua"] UTF8String])!=0) return;
            lua_getglobal([lStateValue pointerValue], "main"); //lua 入口 main函數，可以包含多個 lua 腳本
            lua_pcall([lStateValue pointerValue], 0, 0, 0);
            self.luaerDone(identity);
        });
    }];
}

- (NSString*)testLuaScript {
    lua_State *lState = luaL_newstate();
    if ([self setLuaAPI:lState]==YES) return nil; //沒有 lua 腳本 return NO
    NSString *testStr = [[NSString alloc]initWithCString:lua_tostring(lState, -1) encoding:NSUTF8StringEncoding];//提取棧頂
    lua_close(lState);
    return testStr;
}

- (void)runLuaFuncWithIdentity:(NSString*)identity withNameA:(NSString *)nameA nameB:(NSString *)nameB {
    NSValue *lStateValue = [self.luaStateArray objectForKey:identity];
    NSValue *queueValue = [self.queueArray objectForKey:identity];
    
    dispatch_async([queueValue pointerValue], ^{
        if (luaL_dofile([lStateValue pointerValue], [[NSHomeDirectory() stringByAppendingString:@"/Main.lua"] UTF8String])!=0) return;
        lua_getglobal([lStateValue pointerValue], "main");
        lua_getglobal([lStateValue pointerValue], [[nameA stringByAppendingString:nameB] UTF8String]);
        lua_getglobal([lStateValue pointerValue], [nameB UTF8String]);
        lua_pushstring([lStateValue pointerValue], [nameA UTF8String]);//把指针 s 指向的以零结尾的字符串压栈
        lua_pushstring([lStateValue pointerValue], [nameB UTF8String]);
        lua_pcall([lStateValue pointerValue], 4, 0, 0);
        self.luaerDone(identity);
    });
}

- (id)arrayOrDictionaryWithContentsOfTable:(NSString *)tableName {
    lua_State *lState = luaL_newstate();//打開Lua 生成一個棧？
    //為空就是棧為空，沒有函數  setLuaAPI生成一個 table
    if ([self setLuaAPI:lState]==NO) {
        lua_close(lState);
        return nil;
    }
    
    //在 lua 裡面實現table 的添加,在這裡會去加載的lua 腳本找對應的回調函數，函數名為 tableName
    lua_getglobal(lState, tableName.UTF8String); //把全局变量 name里（裡面含setLuaAPI：方法生成的更新棧 lState）的值压入堆栈,位於棧頂，是個 table
    if (!lua_istable(lState, -1)) //判斷是否壓棧的是一個 table
        return nil;
    return [self arrayWithStack:lState];//lua 腳本生成的序列
}

//這是剛開始，棧頂還是一個 table,name 是stationAndItem
- (id)arrayWithStack:(lua_State*)lState {
    NSMutableArray *mArray = [NSMutableArray new];
    NSMutableDictionary *mDic = [NSMutableDictionary new];
    int initialOrGetArrayOrGetDic = 0;
    id obj;
    lua_pushnil(lState);
    //lua_next() 这个函数的工作过程是：
    //1) 先从栈顶弹出一个 key
    //2) 从栈指定位置的 table(這裡是 ﹣2位置：本來的﹣1，壓入 nil 后為﹣2) 里取下一对 key-value，先将 key 入栈再将 value 入栈
    //3) 如果第 2 步成功则返回非 0 值，否则返回 0，并且不向栈中压入任何值
    
    // 第 2 步中从 table 里取出所谓“下一对 key-value”是相对于第 1 步中弹出的 key 的。table 里第一对 key-value 的前面没有数据，所以先用 lua_pushnil() 压入一个 nil 充当初始 key。
    //先判断上一个key的值（这个值放在栈顶，如果是nil，则表示当前取出的是table中第一个元素的值），然后算出当前的key，这时先把栈顶出栈，将新key进栈，最后将新key对应的值进栈。这样栈顶就是table中第一个遍历到的元素的值。用完这个值后，我们要把这个值出栈，让key在栈顶以便继续遍历。当根据上一个key值算不出下一个key值时，lua_next返回0，结束循环。
    while (lua_next(lState, -2) != 0) {
        //每一輪 lState, -2 是 key， -1是 value，然後判斷彈出的key 對應的 value 是什麼
        if (lua_istable(lState, -1)) { 
            obj = [self arrayWithStack:lState]; //迭代,返回一個 array 或 dic 當做 obj
        }else if (lua_isstring(lState, -1)) {
            obj = [NSString stringWithUTF8String:lua_tostring(lState, -1)];
        }
        
        //判斷 value
        if (initialOrGetArrayOrGetDic==0) {
            if (lua_isnumber(lState, -2)) {
                initialOrGetArrayOrGetDic = 1;
            }else if (lua_isstring(lState, -2)) {
                initialOrGetArrayOrGetDic = 2;
            }
        }
        
        if (initialOrGetArrayOrGetDic==1) {
            [mArray addObject:obj];
        }else if (initialOrGetArrayOrGetDic==2) {
            [mDic setObject:obj forKey:[NSString stringWithUTF8String:lua_tostring(lState, -2)]];
        }
        
        lua_pop(lState, 1);//弹出 value，让 key 留在栈顶，進行下一輪（壓下一個 key，再壓對應的 value）
    }//每一個接受 table 又位於棧頂
    return initialOrGetArrayOrGetDic==2 ? mDic : mArray;
}

#pragma mark - Lua接口 -

NSString *routeToCorrectObject(lua_State *lState){
    LuaScript *luaScript = [LuaScript sharedLuaScript];
    __block NSString *identity;
    //它就一个参数就是block，这个block携带了三个参数，这将要把dictionary里面的key和value每次一组传递到block
    [luaScript.luaStateArray enumerateKeysAndObjectsUsingBlock:^(id key, id lStateNumber, BOOL *stop) {
        if ([(NSValue*)lStateNumber pointerValue]==lState) {
            identity = (NSString*)key; //就是剛好尋求的那個 lua lState  kye-value
            *stop = YES;//If the block sets *stop to YES, the enumeration stops.
        }
    }];
    return identity;//Cablepath
}

//寫：從 lua 腳本獲得命令 -->從棧獲得 -->通過strFromLua存在contrllerToken.sendBuffer array -->寫操作
static int sysSendStr(lua_State *lState){
    NSLog(@"%s",__func__);
    
    NSString *identityToken = routeToCorrectObject(lState); //value 是 lua_State 類型,返回 key 是 cablepath
    const char *dataChar = lua_tostring(lState, 1);//第一個棧數據，把给定索引处的 Lua 值转换为一个 C 字符串，其實就是輸入給 lua 的命令  （取參數） lua的函數形式 sysSendStr(string)
    if (dataChar==NULL) return 0;
    NSString *dataStr = [[NSString alloc]initWithCString:dataChar encoding:NSUTF8StringEncoding];
    
    LuaScript *luaScript =[LuaScript sharedLuaScript];//單例
    luaScript.strFromLua(identityToken, dataStr);//來自 lua 的命令
    
    return 0;
}


//讀：終端讀操作獲得的返回值 --> 存放在contrllerToken.communicationStr string --> luaScript.strToLua獲得 --> lua_pushlstring壓棧 --> lua 腳本的readData()獲得
static int sysReadStr(lua_State *lState){
    NSLog(@"%s",__func__);
    
    NSString *identityToken = routeToCorrectObject(lState);
    LuaScript *luaScript =[LuaScript sharedLuaScript];
    NSString *str = luaScript.strToLua(identityToken); //string from device,就是返回的 log（communicationStr，也是通過strToLua，取得的值）
    lua_pushlstring(lState, [str UTF8String], [str length]);//把指针 s 指向的长度为 len 的字符串压栈（無參數傳遞，lua 的函數形式 sysReadStr()）
    
    return 1;//返回參數個數，壓棧的逆向數據，這裡是lua_pushlstring
}

// sysLogStr(string) ->function logResult(string)
static int sysLogStr(lua_State *lState){
    NSLog(@"%s",__func__);
    
    NSString *identityToken = routeToCorrectObject(lState);
    LuaScript *luaScript =[LuaScript sharedLuaScript];
    
    const char *resultChar = lua_tostring(lState, 1);//上一個函數把 log 壓棧，這裡取出 把给定索引处的 Lua 值转换为一个 C 字符串
    //（communicationStr，也是通過strToLua，取得的值）
    if (resultChar==NULL) return 0;
    NSString *resultStr = [[NSString alloc]initWithCString:resultChar encoding:NSUTF8StringEncoding];
    
    luaScript.logLuaStr(identityToken, resultStr);//所有 log 存放在contrllerToken.luaResultStr
    
    return 0;
}

static int sysUpLoadStr(lua_State *lState){
    NSLog(@"%s",__func__);
    
    NSString *identityToken = routeToCorrectObject(lState);
    LuaScript *luaScript =[LuaScript sharedLuaScript];
    
    luaScript.upLoadLuaStr(identityToken);
    
    return 0;
}

static int sysUSleep(lua_State *lState) {
    NSLog(@"%s",__func__);
    
    int delay = (int)lua_tointeger(lState, 1);
    usleep(delay);
    return 0;
}

static int sysAlertStr(lua_State *lState) {
    NSLog(@"%s",__func__);
    
    NSString *identityToken = routeToCorrectObject(lState);
    const char *str = lua_tostring(lState, 1);
    if (str==NULL) return 0;
    NSString *alertStr = [[NSString alloc]initWithCString:str encoding:NSUTF8StringEncoding];
    
    LuaScript *luaScript =[LuaScript sharedLuaScript];
    luaScript.luaerAlertStr(identityToken, alertStr);
    
    return 0;
}

static int sysGetTime(lua_State *lState){
    NSLog(@"%s",__func__);
    
    lua_pushnumber(lState, CFAbsoluteTimeGetCurrent());
    
    return 1;
}

@end
