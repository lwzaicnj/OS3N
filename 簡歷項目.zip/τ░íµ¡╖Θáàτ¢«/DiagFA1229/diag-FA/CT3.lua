-- Pressure Initialization
function CT3Pressure_Initialization()
	sendAndReadToSmile("sensor --listsensors")
	sendAndReadToSmile("sensor --sel pressure --init")
	logResult(" \nShould contain symbol 'OK' ")
end

-- Pressure Connectivity Test
function CT3Pressure_Connectivity_Test()
	sendAndReadToSmile("sensor --sel pressure --conntest")
	sendAndReadToSmile("sensor --sel pressure --turnoff")
	logResult(" \nShould contain symbol 'test-result: passed' ")
end

-- WV_Phosphorus_Average [90,110]
-- WV_Phosphorus_std [0.01,7]
-- WV_Phosphorus_ODR [20,30]
-- WV_Phosphorus_Temp [15,45]
-- WV_Phosphorus_Temp_std [0,0.2]
function CT3WV_Phosphorus_Average_std_ODR_Temp_TempStd()
	sendAndReadToSmile("time wait 20")
	sendAndReadToSmile("sensor --sel pressure --init")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xD0 1")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xF3 3")
	sendAndReadToSmile("sensorreg --sel pressure -r 0x80 34")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xF7 6")

	local str = sendAndReadToSmile("sensor --sel pressure --sample 1000ms --stats")
	local tempStr = string.match(str, "average: pressure.-(%-?%d+%.%d+),")
	logResult("\naverage: pressure = "..tempStr..", should in WV_Phosphorus_Average [90,110]")

	tempStr = string.match(str, "std%-dev: pressure.-(%-?%d+%.%d+),")
	logResult("\nstd-dev: pressure = "..tempStr..", should in WV_Phosphorus_std [0.01,7]")

	tempStr = string.match(str, "calculated odr.-(%-?%d+%.%d+)Hz")
	logResult("\ncalculated odr: "..tempStr..", should in WV_Phosphorus_ODR [20,30]")

	tempStr = string.match(str, "average.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp = "..tempStr..", should in WV_Phosphorus_Temp [15,45]")

	tempStr = string.match(str, "std%-dev.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp_std = "..tempStr..", should in WV_Phosphorus_Temp_std [0,0.2]")
end

-- WV_Phosphorus_Trim_Rev [0x45]
function CT3WV_Phosphorus_Trim_Rev()
	local str = sendAndReadToSmile("WV_Phosphorus_Trim_Rev")

	str = string.match(str, "0xA1 = (%w+),")
	logResult("\nthe value of 0xA1(key) is"..str..", should in WV_Phosphorus_Trim_Rev [0x45]")
end

-- WV_Phosphorus_ASIC_Average [400000,600000]
-- WV_Phosphorus_ASIC_std [0,24]
-- WV_Phosphorus_ASIC_ODR [20,30]
-- WV_Phosphorus_ASIC_Temp [400000,600000]
-- WV_Phosphorus_ASIC_Temp_std [0,670]
function CT3WV_Phosphorus_ASIC_Average_std_ODR_TempStd()
	sendAndReadToSmile("sensor --sel pressure --set asiconly true")
	sendAndReadToSmile("time wait 100")
	local str = sendAndReadToSmile("sensor --sel pressure --sample 1000ms --stats")

	local tempStr = string.match(str, "average: pressure.-(%-?%d+%.%d+),")
	logResult("\naverage: pressure = "..tempStr..", should in WV_Phosphorus_ASIC_Average [400000,600000]")

	tempStr = string.match(str, "std%-dev: pressure.-(%-?%d+%.%d+),")
	logResult("\nstd-dev: pressure = "..tempStr..", should in WV_Phosphorus_ASIC_std [0,24]")

	tempStr = string.match(str, "calculated odr.-(%-?%d+%.%d+)Hz")
	logResult("\ncalculated odr: "..tempStr..", should in WV_Phosphorus_ASIC_ODR [20,30]")

	tempStr = string.match(str, "average.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp = "..tempStr..", should in WV_Phosphorus_ASIC_Temp [400000,600000]")

	tempStrr = string.match(str, "std%-dev.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp_std = "..tempStr..", should in WV_Phosphorus_ASIC_Temp_std [0,670]")
end

function CT3Button_Test()
	alert("button test! Hold! Up! Down!")
	sendAndReadToSmile("button -h -u -d")
end

-- Mesa Load Firmware
-- Mesa Navajo Calibration
-- Mesa FBFD
function CT3Mesa_Test()
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --sel mesa --on")
	sendAndReadToSmile("touch --load_firmware")
	sendAndReadToSmile("touch --test get_sn --run")
	sendAndReadToSmile("touch --test calibrate --run")
	alert("Ready to touch home button!!!")
	sendAndReadToSmile("touch --test finger_det --run --options --exit_on_det")
	sendAndReadToSmile("touch --off")
end

-- Grape GPIO Test
function CT3Grape_GPIO_Test()
	sendAndReadToSmile("touch --sel grape")
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --on")
	sendAndReadToSmile("touch --test gpio --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Short Test
function CT3Grape_Short_Test()
	sendAndReadToSmile("smokeyshell -r")
	sendAndReadToSmile("smokey --run TouchShortsTest")
end

-- GRAPE POWER ON
function CT3GRAPE_POWER_ON()
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --on")
	sendAndReadToSmile("touch --load_firmware")
end

-- Grape Firmware version
function CT3Grape_Firmware_version()
	sendAndReadToSmile("touch -p firmware-version")
end

-- Grape Touch Opens Test
function CT3Grape_Touch_Opens_Test()
	sendAndReadToSmile("touch --test opens --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape FW Critical Error Check
function CT3Grape_FW_Critical_Error_Check()
	sendAndReadToSmile("touch --test critical --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Touch Opens Test
function CT3Grape_Offset_Test()
	sendAndReadToSmile("touch --test offset --run")
	logResult("\n Should contain symbol 'PASS' at last")
end