-- CM_Accel_Average_X
-- CM_Accel_Average_Y
-- CM_Accel_Average_Z
-- CM_Accel_std_X
-- CM_Accel_std_Y
-- CM_Accel_std_Z
-- CM_Gyro_Average_X
-- CM_Gyro_Average_Y
-- CM_Gyro_Average_Z
-- CM_Gyro_Average_Temp
-- CM_Gyro_std_X
-- CM_Gyro_std_Y
-- CM_Gyro_std_Z
-- CM_Gyro_std_Temp
function CT1CM_Accel_Gyro()
	sendAndReadToSmile("sensor --listsensors")
	sendAndReadToSmile("sensor --sel accel,gyro --init")
	sendAndReadToSmile("sensorreg -s gyro -r 0x75 1")
	sendAndReadToSmile("sensor --sel accel --set rate 200")
	sendAndReadToSmile("sensor --sel gyro --set rate 200")
	local str1 = sendAndReadToSmile("sensor --sel accel --sample 500ms --stats")
	local str2 = sendAndReadToSmile("sensor --sel gyro --sample 500ms --stats")
	sendAndReadToSmile("sensor --sel accel,gyro --turnoff", ClearAutoLog)

	local tempStr1, tempStr2, tempStr3 = string.match(str1, "average.-X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+)")
	logResult("\naverage: X = "..tempStr1..", should in CM_Accel_Average_X [-0.11,0.11]")
	logResult("\naverage: Y = "..tempStr2..", should in CM_Accel_Average_Y [-0.11,0.11]")
	logResult("\naverage: Z = "..tempStr3..", should in CM_Accel_Average_Z [0.89,1.11]\n")

	local tempStr1, tempStr2, tempStr3 = string.match(str1, "std%-dev.-X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+)")
	logResult("\nstd-dev: X = "..tempStr1..", should in CM_Accel_std_X [0.00001,0.05]")
	logResult("\nstd-dev: Y = "..tempStr2..", should in CM_Accel_std_Y [0.00001,0.05]")
	logResult("\nstd-dev: Z = "..tempStr3..", should in CM_Accel_std_Z [0.00001,0.05]\n")

	local tempStr1, tempStr2, tempStr3, tempStr4 = string.match(str2, "average: X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+).-T.-(%-?%d+%.%d+)")
	logResult("\naverage: X = "..tempStr1..", should in CM_Gyro_Average_X [-25,25]")
	logResult("\naverage: Y = "..tempStr2..", should in CM_Gyro_Average_Y [-25,25]")
	logResult("\naverage: Z = "..tempStr3..", should in CM_Gyro_Average_Z [-25,25]")
	logResult("\naverage: Temp = "..tempStr4..", should in CM_Gyro_Average_Temp [5,45]\n")

	local tempStr1, tempStr2, tempStr3, tempStr4 = string.match(str2, "std%-dev: X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+).-T.-(%-?%d+%.%d+)")
	logResult("\nstd-dev: X = "..tempStr1..", should in CM_Gyro_std_X [0.00001,1]")
	logResult("\nstd-dev: Y = "..tempStr2..", should in CM_Gyro_std_Y [0.00001,1]")
	logResult("\nstd-dev: Z = "..tempStr3..", should in CM_Gyro_std_Z [0.00001,1]")
	logResult("\nstd-dev: Temp = "..tempStr3..", should in CM_Gyro_std_Temp [0.00001,1]\n")
end

-- Compass_Average_X
-- Compass_Average_Y
-- Compass_Average_Z
-- Compass_std_X
-- Compass_std_Y
-- Compass_std_Z
-- Compass_ODR
-- Compass_Temp
function CT1Compass()
	sendAndReadToSmile("sensor --listsensors")
	sendAndReadToSmile("sensor -s compass --init")
	local str1 = sendAndReadToSmile("sensor -s compass --sample 1000ms --stats")
	sendAndReadToSmile("sensor -s compass -r 0x00 1", ClearAutoLog)

	local tempStr1, tempStr2, tempStr3, tempStr4 = string.match(str1, "average: X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+), T = (%-?%d+%.%d+)")
	logResult("\naverage: X = "..tempStr1..", should in Compass_Average_X [-1200,1200]")
	logResult("\naverage: Y = "..tempStr2..", should in Compass_Average_Y [-1200,1200]")
	logResult("\naverage: Z = "..tempStr3..", should in Compass_Average_Z [-1200,1200]")
	logResult("\naverage: Temp = "..tempStr4..", should in Compass_Temp [5,45]\n")

	local tempStr1, tempStr2, tempStr3 = string.match(str1, "std%-dev: X.-(%-?%d+%.%d+).-Y.-(%-?%d+%.%d+).-Z.-(%-?%d+%.%d+),")
	logResult("\nstd-dev: X = "..tempStr1..", should in Compass_std_X [0,0.5]")
	logResult("\nstd-dev: Y = "..tempStr2..", should in Compass_std_Y [0,0.5]")
	logResult("\nstd-dev: Z = "..tempStr3..", should in Compass_std_Z [0,0.5]\n")

	local tempStr1 = string.match(str1, "calculated odr.-(%d+%.%d+)Hz")
	logResult("\nCompass_ODR = "..tempStr1..", should in Compass_ODR [90,110]\n")
end

-- Compass_Reg0_4 [0x01 = 0x17]
function CT1Compass_Reg0_4()
	sendAndReadToSmile("sensorreg -s compass -r 0x01 3")
	logResult("\nShould contain symbol '0x01 = 0x17'")
end

-- Compass_Reg1_30 [0x0C = 0x00]
function CT1Compass_Reg1_30()
	sendAndReadToSmile("sensorreg -s compass -r 0x0C 30")
	logResult("\nShould contain symbol '0x0C = 0x00'")
end

-- Compass_RegF_8 [OK]
function CT1Compass_RegF_8()
	sendAndReadToSmile("sensorreg -s compass -r 0x04 8")
	logResult("\nShould contain symbol 'OK'")
end

-- Check E75 Clear [UNTESTED]
-- function CT1bCompass_RegF_8()
-- 	sendAndReadToSmile("sensor -s compass --turnoff")
-- 	sendAndReadToSmile("pmustat vbus")
-- 	sendAndReadToSmile("tristar --test_con_det clear")
-- 	sendAndReadToSmile("tristar --test_con_det check")
-- 	logResult("\nShould contain symbol 'UNTESTED'")
-- end

-- DBCl DTCl
function CT1DBCl_DTCl()
	sendAndReadToSmile("zerofile nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\LcmCal\\PDCA.plist")
	sendAndReadToSmile("zerofile nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\LcmCal\\Smokey.log")
	sendAndReadToSmile("smokey --run LcmCal")
end

-- Mesa Load Firmware
-- Mesa Navajo Calibration
-- Mesa FBFD
function CT1Mesa_Test()
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --sel mesa --on")
	sendAndReadToSmile("touch --load_firmware")
	sendAndReadToSmile("touch --test get_sn --run")
	sendAndReadToSmile("touch --test calibrate --run")
	alert("Ready to touch home button!!!")
	sendAndReadToSmile("touch --test finger_det --run --options --exit_on_det")
	sendAndReadToSmile("touch --off")
end