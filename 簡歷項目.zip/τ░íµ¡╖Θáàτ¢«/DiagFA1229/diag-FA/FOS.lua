function FOSALPM_Mod()
	sendAndReadToSmile("dptx --exectest alpm")
end

function FOSCOG_BERT_Test()
	sendAndReadToSmile("device -k Display@Internal -e cog_bert on 425")
end

function FOSStrobe_Cool_LED1_Test()
	sendAndReadToSmile("strobe --selectchip LM3564 --power off")
	sendAndReadToSmile("strobe --selectchip LM3564 --power on")
	sendAndReadToSmile("strobe --read 0x00 1 1")
	sendAndReadToSmile("strobe --write 0x02 0xa3")
	sendAndReadToSmile("strobe --write 0x05 0xba")
	sendAndReadToSmile("strobe --write 0x06 0x7f")
	sendAndReadToSmile("strobe --write 0x04 0xc2")
	sendAndReadToSmile("strobe --write 0x01 0x83")
end

function FOSStrobe_Warm_LED2_TEST()
	sendAndReadToSmile("strobe --selectchip LM3564 --power off")
	sendAndReadToSmile("strobe --selectchip LM3564 --power on")
	sendAndReadToSmile("strobe --read 0x00 1 1")
	sendAndReadToSmile("strobe --write 0x02 0xa3")
	sendAndReadToSmile("strobe --write 0x05 0xba")
	sendAndReadToSmile("strobe --write 0x06 0x00")
	sendAndReadToSmile("strobe --write 0x04 0xc2")
	sendAndReadToSmile("strobe --write 0x01 0x83")
end

-- function FOSPreWLEDA_123()
-- 	sendAndReadToSmile("strobe --selectchip LM3564 --power off")
-- 	sendAndReadToSmile("bl -h")
-- 	sendAndReadToSmile("pattern --fatp 4")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x4")		
-- end
-- 
-- function FOSPreWLEDA_456()
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x8")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x10")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x20")
-- end
-- 
-- function FOSPreWLEDB_123()
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x1")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x4")
-- end
-- function FOSPreWLEDB_456()
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x8")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x10")
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x2")
-- 	sendAndReadToSmile("pmurw -w 0x0604 0x20")
-- end
-- 
-- function FOSPostWLED()
-- 	sendAndReadToSmile("pmurw -w 0x0081 0x3")
-- 	sendAndReadToSmile("bl -o")
-- end

function FOSBacklight_123456()
	sendAndReadToSmile("bl -n")
	sendAndReadToSmile("bl -h")
	sendAndReadToSmile("pattern 1")

	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x1:pmurw -w 0x0B05 0x10")
	alert("Press enter button to next backlight level")

	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x2:pmurw -w 0x0B05 0x20")
	alert("Press enter button to next backlight level")

	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x4:pmurw -w 0x0B05 0x1")
	alert("Press enter button to next backlight level")

	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x8:pmurw -w 0x0B05 0x2")
	alert("Press enter button to next backlight level")

	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x10:pmurw -w 0x0B05 0x4")
	alert("Press enter button to next backlight level")
	
	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0:pmurw -w 0x0B04 0x20:pmurw -w 0x0B05 0x8")
	alert("Press enter button to next backlight level")

	sendAndReadToSmile("bl -p 100")	
end

function FOSWaterfall_Test()
	sendAndReadToSmile("pmurw -w 0x0B04 0x0:pmurw -w 0x0B05 0x0")
	sendAndReadToSmile("bl -r")
	sendAndReadToSmile("pattern --fatp 12")
	sendAndReadToSmile("bl -r")
end

function FOSDisplay_SyncRate_30Hz_for_Flicker()
	sendAndReadToSmile("display --setmode 1")
	sendAndReadToSmile("display --getmode")	
end
function FOSset_backlight_to_100_level()
	sendAndReadToSmile("bl -p 100")
end

function FOSGrey_32_Flicker_Pattern_Test()
	sendAndReadToSmile("pattern --fill 0x202020")
end

function FOSGrey_64_Flicker_Pattern_Test()
	sendAndReadToSmile("pattern --fill 0x404040")
end

function FOSGrey_127_Flicker_Pattern_Test()
	sendAndReadToSmile("pattern --fill 0x7f7f7f")
end

function FOSDisplay_SyncRate_60Hz_for_Flicker()
	sendAndReadToSmile("display --setmode 0")
	sendAndReadToSmile("display --getmode")
end

function FOSDisplay_SyncRate_Hz()
	sendAndReadToSmile("display --setmode 0")
	sendAndReadToSmile("display --getmode")
end

function FOSPattern_test_white_gray1()
	sendAndReadToSmile("dwi -l 2022")
	sendAndReadToSmile("pattern --fatp 6")
end

function FOSPattern_test_white_gray2()
	sendAndReadToSmile("pattern --fatp 7")
end

function FOSDisplay_SyncRate2_Hz()
	sendAndReadToSmile("display --setmode 0")
	sendAndReadToSmile("display --getmode")
end

function FOSPattern_Grey32_test()
	sendAndReadToSmile("pattern --fill 0x202020")
end

function FOSPattern_Grey64_test()
	sendAndReadToSmile("pattern --fill 0x404040")
end

function FOSPattern_Grey128_test()
	sendAndReadToSmile("pattern --fill 0x808080")
end

function FOSPattern_White_test()
	sendAndReadToSmile("pattern --fill 0xffffff")
end	

function FOSPattern_Black_test()
	sendAndReadToSmile("pattern --fill 0x000000")
end

function FOSPattern_Red_test()
	sendAndReadToSmile("pattern --fill 0xff0000")
end

function FOSPattern_Green_test()
	sendAndReadToSmile("pattern --fill 0x00ff00")
end

function FOSPattern_Blue_test()
	sendAndReadToSmile("pattern --fill 0x0000ff")
end

function FOSLight_Leakage_Test()
	sendAndReadToSmile("pattern 3")
end

function FOSCurtain_Leakage_Test()
	sendAndReadToSmile("pattern 3")
end

-- function FOSWhite_Pattern_test()
-- 	sendAndReadToSmile("pattern --fatp 2")
-- end

-- function FOSGray_Pattern_test_64()
-- 	sendAndReadToSmile("pattern --fatp 17")
-- end

-- function FOSGray_Pattern_test_21()
-- 	sendAndReadToSmile("pattern --fatp 16")
-- end
-- function FOSGray_Back_Pattern_Test()
-- 	sendAndReadToSmile("dwi -l 511")
-- 	sendAndReadToSmile("pattern --fatp 6")
-- end

-- function FOSWBGR_Pattern_Test()
-- 	sendAndReadToSmile("pattern --fatp 8")
-- end

-- function FOSRed_Pattern_Test()
-- 	sendAndReadToSmile("dwi -l 381")
-- 	sendAndReadToSmile("pattern --fatp 3")
-- end

-- function FOSCLCD_Pattern_test()
-- 	sendAndReadToSmile("dwi -l 511")
-- 	sendAndReadToSmile("pattern --fatp")
-- end

-- function FOSLight_Leakage_Test()
-- 	sendAndReadToSmile("pattern 3")
-- end

-- function FOSFront_Camera_DLI()
-- 	sendAndReadToSmile("camisp --find")
-- 	sendAndReadToSmile("camisp --pick front")
-- 	sendAndReadToSmile("camisp --dli")
-- end

-- function FOSBack_Camera_DLI()
-- 	sendAndReadToSmile("camisp --pick back")
-- 	sendAndReadToSmile("camisp --dli")
-- end

function FOSFront_Camera_Preview()
	sendAndReadToSmile("camisp --find")
	sendAndReadToSmile("camisp --pick front")
	sendAndReadToSmile("camisp --preview on")
	alert("Press any button to exit")
	sendAndReadToSmile("camisp --preview off")
end

function FOSBack_Camera_Preview()
	sendAndReadToSmile("camisp --preview off")
	sendAndReadToSmile("camisp --exit")
	sendAndReadToSmile("camisp --pick back")
	sendAndReadToSmile("camisp --preview on")
	alert("Press enter button to exit")
	sendAndReadToSmile("camisp --preview off")
end

