-- HP non-presented
function QT0bHP_non_presented()
	alert("unplug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("mikey --reset")
	sendAndReadToSmile("mikey --detectheadphone")
	logResult("\nShould contain symbol 'No Headphone'")
end

-- Ext. MIC non-presented
function QT0bExt_MIC_non_presented()
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o hp -r")
	sendAndReadToSmile("mikey --detectmic")
	logResult("\nShould contain symbol 'No mikey'")
end

-- Front Camera Find
-- Back Camera Find
function QT0bFront_Back_Camera_Find()
	sendAndReadToSmile("camisp --find")
	logResult("\nShould contain two symbols 'detected'")
end

-- Front Camera DLI
-- Back Camera DLI
function QT0bFront_Back_Camera_DLI()
	sendAndReadToSmile("camisp --dli")
	sendAndReadToSmile("camisp --exit")
	logResult("\nShould contain two symbols 'Pass'")
end

-- Power_on Baseband and load firmware
function QT0bPower_on_Baseband_and_load_firmware()
	sendAndReadToSmile("baseband --off")
	sendAndReadToSmile("baseband --on")
	sendAndReadToSmile("baseband --load_firmware")
	logResult("\nShould contain symbol 'Passed'")
end

-- Sim Tray Test
function QT0bSim_Tray_Test()
	sendAndReadToSmile("baseband --off", ClearAutoLog)
	sendAndReadToSmile("baseband --on", ClearAutoLog)
	sendAndReadToSmile("baseband --load_firmware", ClearAutoLog)
	sendAndReadToSmile("baseband -p")
	logResult(" \nShould contain symbol ' sim-tray-installed: \"Yes\" ' ")
end

-- Sim card check
function QT0bSim_card_checkt()
	sendAndReadToSmile("baseband --off")
	logResult(" \nShould contain symbol ' sim-tray-installed: \"No\" ' ")
end

-- Pressure Initialization
function QT0bPressure_Initialization()
	sendAndReadToSmile("sensor --listsensors")
	sendAndReadToSmile("sensor --sel pressure --init")
	logResult(" \nShould contain symbol 'OK' ")
end

-- Pressure Connectivity Test
function QT0bPressure_Connectivity_Test()
	sendAndReadToSmile("sensor --sel pressure --conntest")
	sendAndReadToSmile("sensor --sel pressure --turnoff")
	logResult(" \nShould contain symbol 'test-result: passed' ")
end

-- WV_Phosphorus_Average [90,110]
-- WV_Phosphorus_std [0.01,7]
-- WV_Phosphorus_ODR [20,30]
-- WV_Phosphorus_Temp [15,45]
-- WV_Phosphorus_Temp_std [0,0.2]
function QT0bWV_Phosphorus_Average_std_ODR_Temp_TempStd()
	sendAndReadToSmile("time wait 20")
	sendAndReadToSmile("sensor --sel pressure --init")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xD0 1")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xF3 3")
	sendAndReadToSmile("sensorreg --sel pressure -r 0x80 34")
	sendAndReadToSmile("sensorreg --sel pressure -r 0xF7 6")

	local str = sendAndReadToSmile("sensor --sel pressure --sample 1000ms --stats")
	local tempStr = string.match(str, "average: pressure.-(%-?%d+%.%d+),")
	logResult("\naverage: pressure = "..tempStr..", should in WV_Phosphorus_Average [90,110]")

	tempStr = string.match(str, "std%-dev: pressure.-(%-?%d+%.%d+),")
	logResult("\nstd-dev: pressure = "..tempStr..", should in WV_Phosphorus_std [0.01,7]")

	tempStr = string.match(str, "calculated odr.-(%-?%d+%.%d+)Hz")
	logResult("\ncalculated odr: "..tempStr..", should in WV_Phosphorus_ODR [20,30]")

	tempStr = string.match(str, "average.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp = "..tempStr..", should in WV_Phosphorus_Temp [15,45]")

	tempStr = string.match(str, "std%-dev.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp_std = "..tempStr..", should in WV_Phosphorus_Temp_std [0,0.2]")
end

-- WV_Phosphorus_Trim_Rev [0x45]
-- function QT0bWV_Phosphorus_Trim_Rev()
-- 	local str = sendAndReadToSmile("WV_Phosphorus_Trim_Rev")

-- 	str = string.match(str, "0xA1 = (%w+),")
-- 	logResult("\nthe value of 0xA1(key) is"..str..", should in WV_Phosphorus_Trim_Rev [0x45]")
-- end

-- WV_Phosphorus_ASIC_Average [400000,600000]
-- WV_Phosphorus_ASIC_std [0,24]
-- WV_Phosphorus_ASIC_ODR [20,30]
-- WV_Phosphorus_ASIC_Temp [400000,600000]
-- WV_Phosphorus_ASIC_Temp_std [0,670]
function QT0bWV_Phosphorus_ASIC_Average()
	sendAndReadToSmile("sensor --sel pressure --set asiconly true")
	sendAndReadToSmile("time wait 100")
	local str = sendAndReadToSmile("sensor --sel pressure --sample 1000ms --stats")

	local tempStr = string.match(str, "average: pressure.-(%-?%d+%.%d+),")
	logResult("\naverage: pressure = "..tempStr..", should in WV_Phosphorus_ASIC_Average [400000,600000]")

	tempStr = string.match(str, "std%-dev: pressure.-(%-?%d+%.%d+),")
	logResult("\nstd-dev: pressure = "..tempStr..", should in WV_Phosphorus_ASIC_std [0,24]")

	tempStr = string.match(str, "calculated odr.-(%-?%d+%.%d+)Hz")
	logResult("\ncalculated odr: "..tempStr..", should in WV_Phosphorus_ASIC_ODR [20,30]")

	tempStr = string.match(str, "average.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp = "..tempStr..", should in WV_Phosphorus_ASIC_Temp [400000,600000]")

	tempStrr = string.match(str, "std%-dev.-temp = (%-?%d+%.%d+)")
	logResult("\ntemp_std = "..tempStr..", should in WV_Phosphorus_ASIC_Temp_std [0,670]")
end

-- Compass Initialization [OK]
function QT0bCompass_Initialization()
	sendAndReadToSmile("sensor -l")
	sendAndReadToSmile("sensor -s compass --init")
	logResult(" \nShould contain symbol 'OK' ")
end

-- Compass Connectivity Test
function QT0bCompass_Connectivity_Test()
	sendAndReadToSmile("sensor -s compass --conntest")
	logResult(" \nShould contain symbol 'passed' ")
end

-- Compass self-test
function QT0bCompass_self_test()
	sendAndReadToSmile("sensor -s compass --turnoff")
	sendAndReadToSmile("sensor -s compass --init")
	sendAndReadToSmile("sensor -s compass -e selftest")
	logResult(" \nShould contain symbol 'passed' ")
end

-- Sensor Accelerometer Selftest
function QT0bSensor_Accelerometer_Selftest()
	sendAndReadToSmile("sensor --sel accel --init")
	sendAndReadToSmile("sensor --sel accel -e selftest")
	sendAndReadToSmile("sensor -s compass -e selftest")
	logResult(" \nShould contain symbol 'FAIL' ")
	sendAndReadToSmile("sensor --sel accel --turnoff", ClearAutoLog)
end

-- Accelerometer Interrupt
function QT0bAccelerometer_Interrupt()
	sendAndReadToSmile("sensor --sel accel --init")
	sendAndReadToSmile("sensor -s accel -p")
	logResult(" \nShould contain symbol 'FAIL' ")
	sendAndReadToSmile("sensor --sel accel --turnoff", ClearAutoLog)
end

-- Accelerometer Interrupt
function QT0bAccelerometer_Interrupt()
	sendAndReadToSmile("sensor --sel accel --init")
	sendAndReadToSmile("sensor -s accel -p")
	logResult(" \nShould contain symbol 'FAIL' ")
	sendAndReadToSmile("sensor --sel accel --turnoff", ClearAutoLog)
end

-- Gyro Init
function QT0bGyro_Init()
	sendAndReadToSmile("sensor --sel gyro --init")
	logResult(" \nShould contain symbol 'OK' ")
end

-- Gyro self test
function QT0bGyro_self_test()
	sendAndReadToSmile("sensor --s gyro --init")
	sendAndReadToSmile("sensor -s gyro -e selftest")
	logResult(" \nShould contain symbol 'passed' ")
	sendAndReadToSmile("sensor --sel gyro --turnoff", ClearAutoLog)
end

-- NTC [3027,14730]
function QT0aGyro_self_test()
	local str = sendAndReadToSmile("pmuadc --sel euphrates --read tbat")
	
	str = string.match(str, "expansion euphrates: tbat: (%-?%d+%.%d+) Ohm")
	logResult("\n"..str..", should in NTC [3027,14730]")
end

-- Battery Chem ID [0x3566||0x3584||0x3624||0x3585]
function QT0aGyro_self_test()
	sendAndReadToSmile("device -k GasGauge --get chem-id")
	logResult("\nShould contain one of symbols '0x3566' or '0x3584' or '0x3624' or '0x3585'")
end

-- Static Chem ID Checksum
-- Static DF Checksum
function QT0bStatic_Chem_ID_Checksum()
	sendAndReadToSmile("device -k GasGauge --e test_checksum")
end

-- Battery Qmax ATL
-- Battery Qmax LGC
-- Battery Qmax SNY
-- Battery Qmax SDI
function QT0bBattery_Qmax_ATL_LGC_SNY_SDI()
	sendAndReadToSmile("device -k GasGauge --get chem-capacity")
	logResult("\nValue should in Battery Qmax ATL [7161,8951]")

	sendAndReadToSmile(" ")
	sendAndReadToSmile("device -k GasGauge --get chem-capacity")
	logResult("\nValue should in Battery Qmax LGC [7161,8951]")

	sendAndReadToSmile(" ")
	sendAndReadToSmile("device -k GasGauge --get chem-capacity")
	logResult("\nValue should in Battery Qmax SNY [7161,8951]")

	sendAndReadToSmile(" ")
	sendAndReadToSmile("device -k GasGauge --get chem-capacity")
	logResult("\nValue should in Battery Qmax SDI [7161,8951]")
end

function QT0bBattery_Cycle_Count()
	local str = sendAndReadToSmile("device -k GasGauge --get cycle-count")
	str = string.match(str, "(%d+)")
	logResult("\ncycle-count = "..str..", should in Battery Cycle Count [0,5]")
end

-- Battery FW Version [0x601]
function QT0bBattery_FW_Version()
	sendAndReadToSmile("device -k GasGauge --get fw-version")
	logResult("\nValue should in Battery FW Version [0x601]")
end

-- Check QEN/Impedance Tracking Bit [Yes]
function QT0bCheck_QENImpedance_Tracking_Bit()
	sendAndReadToSmile("device -k GasGauge -g chem-cap-updates-en")
	logResult("\nShould contain symbol 'Yes'")
end

-- Check Sleep Enable Bit Seal status [Yes]
function QT0bCheck_Sleep_Enable_Bit_Seal_status()
	sendAndReadToSmile("device -k GasGauge --get sealed")
	logResult("\nShould contain symbol 'Yes'")
end

-- Read PMU Temp1 TP1R [10,50]
-- Read PMU Temp2 TP2A [10,50]
-- Read PMU Temp3 TP3W [10,50]
-- Read PMU Temp4 TP4C [10,50]
-- Read PMU Temp5 TP5N [10,50]
-- Read PMU Temp6 TP6F [10,50]
-- Read PMU Temp7 TP7P [10,50]
-- Read PMU Temp8 TP8H [10,50]
-- Read PMU TCAL Temp TP0Z [NA,60]
-- Read Battery Temp TG0B [10,50]
function QT0bRead_PMU_Temp_all()
	local str = sendAndReadToSmile("temperature --all")
	local str2 = sendAndReadToSmile("device -k GasGauge -p")

	local tempStr = string.match(str, "TDEV1.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV1 Instant = "..tempStr..", should in Read PMU Temp1 TP1R [10,50]")

	tempStr = string.match(str, "TDEV2.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV2 Instant = "..tempStr..", should in Read PMU Temp2 TP2A [10,50]")

	tempStr = string.match(str, "TDEV3.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV3 Instant = "..tempStr..", should in Read PMU Temp3 TP3W [10,50]")

	tempStr = string.match(str, "TDEV4.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV4 Instant = "..tempStr..", should in Read PMU Temp4 TP4C [10,50]")

	tempStr = string.match(str, "TDEV5.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV5 Instant = "..tempStr..", should in Read PMU Temp5 TP5N [10,50]")

	tempStr = string.match(str, "TDEV6.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV6 Instant = "..tempStr..", should in Read PMU Temp6 TP6F [10,50]")

	tempStr = string.match(str, "TDEV7.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV7 Instant = "..tempStr..", should in Read PMU Temp7 TP7P [10,50]")

	tempStr = string.match(str, "TDEV8.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTDEV8 Instant = "..tempStr..", should in Read PMU Temp8 TP8H [10,50]")

	tempStr = string.match(str, "TCAL.-Instant.-(%-?%d+%.%d+) deg C")
	logResult("\nTCAL Instant = "..tempStr..", should in Read PMU TCAL Temp TP0Z [NA,60]")

	tempStr = string.match(str2, "temperature.-(%-?%d+%.%d+)C.")
	logResult("\ntemperature =  "..tempStr..", should in Read PMU TCAL Temp TP0Z [NA,60]")
end