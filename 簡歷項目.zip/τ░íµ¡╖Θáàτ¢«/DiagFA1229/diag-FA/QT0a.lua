function QT0aCheck_Battery_Level_Before_Test()
	sendAndReadToSmile("device -k GasGauge -g charge-percentage")
end

function QT0aCheck_Battery_Voltage_Before_Test()
	sendAndReadToSmile("pmuadc --sel euphrates --read vbat")
end

-- vbat -PMUADC
-- vbat -PMUADC euphrates
-- vbat -Gasgauge
-- Vbat -Max Minus Min
function QT0aVbat_Test()
	sendAndReadToSmile("pmuadc --read vbat")
	sendAndReadToSmile("pmuadc --sel euphrates --read vbat")
	sendAndReadToSmile("dev -k gasgauge -p")
	sendAndReadToSmile("vbat -Gasgauge")
end

function QT0aGet_Board_ID()
	sendAndReadToSmile("boardid")
end

-- Max battery life-time temperature
-- Max battery pack voltage
-- Min battery pack voltage
-- Max battery chg current
-- Max battery dsg current
-- Max battery over chg cap
function QT0aMax_battery_life_time_temperature()
	sendAndReadToSmile("dev -k GasGauge -p")
	local str = sendAndReadToSmile("dev -k GasGauge -e read_blk 59 0")
	str = string.match(str, "0000000.-(.-)  %.")
	str = string.gsub(str, " ", "")

	--Max battery life-time temperature [NA,60]
	local hexStr = "0x"..string.sub(str, 1, 4)
	local hexStrValue = getHexStrValue(hexStr)
	hexStrValue = hexStrValue/10
	logResult("\nMax battery life-time temperature is "..hexStrValue..", should be in [NA,60]")

	--Max battery pack voltage
	hexStr = "0x"..string.sub(str, 9, 12)
	hexStrValue = getHexStrValue(hexStr)
	logResult("\nMax battery pack voltage is "..hexStrValue)

	--Min battery pack voltage
	hexStr = "0x"..string.sub(str, 13, 16)
	hexStrValue = getHexStrValue(hexStr)
	logResult("\nMin battery pack voltage is "..hexStrValue)

	--Max battery chg current
	hexStr = "0x"..string.sub(str, 17, 20)
	hexStrValue = getHexStrValue(hexStr)
	logResult("\nMax battery chg current is "..hexStrValue)

	--Max battery dsg current
	hexStr = "0x"..string.sub(str, 21, 24)
	hexStrValue = getHexStrValue(hexStr)
	logResult("\nMax battery dsg current is "..hexStrValue)
	
	--Max battery over chg cap
	hexStr = "0x"..string.sub(str, 25, 28)
	hexStrValue = getHexStrValue(hexStr)
	logResult("\nMax battery over chg cap is "..hexStrValue.."\n")
end

-- Hall Sensor Miss Test_IRQ0
function QT0aHall_Sensor_Miss_Test_IRQ0()
	local str = sendAndReadToSmile("hallsensor --meas 1 --delay 500 --irq 0")
	str = string.match(str, ".-(%w+) intr")
	logResult("\nfound the symbol '"..str.."', should be symbol 'missed'")
end

-- Hall Sensor Detect Test_IRQ0
function QT0aHall_Sensor_Detect_Test_IRQ0()
	alert("test the first Hall Sensor, need magnet!!!")
	local str = sendAndReadToSmile("hallsensor --meas 1 --delay 5000 --irq 0")
	str = string.match(str, ".-(%w+) intr")
	logResult("\nfound the symbol '"..str.."', should be symbol 'Detect'")
end

-- Hall Sensor Miss Test_IRQ1
function QT0aHall_Sensor_Miss_Test_IRQ1()
	local str = sendAndReadToSmile("hallsensor --meas 1 --delay 500 --irq 1")
	str = string.match(str, ".-(%w+) intr")
	logResult("\nfound the symbol '"..str.."', should be symbol 'missed'")
end

-- Hall Sensor Detect Test_IRQ1
function QT0aHall_Sensor_Detect_Test_IRQ1()
	alert("test the second Hall Sensor, need magnet!!!")
	local str = sendAndReadToSmile("hallsensor --meas 1 --delay 5000 --irq 1")
	str = string.match(str, ".-(%w+) intr")
	logResult("\nfound the symbol '"..str.."', should be symbol 'Detect'")
end

function QT0aButton_Test()
	alert("button test! Hold! Up! Down!")
	sendAndReadToSmile("button -h -u -d")
end

-- 2.4K Tone To Left Spk1
-- Left-Spk1 P-to-P
-- Left-Spk1 VMON Present Test_Freq
-- Left-Spk1 VMON Present Test_Mag
-- Left-Spk1 VMON Present Test_SINAD
-- Left-Spk1 VMON Present Test_THD
-- Left-Spk1 IMON Present Test_Freq
-- Left-Spk1 IMON Present Test_Mag
-- Left-Spk1 IMON Present Test_SINAD
-- Left-Spk1 IMON Present Test_THD
-- Left-Spk1 Peak IMON
function QT0a2400hz_Tone_To_Left_Spk1()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkl1")
	sendAndReadToSmile("routeaudio --route --block spkl1 --in spk-i2s --out spk-out")
	sendAndReadToSmile("routeaudio -r -b codec -i dmic1 -o asp")
	sendAndReadToSmile("audioreg --block spkl1 --write --addr 0x2C --data 0xD0")
	sendAndReadToSmile("audioreg --block spkl1 --write --addr 0x2E --data 0x00")
	sendAndReadToSmile("audioparam --set --param enable-mon --block spkl1 --value true")
	sendAndReadToSmile("setvol --block spkl1 --volume spk-vol --value 0")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca2 -x ap-mca2 -d 24 -l 1500 --freq 2400 --rate 48000")
	sendAndReadToSmile("processaudio -p crop -i looprx0 -o '--start 5000'")

	local str = sendAndReadToSmile("processaudio -p MAX98721 -i process0 -o '--stats'", ClearAutoLog)
	str = string.gsub(str, "Peak to Peak VMON.-(%d+%.%d+)V", "%0\n=====================>%1 should in Left-Spk1 P-to-P [3.24,3.96]")
	str = string.gsub(str, "Maximum absolute IMON.-(%d+%.%d+)A", "%0\n=====================>%1 should in Left-Spk1 Peak IMON [0.26,0.40]")
	logResult(str)
	
	sendAndReadToSmile("processaudio -p MAX98721 --inbufs process0 --options '--buffers'")

	str = sendAndReadToSmile("processaudio -p fft --inbufs process5 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Left-Spk1 VMON Present Test_PK_MAG [557,681];\n=====================>%2 should in Left-Spk1 VMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk1 VMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk1 VMON Present Test_THD [NA,-40]")
	logResult(str)

	str = sendAndReadToSmile("processaudio -p fft --inbufs process7 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Left-Spk1 IMON Present Test_PK_MAG [80,146];\n=====================>%2 should in Left-Spk1 IMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk1 IMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk1 IMON Present Test_THD [NA,-40]")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkl1")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- 24K Tone To Right Spk1
-- Right-Spk1 P-to-P
-- Right-Spk1 VMON Present Test_Freq
-- Right-Spk1 VMON Present Test_Mag
-- Right-Spk1 VMON Present Test_SINAD
-- Right-Spk1 VMON Present Test_THD
-- Right-Spk1 IMON Present Test_Freq
-- Right-Spk1 IMON Present Test_Mag
-- Right-Spk1 IMON Present Test_SINAD
-- Right-Spk1 IMON Present Test_THD
-- Right-Spk1 Peak IMON.
function QT0a2400hz_Tone_To_Right_Spk1()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkr1")
	sendAndReadToSmile("routeaudio --route --block spkr1 --in spk-i2s --out spk-out")
	sendAndReadToSmile("routeaudio -r -b codec -i dmic1 -o asp")
	sendAndReadToSmile("audioreg --block spkr1 --write --addr 0x2C --data 0xD0")
	sendAndReadToSmile("audioreg --block spkr1 --write --addr 0x2E --data 0x00")
	sendAndReadToSmile("audioparam --set --param enable-mon --block spkr1 --value true")
	sendAndReadToSmile("setvol --block spkr1 --volume spk-vol --value 0")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca2 -x ap-mca2 -d 24 -l 1500 --freq 2400 --rate 48000")
	sendAndReadToSmile("processaudio -p crop -i looprx0 -o '--start 5000'")

	local str = sendAndReadToSmile("processaudio -p MAX98721 -i process0 -o '--stats'", ClearAutoLog)
	str = string.gsub(str, "Peak to Peak VMON.-(%d+%.%d+)V", "%0\n=====================>%1 should in Right-Spk1 P-to-P [3.24,3.96]")
	str = string.gsub(str, "Maximum absolute IMON.-(%d+%.%d+)A", "%0\n=====================>%1 should in Right-Spk1 Peak IMON [0.26,0.40]")
	logResult(str)
	
	sendAndReadToSmile("processaudio -p MAX98721 --inbufs process0 --options '--buffers'")

	str = sendAndReadToSmile("processaudio -p fft --inbufs process5 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Right-Spk1 VMON Present Test_PK_MAG [557,681]; \n=====================>%2 should in Right-Spk1 VMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk1 VMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk1 VMON Present Test_THD [NA,-40]")
	logResult(str)

	str = sendAndReadToSmile("processaudio -p fft --inbufs process7 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Right-Spk1 IMON Present Test_PK_MAG [101,185];\n=====================>%2 should in Right-Spk1 IMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk1 IMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk1 IMON Present Test_THD [NA,-40]")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkr1")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- 2.4K Tone To Left Spk2
-- Left-Spk2 P-to-P
-- Left-Spk2 VMON Present Test_Freq
-- Left-Spk2 VMON Present Test_Mag
-- Left-Spk2 VMON Present Test_SINAD
-- Left-Spk2 VMON Present Test_THD
-- Left-Spk2 IMON Present Test_Freq
-- Left-Spk2 IMON Present Test_Mag
-- Left-Spk2 IMON Present Test_SINAD
-- Left-Spk2 IMON Present Test_THD
-- Left-Spk2 Peak IMON
function QT0a2400hz_Tone_To_Left_Spk2()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkl2")
	sendAndReadToSmile("routeaudio --route --block spkl2 --in spk-i2s --out spk-out")
	sendAndReadToSmile("routeaudio -r -b codec -i dmic1 -o asp")
	sendAndReadToSmile("audioreg --block spkl2 --write --addr 0x2C --data 0xD0")
	sendAndReadToSmile("audioreg --block spkl2 --write --addr 0x2E --data 0x00")
	sendAndReadToSmile("audioparam --set --param enable-mon --block spkl2 --value true")
	sendAndReadToSmile("setvol --block spkl2 --volume spk-vol --value 0")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca2 -x ap-mca2 -d 24 -l 1500 --freq 2400 --rate 48000")
	sendAndReadToSmile("processaudio -p crop -i looprx0 -o '--start 5000'")

	local str = sendAndReadToSmile("processaudio -p MAX98721 -i process0 -o '--stats'", ClearAutoLog)
	str = string.gsub(str, "Peak to Peak VMON.-(%d+%.%d+)V", "%0\n=====================>%1 should in Left-Spk2 P-to-P [3.24,3.96]")
	str = string.gsub(str, "Maximum absolute IMON.-(%d+%.%d+)A", "%0\n=====================>%1 should in Left-Spk2 Peak IMON [0.26,0.40]")
	logResult(str)
	
	sendAndReadToSmile("processaudio -p MAX98721 --inbufs process0 --options '--buffers'")

	str = sendAndReadToSmile("processaudio -p fft --inbufs process5 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Left-Spk2 VMON Present Test_PK_MAG [557,681];\n=====================>%2 should in Left-Spk2 VMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk2 VMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk2 VMON Present Test_THD [NA,-40]")
	logResult(str)

	str = sendAndReadToSmile("processaudio -p fft --inbufs process7 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Left-Spk2 IMON Present Test_PK_MAG [101,185];\n=====================>%2 should in Left-Spk2 IMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "\n=====================>%1 should in Left-Spk2 IMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Left-Spk2 IMON Present Test_THD [NA,-40]")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkl2")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- 2.4K Tone To Right Spk2
-- Right-Spk2 P-to-P
-- Right-Spk2 VMON Present Test_Freq
-- Right-Spk2 VMON Present Test_Mag
-- Right-Spk2 VMON Present Test_SINAD
-- Right-Spk2 VMON Present Test_THD
-- Right-Spk2 IMON Present Test_Freq
-- Right-Spk2 IMON Present Test_Mag
-- Right-Spk2 IMON Present Test_SINAD
-- Right-Spk2 IMON Present Test_THD
-- Right-Spk2 Peak IMON
function QT0a2400hz_Tone_To_Right_Spk2()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkr2")
	sendAndReadToSmile("routeaudio --route --block spkr2 --in spk-i2s --out spk-out")
	sendAndReadToSmile("routeaudio -r -b codec -i dmic1 -o asp")
	sendAndReadToSmile("audioreg --block spkr2 --write --addr 0x2C --data 0xD0")
	sendAndReadToSmile("audioreg --block spkr2 --write --addr 0x2E --data 0x00")
	sendAndReadToSmile("audioparam --set --param enable-mon --block spkr2 --value true")
	sendAndReadToSmile("setvol --block spkr2 --volume spk-vol --value 0")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca2 -x ap-mca2 -d 24 -l 1500 --freq 2400 --rate 48000")
	sendAndReadToSmile("processaudio -p crop -i looprx0 -o '--start 5000'")

	local str = sendAndReadToSmile("processaudio -p MAX98721 -i process0 -o '--stats'", ClearAutoLog)
	str = string.gsub(str, "Peak to Peak VMON.-(%d+%.%d+)V", "%0\n=====================>%1 should in Right-Spk2 P-to-P [3.24,3.96]")
	str = string.gsub(str, "Maximum absolute IMON.-(%d+%.%d+)A", "%0\n=====================>%1 should in Right-Spk2 Peak IMON [0.26,0.40]")
	logResult(str)

	sendAndReadToSmile("processaudio -p MAX98721 --inbufs process0 --options '--buffers'")

	str = sendAndReadToSmile("processaudio -p fft --inbufs process5 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Right-Spk2 VMON Present Test_PK_MAG [557,681];\n=====================>%2 should in Right-Spk2 VMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk2 VMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk2 VMON Present Test_THD [NA,-40]")
	logResult(str)

	str = sendAndReadToSmile("processaudio -p fft --inbufs process7 --options '--normalize false --numSamples 8192'", ClearAutoLog)
	str = string.gsub(str, "Peak Magnitude.-(%d+%.%d+).-Frequency.-(%d+%.%d+).-Hz", "%0\n=====================>%1 should in Right-Spk2 IMON Present Test_PK_MAG [101,185];\n=====================>%2 should in Right-Spk2 IMON Present Test_Freq [2350,2450]")
	str = string.gsub(str, "SINAD.-(%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk2 IMON Present Test_SINAD [100,NA]")
	str = string.gsub(str, "THD%+N.-(%p%d+%.%d+).-dB", "%0\n=====================>%1 should in Right-Spk2 IMON Present Test_THD [NA,-40]")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkr2")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- Left Spk1 to TopMic&BackMic Loopback Test
function QT0aLeft_Spk1_to_TopMic_BackMic_Loopback_Test()
	sendAndReadToSmile("egpio --pick expander --pin 2 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 2 --write 1")
	sendAndReadToSmile("egpio --pick expander --pin 5 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 5 --write 1")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkl1")
	sendAndReadToSmile("setvol -b spkl1 -n spk-vol -v 3")
	sendAndReadToSmile("routeaudio -r -b spkl1 -i spk-i2s -o spk-out")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("playaudio -b socmca -p ap-mca2 -l 5000 -d 24 --freq 3000 --async")
	sendAndReadToSmile("recordaudio -b socmca -p ap-mca0 -r 48000 -d 32 --len 2000")
	sendAndReadToSmile("stopaudio -b socmca -p ap-mca2")

	local str = sendAndReadToSmile("processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'", ClearAutoLog)
	str = string.gsub(str, "Channel 0.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	str = string.gsub(str, "Channel 1.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkl1")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- Right Spk1 to TopMic&BackMic Loopback Test
function QT0aRight_Spk1_to_TopMic_BackMic_Loopback_Test()
	sendAndReadToSmile("egpio --pick expander --pin 2 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 2 --write 1")
	sendAndReadToSmile("egpio --pick expander --pin 5 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 5 --write 1")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkr1")
	sendAndReadToSmile("setvol -b spkr1 -n spk-vol -v 3")
	sendAndReadToSmile("routeaudio -r -b spkr1 -i spk-i2s -o spk-out")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("playaudio -b socmca -p ap-mca2 -l 5000 -d 24 --freq 3000 --async")
	sendAndReadToSmile("recordaudio -b socmca -p ap-mca0 -r 48000 -d 32 --len 2000")
	sendAndReadToSmile("stopaudio -b socmca -p ap-mca2")

	local str = sendAndReadToSmile("processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'", ClearAutoLog)
	str = string.gsub(str, "Channel 0.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	str = string.gsub(str, "Channel 1.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkr1")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- Left Spk2 to TopMic&BackMic Loopback Test
function QT0aLeft_Spk2_to_TopMic_BackMic_Loopback_Test()
	sendAndReadToSmile("egpio --pick expander --pin 2 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 2 --write 1")
	sendAndReadToSmile("egpio --pick expander --pin 5 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 5 --write 1")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkl2")
	sendAndReadToSmile("setvol -b spkl2 -n spk-vol -v 3")
	sendAndReadToSmile("routeaudio -r -b spkl2 -i spk-i2s -o spk-out")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("playaudio -b socmca -p ap-mca2 -l 5000 -d 24 --freq 3000 --async")
	sendAndReadToSmile("recordaudio -b socmca -p ap-mca0 -r 48000 -d 32 --len 2000")
	sendAndReadToSmile("stopaudio -b socmca -p ap-mca2")

	local str = sendAndReadToSmile("processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'", ClearAutoLog)
	str = string.gsub(str, "Channel 0.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	str = string.gsub(str, "Channel 1.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkl2")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- Right Spk2 to TopMic&BackMic Loopback Test
function QT0aRight_Spk2_to_TopMic_BackMic_Loopback_Test()
	sendAndReadToSmile("egpio --pick expander --pin 2 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 2 --write 1")
	sendAndReadToSmile("egpio --pick expander --pin 5 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 5 --write 1")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("audio --resetblock socmca")
	sendAndReadToSmile("audio --resetblock spkr2")
	sendAndReadToSmile("setvol -b spkr2 -n spk-vol -v 3")
	sendAndReadToSmile("routeaudio -r -b spkr2 -i spk-i2s -o spk-out")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("playaudio -b socmca -p ap-mca2 -l 5000 -d 24 --freq 3000 --async")
	sendAndReadToSmile("recordaudio -b socmca -p ap-mca0 -r 48000 -d 32 --len 2000")
	sendAndReadToSmile("stopaudio -b socmca -p ap-mca2")

	local str = sendAndReadToSmile("processaudio -p fft -i record0 -o '--normalize false --minHz 2990 --maxHz 3010'", ClearAutoLog)
	str = string.gsub(str, "Channel 0.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	str = string.gsub(str, "Channel 1.-Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 Peak Magnitude must >=200000, the difference between Peak Magnitude(Channel 0) and Peak Magnitude(Channel 1) must >=10 or <=-10")
	logResult(str)

	sendAndReadToSmile("audio --turnoff spkr2")
	sendAndReadToSmile("audio --turnoff socmca")
end

-- HP Detect
function QT0aHP_Detect()
	alert("plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o hp -r")
	sendAndReadToSmile("mikey --detectheadphone")
end

-- Global Headset_Left_Open_Freq_Ch4
-- Global Headset_Left_Open_Mag_Ch4
-- Global Headset_Left_Open_SINAD_Ch4
-- Global Headset_Left_Open_THD_Ch4
-- Global Headset_Left_Open_Positive_Ch4
-- Global Headset_Left_Open_Negative_Ch4
function QT0aGlobal_Headset_Left_Open_Freq_Ch4()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("audioreg -b clifden -w -a 0x1208 -d 0x13")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_global")
	sendAndReadToSmile("setvol -b clifden -n mixerAdc -v mute")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Left_Open_Mag_Ch4 [NA,0.01];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-[^%c]+", "%0\n=====================>%1 should in Global Headset_Left_Open_THD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-[^%c]+", "%0\n=====================>%1 Global Headset_Left_Open_Positive_Ch4 [NA,-26]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Open_Positive_Ch4 [NA,-26];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Open_Negative_Ch4 [NA,-26];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- Global Headset_Left_Freq_Ch4
-- Global Headset_Left_Mag_Ch4
-- Global Headset_Left_SINAD_Ch4
-- Global Headset_Left_THD_Ch4
-- Global Headset_Left_Positive_Ch4
-- Global Headset_Left_Negative_Ch4
function QT0aGlobal_Headset_Left_Freq_Ch4()
	alert("need plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("audioreg -b clifden -w -a 0x1208 -d 0x13")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_global")
	sendAndReadToSmile("setvol -b clifden -n mixerAdc -v mute")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Left_Mag_Ch4 [0.14,0.17];\n=====================>%2 should in Global Headset_Left_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Left_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Left_THD_Ch4 [NA,-60]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Positive_Ch4 [-7.5,-5];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Negative_Ch4 [-7.5,-5];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- Global Headset_Right_Open_Freq_Ch4
-- Global Headset_Right_Open_Mag_Ch4
-- Global Headset_Right_Open_SINAD_Ch4
-- Global Headset_Right_Open_THD_Ch4
-- Global Headset_Right_Open_Positive_Ch4
-- Global Headset_Right_Open_Negative_Ch4
function QT0aGlobal_Headset_Right_Open_Freq_Ch4()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[r] -r")
	sendAndReadToSmile("audioreg -b clifden -w -a 0x1208 -d 0x13")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_global")
	sendAndReadToSmile("setvol -b clifden -n mixerAdc -v mute")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Right_Open_Mag_Ch4 [NA,0.01];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Right_Open_THD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 Global Headset_Right_Open_Positive_Ch4 [NA,-26]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Open_Positive_Ch4 [NA,-26];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Open_Negative_Ch4 [NA,-26];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- Global Headset_Right_Freq_Ch4
-- Global Headset_Right_Mag_Ch4
-- Global Headset_Right_SINAD_Ch4
-- Global Headset_Right_THD_Ch4
-- Global Headset_Right_Positive_Ch4
-- Global Headset_Right_Negative_Ch4
function QT0aGlobal_Headset_Right_Freq_Ch4()
	alert("need plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[r] -r")
	sendAndReadToSmile("audioreg -b clifden -w -a 0x1208 -d 0x13")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_global")
	sendAndReadToSmile("setvol -b clifden -n mixerAdc -v mute")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Right_Mag_Ch4 [0.14,0.17];\n=====================>%2 should in Global Headset_Right_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Right_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Right_THD_Ch4 [NA,-60]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Positive_Ch4 [-7.5,-5];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Negative_Ch4 [-7.5,-5];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- HP Detect (from Mikey1A)
function QT0aHP_Detect_from_Mikey1A()
	alert("need plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o hp -r")
	local str = sendAndReadToSmile("mikey --getheadsetid",ClearAutoLog)
	logResult(str.."\nShould contain symbol 'Mikey Headset ID:0x0'")
end

-- Ext. MIC present
function QT0aExt_MIC_present()
	alert("need plug headphone!!!")
	local str = sendAndReadToSmile("mikey --detectmic")
	logResult(str.."\nShould contain symbol 'Mikey detected!'")
end

-- Mikey_Tone_S0
-- Mikey Tone S1
-- Mikey_Tone_S2
-- Mikey_Tone_S3
-- Mikey_Tone_S4
-- function QT0aMikey_Tone()
-- 	alert("need plug headphone!!!")
-- 	alert("ready to press headphone middle button!!!")
-- 	sendAndReadToSmile("mikey --detectshort")
-- 	alert("ready to press headphone up button!!!")
-- 	sendAndReadToSmile("mikey --tone"
-- 	alert("ready to press headphone down button!!!")
-- 	sendAndReadToSmile("mikey --tone")
-- end

-- China Headset_Left_Open_Freq_Ch4
-- China Headset_Left_Open_Mag_Ch4
-- China Headset_Left_Open_SINAD_Ch4
-- China Headset_Left_Open_THD_Ch4
-- China Headset_Left_Open_Positive_Ch4
-- China Headset_Left_Open_Negative_Ch4
function QT0aChina_Headset_Left_Open_Freq_Ch4()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_china")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Left_Mag_Ch4 [NA,0.01];\n=====================>%2 should in Global Headset_Left_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Left_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Left_THD_Ch4 [NA,NA]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Positive_Ch4 [NA,-26];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Negative_Ch4 [NA,-26];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

end

-- China Headset_Left_Freq_Ch4
-- China Headset_Left_Mag_Ch4
-- China Headset_Left_SINAD_Ch4
-- China Headset_Left_THD_Ch4
-- China Headset_Left_Positive_Ch4
-- China Headset_Left_Negative_Ch4
function QT0aChina_Headset_Left_Freq_Ch4()
	alert("need plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_china")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Left_Mag_Ch4 [0.14,0.17];\n=====================>%2 should in Global Headset_Left_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Left_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Left_THD_Ch4 [NA,-60]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Positive_Ch4 [-7.5,-5];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Left_Negative_Ch4 [-7.5,-5];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

end

-- China Headset_Right_Open_Freq_Ch4
-- China Headset_Right_Open_Mag_Ch4
-- China Headset_Right_Open_SINAD_Ch4
-- China Headset_Right_Open_THD_Ch4
-- China Headset_Right_Open_Positive_Ch4
-- China Headset_Right_Open_Negative_Ch4
function QT0aChina_Headset_Right_Open_Freq_Ch4()
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_china")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Right_Mag_Ch4 [NA,0.01];\n=====================>%2 should in Global Headset_Right_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Right_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Right_THD_Ch4 [NA,NA]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Positive_Ch4 [NA,-26];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Negative_Ch4 [NA,-26];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- China Headset_Right_Freq_Ch4
-- China Headset_Right_Mag_Ch4
-- China Headset_Right_SINAD_Ch4
-- China Headset_Right_THD_Ch4
-- China Headset_Right_Positive_Ch4
-- China Headset_Right_Negative_Ch4
function QT0aChina_Headset_Right_Freq_Ch4()
	alert("need plug headphone!!!")
	sendAndReadToSmile("audio --reset")
	sendAndReadToSmile("processaudio --freebufs all")
	sendAndReadToSmile("routeaudio -b clifden -i asp -o hp[l] -r")
	sendAndReadToSmile("routeaudio -b clifden -i hsin -o asp -r")
	sendAndReadToSmile("device -k HpSwitch -e set_china")
	sendAndReadToSmile("loopaudio -b socmca -p ap-mca0 -x ap-mca0 --len 1000 --bitdepth 24 --rate 48000 --channel 8")

	local str = sendAndReadToSmile("processaudio -p fft -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Peak Magnitude.-(%d+.%d+).-FS.-Frequency.-(%d+.%d+).-Hz", "%0\n=====================>%1 should in Global Headset_Right_Mag_Ch4 [0.14,0.17];\n=====================>%2 should in Global Headset_Right_Freq_Ch4 [950,1050];")
	partStr = string.gsub(partStr, "SINAD.-(%-?%d+.%d+).-dBFS", "%0\n=====================>%1 should in Global Headset_Right_SINAD_Ch4 [NA,NA];")
	partStr = string.gsub(partStr, "THD%+N.-(%-?%d+.%d+).-dB", "%0\n=====================>%1 should in Global Headset_Right_THD_Ch4 [NA,-60]")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)

	local str = sendAndReadToSmile("processaudio -p rms -i looprx0", ClearAutoLog)
	local partStr = string.match(str, "Channel 4.-Channel 5")
	partStr = string.gsub(partStr, "Positive dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Positive_Ch4 [-7.5,-5];")
	partStr = string.gsub(partStr, "Negative dBFS.-(%-?%d+.%d+)", "%0\n=====================>%1 should in Global Headset_Right_Negative_Ch4 [-7.5,-5];")
	str = string.gsub(str, "Channel 4.-Channel 5", partStr)
	logResult(str)
end

-- ALS Device ID
-- Sensor ALS Bright -Ch_0
-- Sensor ALS Bright -Ch_1
function QT0aALS_Device()

	sendAndReadToSmile("i2c --devwrite 3 0x39 0x80 0x01")
	sendAndReadToSmile("i2c --devread 3 0x39 0x92 0x01")
	sendAndReadToSmile("sensor --sel als1 --init")
	sendAndReadToSmile("sensor --sel als1 --set gain 8")
	sendAndReadToSmile("sensor --sel als1 --set integration_cycles 148")
	local str = sendAndReadToSmile("sensor --sel als1 --sample 3 --stream")

	local hexStrTable = {}
	for hexStr in string.gmatch(str, "red = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	local average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of red is: "..tostring(average)..", should in Sensor ALS1 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "green = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of green is: "..tostring(average)..", should in Sensor ALS1 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "blue = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of blue is: "..tostring(average)..", should in Sensor ALS1 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "clear = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of clear is: "..tostring(average)..", should in Sensor ALS1 Bright -Ch_0 [5,65534]\n")

	-- ALS2
	sendAndReadToSmile("")
	sendAndReadToSmile("i2c --devwrite 3 0x29 0x80 0x01")
	sendAndReadToSmile("i2c --devread 3 0x29 0x92 0x01")
	sendAndReadToSmile("sensor --sel als2 --init")
	sendAndReadToSmile("sensor --sel als2 --set gain 8")
	sendAndReadToSmile("sensor --sel als2 --set integration_cycles 148")
	str = sendAndReadToSmile("sensor --sel als2 --sample 3 --stream")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "red = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of red is: "..tostring(average)..", should in Sensor ALS2 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "green = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of green is: "..tostring(average)..", should in Sensor ALS2 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "blue = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of blue is: "..tostring(average)..", should in Sensor ALS2 Bright -Ch_1 [5,65534]")

	hexStrTable = {}
	for hexStr in string.gmatch(str, "clear = (%w+)") do
  		hexStrTable[#hexStrTable+1] = hexStr
	end
	average = ( getHexStrValue(hexStrTable[1]) + getHexStrValue(hexStrTable[2]) + getHexStrValue(hexStrTable[3]) ) / 3
	logResult("\nthe average Of clear is: "..tostring(average)..", should in Sensor ALS2 Bright -Ch_0 [5,65534]\n")
end

-- Strobe Cool LED1 Test
-- Strobe Warm LED2 TEST
-- function QT0aStrobe_LED1_Test()
-- 	-- Strobe Cool LED1 Test
-- 	sendAndReadToSmile("strobe --selectchip LM3564 --power on")
-- 	sendAndReadToSmile("strobe --read 0x00 1 1")
-- 	sendAndReadToSmile("strobe --write 0x02 0xa3")
-- 	sendAndReadToSmile("strobe --write 0x05 0xCC")
-- 	sendAndReadToSmile("strobe --write 0x06 0x7f")
-- 	sendAndReadToSmile("strobe --write 0x04 0xd7")
-- 	sendAndReadToSmile("strobe --write 0x01 0x83")

-- 	-- Strobe Warm LED2 TEST
-- 	sendAndReadToSmile("strobe --selectchip LM3564 --power off")
-- 	sendAndReadToSmile("strobe --read 0x00 1 1")
-- 	sendAndReadToSmile("strobe --write 0x02 0xa3")
-- 	sendAndReadToSmile("strobe --write 0x05 0xCC")
-- 	sendAndReadToSmile("strobe --write 0x06 0x00")
-- 	sendAndReadToSmile("strobe --write 0x04 0xd7")
-- 	sendAndReadToSmile("strobe --write 0x01 0x83")
-- 	sendAndReadToSmile("strobe --selectchip LM3564 --power off")
-- end