-- Grape GPIO Test
function CT2Grape_GPIO_Test()
	sendAndReadToSmile("touch --sel grape")
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --on")
	sendAndReadToSmile("touch --test gpio --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Short Test
function CT2Grape_Short_Test()
	sendAndReadToSmile("smokeyshell -r")
	sendAndReadToSmile("smokey --run TouchShortsTest")
end

-- GRAPE POWER ON
function CT2GRAPE_POWER_ON()
	sendAndReadToSmile("touch --off")
	sendAndReadToSmile("touch --on")
	sendAndReadToSmile("touch --load_firmware")
end

-- Grape Firmware version
function CT2Grape_Firmware_version()
	sendAndReadToSmile("touch -p firmware-version")
end

-- Grape Offset Test
function CT2Grape_Offset_Test()
	sendAndReadToSmile("touch --test offset --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Touch Opens Test
function CT2Grape_Touch_Opens_Test()
	sendAndReadToSmile("touch --test opens --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Touch Opens Test
function CT2Grape_Touch_Opens_Test()
	sendAndReadToSmile("touch --test opens --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Memory Test
function CT2Grape_Memory_Test()
	sendAndReadToSmile("touch --test slave_memory --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape FW Critical Error Check
function CT2Grape_FW_Critical_Error_Check()
	sendAndReadToSmile("touch --test critical --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Grape Drive Line Short Test
function CT2Grape_Drive_Line_Short_Test()
	sendAndReadToSmile("touch --test drive_shorts --run")
	logResult("\n Should contain symbol 'PASS' at last")
end

-- Kona Power Cycle Test
function CT2Kona_Power_Cycle_Test()
	sendAndReadToSmile("touch --on")
	sendAndReadToSmile("touch --power_delays disabled")
	local str = sendAndReadToSmile("repeat 500 'touch --off;wait 30;touch --on;wait 50'")
	sendAndReadToSmile("touch --power_delays normal")
	sendAndReadToSmile("touch --off")

	str = string.gsub(str, "FAIL", "ffaaiill")
	str = string.gsub(str, "Fail", "ffaaiill")
	str = string.gsub(str, "Error", "ffaaiill")
	str = string.gsub(str, "ERROR", "ffaaiill")
	str = string.gsub(str, "error", "ffaaiill")

	if string.match(str, "ffaaiill") ~= nil then
		logResult("\n Result contain symbol 'FAIL|Fail|Error|ERROR|error'")
		logResult("\n test fail!!!\n")
	end
end

-- ALS1 RAW Test [OK]
function CT2ALS1_RAW_Test()
	sendAndReadToSmile("sensor --sel als1 --init")
	sendAndReadToSmile("sensor --sel als1 --set gain 8")
	sendAndReadToSmile("sensor --sel als1 --set integration_cycles 148")
	sendAndReadToSmile("sensor --sel als1 --sample 2 --stream")
	logResult("\n Should contain symbol 'OK' at last")
end

-- ALS2 RAW Test [OK]
function CT2ALS1_RAW_Test()
	sendAndReadToSmile("sensor --sel als2 --init")
	sendAndReadToSmile("sensor --sel als2 --set gain 8")
	sendAndReadToSmile("sensor --sel als2 --set integration_cycles 148")
	sendAndReadToSmile("sensor --sel als2 --sample 2 --stream")
	logResult("\n Should contain symbol 'OK' at last")
end

-- Display I2C sweep test
function CT2Display_I2C_sweep_test()
	sendAndReadToSmile("i2c -s 1")
end

-- Mikey Bus Test
function CT2Mikey_Bus_Test()
	sendAndReadToSmile("egpio --pick expander --pin 5 --mode output")
	sendAndReadToSmile("egpio --pick expander --pin 5 --write 1")
	local str = sendAndReadToSmile("script FATP\\MikeyBusLB.sh")
	str = string.match(str, "BER: (%d+) ppm")
	logResult("\nBER = "..str..", should be 0 \n")
end

-- Write Date and Time
function CT2Write_Date_and_Time()
	sendAndReadToSmile("rtc --set 20141111111111")
end

-- RotterDam_Test
function CT2RotterDam_Test()
	sendAndReadToSmile("stockholm --on")
	sendAndReadToSmile("stockholm --download_fw mfg")
	sendAndReadToSmile("bblib -e 'BB_SMTQT()'")
end


