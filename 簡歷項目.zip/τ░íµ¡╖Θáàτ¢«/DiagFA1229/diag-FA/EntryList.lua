loadLib("QT0a.lua")
loadLib("QT0b.lua")
loadLib("CT1.lua")
loadLib("CT2.lua")
loadLib("CT3.lua")
loadLib("FOS.lua")
loadLib("Tool.lua")

-- 在这里调用自定义测项函数
function entryPoint()
	-- local status, err
	-- status, err = pcall(FOSALPM_Mod)
	-- if err ~= nil then
	-- 	logResult('\n\n\n'..err..'!!!\n\n\n')
	-- end
	-- timeOfEnterDiag()
end


-- 以下用于初始化APP
stationAndItem = {
	['Tool'] = {
				'TimeOfEnterDiag',
				},
	['QT0a'] = {
				'Check_Battery_Level_Before_Test',
				'Check_Battery_Voltage_Before_Test',
				'Vbat_Test',
				'Get_Board_ID',
				'Max_battery_life_time_temperature',
				'Hall_Sensor_Miss_Test_IRQ0',
				'Hall_Sensor_Detect_Test_IRQ0',
				'Hall_Sensor_Miss_Test_IRQ1',
				'Hall_Sensor_Detect_Test_IRQ1',
				'Button_Test',
				'2400hz_Tone_To_Left_Spk1',
				'2400hz_Tone_To_Right_Spk1',
				'2400hz_Tone_To_Left_Spk2',
				'2400hz_Tone_To_Right_Spk2',
				'Left_Spk1_to_TopMic_BackMic_Loopback_Test',
				'Right_Spk1_to_TopMic_BackMic_Loopback_Test',
				'Left_Spk2_to_TopMic_BackMic_Loopback_Test',
				'Right_Spk2_to_TopMic_BackMic_Loopback_Test',
				'HP_Detect',
				'Global_Headset_Left_Open_Freq_Ch4',
				'Global_Headset_Left_Freq_Ch4',
				'Global_Headset_Right_Open_Freq_Ch4',
				'Global_Headset_Right_Freq_Ch4',
				'HP_Detect_from_Mikey1A',
				'Ext_MIC_present',
				'China_Headset_Left_Open_Freq_Ch4',
				'China_Headset_Left_Freq_Ch4',
				'China_Headset_Right_Open_Freq_Ch4',
				'China_Headset_Right_Freq_Ch4',
				'ALS_Device',
				},

	['QT0b'] = {
				'HP_non_presented',
				'Ext_MIC_non_presented',
				'Front_Back_Camera_Find',
				'Front_Back_Camera_DLI',
				'Power_on_Baseband_and_load_firmware',
				'Sim_Tray_Test',
				'Sim_card_checkt',
				'Pressure_Initialization',
				'Pressure_Connectivity_Test',
				'WV_Phosphorus_Average_std_ODR_Temp_TempStd',
				-- 'WV_Phosphorus_Trim_Rev',
				'WV_Phosphorus_ASIC_Average',
				'Compass_Initialization',
				'Compass_Connectivity_Test',
				'Compass_self_test',
				'Sensor_Accelerometer_Selftest',
				'Accelerometer_Interrupt',
				'Accelerometer_Interrupt',
				'Gyro_Init',
				'Gyro_self_test',
				'Gyro_self_test',
				'Gyro_self_test',
				'Static_Chem_ID_Checksum',
				'Battery_Qmax_ATL_LGC_SNY_SDI',
				'Battery_Cycle_Count',
				'Battery_FW_Version',
				'Check_QENImpedance_Tracking_Bit',
				'Check_Sleep_Enable_Bit_Seal_status',
				'Read_PMU_Temp_all',
				},
	['CT1'] = {
				'CM_Accel_Gyro',
				'Compass',
				'Compass_Reg0_4',
				'Compass_Reg1_30',
				'Compass_RegF_8',
				'Compass_RegF_8',
				'DBCl_DTCl',
				'Mesa_Test',
				},
	['CT2'] = {
				'Grape_GPIO_Test',
				'Grape_Short_Test',
				'GRAPE_POWER_ON',
				'Grape_Firmware_version',
				'Grape_Offset_Test',
				'Grape_Touch_Opens_Test',
				'Grape_Touch_Opens_Test',
				'Grape_Memory_Test',
				'Grape_FW_Critical_Error_Check',
				'Grape_Drive_Line_Short_Test',
				'Kona_Power_Cycle_Test',
				'ALS1_RAW_Test',
				'ALS1_RAW_Test',
				'Display_I2C_sweep_test',
				'Mikey_Bus_Test',
				'Write_Date_and_Time',
				'RotterDam_Test',	
				},
	['CT3'] = {
				'Pressure_Initialization',
				'Pressure_Connectivity_Test',
				'WV_Phosphorus_Average_std_ODR_Temp_TempStd',
				'WV_Phosphorus_Trim_Rev',
				'WV_Phosphorus_ASIC_Average_std_ODR_TempStd',
				'Button_Test',
				'Mesa_Test',
				'Grape_GPIO_Test',
				'Grape_Short_Test',
				'GRAPE_POWER_ON',
				'Grape_Firmware_version',
				'Grape_Touch_Opens_Test',
				'Grape_FW_Critical_Error_Check',
				'Grape_Offset_Test',
				},
	['FOS'] = {
				'ALPM_Mod',
				'COG_BERT_Test',
				'Strobe_Cool_LED1_Test',
				'Strobe_Warm_LED2_TEST',
				'Backlight_123456',
				'Waterfall_Test',
				'Display_SyncRate_30Hz_for_Flicker',
				'set_backlight_to_100_level',
				'Grey_32_Flicker_Pattern_Test',
				'Grey_64_Flicker_Pattern_Test',
				'Grey_127_Flicker_Pattern_Test',
				'Display_SyncRate_60Hz_for_Flicker',
				'Display_SyncRate_Hz',
				'Pattern_test_white_gray1',
				'Pattern_test_white_gray2',
				'Display_SyncRate2_Hz',
				'Pattern_Grey32_test',
				'Pattern_Grey64_test',
				'Pattern_Grey128_test',
				'Pattern_White_test',
				'Pattern_Black_test',
				'Pattern_Red_test',
				'Pattern_Green_test',
				'Pattern_Blue_test',
				'Light_Leakage_Test',
				'Curtain_Leakage_Test',
				'Front_Camera_Preview',
				'Back_Camera_Preview',
				},
}

buttonInfo = {
	'root',
	'iboot',
	'diags',
	'reboot',
	'res',
	'charge',
	'off'
}

function rootFunc()
	sendCmd(' ')
	sendCmd('root')
	uSleep(SEC*0.5)
	sendCmd('alpine')
end

function ibootFunc()
	sendCmd(' ')
	sendCmd('reboot')
	symbolReadDataAndlogResult(nil, "wdog restart", nil, nil)
	for i=1,20 do
		sendCmd('\r')
		uSleep(SEC*0.2)
	end
end
function diagsFunc()
	sendCmd(' ')
	sendCmd('diags')
end
function rebootFunc()
	sendCmd(' ')
	sendCmd('reboot')
end
function resFunc()
	sendCmd(' ')
	sendCmd('res')
end
function chargeFunc()
	sendCmd(' ')
	sendCmd('charge --set 2400 --force')
end
function offFunc()
	sendCmd(' ')
	sendCmd('device -k GasGauge -e disconnect_bat')
end
