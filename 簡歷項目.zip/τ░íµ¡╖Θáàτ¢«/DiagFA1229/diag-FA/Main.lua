--加载库函数
function loadLib(string)
	dofile(homePath.."/"..string)
end

--下命令，有些命令不能快速下, 需要等待的命令, 需要插入uSleep等待函数
function sendCmd(string)
	sysSendStr(string)
end

--下命令后立即读取数据，配合uSleep等待函数使用
function readData()
	return sysReadStr()
end

--显示结果
function logResult(string)
	sysLogStr(string)
end

--等待，microseconds微妙单位
SEC = 1000*1000
MSec = 1000*1
USec = 1
function uSleep(microseconds)
	sysUSleep(microseconds)
end

--弹窗提醒
function alert(string)
	sysAlertStr(string)
end

--上传服务器
function upLoad()
	sysUpLoadStr()
end

--获取当前时间戳
function getTime()
	return sysGetTime()
end

YES = 1
NO = 0

--microseconds读取的时间间隔
--stringMode, 字符串匹配模式
--completedBlock的Block形式, function completedBlock(string) return parseResult end
--autoLog, 自动显示结果
--count, 循环读取次数
SetAutoLog = 1
ClearAutoLog = 0
function symbolReadDataAndlogResult(microseconds, stringMode, completedBlock, autoLog, count)
	if(stringMode==nil) then return end
	if(milliseconds==nil) then milliseconds = MSec*0.5 end
	if(autoLog==nil) then autoLog = SetAutoLog end
	local backStr = ''

	local stop = NO
	while (stop==NO) do
		uSleep(microseconds)
		local str = readData()
		backStr = backStr..str
		if(autoLog==SetAutoLog) then logResult(str) end
		if (string.match(backStr, stringMode)~=nil) then stop = YES end
		if count~=nil then 
			if count==0 then break end
			count = count-1 
		end
	end

	if(completedBlock==nil) then return backStr end

	local resultStr = completedBlock(backStr)
	if(autoLog==SetAutoLog) then logResult(resultStr..'\n\n') end
	return backStr,resultStr
end

--批量下命令后读取数据, 需要等待的命令不能用
function sectionReadData(milliseconds, completedBlock, autoLog)
	sendCmd('completeCmd')
	stringMode = "completeCmd\r\n\rCommand 'completeCmd' not found%.\r\n%[.*%] :%-%)"

	local str = symbolReadDataAndlogResult(microseconds, stringMode, nil, ClearAutoLog)
	str = string.gsub(str, stringMode, "")
	if(autoLog~=ClearAutoLog) then logResult(str) end

	local resultStr
	if (completedBlock~=nil) then resultStr = logResult(completedBlock(str)) end
	if(autoLog~=ClearAutoLog) then logResult(resultStr) end 

	return str,resultStr
end

--用于下一条命令后读取数据, 适用于需要等待的命令
function singleReadData(microseconds, completedBlock, autoLog)
	local stringMode = '%] :%-%)'
	return symbolReadDataAndlogResult(microseconds, stringMode, completedBlock, autoLog)
end

--下一条命令并且读到笑脸符号
function sendAndReadToSmile(string, autoLog)
	sendCmd(string)
	return singleReadData(nil, nil, autoLog)
end

--下一条命令并且读到指定符号
function sendAndReadToSymbol(string, stringMode, count, autoLog)
	sendCmd(string)
	return symbolReadDataAndlogResult(microseconds, stringMode, completedBlock, autoLog, count)
end

--正负整数的十六进制字符串转十进制数值
function getHexStrValue(hexStr)
	local length = string.len(hexStr) - 2
	local moreValue = "0x1"..string.rep("0", length)
	local lessValue = "0x7"..string.rep("F", length-1)
	local hexStrValue = tonumber(hexStr)

	if hexStrValue > tonumber(lessValue) then
		hexStrValue = -(tonumber(moreValue) - hexStrValue)
	end

	return hexStrValue
end



loadLib("EntryList.lua")

--解释器调用的入口函数
function main(func, shortFunc, nameA, nameB)
	local status, err
	if	nameB~=nil and nameB~="Func" then
		nameB = string.gsub(nameB, '_', ' ')
		logResult("\n\n1. The unit fail at "..nameA.." Station as symbol '"..nameB.."'\n")
		sendAndReadToSmile(" ")
		sendAndReadToSmile("sn")
		sendAndReadToSmile("ver")
		logResult("\n\n2. Manual check the unit, still fail, log as below.\n")
		sendAndReadToSmile(" ")
		status, err = pcall(func)
		logResult("\n\n3. Transfer to EE for further analyse.\n")
	elseif nameB~=nil and nameB=="Func" then
		status, err = pcall(func)
	else
		status, err = pcall(entryPoint)
	end
	logResult('\n\n\n'..err..'!!!\n\n\n')
end

