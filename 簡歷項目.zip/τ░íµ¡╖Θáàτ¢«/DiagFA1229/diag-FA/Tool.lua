function ToolTimeOfEnterDiag()
	local totaltime = 0
	local count = 5

	for times=1,count do
		beginTime = getTime()
		sendAndReadToSmile("diags")
		endTime = getTime()
		intervaltime = endTime - beginTime
		totaltime = intervaltime + totaltime

		logResult("\nbeginTime: "..beginTime)
		logResult("\nendTime: "..endTime)
		logResult("\nintervaltime: "..intervaltime)

		if times == 5 then break end
		
		sendAndReadToSmile(" ")
		sendAndReadToSymbol("res", "Resetting...")
		for i=1,20 do
			sendCmd('\r')
			uSleep(SEC*0.2)
		end
		sendAndReadToSymbol(" ", "\r\n]")
	end

	sendAndReadToSmile("sn")
	sendAndReadToSmile("ver")
	logResult("\n\ntotaltime: "..totaltime)
	logResult("\naverageTime: "..totaltime/count)
end