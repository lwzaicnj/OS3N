/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UIFor4Unit.h		 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UIFor4Unit.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 21.03.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"

#define MaxUnitFlag    10

//extern NSString* getAPPInitLog() ;
@interface UI4M1440X900 : NSObject  {
	//iboutlet variable
	IBOutlet NSWindow *window;
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSBox *boxTestItem ;
	
	IBOutlet NSTableView *testInforTableview1 ;
	IBOutlet NSTableView *testInforTableview2 ;
	IBOutlet NSTableView *testInforTableview3 ;
	IBOutlet NSTableView *testInforTableview4 ;
	IBOutlet NSScrollView* scrollView1 ;
	IBOutlet NSScrollView* scrollView2 ;
	IBOutlet NSScrollView* scrollView3 ;
	IBOutlet NSScrollView* scrollView4 ;
	IBOutlet NSScrollView* textLog ;
	
	IBOutlet NSTextField *textTotalTime1;
	IBOutlet NSTextField *textTotalTime2;
	IBOutlet NSTextField *textTotalTime3;
	IBOutlet NSTextField *textTotalTime4;
	IBOutlet NSTextField *textItemTime1;
	IBOutlet NSTextField *textItemTime2;
	IBOutlet NSTextField *textItemTime3;
	IBOutlet NSTextField *textItemTime4;
	IBOutlet NSTextField *textTestResult1;
	IBOutlet NSTextField *textTestResult2;
	IBOutlet NSTextField *textTestResult3;
	IBOutlet NSTextField *textTestResult4;

    IBOutlet NSButton *btnStartCancel;
    IBOutlet NSButton *btnCancel2;
    IBOutlet NSButton *btnCancel3;
    IBOutlet NSButton *btnCancel4;
	
    IBOutlet NSBox *boxStatus1;
    
    IBOutlet NSBox *boxStatus2;
    
    IBOutlet NSBox *boxStatus3;
    
    IBOutlet NSBox *boxStatus4;
	/*Owner:Henry DATE :2011-03-03 Modify for Display SN on UI*/
	IBOutlet NSTextField *labelSN1;
	IBOutlet NSTextField *labelSN2;
	IBOutlet NSTextField *labelSN3;
	IBOutlet NSTextField *labelSN4;
    
    NSMutableString *stringModuleSn1;
    NSMutableString *stringModuleSn2;
    NSMutableString *stringModuleSn3;
    NSMutableString *stringModuleSn4;
    
    NSDictionary *dicScanData1;
    NSDictionary *dicScanData2;
    NSDictionary *dicScanData3;
    NSDictionary *dicScanData4;
    
    
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	
	int tableViewCnt;
	NSTableView *tableViewForCnt;
	NSTableView *tableViewArray[4];
	BOOL initTableFlag;
	BOOL mTestStartFlag[MaxUnitFlag];
//    BOOL mTestEndFlag[MaxUnitFlag];
	BOOL mTestFlag;
	int refreshTimeCnt;
	
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
    
    NSSpeechSynthesizer *speechSynth;
    NSLock *speechLock;
    
}
- (IBAction)btnStartCancel:(id)sender;
//-(IBAction)btnCancel1_Click:(id)sender;
-(IBAction)btnCancel2_Click:(id)sender;
-(IBAction)btnCancel3_Click:(id)sender;
-(IBAction)btnCancel4_Click:(id)sender;
- (IBAction)labelSN1Change:(id)sender;
- (IBAction)labelSN2Change:(id)sender;
- (IBAction)labelSN3Change:(id)sender;
- (IBAction)labelSN4Change:(id)sender;


//-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer ;
-(void)timerUnitCheckFireMethod:(NSTimer*)theTimer ;
-(void)initUIScanLabelAndText;
-(void)showInitLog;
-(void)setTableBgdColor:(NSInteger)uiIndex;

-(BOOL)checkSN;
-(void)setTableBgdColor1:(NSNotification*)notification;
-(void)setTableBgdColor2:(NSNotification*)notification;
-(void)setTableBgdColor3:(NSNotification*)notification;
-(void)setTableBgdColor4:(NSNotification*)notification;
//-(IBAction)CallEditScriptUI:(id)sender ;
@end

