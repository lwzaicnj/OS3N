//
//  WritePDCA.h
//  qt_simulator
//
//  Created by diags on 3/24/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"

@interface TestItemParse(WritePDCA)
+(void)WritePDCALog:(NSDictionary*)dictKeyDefined ;
+(void)WritePDCALog_NoMLB:(NSDictionary*)dictKeyDefined;
+(void)WritePDCA_tilt:(NSDictionary*)dictKeyDefined ;
+(void)QueryOracle:(NSDictionary*)dictKeyDefined ;
+(void)InsertOracle:(NSDictionary*)dictKeyDefined ;
+(void)ParseStrWithNumber:(NSDictionary*)dictKeyDefined;
+(void)Provisioning:(NSDictionary*)dictKeyDefined;
+(void)UpLoadSFC:(NSDictionary*)dictKeyDefined ;//dsx 03-14
+(void)ParseStrWithNumberAndSpecStr:(NSDictionary*)dictKeyDefined ;
+(void)QueryBobcatUseHTTP:(NSDictionary*)dictKeyDefined ;
+(void)QueryBobcatUseHTTP_MLBSN_Plant_code:(NSDictionary*)dictKeyDefined;
+(void)QueryBobcatUseHTTPRefurbgd:(NSDictionary*)dictKeyDefined ;
+(void)QueryBobcatUseHTTPRefurbgdPlantCode:(NSDictionary*)dictKeyDefined;
+(void)InsertBobcatUseHTTP:(NSDictionary*)dictKeyDefined ;
+(void)ParseNumberAndShowMessageBox:(NSDictionary*)dictKeyDefined;
+(void)ParseLastSixBit:(NSDictionary*)dictKeyDefined;

@end
