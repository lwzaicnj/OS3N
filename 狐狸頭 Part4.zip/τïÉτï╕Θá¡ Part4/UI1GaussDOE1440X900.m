/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI1GaussDOE1440X900.m  $|
 | $Author:: Helen                 $Revision::  1					 $|
 | CREATED: 14.02.11                $Modtime:: 14.02.11 14:06		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI1GaussDOE1440X900.m                                       $
 * *****************  Version 1  *****************
 * User: Helen           Date: 14.02.11   Time: 14:06
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import "UI1GaussDOE1440X900.h"
#import "keysDefine.h"
#import "UICommon.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"
BOOL bReloadTableViewOnceBeforeTest4 = TRUE; //add by judith 20111202


//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGTEXTMIN   = {432,  72,	 960,	149};
static const UI_INFOR LOGTEXTMAX   = {21 ,	72,	 1360,	660};
static const UI_INFOR LOGBUTTONMAX = {20 ,	733, 51,	17};
static const UI_INFOR LABEL1	   = {283,  780, 627,	51};
static const UI_INFOR LABEL2       = {956,  789, 284,	17};

#define TIMERINTERVEL			1  //for check if unit plug in
#define TIMERINTERVEL_REFRESH  0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"



@implementation UI1GaussDOE1440X900
-(id)init
{
	initTableFlag =FALSE;
	tableViewCnt =0;
	refreshTimeCnt=0;
	tableViewForCnt = nil;
	mTestStartFlag = TRUE;
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	fixtureIdPanelController = nil;
	//end
	
	self = [super init] ;
	return self ;
}

-(void)dealloc
{
	/*Owner:Henry DATE :12.16.2010
	 SCRID :043
	 Desc  :Fix memory leak about UI.
	 */
	if(fixtureIdPanelController)
	{
		[fixtureIdPanelController release];
		fixtureIdPanelController =nil ;
	}
	//end
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1Copy  setStringValue:[ScriptParse getUILabel1]];
		[textLabel1 setFrame:(NSMakeRect(LABEL1.x, LABEL1.y, LABEL1.width, LABEL1.height))];
		[textLabel1Copy setFrame:(NSMakeRect(LABEL1.x+1, LABEL1.y+1, LABEL1.width, LABEL1.height))];
	}
	
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
	}
	[window setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:1.0 blue:0.94 alpha:1.0]];
	[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
	[textLabel2 setTextColor:[NSColor blueColor]] ;
	[self initUIScanLabelAndText];

	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	
	NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
															   :self selector
															   :@selector(timerRefreshTableViewMethod:) userInfo
															   :TIMERFORUNITPLUGINCHECK repeats
															   :YES ] retain] ;
	[timerRefreshTableView release] ;
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];
	}
	//Henry add for loop script 20101008
	NSString * strLoopTimes = [ScriptParse getValueFromSummary:STRKEYLOOPTIMES] ;
	if(strLoopTimes != nil)
	{
		mTotalLoopTimes =  [strLoopTimes intValue] ;
		mLoopTimes = [strLoopTimes intValue] ;
	}
	else
	{
		mLoopTimes = 1;
	}
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	/*SCRID-146: for resove the ui crash. Judith, 2011-12-02*/
	if(bReloadTableViewOnceBeforeTest4)
	{
		bReloadTableViewOnceBeforeTest4 = FALSE;
		[tableView reloadData];
	}
	/*SCRID-146: end*/
	refreshTimeCnt++ ;
	
	if (refreshTimeCnt>5)
	{
			NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL target
																	   :self selector
																	   :@selector(timerUnitCheckFireMethod:) userInfo
																	   :TIMERFORUNITPLUGINCHECK repeats
																	   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
	//Henry add for check Fixture ID
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if([UICommon getFixtureIDScanedFlag] ==NO)
		{
			if(![UICommon getShowFixtureIDPanelFlag])
			{
				NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
				if(!fixtureIdPanelController)
					fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
				[fixtureIdPanelController showWindow:self];
				[UICommon setShowFixtureIDPanelFlag:YES];
				return ;
			}
			return ;
		}
	}
	
	if(![UIWinManage isCheckDUTID:1])
	{
		if([UIWinManage getUnit:1])
		{
			if(mTestStartFlag)
			{
				[textLabelTimes1 setStringValue:[NSString stringWithFormat:@"%d",mTotalLoopTimes-mLoopTimes ]];
				[UIWinManage startTest:1 :testInforTableview1 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
				mLoopTimes-- ;
				[textLabelTimes1 setStringValue:[NSString stringWithFormat:@"%d",mTotalLoopTimes-mLoopTimes ]];
				if(mLoopTimes == 0)
					mTestStartFlag=NO ;
			}
		}else
		{
			mTestStartFlag = YES;
			mLoopTimes = mTotalLoopTimes ;
			[textTotalTime1 setStringValue:@"0.0"];
		}
	}
	return ;
}


-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{

	
	if(initTableFlag == FALSE)
	{
		if(tableViewForCnt ==nil)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableView =aTableView;
		}
		else if(tableViewForCnt!= aTableView)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
	//		tableView[tableViewCnt-1]=aTableView;
		}
		
		if(tableViewCnt >= 1)
			initTableFlag = TRUE;
		else
			return nil ;
		return nil ;
	}
	NSInteger resultRowIdx =0;
	 
	
//		[self setTableBgdColor:j];
		if(tableView == aTableView)
			resultRowIdx = 1;

	
	if ([[aTableColumn identifier] isEqual:@"testItem"])
    	return [UIWinManage getTestItemUIName:rowIndex] ;
	else
		return [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex] ;
}

//20100727 add for set box background color for Pass/fail
-(void)setTableBgdColor:(NSInteger)uiIndex
{
	switch (uiIndex) 
	{
		case 0:
			if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
				//For COF
				//[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
			}
			else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:NO];
				[testInforTableview1 setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[testInforTableview1 setUsesAlternatingRowBackgroundColors:YES];
			}
			break;
		default:
			break;
	}
}


-(void)initUIScanLabelAndText
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;

	[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel1Copy setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel2 setTextColor:[NSColor blackColor]];
	[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
	[textLabel1Copy setFont:[NSFont userFontOfSize:28]] ;

	NSArray *arrayUnitInfo = [UIWinManage getTotalUnitInfo];
	if(arrayUnitInfo ==nil)
		NSLog(@"Load Unit Infor error");

	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[ NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}

@end
