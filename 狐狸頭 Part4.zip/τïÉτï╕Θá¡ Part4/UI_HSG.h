//
//  UI_HSG.h
//  iFTS
//
//  Created by Annie on 4/12/13 for HSG station.


#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface UI_HSG : NSObject{
    IBOutlet NSTableView *HSG_tableView;
    IBOutlet NSTextField *inputSNTxt;
    IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;
    
    IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	IBOutlet NSBox *boxTestState ;
    
    IBOutlet NSTextField *totalTimeTxt;
    IBOutlet NSTextField *itemTimeTxt;
    

}
-(IBAction)textSysSnChange:(id)sender;
-(void)setResultAttribut:(int)ItemIndex:(NSString *)ValueTmp:(NSString *)ValueName:(NSString *)TestResult;
-(NSMutableAttributedString *)getResultAttribut:(int)ItemIndex;

-(void)WritePDCA_HSG:(NSDictionary*)dictKeyDefined;
-(void)WriteCSVFile;
-(void)freshTestTimes;

@end
