/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI2M1440X900.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI2M1440X900.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */


#import <Cocoa/Cocoa.h>
#import "FixtureIdPanelController.h"

 /*SCRID:59
  *2011-01-08 Xiu-Xiu modified
  */
@interface UI2M1440X900 : NSObject {
	//for common
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelCopy ;
	IBOutlet NSTextField *textLabelIPVersion ;
	IBOutlet NSWindow *window;
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	FixtureIdPanelController *fixtureIdPanelController;
	NSString *strNeedFixtureID ;
	
	//for Unit 1 
	IBOutlet NSTextField *textTotalTime;
	IBOutlet NSTextField *textItemTime;
	IBOutlet NSTextField *textModuleSN;
	IBOutlet NSTextField *textTestResult;
	IBOutlet NSButton* btnStart;
	IBOutlet NSTableView *tvTableview ;
	IBOutlet NSScrollView *testItemScroView ;
	IBOutlet NSBox *boxTestState ;
	IBOutlet NSTextField* textLabelModuleSn;
	IBOutlet NSTextField* textLabelModuleSnCopy;//dsx-12-16
	NSMutableString *stringModuleSn;
	NSDictionary *dicScanData;
	
	//for Unit 2
	IBOutlet NSTextField *textTotalTime2;
	IBOutlet NSTextField *textItemTime2;
	IBOutlet NSTextField *textModuleSN2;
	IBOutlet NSTextField *textTestResult2;
 	IBOutlet NSButton* btnStart2;
	IBOutlet NSButton* btnPause2;
	IBOutlet NSTableView *tvTableview2 ;
	IBOutlet NSScrollView *testItemScroView2 ;
	IBOutlet NSBox *boxTestState2 ;
	IBOutlet NSTextField* textLabelModuleSn2;
	IBOutlet NSTextField* textLabelModuleSnCopy2;//dsx-12-16
	NSMutableString *stringModuleSn2;
	NSDictionary *dicScanData2;
}
//for common
-(IBAction)setFixtureID:(id)sender;
-(void)showInitLog;

//for unit 1
-(IBAction)btnStart_Click:(id)sender;
-(IBAction)btnCancel_Click:(id)sender;
-(IBAction)textModuleSnChange:(id)sender;
-(void)setTableBgdColor:(NSNotification*)notification;

//for unit 2
-(IBAction)btnStart2_Click:(id)sender;
-(IBAction)btnCancel2_Click:(id)sender;
-(IBAction)textModuleSnChange2:(id)sender;
-(void)setTableBgdColor2:(NSNotification*)notification;
//-(void)testResultHandleThread:(NSTimer*)theTimer ;//dsx 12-28
@end
/*SCRID:59 end
 */