/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa         $Workfile:: UIAlert.h					 $|
 | $Author:: Henry           $Revision::  1							 $|
 | CREATED: 06.09.10         $Modtime:: 11.08.10 15:24				 $|
 | STATE  : Alpha                                                     |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UIAlert.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 06.09.10   Time: 15:58
 * Created in 
 * first implementation
 */

#import <Cocoa/Cocoa.h>
#import <Foundation/NSObject.h>
#import <AppKit/NSGraphics.h>
@class NSTextField, NSPanel, NSArray, NSWindow, NSImage, NSButton, NSError;
/*
enum {
	NSAlertFirstButtonReturn	= 1000,
	NSAlertSecondButtonReturn	= 1001,
	NSAlertThirdButtonReturn	= 1002
};
*/
NSPoint initPosition ;

@interface UIAlert : NSWindowController {
	IBOutlet NSWindow *win;
	IBOutlet NSTextField * labelTitle ;
	IBOutlet NSTextField * labelMessage ;
	IBOutlet NSButton * button1 ;
	IBOutlet NSButton * button2 ;
	IBOutlet NSButton * button3 ;
	IBOutlet NSImageView *imageViewBgd;
    IBOutlet NSTextField * labelTime ;
	NSInteger bntReturnValue ;
	Boolean btnPressedFlag ;
	
}

//message title and message information 
- (void)setMessageText:(NSString *)messageText;
- (void)setInformativeText:(NSString *)informativeText;

// customize the buttons in the alert panel
// buttons are added from right to left (for left to right languages)
- (NSButton *)addButtonWithTitle:(NSString *)title;
-(IBAction)button1_Click:(id)sender ;
-(IBAction)button2_Click:(id)sender ;
-(IBAction)button3_Click:(id)sender ;

// get the buttons, where the rightmost button is at index 0
- (NSArray *)buttons;

// Run the alert as an application-modal panel and return the result
- (NSInteger)runModal;
- (NSInteger)runModalV2:(NSDictionary*)dictKeyDefined;
- (NSInteger)runModalV3:(NSDictionary*)dictKeyDefined;//add by kevin at 2014.10.31 for RX CG-Button 

//Update position of the Alert box
-(void)updatPosition:(NSInteger)totalMessageBox index:(NSInteger)indexOfMessage ;

//get init Position of the Alert Box
+(void)setInitPosition:(NSInteger)totalMessageBox index:(NSInteger)indexOfMessage ;
+(NSPoint)getInitPosition;
/***********************************************************
 **SCRID:50  delete [1] when only show one UI **
 ***********************************************************/
-(void)setWindowTitle:(NSString*)title ;
/** SCRID:50 end**/

@end
