
#import "WritePDCA.h"
#import "Pudding.h"
#import	"SFCConnecter.h"
#import	"UIAlert.h"

#import <Foundation/Foundation.h>
#import <Foundation/NSURL.h>
#import "Foundation/NSURLHandle.h"
#import "Foundation/NSURLRequest.h"
#import "pubFun.h"

extern NSMutableArray *mutArrayTestItemList;
extern NSString* ParametricDataFilePath;
extern NSMutableDictionary *mutDictTestItemActionInfo;

BOOL firstForCSV = YES;
NSMutableArray *itemNameForCSV;
NSMutableArray *upLimitForCSV;
NSMutableArray *lowLimitForCSV;
NSMutableArray *valueForCSV;

NSString *DoefileName=@"";
NSString *keys=@"";
NSString *fileData=@"";
BOOL isNeedCreateFile=YES;
BOOL isNeedCreateKey=YES;

@implementation TestItemParse(WritePDCA)




+(void)WritePDCALog:(NSDictionary*)dictKeyDefined              //Kingking
{
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        itemNameForCSV = [[NSMutableArray alloc] init];
        upLimitForCSV = [[NSMutableArray alloc] init];
        lowLimitForCSV = [[NSMutableArray alloc] init];
        valueForCSV = [[NSMutableArray alloc] init];
    }
    
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;

	NSString* AttributesForPudding = nil;
//	NSString* mBlob = @"";
	NSString* mBlob = nil; //2011-02-28 modified by henry
	NSString* mDevice=@"";
    NSString* mReferenceBufferNameStartTime=@"N/A";
    NSString* mReferenceBufferNameEndTime=@"N/A";
    NSString* mUseMLBSN= nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Attribute"])
		{
			AttributesForPudding =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"Blob"])
		{
			mBlob =  [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Device"])
		{
			mDevice =  [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"ReferenceBufferNameStartTime"])
		{
			mReferenceBufferNameStartTime =  [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"ReferenceBufferNameEndTime"])
		{
			mReferenceBufferNameEndTime =  [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"UseMLBSN"])
		{
			mUseMLBSN =  [dictKeyDefined objectForKey:strKey];
		}
	}

    
    //    add by justin for adding start_time & stop_time  2013-10-11 start
    
    NSString *strDutID = [dictKeyDefined objectForKey:@"DUTID"];
    NSString *strDutIDStartTime = [strDutID stringByAppendingString:@"_StartTime"];
    NSNumber *getStartTime = [mutDictTestItemActionInfo objectForKey:strDutIDStartTime];//the key"StartTime" beed set in "testEngineerThread" fun
    long lStartTime = [getStartTime  longValue];
    //    add by justin for adding start_time & stop_time  2013-10-11 end
    


	NSArray* itemsForPudding =  [[NSArray alloc] init];
	itemsForPudding= [TestItemManage getPDCAInfo:dictKeyDefined] ;
	Pudding* puddintInstanse = [[Pudding alloc] init];
	//Get From Scrip instead of default Value
	NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];// [TestItemManage getBufferValue:dictKeyDefined :@"SN"] ;
    
	if (strSN==nil)
	   strSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	//strSN = @"1236DWF7889990";
	if(strSN==nil)//xiuxiu 2010-10-09 i get mlb number from scan not unit
	{
		 strSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
		NSLog(@"the mlb sn is %@\n",strSN);
	}
    if(mUseMLBSN != nil)
    {
        NSString *mlbsn = [TestItemManage getBufferValue:dictKeyDefined :mUseMLBSN];
        if(mlbsn == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no mlbsn"] ;
            return ;
        }
        strSN = mlbsn;
    }
	if (strSN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no sn"] ;
		return ;
	}
	
    
    
	NSString* initRet = @"";
	initRet = [puddintInstanse initPuddingWithSwVersion:[ScriptParse getSWVerision] SwName:@"iFTS" SerialNumber:strSN LimitsVersion:@"1.1" StationIdentifier:[ScriptParse getStationID] StartTime:lStartTime];
	if([initRet rangeOfString:@"FAIL"].length>0)
	{
		NSLog(@"Write pdca initPuddingWithSwVersion fail");
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
		return;
	}
	NSLog(@"Write pdca initPuddingWithSwVersion pass");
	
	int returnvalue = -1;
	if(nil!= AttributesForPudding)
	{
		//add attributes
		NSArray* Attributes = [AttributesForPudding componentsSeparatedByString:@","];
		for(NSString* Attribute in Attributes )
		{
            Attribute = [ToolFun allTrimFromString:Attribute trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
			NSString*  AttributeValue = [TestItemManage getBufferValue:dictKeyDefined	:Attribute];
			//Get From manager
			if(nil==AttributeValue)
				AttributeValue= @"";
			initRet = [puddintInstanse puddingAttributeWithKeyName:Attribute andKeyValue:AttributeValue];
			if([initRet rangeOfString:@"FAIL"].length>0)
			{
				NSLog(@"Write pdca puddingAttributeWithKeyName fail");
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
				return;
			}
		}	
	}
	NSLog(@"Write pdca puddingAttributeWithKeyName pass");
	//joko add 2010-10-01 add
	if(nil!= mBlob)
	{
		//add attributes
		NSArray* Blobs = [mBlob componentsSeparatedByString:@","];
		for(NSString* Blob in Blobs )
		{
			NSString*  BlobValue = [TestItemManage getBufferValue:dictKeyDefined :Blob];
			//Get From manager
			if(nil==BlobValue)
				BlobValue= @"";
			//SCRID:58
			//modified by Henry on 2011-01-05 for avoiding warning initia variable
//			initRet = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:BlobValue];
//			if([initRet rangeOfString:@"FAIL"].length>0)
			NSInteger iRetValue =-1;
			iRetValue = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:BlobValue];
			if( iRetValue < 0)
			//end
			{
				NSLog(@"Write pdca puddingAddBlob fail");
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
				return;
			}
		}	
	}
	NSLog(@"Write pdca puddingAddBlob pass");
	//joko add 2010-10-01 add end
	NSLog(@"dp dp dp itemsForPudding=%@", itemsForPudding);
    int count = 0;  
	for(NSDictionary* item in itemsForPudding)
	{
		/*Owner:Henry DATE :11.12.2010
		 SCRID :015
		 Desc  :Move DP total item .
		 */
		NSString *testItemName = [item objectForKey:@"TestName"];
		if([testItemName isEqualToString: @"DP HotPlug Detect SleepTest"])
			testItemName=@"DP ";
		//SCRID-151:to resove upload DP items twice to PDCA.joko.2011-12-14.
		if([testItemName rangeOfString:@"DisplayPort"].length > 0)
		{
			continue;
		}
		//SCRID-151:end
		if([testItemName isEqualToString:@"LCD Vendor"] || [testItemName isEqualToString:@"LCD Config"] || [testItemName isEqualToString:@"LED Vendor"] || [testItemName isEqualToString:@"LED Brt"] || [testItemName isEqualToString:@"LED Color"] || [testItemName isEqualToString:@"default LED current"] || [testItemName isEqualToString:@"Full LED current"] || [testItemName isEqualToString:@"MLBSN"] || [testItemName isEqualToString:@"OS Version"] || [testItemName isEqualToString:@"LCD SN"])
        {
            returnvalue = [puddintInstanse puddingWithParametricDataForTestItem:(NSString*)testItemName 
                                                                    SubTestItem:(NSString*)[item objectForKey:@"SubTestName"]==nil?@"":[item objectForKey:@"SubTestName"] 
                                                                 SubSubTestItem:(NSString*)[item objectForKey:@"SubSubTestName"]==nil?@"":[item objectForKey:@"SubSubTestName"] 
                                                                       LowLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"LowLimit"]]?[item objectForKey:@"LowLimit"]:@"N/A" 
                                                                        UpLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"UpLimit"]]?[item objectForKey:@"UpLimit"]:@"N/A" 
                                                                      TestValue:[item objectForKey:@"TestValue"]
                                                                       TestUnit:[item objectForKey:@"TestUnit"]==nil?@"N/A":[item objectForKey:@"TestUnit"]
                                                                     TestResult:[[item objectForKey:@"TestResult"] intValue]
                                                                        FailMsg:[item objectForKey:@"FailMsg"]
                                                                       Priority:0];
        }
        else
        {
            returnvalue = [puddintInstanse puddingWithParametricDataForTestItem:(NSString*)testItemName 
                                                                    SubTestItem:(NSString*)[item objectForKey:@"SubTestName"]==nil?@"":[item objectForKey:@"SubTestName"] 
                                                                 SubSubTestItem:(NSString*)[item objectForKey:@"SubSubTestName"]==nil?@"":[item objectForKey:@"SubSubTestName"] 
                                                                       LowLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"LowLimit"]]?[item objectForKey:@"LowLimit"]:@"N/A" 
                                                                        UpLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"UpLimit"]]?[item objectForKey:@"UpLimit"]:@"N/A" 
                                                                      TestValue:[ToolFun isNumber:[item objectForKey:@"TestValue"]]?[item objectForKey:@"TestValue"]:@"N/A"
                                                                       TestUnit:[item objectForKey:@"TestUnit"]==nil?@"N/A":[item objectForKey:@"TestUnit"]
                                                                     TestResult:[[item objectForKey:@"TestResult"] intValue]
                                                                        FailMsg:[item objectForKey:@"FailMsg"]
                                                                       Priority:0];
        }
		//henry add end
		NSLog(@"dp dp dp testItemName=%@", testItemName);
		if(returnvalue < 0)
		{
			NSLog(@"Write pdca puddingWithParametricDataForTestItem fail");
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD TESTRESULT FAIL"];
			return;
		}
        
        if (++count == 400) //judith add 2012-06-09
        {
            sleep(1);
        }
	}
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        NSLog(@"%@",ParametricDataFilePath);
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];
        [filehandTmp seekToEndOfFile];
        if (filehandTmp!=nil)
        {
            if(firstForCSV)
            {   
                firstForCSV = NO;
                for(int i = 0;i < [itemNameForCSV count];i++)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[[itemNameForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"Upper Limit ----->,,,,,," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                for(int i = 0;i < [upLimitForCSV count];i++)
                {
                    [filehandTmp writeData:[NSData dataWithData:[[upLimitForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"Lower Limit ----->,,,,,," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                for(int i = 0;i < [lowLimitForCSV count];i++)
                {
                    [filehandTmp writeData:[NSData dataWithData:[[lowLimitForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            NSString *dataResultBoardId =[TestItemManage getUnitValue:dictKeyDefined:STRKEYBOARDID];
            NSString *barcode = [TestItemManage getSFCValue:dictKeyDefined :@"strBarcodeSn"];
            if([dataResultBoardId rangeOfString:@"0A"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J128," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            else if([dataResultBoardId rangeOfString:@"0C"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J127," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            else if([dataResultBoardId rangeOfString:@"0E"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J83," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            else
                [filehandTmp writeData:[NSData dataWithData:[@"unknow type," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
            [filehandTmp writeData:[NSData dataWithData:[strSN dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[barcode dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            BOOL result = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
            if(result)
            {
                [filehandTmp writeData:[NSData dataWithData:[@"PASS" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            else
            {
                [filehandTmp writeData:[NSData dataWithData:[@"FAIL" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            /*add start time*/
            [filehandTmp writeData:[NSData dataWithData:[[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameStartTime] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            /*add finish time*/
            [filehandTmp writeData:[NSData dataWithData:[[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameEndTime] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            for(int i = 0;i < [valueForCSV count];i++)
            {
                [filehandTmp writeData:[NSData dataWithData:[[valueForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            
            
            [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
        [itemNameForCSV release];
        [upLimitForCSV release];
        [lowLimitForCSV release];
        [valueForCSV release];
    }
    //add by Rick for write csvfile 2012-10-27
	NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
	
	NSString* Logpath = [TestItemManage getLogPath:dictKeyDefined];
	if(nil != Logpath )
	{
		returnvalue = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:Logpath];
		if( returnvalue < 0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD BLOB FAIL"];
			return;
		}
	}
	NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
	
	NSString * reErrorM =@"Fail";
	//returnvalue = [puddintInstanse puddingCommit];
    reErrorM = [puddintInstanse puddingCommit:strSN];
	
	//henry modified 2011-02-24
	NSString* strUIName=[ScriptParse getValueFromSummary:@"SwitchUI"];
	if(![strUIName isEqualToString:@"UI3Prox"])
	{
		if([reErrorM rangeOfString:@"FAIL"].length>0)
		{
			NSLog(@"Write pdca puddingCommit fail");
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
		}
		else
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo =@"Pass" ;
			NSLog(@"Write pdca puddingCommit pass");
		}
	}
	else
	{
		if([reErrorM rangeOfString:@"FAIL"].length>0)
		{
			NSLog(@"Write pdca puddingCommit fail");
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
			
			NSString *mWriteCmd = @"pattern 2\n" ;
			[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = 6 ;
			BOOL bPassFlag= FALSE;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				{
					NSString *dataResult = [self ReceData:dictKeyDefined] ;
					if([dataResult rangeOfString:@"Finish"].length >0)
					{
						bPassFlag = TRUE;
						break;
					}
				}
				else
				{
					[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
					usleep(500000) ; //delay 500
				}
			}
			if(bPassFlag ==FALSE)
			{
				enumResult =RESULT_FOR_FAIL ;
				strTestResultForUIinfo=@"Write PDCA Pass but Send diags cmd to change picture Fail";
			}
			
		}
		else
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo =@"Pass" ;
			NSLog(@"Write pdca puddingCommit pass");
			
			BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
			
			NSString *mWriteCmd = nil;
			if(flag)
				mWriteCmd = @"pattern 1\n" ;
			else 
				mWriteCmd = @"pattern 2\n" ;
			
			[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = 6 ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			BOOL bPassFlag= FALSE;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				{
					NSString *dataResult = [self ReceData:dictKeyDefined] ;
					if([dataResult rangeOfString:@"Finish"].length >0)
					{
						bPassFlag = TRUE;
						break;
					}
				}
				else
				{
					[TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
					usleep(500000) ; //delay 500
				}
			}
			if(bPassFlag ==FALSE)
			{
				enumResult =RESULT_FOR_FAIL ;
				strTestResultForUIinfo=@"Write PDCA Pass but Send diags cmd to change picture Fail";
			}
			
		}
	}

    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
 
}

+(void)WritePDCALog_NoMLB:(NSDictionary*)dictKeyDefined              //JianSheng
{
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        itemNameForCSV = [[NSMutableArray alloc] init];
        upLimitForCSV = [[NSMutableArray alloc] init];
        lowLimitForCSV = [[NSMutableArray alloc] init];
        valueForCSV = [[NSMutableArray alloc] init];
    }
    
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
    
	NSString* AttributesForPudding = nil;
    //	NSString* mBlob = @"";
	NSString* mBlob = nil; //2011-02-28 modified by henry
	NSString* mDevice=@"";
    NSString* mReferenceBufferNameStartTime=@"N/A";
    NSString* mReferenceBufferNameEndTime=@"N/A";
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Attribute"])
		{
			AttributesForPudding =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"Blob"])
		{
			mBlob =  [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Device"])
		{
			mDevice =  [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"ReferenceBufferNameStartTime"])
		{
			mReferenceBufferNameStartTime =  [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"ReferenceBufferNameEndTime"])
		{
			mReferenceBufferNameEndTime =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    
	NSArray* itemsForPudding =  [[NSArray alloc] init];
	itemsForPudding= [TestItemManage getPDCAInfo:dictKeyDefined] ;
	Pudding* puddintInstanse = [[Pudding alloc] init];
	//Get From Scrip instead of default Value
	NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];// [TestItemManage getBufferValue:dictKeyDefined :@"SN"] ;
    
	if (strSN==nil)
        strSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	//strSN = @"1236DWF7889990";
	if(strSN==nil)//xiuxiu 2010-10-09 i get mlb number from scan not unit
	{
        strSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN];
		NSLog(@"the mlb sn is %@\n",strSN);
	}
	if (strSN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no sn"] ;
		return ;
	}
	
    
    /*
     NSString* initRet = @"";
     initRet = [puddintInstanse initPuddingWithSwVersion:[ScriptParse getSWVerision] SwName:@"iFTS" SerialNumber:strSN LimitsVersion:@"1.1" StationIdentifier:[ScriptParse getStationID]];
     if([initRet rangeOfString:@"FAIL"].length>0)
     {
     NSLog(@"Write pdca initPuddingWithSwVersion fail");
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
     return;
     }
     NSLog(@"Write pdca initPuddingWithSwVersion pass");
     
     int returnvalue = -1;
     if(nil!= AttributesForPudding)
     {
     //add attributes
     NSArray* Attributes = [AttributesForPudding componentsSeparatedByString:@","];
     for(NSString* Attribute in Attributes )
     {
     NSString*  AttributeValue = [TestItemManage getBufferValue:dictKeyDefined	:Attribute];
     //Get From manager
     if(nil==AttributeValue)
     AttributeValue= @"";
     initRet = [puddintInstanse puddingAttributeWithKeyName:Attribute andKeyValue:AttributeValue];
     if([initRet rangeOfString:@"FAIL"].length>0)
     {
     NSLog(@"Write pdca puddingAttributeWithKeyName fail");
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
     return;
     }
     }	
     }
     NSLog(@"Write pdca puddingAttributeWithKeyName pass");
     //joko add 2010-10-01 add
     if(nil!= mBlob)
     {
     //add attributes
     NSArray* Blobs = [mBlob componentsSeparatedByString:@","];
     for(NSString* Blob in Blobs )
     {
     NSString*  BlobValue = [TestItemManage getBufferValue:dictKeyDefined :Blob];
     //Get From manager
     if(nil==BlobValue)
     BlobValue= @"";
     //SCRID:58
     //modified by Henry on 2011-01-05 for avoiding warning initia variable
     //			initRet = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:BlobValue];
     //			if([initRet rangeOfString:@"FAIL"].length>0)
     NSInteger iRetValue =-1;
     iRetValue = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:BlobValue];
     if( iRetValue < 0)
     //end
     {
     NSLog(@"Write pdca puddingAddBlob fail");
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :initRet];
     return;
     }
     }	
     }
     NSLog(@"Write pdca puddingAddBlob pass");
     //joko add 2010-10-01 add end
     NSLog(@"dp dp dp itemsForPudding=%@", itemsForPudding);
     
     */
    
    int returnvalue = -1;
    int count = 0;  
	for(NSDictionary* item in itemsForPudding)
	{
		/*Owner:Henry DATE :11.12.2010
		 SCRID :015
		 Desc  :Move DP total item .
		 */
		NSString *testItemName = [item objectForKey:@"TestName"];
		if([testItemName isEqualToString: @"DP HotPlug Detect SleepTest"])
			testItemName=@"DP ";
		//SCRID-151:to resove upload DP items twice to PDCA.joko.2011-12-14.
		if([testItemName rangeOfString:@"DisplayPort"].length > 0)
		{
			continue;
		}
		//SCRID-151:end
		if([testItemName isEqualToString:@"LCD Vendor"] || [testItemName isEqualToString:@"LCD Config"] || [testItemName isEqualToString:@"LED Vendor"] || [testItemName isEqualToString:@"LED Brt"] || [testItemName isEqualToString:@"LED Color"] || [testItemName isEqualToString:@"default LED current"] || [testItemName isEqualToString:@"Full LED current"] || [testItemName isEqualToString:@"MLBSN"] || [testItemName isEqualToString:@"OS Version"])
        {
            returnvalue = [puddintInstanse puddingWithParametricDataForTestItem_NoMLB:(NSString*)testItemName 
                                                                          SubTestItem:(NSString*)[item objectForKey:@"SubTestName"]==nil?@"":[item objectForKey:@"SubTestName"] 
                                                                       SubSubTestItem:(NSString*)[item objectForKey:@"SubSubTestName"]==nil?@"":[item objectForKey:@"SubSubTestName"] 
                                                                             LowLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"LowLimit"]]?[item objectForKey:@"LowLimit"]:@"N/A" 
                                                                              UpLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"UpLimit"]]?[item objectForKey:@"UpLimit"]:@"N/A" 
                                                                            TestValue:[item objectForKey:@"TestValue"]
                                                                             TestUnit:[item objectForKey:@"TestUnit"]==nil?@"N/A":[item objectForKey:@"TestUnit"]
                                                                           TestResult:[[item objectForKey:@"TestResult"] intValue]
                                                                              FailMsg:[item objectForKey:@"FailMsg"]
                                                                             Priority:0];
        }
        else
        {
            returnvalue = [puddintInstanse puddingWithParametricDataForTestItem_NoMLB:(NSString*)testItemName 
                                                                          SubTestItem:(NSString*)[item objectForKey:@"SubTestName"]==nil?@"":[item objectForKey:@"SubTestName"] 
                                                                       SubSubTestItem:(NSString*)[item objectForKey:@"SubSubTestName"]==nil?@"":[item objectForKey:@"SubSubTestName"] 
                                                                             LowLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"LowLimit"]]?[item objectForKey:@"LowLimit"]:@"N/A" 
                                                                              UpLimit:(NSString*)[ToolFun isNumber:[item objectForKey:@"UpLimit"]]?[item objectForKey:@"UpLimit"]:@"N/A" 
                                                                            TestValue:[ToolFun isNumber:[item objectForKey:@"TestValue"]]?[item objectForKey:@"TestValue"]:@"N/A"
                                                                             TestUnit:[item objectForKey:@"TestUnit"]==nil?@"N/A":[item objectForKey:@"TestUnit"]
                                                                           TestResult:[[item objectForKey:@"TestResult"] intValue]
                                                                              FailMsg:[item objectForKey:@"FailMsg"]
                                                                             Priority:0];
        }
		//henry add end
		NSLog(@"dp dp dp testItemName=%@", testItemName);
		if(returnvalue < 0)
		{
			NSLog(@"Write pdca puddingWithParametricDataForTestItem fail");
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD TESTRESULT FAIL"];
			return;
		}
        
        if (++count == 400) //judith add 2012-06-09
        {
            sleep(1);
        }
	}
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        NSLog(@"%@",ParametricDataFilePath);
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:ParametricDataFilePath];
        [filehandTmp seekToEndOfFile];
        if (filehandTmp!=nil)
        {
            if(firstForCSV)
            {   
                firstForCSV = NO;
                for(int i = 0;i < [itemNameForCSV count];i++)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[[itemNameForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"Upper Limit ----->,,,,,," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                for(int i = 0;i < [upLimitForCSV count];i++)
                {
                    [filehandTmp writeData:[NSData dataWithData:[[upLimitForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"Lower Limit ----->,,,,,," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                for(int i = 0;i < [lowLimitForCSV count];i++)
                {
                    [filehandTmp writeData:[NSData dataWithData:[[lowLimitForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                }
                [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            NSString *dataResultBoardId =[TestItemManage getUnitValue:dictKeyDefined:STRKEYBOARDID];
            NSString *barcode = [TestItemManage getScanValue:dictKeyDefined :@"strBarcodeSn"];
            if([dataResultBoardId rangeOfString:@"0A"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J128," dataUsingEncoding:NSASCIIStringEncoding]]] ;
           // else if([dataResultBoardId rangeOfString:@"0C"].length > 0)
            else if([dataResultBoardId rangeOfString:@"08"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J127," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            else if([dataResultBoardId rangeOfString:@"0E"].length > 0)
                [filehandTmp writeData:[NSData dataWithData:[@"J83," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            else
                [filehandTmp writeData:[NSData dataWithData:[@"unknow type," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
            [filehandTmp writeData:[NSData dataWithData:[strSN dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[barcode dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            BOOL result = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
            if(result)
            {
                [filehandTmp writeData:[NSData dataWithData:[@"PASS" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            else
            {
                [filehandTmp writeData:[NSData dataWithData:[@"FAIL" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            /*add start time*/
            [filehandTmp writeData:[NSData dataWithData:[[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameStartTime] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            /*add finish time*/
            [filehandTmp writeData:[NSData dataWithData:[[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameEndTime] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            
            for(int i = 0;i < [valueForCSV count];i++)
            {
                [filehandTmp writeData:[NSData dataWithData:[[valueForCSV objectAtIndex:i] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            }
            
            
            [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
        [itemNameForCSV release];
        [upLimitForCSV release];
        [lowLimitForCSV release];
        [valueForCSV release];
    }
    //add by Rick for write csvfile 2012-10-27
    
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    
    /*
     NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
     
     NSString* Logpath = [TestItemManage getLogPath:dictKeyDefined];
     if(nil != Logpath )
     {
     returnvalue = [puddintInstanse puddingBlobWithNameInPDCA:[ScriptParse getStationID]	FilePath:Logpath];
     if( returnvalue < 0)
     {
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ADD BLOB FAIL"];
     return;
     }
     }
     NSLog(@"Write pdca puddingWithParametricDataForTestItem pass");
     
     NSString * reErrorM =@"Fail";
     //returnvalue = [puddintInstanse puddingCommit];
     reErrorM = [puddintInstanse puddingCommit];
     
     //henry modified 2011-02-24
     NSString* strUIName=[ScriptParse getValueFromSummary:@"SwitchUI"];
     if(![strUIName isEqualToString:@"UI3Prox"])
     {
     if([reErrorM rangeOfString:@"FAIL"].length>0)
     {
     NSLog(@"Write pdca puddingCommit fail");
     enumResult =RESULT_FOR_FAIL ;
     strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
     }
     else
     {
     enumResult =RESULT_FOR_PASS ;
     strTestResultForUIinfo =@"Pass" ;
     NSLog(@"Write pdca puddingCommit pass");
     }
     }
     else
     {
     if([reErrorM rangeOfString:@"FAIL"].length>0)
     {
     NSLog(@"Write pdca puddingCommit fail");
     enumResult =RESULT_FOR_FAIL ;
     strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
     
     NSString *mWriteCmd = @"pattern 2\n" ;
     [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
     NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
     int iTmp = 6 ;
     BOOL bPassFlag= FALSE;
     int timeInterval = - [dateTmp timeIntervalSinceNow] ;
     while (timeInterval<=iTmp)
     {
     timeInterval = -[dateTmp timeIntervalSinceNow] ;
     
     if ([self CheckReceDataIsComplete:dictKeyDefined]) 
     {
     NSString *dataResult = [self ReceData:dictKeyDefined] ;
     if([dataResult rangeOfString:@"Finish"].length >0)
     {
     bPassFlag = TRUE;
     break;
     }
     }
     else
     {
     [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
     usleep(500000) ; //delay 500
     }
     }
     if(bPassFlag ==FALSE)
     {
     enumResult =RESULT_FOR_FAIL ;
     strTestResultForUIinfo=@"Write PDCA Pass but Send diags cmd to change picture Fail";
     }
     
     }
     else
     {
     enumResult =RESULT_FOR_PASS ;
     strTestResultForUIinfo =@"Pass" ;
     NSLog(@"Write pdca puddingCommit pass");
     
     BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
     
     NSString *mWriteCmd = nil;
     if(flag)
     mWriteCmd = @"pattern 1\n" ;
     else 
     mWriteCmd = @"pattern 2\n" ;
     
     [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
     NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
     int iTmp = 6 ;
     int timeInterval = - [dateTmp timeIntervalSinceNow] ;
     BOOL bPassFlag= FALSE;
     while (timeInterval<=iTmp)
     {
     timeInterval = -[dateTmp timeIntervalSinceNow] ;
     
     if ([self CheckReceDataIsComplete:dictKeyDefined]) 
     {
     NSString *dataResult = [self ReceData:dictKeyDefined] ;
     if([dataResult rangeOfString:@"Finish"].length >0)
     {
     bPassFlag = TRUE;
     break;
     }
     }
     else
     {
     [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
     usleep(500000) ; //delay 500
     }
     }
     if(bPassFlag ==FALSE)
     {
     enumResult =RESULT_FOR_FAIL ;
     strTestResultForUIinfo=@"Write PDCA Pass but Send diags cmd to change picture Fail";
     }
     
     }
     }
     
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
     */
}

+(void)WritePDCA_tilt:(NSDictionary*)dictKeyDefined 
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	
	NSArray* itemsForPudding =  [[NSArray alloc] init];
	itemsForPudding= [TestItemManage getPDCAInfo:dictKeyDefined] ;
	Pudding* puddintInstanse = [[Pudding alloc] init];
	//Get From Scrip instead of default Value
	NSString *strSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYSYSSN] ;
	//-Get Tilt_SN From instead of SN
	if (strSN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no sn"] ;
		return ;
	}
	
	[puddintInstanse initPuddingWithSwVersion:[ScriptParse getSWVerision] SwName:@"Test Studio" SerialNumber:strSN LimitsVersion:@"1.1" StationIdentifier:[ScriptParse getStationID] StartTime:nil];
	
	for(NSDictionary* item in itemsForPudding)
	{
		
		//NSLog(@" test name =%@",item);
		
		[puddintInstanse puddingWithParametricDataForTestItem:(NSString*)[item objectForKey:@"TestName"] 
												 SubTestItem:(NSString*)[item objectForKey:@"SubTestName"]==nil?@"N/A":[item objectForKey:@"SubTestName"] 
											  SubSubTestItem:(NSString*)[item objectForKey:@"SubSubTestName"]==nil?@"N/A":[item objectForKey:@"SubSubTestName"] 
													LowLimit:(NSString*)[item objectForKey:@"LowLimit"]==nil?@"N/A":[item objectForKey:@"LowLimit"] 
													 UpLimit:(NSString*)[item objectForKey:@"UpLimit"]==nil?@"N/A":[item objectForKey:@"UpLimit"] 
												   TestValue:[ToolFun isNumber:[item objectForKey:@"TestValue"]]?[item objectForKey:@"TestValue"]:@"N/A"
													TestUnit:[item objectForKey:@"TestUnit"]==nil?@"N/A":[item objectForKey:@"TestUnit"]
												  TestResult:[[item objectForKey:@"TestResult"] intValue]
													 FailMsg:[item objectForKey:@"FailMsg"]
													Priority:0];
	}
	//NSString* PuddingMsgForUI = [NSString alloc];
	
	//
	NSString* reErrorM = [puddintInstanse puddingCommit];
	if([reErrorM rangeOfString:@"FAIL"].length>0)
	{
		NSLog(@"Write pdca puddingCommit fail");
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo =  reErrorM;//@"UUTDONE_FAIL  Ethernet IS NOT OK or Pudding is Not Running!~" ;
	}
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo =@"Pass" ;
		NSLog(@"Write pdca puddingCommit pass");
	}
	
	//
	/*int returnvalue = [puddintInstanse puddingCommit];
	
	if(returnvalue < 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}else //failse conditional
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = PuddingMsgForUI ;
	}
	*/
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;

}

+(void)InsertOracle:(NSDictionary*)dictKeyDefined 
{	
	NSString *mUserName=@""  ;
	NSString *mPWD = @"" ;
    NSString *mUserNameBZ=@""  ;
	NSString *mPWDBZ = @"" ;
	NSString *mDSN =@"";
	NSString *mQueryString=@"";
	NSString *mWhetherForceInsert=@"yes";
	//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
	NSString *mDSN_LH =@"";
	NSString *mDSN_CD =@"";
    NSString *mDSN_BZ =@"";
	NSString *mLocate=@"";
	//SCRID:93 end
	NSString *mInsertFailString=@"";
    NSString *mInsertStringBZ=@"";
    NSString *mInsertFailStringBZ=@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"UserName"])
		{
			mUserName =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"PassWord"])
		{
			mPWD =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserNameBZ"])
		{
			mUserNameBZ =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"PassWordBZ"])
		{
			mPWDBZ =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn"])
		{
			mDSN =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"InsertString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"WhetherForceInsert"])
		{
			mWhetherForceInsert =  [dictKeyDefined objectForKey:strKey];
		}
		//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
		else if ([strKey isEqualToString:@"Locate"])
		{
			mLocate =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_LH"])
		{
			mDSN_LH =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_CD"])
		{
			mDSN_CD =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_BZ"])
		{
			mDSN_BZ =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"InsertFailString"])
		{
			mInsertFailString =  [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"InsertStringBZ"])
		{
			mInsertStringBZ =  [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"InsertFailStringBZ"])
		{
			mInsertFailStringBZ =  [dictKeyDefined objectForKey:strKey];
		}
		//SCRID:93 end
	}
	//dsx 2010-07-27
	if([mWhetherForceInsert isEqualToString:@"no"])
	{
		BOOL flag =NO;
		
		flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
		//DSX 2010 07 26
		
		if(!flag)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Need UpLoad SFC"] ;
			return;
		}
	
	}
	/*SCRID-103: Force Insert Fail Log to SFC. Joko 2011-09-19*/
	else
	{
		if(![TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
			mQueryString = mInsertFailString;
	}
	/*SCRID-103:*/
	
	//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
	if([mLocate isEqualToString:@"FATP"])
	{
		NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
		if(!file)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
			return;
		}
		NSString *site = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE" Postfix:@"PRODUCT"];
		site = [ToolFun deleteFromString:site trimStr:@"\n"];
		site = [ToolFun deleteFromString:site trimStr:@"\r"];
		if([site rangeOfString:@"FXLH"].length > 0)
		{
			mDSN=mDSN_LH;
		}
		else if ([site rangeOfString:@"FXCD"].length > 0)
		{
			mDSN=mDSN_CD;
		}else if ([site rangeOfString:@"FXBZ"].length > 0)
		{
			mDSN=mDSN_BZ;
			if([mUserNameBZ length] == 0 && [mPWDBZ length] == 0)
                ;
			else
			{
				mUserName = mUserNameBZ;
				mPWD = mPWDBZ;
			}
            
            if([mInsertStringBZ length] == 0 && [mInsertFailStringBZ length] == 0)
                ;
			else
			{
				mQueryString=mInsertStringBZ;
				if(![TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
                    mQueryString = mInsertFailStringBZ;
			}
		}else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;	
			return;
		}
	}
	//SCRID:93 end
	
	SFCConnecter* mSFCconnecter  =  [[[SFCConnecter alloc] init] autorelease];
	//added by caijunbo20100727
	 NSString *strTestResultForUIinfo=nil;
	 NSArray* DNSARR = [mDSN componentsSeparatedByString:@","];
	 if (DNSARR==nil)
	 {
		 strTestResultForUIinfo = @"DSN in Script Error" ;
		 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :strTestResultForUIinfo] ;
		 return;		
	 }
	 bool connectFla = false;
	 for (NSString* dsn in DNSARR) 
	 {
	 
		 if([mSFCconnecter ConnectSFCWithUserName:mUserName	PassWord:mPWD DSN:dsn]==true)//1
		 {
			 connectFla = TRUE;
			 break;
		 }
	 
	 }
	 
	 if(!connectFla)
	 {
		 strTestResultForUIinfo = @"All DSN Can't Connect !" ;
		 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :strTestResultForUIinfo] ;
		 return;	
	 }
// added end by caijunbo 20100727
	
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		[mSFCconnecter CloseConnect]; //add by giga
		return ;
	}	
	
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SN]" withString:sN];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"||" withString:@";"];
	
	//joko Get buffer value and use it replace QueryString
	NSString *tmpQueryString = mQueryString;
	NSArray *bufferNames = nil;
	if ([tmpQueryString rangeOfString:@"BufferName_"].length>0)
	{
		bufferNames = [tmpQueryString componentsSeparatedByString:@"BufferName_"];
		for(int i=1; i<[bufferNames count]; i++)
		{	
			NSString *strBufferName = @"";
			
			NSRange rg = [[bufferNames objectAtIndex:i] rangeOfString:@"'"];
			if(rg.location > 0)
			{
				strBufferName = [[bufferNames objectAtIndex:i] substringToIndex:rg.location];
			}
			if (strBufferName==nil)
				strBufferName = @"";
			
			NSString *strBufferVanlue = [TestItemManage getBufferValue:dictKeyDefined :strBufferName];	
			if (strBufferVanlue==nil)
				strBufferVanlue = @"";
			if ([strBufferVanlue isEqualToString:@"STOP"])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid Value,No Upload SFC"] ;
				[mSFCconnecter CloseConnect]; //add by giga
				return;
			}
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"BufferName_" withString:@""];
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:strBufferName withString:strBufferVanlue];
		}
	}
	//end
	
	NSLog(@"\n mQueryString=%@",mQueryString);
	bool resultstr = [mSFCconnecter insertSQL:mQueryString];

	[mSFCconnecter CloseConnect];
	if(resultstr)
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	else
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
	
	return;
}

+(void)QueryOracle:(NSDictionary*)dictKeyDefined 
{
	
	NSString *mUserName=@""  ;
	NSString *mPWD = @"" ;
	NSString *mDSN =@"";
    NSString *mUserNameBZ=@""  ;
	NSString *mPWDBZ = @"" ;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
	NSString *mDSN_LH =@"";
	NSString *mDSN_CD =@"";
    NSString *mDSN_BZ =@"";
	NSString *mLocate=@"";
	NSString *mLocation=@"";//dsx -04-13
	//SCRID:93 end
	
	NSString *strTestResultForUIinfo = @"" ;
	enum TestResutStatus enumResult ;
	enumResult = RESULT_FOR_FAIL;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"UserName"])
		{
			mUserName =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"PassWord"])
		{
			mPWD =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsnBZ"])
		{
			mUserNameBZ =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"PassWordBZ"])
		{
			mPWDBZ =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn"])
		{
			mDSN =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"JudgeLocation"])//dsx-04-13
		{
			mLocation =  [dictKeyDefined objectForKey:strKey];
		}
		//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
		else if ([strKey isEqualToString:@"Locate"])
		{
			mLocate =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_LH"])
		{
			mDSN_LH =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_CD"])
		{
			mDSN_CD =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn_BZ"])
		{
			mDSN_BZ =  [dictKeyDefined objectForKey:strKey];
		}
		//SCRID:93 end
		
	}
	
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :@""]; //Kenshin 2011.05.23
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX15SN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYCUSTPARTNO :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX17SN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :@""];
	//2010-09-14 joko add
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX23 :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX24 :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX25 :@""];
	
	//SCRID:129 Add burn camera barcode by Helen 20110810
	[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :@""];
	//SCRID:129 end
	
	// J1J2-SCRID:1 add by Evan on 2011-03-17
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX26 :@""];
	// J1J2-SCRID:1 add end;
	
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :@""];
	//2010-09-14 joko add end
	//dsx 03-14 get x26sn from sfc
	//[TestItemManage setSFCValue:dictKeyDefined :STRKEYX26 :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYX26RECORD :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBRECORD :@""];
	//end
	
	//dsx-04-13 judge which ip should connect LH or CD
	if([mLocation isEqualToString:@"yes"])
	{
		NSString *ghInfor=[NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil] ;
		if(!ghInfor)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
			return;
		}
		NSString *site=[ToolFun getStrFromPrefixAndPostfix:ghInfor Prefix:@"SITE" Postfix:@"PRODUCT"] ;//dsx 04-13
		
		site=[site stringByReplacingOccurrencesOfString:@" " withString:@""];//dsx 04-13
		
		if(site==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get infor from local fail"] ;
			return;
		}
		
		if([site rangeOfString:@"FXLH"].length > 0)
			mDSN=@"PRODUCTLINE_SMT";
		else if([site rangeOfString:@"FXCD"].length > 0)
			mDSN=@"PRODUCTLINE_SMT_TWO";
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;	
			return;
		}
	}
	
	//SCRID:93 Modify for combining LH&CD SFC by using unitive overlay by Jack 2011-05-13
	if([mLocate isEqualToString:@"FATP"])
	{
		NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
		if(!file)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
			return;
		}
		NSString *site = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE" Postfix:@"PRODUCT"];
		site = [ToolFun deleteFromString:site trimStr:@"\n"];
		site = [ToolFun deleteFromString:site trimStr:@"\r"];
		if([site rangeOfString:@"FXLH"].length > 0)
		{
			mDSN=mDSN_LH;
		}
		else if ([site rangeOfString:@"FXCD"].length > 0)
		{
			mDSN=mDSN_CD;
		}else if ([site isEqualToString:@"FXBZ"])
		{
			mDSN=mDSN_BZ;
			if(mUserNameBZ == nil && mPWDBZ == nil);
			else
			{
				mUserName = mUserNameBZ;
				mPWD = mPWDBZ;
			}
		}else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;	
			return;
		}
	}
	// SCRID:93 end
	
	SFCConnecter* mSFCconnecter  =[[[SFCConnecter alloc] init] autorelease];
	
	NSArray* DNSARR = [mDSN componentsSeparatedByString:@","];
	if (DNSARR==nil)
	{
		strTestResultForUIinfo = @"DSN in Script  Error" ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
		return;		
	}
	bool connectFla = false;
	for (NSString* dsn in DNSARR) 
	{
		
		if([mSFCconnecter ConnectSFCWithUserName:mUserName	PassWord:mPWD DSN:dsn]==true)//1
		{
			connectFla = TRUE;
			break;
		}
	}
	
	if(!connectFla)
	{
		strTestResultForUIinfo = @"All DSN Can't Connect 1! Due to Network or SFC error" ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
		return;	
	}
	
	
   	NSString *sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	
	if (sN==nil) //add by giga
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no sn"] ;
		[mSFCconnecter CloseConnect] ;// add by giga ,close the connect
		return;
	}
	//dengshouxiu 2010-07-24
	
	//NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"]; //dsx 04-06 unuse variable
	
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[0]" withString:sN];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"||" withString:@";"];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[ModuleSN]" withString:sN];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SensorSN]" withString:sN];
	
	//bool bK93 = FALSE;
	//bool bK94 = FALSE;
	//bool bK95 = FALSE;
	
	// J1J2-SCRID:1 add by Evan on 2011-03-17
	bool bJ1 = FALSE;
	// J1J2-SCRID:1 add end;
	
	NSString* HWconfig = @"";
	
	
	// J1J2-SCRID:1 Modify by Evan on 2011-03-17
	NSString* boardID_fromBuffer = @"";
	boardID_fromBuffer = [TestItemManage getBufferValue:dictKeyDefined :@"boadidbuffer"] ;
	if([boardID_fromBuffer length] > 0)
	{
		boardID_fromBuffer = [boardID_fromBuffer stringByReplacingOccurrencesOfString:@"0x" withString:@""];
		boardID_fromBuffer = [boardID_fromBuffer stringByReplacingOccurrencesOfString:@"0X" withString:@""];
		
		// J1J2-SCRID:1 add by Evan on 2011-03-17
		if([boardID_fromBuffer rangeOfString:@"0A"].length > 0) //0x00 == J1
		{
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"X26_SN;" withString:@""];
			bJ1 = TRUE;
		}
		// J1J2-SCRID:1 add end;
		
		//joko add end 2010-09-08
	}
	
	NSString* resultstr = [mSFCconnecter QueryResultWithSql:mQueryString];
	[mSFCconnecter CloseConnect];
	mSFCconnecter = nil;
	
	if([resultstr rangeOfString:@"OKOK"].length>0)
	{
		//SCRID:129 Add burn camera barcode by Helen 20110810
		NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"FCAMERA_SN:" Postfix:@";"];
		NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"RCAMERA_SN:" Postfix:@";"];
		//SCRID:129 end
		
		NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"BATTERY_SN:" Postfix:@";"];
		NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"GRP_SN:" Postfix:@";"];
		NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"DSPL_SN:" Postfix:@";"];//Kenshin 2011-05-23
		NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"MLB_SN:" Postfix:@";"];
		NSString* HWYSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"HWY_SN:" Postfix:@";"];
		NSString* X15SN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X15_SN:" Postfix:@";"];
		NSString* CustPartNo = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"CUST_PART_NO:" Postfix:@";"];
		//joko add 2010-09-13
		NSString* X23SN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X23_SN:" Postfix:@";"];
		NSString* X24SN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X24_SN:" Postfix:@";"];
		NSString* X25SN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X25_SN:" Postfix:@";"];
		// J1J2-SCRID:1 add by Evan on 2011-03-17
		NSString* X26SN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X26_SN:" Postfix:@";"];
		// J1J2-SCRID:1 add end;
		NSString* MlbRecord =[ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"MLBR:" Postfix:@";"];
		NSString* X23Record =[ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X23R:" Postfix:@";"];
		NSString* X24Record =[ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X24R:" Postfix:@";"];
		NSString* X25Record =[ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X25R:" Postfix:@";"];
		// J1J2-SCRID:1 add by Evan on 2011-03-17
		NSString* X26Record =[ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"X26R:" Postfix:@";"];
		// J1J2-SCRID:1 add end;
		NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:resultstr Prefix:@"SENSOR_SN:" Postfix:@";"];
		
		NSString* MPN = nil ;
		NSString* Regn = nil ;
		//NSString* t39MPN = @"" ;
		if (CustPartNo!=nil)
		{
			//add by caijunbo 20100726
			if ([ToolFun numberOfOccurrences:CustPartNo searchStr:@"*"]==2) //CUST_PART_NO:995-0576*K94*LL/A
			{
				/* SCRID-108: change mpn format */
				int fisrtStarIndex = [CustPartNo rangeOfString:@"*"].location;
				MPN = [CustPartNo substringToIndex:fisrtStarIndex];
				/* SCRID-108: end */
				
				NSRange rangeCustPartNo=[CustPartNo rangeOfString:@"*"];
				CustPartNo = [CustPartNo substringFromIndex:rangeCustPartNo.location +1];
			}
			//added end 20100726
			NSRange rangTmp = [CustPartNo rangeOfString:@"*"] ;
			if (rangTmp.length > 0) //exist *
			{
				//MPN = [CustPartNo substringToIndex:rangTmp.location] ;
				Regn = [CustPartNo substringFromIndex:rangTmp.location +1] ;
			}
			else
			{
				/* SCRID-108: change mpn format */
				if([CustPartNo rangeOfString:@"-"].length > 0)
				{
					if([CustPartNo length] > 8)
					{
						MPN = [CustPartNo substringToIndex:8];
						Regn = [CustPartNo substringFromIndex:8];
					}
				}
				else
				{
					if ([CustPartNo length]>5)
					{
						MPN = [CustPartNo substringToIndex:5];
						Regn = [CustPartNo substringFromIndex:5];
					}else
					{
						[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%@ \n CustPartNo length less than 5",resultstr]];
						return ;
					}
				}
				/* SCRID-108: end */
			};
		}
		
		NSString* HWConfigProperties = [ToolFun GetSubStrFrom:resultstr BetweenStr:@"HWCONFIG:" ANDSymbol:@";"];
		HWconfig = HWConfigProperties;
		NSString* X17SN = [ToolFun GetSubStrFrom:resultstr BetweenStr:@"U3_SN:" ANDSymbol:@";"];
		
		//SCRID:129 Add burn camera barcode by Helen 20110810
		if (mFCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
		if (mBCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
		//SCRID:129 end

		
		if (mBATSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
		
		if (GrapSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
		/*SCRID-103: Add Burn Display SN, Kenshin 2011-05-23*/
		if (DSPLSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
		/*SCRID-103:end*/
		
		if (MLBSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
		
		if (HWYSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWSN :HWYSN];
		
		if (X15SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX15SN :X15SN];
		
		if (CustPartNo!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYCUSTPARTNO :CustPartNo];
	
		if (HWConfigProperties!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfigProperties];
		
		if (X17SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX17SN :X17SN];

		if (MPN!=nil) /* SCRID-108: change mpn format */
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
		
		if (Regn!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
		 
		if (X23SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX23 :X23SN];
		
		if (X24SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX24 :X24SN];
		
		if (X25SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX25 :X25SN];
		
		// J1J2-SCRID:1 add by Evan on 2011-03-17
		if (X26SN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX26 :X26SN];
		// J1J2-SCRID:1 add end;
		
		if(MlbRecord!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBRECORD :MlbRecord];
		if(X23Record!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX23RECORD :X23Record];
		if(X24Record!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX24RECORD :X24Record];
		if(X25Record!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX25RECORD :X25Record];
		
		// J1J2-SCRID:1 add by Evan on 2011-03-17
		if(X26Record!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYX26RECORD :X26Record];
		// J1J2-SCRID:1 add end;
		
		if (SensorSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
		//joko add 2010-09-13 end
		
		enumResult = RESULT_FOR_PASS ;
		
	}
	//joko add 2010-09-08
	else  
	{
		if([resultstr rangeOfString: @"Not Found"].length > 0 || [resultstr rangeOfString: @"not found"].length > 0)
			resultstr = [resultstr stringByAppendingString:@", Due to SFC Error"];
	}    
	//joko add end 2010-09-08 
	
	if (resultstr!=nil)
	{
		strTestResultForUIinfo = [NSString stringWithString:resultstr] ;
        // ****************justin add for Incoming to check factory_checkin date ***2013-08-28  start ---->>>>>
        if ([mQueryString rangeOfString:@"factory_checkin"].length > 0)
        {
            //            NSDateFormatter *dateFormat = [[NSDateFormatter alloc]init];
            //            [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            //            int lengthOfDate = [@"yyyy-MM-dd HH:mm:ss" length];
            //            strTestResultForUIinfo = [strTestResultForUIinfo substringToIndex:lengthOfDate];
            //            NSDate *mCheckInData = [dateFormat dateFromString:strTestResultForUIinfo];
            //            if (mCheckInData!=nil)
            //            {
            //                strTestResultForUIinfo = [@"CheckInDate:" stringByAppendingString:strTestResultForUIinfo];
            enumResult = RESULT_FOR_PASS;
            //            }
            //            else
            //                strTestResultForUIinfo = [NSString stringWithFormat:@"CheckInDate:%@ is not a date type",strTestResultForUIinfo];
            //            [dateFormat release];
        }
		if (mBufferName!=nil)
		{
			resultstr = [resultstr stringByReplacingOccurrencesOfString:@";" withString:@"||"];
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :resultstr] ;
		}
	}
	else
		strTestResultForUIinfo = @"get Data is null from SFC" ;
	
	//joko add 2010-09-08
	if([HWconfig length] > 0) 
	{
		NSString *tmp = @"";
		/*
		if(bK93)
		{
			if([HWconfig rangeOfString: @"UMTS"].length > 0 || [HWconfig rangeOfString: @"CDMA2000"].length > 0)
			{
				tmp = @"K93 Unit, HWConfig should not contain 'UMTS' or 'CDMA2000'; ";
				tmp = [tmp stringByAppendingString:resultstr];
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :tmp] ;
				return;
			}
		}
		if(bK94)
		{
			if([HWconfig rangeOfString: @"CDMA2000"].length > 0 || [HWconfig rangeOfString: @"UMTS"].length <= 0)
			{
				tmp = @"K94 Unit, HWConfig should contain 'UMTS'; ";
				tmp = [tmp stringByAppendingString:resultstr];
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :tmp] ;
				return;
			}
		}
		if(bK95)
		{
			if([HWconfig rangeOfString: @"UMTS"].length > 0 || [HWconfig rangeOfString: @"CDMA2000"].length <= 0)
			{
				tmp = @"K95 Unit, HWConfig should contain 'CDMA2000'; ";
				tmp = [tmp stringByAppendingString:resultstr];
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :tmp] ;
				return;
			}
		}
		*/
		if(bJ1)
		{
			if([HWconfig rangeOfString: @"UMTS"].length > 0)
			{
				tmp = @"J1 Unit, HWConfig should not contain 'UMTS'; ";
				tmp = [tmp stringByAppendingString:resultstr];
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :tmp] ;
				return;
			}
		}
		
	}   
	//joko add end 2010-09-08
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	
	return;
}
// Bruce add 2015.1.13 start
+(void)QueryBobcatUseHTTP_MLBSN_Plant_code:(NSDictionary*)dictKeyDefined
{
    //Boolean siteIsLH = false;
    //Boolean firstTimeIsPass = false;
    //Boolean secondTimeIsPass = false;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	NSString *mQueryString_CD=@"";
    NSString *mQueryString_LH=@"";
    NSString *mWriteCmd3=@"";
    NSString *mWriteCmd2=@"";
    NSString *mWriteCmd=@"";
    NSString *mForceBurnUnitSN=@"";
    
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_CD"])
        {
			mQueryString_CD =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_LH"])
        {
			mQueryString_LH =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"WriteCmd3"])
		{
			mWriteCmd3 =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd3 = [mWriteCmd3 stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd2 = [mWriteCmd2 stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd = [mWriteCmd stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"ForceBurnUnitSN"])
		{
			mForceBurnUnitSN =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    //1.==============Read Unit SN from Unit==========
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,1"] ;
        return ;
    }
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = 3;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *unitSNReadFromUnit = [self ReceData:dictKeyDefined] ;
    
    if (unitSNReadFromUnit==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 1"] ;
        return ;
    }
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
    unitSNReadFromUnit = [ToolFun getStrFromPrefixAndPostfix:unitSNReadFromUnit Prefix:@"Serial:" Postfix:@":-)"];
    
    
    //2.==============Read MLB SN from Unit==========
    bTmp = [self SendData:dictKeyDefined :mWriteCmd2 :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,2"] ;
        return ;
    }
    NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
    int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
    while (timeInterval2<=iTmp)
    {
        timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *MLBSNReadFromUnit = [self ReceData:dictKeyDefined] ;
    
    if (MLBSNReadFromUnit==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 2"] ;
        return ;
    }
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
    MLBSNReadFromUnit = [ToolFun getStrFromPrefixAndPostfix:MLBSNReadFromUnit Prefix:@"syscfgprintMLB#" Postfix:@":-)"];
    
	if (MLBSNReadFromUnit==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no MLBSN"] ;
		return ;
	}
    
    
    //3.==============Read Unit SN from SFC==========
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *ghInfoSite = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE:" Postfix:@","];
    if([ghInfoSite rangeOfString:@"APPL"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Bobcat of Information In American(AppleSite) is dummy, cann't use it"] ;
        return;
    }
    
    ghInfoSite = [ToolFun deleteFromString:ghInfoSite trimStr:@"\n"];
    ghInfoSite = [ToolFun deleteFromString:ghInfoSite trimStr:@"\r"];
    
    
    /*
     if([ghInfoSite rangeOfString:@"FXLH"].length > 0 || [ghInfoSite rangeOfString:@"FXCD"].length > 0)
     {
     mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:@"http://172.16.241.131/fatprc6"];
     }
     else if ([ghInfoSite rangeOfString:@"FXBZ"].length > 0)
     {
     mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:@"http://172.19.240.73/fatpt39"];
     }
     else
     {
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;
     return;
     }
     */
    NSString *SFC_URL =@"";
    //    if([ghInfoSite rangeOfString:@"FXLH"].length > 0 || [ghInfoSite rangeOfString:@"FXCD"].length > 0)
    //    {
    //        // SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatprc6"];
    //        SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatprl"];
    //    }
    //    else if ([ghInfoSite rangeOfString:@"FXBZ"].length > 0)
    //    {
    //        SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatpt39"];
    //    }
    //    else
    //    {
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;
    //        return;
    //    }
    NSString* LH=@"DLX,DL9,DQX,DQY,DR2,DR3,DR4,DR5,DR6,DR7,DQT,DQW,DQV";
    NSString* CD=@"DN6,DMP,DMQ,DMR,DMT,DMV,DVG,DVH,DVJ,DVK,DVL,DVN,DVP,DVQ,DVR,DVT,DV9,DVC,DVD,DVF";
    NSString* CD_SVC=@"F6Q,F8Q,F6P";
    if (unitSNReadFromUnit==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"unitSN is nil 2!"] ;
        return ;
    }
    NSString* sNtemp=[unitSNReadFromUnit substringToIndex:3];
    if([LH rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.16.241.131/fatprl";
        NSLog(@"SFC_URL:%@",SFC_URL);
    }else if([CD rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.17.241.131/fatprl";
        NSLog(@"SFC_URL:%@",SFC_URL);
    }else if([CD_SVC rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.17.240.171/fatp/ipad/refurbqx";
        NSLog(@"SFC_URL:%@",SFC_URL);
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location "] ;
        return;
    }
    
    
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];
    
    
    
    //Blake change for query data with MLBSN 20131219
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:MLBSNReadFromUnit];
	//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
    NSLog(@"mQueryString:%@",mQueryString);
	
	NSURL* url = [NSURL URLWithString:mQueryString];
    
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=hwconfig"];
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=wo_no&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
	//NSURL* url = [NSURL URLWithString:@"http://10.146.67.61:8081/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mpn"];
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        [request setURL:url];
        [request setHTTPMethod:@"GET"];
        NSURLRequest* response;
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
        {
            break;
        }
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
        
    }
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
		/*
         NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"front_nvm_barcode=" Postfix:@"\n"];
         NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"back_nvm_barcode=" Postfix:@"\n"];
         NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"battery_sn=" Postfix:@"\n"];
         NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"grp_sn=" Postfix:@"\n"];
         NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"lcg_sn=" Postfix:@"\n"];
         NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mlbsn=" Postfix:@"\n"];
         NSString* HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@";"];
         NSString* MPN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mpn=" Postfix:@"\n"];
         NSString* Regn = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"region_code=" Postfix:@"\n"];
         NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"sensor_sn=" Postfix:@"\n"];
         NSString* mBarCode = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"unit_lbl=" Postfix:@"\n"];
         
         if(HWConfig==nil)
         {
         HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@"\n"];
         }
         
         if (mFCMS!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
         if (mBCMS!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
         if (mBATSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
         if (GrapSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
         if (DSPLSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
         if (MLBSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
         if (HWConfig!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfig];
         if (MPN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
         if (Regn!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
         if (SensorSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
         if (mBarCode != nil) {
         [TestItemManage setSFCValue:dictKeyDefined :@"strBarcodeSn" :mBarCode];
         }
         */
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
        
        NSString *UnitSNFromSFC = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"fgsn=" Postfix:@"\n"];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        BOOL sameUnitSN = false;
        if([UnitSNFromSFC isEqualToString:unitSNReadFromUnit])
            sameUnitSN = true;
        
        if((![mForceBurnUnitSN boolValue]) && sameUnitSN)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
            return;
        }
        else
        {
            //4.==============Burn Unit SN ==========
            mWriteCmd3 = [mWriteCmd3 stringByReplacingOccurrencesOfString:@"+" withString:UnitSNFromSFC];
            
            bool bTmp = [self SendData:dictKeyDefined :mWriteCmd3 :@":-)"] ;
            
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,3"] ;
                return ;
            }
            NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
            int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
            while (timeInterval3<=iTmp)
            {
                timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
            }
            //read data
            NSString *recData = [self ReceData:dictKeyDefined] ;
            
            if (recData==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 3"] ;
                return ;
            }
            else
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :recData] ;
            }
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :recData] ;
        }
	}
	else
	{
		NSString *uiInfo = mQueryString;
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}

// Bruce add 2015.1.13 end

+(void)QueryBobcatUseHTTP_MLBSN:(NSDictionary*)dictKeyDefined
{
    //Boolean siteIsLH = false;
    //Boolean firstTimeIsPass = false;
    //Boolean secondTimeIsPass = false;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	NSString *mQueryString_CD=@"";
    NSString *mQueryString_LH=@"";
    NSString *mWriteCmd3=@"";
    NSString *mWriteCmd2=@"";
    NSString *mWriteCmd=@"";
    NSString *mForceBurnUnitSN=@"";
    
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_CD"])
        {
			mQueryString_CD =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_LH"])
        {
			mQueryString_LH =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"WriteCmd3"])
		{
			mWriteCmd3 =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd3 = [mWriteCmd3 stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd2 = [mWriteCmd2 stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd =  [dictKeyDefined objectForKey:strKey];
            mWriteCmd = [mWriteCmd stringByAppendingString:@"\n"];
		}
        else if ([strKey isEqualToString:@"ForceBurnUnitSN"])
		{
			mForceBurnUnitSN =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    //1.==============Read Unit SN from Unit==========
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,1"] ;
        return ;
    }
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = 3;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined]) 
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *unitSNReadFromUnit = [self ReceData:dictKeyDefined] ;
    
    if (unitSNReadFromUnit==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 1"] ;
        return ;
    }
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    unitSNReadFromUnit = [unitSNReadFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
    unitSNReadFromUnit = [ToolFun getStrFromPrefixAndPostfix:unitSNReadFromUnit Prefix:@"Serial:" Postfix:@":-)"];
    
    
    //2.==============Read MLB SN from Unit==========
    bTmp = [self SendData:dictKeyDefined :mWriteCmd2 :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,2"] ;
        return ;
    }
    NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
    int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
    while (timeInterval2<=iTmp)
    {
        timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined]) 
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *MLBSNReadFromUnit = [self ReceData:dictKeyDefined] ;
    
    if (MLBSNReadFromUnit==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 2"] ;
        return ;
    }
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    MLBSNReadFromUnit = [MLBSNReadFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
    MLBSNReadFromUnit = [ToolFun getStrFromPrefixAndPostfix:MLBSNReadFromUnit Prefix:@"syscfgprintMLB#" Postfix:@":-)"];
    
	if (MLBSNReadFromUnit==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no MLBSN"] ;
		return ;
	}
    
    
    //3.==============Read Unit SN from SFC==========
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *ghInfoSite = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE:" Postfix:@","];
    if([ghInfoSite rangeOfString:@"APPL"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Bobcat of Information In American(AppleSite) is dummy, cann't use it"] ;
        return;
    }
    
    ghInfoSite = [ToolFun deleteFromString:ghInfoSite trimStr:@"\n"];
    ghInfoSite = [ToolFun deleteFromString:ghInfoSite trimStr:@"\r"];
    
    
    /*
     if([ghInfoSite rangeOfString:@"FXLH"].length > 0 || [ghInfoSite rangeOfString:@"FXCD"].length > 0)
     {
     mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:@"http://172.16.241.131/fatprc6"];
     }
     else if ([ghInfoSite rangeOfString:@"FXBZ"].length > 0)
     {
     mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:@"http://172.19.240.73/fatpt39"];
     }
     else
     {
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;
     return;
     }
     */
    NSString *SFC_URL = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SFC_URL:" Postfix:@","];
    if([ghInfoSite rangeOfString:@"FXLH"].length > 0 || [ghInfoSite rangeOfString:@"FXCD"].length > 0)
    {
       // SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatprc6"];
        SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatprl"];
    }
    else if ([ghInfoSite rangeOfString:@"FXBZ"].length > 0)
    {
        SFC_URL = [SFC_URL stringByReplacingOccurrencesOfString:@"aa" withString:@"fatpt39"];
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location LH/CD"] ;
        return;
    }
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];
    
    
    
    //Blake change for query data with MLBSN 20131219
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:MLBSNReadFromUnit];
	//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
	
	NSURL* url = [NSURL URLWithString:mQueryString];
    
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=hwconfig"];
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=wo_no&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
	//NSURL* url = [NSURL URLWithString:@"http://10.146.67.61:8081/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mpn"];
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        [request setURL:url];
        [request setHTTPMethod:@"GET"];
        NSURLRequest* response;
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
        {
            break;
        }
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
        
    }
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
		/*
         NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"front_nvm_barcode=" Postfix:@"\n"];
         NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"back_nvm_barcode=" Postfix:@"\n"];
         NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"battery_sn=" Postfix:@"\n"];
         NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"grp_sn=" Postfix:@"\n"];
         NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"lcg_sn=" Postfix:@"\n"];
         NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mlbsn=" Postfix:@"\n"];
         NSString* HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@";"];
         NSString* MPN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mpn=" Postfix:@"\n"];
         NSString* Regn = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"region_code=" Postfix:@"\n"];
         NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"sensor_sn=" Postfix:@"\n"];
         NSString* mBarCode = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"unit_lbl=" Postfix:@"\n"];
         
         if(HWConfig==nil)
         {
         HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@"\n"];
         }
         
         if (mFCMS!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
         if (mBCMS!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
         if (mBATSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
         if (GrapSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
         if (DSPLSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
         if (MLBSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
         if (HWConfig!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfig];
         if (MPN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
         if (Regn!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
         if (SensorSN!=nil)
         [TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
         if (mBarCode != nil) {
         [TestItemManage setSFCValue:dictKeyDefined :@"strBarcodeSn" :mBarCode];
         }
         */
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
        
        NSString *UnitSNFromSFC = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"fgsn=" Postfix:@"\n"];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        UnitSNFromSFC = [UnitSNFromSFC stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        BOOL sameUnitSN = false;
        if([UnitSNFromSFC isEqualToString:unitSNReadFromUnit])
            sameUnitSN = true;
        
        if((![mForceBurnUnitSN boolValue]) && sameUnitSN)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish"] ;
            return;
        }
        else
        {
            //4.==============Burn Unit SN ==========
            mWriteCmd3 = [mWriteCmd3 stringByReplacingOccurrencesOfString:@"+" withString:UnitSNFromSFC];
            
            bool bTmp = [self SendData:dictKeyDefined :mWriteCmd3 :@":-)"] ;
            
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail,3"] ;
                return ;
            }
            NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
            int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
            while (timeInterval3<=iTmp)
            {
                timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
            }
            //read data
            NSString *recData = [self ReceData:dictKeyDefined] ;
            
            if (recData==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data! 3"] ;
                return ;
            }
            else
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :recData] ;
            }
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :recData] ;
        }
	}
	else
	{
		NSString *uiInfo = mQueryString;
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}

//JianSheng add 2012-06-29
+(void)QueryBobcatUseHTTP:(NSDictionary*)dictKeyDefined 
{	
    //Boolean siteIsLH = false;
    //Boolean firstTimeIsPass = false;
    //Boolean secondTimeIsPass = false;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	NSString *mQueryString_CD=@"";
    NSString *mQueryString_LH=@"";
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_CD"])
        {
			mQueryString_CD =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_LH"])
        {
			mQueryString_LH =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :@""];
    
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	//NSString* sN = @"DLXHT00ZF53K";
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		return ;
	}	
    
	
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *ghInfoSite = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE:" Postfix:@","];
    if([ghInfoSite rangeOfString:@"APPL"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The Bobcat of Information In American(AppleSite) is dummy, cann't use it"] ;
        return;
    }
    
    NSString *SFC_URL = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SFC_URL:" Postfix:@","];
    NSString *station_id = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"STATION_ID:" Postfix:@","];
    station_id = [station_id uppercaseString];
    if(SFC_URL == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor SFC_URL fail"] ;
        return;
    }
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];

	if([[ScriptParse getStationID] isEqualToString :@"SA-Grape"]||[[ScriptParse getStationID] isEqualToString :@"HomeButton"]||[[ScriptParse getStationID] isEqualToString :@"SUB FOS"])
    {
		//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"aa" withString:@"fatpsub"];
        mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"fatprc6" withString:@"fatpsub"];//Modified by annie on 2013.07.03
        mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"fatprl" withString:@"fatpsub"];
    }

	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:sN];
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[STATION_ID]" withString:station_id];
	//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
	
	NSURL* url = [NSURL URLWithString:mQueryString];
    
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=hwconfig"];
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=wo_no&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
	//NSURL* url = [NSURL URLWithString:@"http://10.146.67.61:8081/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mpn"];
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {   
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        [request setURL:url];        
        [request setHTTPMethod:@"GET"];        
        NSURLRequest* response;        
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];        
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];        
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
        {
            break;
        }
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
        
    }
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
		
		NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"front_nvm_barcode=" Postfix:@"\n"];
		NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"back_nvm_barcode=" Postfix:@"\n"];
		NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"battery_sn=" Postfix:@"\n"];
		NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"grp_sn=" Postfix:@"\n"];
		NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"lcg_sn=" Postfix:@"\n"];
		NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mlbsn=" Postfix:@"\n"];
		NSString* HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@";"];
		NSString* MPN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mpn=" Postfix:@"\n"];
		NSString* Regn = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"region_code=" Postfix:@"\n"];
		NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"sensor_sn=" Postfix:@"\n"];
        NSString* mBarCode = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"unit_lbl=" Postfix:@"\n"];
		
		if(HWConfig==nil)
        {
            HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@"\n"];
        }
        
		if (mFCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
		if (mBCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
		if (mBATSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
		if (GrapSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
		if (DSPLSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
		if (MLBSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
		if (HWConfig!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfig];
		if (MPN!=nil) 
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
		if (Regn!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
		if (SensorSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
        if (mBarCode != nil) {
            [TestItemManage setSFCValue:dictKeyDefined :@"strBarcodeSn" :mBarCode];
        }
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
	}
	else
	{
		NSString *uiInfo = mQueryString;
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}
//Bruce add 2015-1-13start
+(void)QueryBobcatUseHTTPRefurbgdPlantCode:(NSDictionary*)dictKeyDefined
{
    //Boolean siteIsLH = false;
    Boolean firstTimeIsPass = false;
    Boolean secondTimeIsPass = false;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	NSString *mQueryString_CD=@"";
    NSString *mQueryString_LH=@"";
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_CD"])
        {
			mQueryString_CD =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_LH"])
        {
			mQueryString_LH =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :@""];
    
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	//NSString* sN = @"DLXHT00ZF53K";
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
    //  sN=@"F6QNL2HLG5YN";
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		return ;
	}
    
	
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *ghInfoSite = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE:" Postfix:@","];
    NSString *SFC_URL = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SFC_URL:" Postfix:@","];
    //   NSString *SFC_URL=@"http://172.17.240.171/fatp/ipad/refurbqx";
    if(SFC_URL == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor SFC_URL fail"] ;
        return;
    }
    
    NSString* LH=@"DLX,DL9,DQX,DQY,DR2,DR3,DR4,DR5,DR6,DR7,DQT,DQW,DQV";
    NSString* CD=@"DN6,DMP,DMQ,DMR,DMT,DMV,DVG,DVH,DVJ,DVK,DVL,DVN,DVP,DVQ,DVR,DVT,DV9,DVC,DVD,DVF";
    NSString* CD_SVC=@"F6Q,F8Q,F6P";
    if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sN"] ;
		return ;
	}
    NSString* sNtemp=[sN substringToIndex:3];
    if (sNtemp==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sNtemp"] ;
		return ;
	}
    
    if([LH rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.16.241.131/aa";
    }else if([CD rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.17.241.131/aa";
    }else if([CD_SVC rangeOfString:sNtemp].length>0)
    {
        SFC_URL=@"http://172.17.240.171/fatp/ipad/refurbqx";
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can't Judge Location "] ;
        return;
    }
    
    
    
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:sN];
	//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
	
	NSURL* url = [NSURL URLWithString:mQueryString];
    
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=hwconfig"];
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=wo_no&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
	//NSURL* url = [NSURL URLWithString:@"http://10.146.67.61:8081/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mpn"];
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        [request setURL:url];
        [request setHTTPMethod:@"GET"];
        NSURLRequest* response;
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
        {
            firstTimeIsPass = true;
            break;
        }
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
        
    }
    
    if([SFC_URL rangeOfString:@"refurb"].length > 0 && (!firstTimeIsPass))
    {
        
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
        
        mQueryString_LH = [mQueryString_LH stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
		if(mQueryString_LH != nil)
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:SFC_URL withString:mQueryString_LH];
        url = [NSURL URLWithString:mQueryString];
        
        for(int i=0; i<10; i++)
        {
            NSMutableURLRequest* request = [NSMutableURLRequest new];
            [request setURL:url];
            [request setHTTPMethod:@"GET"];
            NSURLRequest* response;
            NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
            strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
            if (mBufferName!=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
            }
            if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
            {
                secondTimeIsPass = true;
                break;
            }
            
            if(i < 6)
                sleep(1);
            else if (i >= 6 && i < 8)
                sleep(2);
            else
                sleep(4);
        }
    }
    if([SFC_URL rangeOfString:@"refurb"].length > 0 && (!secondTimeIsPass) && (!firstTimeIsPass))
    {
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
        
        mQueryString_CD = [mQueryString_CD stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
		if(mQueryString_CD != nil)
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:SFC_URL withString:mQueryString_CD];
        url = [NSURL URLWithString:mQueryString];
        
        for(int i=0; i<10; i++)
        {
            NSMutableURLRequest* request = [NSMutableURLRequest new];
            [request setURL:url];
            [request setHTTPMethod:@"GET"];
            NSURLRequest* response;
            NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
            strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
            if (mBufferName!=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
            }
            if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
            {
                break;
            }
            
            if(i < 6)
                sleep(1);
            else if (i >= 6 && i < 8)
                sleep(2);
            else
                sleep(4);
        }
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"connect fail！！！"] ;
        
    }
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
		
		NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"front_nvm_barcode=" Postfix:@"\n"];
		NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"back_nvm_barcode=" Postfix:@"\n"];
		NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"battery_sn=" Postfix:@"\n"];
		NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"grp_sn=" Postfix:@"\n"];
		NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"lcg_sn=" Postfix:@"\n"];
		NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mlbsn=" Postfix:@"\n"];
		NSString* HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@";"];
		NSString* MPN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mpn=" Postfix:@"\n"];
		NSString* Regn = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"region_code=" Postfix:@"\n"];
		NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"sensor_sn=" Postfix:@"\n"];
		
		
        if(HWConfig==nil)
        {
            HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@"\n"];
        }
        
		if (mFCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
		if (mBCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
		if (mBATSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
		if (GrapSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
		if (DSPLSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
		if (MLBSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
		if (HWConfig!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfig];
		if (MPN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
		if (Regn!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
		if (SensorSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
	}
	else
	{
		NSString *uiInfo = mQueryString;
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}
//Bruce add 2015-1-13end

//JianSheng add 2012-06-29
+(void)QueryBobcatUseHTTPRefurbgd:(NSDictionary*)dictKeyDefined 
{	
    //Boolean siteIsLH = false;
    Boolean firstTimeIsPass = false;
    Boolean secondTimeIsPass = false;
	NSString *mQueryString=@"";
	NSString *mBufferName=@"";
	NSString *mQueryString_CD=@"";
    NSString *mQueryString_LH=@"";
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"QueryString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_CD"])
        {
			mQueryString_CD =  [dictKeyDefined objectForKey:strKey];
		}
        if ([strKey isEqualToString:@"QueryString_LH"])
        {
			mQueryString_LH =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
	}
    
    [TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :@""];
	[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :@""];
    
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	//NSString* sN = @"DLXHT00ZF53K";
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		return ;
	}	
    
	
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *ghInfoSite = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SITE:" Postfix:@","];
    NSString *SFC_URL = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SFC_URL:" Postfix:@","];
    if(SFC_URL == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor SFC_URL fail"] ;
        return;
    }
    mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:sN];
	//mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
	
	NSURL* url = [NSURL URLWithString:mQueryString];
    
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=hwconfig"];
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mlbsn&p=wo_no&p=mpn&p=region_code&p=battery_sn&p=hwconfig&p=front_nvm_barcode&p=back_nvm_barcode&p=grp_sn&p=lcg_sn"];
	//NSURL* url = [NSURL URLWithString:@"http://10.146.67.61:8081/fatpgd9?sn=DLXHT00ZF53K&c=QUERY_RECORD&p=mpn"];
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {   
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        [request setURL:url];        
        [request setHTTPMethod:@"GET"];        
        NSURLRequest* response;        
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];        
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];        
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
        {
            firstTimeIsPass = true;
            break;
        }
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
        
    }
    
    if([SFC_URL rangeOfString:@"refurb"].length > 0 && (!firstTimeIsPass))
    {   
        
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
        
        mQueryString_LH = [mQueryString_LH stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
		if(mQueryString_LH != nil)
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:SFC_URL withString:mQueryString_LH];
        url = [NSURL URLWithString:mQueryString];
        
        for(int i=0; i<10; i++)
        {   
            NSMutableURLRequest* request = [NSMutableURLRequest new];
            [request setURL:url];        
            [request setHTTPMethod:@"GET"];        
            NSURLRequest* response;        
            NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];        
            strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];        
            if (mBufferName!=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
            }
            if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
            {
                secondTimeIsPass = true;
                break;
            }
            
            if(i < 6)
                sleep(1);
            else if (i >= 6 && i < 8)
                sleep(2);
            else
                sleep(4);
        }
    }
    if([SFC_URL rangeOfString:@"refurb"].length > 0 && (!secondTimeIsPass) && (!firstTimeIsPass))
    {   
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
        
        mQueryString_CD = [mQueryString_CD stringByReplacingOccurrencesOfString:@"|" withString:@"/"];
		if(mQueryString_CD != nil)
			mQueryString = [mQueryString stringByReplacingOccurrencesOfString:SFC_URL withString:mQueryString_CD];
        url = [NSURL URLWithString:mQueryString];
        
        for(int i=0; i<10; i++)
        {   
            NSMutableURLRequest* request = [NSMutableURLRequest new];
            [request setURL:url];        
            [request setHTTPMethod:@"GET"];        
            NSURLRequest* response;        
            NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];        
            strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];        
            if (mBufferName!=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
            }
            if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
            {
                break;
            }
            
            if(i < 6)
                sleep(1);
            else if (i >= 6 && i < 8)
                sleep(2);
            else
                sleep(4);
        }
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"connect fail！！！"] ;
        
    }
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
		
		NSString *mFCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"front_nvm_barcode=" Postfix:@"\n"];
		NSString *mBCMS = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"back_nvm_barcode=" Postfix:@"\n"];
		NSString *mBATSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"battery_sn=" Postfix:@"\n"];
		NSString *GrapSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"grp_sn=" Postfix:@"\n"];
		NSString *DSPLSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"lcg_sn=" Postfix:@"\n"];
		NSString* MLBSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mlbsn=" Postfix:@"\n"];
		NSString* HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@";"];
		NSString* MPN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"mpn=" Postfix:@"\n"];
		NSString* Regn = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"region_code=" Postfix:@"\n"];
		NSString* SensorSN = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"sensor_sn=" Postfix:@"\n"];
		
		
        if(HWConfig==nil)
        {
            HWConfig = [ToolFun getStrFromPrefixAndPostfix:strReturn Prefix:@"hwconfig=" Postfix:@"\n"];
        }
        
		if (mFCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRFCMS :mFCMS];
		if (mBCMS!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRBCMS :mBCMS];
		if (mBATSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYBATTERYSN :mBATSN];
		if (GrapSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYGRAPESN :GrapSN];
		if (DSPLSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYDSPLSN :DSPLSN];
		if (MLBSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMLBSN :MLBSN];
		if (HWConfig!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYHWCOIG :HWConfig];
		if (MPN!=nil) 
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYMPN :MPN];
		if (Regn!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYREGN :Regn];
		if (SensorSN!=nil)
			[TestItemManage setSFCValue:dictKeyDefined :STRKEYSENSORSN :SensorSN];
        NSString *uiInfo = mQueryString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
	}
	else
	{
		NSString *uiInfo = mQueryString;
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}+(void)InsertBobcatUseHTTP:(NSDictionary*)dictKeyDefined 
{	
	NSString *mInsertString=@"";
	NSString *mBufferName=@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"InsertString"])
		{
			mInsertString =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName =  [dictKeyDefined objectForKey:strKey];
		}
	}
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	//sN = @"DLXHT00ZF53K";
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		return ;
	}	
    
	
    NSString* file = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
    if(!file)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
    file = [file stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@" " withString:@""];
    file = [file stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *SFC_URL = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"SFC_URL:" Postfix:@","];
    if(SFC_URL == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor SFC_URL fail"] ;
        return;
    }
    NSString *PRODUCT = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"PRODUCT:" Postfix:@","];
    if(PRODUCT == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor PRODUCT fail"] ;
        return;
    }
    NSString *STATION_NAME = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"STATION_TYPE:" Postfix:@","];
    if(STATION_NAME == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor STATION_NAME/TYPE fail"] ;
        return;
    }
    NSString *STATION_ID = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"STATION_ID:" Postfix:@","];
    if(STATION_ID == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor STATION_ID fail"] ;
        return;
    }
    NSString *MAC_ADDRESS = [ToolFun getStrFromPrefixAndPostfix:file Prefix:@"MAC:" Postfix:@","];
    if(MAC_ADDRESS == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor MAC_ADDRESS fail"] ;
        return;
    }
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@" " withString:@""];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Unit_SN]" withString:sN];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[SFC_URL]" withString:SFC_URL];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Product]" withString:PRODUCT];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Test_Station_Name]" withString:STATION_NAME];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Station_ID]" withString:STATION_ID];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[MAC_Address]" withString:MAC_ADDRESS];
    
    if([TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
	{
        mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Test_Result]" withString:@"PASS"];
		mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"&list_of_failing_tests=[Fail_Item_List]" withString:@""];
		mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"&failure_message=[Fail_Message]" withString:@""];
	}
    else
	{
        mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Test_Result]" withString:@"FAIL"];
		
		NSString *strDUTID,*strTestItemIndex ;
		strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
		strTestItemIndex = [dictKeyDefined objectForKey:@"TestItemIndex"] ;
		
		if (strDUTID==nil || strTestItemIndex==nil || mutArrayTestItemList==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test engineer fail 1"] ;
			return;
		}
		if ([strTestItemIndex intValue] >= [mutArrayTestItemList count])
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test item count unexception"] ;
			return;
		}
		
		NSString *firstFailTestItemName = @"";
		int iPriorTestIndex = [strTestItemIndex intValue] -1 ;
		for(int i=0 ;i<=iPriorTestIndex ;i++)
		{
			NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:i] ;
			if (mutdictTmp==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test engineer fail 2"] ;
				return;
			}
			NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestItemResult"] ;
			if (mutdictTmp1==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test engineer fail 3"] ;
				return;
			}
			NSNumber *numberTmp = [mutdictTmp1 objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]];
			if (numberTmp==nil)
			{
				//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test engineer fail 4"] ;
				break;
			}
			switch ([numberTmp intValue]) 
			{
				case RESULT_FOR_PASS:
				case RESULT_FOR_BYPASS :
					;
				case RESULT_FOR_FAIL :
				case RESULT_FOR_OTHER :
				{
					firstFailTestItemName = [[mutArrayTestItemList objectAtIndex:i] objectForKey: @"TestItemName"];
                    break;
				}
				default:
					;
			}
		}
		mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Fail_Item_List]" withString:firstFailTestItemName];
		mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Fail_Message]" withString:@"Test FAIL"];
	}
	
    NSString*currentDate		= [NSDate date];
	NSString*strCurrentTime	= [currentDate description];
	strCurrentTime	= [strCurrentTime substringToIndex:(NSUInteger)19];
	//strCurrentTime = [strCurrentTime stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    //strCurrentTime = [strCurrentTime stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Start_Time]" withString:strCurrentTime];
    mInsertString = [mInsertString stringByReplacingOccurrencesOfString:@"[Stop_Time]" withString:strCurrentTime];
	
	mInsertString = [mInsertString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	NSURL* url = [NSURL URLWithString:mInsertString];
	
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?result=FAIL&c=ADD_RECORD&sn=DLXHT00ZF53K&product=P105&test_station_name=SA-PAT&station_id=FXLH_E03-4FT-01A_2_SA-PAT&mac_address=d4:9a:20:f3:f4:4c&start_time=2012-07-04%2014:33:40&stop_time=2012-07-04%2014:33:44"];
    
	//NSURL* url = [NSURL URLWithString:@"http://172.16.241.131/fatpgd9?result=PASS&c=ADD_RECORD&sn=DLXHT00ZF53K&product=P105&test_station_name=QT0&station_id=FXLH_E03-4FT-01A_2_QT0&mac_address=00:f4:34:45:a1&start_time=2012-07-03%2015:06:06&stop_time=2012-07-03%2015:06:12"];
	
	
    NSString* strReturn = @"";
    for(int i=0; i<10; i++)
    {
        NSMutableURLRequest* request = [NSMutableURLRequest new];
        
        [request setURL:url];
        
        [request setHTTPMethod:@"GET"];
        
        NSURLRequest* response;
        
        NSData* data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
        
        strReturn = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
        
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strReturn] ;
        }
        if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
            break;
        
        if(i < 6)
            sleep(1);
        else if (i >= 6 && i < 8)
            sleep(2);
        else
            sleep(4);
    }
	
	NSLog(@"##### %@",strReturn);
	
	
	if([strReturn rangeOfString:@"0 SFC_OK"].length>0)
	{
        NSString *uiInfo = mInsertString;
		uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
        uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;
	}
	else
	{
		NSString *uiInfo = @"Fail, ";
        uiInfo = [uiInfo stringByAppendingString:mInsertString];
        uiInfo = [uiInfo stringByAppendingString:@"\n\n"];
		uiInfo = [uiInfo stringByAppendingString:strReturn];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
	}
    
}
//added by Paul 20160112 for CT2
+(void)ParseVinylSmokeyTest:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferName2=nil;
    NSString *mReferenceBufferName3=nil;
    NSString *mBuffferName=nil;
    for(int i=0;i<[dictKeyDefined count];i++)
    {
        NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
        if([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"ReferenceBufferName3"])
        {
            mReferenceBufferName3=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"BufferName"])
        {
            mBuffferName=[dictKeyDefined objectForKey:strKey];
        }
    
    }
    if(mReferenceBufferName==nil&&mReferenceBufferName2==nil&&mReferenceBufferName3==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    NSString *mReferenceBufferValue,*mReferenceBufferValue2,*mReferenceBufferValue3;
    mReferenceBufferValue =[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    mReferenceBufferValue2=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"BoardID return nil"];
        return;
    }
    if ((mReferenceBufferValue2==nil || ([mReferenceBufferValue2 rangeOfString:@"region_code= "].length>0) ))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"SFC return nil"];
        return;
    }
    if (([mReferenceBufferValue rangeOfString:@"0x08"].length>0)||([mReferenceBufferValue2 rangeOfString:@"region_code=CH/A"].length>0))
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :@"NoNeedVinylSmokey"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"J127 or China config, no need test"] ;
        return;
    }
    mReferenceBufferValue3=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3] ;
    //NSLog(@"mReferenceBufferValue3=%@",mReferenceBufferValue3);
    if (mReferenceBufferValue3==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Sim card dectect fail"];
        return;
    }
    if (([mReferenceBufferValue rangeOfString:@"0x0A"].length>0)&& ([mReferenceBufferValue3 rangeOfString:@"No"].length>0))
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :@"DonotInsertSim"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Pass"] ;
        return;
    }else if(([mReferenceBufferValue rangeOfString:@"0x0A"].length>0)&& ([mReferenceBufferValue3 rangeOfString:@"Yes"].length>0))
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :@"NeedInsertSim"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Pass"] ;
        return;
    }
    [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :@"NoValue"] ;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_FAIL :@"Fail"] ;
    
    


}
//ended by Paul 20160112 for CT2
//JianSheng add end

+(void)ParseStrWithNumber:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mReferenceBufferName2=nil;//Added by Julian for QL Proto1 dryrun
	NSString *mReferenceBufferNameVendor=nil;//Added by Julian for RL P0 20140111
    NSString *mReferenceBufferNameVendorValue=nil;//add by kevin 20140123
    NSString *mFunction=nil;//Added by Julian for QL Proto1 dryrun
    NSString *mTimes=nil;//Added by Julian for QL Proto1 dryrun
	NSString *mBuffferName=nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	NSString *mResultType=nil;
	NSString *mNumberType=nil;
	NSString *mRecord=nil;
    NSString *mWriteToLocalfile=nil;
    NSString *mFirstValue = nil;
    NSString *mLastValue = nil;
    NSString *mVendorName=nil;// added by justin for RL P0 20140111
    NSString *mQuantityOfBattery= nil;
    
    BOOL isNeedWriteToLocalfile = NO;
    BOOL isFirstValue = NO;
    BOOL isLastValue = NO;
	//NSString *mIsFront=@"no";
    
    
    NSString *mDivision=nil;
	
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName2"])//Added by Julian for QL Proto1 dryrun
		{
			mReferenceBufferName2=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])//Added by Julian for RL Proto0 20140111
		{
			mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
            //add by kevin 20140123
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ResultType"])
		{
			mResultType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Record"])
		{
			mRecord=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"VendorName"])
		{
			mVendorName=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"WriteToLocalfile"])
        {
            mWriteToLocalfile=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"FirstValue"])
        {
            mFirstValue=[dictKeyDefined objectForKey:strKey];
        }
        else if([strKey isEqualToString:@"LastValue"])
        {
            mLastValue=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"Function"])
		{
			mFunction=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Times"])
		{
			mTimes=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"Division"])
		{
			mDivision=[dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"QuantityOfBattery"])
        {
            mQuantityOfBattery = [dictKeyDefined objectForKey:strKey];
        }
	}
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        //mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
    if(mReferenceBufferName==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    //add by kevin start  20140123
    //For gyro and accel offset test
    if([mTestItemName rangeOfString:@"ffset"].length>0 || [mTestItemName rangeOfString:@"_Average_"].length>0 || [mTestItemName rangeOfString:@"_Compass_"].length>0 || [mTestItemName rangeOfString:@"_Gyro_"].length>0){
        if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<=0){
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_PASS :@"Not for this vendor, bypass"] ;
			return;
            
        }
    }
    
    if ([mWriteToLocalfile isEqualToString:@"yes"]) {
        isNeedWriteToLocalfile = YES;
    }
    if ([mFirstValue isEqualToString:@"yes"]) {
        isFirstValue = YES;
    }
    if ([mLastValue isEqualToString:@"yes"]) {
        isLastValue = YES;
    }
    NSString * strUnitSN  = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
    
    NSString *mReferenceBufferValue;
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //add by lorne for sl gatekeeper station on 20160305
    if ([mReferenceBufferName isEqualToString:@"CheckBatteryLevelBeforeTest"]) {
        mReferenceBufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
                                                             Prefix:mPrefix
                                                            Postfix:mPostfix] ;
        if ([mReferenceBufferValue doubleValue] >= [mQuantityOfBattery  doubleValue]) {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"%@ Value",mTestItemName]:nil:[NSString stringWithFormat:@"%d",[mLowerValue intValue]]:[NSString stringWithFormat:@"%d",[mUpperValue intValue]]:[NSString stringWithFormat:@"%@",mReferenceBufferValue]:nil:IP_PASS:@"PASS"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:mReferenceBufferValue];
            return;
        }else{
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"%@ Value",mTestItemName]:nil:[NSString stringWithFormat:@"%d",[mLowerValue intValue]]:[NSString stringWithFormat:@"%d",[mUpperValue intValue]]:[NSString stringWithFormat:@"%@",mReferenceBufferValue]:nil:IP_PASS:@"PASS"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"Charge UUT..."];
            //stop test by LongGe.
            NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];
            [TestItemManage StopTest:[strDUTID intValue]];
            return;
        }
        
    }
    //debug
    //mReferenceBufferValue=@"+00.51@";
    //debug
    
    
    /*added by Rick for the NA value 2012-09-19*/
    if([mUpperValue isEqualTo:@"NA"])
    {
        mUpperValue = nil;
    }
    if([mLowerValue isEqualTo:@"NA"])
    {
        mLowerValue = nil;
    }
    
    /*added by Rick for the NA value end 2012-09-19*/
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    if ([mReferenceBufferValue rangeOfString:@"Not been triggered, bypass this item"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not been triggered, bypass this item"] ;
        return ;
    }
    NSRange postRange = [mPostfix rangeOfString:@"||"];
    if(postRange.length > 0)
        mPostfix = [mPostfix stringByReplacingOccurrencesOfString:@"||" withString:@";"];
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
                                                     Prefix:mPrefix
                                                    Postfix:mPostfix] ;
    //strFind=@"1";
    if (strFind==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
        return  ;
    }
    char* stopEnd;
	if([mNumberType isEqualToString:@"Hex"]||[mResultType isEqualToString:@"Hex"] || [mNumberType isEqualToString:@"hex"]||[mResultType isEqualToString:@"hex"])
	{
		int resultValue = (int)strtol([strFind UTF8String], &stopEnd, 16);//Kingking
        
		//if(resultValue >=[mLowerValue intValue] && resultValue<=[mUpperValue intValue])
		if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue intValue]))
           && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue intValue])))
		/*SCRID-3:Modify end*/
		{
			enumResult =RESULT_FOR_PASS ;
		}
        else
		{
			enumResult =RESULT_FOR_FAIL ;
		}
        
		if (mBuffferName!=nil)  //add by giga
			[TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%d",resultValue]] ;
		
        strTestResultForUIinfo = [NSString stringWithFormat:@"%d",resultValue] ;
        
        
	}
	//Ray modified for QL 2012-11-25
	else if ([mNumberType isEqualToString:@"Bin"] || [mResultType isEqualToString:@"Bin"] || [mNumberType isEqualToString:@"bin"] || [mResultType isEqualToString:@"bin"])
	{
        int resultValue=-1;
        
        resultValue = (int)strtol([strFind UTF8String], &stopEnd, 2);
        
        if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue intValue]))
           && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue intValue])))
            enumResult =RESULT_FOR_PASS ;
        else
            enumResult =RESULT_FOR_FAIL ;
        
        strTestResultForUIinfo = [NSString stringWithFormat:@"%d",resultValue] ;
	}
	//End
	
	else if ([mNumberType isEqualToString:@"int"] || [mResultType isEqualToString:@"int"] || [mNumberType isEqualToString:@"Int"] || [mResultType isEqualToString:@"Int"])
    {
		/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
		NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
		if (stationName==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_FAIL :@"Station name is not set in Appconfig"] ;
			return;
		}
		//add by judith for prefix control status: 2012-06-05
		[strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
		NSRange range;
		range = [strFind rangeOfString:@"0x" options:NSBackwardsSearch];
		if(range.length > 0)
			strFind = [strFind substringFromIndex:range.location+range.length+4];
        //add end 2012-06-05
        //Added by Julian for QL Proto1
        int resultValue=0;
        if (mReferenceBufferName2!=nil)
        {
            NSString *mReferenceBufferValue2= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
            if (mReferenceBufferValue2==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
                return ;
            }
            
            if ([mFunction isEqualToString:@"minus"])
            {
                resultValue = [mReferenceBufferValue intValue]-[mReferenceBufferValue2 intValue];
            }
            
        }
        
        else
        {
            resultValue =[strFind intValue];
        }
		if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue doubleValue]))
		   && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
		{
			enumResult =RESULT_FOR_PASS ;
			
		}else
		{
			enumResult =RESULT_FOR_FAIL ;
			
		}
		if (mBuffferName!=nil)  //add by giga
			[TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%d",resultValue]] ;
        
		strTestResultForUIinfo = [NSString stringWithFormat:@"%d",resultValue] ;
    }
    else
	{
		/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
		NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
		if (stationName==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_FAIL :@"Station name is not set in Appconfig"] ;
			return;
		}
        //Added by Julian for PS PVT
        double resultValue=0;
        
        if (mReferenceBufferName2!=nil)
        {
            NSString *mReferenceBufferValue2= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
            if (mReferenceBufferValue2==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
                return ;
            }
            
            
            if ([mFunction isEqualToString:@"minus"])
            {
                resultValue = [mReferenceBufferValue doubleValue]-[mReferenceBufferValue2 doubleValue];
            }
            // Added by Justin for Dryun 2014-10-17
            else if ([mFunction isEqualToString:@"division"])
            {
                resultValue = [mReferenceBufferValue doubleValue] / [mReferenceBufferValue2 doubleValue] * 1000;
            }
            // end
        }
        //end
        else
        {
            resultValue =[strFind doubleValue];
        }
        if([mFunction isEqualToString:@"Log"])//Added for Pole star by Julian
        {
            resultValue = log10(resultValue);
        }
        if(mTimes!=nil)
        {
            resultValue = resultValue * [mTimes doubleValue];
        }
        if (mDivision != nil) {
            resultValue = resultValue / [mDivision doubleValue];
        }
        
        //20160305 QT0a peter
        if ([stationName isEqualToString:@"QT0"])
        {
            if([mTestItemName rangeOfString:@"Orion Gnd Check"].length>0)
            {
                NSString *mUpperValue=@"4400";
                NSString *mLowerValue=@"2900";
                
                if((resultValue<=[mUpperValue doubleValue]) &&(resultValue>=[mLowerValue doubleValue]))
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
                    return;
                }
                else
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
                    return;
                }
            }
        }
        
		/*SCRID-3:Let test pass, when no lowLimit and upLimit.*/
		/*Joko Modify,2010-10-15*/
		//if(resultValue >=[mLowerValue intValue] && resultValue<=[mUpperValue intValue])
        //Added by bruce 2015.4.8----------------------------------
        if([mTestItemName rangeOfString:@"Flash LED"].length>0 )
        {
            if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >[mLowerValue doubleValue]))
               && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
            /*SCRID-3:Modify end*/
            {
                enumResult =RESULT_FOR_PASS ;
            }else
            {
                enumResult =RESULT_FOR_FAIL ;
            }
        }else
        {
            if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue doubleValue]))
               && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
            /*SCRID-3:Modify end*/
            {
                enumResult =RESULT_FOR_PASS ;
            }else
            {
                enumResult =RESULT_FOR_FAIL ;
            }

        }
		if (mBuffferName!=nil)  //add by giga
        {
			[TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%f",resultValue]] ;
            strTestResultForUIinfo = [NSString stringWithFormat:@"%0.6f",resultValue] ;
            // Added by Annie for CGButton only show pass on UI, but show the value to PDCA
            if ([mTestItemName rangeOfString:@"force"].length>0 && enumResult==RESULT_FOR_PASS )
            {
                strTestResultForUIinfo=@"Pass";
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"%@ Value",mTestItemName]:nil:[NSString stringWithFormat:@"%d",[mLowerValue intValue]]:[NSString stringWithFormat:@"%d",[mUpperValue intValue]]:[NSString stringWithFormat:@"%0.6f",resultValue]:nil:IP_PASS:@"PASS"];
            }else if([mTestItemName rangeOfString:@"force"].length>0 && enumResult==RESULT_FOR_FAIL )
            {
                strTestResultForUIinfo=@"Fail";
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"%@ Value",mTestItemName]:nil:[NSString stringWithFormat:@"%d",[mLowerValue intValue]]:[NSString stringWithFormat:@"%d",[mUpperValue intValue]]:[NSString stringWithFormat:@"%0.6f",resultValue]:nil:RESULT_FOR_FAIL:@"FAIL"];
            }
            //----------------Added end---------------------------------------------------
        }
        
        else
        {
            strTestResultForUIinfo = [NSString stringWithFormat:@"%0.6f",resultValue] ;
            //Added by bruce 2015.4.8----------------------------------
            if([mTestItemName rangeOfString:@"Flash LED"].length>0 && enumResult==RESULT_FOR_FAIL )
            {
                strTestResultForUIinfo=@"Fail";
            }
        }
        
	}
    //created by Fred  2012/08/08
    if( isNeedWriteToLocalfile == YES )
    {
        if (isNeedCreateFile){
            isNeedCreateFile=NO;
            //storageSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
            NSString*currentDate		= [NSDate date];
            NSString*strCreatTime	= [currentDate description];
            strCreatTime = [strCreatTime substringToIndex:(NSUInteger)19];
            strCreatTime = [strCreatTime stringByReplacingOccurrencesOfString:@":" withString:@"-"];
            strCreatTime = [strCreatTime stringByReplacingOccurrencesOfString:@" " withString:@"_"];
            DoefileName=[DoefileName stringByAppendingString:@"/vault/Localfile_"];
            DoefileName=[DoefileName stringByAppendingString:strCreatTime];
            DoefileName=[DoefileName stringByAppendingString:@".csv"];
            [DoefileName retain];
            
            FILE* fp=NULL;
            fp=fopen([DoefileName UTF8String],"wr");
            fclose(fp);
            
            keys = [keys stringByAppendingString:@"SN"];
            keys = [keys stringByAppendingString:@","];
            [keys retain];
        }
        
        if(isFirstValue == YES){
            fileData= @"";
            fileData=[fileData stringByAppendingString:@"\n"];
            
            fileData=[fileData stringByAppendingString:strUnitSN];
            fileData=[fileData stringByAppendingString:@","];
            [fileData retain];
        }
        
        keys = [keys stringByAppendingString:mTestItemName];
        keys = [keys stringByAppendingString:@","];
        [keys retain];
        
        fileData=[fileData stringByAppendingString:strTestResultForUIinfo];
        fileData=[fileData stringByAppendingString:@","];
        [fileData retain];
        
        if(isLastValue == YES){
            if(isNeedCreateKey == YES){
                isNeedCreateKey = NO;
                
                NSFileHandle *filehandKeys = [NSFileHandle fileHandleForWritingAtPath:DoefileName];
                if (filehandKeys!=nil) {
                    keys = [keys stringByAppendingString:@"Complete_time"];
                    [keys retain];
                    [filehandKeys seekToEndOfFile] ;
                    [filehandKeys writeData:[NSData dataWithData:[keys dataUsingEncoding:NSASCIIStringEncoding]]] ;
                    [filehandKeys closeFile] ;
                }
            }
            
            NSFileHandle *filehandValue = [NSFileHandle fileHandleForWritingAtPath:DoefileName];
            if(filehandValue!=nil)
            {
                NSString  *Time = [ToolFun getCurrentDateTime];
                fileData=[fileData stringByAppendingString:Time];
                [filehandValue seekToEndOfFile] ;
                [filehandValue writeData:[NSData dataWithData:[fileData dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandValue closeFile] ;
                [fileData retain];
                
            }
        }
        
    }//created end by Fred  2012/08/08
    
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	return;
}


//Add by justin start
+(void)ParseNumberAndShowMessageBox:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = @"";
    NSString *mReferenceBufferName = @"";
    NSString *mStrSpec = @"";
    NSString *mPrefix=nil;
    NSString *mPostfix=nil;
    NSString *mUpperValue=nil;
    NSString *mLowerValue=nil;
    
    NSString *mWinTitle = @"Unit";
    NSString *mTitle = @"壓力檢測警告！";
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if([strKey isEqualToString:@"Prefix"])
        {
            mPrefix=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"Postfix"])
        {
            mPostfix=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"UpperValue"])
        {
            mUpperValue=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"LowerValue"])
        {
            mLowerValue=[dictKeyDefined objectForKey:strKey];
        }
    }
    
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    
    
    NSString *strFindValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                                :mPrefix Postfix
                                                                :mPostfix] ;
    if (strFindValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format is not right"] ;
        return ;
    }
    
    strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    double resultValue=0;
    resultValue =[strFindValue doubleValue];
    
    if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue doubleValue]))
       && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue doubleValue])))
    /*SCRID-3:Modify end*/
    {
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"Value" :nil :mLowerValue :mUpperValue :strFindValue :nil:RESULT_FOR_PASS:@"Pass"];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
        return;
    }
    else
    {
        NSString *strDutid = [dictKeyDefined objectForKey:@"DUTID"] ;
        
        if (strDutid!=nil)
        {
            mWinTitle = [mWinTitle stringByAppendingFormat:@" - %@ ",strDutid];
        }
        NSInteger totalUI;
        NSInteger indexOfDut = [strDutid intValue] ;
        NSString *strUISelected = [ScriptParse getValueFromSummary:STRKEYSWITCHUI];
        if([strUISelected isEqualToString:@"UI4"]||[strUISelected isEqualToString:@"UI4DP"])
            totalUI = 4 ;
        
        else if(([strUISelected isEqualToString:@"UI2"])||([strUISelected isEqualToString:@"UI2QT"]))
            totalUI = 2 ;
        
        else
            totalUI = 1 ;
        [UIAlert setInitPosition:totalUI index:indexOfDut] ;
        UIAlert *alert = [[[UIAlert alloc] init] autorelease];
        
        NSLock *lock = [[NSLock alloc] init];
        [lock lock];
        [alert showWindow:self];
        [lock unlock];
        [alert updatPosition:totalUI index:indexOfDut];
        
        [alert setMessageText:@"请工站DRI检测Force sensor！"];
        [alert setInformativeText:mTitle];
        [alert addButtonWithTitle:@"确定?"];
        [alert runModal];
        
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"Value" :nil :mLowerValue :mUpperValue :strFindValue :nil:RESULT_FOR_FAIL:@"Fail"];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
        
        return;
    }
}
//Justin add end

+(void)ParseLastSixBit:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
    NSString *mFunction=nil;
    NSString *mTimes=nil;
	NSString *mBuffferName=nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	NSString *mResultType=nil;
	NSString *mNumberType=nil;
	NSString *mRecord=nil;
    NSString *mWriteToLocalfile=nil;
    NSString *mFirstValue = nil;
    NSString *mLastValue = nil;
    
	enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ResultType"])
		{
			mResultType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Record"])
		{
			mRecord=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"WriteToLocalfile"])
        {
            mWriteToLocalfile=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"FirstValue"])
        {
            mFirstValue=[dictKeyDefined objectForKey:strKey];
        }
        else if([strKey isEqualToString:@"LastValue"])
        {
            mLastValue=[dictKeyDefined objectForKey:strKey];
        }else if([strKey isEqualToString:@"Function"])
		{
			mFunction=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Times"])
		{
			mTimes=[dictKeyDefined objectForKey:strKey];
		}
        
	}
    
    if(mReferenceBufferName==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    
    NSString *mReferenceBufferValue;
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if([mUpperValue isEqualTo:@"NA"])
    {
        mUpperValue = nil;
    }
    if([mLowerValue isEqualTo:@"NA"])
    {
        mLowerValue = nil;
    }
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
                                                     Prefix:mPrefix
                                                    Postfix:mPostfix] ;	
    
    
    strFind=[strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
    strFind=[strFind stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    strFind=[strFind stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    strFind=[strFind stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if (strFind==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
        return  ;
    }
    
    NSArray * arrayTemp = [strFind componentsSeparatedByString:@"0x"];
    
    if([arrayTemp count] < 4)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
        return  ;
    }
    
    int resultValue = (int)strtol([[arrayTemp objectAtIndex:3] UTF8String], NULL, 16);
    resultValue = resultValue % 64;
    
    if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(resultValue >=[mLowerValue intValue]))
       && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(resultValue<=[mUpperValue intValue])))
    {
        enumResult =RESULT_FOR_PASS ;
    }
    else 
    {
        enumResult =RESULT_FOR_FAIL ;
    }
    
    if (mBuffferName!=nil)
        [TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%d",resultValue]] ;
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :[NSString stringWithFormat:@"%d",resultValue]] ;
}

+(void)Provisioning:(NSDictionary*)dictKeyDefined
{
	
	NSString *mProductType = nil;
	NSString* mSerialPort = nil;
	NSString* mBandRate = nil;
	NSString* mMPN = nil;
	NSString *mReignCode = nil;
	NSString *mMPNReference =nil;
	NSString *mRegionReferencce =nil;
	NSString *mNeedFG_SN = nil;
	NSString *mWhetherForceInsert = nil;
	
	
	NSString *strTestResultForUIinfo = @"FAIL";
	enum TestResutStatus enumResult = RESULT_FOR_FAIL;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"ProductType"])
		{
			mProductType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SerialPort"])
		{
			mSerialPort=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BandRate"])
		{
			mBandRate = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"MPN"])
		{
			mMPN = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReignCode"])
		{
			mReignCode = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"MPNReferenceBuffer"])
		{
			mMPNReference = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"RegionCodeReferenceBuffer"])
		{
			mRegionReferencce = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"NeedFG_SN"])
		{
			mNeedFG_SN = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"WhetherForceInsert"])
		{
			mWhetherForceInsert = [dictKeyDefined objectForKey:strKey];
		}
	}
	// close Comport  --------
	[self closeCurrPort:dictKeyDefined];
	mSerialPort = [self getCurrUnitDeviceName:dictKeyDefined] ;
	if (mSerialPort==nil)
	{
		[self openCurrPort:dictKeyDefined] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"Can't get current device"];
		return;
	};
	
	mMPN=[TestItemManage getSFCValue:dictKeyDefined :STRKEYMPN] ;
	mReignCode =[TestItemManage getSFCValue:dictKeyDefined :STRKEYREGN] ;

	bool mBol_GetAboveresult = false;
	int ret;
	mBol_GetAboveresult =  [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
	NSString * FILEPATH = @"";
	if(mWhetherForceInsert||mBol_GetAboveresult)//force INsert OR All Pass -> do provision
	{
		
		
		int index = [self GetCurrDUTID:dictKeyDefined];
		FILEPATH =[NSString stringWithFormat:@"/vault/provisioning/test%d.txt",index];
		
		
		//FILEPATH =@"/vault/provisioning/test.txt";
		
		NSLog(@"file path is QQQQQQQQQQQQQQQ: %@",FILEPATH);

		NSLog(@"begin to do provision ,,,,,,,,,,,,,,,,,\n");
		@try 
		{
			if(mMPN == nil || mReignCode == nil || mSerialPort == nil)  //joko add when mpn is nil, crash 2010-09-09
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"No 'MPN' or 'REGN' or No serial port"];
				return;
			}
			
			NSString *HWconfig = [TestItemManage getSFCValue:dictKeyDefined :STRKEYHWCOIG] ;
			NSString *strexec = @"";
			
			/*
			if(HWconfig==nil || [HWconfig length] <= 0)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"NO HWConfig which get from SFC!"];
				return;
			}else if([HWconfig rangeOfString:@"UMTS"].length>0)
			{
				strexec = [NSString stringWithFormat:@"/usr/local/bin/k94prov provision --port %@  --speed %@  --mpn %@  --rgn %@  > %@",mSerialPort,mBandRate==nil?@"115200":mBandRate,mMPN,mReignCode,FILEPATH];
				
			}else if([HWconfig rangeOfString:@"CDMA2000"].length>0)
			{
				strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --product=k95 --port %@ --mpn=K95 --rgn=LL/A  > %@",mSerialPort,FILEPATH];
				
			}else
			{
				strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --port %@  --speed %@ --sim --mpn=%@  --rgn=%@  --product=%@ > %@",mSerialPort,mBandRate==nil?@"115200":mBandRate,mMPN,mReignCode,mProduct,FILEPATH];
			}
			*/
			/*SCRID:3 modified by Henry on 2011-03-19 for provision*/
			if(HWconfig==nil || [HWconfig length] <= 0)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"NO HWConfig which get from SFC!"];
				return;
			}else if([HWconfig rangeOfString:@"UMTS"].length>0) //for J2
			{
				NSLog(@"begin to do provision J2 J2 J2 J2 J2 J2 J2 J2 J2 J2 J2 J2 J2 J2\n");
				/*SCRID:4 modified by caijunbo on 2011-03-20 */
				// don't need to specify speed
				//strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --port %@ --speed %@ --mpn=%@ --rgn=LL/A --product=j2  > %@",mSerialPort,mBandRate==nil?@"115200":mBandRate,mMPN,FILEPATH];
				strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --port %@ --mpn=%@ --rgn=LL/A --product=j2  > %@",mSerialPort,mMPN,FILEPATH];
			}else //for J1
			{
				NSLog(@"begin to do provision J1 J1 J1 J1 J1 J1 J1 J1 J1 J1 J1 J1 J1 J1\n");
				/*SCRID:4 modified by caijunbo on 2011-03-20 */
				// don't need to specify speed
				//strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --port %@ --speed %@ --mpn=%@ --rgn=LL/A --product=j1  > %@",mSerialPort,mBandRate==nil?@"115200":mBandRate,mMPN,FILEPATH];
				strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --port %@ --mpn=%@ --rgn=LL/A --product=j1  > %@",mSerialPort,mMPN,FILEPATH];
				//end modify
				
			}
			/*SCRID:3 end*/
			
			/* SCRID-28: T39 MPN Use 995-8188,when CustPartNo=995-8188*T39*LL/A  */
/*			if([mMPN rangeOfString:@"T39"].length > 0 || [mMPN rangeOfString:@"t39"].length > 0)
			{
				strexec = [NSString stringWithFormat:@"/usr/local/bin/provision --product=t39 --port %@ --mpn=%@ --rgn=LL/A  > %@",mSerialPort,t39MPN,FILEPATH];
			}
 */
			ret=system([strexec UTF8String]);
			
			NSLog(@"strexec is QQQQQQQQQQQQQQQ: %@",strexec);
		}
		@catch (NSException * e) 
		{
			ret = 257;
		}
		@finally {
			//
		}
		NSLog(@"after doing provision ,,,,,,,,,,,,,,,,,\n");
	}else
	{
		[self openCurrPort:dictKeyDefined] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no do provision!"];
		return;		
	}
	
	[self openCurrPort:dictKeyDefined];
	//Open ComPort---------------
	NSString* logContent = [NSString stringWithContentsOfFile:FILEPATH encoding:NSASCIIStringEncoding error:nil];
	NSLog(@"Porvision log is QQQQQQQQQQQQQQQ: %@",logContent);
	
	bool containPassStr = FALSE;
	if(([logContent rangeOfString:@"Provisioning completed"].length>0) || ([logContent rangeOfString:@"Provisioning Succeeded"].length>0)
		|| ([logContent rangeOfString:@"has already been provisioned"].length>0))  //joko add 2010-10-07 K95 provision return log format change
		containPassStr = TRUE;
	
	if(containPassStr)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}
	else
	{
		NSLog(@"Enter Fail Loop  QQQQQQQQQQQQQQQ");
		enumResult =RESULT_FOR_FAIL ;
		if([logContent rangeOfString:@"Error Message:"].length > 0) //joko add 2010-10-07
			strTestResultForUIinfo = [logContent substringFromIndex:[logContent rangeOfString:@"Error Message:"].location] ;
		if (strTestResultForUIinfo==nil)
			strTestResultForUIinfo = @"fail" ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	
	//after provision,delete testX.txt file.
	NSString *strExeDel=[NSString stringWithFormat:@"rm %@",FILEPATH];
	system([strExeDel UTF8String]);
	return;	
	
}
+(void)UpLoadSFC:(NSDictionary*)dictKeyDefined 
{	
	NSString *mUserName=@""  ;
	NSString *mPWD = @"" ;
	NSString *mDSN =@"";
	NSString *mQueryString=@"";
	NSString *mWhetherForceInsert=@"yes";
    NSString *mUseMLBSN=@"";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"UserName"])
		{
			mUserName =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"PassWord"])
		{
			mPWD =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"UserDsn"])
		{
			mDSN =  [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"InsertString"])
		{
			mQueryString =  [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"WhetherForceInsert"])
		{
			mWhetherForceInsert =  [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"UseMLBSN"])
		{
			mUseMLBSN =  [dictKeyDefined objectForKey:strKey];
		}
	}
	NSString* sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN]; //add by giga
	if (sN==nil)
		sN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
	if (sN==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@" no sn"] ;
		//[mSFCconnecter CloseConnect]; //add by giga
		return ;
	}	
    
    if ([mUseMLBSN length] > 0)
	{
		NSString *MLBSN = [TestItemManage getBufferValue:dictKeyDefined :mUseMLBSN];
        if ([MLBSN length] > 0)
        {
            sN = MLBSN;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get MLB sn"] ;
            return ;
        }
	}
	
	NSString *ghInfor=[NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil] ;
	if(!ghInfor)
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
		return;
	}
	ghInfor=[ghInfor stringByReplacingOccurrencesOfString:@"\"" withString:@""];
	//NSLog(@"infor %@",ghInfor);
	NSString *ghStation=[ToolFun getStrFromPrefixAndPostfix:ghInfor Prefix:@"STATION_ID :" Postfix:@","] ;
	NSString *machineID=[ToolFun getStrFromPrefixAndPostfix:ghInfor Prefix:@"MAC :" Postfix:@","] ;
    ghStation=[ghStation stringByReplacingOccurrencesOfString:@" " withString:@""];
	machineID=[machineID stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	if((ghStation==nil)||(machineID==nil))
	{
	    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get infor from local fail"] ;
		return;
	}
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"SN" withString:sN];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"GHSTATION" withString:ghStation];
	mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"MACHINEID" withString:machineID];
	
	BOOL flag =NO;
	flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
	if(flag)
	{
		NSString* testResult=@"0";
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"TESTRESULT" withString:testResult];
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"FAILITEM" withString:@"null"];
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"FAILDESC" withString:@"null"];
	}
	else {
		NSArray*itemsForPudding = [TestItemManage getPDCAInfo:dictKeyDefined] ;
		NSLog(@"upload data %@",itemsForPudding);
		NSString* failItem=@"";
		NSString*failCode=@"";
		
		for (int i =0;i<[itemsForPudding count];i++)
		{
			NSDictionary* item=[itemsForPudding objectAtIndex:i];
			if([[item objectForKey:@"TestResult"]intValue]==0)
			{
				failItem=[item objectForKey:@"TestName"];
				failCode=[item objectForKey:@"TestItemIndex"];
				if(([item objectForKey:@"SubTestName"]!=nil)&&(failCode==nil))
					continue;
				break;
			}
		}
		if((failCode==nil)||(failItem==nil))
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get testItem fail"] ;
			return;
		}
		NSString* testResult=@"1";
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"TESTRESULT" withString:testResult];
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"FAILITEM" withString:failItem];
		//NSLog(@"length =%d",[failItemValue length]);
		mQueryString = [mQueryString stringByReplacingOccurrencesOfString:@"FAILDESC" withString:failCode];
	}
	SFCConnecter* mSFCconnecter  =  [[[SFCConnecter alloc] init] autorelease];
	//added by caijunbo20100727
	NSString *strTestResultForUIinfo=nil;
	NSArray* DNSARR = [mDSN componentsSeparatedByString:@","];
	if (DNSARR==nil)
	{
		strTestResultForUIinfo = @"DSN in Script Error" ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :strTestResultForUIinfo] ;
		return;		
	}
	bool connectFla = false;
	for (NSString* dsn in DNSARR) 
	{
		
		if([mSFCconnecter ConnectSFCWithUserName:mUserName	PassWord:mPWD DSN:dsn]==true)//1
		{
			connectFla = TRUE;
			break;
		}
		
	}
	
	if(!connectFla)
	{
		strTestResultForUIinfo = @"All DSN Can't Connect !" ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :strTestResultForUIinfo] ;
		return;	
	}
	
	NSLog(@"\n insertString=%@",mQueryString);
	bool resultstr = [mSFCconnecter insertSQL:mQueryString];
	
	[mSFCconnecter CloseConnect];
	if(resultstr)
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	else
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
	
	return;
}

/*SCRID-144: Add Parser ParseStrWithNumberAndSpecStr. joko 2011-11-14*/
+(void)ParseStrWithNumberAndSpecStr:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBuffferName=nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	NSString *mUpperValue=nil;
	NSString *mLowerValue=nil;
	NSString *mResultType=nil;
	NSString *mNumberType=nil;
	NSString *mSpecailString=nil;
	
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ResultType"])
		{
			mResultType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"BufferName"])
		{
			mBuffferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"SpecailString"])
		{
			mSpecailString=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	if(mReferenceBufferName==nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
		return;
	}
	
	NSString *mReferenceBufferValue;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//mReferenceBufferValue = @" Checksum response = 0x5341 Checksum = 0x540E Checksum match.";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
													 Prefix:mPrefix
													Postfix:mPostfix] ;	
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
		return  ;
	}
	
	strFind = [strFind stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	strFind = [strFind stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSArray *arraySpecial = [mSpecailString componentsSeparatedByString:@","];
	BOOL flag = FALSE;
	
	for(int i=0; i<[arraySpecial count]; i++)
	{
		if([strFind rangeOfString:[arraySpecial objectAtIndex:i]].length > 0)
			flag = TRUE;
	}
	
	if(flag)
		enumResult =RESULT_FOR_PASS ;
	else 
		enumResult =RESULT_FOR_FAIL ;
	
	
	int resultValue = (int)strtol([strFind UTF8String], NULL, 16);

	if (mBuffferName!=nil)  
		[TestItemManage setBufferValue:dictKeyDefined :mBuffferName :[NSString stringWithFormat:@"%d",resultValue]] ;
	
	strTestResultForUIinfo = [NSString stringWithFormat:@"%d",resultValue] ;

	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	return;
}
/*SCRID-144:end*/

@end
