
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UICommon.m		     $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 26 Aug. 2010            $Modtime:: 26 Aug. 2010 15:24	 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History: UICommon.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 26 Aug. 2010   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import "UICommon.h"
#import "InstantPudding_API.h"
#import "testItemParse.h"

NSMutableDictionary *mutDictUiComm=nil ;
BOOL gbStationTestedFlag[3]={FALSE,FALSE,FALSE};
BOOL gBlinkFlag[3][3]={{FALSE,FALSE,FALSE},{FALSE,FALSE,FALSE},{FALSE,FALSE,FALSE}};

UNIT_PLUG_STATE plugStatus={TRUE,TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE}; //henry added 2011-01-27
BAR_STATUS statusBarState[3][3]={{BAR_GRAY,BAR_GRAY,BAR_GRAY},{BAR_GRAY,BAR_GRAY,BAR_GRAY},{BAR_GRAY,BAR_GRAY,BAR_GRAY}};

//henry added 2011-01-30 for record the step which have tested
BOOL bStepFinished[3][3]={{FALSE,FALSE,FALSE},{FALSE,FALSE,FALSE},{FALSE,FALSE,FALSE}};

NSString *strConfig=nil;
bool configScanedFlag=nil;

@implementation UICommon

/**** SCRID-66: Change prox cal to three fixtures and three UI. 2010-1-22 Henry ****/
+(void)init
{
	if(mutDictUiComm==nil)
		mutDictUiComm = [[NSMutableDictionary alloc] init];
}

+(void)deAlloc
{
	if(mutDictUiComm != nil)
	{
		[mutDictUiComm release];
		mutDictUiComm=nil;
	}

}
/**** SCRID-66 end ***/
+(NSString *)getPudingVersion
{
	NSString *strTemVer = nil;
	NSString *strVersion =@"";
	NSString *strVersionPre = @"Instant Pudding: ";
	
	char *ver = (char*)IP_getVersion();
	if(ver!=nil)
		strTemVer =[[NSString alloc] initWithFormat:@"%s",ver];
	strVersion = [strVersionPre stringByAppendingString:strTemVer];
	[strTemVer release];
	NSLog(strVersion);
	
	return strVersion;
}

+(NSString *)getFixtureID
{
	return strFixtureID ;
}

+(void)setFixtureID:(NSString *)fixtureId
{
	strFixtureID = fixtureId ;
}
+(bool)getFixtureIDScanedFlag
{
	return fixtureIdScanedFlag;
}
+(void)setFixtureIDScanedFlag:(bool)fixtureIdScaned
{
	fixtureIdScanedFlag = fixtureIdScaned ;
}
+(bool)getShowFixtureIDPanelFlag
{
	return fixtureIdPanelShowFlag ;
}
+(void)setShowFixtureIDPanelFlag:(bool)panelShowed
{
	fixtureIdPanelShowFlag = panelShowed ;
}


// Owner:Helen DATE :11.30.2010
// SCRID :025
// Desc  :Add for test Magnet Retention
+(void)setGaussValue:(NSString *)gaussValue
{
	strGaussValue = gaussValue ;
}
+(NSString *)getGaussValue
{
	return strGaussValue ;
}
//End by Helen 11.30.2010

// Owner:Henry DATE :1.19.2011  SCRID:66 Desc  :Add for QT3
+(void)addObjectToUIComm:(id)obj Key:(NSString*)strKey
{
	if((obj==nil)||(strKey==nil))
		return ;
	if(mutDictUiComm ==nil)
		return;
	[mutDictUiComm setObject:obj forKey:strKey];
}

+(id)getObjectFromUIComm:(NSString*)strKey
{
	if(strKey==nil)
		return nil;
	return [mutDictUiComm objectForKey:strKey];
}

+(void)setObjectBgdColor:(id)obj Key:(NSString*)strKey objType:(NSString*)strType
{
	if(obj == nil)
		return ;
	if(strKey == nil)
		return ;
	if(strType == nil)
		return ;
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	
	if([strType isEqualToString:@"tableView"])
	{
		NSTableView *aTableView = obj;
		if([strKey isEqualToString:@"red"])
		{
			[aTableView setUsesAlternatingRowBackgroundColors:NO];
			[aTableView setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([strKey isEqualToString:@"green"])
		{
			[aTableView setUsesAlternatingRowBackgroundColors:NO];
			[aTableView setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
		}
		else if([strKey isEqualToString:@"no"])
		{
			[aTableView setUsesAlternatingRowBackgroundColors:YES];
		}
	}
	else if([strType isEqualToString:@"statusBar"])
	{
		NSTextField *aStatusBar = obj;
		[aStatusBar setBackgroundColor:[NSColor clearColor]];

		if([strKey isEqualToString:@"red"])
		{
			[aStatusBar setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([strKey isEqualToString:@"green"])
		{
			[aStatusBar setBackgroundColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
		}
		else if([strKey isEqualToString:@"yellow"])
		{
			[aStatusBar setBackgroundColor:[NSColor yellowColor]];
		}
		else if([strKey isEqualToString:@"gray"])
		{
			[aStatusBar setBackgroundColor:[NSColor grayColor]];
		}
		else if([strKey isEqualToString:@"pink"])
		{
			[aStatusBar setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:0.55 blue:0.93 alpha:1]];
		}
		else if([strKey isEqualToString:@"no"])
		{
			[aStatusBar setBackgroundColor:[NSColor whiteColor]];
		}
		[aStatusBar display]; //henry added 2011-01-30
	}
	
	[pool release];
}

+(void)setOjbectPostion:(id)obj position:(NSRect)rect 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;

	if(obj != nil)
	{
		[obj setFrame:NSMakeRect(rect.origin.x , rect.origin.y, rect.size.width, rect.size.height) ];
	}	
	
	[pool release];
}

//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
+(void)setConfig:(NSString *)config
{
	strConfig = config;
}

+(NSString *)getconfig
{
	return strConfig;
}

+(bool)getConfigScanedFlag
{
	return configScanedFlag;
}

+(void)setConfigScanedFlag:(bool)config
{
	configScanedFlag = config;
}
//SCRID-71:END



//henry added 2011-01-27
+(UNIT_PLUG_STATE)getUnitPlugStatus
{
	return plugStatus;
}
+(void)updateUnitPlugStatus:(NSString*)strDevice
{
	BOOL bPortFlag1= FALSE;
	BOOL bPortFlag2= FALSE;
	BOOL bPortFlag3= FALSE;
	BOOL bPortPlugInFlag1= FALSE;
	BOOL bPortPlugInFlag2= FALSE;
	BOOL bPortPlugInFlag3= FALSE;
	UNIT_PLUG_STATE currentStatus=plugStatus;
	
	//if port plug out ,we will check whether plug in .if port plug in, we will check whether plug out
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	while (1) 
	{
		currentStatus=plugStatus;
		if(currentStatus.portDetectEnable1)
		{
			bPortFlag1 =[TestItemParse CheckUnitExist:@"IPad11":strTmp];
			if(bPortFlag1!=currentStatus.portFlag1)
			{
				if(bPortFlag1==TRUE)
					bPortPlugInFlag1=TRUE;
				else
					bPortPlugInFlag1=FALSE;
				
				plugStatus.portFlag1=bPortFlag1;
				plugStatus.portPlugInOrOut1=bPortPlugInFlag1;
			}
		}

		if(currentStatus.portDetectEnable2)
		{
			bPortFlag2 =[TestItemParse CheckUnitExist:@"IPad12":strTmp];
			if(bPortFlag2!=currentStatus.portFlag2)
			{
				if(bPortFlag2==TRUE)
					bPortPlugInFlag2=TRUE;
				else
					bPortPlugInFlag2=FALSE;
				
				plugStatus.portFlag2=bPortFlag2;
				plugStatus.portPlugInOrOut2=bPortPlugInFlag2;
			}
		}

		if(currentStatus.portDetectEnable3)
		{
			bPortFlag3 =[TestItemParse CheckUnitExist:@"IPad13":strTmp];
			if(bPortFlag3!=currentStatus.portFlag3)
			{
				if(bPortFlag3==TRUE)
					bPortPlugInFlag3=TRUE;
				else
					bPortPlugInFlag3=FALSE;
				
				plugStatus.portFlag3=bPortFlag3;
				plugStatus.portPlugInOrOut3=bPortPlugInFlag3;
			}
		}
		usleep(500000); //500ms
	}
}

+(void)setUnitPlugCheckStatus:(UNIT_PLUG_STATE)currStatus bflag:(BOOL)flag idx:(NSInteger)index;
{
	if(index==1)
		plugStatus.portDetectEnable1=flag;
	else if(index==2)
		plugStatus.portDetectEnable2=flag;
	else if(index==3)
		plugStatus.portDetectEnable3=flag;
	else if(index==4)
		plugStatus.portFlag1=flag;
	else if(index==5)
		plugStatus.portFlag2=flag;
	else if(index==6)
		plugStatus.portFlag3=flag;
	else if(index==7)
		plugStatus.portPlugInOrOut1=flag;
	else if(index==8)
		plugStatus.portPlugInOrOut2=flag;
	else if(index==9)
		plugStatus.portPlugInOrOut3=flag;
}
+(bool)waitForUnitPlug:(NSString*)strTmpDevice
{
	return TRUE;
}
+(void)objectBlinkStart:(id)obj indexBox:(NSInteger)idxBox indexBar:(NSInteger)idx
{
	if(gBlinkFlag[idxBox][idx] ==FALSE)
	{
		gBlinkFlag[idxBox][idx] =TRUE;
		//[self setStatusBarState:BAR_BLINKING idxBox:idxBox idxBar:idx]; //henry added 2011-01-30
		NSThread * threadBlink = [[NSThread alloc] initWithTarget:self selector:@selector(objectBlinking:) object:obj] ;
		[threadBlink start];
		[threadBlink release];
		threadBlink = nil;
	}
}
+(void)objectBlinkStop:(id)obj indexBox:(NSInteger)idxBox indexBar:(NSInteger)idx
{
	gBlinkFlag[idxBox][idx] =FALSE;
	//NSTextField *statusBar = obj;
	//[self setStatusBarState:BAR_PINK idxBox:idxBox idxBar:idx]; //henry added 2011-01-30
	//[statusBar setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:0.55 blue:0.93 alpha:1]];
	//[statusBar display];
}

+(void)objectBlinking:(id)obj
{
	NSTextField *statusBar = obj;
	
	BOOL bFlag=TRUE;
	NSInteger idxBox=0;
	NSInteger idxTable=0;
	
	if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar11"])
	{
		idxBox=0;
		idxTable=0;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar12"])
	{
		idxBox=0;
		idxTable=1;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar13"])
	{
		idxBox=0;
		idxTable=2;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar21"])
	{
		idxBox=1;
		idxTable=0;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar22"])
	{
		idxBox=1;
		idxTable=1;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar23"])
	{
		idxBox=1;
		idxTable=2;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar31"])
	{
		idxBox=2;
		idxTable=0;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar32"])
	{
		idxBox=2;
		idxTable=1;
	}
	else if(statusBar ==[UICommon getObjectFromUIComm:@"statusBar33"])
	{
		idxBox=2;
		idxTable=2;
	}
	
	while (gBlinkFlag[idxBox][idxTable]) 
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		if(statusBar==nil) //henry added 2011-02-14
			break;

		if(bFlag)
		{
			if(statusBar)
				[statusBar setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:0.55 blue:0.93 alpha:1]];
			bFlag=FALSE;
		}
		else 
		{
			if(statusBar)
				[statusBar setBackgroundColor:[NSColor grayColor]];
			bFlag=TRUE;
		}
		if(statusBar)
			[statusBar display];
		[pool release];
		usleep(300000); //500ms
	}

	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	if(statusBar)
	{
		//[statusBar setBackgroundColor:[NSColor grayColor]];
		[statusBar setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:0.55 blue:0.93 alpha:1]];
		[statusBar display];
	}
	[pool release];
}

+(void)setStatusBarState:(BAR_STATUS)barStatus idxBox:(NSInteger)index idxBar:(NSInteger)indx
{
	statusBarState[index][indx] =barStatus;
}

+(BAR_STATUS)getStatusBarState:(NSInteger)indexBox idxBar:(NSInteger)indx
{
	return statusBarState[indexBox][indx];
}

//henry added 2011-01-30
+(void)setFlagStepTested:(BOOL)flag boxIdx:(NSInteger)row barIdx:(NSInteger)line 
{
	bStepFinished[row][line]=flag;
}

+(BOOL)getFlagStepTested:(NSInteger)row barIdx:(NSInteger)line 
{
	return bStepFinished[row][line];
}
//henry added 2011-02-02
+(void)creatThreadToDetectErrorPlug
{
	//if([UICommon getTestingFlag]==FALSE)
	{
		NSThread * threadDetectPlug = [[NSThread alloc] initWithTarget:self selector:@selector(detectErrorPlug) object:nil] ;
		[threadDetectPlug start];
		[threadDetectPlug release];
		threadDetectPlug = nil;
	}
}
//[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar12"] Key:@"pink" objType:@"statusBar"];
+(BOOL)detectErrorPlug
{
#if 0
	int i=0;
	int j=0;
	BOOL bBlinkTmp=FALSE;
	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			if(gBlinkFlag[i][j])
			{
				bBlinkTmp=TRUE;
				break;
			}
		}
		if(bBlinkTmp)
			break;
	}
	
	if(bBlinkTmp)
	{
		
	}
	
	
	
	NSInteger iErrorPlugCnt=0;
	NSInteger totalUI=9;
	NSInteger indexOfWindow=1;
	NSString *strDevicePort1 = @"IPad11";
	NSString *strDevicePort2 = @"IPad12";
	NSString *strDevicePort3 = @"IPad13";
	BOOL bIsUnitExist1=FALSE;
	BOOL bIsUnitExist2=FALSE;
	BOOL bIsUnitExist3=FALSE;
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	
	while ([self getTestingFlag]==FALSE) 
	{
		//status bar 1 blinking
		if(gbStationTestedFlag[0]==FALSE)  
		{
			bIsUnitExist1=[TestItemParse CheckUnitExist:strDevicePort1:strTmp] ;
			if(bIsUnitExist1)
				return TRUE;
			bIsUnitExist2=[TestItemParse CheckUnitExist:strDevicePort2:strTmp] ;
			if (bIsUnitExist2)
			{
				indexOfWindow=2;
				//iErrorPlugCnt++;
				if(iErrorPlugCnt<3)
				{
					gbMessageBoxExist=TRUE;
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init]; 
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"OK"];
					[alert runModal];
					[alert release];
					bIsUnitExist2=FALSE;
					gbMessageBoxExist=FALSE;
				}
				else 
				{
					gbMessageBoxExist=TRUE;
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"Cancle"];
					[alert runModal];
					[alert release];
					gbMessageBoxExist=FALSE;
					return TRUE;
				}
			}
			
			bIsUnitExist3=[TestItemParse CheckUnitExist:strDevicePort3:strTmp] ;
			if (bIsUnitExist3)
			{
				indexOfWindow=3;
				iErrorPlugCnt++;
				if(iErrorPlugCnt<3)
				{
					gbMessageBoxExist=TRUE;
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init]; 
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"OK"];
					[alert runModal];
					[alert release];
					bIsUnitExist3=false;
					gbMessageBoxExist=FALSE;
				}
				else 
				{
					gbMessageBoxExist=TRUE;
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"Cancle"];
					[alert runModal];
					[alert release];
					gbMessageBoxExist=FALSE;
					return TRUE;
				}
			}
			
		}
		//status bar 2 blinking
		if((gbStationTestedFlag[0]==TRUE)&&(gbStationTestedFlag[1]==FALSE))  
		{
			bIsUnitExist2=[TestItemParse CheckUnitExist:strDevicePort2:strTmp] ;
			if(bIsUnitExist2)
				return TRUE;
			
			bIsUnitExist3=[TestItemParse CheckUnitExist:strDevicePort3:strTmp] ;
			if (bIsUnitExist3)
			{
				indexOfWindow=3;
				iErrorPlugCnt++;
				if(iErrorPlugCnt<3)
				{
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init]; 
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"OK"];
					[alert runModal];
					[alert release];
					bIsUnitExist3=false;
				}
				else 
				{
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"Cancle"];
					[alert runModal];
					[alert release];
					return TRUE;
				}
			}
			
			//port1 unplug-->plug
			if(plugStatus.portPlugInOrOut1 == NO)
			{
				bIsUnitExist1=[TestItemParse CheckUnitExist:strDevicePort1:strTmp] ;
				if (bIsUnitExist1)
				{
					indexOfWindow=1;
					iErrorPlugCnt++;
					if(iErrorPlugCnt<3)
					{
						[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
						UIAlert *alert = [[UIAlert alloc] init]; 
						[alert showWindow:self];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert setMessageText:@"Error!"];
						[alert setInformativeText:@"Wrong position!"];
						[alert addButtonWithTitle:@"OK"];
						[alert runModal];
						[alert release];
						bIsUnitExist1=false;
					}
					else 
					{
						[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
						UIAlert *alert = [[UIAlert alloc] init];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert showWindow:self];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert setMessageText:@"Error!"];
						[alert setInformativeText:@"Wrong position!"];
						[alert addButtonWithTitle:@"Cancle"];
						[alert runModal];
						[alert release];
						return TRUE;
					}
				}
			}
		}
		//status bar 3 blinking
		if((gbStationTestedFlag[0]==TRUE)&&(gbStationTestedFlag[1]==TRUE))  
		{
			bIsUnitExist3=[TestItemParse CheckUnitExist:strDevicePort3:strTmp] ;
			if(bIsUnitExist3)
				return TRUE;
			
			bIsUnitExist1=[TestItemParse CheckUnitExist:strDevicePort1:strTmp] ;
			if (bIsUnitExist1)
			{
				indexOfWindow=1;
				iErrorPlugCnt++;
				if(iErrorPlugCnt<3)
				{
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init]; 
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"OK"];
					[alert runModal];
					[alert release];
					bIsUnitExist1=false;
				}
				else 
				{
					[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
					UIAlert *alert = [[UIAlert alloc] init];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert showWindow:self];
					[alert updatPosition:totalUI index:indexOfWindow];
					[alert setMessageText:@"Error!"];
					[alert setInformativeText:@"Wrong position!"];
					[alert addButtonWithTitle:@"Cancle"];
					[alert runModal];
					[alert release];
					return TRUE;
				}
			}
			
			//port 2 unplug-->plug
			if(plugStatus.portPlugInOrOut2 == NO)
			{
				bIsUnitExist2=[TestItemParse CheckUnitExist:strDevicePort2:strTmp] ;
				if (bIsUnitExist2)
				{
					indexOfWindow=2;
					iErrorPlugCnt++;
					if(iErrorPlugCnt<3)
					{
						[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
						UIAlert *alert = [[UIAlert alloc] init]; 
						[alert showWindow:self];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert setMessageText:@"Error!"];
						[alert setInformativeText:@"Wrong position!"];
						[alert addButtonWithTitle:@"OK"];
						[alert runModal];
						[alert release];
						bIsUnitExist2=false;
					}
					else 
					{
						[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
						UIAlert *alert = [[UIAlert alloc] init];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert showWindow:self];
						[alert updatPosition:totalUI index:indexOfWindow];
						[alert setMessageText:@"Error!"];
						[alert setInformativeText:@"Wrong position!"];
						[alert addButtonWithTitle:@"Cancle"];
						[alert runModal];
						[alert release];
						return TRUE;
					}
				}
			}
		}
	}
#endif
	return FALSE;
}

//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
+(NSInteger)getMessageBoxWaitTime
{
	return messageBoxWaitTime;
}
+(void)setMessageBoxWaitTime:(NSInteger)waitTime
{
	messageBoxWaitTime = waitTime;
}
//SCRID:101 end

//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
+(void)setStopFailFlag:(BOOL)flag
{
	stopFailFlag = flag;
}
+(BOOL)getStopFailFlag
{
	return stopFailFlag;
}
//SCRID:109 end

@end
