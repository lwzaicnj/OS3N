
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UICommon.h		     $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 26 Aug. 2010            $Modtime:: 26 Aug. 2010 15:24	 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History: UICommon.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 26 Aug. 2010   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import <Cocoa/Cocoa.h>


typedef struct UIObjectInfor{
	int x;
	int y;
	int width;
	int height;
} UI_INFOR;

//henry added 2011-01-27
typedef struct UnitPlugIn{
	BOOL portDetectEnable1; //whether enable detect the port
	BOOL portDetectEnable2;
	BOOL portDetectEnable3;
	BOOL portFlag1; //already plug in or not
	BOOL portFlag2;
	BOOL portFlag3;
	BOOL portPlugInOrOut1;//true:in  false:out
	BOOL portPlugInOrOut2;
	BOOL portPlugInOrOut3;
} UNIT_PLUG_STATE;

//SCRID:58
//modified by Henry on 2011-01-05 for avoiding warning initia variable
//NSMutableString* strFixtureID; //20100902
NSString* strFixtureID; //20100902
//end
bool fixtureIdScanedFlag ;
bool fixtureIdPanelShowFlag ;

// Owner:Helen DATE :11.30.2010
// SCRID :025
// Desc  :Add for test Magnet Retention
//SCRID:58
//modified by Henry on 2011-01-05 for avoiding warning initia variable
//NSMutableString* strGaussValue;
NSString* strGaussValue;
//end
//End by Helen 11.30.2010

//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
NSInteger messageBoxWaitTime;
//SCRID:101 end

// Owner:Henry DATE :1.22.2011  SCRID:00 Desc  :Add for QT3
enum FAILTYPE
{
	FAIL_NONE			=0,
	FAIL_WRONG_UNIT		=1,
	FAIL_WRONG_POSITION	= 2 ,
	FAIL_FOR_DEFINE =FAIL_NONE , 
} ; 

typedef enum Bar_Status
{
	BAR_BLINKING	=0,
	BAR_PINK		=1,
	BAR_GRAY		=2 ,
} BAR_STATUS; 

//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
bool stopFailFlag;
//SCRID:109 end
@interface UICommon : NSObject {

}
+(void)init; //Henry add 2010-1-22
+(void)deAlloc; //Henry add 2010-1-22
+(NSString *)getPudingVersion;
+(NSString *)getFixtureID;
+(void)setFixtureID:(NSString *)fixtureId;
+(bool)getFixtureIDScanedFlag;
+(void)setFixtureIDScanedFlag:(bool)fixtureIdScaned;
+(bool)getShowFixtureIDPanelFlag;
+(void)setShowFixtureIDPanelFlag:(bool)panelShowed;

//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
+(void)setConfig:(NSString *)config;
+(NSString *)getconfig;
+(bool)getConfigScanedFlag;
+(void)setConfigScanedFlag:(bool)config;
//SCRID-71 END

// Owner:Helen DATE :11.30.2010
// SCRID :025
// Desc  :Add for test Magnet Retention
+(void)setGaussValue:(NSString *)gaussValue;
+(NSString *)getGaussValue;
//End by Helen 11.30.2010

// Owner:Henry DATE :1.19.2011  SCRID:00 Desc  :Add for QT3
+(void)addObjectToUIComm:(id)obj Key:(NSString*)strKey;
+(id)getObjectFromUIComm:(NSString*)strKey;
+(void)setObjectBgdColor:(id)obj Key:(NSString*)strKey objType:(NSString*)strType;
+(void)setOjbectPostion:(id)obj position:(NSRect)rect ;
//henry added 2011-01-27
+(UNIT_PLUG_STATE)getUnitPlugStatus;
+(void)updateUnitPlugStatus:(NSString*)strDevice;
+(void)setUnitPlugCheckStatus:(UNIT_PLUG_STATE)currStatus bflag:(BOOL)flag idx:(NSInteger)index;

+(bool)waitForUnitPlug:(NSString*)strDevice;
+(void)objectBlinkStart:(id)obj indexBox:(NSInteger)idxBox indexBar:(NSInteger)idx;
+(void)objectBlinkStop:(id)obj indexBox:(NSInteger)idxBox indexBar:(NSInteger)idx;
+(void)objectBlinking:(id)obj;
//for prox cal use only
+(void)setStatusBarState:(BAR_STATUS)barStatus idxBox:(NSInteger)index idxBar:(NSInteger)indx;
+(BAR_STATUS)getStatusBarState:(NSInteger)indexBox idxBar:(NSInteger)indx;

//henry added 2011-01-30
+(void)setFlagStepTested:(BOOL)flag boxIdx:(NSInteger)row barIdx:(NSInteger)line ;
+(BOOL)getFlagStepTested:(NSInteger)row barIdx:(NSInteger)line ;

//+(void)setTestingFlag:(BOOL)flag;
//+(BOOL)getTestingFlag;

//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
+(NSInteger)getMessageBoxWaitTime;
+(void)setMessageBoxWaitTime:(NSInteger)waitTime;
//SCRID:101 end.

//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
+(void)setStopFailFlag:(BOOL)flag;
+(BOOL)getStopFailFlag;
//SCRID:109 end
@end
