/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIWithoutScan.h  $|
 | $Author:: Henry                  $Revision::  2					 $|
 | CREATED: 13.05.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIWithoutScan.h                                       $
 * *****************  Version 1  *****************
 * User: Giga           Date: 24.02.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */


#import <Cocoa/Cocoa.h>
#import <eTraveler/eTravelerParameterKeys.h>
#import <eTraveler/eTraveler_StationProcess.h>
#import <eTraveler/eTraveler_TestResult.h>

#import <AppleTestStationAutomation/AppleControlledStation.h>
#import <AppleTestStationAutomation/AppleControlledStationDelegate.h>
#import <AppleTestStationAutomation/AppleTestStationAutomation.h>

@interface UI1QT1440X900 : NSObject {
    //Added by Luke for ATA 20160526
    AppleControlledStation * myStation;
    NSMutableDictionary *mytravelers;
    
	//iboutlet variable
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;

	IBOutlet NSTextField *textTotalTime;
	IBOutlet NSTextField *textItemTime;
	IBOutlet NSTextField *textSysSN;
	IBOutlet NSTextField *textBarCode ;
//	IBOutlet NSTextField *textHwySn;
	IBOutlet NSTextField* textFixtureID ;
	IBOutlet NSTextField *textX15Sn;
	IBOutlet NSTextField *textTestResult;

	IBOutlet NSButton* btnExit;
	IBOutlet NSButton* btnStart;
	IBOutlet NSButton* btnSimulator;
	IBOutlet NSButton* btnLogMaxMin;
    IBOutlet NSButton* btnReloadScript;
	
	IBOutlet NSTableView *tvTableview ;
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	IBOutlet NSBox *boxTestState ;
	IBOutlet NSTextField* textLabelSysSn;
	IBOutlet NSTextField* textLabelBarCode;
//	IBOutlet NSTextField* textLabelHWySn;
	IBOutlet NSTextField* textLabelX15Sn;
	IBOutlet NSTabView	 *tvTabview ;
	IBOutlet NSScrollView* textTestResultDetail ;
	IBOutlet NSScrollView* textAllLog ;
	IBOutlet NSScrollView* textItemLog ;
	IBOutlet NSScrollView *testItemScroView ;
	
//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
	IBOutlet NSTextField *textLabelConfig;
	IBOutlet NSTextField *textConfig;
	NSString *strNeedConfig;
//SCRID-71:END
	
	NSMutableString *stringSysSn;
	NSMutableString* stringBarcode;
//	NSMutableString* stringHwySn;
	NSMutableString* stringX15Sn;
	
	IBOutlet NSWindow *window;
	BOOL bSnScanedFlag[4];
	BOOL mNeedBarcode;
//SCRID-149: modify UI1Q to resove K93 UI crash issue.Judith 2011-12-12.	
	//NSDictionary *dicScanData;
	NSMutableDictionary *dicScanData ;
//SCRID-149:end
	NSString *strNeedFixtureID ;
 

}
-(IBAction)textConfigChange:(id)sender;//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28 
-(IBAction)reloadScript:(id)sender;
-(IBAction)btnStart_Click:(id)sender;
-(IBAction)btnCancel_Click:(id)sender;
-(IBAction)btnTabViewMaxMin_Click:(id)sender;
-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)textSysSnChange:(id)sender;
-(IBAction)textBarcodeChange:(id)sender;
//-(IBAction)textHwySnChange:(id)sender;
-(IBAction)textFixtureIdChange:(id)sender;
-(IBAction)textX15SnChange:(id)sender; 
-(IBAction)setFixtureID:(id)sender;
-(void)showInitLog;
-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(IBAction)btnSimulator_Click:(id)sender;
-(void)showItemLog;
-(NSString *)getItemClickedString;
-(void)showItemLog;
-(void)showTestResult;
-(void)tabViewItemUpdate:(NSInteger)index ;
-(IBAction)CallEditScriptUI:(id)sender ;
-(void)setBoxBgdColor:(NSNotification*)notification ; //henry added 2011-02-28

@end
