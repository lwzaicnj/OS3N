/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIWithoutScan.h  $|
 | $Author:: Henry                  $Revision::  2					 $|
 | CREATED: 13.05.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIWithoutScan.h                                       $
 * *****************  Version 1  *****************
 * User: Giga           Date: 24.02.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */


#import <Cocoa/Cocoa.h>


@interface UI1QT1440X900AutoTest : NSObject {
	
	//iboutlet variable
	IBOutlet NSTextField *textLabel1 ;
//	IBOutlet NSTextField *textLabel1Copy ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;

	IBOutlet NSTextField *textTotalTime;
	IBOutlet NSTextField *textItemTime;
	IBOutlet NSTextField *textTestResult;

	IBOutlet NSButton* btnExit;
	IBOutlet NSButton* btnSimulator;
	IBOutlet NSButton* btnLogMaxMin;
	
	IBOutlet NSTableView *tvTableview ;
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	IBOutlet NSBox *boxTestState ;
	IBOutlet NSTabView	 *tvTabview ;
	IBOutlet NSScrollView* textTestResultDetail ;
	IBOutlet NSScrollView* textAllLog ;
	IBOutlet NSScrollView* textItemLog ;
	IBOutlet NSScrollView *testItemScroView ;
	
	IBOutlet NSWindow *window;
	
	NSTableView *tableViewArray;
	BOOL mTestStartFlag;
	int refreshTimeCnt;
	
}
-(IBAction)btnCancel_Click:(id)sender;
-(IBAction)btnTabViewMaxMin_Click:(id)sender;
-(void)showInitLog;
-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(IBAction)btnSimulator_Click:(id)sender;
-(void)showItemLog;
-(NSString *)getItemClickedString;
-(void)showItemLog;
-(void)showTestResult;
-(void)tabViewItemUpdate:(NSInteger)index ;
-(IBAction)CallEditScriptUI:(id)sender ;
-(void)setTableBgdColor;

@end
