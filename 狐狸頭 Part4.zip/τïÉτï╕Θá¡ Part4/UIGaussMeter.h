
// Owner:Helen DATE :11.30.2010
// SCRID :025
// Desc  :Add for test Magnet Retention
 

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SingleUIWithoutScan.h  $|
 | $Author:: Henry                  $Revision::  2					 $|
 | CREATED: 13.05.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIWithoutScan.h                                       $
 * *****************  Version 1  *****************
 * User: Giga           Date: 24.02.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 */


#import <Cocoa/Cocoa.h>

@interface UIGaussMeter : NSObject {
	
	//iboutlet variable
	IBOutlet NSTextField *textLabel1 ;
	IBOutlet NSTextField *textLabel2 ;
	IBOutlet NSTextField *textLabelIPVersion ;

	IBOutlet NSTextField *textTotalTime;
	IBOutlet NSTextField *textItemTime;
	IBOutlet NSTextField *textSysSN;
	IBOutlet NSTextField *textBarCode ;
//	IBOutlet NSTextField *textHwySn;
	IBOutlet NSTextField* textFixtureID ;
	IBOutlet NSTextField *textX15Sn;
	IBOutlet NSTextField *textTestResult;
	
	IBOutlet NSTextField *textGauss;

	IBOutlet NSButton* btnExit;
	IBOutlet NSButton* btnStart;
	IBOutlet NSButton* btnSimulator;
	IBOutlet NSButton* btnLogMaxMin;
	
	IBOutlet NSTableView *tvTableview ;
	IBOutlet NSImageView * imageViewOfAppleLogo;
	IBOutlet NSImageView * imageViewBgd;
	IBOutlet NSBox *boxTestState ;
	IBOutlet NSBox *hide ;
	IBOutlet NSTextField* textLabelSysSn;
	IBOutlet NSTextField* textLabelBarCode;
//	IBOutlet NSTextField* textLabelHWySn;
	IBOutlet NSTextField* textLabelX15Sn;
	IBOutlet NSTextField* textLabelGauss;
	IBOutlet NSTabView	 *tvTabview ;
	IBOutlet NSScrollView* textTestResultDetail ;
	IBOutlet NSScrollView* textAllLog ;
	IBOutlet NSScrollView* textItemLog ;
	IBOutlet NSScrollView *testItemScroView ;

	NSMutableString *stringSysSn;
	NSMutableString* stringBarcode;
//	NSMutableString* stringHwySn;
	NSMutableString* stringX15Sn;
//	NSMutableString* stringGauss;
	
	IBOutlet NSWindow *window;
	BOOL bSnScanedFlag[4];
	BOOL mNeedBarcode;
	NSDictionary *dicScanData;
	
	NSString *strNeedFixtureID ;

}
-(IBAction)textGaussValueChange:(id)sender;
-(IBAction)btnStart_Click:(id)sender;
-(IBAction)btnCancel_Click:(id)sender;
-(IBAction)btnTabViewMaxMin_Click:(id)sender;
-(IBAction)btnSimulator_Click:(id)sender;
-(IBAction)textSysSnChange:(id)sender;
-(IBAction)textBarcodeChange:(id)sender;
//-(IBAction)textHwySnChange:(id)sender;
-(IBAction)textFixtureIdChange:(id)sender;
-(IBAction)textX15SnChange:(id)sender; 
-(IBAction)setFixtureID:(id)sender;
-(void)showInitLog;
-(BOOL)showLog:(NSInteger)logIndex isDisable:(BOOL)iShowFlag;
-(IBAction)btnSimulator_Click:(id)sender;
-(void)showItemLog;
-(NSString *)getItemClickedString;
-(void)setTableBgdColor;
-(void)showItemLog;
-(void)showTestResult;
-(void)tabViewItemUpdate:(NSInteger)index ;
-(IBAction)CallEditScriptUI:(id)sender ;
@end
