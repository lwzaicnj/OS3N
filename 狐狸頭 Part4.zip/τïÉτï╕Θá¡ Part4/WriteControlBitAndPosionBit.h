//
//  WriteControlBitAndPosionBit.h
//  qt_simulator
//
//  Created by QTeam on 3/26/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"
#import "CBAuth_API.h"


@interface TestItemParse(WriteControlBitAndPosionBit)

+(void)RS232WriteControlAndPosionBit:(NSDictionary*)dictKeyDefined ;
/*SCRID:63 add by Joko to add a parser to Write new CB */
+(void)RS232WriteControlAndPosionBitPassWord:(NSDictionary*)dictKeyDefined ;
/*SCRID:63 end*/

//Added by Annie for CB erasing password 2014.10.7
+(void)RS232ControlBitErasePassWord:(NSDictionary*)dictKeyDefined;

+(void)RS232WriteControlAndPosionBitPassWordV2:(NSDictionary*)dictKeyDefined ;
//SCRID:151 Ray add for writeCB three times in Magnetic station
+(void)RS232WriteControlAndPosionBitPassWordV2_3times:(NSDictionary*)dictKeyDefined ;
//SCRID:151 End

+(void)ParseDeviceID:(NSDictionary*)dictKeyDefined; //JianSheng add 2013-10-04

+(void)RS232EraseControlAndPosionBitPassWord:(NSDictionary*)dictKeyDefined;

@end
