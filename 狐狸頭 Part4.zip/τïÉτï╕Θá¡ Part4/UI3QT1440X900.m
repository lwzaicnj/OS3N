/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI3QT1440X900.m  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 14.05.10                $Modtime:: 14.05.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI3QT1440X900.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 14.05.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import "UI3QT1440X900.h"
#import "keysDefine.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"



//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGTEXTMIN   = {432,  72,	 960,	149};
static const UI_INFOR LOGTEXTMAX   = {21 ,	72,	 1360,	660};
static const UI_INFOR LOGBUTTONMAX = {20 ,	733, 51,	17};
static const UI_INFOR LABEL1	   = {283,  780, 627,	51};
static const UI_INFOR LABEL2       = {956,  789, 284,	17};

//static const UI_INFOR ICON       = {470,  198, 58,	22};

#define TIMERINTERVEL			0.25  //for check if unit plug in 250ms
#define TIMERINTERVEL_REFRESH	0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"



@implementation UI3QT1440X900
-(id)init
{
	initTableFlag =FALSE;
	tableViewCnt =0;
	refreshTimeCnt=0;
	tableViewForCnt = nil;
	for(NSInteger i=0; i<MaxUnitFlag; i++)
		mTestStartFlag[i] = TRUE;
	fixtureIdPanelController = nil;
	[UICommon init];
	NSString *strUITestItems = [ScriptParse getValueFromSummary:STRKEYQT3UIITEMS] ;
	if(strUITestItems != nil)
	{
		NSArray *tmpAry= [strUITestItems componentsSeparatedByString:@","];
		for(int i=0;i<3;i++)
			mUIItems[i]=[[tmpAry objectAtIndex:i] intValue];
	}
	else
	{
		NSRunAlertPanel(@"WARNNING", @"Please check Appconfig!", @"prompt", nil, nil) ;
	}
	self = [super init] ;
	return self ;
}

-(void)dealloc
{
	if(fixtureIdPanelController)
	{
		[fixtureIdPanelController release];
		fixtureIdPanelController =nil ;
	}
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1Copy  setStringValue:[ScriptParse getUILabel1]];
		[textLabel1 setFrame:(NSMakeRect(LABEL1.x, LABEL1.y, LABEL1.width, LABEL1.height))];
		[textLabel1Copy setFrame:(NSMakeRect(LABEL1.x+1, LABEL1.y+1, LABEL1.width, LABEL1.height))];
	}
	
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
	}
	[window setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:1.0 blue:0.94 alpha:1.0]];
	[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
	[textLabel2 setTextColor:[NSColor blueColor]] ;
//	[txtTest setBackgroundColor:[NSColor colorWithCalibratedRed:1.0 green:0.75 blue:0.8 alpha:0.5]] ;
	[self initUIScanLabelAndText];
	[textLog setHidden:TRUE];
	[self showInitLog];
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
															   :self selector
															   :@selector(timerRefreshTableViewMethod:) userInfo
															   :TIMERFORUNITPLUGINCHECK repeats
															   :YES ] retain] ;
	[timerRefreshTableView release] ;
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];
	}
	//Henry add for loop script 20101008
	[textIcon setBackgroundColor:[NSColor greenColor]];
	[UICommon addObjectToUIComm:textIcon Key:@"icon"];
	
	if((txtStatusBar11!=nil)&&(txtStatusBar12!=nil)&&(txtStatusBar13!=nil))
	{
		[UICommon addObjectToUIComm:txtStatusBar11 Key:@"statusBar11"];
		[UICommon addObjectToUIComm:txtStatusBar12 Key:@"statusBar12"];
		[UICommon addObjectToUIComm:txtStatusBar13 Key:@"statusBar13"];
		[txtStatusBar11 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar12 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar13 setBackgroundColor:[NSColor grayColor]];
	}
	else
		NSRunAlertPanel(@"WARNNING", @"UI init fail !", @"prompt", nil, nil) ;

	if((boxUnitView1!= nil)&&(boxUnitView1!= nil)&&(boxUnitView1!= nil))
	{
		[UICommon addObjectToUIComm:boxUnitView1 Key:@"boxView1"];
		[UICommon addObjectToUIComm:boxUnitView2 Key:@"boxView2"];
		[UICommon addObjectToUIComm:boxUnitView3 Key:@"boxView3"];
	}
	else
		NSRunAlertPanel(@"WARNNING", @"UI init fail !", @"prompt", nil, nil) ;
	NSTimer *timerRefreshBox =[[NSTimer scheduledTimerWithTimeInterval:0.1 target
																			:self selector
																			:@selector(testResultHandleThread:) userInfo
																			:nil repeats
																			:YES ] retain] ;
	[timerRefreshBox release] ;
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	/* SCRID-60: Record the Debug Log for crash analize. Joko 2011-1-8*/
	[ScriptParse recordCrashLog:@"UI4DOE1440X900.m, timerRefreshTableViewMethod, startTest"];
	/* SCRID-60 end */
	
	for(int i=0;i<4;i++)
	{
		if(tableViewArray[i] != nil)
			[tableViewArray[i] reloadData];
	}
	
	refreshTimeCnt++ ;
	if (refreshTimeCnt>5)
	{
			NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL target
																	   :self selector
																	   :@selector(timerUnitCheckFireMethod:) userInfo
																	   :TIMERFORUNITPLUGINCHECK repeats
																	   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	
	NSInteger totalUnit = 4;//[UIWinManage getTotalUnitNumber];
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
	//Henry add for check Fixture ID
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if([UICommon getFixtureIDScanedFlag] ==NO)
		{
			if(![UICommon getShowFixtureIDPanelFlag])
			{
				NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
				if(!fixtureIdPanelController)
					fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
				[fixtureIdPanelController showWindow:self];
				[UICommon setShowFixtureIDPanelFlag:YES];
				return ;
			}
			return ;
		}
	}
	
	for(int i=0;i<totalUnit;i++)
	{ 
		if([UIWinManage isCheckDUTID:1])
		{
			continue;
		}
		else 
		{
			if([UIWinManage getUnit:1])
			{
				switch(1)
				{
					case 1:
						if((mTestStartFlag[0])&&(![[textTestResult1 stringValue] isEqualToString:@"on going"]))
						{
							[UIWinManage startTest:1 :tableView11 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
							mTestStartFlag[0]=NO ;
						}

							[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar11"] Key:@"gray" objType:@"statusBar"];
							[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar12"] Key:@"gray" objType:@"statusBar"];
							[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar13"] Key:@"gray" objType:@"statusBar"];
						
						break;
/*				case 2:
						if(mTestStartFlag[i])
						{
							[UIWinManage startTest:2 :tableView21 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
							mTestStartFlag[i]=NO ;
						}
						break;
						case 3:
						if(mTestStartFlag[i])
						{
							[UIWinManage startTest:3 :tableView31 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
							mTestStartFlag[i]=NO ;
						}
						break;
	*/				default:
						break;
				}
			}
			else
			{
				//if (i<MaxUnitFlag)
				//	mTestStartFlag[i] = YES;
				mTestStartFlag[0] = YES;
			}
	 
		}
	}
	return ;
}

-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	if(tableViewArray[0]==tableView)
		return mUIItems[0];
	else if(tableViewArray[1]==tableView)
		return mUIItems[1];
	else if(tableViewArray[2]==tableView)
		return mUIItems[2];
	else 
		return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{

	NSInteger resultRowIdx =1;
	NSString *strResult = [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex];
	if(strResult == nil)
		strResult = @"TEST RESULT";
	NSInteger tagId = [aTableView tag];
	NSLog(@"tag ID = %d",tagId);
	
	if(initTableFlag == FALSE)
	{
		if(tableViewForCnt ==nil)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[0]=aTableView;
			if(tableViewArray[0])
				[UICommon addObjectToUIComm:tableViewArray[0] Key:@"tableView11"];
		}
		else if(tableViewForCnt!= aTableView)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[tableViewCnt-1]=aTableView;
			
			if(tableViewArray[1])
				[UICommon addObjectToUIComm:tableViewArray[1] Key:@"tableView12"];
			if(tableViewArray[2])
				[UICommon addObjectToUIComm:tableViewArray[2] Key:@"tableView13"];
		}
		
		if(tableViewCnt >= 4)
			initTableFlag = TRUE;
		else
			return nil ;
		return nil ;
	}
	
	if(tableViewArray[0]==aTableView)
	{
		rowIndex = rowIndex;
		if(rowIndex>=mUIItems[0])
			return nil;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex];
	}
	else if(tableViewArray[1]==aTableView)
	{
		rowIndex = rowIndex +mUIItems[0];
		if(rowIndex>=(mUIItems[0]+mUIItems[1]))
			return nil;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex];
	}
	else if(tableViewArray[2]==aTableView)
	{
		rowIndex = rowIndex +mUIItems[0]+mUIItems[1];
		if(rowIndex>=(mUIItems[0]+mUIItems[1]+mUIItems[2]))
			return nil;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex];
	}
	
	return nil;
}

-(void)setBoxBgdColor:(id)obj objType:(NSString*)strType;
{
	NSString *strObjectType = strType;
	if([strObjectType isEqualToString:@"box"])
	{
		NSBox *boxUnitView = obj;
		if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
		{
			[boxUnitView setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0.35 blue:0.6 alpha:0.5]];
		}
		else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
		{
			[boxUnitView setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
		}
		else 
		{
			[boxUnitView setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
		}
	}
}
-(void)showInitLog
{
	NSString *temStr=[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
	{	
		NSRunAlertPanel(@"init log info", temStr, @"prompt", nil, nil) ;
	}
}

-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}

-(void)initUIScanLabelAndText
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;

	[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel1Copy setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel2 setTextColor:[NSColor blackColor]];
	[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
	[textLabel1Copy setFont:[NSFont userFontOfSize:28]] ;

	NSArray *arrayUnitInfo = [UIWinManage getTotalUnitInfo];
	if(arrayUnitInfo ==nil)
		NSLog(@"Load Unit Infor error");

	[[textLog documentView]setEditable:false] ;
	[textLog setFrame:NSMakeRect(LOGTEXTMIN.x, LOGTEXTMIN.y, LOGTEXTMIN.width, LOGTEXTMIN.height)];

	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[ NSBundle mainBundle];
	NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	[imageAppleLogo release];
	[imageBgd release];
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}
-(void)testResultHandleThread:(NSTimer*)theTimer
{
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	[self setBoxBgdColor:boxUnitView1 objType:@"box"];
	
	usleep(200000) ; //delay 100 ms
	[pool release];
}

@end
