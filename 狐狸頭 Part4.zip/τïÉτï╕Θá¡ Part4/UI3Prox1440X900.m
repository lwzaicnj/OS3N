/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: UI3Prox1440X900.m	 $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 2011-02-10                $Modtime:: 2011-02-10 15:24	 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: UI3Prox1440X900.m                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 2011-02-10   Time: 11:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */



#import "UI3Prox1440X900.h"
#import "keysDefine.h"
#import "ScriptParse.h"
#import "pubFun.h"
#import "testItemManage.h"
#import "UIWinManage.h"
#import "testItemParse.h"
#import "UIAlert.h"

extern NSString *Thread1SN;
extern NSString *Thread2SN;
extern NSString *Thread3SN;

extern BOOL canTestFixture1;
extern BOOL canTestFixture2;
extern BOOL canTestFixture3;

extern BOOL canDetectFixture1;
extern BOOL canDetectFixture2;
extern BOOL canDetectFixture3;
extern BOOL gBlinkFlag[3][3];

//           UI Item Name             x,    y,   Width, Height 
static const UI_INFOR HEADVIEWBGD  = {7 ,	760, 1270,	100};
static const UI_INFOR LOGTEXTMIN   = {432,  72,	 960,	149};
static const UI_INFOR LOGTEXTMAX   = {21 ,	72,	 1360,	660};
static const UI_INFOR LOGBUTTONMAX = {20 ,	733, 51,	17};
static const UI_INFOR LABEL1	   = {283,  780, 627,	51};
static const UI_INFOR LABEL2       = {956,  789, 284,	17};

static const UI_INFOR BOXVIEW_POSITION_1  = {23,  662, 436,	89};
static const UI_INFOR BOXVIEW_POSITION_2  = {484,  662, 436,	89};
static const UI_INFOR BOXVIEW_POSITION_3  = {945,  662, 436,	89};

#define TIMERINTERVEL			0.25  //for check if unit plug in 250ms
#define TIMERINTERVEL_REFRESH	0.1  //for refresh tableView
#define TIMERFORUNITPLUGINCHECK   @"1"


NSInteger testResult[3]={1,2,3};

NSTextField *SN1=nil;
NSTextField *SN2=nil;
NSTextField *SN3=nil;
NSTextField *TestResult1=nil;
NSTextField *TestResult2=nil;
NSTextField *TestResult3=nil;
NSTextField *TotalCycleTime1=nil;
NSTextField *TotalCycleTime2=nil;
NSTextField *TotalCycleTime3=nil;
NSTextField *ItemGroupTime1=nil;
NSTextField *ItemGroupTime2=nil;
NSTextField *ItemGroupTime3=nil;


@implementation UI3Prox1440X900
-(id)init
{
	dicFirstThreeUnitSn=[[NSMutableDictionary alloc] init];
	bHaveUnPlugUnit1=TRUE;
	bHaveUnPlugUnit2=TRUE;
	bHaveUnPlugUnit3=TRUE;
	
	for(NSInteger i=0;i<3;i++)
	{
		enableRefreshTimer[i] =TRUE;
		enableTotalTimer[i]=TRUE;
	}
	
	bMessageFlag=false;
	initTableFlag =FALSE;
	tableViewCnt =0;
	refreshTimeCnt=0;
	tableViewForCnt = nil;
	for(NSInteger i=0; i<MaxUnitFlag; i++)
		mTestStartFlag[i] = TRUE;
	fixtureIdPanelController = nil;
	bCheckUnplug=FALSE;
	[UICommon init];
	NSString *strUITestItems = [ScriptParse getValueFromSummary:STRKEYQT3UIITEMS] ;
	if(strUITestItems != nil)
	{
		NSArray *tmpAry= [strUITestItems componentsSeparatedByString:@","];
		for(int i=0;i<3;i++)
			mUIItems[i]=[[tmpAry objectAtIndex:i] intValue];
	}
	else
	{
		NSRunAlertPanel(@"WARNNING", @"Please check Appconfig!", @"prompt", nil, nil) ;
	}
	self = [super init] ;
	return self ;
}

-(void)dealloc
{
	[dicFirstThreeUnitSn release];
	dicFirstThreeUnitSn=nil;
	if(fixtureIdPanelController)
	{
		[fixtureIdPanelController release];
		fixtureIdPanelController =nil ;
	}
	[[NSNotificationCenter defaultCenter] removeObserver:self] ; //henry add 2011-01-25
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if ([ScriptParse getUILabel1]!=nil)
	{
		[textLabel1 setStringValue:[ScriptParse getUILabel1]] ;
		[textLabel1Copy  setStringValue:[ScriptParse getUILabel1]];
		[textLabel1 setFrame:(NSMakeRect(LABEL1.x, LABEL1.y, LABEL1.width, LABEL1.height))];
		[textLabel1Copy setFrame:(NSMakeRect(LABEL1.x+1, LABEL1.y+1, LABEL1.width, LABEL1.height))];
	}
	
	if ([ScriptParse getUILabel2]!=nil)
	{
		[textLabel2 setStringValue:[ScriptParse getUILabel2]] ;
	}
	[window setBackgroundColor:[NSColor colorWithCalibratedRed:0.94 green:1.0 blue:0.94 alpha:1.0]];
	[textLabel2 setFont:[NSFont userFontOfSize:15]] ;
	[textLabel2 setTextColor:[NSColor blueColor]] ;
	[self initUIScanLabelAndText];
	[self showInitLog];
	[textLabelIPVersion setStringValue:[UICommon getPudingVersion]];
	NSTimer *timerRefreshTableView =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL_REFRESH target
																			:self selector
																			:@selector(timerRefreshTableViewMethod:) userInfo
																			:TIMERFORUNITPLUGINCHECK repeats
																			:YES ] retain] ;
	[timerRefreshTableView release] ;
	//show Set Fixture ID panel  20100902
	strNeedFixtureID = [ScriptParse getValueFromSummary:STRKEYNEEDFIXTUREID] ;
	if(strNeedFixtureID == nil)
		strNeedFixtureID = @"no";
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if(!fixtureIdPanelController)
			fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
		NSLog(@"showing %@",fixtureIdPanelController);
		[fixtureIdPanelController showWindow:self];
	}
	
	//Henry add for store status bar 20110125
	if(((txtStatusBar11!=nil)&&(txtStatusBar12!=nil)&&(txtStatusBar13!=nil))
	   &&((txtStatusBar21!=nil)&&(txtStatusBar22!=nil)&&(txtStatusBar23!=nil))
	   &&((txtStatusBar31!=nil)&&(txtStatusBar32!=nil)&&(txtStatusBar33!=nil)))
	{
		[UICommon addObjectToUIComm:txtStatusBar11 Key:@"statusBar11"];
		[UICommon addObjectToUIComm:txtStatusBar12 Key:@"statusBar12"];
		[UICommon addObjectToUIComm:txtStatusBar13 Key:@"statusBar13"];
		[UICommon addObjectToUIComm:txtStatusBar21 Key:@"statusBar21"];
		[UICommon addObjectToUIComm:txtStatusBar22 Key:@"statusBar22"];
		[UICommon addObjectToUIComm:txtStatusBar23 Key:@"statusBar23"];
		[UICommon addObjectToUIComm:txtStatusBar31 Key:@"statusBar31"];
		[UICommon addObjectToUIComm:txtStatusBar32 Key:@"statusBar32"];
		[UICommon addObjectToUIComm:txtStatusBar33 Key:@"statusBar33"];
		[txtStatusBar11 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar12 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar13 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar21 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar22 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar23 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar31 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar32 setBackgroundColor:[NSColor grayColor]];
		[txtStatusBar33 setBackgroundColor:[NSColor grayColor]];
	}
	else
		NSRunAlertPanel(@"WARNNING", @"UI init fail !", @"prompt", nil, nil) ;
	
	[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
	[UICommon setStatusBarState:BAR_BLINKING idxBox:0 idxBar:0];
	
	if((boxUnitView1!= nil)&&(boxUnitView1!= nil)&&(boxUnitView1!= nil))
	{
		[UICommon addObjectToUIComm:boxUnitView1 Key:@"boxView1"];
		[UICommon addObjectToUIComm:boxUnitView2 Key:@"boxView2"];
		[UICommon addObjectToUIComm:boxUnitView3 Key:@"boxView3"];
	}
	else
		NSRunAlertPanel(@"WARNNING", @"UI init fail !", @"prompt", nil, nil) ;
	//henry added 2011-02-13
	if(((textLabelSN1!= nil)&&(textLabelSN2!= nil)&&(textLabelSN3!= nil))
		&&((textTestResult1!=nil)&&(textTestResult2!=nil)&&(textTestResult3!=nil))
		&&((textTotalCycleTime1!=nil)&&(textTotalCycleTime2!=nil)&&(textTotalCycleTime3!=nil))
		&&((textItemGroupTime1!=nil)&&(textItemGroupTime2!=nil)&&(textItemGroupTime3!=nil)))
	{
		[UICommon addObjectToUIComm:textLabelSN1 Key:@"sn1"];
		[UICommon addObjectToUIComm:textLabelSN2 Key:@"sn2"];
		[UICommon addObjectToUIComm:textLabelSN3 Key:@"sn3"];
		[UICommon addObjectToUIComm:textTestResult1 Key:@"result1"];
		[UICommon addObjectToUIComm:textTestResult2 Key:@"result2"];
		[UICommon addObjectToUIComm:textTestResult3 Key:@"result3"];
		[UICommon addObjectToUIComm:textTotalCycleTime1 Key:@"totalTime1"];
		[UICommon addObjectToUIComm:textTotalCycleTime2 Key:@"totalTime2"];
		[UICommon addObjectToUIComm:textTotalCycleTime3 Key:@"totalTime3"];
		[UICommon addObjectToUIComm:textItemGroupTime1 Key:@"groupTime1"];
		[UICommon addObjectToUIComm:textItemGroupTime2 Key:@"groupTime2"];
		[UICommon addObjectToUIComm:textItemGroupTime3 Key:@"groupTime3"];
	}
	SN1=textLabelSN1;
	SN2=textLabelSN2;
	SN3=textLabelSN3;
	//henry added end 2011-02-13
	
	[textLabelSN1 setStringValue:@""];
	[textLabelSN2 setStringValue:@""];
	[textLabelSN3 setStringValue:@""];
	//bWhetherAlreadyPlug = [UIWinManage getUnit:1];//marked by caijunbo on 2011-01-27
	
	//bWhetherAlreadyPlug = [UIWinManage getUnit:1];
	//[UICommon creatThreadToDetectErrorPlug]; //henry added 2011-02-02
	
	//henry add for set status bar and box satatus 2011-01-25
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR1" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR2" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setBoxBgdColor:) name:@"SET_UI_BGD_COLOR3" object:nil ] ;
	
	//henry add for show Unit SN 2011-02-07
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN1" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN2" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showUnitSN:) name:@"SHOW_UNIT_SN3" object:nil ] ;
	
	//henry added 2011-02-08
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT1_TIMER_RESTART" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT2_TIMER_RESTART" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT3_TIMER_RESTART" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT1_TIMER_STOP" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT2_TIMER_STOP" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTestItemTimerStatus:) name:@"UUT3_TIMER_STOP" object:nil ] ;
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeBoxViewPostion:) name:@"SET_UI_BOX_POSITION" object:nil ] ;
	
	
}

-(void)timerRefreshTableViewMethod:(NSTimer*)theTimer
{
	for(int i=0;i<9;i++)
	{
		if(tableViewArray[i] != nil)
			[tableViewArray[i] reloadData];
	}
	
	refreshTimeCnt++ ;
	if (refreshTimeCnt>9)
	{
		NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:TIMERINTERVEL target
																   :self selector
																   :@selector(timerUnitCheckFireMethod:) userInfo
																   :TIMERFORUNITPLUGINCHECK repeats
																   :YES ] retain] ;
		[timerTmp release] ;
	    [theTimer invalidate] ;
	}
}

- (void)timerUnitCheckFireMethod:(NSTimer*)theTimer 
{
	
	//added by caijunbo on 2011-01-26
	//NSString *strCurrentUnitSnAtFirstLocation=nil;
	NSMutableDictionary *mutDicTemp=[[[NSMutableDictionary alloc] init] autorelease];
	[mutDicTemp setObject:@"IPad" forKey:@"Device"];
	[mutDicTemp setObject:@"IPad11" forKey:@"UNITDevice"];
	//end
	
	NSInteger totalUnit = 3;//[UIWinManage getTotalUnitNumber];
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
	//Henry add for check Fixture ID
	if([strNeedFixtureID isEqualToString:@"yes"])
	{
		if([UICommon getFixtureIDScanedFlag] ==NO)
		{
			if(![UICommon getShowFixtureIDPanelFlag])
			{
				NSRunAlertPanel(@"WARNNING", @"Please scan the Fixture Barcode!", @"prompt", nil, nil) ;
				if(!fixtureIdPanelController)
					fixtureIdPanelController = [[ FixtureIdPanelController alloc] init];
				[fixtureIdPanelController showWindow:self];
				[UICommon setShowFixtureIDPanelFlag:YES];
				return ;
			}
			return ;
		}
	}
	
	for(int i=0;i<totalUnit;i++)
	{ 
		if([UIWinManage isCheckDUTID:1])
		{
			if([UIWinManage isCheckDUTID:2])
			{
				if([UIWinManage isCheckDUTID:3])
				{
					continue;
				}
				else //1 testing, 2 testing, 3 notest
				{
					if(canDetectFixture1 && ![UIWinManage getUnit:3])
						[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar31"] indexBox:2 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:3] && gBlinkFlag[2][0])
					{
						if((![[textTestResult3 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:3]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:3 :tableView11 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
								[self startDUTIDTimer:@"3"];
							}
						}
					}
				}
			}
			else  //1 testing, 2 no test
			{	
				if([UIWinManage isCheckDUTID:3]) //1 testing, 2 no test, 3 testing
				{
					if(canDetectFixture1 && ![UIWinManage getUnit:2])
						[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:2] && gBlinkFlag[1][0])
					{
						if((![[textTestResult2 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:2]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:2 :tableView11 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
								[self startDUTIDTimer:@"2"];
							}
						}
					}
				}
				else //1 testing, 2 no test, 3 no test
				{
					if(gBlinkFlag[2][0])
					{
						if(canDetectFixture1 && [UIWinManage getUnit:3])
						{
							if((![[textTestResult3 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:3]))
							{
								if(canTestFixture1)
								{
									canDetectFixture1=FALSE;
									canDetectFixture1=FALSE;
									[UIWinManage startTest:3 :tableView11 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
									[self startDUTIDTimer:@"3"];
								}
							}
						}
					}
					else
					{
						if(canDetectFixture1 && ![UIWinManage getUnit:2])
							[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
						if(canDetectFixture1 && [UIWinManage getUnit:2] && gBlinkFlag[1][0])
						{
							if((![[textTestResult2 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:2]))
							{
								if(canTestFixture1)
								{
									canTestFixture1=FALSE;
									canDetectFixture1=FALSE;
									[UIWinManage startTest:2 :tableView11 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
									[self startDUTIDTimer:@"2"];
								}
							}
						}
					}
				}
			}
		}
		else //1 notest,
		{
			if([UIWinManage isCheckDUTID:2] && [UIWinManage isCheckDUTID:3]) //1 notest, 2 testing, 3 testing
			{
				if(canDetectFixture1 && ![UIWinManage getUnit:1])
					[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
				if(canDetectFixture1 && [UIWinManage getUnit:1] && gBlinkFlag[0][0])
				{
					if((![[textTestResult1 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:1]))
					{
						if(canTestFixture1)
						{
							canTestFixture1=FALSE;
							canDetectFixture1=FALSE;
							[UIWinManage startTest:1 :tableView11 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
							[self startDUTIDTimer:@"1"];
						}
					}
				}
			}
			if([UIWinManage isCheckDUTID:2] && ![UIWinManage isCheckDUTID:3]) //1 notest, 2 testing, 3 notest
			{
				if(canDetectFixture1 && ![UIWinManage getUnit:3])
					[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar31"] indexBox:2 indexBar:0];
				if(canDetectFixture1 && [UIWinManage getUnit:3] && gBlinkFlag[2][0])
				{
					if((![[textTestResult3 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:3]))
					{
						if(canTestFixture1)
						{
							canTestFixture1=FALSE;
							canDetectFixture1=FALSE;
							[UIWinManage startTest:3 :tableView11 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
							[self startDUTIDTimer:@"3"];
						}
					}
				}
			}
			if(![UIWinManage isCheckDUTID:2] && [UIWinManage isCheckDUTID:3]) //1 notest, 2 notest, 3 testing
			{
				if(gBlinkFlag[1][0])
				{
					//[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:2])
					{
						if((![[textTestResult2 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:2]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:2 :tableView11 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
								[self startDUTIDTimer:@"2"];
							}
						}
					}
				}
				else
				{
					if(canDetectFixture1 && ![UIWinManage getUnit:1])
						[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:1] && gBlinkFlag[0][0])
					{
						if((![[textTestResult1 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:1]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:1 :tableView11 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
								[self startDUTIDTimer:@"1"];
							}
						}
					}
				}
			}
			if(![UIWinManage isCheckDUTID:2] && ![UIWinManage isCheckDUTID:3]) //1 notest, 2 notest, 3 notest
			{
				if(gBlinkFlag[2][0])
				{
					if(canDetectFixture1 && [UIWinManage getUnit:3])
					{
						if((![[textTestResult3 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:3]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:3 :tableView11 :textItemTime3 :textTotalTime3:textTestResult3:NO ScanData:nil] ;
								[self startDUTIDTimer:@"3"];
							}
						}
					}
				}
				else if(gBlinkFlag[1][0])
				{
					//[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar21"] indexBox:1 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:2])
					{
						if((![[textTestResult2 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:2]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:2 :tableView11 :textItemTime2 :textTotalTime2:textTestResult2:NO ScanData:nil] ;
								[self startDUTIDTimer:@"2"];
							}
						}
					}
				}
				else
				{
					if(canDetectFixture1 && ![UIWinManage getUnit:1])
						[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:0 indexBar:0];
					if(canDetectFixture1 && [UIWinManage getUnit:1] && gBlinkFlag[0][0])
					{
						if((![[textTestResult1 stringValue] isEqualToString:@"on going"]) && ([self CheckWrongUnitInFixture1:1]))
						{
							if(canTestFixture1)
							{
								canTestFixture1=FALSE;
								canDetectFixture1=FALSE;
								[UIWinManage startTest:1 :tableView11 :textItemTime1 :textTotalTime1:textTestResult1:NO ScanData:nil] ;
								[self startDUTIDTimer:@"1"];
							}
						}
					}
				}
			}
		}
	}
	return ;
}

-(bool)CheckWrongUnitInFixture1:(int)threadID
{
	//return true;
	BOOL bRet=false;
	//SCRID:92 Henry modified on 2011-03-22 for ProxCal 
	NSString *getSN=nil;
	NSString *strSpec=@"Serial:";
	NSString *tmpSN = [UIWinManage getUnitSN:threadID :@"sn\n"];
	NSRange rangTmp=[tmpSN rangeOfString:strSpec];
	getSN=[tmpSN substringFromIndex:(rangTmp.location+rangTmp.length)];
	if([tmpSN length]>12) 
		getSN=[getSN substringWithRange:NSMakeRange(0, 13)];
	//SCRID:92 end
	
	//getSN = [[NSMutableString alloc] initWithString:tmp] ;
	if(getSN!=nil || [getSN length]>0)
	{

		if(1==threadID)
		{
			//if(([getSN rangeOfString:Thread1SN].length>0) || ([getSN rangeOfString:Thread2SN].length>0) || ([getSN rangeOfString:Thread3SN].length>0))
			if([getSN isEqualToString:Thread1SN] || [getSN isEqualToString:Thread2SN] || [getSN isEqualToString:Thread3SN])
			{
				//[self setWrongUnitBgdColor:dictKeyDefined];
				NSLog(@"\n ");
				NSLog(@"\n###@@@ UUT-win11 sedCmdReturnSN11=%@",getSN);
				NSLog(@"\n###@@@ UUT-win11 Thread1SN=%@",Thread1SN);
				NSLog(@"\n###@@@ UUT-win11 Thread2SN=%@",Thread2SN);
				NSLog(@"\n###@@@ UUT-win11 Thread3SN=%@",Thread3SN);
				
				NSString *tmpPattern = [UIWinManage getUnitSN:threadID :@"pattern 8\n"];
				[tmpPattern release];
				
				
				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];

				if(bMessageFlag==false)
				{
					bMessageFlag=true;
					NSThread *threadShowMessage = [[NSThread alloc] initWithTarget:self selector:@selector(showUIAlertBox) object:nil];
					[threadShowMessage start];
					[threadShowMessage release];
				}

				bRet= false;
			}
			else
			{
				Thread1SN = getSN;
				
				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];

				bRet= true;
			}
		}
		else if(2==threadID)
		{
			if([getSN isEqualToString:Thread1SN] || [getSN isEqualToString:Thread2SN] || [getSN isEqualToString:Thread3SN])
			{
				//[self setWrongUnitBgdColor:dictKeyDefined];
				NSLog(@"\n ");
				NSLog(@"\n###@@@ UUT-win11 sedCmdReturnSN11=%@",getSN);
				NSLog(@"\n###@@@ UUT-win11 Thread1SN=%@",Thread1SN);
				NSLog(@"\n###@@@ UUT-win11 Thread2SN=%@",Thread2SN);
				NSLog(@"\n###@@@ UUT-win11 Thread3SN=%@",Thread3SN);
				
				NSString *tmpPattern = [UIWinManage getUnitSN:threadID :@"pattern 8\n"];
				[tmpPattern release];
				

				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];

				if(bMessageFlag==false)
				{
					bMessageFlag=true;
					NSThread *threadShowMessage = [[NSThread alloc] initWithTarget:self selector:@selector(showUIAlertBox) object:nil];
					[threadShowMessage start];
					[threadShowMessage release];
				}

				bRet= false;
			}
			else
			{
				Thread2SN = getSN;
				
				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];

				bRet= true;
			}
		}
		else if(3==threadID)
		{
			if([getSN isEqualToString:Thread1SN] || [getSN isEqualToString:Thread2SN] || [getSN isEqualToString:Thread3SN])
			{
				//[self setWrongUnitBgdColor:dictKeyDefined];
				NSLog(@"\n ");
				NSLog(@"\n###@@@ UUT-win11 sedCmdReturnSN11=%@",getSN);
				NSLog(@"\n###@@@ UUT-win11 Thread1SN=%@",Thread1SN);
				NSLog(@"\n###@@@ UUT-win11 Thread2SN=%@",Thread2SN);
				NSLog(@"\n###@@@ UUT-win11 Thread3SN=%@",Thread3SN);
				
				NSString *tmpPattern = [UIWinManage getUnitSN:threadID :@"pattern 8\n"];
				[tmpPattern release];
				
				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];
				if(bMessageFlag==false)
				{
					bMessageFlag=true;
					NSThread *threadShowMessage = [[NSThread alloc] initWithTarget:self selector:@selector(showUIAlertBox) object:nil];
					[threadShowMessage start];
					[threadShowMessage release];
				}
				
				bRet= false;
			}
			else
			{
				Thread3SN = getSN;
				
				if(![Thread1SN isEqualToString:@"default"])
					[Thread1SN retain];
				if(![Thread2SN isEqualToString:@"default"])
					[Thread2SN retain];
				if(![Thread3SN isEqualToString:@"default"])
					[Thread3SN retain];

				bRet= true;
			}
		}
	}
	else
	{
		bRet= false;
	}
	
	return bRet;
}

-(int)numberOfRowsInTableView:(NSTableView*)tableView
{
	if((tableViewArray[0]==tableView))
		return mUIItems[0];
	else if((tableViewArray[1]==tableView))
		return (mUIItems[0]+mUIItems[1]);
	else if((tableViewArray[2]==tableView))
		return (mUIItems[0]+mUIItems[1]+mUIItems[2]);

	return [UIWinManage getTestItemTotal ] ;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	
	NSInteger resultRowIdx =1;
	NSString *strResult = [UIWinManage getTestItemUIResult:resultRowIdx :rowIndex];
	if(strResult == nil)
		strResult = @"TEST RESULT";
	//	NSInteger tagId = [aTableView tag];
	//	NSLog(@"tag ID = %d",tagId);
	
	if(initTableFlag == FALSE)
	{
		if(tableViewForCnt ==nil)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[0]=aTableView;
			if(tableViewArray[0])
				[UICommon addObjectToUIComm:tableViewArray[0] Key:@"tableView11"];
		}
		else if(tableViewForCnt!= aTableView)
		{
			tableViewCnt++;
			tableViewForCnt =aTableView;
			tableViewArray[tableViewCnt-1]=aTableView;
			
			if(tableViewArray[1])
				[UICommon addObjectToUIComm:tableViewArray[1] Key:@"tableView12"];
			if(tableViewArray[2])
				[UICommon addObjectToUIComm:tableViewArray[2] Key:@"tableView13"];
		}
		
		if(tableViewCnt >= 3)
			initTableFlag = TRUE;
		else
			return nil ;
		return nil ;
	}
	

	if(tableViewArray[0]==aTableView)
	{
		rowIndex = rowIndex;
		if(rowIndex>=mUIItems[0])
			return nil;

		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:testResult[0] :rowIndex];
	}
	else if(tableViewArray[1]==aTableView)
	{
		if(rowIndex>=(mUIItems[0]+mUIItems[1]))
			return nil;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:testResult[1] :rowIndex];
	}
	else if(tableViewArray[2]==aTableView)
	{
		if(rowIndex>=(mUIItems[0]+mUIItems[1]+mUIItems[2]))
			return nil;
		
		if ([[aTableColumn identifier] isEqual:@"testItem"])
			return [UIWinManage getTestItemUIName:rowIndex] ;
		else
			return [UIWinManage getTestItemUIResult:testResult[2] :rowIndex];
	}
	
	return nil;
}
-(void)showInitLog
{
	NSString *temStr=[ToolFun getAPPInitLog] ;
	if (temStr!=nil) 
	{	
		NSRunAlertPanel(@"init log info", temStr, @"prompt", nil, nil) ;
	}
}

-(IBAction)btnSimulator_Click:(id)sender
{	
	//close all port
	if ([UIWinManage CloseAllPort])
		[NSBundle loadNibNamed:@"MainMenu" owner:NSApp];
	else
		NSRunAlertPanel(@"WARNNING", @"UART Port on going,please pause all unit", @"prompt", nil, nil) ;
}

-(void)initUIScanLabelAndText
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	[textLabel1 setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel1Copy setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
	[textLabel2 setTextColor:[NSColor blackColor]];
	[textLabel1 setFont:[NSFont userFontOfSize:28]] ;
	[textLabel1Copy setFont:[NSFont userFontOfSize:28]] ;
	
	NSArray *arrayUnitInfo = [UIWinManage getTotalUnitInfo];
	if(arrayUnitInfo ==nil)
		NSLog(@"Load Unit Infor error");
	
	//load apple logo image and foxconn logo image
	NSBundle * mainBundle =[ NSBundle mainBundle];
	//NSString * pathOfAppleLogo = [mainBundle pathForResource:@"appleLogo" ofType:@"jpg"];
	//NSImage * imageAppleLogo= [[NSImage alloc] initWithContentsOfFile:pathOfAppleLogo];
	NSString *pathOfBgdPic =[mainBundle pathForResource:@"LightHouse01" ofType:@"jpg"];
	NSImage *imageBgd = [[NSImage alloc] initWithContentsOfFile:pathOfBgdPic];
	[imageViewBgd setFrame:NSMakeRect(HEADVIEWBGD.x, HEADVIEWBGD.y, HEADVIEWBGD.width, HEADVIEWBGD.height)];
	[imageViewBgd setImageFrameStyle:NSImageFrameNone];
	//[imageViewOfAppleLogo setImage:imageAppleLogo];
	[imageViewBgd setImage:imageBgd];
	//[imageAppleLogo release];
	[imageBgd release];
}
-(IBAction)setFixtureID:(id)sender
{
	NSLog(@"Set OK ") ;
}

-(IBAction)CallEditScriptUI:(id)sender 
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	NSApplication *nsApp = [NSApplication sharedApplication] ;
	[NSBundle loadNibNamed:@"SelectScriptAppconfig" owner:nsApp];
	[nsApp run] ;
	[pool release] ;
}

//henry add for set status bar and box satatus 2011-01-25
-(void)setBoxBgdColor:(NSNotification*)notification
{
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	canTestFixture3=TRUE;
	canDetectFixture3=TRUE;
	NSString *strTmp = [ScriptParse getValueFromSummary:@"SwitchUI"] ;
	if([strTmp isEqualToString:@"UI3Prox"])
	{
		if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
		{
			Thread1SN=@"default";

			enableTotalTimer[0] = FALSE;
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:0 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar13"] Key:@"gray" objType:@"statusBar"];
			if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
			{
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
				NSThread * checkUnitPlugOutFromSlot3 = [[NSThread alloc] initWithTarget:self selector:@selector(checkUnitPlugOut:) object:nil] ;
				[checkUnitPlugOutFromSlot3 start] ;
				[checkUnitPlugOutFromSlot3 release];
			}
			else 
			{
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
		else if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR2"])
		{
			Thread2SN=@"default";

			enableTotalTimer[1] = FALSE;
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar23"] indexBox:1 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar23"] Key:@"gray" objType:@"statusBar"];
			if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
				NSThread * checkUnitPlugOutFromSlot3 = [[NSThread alloc] initWithTarget:self selector:@selector(checkUnitPlugOut:) object:nil] ;
				[checkUnitPlugOutFromSlot3 start] ;
				[checkUnitPlugOutFromSlot3 release];
			}
			else 
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
		else if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR3"])
		{
			Thread3SN=@"default";

			enableTotalTimer[2] = FALSE;
			
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar33"] indexBox:2 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar33"] Key:@"gray" objType:@"statusBar"];
			
			if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
				NSThread * checkUnitPlugOutFromSlot3 = [[NSThread alloc] initWithTarget:self selector:@selector(checkUnitPlugOut:) object:nil] ;
				[checkUnitPlugOutFromSlot3 start] ;
				[checkUnitPlugOutFromSlot3 release];
			}
			else 
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
	}
	else 
	{
		if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR1"])
		{
			enableTotalTimer[0] = FALSE;
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:0 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar13"] Key:@"gray" objType:@"statusBar"];
			
			[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTestResult2 setTextColor:[NSColor blackColor]] ;
			[textTestResult3 setTextColor:[NSColor blackColor]] ;
			
			if([[textTestResult1 stringValue] isEqualToString:@"Fail"])
			{
				
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult1 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
		else if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR2"])
		{
			enableTotalTimer[1] = FALSE;
			
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar23"] indexBox:1 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar23"] Key:@"gray" objType:@"statusBar"];
			
			[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTestResult1 setTextColor:[NSColor blackColor]] ;
			[textTestResult3 setTextColor:[NSColor blackColor]] ;
			
			if([[textTestResult2 stringValue] isEqualToString:@"Fail"])
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult2 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
		else if([[notification name] isEqualToString:@"SET_UI_BGD_COLOR3"])
		{
			enableTotalTimer[2] = FALSE;
			
			[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar33"] indexBox:2 indexBar:2];
			[UICommon setObjectBgdColor:[UICommon getObjectFromUIComm:@"statusBar33"] Key:@"gray" objType:@"statusBar"];
			
			[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTestResult1 setTextColor:[NSColor blackColor]] ;
			[textTestResult2 setTextColor:[NSColor blackColor]] ;
			
			if([[textTestResult3 stringValue] isEqualToString:@"Fail"])
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:0.7]];
			}
			else if([[textTestResult3 stringValue] isEqualToString:@"PASS"])
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:0.35 green:1.0 blue:0.6 alpha:0.5]];
			}
			else 
			{
				[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			}
		}
	}
	[pool release];
	
}

-(void)showUnitSN:(NSNotification*)notification ;
{
	NSDictionary *temDic= [notification userInfo];
	NSString *strSN = [temDic objectForKey:@"UnitSN"];
	
	if([[notification name] isEqualToString:@"SHOW_UNIT_SN1"])
	{
		[textLabelSN1 setStringValue:strSN];
	}
	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN2"])
	{
		[textLabelSN2 setStringValue:strSN];
	}
	else if([[notification name] isEqualToString:@"SHOW_UNIT_SN3"])
	{
		[textLabelSN3 setStringValue:strSN];
	}
}


//henry added 2011-02-08
-(void)testTimerRefreshProxCal:(NSDictionary*)dictParam //Refresh timer
{
	
	if (dictParam==nil)
		return ;
	
	NSTextField *totalTime =[dictParam objectForKey:@"TotalCycleTimeField"] ;
	NSTextField *itemTime = [dictParam objectForKey:@"ItemGroupTimeField"] ;
	if (totalTime ==nil ||
		itemTime ==nil
		)
		return ;
	NSString *strDutID = [dictParam objectForKey:@"ThreadID"];
	if (strDutID==nil)
		return ;
	NSInteger iDutID= [strDutID intValue];

	NSString *strStatus = [dictParam objectForKey:@"RefreshTimeStatus"];
	if (strStatus==nil)
		return ;
	
	while (TRUE)
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		
		float fTotalCycletime = [[totalTime stringValue] floatValue] ;
		fTotalCycletime +=0.1 ;
		[totalTime setStringValue:[NSString stringWithFormat:@"%5.2f",fTotalCycletime]] ;
		[totalTime display]; 
		
		
		if(enableRefreshTimer[iDutID-1])
		{
			float fitemtime = [[itemTime stringValue] floatValue] ;
			fitemtime +=0.1 ;
			[itemTime setStringValue:[NSString stringWithFormat:@"%5.2f",fitemtime]] ;
			[itemTime display]; 
		}
		
		usleep(100000) ;
		[pool release] ;
		
		if(enableTotalTimer[iDutID-1]==FALSE)
			break;
		
	}
}

-(void)startDUTIDTimer:(NSString*)dutID
{
	NSMutableDictionary *mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
	
	if([dutID isEqualToString:@"1"])
	{
		[mutdictTmp setObject:textItemGroupTime1 forKey:@"ItemGroupTimeField"]  ;
		[mutdictTmp setObject:textTotalCycleTime1 forKey:@"TotalCycleTimeField"]  ;
		[mutdictTmp setObject:dutID forKey:@"ThreadID"] ;
		[textTotalCycleTime1 setStringValue:@"0.0"];
		[textItemGroupTime1 setStringValue:@"0.0"] ;
		enableRefreshTimer[0] =TRUE;
		enableTotalTimer[0] = TRUE;
	}
	else if([dutID isEqualToString:@"2"])
	{
		[mutdictTmp setObject:textItemGroupTime2 forKey:@"ItemGroupTimeField"]  ;
		[mutdictTmp setObject:textTotalCycleTime2 forKey:@"TotalCycleTimeField"]  ;
		[mutdictTmp setObject:dutID forKey:@"ThreadID"] ;
		[textTotalCycleTime2 setStringValue:@"0.0"];
		[textItemGroupTime2 setStringValue:@"0.0"] ;
		enableRefreshTimer[1] =TRUE;
		enableTotalTimer[1] = TRUE;
	}
	else if([dutID isEqualToString:@"3"])
	{
		[mutdictTmp setObject:textItemGroupTime3 forKey:@"ItemGroupTimeField"]  ;
		[mutdictTmp setObject:textTotalCycleTime3 forKey:@"TotalCycleTimeField"]  ;
		[mutdictTmp setObject:dutID forKey:@"ThreadID"] ;
		[textTotalCycleTime3 setStringValue:@"0.0"];
		[textItemGroupTime3 setStringValue:@"0.0"] ;
		enableRefreshTimer[2] =TRUE;
		enableTotalTimer[2] = TRUE;
	}
	
	[mutdictTmp setObject:@"start" forKey:@"RefreshTimeStatus"] ;
	
	//create a THread to refresh time
	NSThread * threadRefTime = [[[NSThread alloc] initWithTarget:self selector:@selector(testTimerRefreshProxCal:) object:mutdictTmp] autorelease] ;
	
	[threadRefTime start] ;
	//[threadRefTime release];
}

-(void)changeTestItemTimerStatus:(NSNotification*)notification ;
{
//		NSDictionary *temDic= [notification userInfo];
//		NSString *strDutID = [temDic objectForKey:@"DUTID"];
	
	if([[notification name] isEqualToString:@"UUT1_TIMER_RESTART"])
	{
		[textItemGroupTime1 setStringValue:@"0.0"] ;
		enableRefreshTimer[0] =TRUE;
	}
	else if([[notification name] isEqualToString:@"UUT2_TIMER_RESTART"])
	{
		[textItemGroupTime2 setStringValue:@"0.0"] ;
		enableRefreshTimer[1] =TRUE;
	}
	else if([[notification name] isEqualToString:@"UUT3_TIMER_RESTART"])
	{
		[textItemGroupTime3 setStringValue:@"0.0"] ;
		enableRefreshTimer[2] =TRUE;
	}
	else if([[notification name] isEqualToString:@"UUT1_TIMER_STOP"])
	{
		enableRefreshTimer[0] =FALSE;
	}
	else if([[notification name] isEqualToString:@"UUT2_TIMER_STOP"])
	{
		enableRefreshTimer[1] =FALSE;
	}
	else if([[notification name] isEqualToString:@"UUT3_TIMER_STOP"])
	{
		enableRefreshTimer[2] =FALSE;
	}
	
}

-(void)showMessageAndResetWindow:(NSString*)dutID  //added by henry 2011-02-09
{
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setAlertStyle:NSInformationalAlertStyle];
	
	NSString * mTitle = @"Reset the test status !" ;
	
	[alert setMessageText:@"Are you sure to Cancel ?"];
	[alert setInformativeText:mTitle];
	[alert addButtonWithTitle:@"OK"];
	[alert runModal];
	[alert release];	
}

-(void)resetAllTestStatus 
{
	for(NSInteger i=0;i<3;i++)
	{
		enableRefreshTimer[i] =TRUE;
		enableTotalTimer[i]=TRUE;
	}
	
	[textLabelSN1 setStringValue:@""];
	[textLabelSN2 setStringValue:@""];
	[textLabelSN3 setStringValue:@""];
	
	canDetectFixture1=TRUE;
	canDetectFixture2=TRUE;
	canDetectFixture3=TRUE;
	
	for(NSInteger i=0;i<3;i++)
	{
		for(NSInteger j=0;j<3;j++)
			gBlinkFlag[i][j]=FALSE;
	}
	
}
-(void)changeBoxViewPostion:(NSNotification*)notification ;
{
	NSDictionary *temDic= [notification userInfo];
	NSString *prePosition = [temDic objectForKey:@"PREPOSITION"];
	NSString *curPosition = [temDic objectForKey:@"CURPOSITION"];
	
	if([[notification name] isEqualToString:@"SET_UI_BOX_POSITION"])
	{
		[self changeBoxPosition:curPosition preDutID:prePosition];
	}
}

-(void)changeBoxPosition:(NSString*)dutID preDutID:(NSString*)preDUDid 
{
	NSPoint point1=NSMakePoint(BOXVIEW_POSITION_1.x, BOXVIEW_POSITION_1.y);
	NSPoint point2=NSMakePoint(BOXVIEW_POSITION_2.x, BOXVIEW_POSITION_2.y);
	NSPoint point3=NSMakePoint(BOXVIEW_POSITION_3.x, BOXVIEW_POSITION_3.y);
	
	if([dutID isEqualToString:@"1"])
	{
		if([preDUDid isEqualToString:@"2"])   //1,2
		{
			[textLabelSlotCfg2 setStringValue:@"Free Space"];
			[textLabelSlotCfg1 setStringValue:@"Edge Config"];
			[boxUnitView1 setFrameOrigin:point2]; 
			[boxUnitView2 setFrameOrigin:point1]; 
			[boxUnitView1 display];
			[boxUnitView2 display];
		}
		if([preDUDid isEqualToString:@"3"])  //1,3
		{
			[textLabelSlotCfg1 setStringValue:@"Bottom Config"];
			[textLabelSlotCfg3 setStringValue:@"Edge Config"];
			[boxUnitView1 setFrameOrigin:point3]; 
			[boxUnitView3 setFrameOrigin:point2]; 
			[boxUnitView1 display];
			[boxUnitView3 display];
			[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTotalCycleTime3 setStringValue:@"0.0"];
			[textItemGroupTime3 setStringValue:@"0.0"];
			[textTestResult3 setStringValue:@""];
			[textLabelSN3 setStringValue:@""];
			[boxUnitView3 display];
			[textTotalCycleTime3 display];
			[textItemGroupTime3 display];
			[textTestResult3 display];
			
		}
	}
	if([dutID isEqualToString:@"2"])
	{
		if([preDUDid isEqualToString:@"3"])   //2,3
		{
			[textLabelSlotCfg2 setStringValue:@"Edge Config"];
			[textLabelSlotCfg3 setStringValue:@"Free Space"];
			[boxUnitView2 setFrameOrigin:point2]; 
			[boxUnitView3 setFrameOrigin:point1]; 
			[boxUnitView2 display];
			[boxUnitView3 display];
		}
		if([preDUDid isEqualToString:@"1"])   //2,1
		{
			[textLabelSlotCfg2 setStringValue:@"Bottom Config"];
			[textLabelSlotCfg1 setStringValue:@"Edge Config"];
			[boxUnitView2 setFrameOrigin:point3]; 
			[boxUnitView1 setFrameOrigin:point2]; 
			
			[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTotalCycleTime1 setStringValue:@"0.0"];
			[textItemGroupTime1 setStringValue:@"0.0"];
			[textTestResult1 setStringValue:@""];
			[textLabelSN1 setStringValue:@""];
			[boxUnitView1 display];
			[textTotalCycleTime1 display];
			[textItemGroupTime1 display];
			[textTestResult1 display];
			[textLabelSN1 display];
			[boxUnitView2 display];
			[boxUnitView1 display];
		}
	}
	if([dutID isEqualToString:@"3"])
	{
		if([preDUDid isEqualToString:@"1"])   //3,1
		{
			[textLabelSlotCfg3 setStringValue:@"Edge Config"];
			[textLabelSlotCfg1 setStringValue:@"Free Space"];
			[boxUnitView3 setFrameOrigin:point2]; 
			[boxUnitView1 setFrameOrigin:point1]; 
			[boxUnitView3 display];
			[boxUnitView1 display];
		}
		if([preDUDid isEqualToString:@"2"])  //3,2
		{
			[textLabelSlotCfg3 setStringValue:@"Bottom Config"];
			[textLabelSlotCfg2 setStringValue:@"Edge Config"];
			[boxUnitView3 setFrameOrigin:point3]; 
			[boxUnitView2 setFrameOrigin:point2]; 
			[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[textTotalCycleTime2 setStringValue:@"0.0"];
			[textItemGroupTime2 setStringValue:@"0.0"];
			[textTestResult2 setStringValue:@""];
			[textLabelSN2 setStringValue:@""];
			[boxUnitView2 display];
			[textTotalCycleTime2 display];
			[textItemGroupTime2 display];
			[textTestResult2 display];
			[boxUnitView3 display];
			[boxUnitView2 display];
		}
	}
}

-(void)checkUnitPlugOut:(NSString*)device   //added by henry 2011-02-15
{
	NSString *strTmp = [NSString stringWithFormat:@"%d",UnitStatus_FOR_DIAGS];
	while (TRUE) 
	{
		if(canDetectFixture3&&(![TestItemParse CheckUnitExist:@"UART11":strTmp]))
		{
			[boxUnitView1 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[boxUnitView2 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			[boxUnitView3 setFillColor:[NSColor colorWithCalibratedRed:1.0 green:1.0 blue:1.0 alpha:0.5]];
			
			NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
			[boxUnitView1 display];
			[boxUnitView2 display];
			[boxUnitView3 display];
			[pool release];
			break;
		}
		usleep(500000); //500ms
	}
}

//2011-02-22 add to show messagebox
-(void)showUIAlertBox
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	
	NSInteger totalUI=3;
	NSInteger indexOfWindow=1;
	[UIAlert setInitPosition:totalUI index:indexOfWindow] ;
	UIAlert *alert = [[UIAlert alloc] init];
	[alert showWindow:self];
	[alert updatPosition:totalUI index:indexOfWindow];
	[alert setMessageText:@"Error! Free Space"];
	[alert setInformativeText:@"Wrong Unit!"];
	[alert addButtonWithTitle:@"OK"];
	[alert runModal];
	[alert release];
	
	[pool release];
	bMessageFlag=false;
	/*
	 NSAlert *alert = [[NSAlert alloc] init];
	 [alert setAlertStyle:NSInformationalAlertStyle];
	 [alert setMessageText:@"Error! win31"];
	 [alert setInformativeText:@"Wrong Unit!"];
	 [alert addButtonWithTitle:@"OK"];
	 [alert runModal];
	 [alert release];
	 */
	
}

@end
