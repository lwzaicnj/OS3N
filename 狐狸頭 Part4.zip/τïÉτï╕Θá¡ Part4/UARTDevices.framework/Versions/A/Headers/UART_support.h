#ifndef crimson_acoustic__uart_support__hh__
#define crimson_acoustic__uart_support__hh__


#include <UARTDevices/UARTManager.h>


#ifdef __cplusplus

#include <vector>
#include <string>

extern UART_t *OpenUART(std::string const &path, unsigned speed);
extern std::vector<std::string> GetUARTS();

#endif


#endif
