//
//  AppDelegate.m
//  dispatch
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (IBAction)test:(id)sender {
    
    dispatch_queue_t concurrentQueue = dispatch_queue_create("test.name", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(concurrentQueue, ^{
        while (1) {
            int loop_times = _time.intValue;
            if (loop_times<=0) {
                break;
            }
            NSLog(@"inside the async");
            loop_times--;
            sleep(1);
            [_time setIntValue:loop_times];
        }
        
    });
    NSLog(@"outside the async");//先執行，異步
}
@end
