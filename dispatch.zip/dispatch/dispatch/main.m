//
//  main.m
//  dispatch
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
