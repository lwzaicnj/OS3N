//
//  AppDelegate.h
//  dispatch
//
//  Created by apple on 2/11/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (weak) IBOutlet NSTextField *time;
- (IBAction)test:(id)sender;

@end

