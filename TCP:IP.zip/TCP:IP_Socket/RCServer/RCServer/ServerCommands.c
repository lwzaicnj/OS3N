//
//  ServerCommands.c
//  RCServer
//
//  Created by Jen-Wei Peng on 1/6/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//

#include <stdlib.h>
#include <ctype.h>
#include "ServerCommands.h"
#include "HWTE_RobotDriverLib.h"
#include "HWTE_RobotProtoDefs.h"
#include "IDHelpers.h"

#define MAXCONNECTIONS          4
#define PORT                    28100               //Service port
#define BUFFER_SIZE             256
#define COMMAND_COUNT           22
#define CMESSAGE_ID_MAX         32767
#define CMESSAGE_ID_MIN         1
#define NMESSAGE_ID_MAX         65535
#define NMESSAGE_ID_MIN         32768
#define ERROR_SIZE              20
#define PENDING                 1
#define STATUS_PARAMETER_COUNT  16

void *sendMoreStatusNotifications(void *);

uint16_t NMessageID = 32768;
static bool sleepFlag = true;

int CreateTCPServerSocket()
{
    int sock;
    struct sockaddr_in servAddr;
    
    /* Create socket for incoming connections */
    // 在所有数据传送前必须使用connect()来建立连线状态
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    {
        perror("Fail to create socket for incoming connections.");
        exit(1);
    }
    
    /* Construct local address structure */
    bzero(&servAddr, sizeof(servAddr));             /* Zero out structure */
    servAddr.sin_family = AF_INET;                  /* Internet addeess family */
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);   /* Any incoming interface */
    servAddr.sin_port = htons(PORT);                /* Local port */

    /* Bind to the local address */
    if (bind(sock, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0)
    {
        perror("Fail to bind to the local address.");
        exit(1);
    }
    
    /* Mark the socket so it will listen for incoming connections */
    if (listen(sock, MAXCONNECTIONS) < 0)
    {
        perror("Fail to listen for incoming connections.");
        exit(1);
    }
    
    printf("Server is listening...\n");
    
    return sock;
}

int AcceptTCPConnection(int servSock)
{
    int clientSock;                 /* Socket descriptor for client */
    struct sockaddr_in clientAddr;  /* Client address */
    socklen_t clientLen;            /* Length of client address data structure */
    
    /* Wait for a client to connect */
    if ((clientSock = accept(servSock, (struct sockaddr *) &clientAddr, &clientLen)) < 0)
    {
        perror("Faile to accept client connection.");
        exit(1);
    }
    
    printf("Handling client %s\n", inet_ntoa(clientAddr.sin_addr));
    
    return clientSock;
}

void HandleTransferRequest(int clientSocket, bool isHomed,
                           HWTE_RobotMotorState_t motorState,
                           HWTE_RobotMode_t robotMode,
                           HWTE_RobotTransferRequest_t *requestPtr,
                           QUEUE *commandQueue, struct ListenerThreadArgs **robotPtr)
{
    /* Generate jobstarted notification */
    char *notificationMessage, *notificationError;
    bool sendNotification = false;
    int sendMoreNotifications = -1;
    
    if ( !(notificationMessage = calloc(BUFFER_SIZE + 1, sizeof(char))) )
    {
        perror("Fail to calloc memory for message in HandleTransferRequest.");
        exit(1);
    }
    
    if ( !(notificationError = calloc(ERROR_SIZE + 1, sizeof(char))) )
    {
        perror("Fail to calloc memory for error in HandleTransferRequest.");
        exit(1);
    }
    
    /* 
     * HWTE_RobotCommandCreatejob = 0,
     * HWTE_RobotCommandStatus = 1,
     * HWTE_RobotCommandStatusStartOrStop = 2,
     * HWTE_RobotCommandGetCurrentPosition = 3,
     * HWTE_RobotCommandListjobs = 4,
     * HWTE_RobotCommandRemote = 5,
     * HWTE_RobotCommandMotorOn = 6,
     * HWTE_RobotCommandMotorOff = 7,
     * HWTE_RobotCommandHome = 8
     */
    switch (requestPtr->command) {
        //        HWTE_RobotCommandCreatejob = 0,
        //        HWTE_RobotCommandStatus = 1,
        //        HWTE_RobotCommandStatusStart = 2,
        //        HWTE_RobotCommandStatusStop = 3,
        //        HWTE_RobotCommandGetCurrentPosition = 4,
        //        HWTE_RobotCommandListjobs = 5,
        //        HWTE_RobotCommandRemote = 6,
        //        HWTE_RobotCommandMotorOn = 7,
        //        HWTE_RobotCommandMotorOff = 8,
        //        HWTE_RobotCommandHome = 9,
        //        HWTE_RobotCommandSetMaxSpeed = 10,
        //        HWTE_RobotCommandGetMaxSpeed = 11,
        //        HWTE_RobotCommandGrip = 12,
        //        HWTE_RobotCommandUnGrip = 13,
        //        HWTE_RobotCommandLocal = 14
        case 0:
        {
            /* HWTE_RobotCommandCreatejob */
            sendNotification = true;
            sendMoreNotifications = 4;
            CreateNotification(&notificationMessage, 3, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 1:
        {
            break;
        }
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
        {
            /* HWTE_RobotCommandListjobs:
             * Never reached - because listjobs is won't be saved into queue, thus the worker won't pick up the request. */
            sendNotification = true;
            sendMoreNotifications = -1;
            break;
        }
        case 6:
        {
            /* HWTE_RobotCommandMode: Don't need to send any notification for command remote/local */
            (*robotPtr)->robotMode = 1;
            sendNotification = false;
            sendMoreNotifications = -1;
            break;
        }
        case 7:
        {
            /* HWTE_RobotCommandMotorOn: NmessageID,on,errorCode */
            (*robotPtr)->motorState = 1;
            sendNotification = true;
            sendMoreNotifications = -1;
            CreateNotification(&notificationMessage, 5, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 8:
        {
            /* HWTE_RobotCommandMotorOff: NmessageID,off,errorCode */
            (*robotPtr)->motorState = 0;
            sendNotification = true;
            sendMoreNotifications = -1;
            CreateNotification(&notificationMessage, 6, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 9:
        {
            /* HWTE_RobotCommandHome */
            (*robotPtr)->isHomed = true;
            sendNotification = true;
            sendMoreNotifications = 8;
            CreateNotification(&notificationMessage, 7, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 12:
        {
            /* grip */
            (*robotPtr)->gripper1Status = HWTE_RobotGripper1Gripped;
            sendNotification = true;
            sendMoreNotifications = -1;
            sleep(5);
            CreateNotification(&notificationMessage, 10, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 13:
        {
            /* ungrip */
            (*robotPtr)->gripper1Status = HWTE_RobotGripper1Idle;
            sendNotification = true;
            sendMoreNotifications = false;
            sleep(5);
            CreateNotification(&notificationMessage, 11, requestPtr->jobID, &notificationError, requestPtr);
            break;
        }
        case 14:
        {
            /* HWTE_RobotCommandMode: Don't need to send any notification for command remote/local */
            (*robotPtr)->robotMode = 0;
            sendNotification = false;
            sendMoreNotifications = -1;
            break;
        }
        default:
            break;
    }
    
    if (sendNotification) {
        while (!sleepFlag);
        /* Send notification to the client */
        if (send(clientSocket, notificationMessage, strlen(notificationMessage) + 1, 0) < 0)
        {
            perror("Fail to send ");
            exit(1);
        }
        
        if (sendMoreNotifications >= 0) {
            delay(5);
            
            /* Flash strins */
            memset(notificationMessage, '\0', BUFFER_SIZE + 1);
            memset(notificationError, '\0', ERROR_SIZE + 1);
            
            CreateNotification(&notificationMessage, sendMoreNotifications, requestPtr->jobID, &notificationError, requestPtr);
            
            /* Send notification to the client */
            if (send(clientSocket, notificationMessage, strlen(notificationMessage) + 1, 0) < 0)
            {
                perror("Fail to send ");
                exit(1);
            }
        }
    }
    
    free(notificationMessage);
    free(notificationError);
}

void StatusNotification(struct ListenerThreadArgs *robotPtr, char *message, HWTE_RobotTransferRequest_t *requestPtr, int *period)
{
    char *tempStr = (char *) calloc(BUFFER_SIZE + 1, sizeof(char));
    char *stringToBeSent = (char *) calloc(BUFFER_SIZE + 1, sizeof(char));
    char *token;
    int order = 0;
    int walker = 1;
    int parameterArray[STATUS_PARAMETER_COUNT][2] = {-1};
    
    memset(tempStr, '\0', strlen(message));
    strncpy(tempStr, message, strlen(message));
    token = strtok(tempStr, ",");
    memset(stringToBeSent, '\0', BUFFER_SIZE + 1);

    if  (requestPtr->command == 1) {
        char *CMessage_id = calloc(strlen(token) + 1, sizeof(char));
        strncpy(CMessage_id, token, strlen(token));
        strncat(stringToBeSent, CMessage_id, strlen(CMessage_id));
        
        free(CMessage_id);
    }
    else if (requestPtr->command == 2) {
        int nMessage_len = snprintf(NULL, 0, "%d", NMessageID);
        char *NMessage_id = calloc(nMessage_len + 1, sizeof(char));
        
        if (NMessageID >= NMESSAGE_ID_MAX)
            NMessageID = NMESSAGE_ID_MIN;
        
        snprintf(NMessage_id, nMessage_len + 1, "%d", NMessageID);
        strncat(stringToBeSent, NMessage_id, nMessage_len);
        
        free(NMessage_id);
    }
    
    /* Initialize all parameterArray elements to -1 */
    for (int i = 0; i < STATUS_PARAMETER_COUNT; i++) {
        for (int j = 0; j < 2; j++){
            parameterArray[i][j] = -1;
        }
    }

    token = strtok(NULL, ",");

    if (strcmp(token, "status") == 0 || strcmp(token, "statusstart") == 0) {
        /* Set period */
        if (strcmp(token, "statusstart") == 0) {
            token = strtok(NULL, ",");
            *period = atoi(token);
        }
        else
            period = 0;
        
        /* The while loop continues if theere are more parameters
         * Token is updated at the end of the while loop */
        while (token != NULL) {
            if (strcmp(token, "mode") == 0 || strcmp(token, "mode\r\n") == 0) {
                order++;
                parameterArray[0][0] = robotPtr->robotMode;
                parameterArray[0][1] = order;
            }
            else if (strcmp(token, "state") == 0 || strcmp(token, "state\r\n") == 0) {
                order++;
                parameterArray[1][0] = (uint16_t)robotPtr->robotState;
                parameterArray[1][1] = order;
            }
            else if (strcmp(token, "homed") == 0 || strcmp(token, "homed\r\n") == 0) {
                order++;
                parameterArray[2][0] = robotPtr->isHomed;
                parameterArray[2][1] = order;
            }
            else if (strcmp(token, "currentjobid") == 0 || strcmp(token, "currentjobid\r\n") == 0) {
                order++;
                parameterArray[3][0] = requestPtr->jobID;
                parameterArray[3][1] = order;
            }
            else if (strcmp(token, "motorstatus") == 0 || strcmp(token, "motorstatus\r\n") == 0) {
                order++;
                parameterArray[4][0] = robotPtr->motorState;
                parameterArray[4][1] = order;
            }
            else if (strcmp(token, "jobsinqueue") == 0 || strcmp(token, "jobsinqueue\r\n") == 0) {
                order++;
                parameterArray[5][0] = queueCount(robotPtr->commandQueue);
                parameterArray[5][1] = order;
            }
            else if (strcmp(token, "estop") == 0 || strcmp(token, "estop\r\n") == 0) {
                order++;
                parameterArray[6][0] = robotPtr->robotEStopStatus;
                parameterArray[6][1] = order;
            }
            else if (strcmp(token, "totallocationids") == 0 || strcmp(token, "totallocationids\r\n") == 0) {
                order++;
                parameterArray[7][0] = robotPtr->totalLocationIDs;
                parameterArray[7][1] = order;
            }
            else if (strcmp(token, "taughtlocations") == 0 || strcmp(token, "taughtlocations\r\n") == 0) {
                order++;
                parameterArray[8][0] = robotPtr->taughtLocations;
                parameterArray[8][1] = order;
            }
            else if (strcmp(token, "activeconnections") == 0 || strcmp(token, "activeconnections\r\n") == 0) {
                order++;
                parameterArray[9][0] = robotPtr->activeConnections;
                parameterArray[9][1] = order;
            }
            else if (strcmp(token, "gripper1") == 0 || strcmp(token, "gripper1\r\n") == 0) {
                order++;
                parameterArray[10][0] = robotPtr->gripper1Status;
                parameterArray[10][1] = order;
            }
            else if (strcmp(token, "vacuumgen1") == 0 || strcmp(token, "vacuumgen1\r\n") == 0) {
                order++;
                parameterArray[11][0] = robotPtr->vacuumGen1Status;
                parameterArray[11][1] = order;
            }
            else if (strcmp(token, "vacuumsensor1") == 0 || strcmp(token, "vacuumsensor1\r\n") == 0) {
                order++;
                parameterArray[12][0] = robotPtr->vacuumSensor1Status;
                parameterArray[12][1] = order;
            }
            else if (strcmp(token, "currentlocation") == 0 || strcmp(token, "currentlocation\r\n") == 0) {
                order++;
                parameterArray[13][0] = 0;
                parameterArray[13][1] = order;
            }
            else if (strcmp(token, "maxgrippers") == 0 || strcmp(token, "maxgrippers\r\n") == 0) {
                order++;
                parameterArray[14][0] = 1;
                parameterArray[14][1] = order;
            }
            else if (strcmp(token, "maxjobs") == 0 || strcmp(token, "maxjobs\r\n") == 0) {
                order++;
                parameterArray[15][0] = 4;
                parameterArray[15][1] = order;
            }
            
            memset(token, '\0', strlen(token));
            /* Get next parameter */
            token = strtok(NULL, ",");
        }
    }
    
    if (requestPtr->command == 1) {
        strncat(stringToBeSent, ",statusonce", 11);
    }
    else if (requestPtr->command == 2) {
        strncat(stringToBeSent, ",statusperiodic", 15);
    }
    
    /* Strcat parameter value based on order */
    while (walker <= order) {
        for (int i = 0; i < STATUS_PARAMETER_COUNT; i++) {
            if (parameterArray[i][1] == walker) {
                int parameterValue_len = snprintf(NULL, 0, "%d", parameterArray[i][0]);
                char *parameterValue = calloc(parameterValue_len + 1, sizeof(char));
                
                snprintf(parameterValue, parameterValue_len + 1, "%d", parameterArray[i][0]);
                strncat(stringToBeSent, ",", 1);
                strncat(stringToBeSent, parameterValue, parameterValue_len + 1);
                
                walker++;
                free(parameterValue);
                break;
            }
        }
    }
    
    strncat(stringToBeSent, "\r\n", 4);
    
    /* Send ack to the client, then rest buffer*/
    if (send(robotPtr->clientSock, stringToBeSent, strlen(stringToBeSent) + 1, 0) < 0)
    {
        perror("Fail to send status ack.");
        exit(1);
    }
    
    if (requestPtr->command == 2) {
        NMessageID++;
    }
    
    free(tempStr);
    free(stringToBeSent);
    return;
}

void ListjobsNotification(int clientSocket, char **message, QUEUE *commandQueue)
{
    QUEUE_NODE *current = commandQueue->front;

    while (current != NULL) {
        if (NMessageID >= NMESSAGE_ID_MAX)
            NMessageID = NMESSAGE_ID_MIN;
        
        int nMessage_len = snprintf(NULL, 0, "%d", NMessageID);
        char *nMessage_id = calloc(nMessage_len + 1, sizeof(char));
        int jobID_len = snprintf(NULL, 0, "%d", current->requestPtr->jobID);
        char *jobIDstr = calloc(jobID_len + 1, sizeof(char));
        int queuePosition_len = snprintf(NULL, 0, "%d", current->requestPtr->queuePosition);
        char *queuePosition = calloc(queuePosition_len + 1, sizeof(char));
        int numberOfJobs_len = snprintf(NULL, 0, "%d", current->requestPtr->jobsEnqueued);
        char *numberOfJobs = calloc(numberOfJobs_len + 1, sizeof(char));
        int sourceLocationID_len = snprintf(NULL, 0, "%d", current->requestPtr->source);
        char *sourceLocationID = calloc(sourceLocationID_len + 1, sizeof(char));
        int destinationLocation_len = snprintf(NULL, 0, "%d", current->requestPtr->source);
        char *destinationLocationID = calloc(destinationLocation_len + 1, sizeof(char));
        
        memset(*message, '\0', BUFFER_SIZE + 1);
        snprintf(nMessage_id, nMessage_len + 1, "%d", NMessageID);
        strncpy(*message, nMessage_id, strlen(nMessage_id));
        strncat(*message, ",", 1);
        snprintf(jobIDstr, jobID_len + 1, "%d", current->requestPtr->jobID);
        strncat(*message, jobIDstr, jobID_len);
        strncat(*message, ",", 1);
        snprintf(queuePosition, queuePosition_len + 1, "%d", current->requestPtr->queuePosition);
        strncat(*message, queuePosition, queuePosition_len);
        strncat(*message, ",", 1);
        snprintf(numberOfJobs, numberOfJobs_len + 1, "%d", current->requestPtr->jobsEnqueued);
        strncat(*message, numberOfJobs, numberOfJobs_len);
        
        switch (current->requestPtr->type) {
            case 0:
            {   /* HWTE_RobotJobTypePick = 0 */
                strncat(*message, ",pick,", 6);
                break;
            }
            case 1:
            {   /* HWTE_RobotJobTypePlace = 1 */
                strncat(*message, ",place,", 7);
                break;
            }
            case 2:
            {   /* HWTE_RobotJobTypePickPlace = 2 */
                strncat(*message, ",pp,", 4);
                break;
            }
            case 3:
            {   /* HWTE_RobotJobTypeGoto = 3 */
                strncat(*message, ",go,", 4);
                break;
            }
            default:
                break;
        }
        
        snprintf(sourceLocationID, sourceLocationID_len + 1, "%d", current->requestPtr->source);
        strncat(*message, sourceLocationID, sourceLocationID_len);
        strncat(*message, ",", 1);
        snprintf(destinationLocationID, destinationLocation_len + 1, "%d", current->requestPtr->destination);
        strncat(*message, destinationLocationID, destinationLocation_len);
        strncat(*message, ",", 1);
        
        if (current->requestPtr->status == 0)
            strncat(*message, "executing\r\n", 13);
        else
            strncat(*message, "pending\r\n", 11);
    
        free(jobIDstr);
        free(queuePosition);
        free(numberOfJobs);
        free(sourceLocationID);
        free(destinationLocationID);
        
        current = current->next;
        NMessageID++;
        
        /* Send notification to the client */
        if (send(clientSocket, *message, strlen(*message) + 1, 0) < 0)
        {
            perror("Fail to send ");
            exit(1);
        }
    }
}

void CreateNotification(char **message,
                        HWTE_RobotNotificationType_t notificationType,
                        HWTE_RobotJobID_t jobID, char **error, HWTE_RobotTransferRequest_t *requestPtr)
{
    if (NMessageID >= NMESSAGE_ID_MAX)
        NMessageID = NMESSAGE_ID_MIN;
    
    int nMessageID_len = snprintf(NULL, 0, "%d", NMessageID);
    char *nMessage_id = calloc(nMessageID_len + 1, sizeof(char));
    int jobID_len = snprintf(NULL, 0, "%d", jobID);
    char *jobIDstr = calloc(jobID_len + 1, sizeof(char));

    snprintf(jobIDstr, jobID_len + 1, "%d", jobID);
    snprintf(nMessage_id, nMessageID_len + 1, "%d", NMessageID);
    strncpy(*message, nMessage_id, strlen(nMessage_id));
    
    /*
     HWTE_RobotNotifyStatusMessage = 0,
     HWTE_RobotNotifyModeChangeRemote = 1,
     HWTE_RobotNotifyModeChangeLocal = 2,
     HWTE_RobotNotifyJobStarted = 3,
     HWTE_RobotNotifyJobCompleted = 4,
     HWTE_RobotNotifyMotoson = 5,
     HWTE_RobotNotifyMotorsOff = 6,
     HWTE_RobotNotifyHomeStarted = 7,
     HWTE_RobotNotifyHomeCompleted =8,
     HWTE_RobotNotifyListjobs = 9,
     HWTE_RobotNotifyGripCompleted = 10,
     HWTE_RobotNotifyUnGripCompleted = 11,
     HWTE_RobotNotifySetLocationCompleted = 12
     */
    switch (notificationType)
    {
        case 0:
            break;
        case 1:
        case 2:
            /* 1 - romote
             * 2 - local
             * No notification needed for mode changing */
            break;
        case 3:
        {
            strncat(*message, ",jobstarted,", 12);
            strncat(*message, jobIDstr, jobID_len);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 4:
        {
            strncat(*message, ",jobcompleted,", 14);
            strncat(*message, jobIDstr, jobID_len);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 5:
        {
            /* motors on: NmessageID,on,errorCode */
            strncat(*message, ",on", 3);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 6:
        {
            /* motors off: NmessageID,off,errorCode */
            strncat(*message, ",off", 4);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 7:
        {
            /* home: NmessageID,homestarted,errorcode */
            strncat(*message, ",homestarted", 12);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 8:
        {
            /* home: NmessageID,homecompleted,errorcode */
            strncat(*message, ",homecompleted", 14);
            strncat(*error, ",0", 2);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 9:
        {
            break;
        }
        case 10:
        {
            int gripperID_len = snprintf(NULL, 0, "%d", requestPtr->gripperID);
            char *gripperIDstr = calloc(jobID_len + 1, sizeof(char));
            snprintf(gripperIDstr, gripperID_len + 1, "%d", requestPtr->gripperID);
            
            strncpy(*message, nMessage_id, strlen(nMessage_id));
            strncat(*message, ",gripcompleted,", 15);
            strncat(*message, gripperIDstr, strlen(gripperIDstr));
            strncat(*error, ",", 1);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 11:
        {
            int gripperID_len = snprintf(NULL, 0, "%d", requestPtr->gripperID);
            char *gripperIDstr = calloc(jobID_len + 1, sizeof(char));
            snprintf(gripperIDstr, gripperID_len + 1, "%d", requestPtr->gripperID);
            
            strncpy(*message, nMessage_id, strlen(nMessage_id));
            strncat(*message, ",ungripcompleted,", 17);
            strncat(*message, gripperIDstr, strlen(gripperIDstr));
            strncat(*error, ",", 1);
            strncat(*message, *error, strlen(*error));
            break;
        }
        case 12:
        {
            strncpy(*message, nMessage_id, strlen(nMessage_id));
            strncat(*message, ",setlocationcompleted", 22);
            strncat(*message, *error, strlen(*error));
            break;
        }
        default:
            break;
    }
    
    strcat(*message, "\r\n");
    NMessageID++;
    free(jobIDstr);
    free(nMessage_id);
    return;
}

/*bool CreateRequest(char *message, HWTE_RobotTransferRequest_t **requestPtr, char **error,
                   bool *isHomed, HWTE_RobotMotorState_t *motorState, HWTE_RobotMode_t *robotMode)*/
bool CreateRequest(char *message, HWTE_RobotTransferRequest_t **requestPtr, char **error,
                   struct ListenerThreadArgs **robotPtr)
{
    char *requestBuffer = (char *) calloc(strlen(message) + 1, sizeof(char));
    char *token = NULL;
    int  content = 0;
    bool keepFillingRequest = true;
    bool isValidRequest = true;
    
    strncpy(requestBuffer, message, strlen(message));
    token = strtok(requestBuffer, ",");
    (*requestPtr)->gripperID = -1;
    (*requestPtr)->locationID = 0;
    
    while (token != NULL && content < 5 && keepFillingRequest)
    {
        /*
         HWTE_RobotCommandCreatejob = 0,
         HWTE_RobotCommandStatus = 1,
         HWTE_RobotCommandStatusStart = 2,
         HWTE_RobotCommandStatusStop = 3,
         HWTE_RobotCommandGetCurrentPosition = 4,
         HWTE_RobotCommandListjobs = 5,
         HWTE_RobotCommandRemote = 6,
         HWTE_RobotCommandMotorOn = 7,
         HWTE_RobotCommandMotorOff = 8,
         HWTE_RobotCommandHome = 9,
         HWTE_RobotCommandSetMaxSpeed = 10,
         HWTE_RobotCommandGetMaxSpeed = 11,
         HWTE_RobotCommandGrip = 12,
         HWTE_RobotCommandUnGrip = 13,
         HWTE_RobotCommandLocal = 14,
         HWTE_RobotCommandGetLocationConfig = 15,
         HWTE_RobotCommandSetLocationConfig = 16,
         HWTE_RobotCommandAbort = 17,
         HWTE_RobotCommandResume = 18,
         HWTE_RobotCommandReportConfig = 19,
         HWTE_RobotCommandInitialize = 20,
         HWTE_RobotCommandReset = 21
        */
        switch(content)
        {
            case 0:
            {
                /* Validate CMessageID */
                if (!(ValidateCMessageID(token, error)))
                {
                    keepFillingRequest = false;
                    isValidRequest = false;
                }
                break;
            } /* End of case 0 */
            case 1:
            {
                /* Validate Command */
                if (!(ValidateCommand(token, error)))
                {
                    keepFillingRequest = false;
                    isValidRequest = false;
                    break;
                }
                
                /* Movement type, source, and destination don't need to be filled if it is not a createjob command */
                if (!(strcmp(token, "createjob") == 0))
                {
                    keepFillingRequest = false;
                    (*requestPtr)->source = 0;
                    (*requestPtr)->destination = 0;
                    (*requestPtr)->type = -1;
                    

                    if ((strcmp(token, "remote\r\n") == 0)) {
                        (*requestPtr)->command = 6;
                    }
                    else if ((strcmp(token, "local\r\n") == 0)) {
                        (*requestPtr)->command = 14;
                    }
                    else if ((strcmp(token, "motorson\r\n") == 0)) {
                        (*requestPtr)->command = 7;
                    }
                    else if ((strcmp(token, "motorsoff\r\n") == 0)) {
                        (*requestPtr)->command = 8;
                    }
                    else if ((strcmp(token, "home\r\n") == 0))
                    {
                        (*requestPtr)->command = 9;
                    }
                    else if ((strcmp(token, "listjobs\r\n") == 0))
                    {
                        /* No information required for listjobs command */
                        (*requestPtr)->command = 5;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "status") == 0))
                    {
                        /* No information required for status command */
                        (*requestPtr)->command = 1;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "statusstart") == 0))
                    {
                        /* No information required for status command */
                        (*requestPtr)->command = 2;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "statusstop\r\n") == 0))
                    {
                        /* No information required for status command */
                        (*requestPtr)->command = 3;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "getcurrentposition\r\n") == 0))
                    {
                        /* No information required for status command */
                        (*requestPtr)->command = 4;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "setmaxspeed") == 0))
                    {
                        (*requestPtr)->command = 10;
                        keepFillingRequest = true;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "getmaxspeed\r\n") == 0))
                    {
                        (*requestPtr)->command = 11;
                        keepFillingRequest = false;
                        isValidRequest = false; 
                    }
                    else if ((strcmp(token, "grip") == 0))
                    {
                        (*requestPtr)->command = 12;
                        keepFillingRequest = false;
                        isValidRequest = true;
                    }
                    else if ((strcmp(token, "ungrip") == 0))
                    {
                        (*requestPtr)->command = 13;
                        keepFillingRequest = false;
                        isValidRequest = true;
                    }
                    else if ((strcmp(token, "getlocationconfig") == 0))
                    {
                        (*requestPtr)->command = 15;
                        keepFillingRequest = true;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "setlocationconfig") == 0))
                    {
                        (*requestPtr)->command = 16;
                        keepFillingRequest = true;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "abort\r\n") == 0))
                    {
                        (*requestPtr)->command = 17;
                        keepFillingRequest = false;
                        isValidRequest = false;
                        sleepFlag = false;
                    }
                    else if ((strcmp(token, "resume\r\n") == 0))
                    {
                        (*requestPtr)->command = 18;
                        keepFillingRequest = false;
                        isValidRequest = false;
                        sleepFlag = true;
                    }
                    else if ((strcmp(token, "reportconfig") == 0))
                    {
                        (*requestPtr)->command = 19;
                        keepFillingRequest = true;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "initialize\r\n") == 0))
                    {
                        (*requestPtr)->command = 20;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                    else if ((strcmp(token, "reset\r\n") == 0))
                    {
                        (*requestPtr)->command = 21;
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                }
                else {
                    (*requestPtr)->command = 0;
                }
                break;
            } /* End of case 1 */
            case 2:
            {
                if ((*requestPtr)->command == 0) {
                    /* Validate movement type */
                    int enumValue = ToRobotMovementType(token, error);
                    
                    if (enumValue >= 0)
                    {
                        /* Movement type validation passed */
                        //if (*robotMode == 0)
                        if ((*robotPtr)->robotMode == 0)
                        {
                            /* Validate robot mode */
                            strncpy(*error, ",-8", 3);
                            keepFillingRequest = false;
                            isValidRequest = false;
                        }
                        //else if (*motorState == 0)
                        else if ((*robotPtr)->motorState == 0)
                        {
                            /* Validate motor state */
                            strncpy(*error, ",-15", 4);
                            keepFillingRequest = false;
                            isValidRequest = false;
                        }
                        //else if (*isHomed == false)
                        else if ((*robotPtr)->isHomed == false)
                        {
                            /* Validate if robot is homed */
                            strncpy(*error, ",-9", 3);
                            keepFillingRequest = false;
                            isValidRequest = false;
                        }
                        else
                        {
                            /* Robot is in remote mode, homed, and motors are on */
                            (*requestPtr)->type = enumValue;
                        }
                    }
                    else
                    {
                        keepFillingRequest = false;
                        isValidRequest = false;
                    }
                }
                else if ((*requestPtr)->command == 10) {
                    /* setmaxspeed - set maxSpeedValue */
                    (*robotPtr)->maxSpeedValue = atoi(token);
                }
                else if ((*requestPtr)->command == 12 || (*requestPtr)->command == 13) {
                    /* grip - set gripper ID */
                    (*requestPtr)->gripperID = atoi(token);
                }
                else if ((*requestPtr)->command == 15 || (*requestPtr)->command == 16) {
                    /* getlocationconfig or setlocationconfig */
                    (*requestPtr)->locationID = atoi(token);
                }
                else if ((*requestPtr)->command == 19) {
                    /* reportconfig */
                    if (strcmp(token, "ManufacturerID\r\n") == 0)
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestManufacturerID;
                    else if (strcmp(token, "ConfigurationID\r\n") == 0)
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestConfigurationID;
                    else if (strcmp(token, "NumberOfLocations\r\n") == 0)
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestNumberOfLocations;
                    else if (strcmp(token, "ProtocolVersion\r\n") == 0)
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestProtocolVersion;
                    else if (strcmp(token, "RCSoftwareVersion\r\n") == 0)
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestRCSoftwareVersion;
                    else
                    {
                        (*requestPtr)->requestedConfiguration = HWTE_RobotRequestNoConfiguration;
                        strncpy(*error, ",-31", 4);
                    }
                }
                break;
            }
            case 3:
                if ((*requestPtr)->command == 16) {
                    if ((*robotPtr)->robotMode == HWTE_RobotModeRemote && (*robotPtr)->robotState == HWTE_RobotStateIdle) {
                        char *ret = strchr(message, '"');
                        ((*robotPtr)->locationConfig[(*requestPtr)->locationID])->stringData = calloc(strlen(ret), sizeof(char));
                        strncpy((*robotPtr)->locationConfig[(*requestPtr)->locationID]->stringDataFormat, "\"X,Y,Z,A,B,C,L1,L2,FLG1,FLG2\"", strlen("\"X,Y,Z,A,B,C,L1,L2,FLG1,FLG2\""));
                        strncpy((*robotPtr)->locationConfig[(*requestPtr)->locationID]->stringData, ret, strlen(ret) - 2);
                        strncpy((*robotPtr)->currentPosition, ret, strlen(ret));
                    }
                    else {
                        /* Robot is not in remote mode, and not idle, should post errors */
                        strncpy(*error, ",-15", 4);
                    }
                }
                else {
                    (*requestPtr)->source = atoi(token);
                }
                break;
            case 4:
                (*requestPtr)->destination = atoi(token);
                break;
            default:
                break;
        } /* End switch */
        
        token = strtok(NULL, ",");
        content++;
    } /* End while */
    
    free(requestBuffer);
    return isValidRequest;
}

void CreateAck(char **socket_buffer, HWTE_RobotTransferRequest_t *requestPtr, char *error, int queueCount, struct ListenerThreadArgs **robotPtr)
{
    /* Tokenize buffer, using delimeter "," */
    char *token = strtok(*socket_buffer, ",");

    token = strtok(NULL, ",");
    
    /* If there is no error, set the error code to 0 */
    if (strcmp(error, "") == 0) {
        strncpy(error, ",0", 2);
    }
    else {
        /* Case: invalid CMessage ID, set CMessage ID to 0 */
        if((strcmp(error, ",-1") == 0)) {
            memset(*socket_buffer, '\0', sizeof(BUFFER_SIZE));
            *socket_buffer[0] = '0';
        }
    }
    
    /*
     HWTE_RobotCommandCreatejob = 0,
     HWTE_RobotCommandStatus = 1,
     HWTE_RobotCommandStatusStart = 2,
     HWTE_RobotCommandStatusStop = 3,
     HWTE_RobotCommandGetCurrentPosition = 4,
     HWTE_RobotCommandListjobs = 5,
     HWTE_RobotCommandRemote = 6,
     HWTE_RobotCommandMotorOn = 7,
     HWTE_RobotCommandMotorOff = 8,
     HWTE_RobotCommandHome = 9,
     HWTE_RobotCommandSetMaxSpeed = 10,
     HWTE_RobotCommandGetMaxSpeed = 11,
     HWTE_RobotCommandGrip = 12,
     HWTE_RobotCommandUnGrip = 13,
     HWTE_RobotCommandLocal = 14,
     HWTE_RobotCommandGetLocationConfig = 15,
     HWTE_RobotCommandSetLocationConfig = 16,
     HWTE_RobotCommandAbort = 17,
     HWTE_RobotCommandResume = 18,
     HWTE_RobotCommandReportConfig = 19,
     HWTE_RobotCommandInitialize = 20,
     HWTE_RobotCommandReset = 21
     */
    
    /* If Command is listjobs, the ack should be:  
     * CMessageID,jobinqueue,numberOfJobsInQueue */
    if (requestPtr->command == 5) {
        /* Convert queueCount to string */
        int queueCount_len = snprintf(NULL, 0, "%d", queueCount);
        char *queueCountStr = (char *) calloc(queueCount_len + 1, sizeof(char) );
        
        strncat(*socket_buffer, ",jobsinqueue,", 13);
        sprintf(queueCountStr, "%d", queueCount);
        strncat(*socket_buffer, queueCountStr, strlen(queueCountStr));
        
        free(queueCountStr);
    }
    else {
        if (requestPtr->command ==  2 || requestPtr->command == 3) {
            /* statusstart or statusstop */
            strncat(*socket_buffer, ",ack", 4);
        }
        else if (requestPtr->command == 11) {
            /* getmaxspeed */
            int maxSpeed_len = snprintf(NULL, 0, "%d", (*robotPtr)->maxSpeedValue);
            char *maxSpeedStr = (char *) calloc(maxSpeed_len + 1, sizeof(char) );
            
            sprintf(maxSpeedStr, "%d", (*robotPtr)->maxSpeedValue);
            strncat(*socket_buffer, ",maxspeed,", 10);
            strncat(*socket_buffer, maxSpeedStr, strlen(maxSpeedStr));
        }
        else if (requestPtr->command == 8 || requestPtr->command == 7 || requestPtr->command == 12 || requestPtr->command == 13 ||
                 requestPtr->command == 10 || requestPtr->command == 14 || requestPtr->command == 6 || requestPtr->command == 9 ||
                 requestPtr->command == 16 || requestPtr->command == 17 || requestPtr->command == 18 || requestPtr->command == 20 ||
                 requestPtr->command == 21) {
            /* motorson, motorsoff, grip, ungrip, setmaxspeed, local, remote, setlocationconfig */
            strncat(*socket_buffer, ",ack", 4);
            strncat(*socket_buffer, error, strlen(error));
        }
        else if (requestPtr->command == 4) {
            /* motorson, motorsoff, grip, ungrip, setmaxspeed, local, remote, setlocationconfig */
            strncat(*socket_buffer, ",currentposition,", 17);
            strncat(*socket_buffer, (*robotPtr)->currentPosition, strlen((*robotPtr)->currentPosition));
        }
        else if (requestPtr->command == 15) {
            /* getlocationconfig */
            int locationID_len = snprintf(NULL, 0, "%d", requestPtr->locationID);
            char *locationIDStr = (char *) calloc(locationID_len + 1, sizeof(char) );
            char *stringDataFormat = (*robotPtr)->locationConfig[requestPtr->locationID]->stringDataFormat;
            char *stringData = (*robotPtr)->locationConfig[requestPtr->locationID]->stringData;
            snprintf(locationIDStr, locationID_len + 1, "%d", requestPtr->locationID);
            
            strncat(*socket_buffer, ",", 1);
            strncat(*socket_buffer, locationIDStr, strlen(locationIDStr));
            strncat(*socket_buffer, ",taught,", 8);
            strncat(*socket_buffer, stringDataFormat, strlen(stringDataFormat));
            strncat(*socket_buffer, ",", 1);
            strncat(*socket_buffer, stringData, strlen(stringData));
        }
        else if (requestPtr->command == 19) {
            /* reportconfig */
            switch (requestPtr->requestedConfiguration) {
                case HWTE_RobotRequestConfigurationID:
                {
                    strncat(*socket_buffer, ",", 1);
                    strncat(*socket_buffer, "ConfigurationID,", 16);
                    strcat(*socket_buffer, (*robotPtr)->robotConfiguration->ConfigurationID);
                    break;
                }
                case HWTE_RobotRequestManufacturerID:
                {
                    strncat(*socket_buffer, ",", 1);
                    strncat(*socket_buffer, "ManufacturerID,", 15);
                    strcat(*socket_buffer, (*robotPtr)->robotConfiguration->ManufacturerID);
                    break;
                }
                case HWTE_RobotRequestNumberOfLocations:
                {
                    strncat(*socket_buffer, ",", 1);
                    strncat(*socket_buffer, "NumberOfLocations,", 18);
                    strcat(*socket_buffer, (*robotPtr)->robotConfiguration->NumberOfLocations);
                    break;
                }
                case HWTE_RobotRequestProtocolVersion:
                {
                    strncat(*socket_buffer, ",", 1);
                    strncat(*socket_buffer, "ProtocolVersion,", 16);
                    strcat(*socket_buffer, (*robotPtr)->robotConfiguration->ProtocolVersion);
                    break;
                }
                case HWTE_RobotRequestRCSoftwareVersion:
                {
                    strncat(*socket_buffer, ",", 1);
                    strncat(*socket_buffer, "RCSoftwareVersion,", 18);
                    strcat(*socket_buffer, (*robotPtr)->robotConfiguration->RCSoftwareVersion);
                    break;
                }
                case HWTE_RobotRequestNoConfiguration:
                default:
                    /* invalid parameter value, send an ack to show the error code */
                    strncat(*socket_buffer, ",ack", 4);
                    strcat(*socket_buffer, error);
                    break;
            }
        }
        else {
            /* Convert jobID to string */
            int jobID_len = snprintf(NULL, 0, "%d", requestPtr->jobID);
            char *jobIDStr = (char *) calloc(jobID_len + 1, sizeof(char) );
            strncat(*socket_buffer, ",ack,", 5);
            sprintf(jobIDStr, "%d", requestPtr->jobID);
            strncat(*socket_buffer, jobIDStr, strlen(jobIDStr));
            strncat(*socket_buffer, error, strlen(error));
            
            free(jobIDStr);
        }
    }

    strncat(*socket_buffer, "\r\n", 4);
    
    return;
}

void CreateAndSendAlert(int clientSocket, char *errorCode) {
    if (NMessageID >= NMESSAGE_ID_MAX)
        NMessageID = NMESSAGE_ID_MIN;
    
    int nMessage_len = snprintf(NULL, 0, "%d", NMessageID);
    char *nMessage_id = calloc(nMessage_len + 1, sizeof(char));
    char *message = calloc(BUFFER_SIZE, sizeof(char));
    
    snprintf(nMessage_id, nMessage_len + 1, "%d", NMessageID);
    strncpy(message, nMessage_id, strlen(nMessage_id));
    strncat(message, ",alert,", 7);
    strncat(message, errorCode, strlen(errorCode));
    strncat(message, "\r\n", 4);
    
    if (send(clientSocket, message, strlen(message) + 1, 0) < 0)
    {
        perror("Fail to send ");
        exit(1);
    }
    
    NMessageID++;
    
    free(message);
    free(nMessage_id);
}

bool ValidateCMessageID(char *token, char **error)
{
    bool isCMessageIDValid = false;
    int cMessageID = atoi(token);
    
    if (cMessageID >= CMESSAGE_ID_MIN && cMessageID <= CMESSAGE_ID_MAX)
        isCMessageIDValid = true;
    else
        strncpy(*error, ",-1", 3);
        
    return isCMessageIDValid;
}

int ToRobotMovementType(char *token, char **error)
{
    int enumValue = -1;
    
    if ((strcmp(token, "pick") == 0))
        enumValue = 0;
    else if ((strcmp(token, "place") == 0))
        enumValue = 1;
    else if ((strcmp(token, "pp") == 0))
        enumValue = 2;
    else if ((strcmp(token, "HWTE_RobotJobTypeGoto") == 0))
        enumValue = 3;
    else
    {
        strncpy(*error, ",-4", 3);
    }
    
    return enumValue;
}

bool ValidateCommand(char *token, char **error)
{
    char *validCommand[] = {"createjob", "status", "statusstart", "statusstop\r\n", "listjobs\r\n",
        "initialize\r\n", "abort\r\n", "resume\r\n","reset\r\n", "motorson\r\n", "motorsoff\r\n", "local\r\n",
        "remote\r\n", "grip", "ungrip", "home\r\n", "setmaxspeed", "getmaxspeed\r\n", "reportconfig",
        "getlocationconfig", "setlocationconfig", "getcurrentposition\r\n"};
    int isCommandValid = false;
    
    for (int i=0; i<COMMAND_COUNT; i++)
    {
        if ((strcmp(token, validCommand[i]) == 0))
        {
            isCommandValid = true;
            break;
        }
    }
    
    if(!isCommandValid)
        strncpy(*error, ",-2", 3);
    
    return isCommandValid;
}

void delay(int sec)
{
    bool   finish    = false;
    time_t timeCount = 0;
    
    while(!finish)
    {
        while ( (timeCount < (sec * 1000000)) && sleepFlag)
        {
            usleep(1000);
            timeCount = timeCount + 1000;
        }
        if((!(timeCount < (sec * 1000000))) && sleepFlag)
            finish = true;
    }
    return;
}