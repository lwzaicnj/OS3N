//
//  main.c
//  RCServer
//
//  Created by Jenwei Peng on 12/13/13.
//  Copyright (c) 2013 Jenwei Peng. All rights reserved.
//

#include "ServerCommands.h"
#include "pthread.h"
#include "commandQueue.h"
#include "IDHelpers.h"
#define EXECUTING   0
#define PENDING     1
#define ERROR_SIZE  20

void *sendMoreStatusNotifications (void *statusNotificationArgs);

int currentActiveConnections = 0;

int main(int argc, const char * argv[])
{
    int serverSock;                                 /* Server socket descriptor                 */
    int clientSock;                                 /* Client socket descriptor                 */
    pthread_t listenerThreadID, workerThreadID;     /* Thread ID from pthread_create()          */
    struct ListenerThreadArgs *listenerThreadArgs;  /* Pointer to argument structure for thread */
    
    /* Create TCP server socket */
    serverSock = CreateTCPServerSocket();
    
    for(;;)
    {
        clientSock = AcceptTCPConnection(serverSock);
        
        /* Create separate memory for listener thread argument */
        if ((listenerThreadArgs = (struct ListenerThreadArgs *) malloc(sizeof(struct ListenerThreadArgs))) == NULL)
        {
            perror("Fail to malloc memory for listenerThreadArgs.\n");
            exit(1);
        }
        else
        {
            listenerThreadArgs->clientSock = clientSock;
            listenerThreadArgs->commandQueue = createQueue();
            listenerThreadArgs->motorState = 0;             /* 0: off               */
            listenerThreadArgs->robotMode = 0;              /* 0: local             */
            listenerThreadArgs->isHomed = false;            /* false: not home      */
            listenerThreadArgs->eStop = false;
            listenerThreadArgs->robotState = 0;             /* 0: initializing      */
            listenerThreadArgs->robotEStopStatus = 0;       /* 0: eStop not pressed */
            listenerThreadArgs->totalLocationIDs = 0;
            listenerThreadArgs->taughtLocations = 0;
            listenerThreadArgs->activeConnections = currentActiveConnections + 1;
            listenerThreadArgs->gripper1Status = 0;         /* 0: faulted           */
            listenerThreadArgs->vacuumGen1Status = 0;       /* 0: gripper1 off      */
            listenerThreadArgs->vacuumSensor1Status = 0;    /* 0: sensor1 off       */
            listenerThreadArgs->currentPosition = calloc(BUFFER_SIZE + 1, sizeof(char));
            strncpy(listenerThreadArgs->currentPosition, "0,0,0,0,0,0,0,0,0,0", 19);
            /* set the default robot configuration */
            HWTE_RobotConfiguration *defaultConfiguration = malloc(sizeof(HWTE_RobotConfiguration));
            defaultConfiguration->ManufacturerID      = "default";
            defaultConfiguration->ConfigurationID     = "default";
            defaultConfiguration->NumberOfLocations   = "default";
            defaultConfiguration->ProtocolVersion     = "default";
            defaultConfiguration->RCSoftwareVersion   = "default";
            listenerThreadArgs->robotConfiguration = defaultConfiguration;
            for (int i = 0; i < 200; i++) {
                listenerThreadArgs->locationConfig[i] = calloc(1, sizeof(struct LocationConfig));
            }
            /* Create listener thread */
            if (pthread_create(&listenerThreadID, NULL, ListenerThread, (void *) listenerThreadArgs) != 0)
            {
                perror("Fail to create listener thread.\n");
                exit(1);
            }
            
            /* Create worker thread */
            
            if (pthread_create(&workerThreadID, NULL, WorkerThread, (void *) listenerThreadArgs) != 0)
            {
                perror("Fail to create worker thread.\n");
                exit(1);
            }
            printf("worker thread %ld is running...\n", (long int) workerThreadID);
            
        }
    }
}

/* Worker thread */
void *WorkerThread(void *workerThreadArgs)
{
    QUEUE *commandQueue = ((struct ListenerThreadArgs *) workerThreadArgs)->commandQueue;
    struct ListenerThreadArgs *robotPtr = (struct ListenerThreadArgs *) workerThreadArgs;
    HWTE_RobotMode_t currentRobotMode = robotPtr->robotMode;
    HWTE_RobotMotorState_t currentMotorState = robotPtr->motorState;
    
    for(;;)
    {
        if (!(emptyQueue(commandQueue)))
        {
            HWTE_RobotTransferRequest_t *requestPtr;
            queueFront(commandQueue, &requestPtr);
            
            if (requestPtr->status == PENDING) {
                requestPtr->status = EXECUTING;
        
                printf("JOB ID: %d, JOB TYPE: %d, Source: %d\n", requestPtr->jobID, requestPtr->type, requestPtr->source);
                /* Set robot state to executing */
                ((struct ListenerThreadArgs *) workerThreadArgs)->robotState = 2;
                HandleTransferRequest(((struct ListenerThreadArgs *) workerThreadArgs)->clientSock,
                                      ((struct ListenerThreadArgs *) workerThreadArgs)->isHomed,
                                      ((struct ListenerThreadArgs *) workerThreadArgs)->motorState,
                                      ((struct ListenerThreadArgs *) workerThreadArgs)->robotMode,
                                      requestPtr,
                                      commandQueue, &robotPtr);
                dequeue(commandQueue, &(commandQueue->front->requestPtr));
                
                
                /* Update robot state */
                if (emptyQueue(((struct ListenerThreadArgs *) workerThreadArgs)->commandQueue))
                    ((struct ListenerThreadArgs *) workerThreadArgs)->robotState = 1;
            }
        }
        
        if (currentRobotMode != robotPtr->robotMode) {
            if (currentRobotMode == 0)
                CreateAndSendAlert(robotPtr->clientSock, "-14");
            else
                CreateAndSendAlert(robotPtr->clientSock, "-13");
            
            currentRobotMode = robotPtr->robotMode;
        }
        
        if (currentMotorState != robotPtr->motorState) {
            if (currentMotorState == 0)
                CreateAndSendAlert(robotPtr->clientSock, "-30");
            else
                CreateAndSendAlert(robotPtr->clientSock, "-17");
            
            currentMotorState = robotPtr->motorState;
        }
        
        if (robotPtr->eStop == true) {
            CreateAndSendAlert(robotPtr->clientSock, "-12");
        }
    }
    
    pthread_exit(NULL);
    
    return NULL;
}

/* Listener thread */
void *ListenerThread(void *listenerThreadArgs)
{
    struct ListenerThreadArgs *robotPtr = (struct ListenerThreadArgs *) listenerThreadArgs;

    HandleTCPClient(&robotPtr);
    
    pthread_exit(NULL);
    
    return NULL;
}

void HandleTCPClient(struct ListenerThreadArgs **robotPtr)
{
    char *message = (char *) calloc(BUFFER_SIZE + 1, sizeof(char));
    ssize_t receivedMessageSize = recv( (*robotPtr)->clientSock, message, BUFFER_SIZE, 0);
    QUEUE *commandQueue = (*robotPtr)->commandQueue;
    
    /* Receive message from client */
    if (receivedMessageSize < 0)
    {
        perror("Fail to receive message from client.");
        exit(1);
    }
    
    while(receivedMessageSize > 0)
    {
        HWTE_RobotTransferRequest_t *requestPtr;
        bool isValid = false;
        char *error  = (char *) calloc(ERROR_SIZE + 1, sizeof(char));
        
        if ( !(requestPtr = (HWTE_RobotTransferRequest_t *) calloc(1, sizeof(HWTE_RobotTransferRequest_t))) )
        {
            perror("Fail to calloc memory for requestPtr in HAndleTCPClient.");
            exit(1);
        }
        
        /* Update robot state:
         * If queue is empty, set robot state to idle 
         * otherwise, set robot state to executing */
        if (emptyQueue(commandQueue))
            (*robotPtr)->robotState = 1;
        else
            (*robotPtr)->robotState = 2;
        
        /* Analyze buffer, fill requestPtr, and enqueue the request */
        /* &((*robotPtr)->isHomed), &((*robotPtr)->motorState), &((*robotPtr)->robotMode) */
        isValid = CreateRequest(message, &requestPtr, &error, robotPtr);
        
        /* Add to the job queue if validations passed - a transfer request */
        if (isValid)
        {
            requestPtr->status = PENDING;
            requestPtr->jobID = GetJobID();
            requestPtr->jobsEnqueued = queueCount(commandQueue) + 1;
            requestPtr->queuePosition = queueCount(commandQueue);
            Enqueue(commandQueue, requestPtr);
            IncrementJobID();
            
            /* Modify variable message to create an ack */
            CreateAck(&message, requestPtr, error, queueCount(commandQueue), robotPtr);
            
            /* Echo ack to the  client */
            if (send((*robotPtr)->clientSock, message, strlen(message) + 1, 0) < 0)
            {
                perror("Fail to send ");
                exit(1);
            }
        }
        else {
            static bool keepSending = true;
            
            if (requestPtr->command == 1) {
                /* Command: status */
                StatusNotification(*robotPtr, message, requestPtr, 0);
            }
            else if (requestPtr->command == 2){
                /* Command: statusstart */
                struct StatusNotificationArgs *argPtr;
                
                if ((argPtr = (struct StatusNotificationArgs *) malloc(sizeof(struct StatusNotificationArgs))) == NULL)
                {
                    perror("Fail to malloc memory for statusNotificationArgs.\n");
                    exit(1);
                }
                else {
                    argPtr->requestPtr = &requestPtr;
                    argPtr->robotPtr = robotPtr;
                    argPtr->keepSending = &keepSending;
                    argPtr->message = calloc(strlen(message), sizeof(char));
                    strncpy(argPtr->message, message, strlen(message));
                }
                
                CreateAck(&message, requestPtr, error, queueCount(commandQueue), robotPtr);
                /* Echo ack to the  client */
                if (send((*robotPtr)->clientSock, message, strlen(message) + 1, 0) < 0)
                {
                    perror("Fail to send ");
                    exit(1);
                }
                
                memset(message, '\0', (BUFFER_SIZE + 1));
                
                pthread_t statusNotificationThreadID;
                
                if (pthread_create(&statusNotificationThreadID, NULL, sendMoreStatusNotifications, (void *)argPtr) != 0)
                {
                    perror("Fail to create listener thread.\n");
                    exit(1);
                }
            }
            else if (requestPtr->command == 3) {
                /* Command: statusstop */
                keepSending = false;
                
                CreateAck(&message, requestPtr, error, queueCount(commandQueue), robotPtr);
                /* Echo ack to the  client */
                if (send((*robotPtr)->clientSock, message, strlen(message) + 1, 0) < 0)
                {
                    perror("Fail to send ");
                    exit(1);
                }
            }
            else {
                /* Modify variable message to create an ack */
                CreateAck(&message, requestPtr, error, queueCount(commandQueue), robotPtr);
                
                /* Echo ack to the  client */
                if (send((*robotPtr)->clientSock, message, strlen(message) + 1, 0) < 0)
                {
                    perror("Fail to send ");
                    exit(1);
                }
                memset(message, '\0', (BUFFER_SIZE + 1));
                
                if (requestPtr->command == 20) {
                    destroyQueue((*robotPtr)->commandQueue);
                    /* command: initialize */
                    (*robotPtr)->commandQueue = createQueue();
                    (*robotPtr)->motorState = 0;             /* 0: off               */
                    (*robotPtr)->robotMode = 0;              /* 0: local             */
                    (*robotPtr)->isHomed = false;            /* false: not home      */
                    (*robotPtr)->eStop = false;
                    (*robotPtr)->robotState = 0;             /* 0: initializing      */
                    (*robotPtr)->robotEStopStatus = 0;       /* 0: eStop not pressed */
                    (*robotPtr)->totalLocationIDs = 0;
                    (*robotPtr)->taughtLocations = 0;
                    (*robotPtr)->activeConnections = currentActiveConnections + 1;
                    (*robotPtr)->gripper1Status = 0;         /* 0: faulted           */
                    (*robotPtr)->vacuumGen1Status = 0;       /* 0: gripper1 off      */
                    (*robotPtr)->vacuumSensor1Status = 0;    /* 0: sensor1 off       */
                    memset((*robotPtr)->currentPosition, '\0', (BUFFER_SIZE + 1));
                }
                
                if (requestPtr->command == 21) {
                    memset(error, '\0', (ERROR_SIZE + 1));
                }
                
                if (requestPtr->command == 4) {
                    /* command: listjobs */
                    ListjobsNotification((*robotPtr)->clientSock, &message, commandQueue);
                }
                
                if (requestPtr->command == 16) {
                    /* notification type 12: HWTE_RobotNotifySetLocationCompleted */
                    CreateNotification(&message, 12, requestPtr->jobID, &error, requestPtr);
                    
                    /* Echo ack to the  client */
                    if (send((*robotPtr)->clientSock, message, strlen(message) + 1, 0) < 0)
                    {
                        perror("Fail to send ");
                        exit(1);
                    }
                    memset(message, '\0', (BUFFER_SIZE + 1));
                }
            }
        }
        
        memset(message, '\0', (BUFFER_SIZE + 1));
        
        memset(message, '\0', (BUFFER_SIZE + 1));
        
        /* Check if there is more data to receive */
        if ((receivedMessageSize = recv((*robotPtr)->clientSock, message, BUFFER_SIZE, 0)) < 0)
        {
            perror("Fail to receive message from client.");
            exit(1);
        }
    }
    
    free(message);
    close((*robotPtr)->clientSock);
}

/* Function called by statusNotificationThreadID */
void *sendMoreStatusNotifications (void *statusNotificationArgs) {
    struct StatusNotificationArgs *argPtr = (struct StatusNotificationArgs *) statusNotificationArgs;
    struct ListenerThreadArgs *robotPtr;
    int period = 0;
    HWTE_RobotTransferRequest_t *requestPtr = *argPtr->requestPtr;;
    
    while (*(argPtr->keepSending)) {
        robotPtr = *(argPtr->robotPtr);

        StatusNotification(robotPtr, argPtr->message, requestPtr, &period);
        
        sleep(period);
    }
    
    return NULL;
}