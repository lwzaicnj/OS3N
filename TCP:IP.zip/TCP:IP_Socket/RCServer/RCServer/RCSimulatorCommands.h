//
//  RCSimulatorCommands.h
//  RCServer
//
//  Created by Jen-Wei Peng on 1/15/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//

#ifndef RCServer_RCSimulatorCommands_h
#define RCServer_RCSimulatorCommands_h

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "IDHelpers.h"
#include "HWTE_RobotDriverLib.h"



/*
 * Notification APIs
 *
 * Calling registerForNotification() with an interval of 0
 * and a repeat of 'false' executes a single immediate callback.
*/
HWTE_RobotResponse_t registerForNotification(HWTE_RobotHandle_t robot, HWTE_RobotNotificationType_t type, HWTE_RobotNotificationCallback_t cb,
                                             float interval, bool repeat, void* userInfo, HWTE_RobotTimerHandle_t *handle);
HWTE_RobotNotification_t CreateNotification(HWTE_RobotNotificationType_t type, HWTE_RobotHandle_t roboty, HWTE_RobotTimerHandle_t *handle, void *userInfo);

#endif
