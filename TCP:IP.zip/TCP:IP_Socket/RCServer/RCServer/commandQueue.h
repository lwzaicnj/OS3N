//
//  commandQueue.h
//  RCSimulator
//
//  Created by Jen-Wei Peng on 1/8/14.
//  Copyright (c) 2014 Jen-Wei Peng. All rights reserved.
//

#ifndef RCSimulator_commandQueue_h
#define RCSimulator_commandQueue_h
#define COMMAND_QUEUE_SIZE 4
#define EMPTY_QUEUE 0

#include <stdbool.h>
#include <pthread.h>
#include "HWTE_RobotDriverLib.h"

typedef struct node {
    HWTE_RobotTransferRequest_t *requestPtr;
    struct node                 *next;
} QUEUE_NODE;

typedef struct {
    int         count;
    QUEUE_NODE  *front;
    QUEUE_NODE  *rear;
    pthread_mutex_t lock;
} QUEUE;

/* Helper function declarations */

QUEUE *createQueue(void);
QUEUE *destroyQueue(QUEUE *commandQueue);
bool  Enqueue(QUEUE *commandQueue, HWTE_RobotTransferRequest_t *requestPtr);
bool  dequeue(QUEUE *commandQueue, HWTE_RobotTransferRequest_t **requestPtr);
bool  emptyQueue(QUEUE *commandQUeue);
bool  fullQueue(QUEUE *commandQueue);
bool  queueFront (QUEUE *commandQueue, HWTE_RobotTransferRequest_t **requestPtr);
int   queueCount(QUEUE *commandQueue);
void  printQueue(QUEUE *commandQueue);
#endif
