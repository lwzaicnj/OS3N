//
//  IDHelpers.c
//  RCServer
//
//  Created by Jen-Wei Peng on 1/15/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//

#define NMESSAGE_ID_MIN 32768
#define NMESSAGE_ID_MAX 65535

#include "IDHelpers.h"

static uint16_t NMessageID = 32768;
static HWTE_RobotJobID_t JOB_ID = 1;

uint16_t GetNMessageID()
{
    return NMessageID;
}

void IncrementNMessageID()
{
    if (NMessageID >= NMESSAGE_ID_MAX)
        NMessageID = NMESSAGE_ID_MIN;
    else
        NMessageID++;
}

HWTE_RobotJobID_t GetJobID()
{
    return JOB_ID;
}

void IncrementJobID()
{
    JOB_ID++;
}
