#ifndef RCServer_HWTE_RobotDriverLib_h
#define RCServer_HWTE_RobotDriverLib_h

/*
 * All APIs herein conform to “transfer” or “create"
 * ownership rules: the caller owns the memory returned.
 * The only exception is HWTE_RobotDescriptor_t, see below.
 */

#include <stdint.h>
#include "HWTE_RobotProtoDefs.h"
#include <stdbool.h>
#include <stddef.h>

/* Type definitions and enumerations */
typedef void *HWTE_RobotHandle_t;
typedef void *HWTE_RobotConfigValue_t;
typedef uint16_t HWTE_LocationID_t;
typedef uint16_t HWTE_RobotJobID_t;
typedef uint16_t HWTE_RobotGripperID_t;
typedef uint16_t HWTE_RobotTimerHandle_t;

typedef enum {
    HWTE_RobotNotifyStatusMessage = 0,
    HWTE_RobotNotifyModeChangeRemote = 1,
    HWTE_RobotNotifyModeChangeLocal = 2,
    HWTE_RobotNotifyJobStarted = 3,
    HWTE_RobotNotifyJobCompleted = 4,
    HWTE_RobotNotifyMotoson = 5,
    HWTE_RobotNotifyMotorsOff = 6,
    HWTE_RobotNotifyHomeStarted = 7,
    HWTE_RobotNotifyHomeCompleted =8,
    HWTE_RobotNotifyListjobs = 9,
    HWTE_RobotNotifyGripCompleted = 10,
    HWTE_RobotNotifyUnGripCompleted = 11,
    HWTE_RobotNotifySetLocationCompleted = 12
} HWTE_RobotNotificationType_t;

typedef enum {
    HWTE_RobotJobTypePick = 0,
    HWTE_RobotJobTypePlace = 1,
    HWTE_RobotJobTypePickPlace = 2,
    HWTE_RobotJobTypeGoto = 3
} HWTE_RobotMovementType_t;


typedef enum {
    HWTE_RobotModeLocal = 0,
    HWTE_RobotModeRemote = 1
} HWTE_RobotMode_t;

typedef enum {
    HWTE_RobotMotorsOff = 0, 
    HWTE_RobotMotorsOn = 1
} HWTE_RobotMotorState_t;

typedef enum {
    HWTE_RobotUnGrip = 0,
    HWTE_RobotGrip = 1
} HWTE_RobotGripperPosition_t;

typedef enum {
    HWTE_RobotStateInitializing = 0,
    HWTE_RobotStateIdle = 1,
    HWTE_RobotStateExecuting = 2,
    HWTE_RobotStateFaulted = 3
} HWTE_RobotState_t;

typedef enum {
    HWTE_RobotEStopNotPressed = 0,
    HWTE_RobotEStopPressed = 1
} HWTE_RobotEStop_t;

typedef enum {
    HWTE_RobotVacuumGen1Off = 0,
    HWTE_RobotVacuumGen1On = 1
} HWTE_RobotVacuumGen1_t;

typedef enum {
    HWTE_RobotVacuumSensor1Off = 0,
    HWTE_RobotVacuumSEnsor1On = 1
} HWTE_RobotVacuumSensor1_t;

typedef enum {
    HWTE_RobotGripper1faulted = 0,
    HWTE_RobotGripper1Idle = 2,
    HWTE_RobotGripper1Gripped = 1
} HWTE_RobotGripper1Status_t;

typedef enum {
    HWTE_RobotConfigManufacturerID = 0,
    HWTE_RobotConfigConfigID = 1,
    HWTE_RobotConfigNumLocations = 2,
    HWTE_RobotConfigProtocolVersion = 3,
    HWTE_RobotConfigControllerVersion = 4,
    HWTE_RobotConfigMaxTCPConnections = 5,
    HWTE_RobotConfigNumOpenTCPConnections = 6,
    HWTE_RobotConfigNumGrippers = 7
} HWTE_RobotConfigParameter_t;

typedef struct {
    HWTE_RobotNotificationType_t    type;
    HWTE_RobotHandle_t              robot;
    HWTE_RobotJobID_t               jobID;
    HWTE_RobotMode_t                robotMode;
    HWTE_RobotTimerHandle_t         timer;
    void                            *data;
    size_t                          dataSize;
    void                            *userInfo;
} HWTE_RobotNotification_t;

typedef enum {
    HWTE_RobotCommandCreatejob = 0,
    HWTE_RobotCommandStatus = 1,
    HWTE_RobotCommandStatusStart = 2,
    HWTE_RobotCommandStatusStop = 3,
    HWTE_RobotCommandGetCurrentPosition = 4,
    HWTE_RobotCommandListjobs = 5,
    HWTE_RobotCommandRemote = 6,
    HWTE_RobotCommandMotorOn = 7,
    HWTE_RobotCommandMotorOff = 8,
    HWTE_RobotCommandHome = 9,
    HWTE_RobotCommandSetMaxSpeed = 10,
    HWTE_RobotCommandGetMaxSpeed = 11,
    HWTE_RobotCommandGrip = 12,
    HWTE_RobotCommandUnGrip = 13,
    HWTE_RobotCommandLocal = 14,
    HWTE_RobotCommandGetLocationConfig = 15,
    HWTE_RobotCommandSetLocationConfig = 16,
    HWTE_RobotCommandAbort = 17,
    HWTE_RobotCommandResume = 18,
    HWTE_RobotCommandReportConfig = 19,
    HWTE_RobotCommandInitialize = 20,
    HWTE_RobotCommandReset = 21,
} HWTE_RobotCommand_t;

typedef enum {
    HWTE_RobotRequestStatusExecuting = 0,
    HWTE_RobotRequestStatusPending = 1
} HWTE_RobotRequestStatus_t;

typedef struct {
    char        *ManufacturerID;
    char        *ConfigurationID;
    char        *NumberOfLocations;
    char        *ProtocolVersion;
    char        *RCSoftwareVersion;
}HWTE_RobotConfiguration;

typedef enum {
    HWTE_RobotRequestNoConfiguration    = 0,
    HWTE_RobotRequestManufacturerID     = 1,
    HWTE_RobotRequestConfigurationID    = 2,
    HWTE_RobotRequestNumberOfLocations  = 3,
    HWTE_RobotRequestProtocolVersion    = 4,
    HWTE_RobotRequestRCSoftwareVersion  = 5
} HWTE_RobotRequestConfiguration;

typedef struct {
    // filled in by the consumer requesting a transfer
    HWTE_RobotRequestConfiguration  requestedConfiguration;
    HWTE_RobotRequestStatus_t       status;
    HWTE_RobotCommand_t             command;
    HWTE_RobotMovementType_t        type;
    HWTE_LocationID_t               source;
    HWTE_LocationID_t               destination;
    int                             gripperID;
    int                             locationID;
    // filled in after a transfer request completes successfully
    HWTE_RobotJobID_t               jobID;
    uint16_t                        queuePosition;
    uint16_t                        jobsEnqueued;
} HWTE_RobotTransferRequest_t;

// memory is *not* owned by the caller
typedef struct {
    char const                    *name;
    char const                    *location;
} HWTE_RobotDescriptor_t;

typedef void
(*HWTE_RobotNotificationCallback_t)(HWTE_RobotNotification_t notification);

//Add by FX team
typedef enum {
    HWTE_RobotStatusType = 0,
    HWTE_RobotStatusTypeStart = 1,
    HWTE_RobotStatusTypeStop = 2,
} HWTE_RobotStatusType_t;

typedef enum {
    HWTE_RobotStatusMode = 0,
    HWTE_RobotStatusState = 1,
    HWTE_RobotStatusHomed = 2,
    HWTE_RobotStatusCurrentJobID = 3,
    HWTE_RobotStatusMotorStatus = 4,
    HWTE_RobotStatusJobsInQueue = 5,
    HWTE_RobotStatusEstop = 6,
    HWTE_RobotStatusTaughtPositions = 7,
    HWTE_RobotStatusActiveConnections = 8,
    HWTE_RobotStatusGripper1 = 9,
    HWTE_RobotStatusVacuumgen1 = 10,
    HWTE_RobotStatusVacuumsensor1 = 11
} HWTE_RobotStatusParameter_t;
#endif