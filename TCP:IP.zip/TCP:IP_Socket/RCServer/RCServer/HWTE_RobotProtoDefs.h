#ifndef RCServer_HWTE_RobotProtoDefs_h
#define RCServer_HWTE_RobotProtoDefs_h

#include <stdint.h>

// negative values denote errors, non-negative values denote success

typedef enum {
    HWTE_RobotResponseMultipleErrors = -13,
    HWTE_RobotResponseStopPressed = -12,
    HWTE_RobotResponseDestinationNotTrained = -11,
    HWTE_RobotResponseSourceNotTrained = -10,
    HWTE_RobotResponseNotHomed = -9,
    HWTE_RobotResponseLocalMode = -8,
    HWTE_RobotResponseTransferQueueFull = -7,
    HWTE_RobotResponseInvalidDestination = -6,
    HWTE_RobotResponseInvalidSource = -5,
    HWTE_RobotResponseInvalidJobType = -4,
    HWTE_RobotResponseInvalidJobID = -3,
    HWTE_RobotResponseInvalidCommand = -2,
    HWTE_RobotResponseInvalidMessageID = -1,
    HWTE_RobotResponseAcknowledge = 0,
    HWTE_RobotResponseOK = 0
} HWTE_RobotResponse_t;

/* All possible commands */
typedef enum {
    createjob = 0,
    status = 1,
    statusstart = 2,
    statusstop = 3,
    listjobs = 4,
    initialize = 5,
    abortr = 6,
    reset = 7,
    motorson = 8,
    motorsoff = 9,
    local = 10,
    remote = 11,
    grip = 12,
    ungrip = 13,
    home = 14,
    setmaxspeed = 15,
    getmaxspeed = 16,
    reportconfig = 17,
    getlocationconfig = 18
} HWTE_RobotCommand;
#endif
