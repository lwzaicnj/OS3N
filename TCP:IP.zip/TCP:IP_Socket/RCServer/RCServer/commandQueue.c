//
//  commandQueue.c
//  RCSimulator
//
//  Created by Jen-Wei Peng on 1/8/14.
//  Copyright (c) 2014 Jen-Wei Peng. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "commandQueue.h"
#include <pthread.h>

/* Allocate the head queue node */
QUEUE* createQueue(void) {
    
    QUEUE* commandQueue = (QUEUE*)malloc(sizeof(QUEUE));
    
    /* Initialize the allocated head */
    if(commandQueue) {
        commandQueue->front = commandQueue->rear = NULL;
        commandQueue->count = 0;
        pthread_mutex_init(&commandQueue->lock, NULL);
    }
    
    return commandQueue;
} /* createQueue */

/* Insert command to command queue */
bool Enqueue(QUEUE* commandQueue, HWTE_RobotTransferRequest_t *requestPtr) {
    pthread_mutex_lock(&commandQueue->lock);
    QUEUE_NODE* newCommand;
    
    /* Return false if fall to allocate memory for newCommand */
    if( (newCommand = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE))) ) {
        
        if (!(newCommand->requestPtr = calloc(1, sizeof(*requestPtr)) ))
        {
            free(newCommand);
            return false;
        }
    }
    else
        return false;
    
    /* Initialize newCommand */
    newCommand->next = NULL;
    newCommand->requestPtr->destination = (requestPtr->destination);
    newCommand->requestPtr->jobID = requestPtr->jobID;
    newCommand->requestPtr->jobsEnqueued = requestPtr->jobsEnqueued;
    newCommand->requestPtr->queuePosition = requestPtr->queuePosition;
    newCommand->requestPtr->source = requestPtr->source;
    newCommand->requestPtr->type = requestPtr->type;
    newCommand->requestPtr->command = requestPtr->command;
    newCommand->requestPtr->status = requestPtr->status;
    
    if(commandQueue->count == 0)
        commandQueue->front = newCommand;
    else
        commandQueue->rear->next = newCommand;
    
    commandQueue->rear = newCommand;
    (commandQueue->count)++;
    pthread_mutex_unlock(&commandQueue->lock);
    
    return true;
} /* enqueue */

/* Delete command from command queue */
bool dequeue(QUEUE* commandQueue, HWTE_RobotTransferRequest_t ** requestPtr) {
    
    QUEUE_NODE* nodeToBeDeleted;
    
    /* Return false if command queue is empty */
    if(!commandQueue->count)
        return false;
    
    *requestPtr = commandQueue->front->requestPtr;
    nodeToBeDeleted = commandQueue->front;
    
    /* Just delete first node if there is only command in the queue */
    if(commandQueue->count == 1){
        commandQueue->front = NULL;
        commandQueue->rear = NULL;
    }
    else {
        commandQueue->front = commandQueue->front->next;
    }
    
    /* Update count and free nodeToBeDeleted */
    (commandQueue->count)--;
    free(*requestPtr);
    free(nodeToBeDeleted);
    
    return true;
} /* dequeue */

/* Check if command queue is empty */
bool emptyQueue(QUEUE* commandQueue){
    
    return (commandQueue->count == EMPTY_QUEUE);
} /* emptyQueue */

/* Check if command queue is full */
bool fullQueue(QUEUE* commandQueue){
    
    return (commandQueue->count == COMMAND_QUEUE_SIZE);
} /* fullQueue */

/* Return the number of commands in the queue */
int queueCount(QUEUE* commandQueue){
    
    return (commandQueue->count);
} /* queueCount */

/* Free all data from the command queue, then free the command queue */
QUEUE* destroyQueue(QUEUE* commandQueue) {
    
    QUEUE_NODE* nodeToBeDeleted;
    
    /* if command queue is allocated */
    if(commandQueue) {
        while(commandQueue->front) {
            free(commandQueue->front->requestPtr);
            nodeToBeDeleted = commandQueue->front;
            commandQueue->front = commandQueue->front->next;
            free(nodeToBeDeleted);
        }
        
        free(commandQueue);
    }
    
    return NULL;
} /* destroyQueue */

bool queueFront (QUEUE *commandQueue, HWTE_RobotTransferRequest_t **requestPtr)
{
    if (!(commandQueue->count))
        return false;
    else
    {
        pthread_mutex_lock(&commandQueue->lock);
        *requestPtr = commandQueue->front->requestPtr;
        pthread_mutex_unlock(&commandQueue->lock);
        return true;
    }
}





