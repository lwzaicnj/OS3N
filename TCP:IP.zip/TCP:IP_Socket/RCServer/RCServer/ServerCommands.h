//
//  ServerCommands.h
//  RCServer
//
//  Created by Jen-Wei Peng on 1/6/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//

#ifndef RCServer_ServerCommands_h
#define RCServer_ServerCommands_h
#define BUFFER_SIZE 256

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include "commandQueue.h"

struct ListenerThreadArgs
{
    /* TCP client socket */
    int clientSock;
    /* Robot status */
    HWTE_RobotMode_t robotMode;                     /* local/remote                                 */
    HWTE_RobotState_t robotState;                   /* initializing/idle/executing/faulted          */
    bool isHomed;                                   /* true/false                                   */
    bool eStop;
    HWTE_RobotMotorState_t motorState;              /* on/off                                       */
    HWTE_RobotEStop_t robotEStopStatus;             /* unpressed/pressed                            */
    int totalLocationIDs;                           /* currently 200 are required                   */
    int taughtLocations;                            /* this number cannot exceed totalLocationIDs   */
    int activeConnections;                          /* number of active TCP connections             */
    int maxSpeedValue;
    HWTE_RobotGripper1Status_t gripper1Status;      /* idle/gripped/faulted                         */
    HWTE_RobotVacuumGen1_t vacuumGen1Status;        /* on/off                                       */
    HWTE_RobotVacuumSensor1_t vacuumSensor1Status;  /* on/off                                       */
    struct LocationConfig *locationConfig[200];
    char *currentPosition;
    /* Job queue */
    QUEUE *commandQueue;
    /* Robot configuration */
    HWTE_RobotConfiguration *robotConfiguration;
};

struct LocationConfig
{
    char stringDataFormat[BUFFER_SIZE];
    char *stringData;
};

struct StatusNotificationArgs
{
    struct ListenerThreadArgs **robotPtr;
    HWTE_RobotTransferRequest_t **requestPtr;
    bool *keepSending;
    char *message;
};

int     CreateTCPServerSocket   (void);
int     AcceptTCPConnection     (int servSocket);
void    HandleTCPClient         (struct ListenerThreadArgs **robotPtr);
//bool    CreateRequest           (char *message, HWTE_RobotTransferRequest_t **requestPtr, char **error,
//                                 bool *isHomed, HWTE_RobotMotorState_t *motorState, HWTE_RobotMode_t *robotMode);
bool    CreateRequest           (char *message, HWTE_RobotTransferRequest_t **requestPtr, char **error, struct ListenerThreadArgs **robotPtr);
void    HandleTransferRequest   (int clientSocker, bool isHomed, HWTE_RobotMotorState_t motorState,
                                 HWTE_RobotMode_t robotMode, HWTE_RobotTransferRequest_t *requestPtr, QUEUE *commandQueue, struct ListenerThreadArgs **robotPtr);
int     ToRobotMovementType     (char *token, char **error);
bool    ValidateCommand         (char *token, char **error);
bool    ValidateCMessageID      (char *token, char **error);
void    CreateAck               (char **socket_buffer, HWTE_RobotTransferRequest_t *requestPtr, char *error, int queueCount, struct ListenerThreadArgs **robotPtr);
void    CreateNotification      (char **message, HWTE_RobotNotificationType_t notificationType, HWTE_RobotJobID_t jobID,
                                 char **error, HWTE_RobotTransferRequest_t *requestPtr);
void    ListjobsNotification    (int clientSocket, char **message, QUEUE *commandQueue);
//void    StatusNotification      (int clientSocket, char **message, HWTE_RobotTransferRequest_t *requestPtr, bool isHomed, HWTE_RobotMotorState_t motorState,
//                                 HWTE_RobotMode_t robotMode, HWTE_RobotState_t *robotState, HWTE_RobotEStop_t robotEStopStatus, int totalLocationIDs,
//                                 int taughtLocations, int activeConnections, HWTE_RobotGripper1Status_t gripper1Status, HWTE_RobotVacuumGen1_t vacuumGen1Status,
//                                 HWTE_RobotVacuumSensor1_t vacuumSensor1Status);
void    StatusNotification      (struct ListenerThreadArgs *robotPtr, char *message, HWTE_RobotTransferRequest_t *requestPtr, int *period);
void    CheckAckForRobotStatus  (int period, char *statusParameter, char **message);
void    *ListenerThread         (void *listenerThreadArgs);
void    *WorkerThread           (void *workerThreadArgs);
void    CreateAndSendAlert      (int clientSocket,char *errorCode);
void    delay                   (int sec);


#endif
