//
//  RCSimulatorCommands.c
//  RCServer
//
//  Created by Jen-Wei Peng on 1/15/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//

#include "RCSimulatorCommands.h"



HWTE_RobotResponse_t registerForNotification(HWTE_RobotHandle_t robot, HWTE_RobotNotificationType_t type, HWTE_RobotNotificationCallback_t cb,
                                             float interval, bool repeat, void* userInfo, HWTE_RobotTimerHandle_t *handle)
{
    /*
     HWTE_RobotResponseMultipleErrors = -13,
     HWTE_RobotResponseStopPressed = -12,
     HWTE_RobotResponseDestinationNotTrained = -11,
     HWTE_RobotResponseSourceNotTrained = -10,
     HWTE_RobotResponseNotHomed = -9,
     HWTE_RobotResponseLocalMode = -8,
     HWTE_RobotResponseTransferQueueFull = -7,
     HWTE_RobotResponseInvalidDestination = -6,
     HWTE_RobotResponseInvalidSource = -5,
     HWTE_RobotResponseInvalidJobType = -4,
     HWTE_RobotResponseInvalidJobID = -3,
     HWTE_RobotResponseInvalidCommand = -2,
     HWTE_RobotResponseInvalidMessageID = -1,
     HWTE_RobotResponseAcknowledge = 0,
     HWTE_RobotResponseOK = 0
     
     HWTE_RobotNotifyStatusMessage = 0,
     HWTE_RobotNotifyModeChangeRemote = 1,
     HWTE_RobotNotifyModeChangeLocal = 2,
     HWTE_RobotNotifyJobStarted = 3,
     HWTE_RobotNotifyJobCompleted = 4
     */
    HWTE_RobotResponse_t t = 1;
    
    HWTE_RobotNotification_t notification = CreateNotification(type, robot, handle, userInfo);
    
    /* Should have some logic to fill the notification data, data size, and return type */
    (*cb)(notification);
    
    switch (type)
    {
        case 0:
            break;
        case 1:
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        default:
            break;
    }
    
    return t;
}

/* Callback functions
void Callback1(HWTE_RobotNotification_t notification)
{
    //generate notification buffer
    return NULL;
    //todo
}
*/