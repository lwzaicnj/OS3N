//
//  IDHelpers.h
//  RCServer
//
//  Created by Jen-Wei Peng on 1/15/14.
//  Copyright (c) 2014 Jenwei Peng. All rights reserved.
//
#ifndef RCServer_IDHelpers_h
#define RCServer_IDHelpers_h

#include <stdint.h>
#include "HWTE_RobotDriverLib.h"

uint16_t            GetNMessageID();
void                IncrementNMessageID();
void                IncrementJobID();   
HWTE_RobotJobID_t   GetJobID();

#endif
