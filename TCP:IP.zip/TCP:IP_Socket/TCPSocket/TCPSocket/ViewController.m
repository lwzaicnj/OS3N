//
//  ViewController.m
//  TCPSocket
//
//  Created by apple on 2/21/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController
@synthesize client; // 属性和成员变量同名，不用 client=_client
@synthesize outputMsg,inputMsg;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self connectServer:HOST_IP port:HOST_PORT];

}

- (int) connectServer: (NSString *) hostIP port:(int) hostPort{
    
    if (client == nil) {
        client = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
//        client = [[AsyncSocket alloc] initWithDelegate:self];
        NSError *error = nil;
        
        //192.168.110.128
        if (![client connectToHost:hostIP onPort:hostPort error:&error]) {
            NSLog(@"%ld %@",(long)[error code], [error localizedDescription]);
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:
                                  [@"Connection failed to host" stringByAppendingString:hostIP]
                                                            message:[[[NSString alloc] initWithFormat:@"%ld",(long)[error code]] stringByAppendingString:[error localizedDescription]]
                                                            delegate:self
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles: nil];
            
            [alert show];
//            is_open = NO;
            return SRV_CONNECT_FAIL;
        }
        else{
            
//            is_open = YES;
            NSLog(@"Connection!");
            return SRV_CONNECT_SUC;
        }
    }
    
    //已经连接
    else {
        [client readDataWithTimeout:-1 tag:0];
        return SRV_CONNECTED;
    }
}

//客户端发送信息到服务器
- (IBAction)sendMsg{

    NSString *inputMsgStr = self.inputMsg.text;
    NSString *content = [inputMsgStr stringByAppendingString:@"\r\n"];
    if ([client isConnected]) {
        NSLog(@"send message : %@",content);
        NSData *data = [content dataUsingEncoding:NSISOLatin1StringEncoding];
        [client writeData:data withTimeout:-1 tag:0];
    }
}

- (IBAction) reConnect{

    int stat = [self connectServer:HOST_IP port:HOST_PORT];
    
    switch (stat) {
        case SRV_CONNECT_SUC:
            [self showMessage:@"connect success"];
            break;
        case SRV_CONNECTED:
            [self showMessage:@"It's connected,don't agian"];
            break;
        default:
            break;
    }
}

#pragma mark close Keyboard
- (IBAction) textFieldDoneEditing:(id)sender{
    
    [sender resignFirstResponder];
}

- (IBAction) backgroundTouch:(id)sender{
    [inputMsg resignFirstResponder];
}


#pragma mark socket delegate
- (void) showMessage:(NSString *) msg{

    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"Alert!"
                                                    message:msg
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark socket delegate

//連接成功后
- (void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port{
    
    //監聽函數
    [client readDataWithTimeout:-1 tag:0];
}

//即將斷開連接
- (void)onSocket:(AsyncSocket *)sock willDisconnectWithError:(NSError *)err
{
    NSLog(@"Error, Socket disconect!");
}

//已經斷了連接
- (void)onSocketDidDisconnect:(AsyncSocket *)sock
{
    NSString *msg = @"Sorry this connect is failure";
    [self showMessage:msg];
    self.outputMsg.text = @"Disconnected";
    client = nil;
}

- (void)onSocketDidSecure:(AsyncSocket *)sock{
    
}

//處理 socket 接收數據
- (void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag{
    
    NSLog(@"thread(%@),onSocket:%@ didWriteDataWithTag:%ld",[[NSThread currentThread] name],
          
          sock,tag);
}


//在onSocket重载函数，有如定义采用是专门用来处理SOCKET的发送数据的：
- (void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    
    NSString* aStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"Have received datas is :%@",aStr);
    self.outputMsg.text = aStr;
//    [aStr release];
    [client readDataWithTimeout:-1 tag:0];
}


@end






















































