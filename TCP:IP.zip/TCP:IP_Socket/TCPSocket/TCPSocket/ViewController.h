//
//  ViewController.h
//  TCPSocket
//
//  Created by apple on 2/21/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCDAsyncSocket.h"
#import "AsyncSocket.h"

#define SRV_CONNECTED 0
#define SRV_CONNECT_SUC 1
#define SRV_CONNECT_FAIL 2
#define HOST_IP @"192.168.0.1"
#define HOST_PORT 8080


@interface ViewController : UIViewController<GCDAsyncSocketDelegate>{
    
    
    BOOL is_open;
    UITextField *inputMsg;
    UILabel *outputMsg;
    GCDAsyncSocket *client;
//    AsyncSocket *client;
}
@property (nonatomic, retain) GCDAsyncSocket *client;
//@property (nonatomic, retain) AsyncSocket *client;
@property (nonatomic, retain) IBOutlet UITextField *inputMsg;
@property (nonatomic, retain) IBOutlet UILabel *outputMsg;


- (int) connectServer: (NSString *) hostIP port:(int) hostPort;
- (void) showMessage:(NSString *) msg;

- (IBAction) sendMsg;
- (IBAction) reConnect;
- (IBAction) textFieldDoneEditing:(id)sender;
- (IBAction) backgroundTouch:(id)sender;

@end

