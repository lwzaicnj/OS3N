//
//  ServerViewController.h
//  GCDAsyncSocket
//
//  Created by apple on 2/23/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCDAsyncSocket.h"

@interface ServerViewController : UIViewController<GCDAsyncSocketDelegate>{

    UITextField *_portTF;// 端口号
    UITextField *_contentTF;// 内容
    UITextView *_message;// 多行文本输入框
    GCDAsyncSocket *_serverSocket; // 服务器socket
    GCDAsyncSocket *_clientSocket; // 为客户端生成的socket
}

@property (copy, nonatomic) UITextField *portTF;

@property (copy, nonatomic)  UITextField *contentTF;

@property (copy, nonatomic) UITextView *message;

@property (nonatomic, strong)  GCDAsyncSocket *serverSocket;

@property (nonatomic, strong) GCDAsyncSocket *clientSocket;



@end
