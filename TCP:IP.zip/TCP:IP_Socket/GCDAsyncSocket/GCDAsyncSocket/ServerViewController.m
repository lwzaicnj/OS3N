//
//  ServerViewController.m
//  GCDAsyncSocket
//
//  Created by apple on 2/23/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ServerViewController.h"
#import "JQSocket.h"

@interface ServerViewController ()<GCDAsyncSocketDelegate>

@property (weak, nonatomic) IBOutlet UITextField *portTF;   // 端口号

@property (weak, nonatomic) IBOutlet UITextField *contentTF;// 内容

@property (weak, nonatomic) IBOutlet UITextView *message;   // 多行文本输入框

@property (nonatomic, strong) GCDAsyncSocket *serverSocket; // 服务器socket

@property (nonatomic, strong) GCDAsyncSocket *clientSocket; // 为客户端生成的socket

@end

@implementation ServerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_message scrollRangeToVisible:NSMakeRange(_message.text.length, 1)];
    _message.layoutManager.allowsNonContiguousLayout = NO;//
    
}

//服務器監聽某個端口
- (IBAction)listen:(id)sender {
    
    //1. 創建服務器 socket
    self.serverSocket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    //2. 開放端口
    
    NSError *error = nil;
    BOOL result = [self.serverSocket acceptOnPort:self.portTF.text.integerValue error:&error];
    
    if (result) {
        [self addText:@"端口開放成功"];
    }else{
        [self addText:@"端口開放失敗"];
    }
        
    [self hidTheKeyword];
    
}

- (void) addText:(NSString *) text{
    
    self.message.text = [self.message.text stringByAppendingFormat:@"%@\n", text];
}

- (void)hidTheKeyword{
    
    [self.contentTF resignFirstResponder];
    [self.portTF resignFirstResponder];
    [self.message endEditing:YES];
}

- (IBAction)sendMessage:(id)sender {
    
    NSData *data = [self.contentTF.text dataUsingEncoding:NSUTF8StringEncoding];
    [self.clientSocket writeData:data withTimeout:-1 tag:0];
    
    JQSocket *socket = [JQSocket defaultSocket];
    [socket.mySocket readDataWithTimeout:-1 tag:0];
}


- (IBAction)receiveMessage:(id)sender {
    
    [self.clientSocket readDataWithTimeout:-1 tag:0];
    [self hidTheKeyword];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self hidTheKeyword];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - GCDAsyncSocketDelegate
// 当客户端链接服务器端的socket, 为客户端单生成一个socket
- (void)socket:(GCDAsyncSocket *)sock didAcceptNewSocket:(GCDAsyncSocket *)newSocket
{
    [self addText:@"链接成功"];
    //IP: newSocket.connectedHost
    //端口号: newSocket.connectedPort
    [self addText:[NSString stringWithFormat:@"链接地址:%@", newSocket.connectedHost]];
    [self addText:[NSString stringWithFormat:@"端口号:%hu", newSocket.connectedPort]];
    // short: %hd
    // unsigned short: %hu
    
    // 存储新的端口号
    self.clientSocket = newSocket;
}

// 服务端接收到消息
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    NSString *message = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    [self addText:message];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
