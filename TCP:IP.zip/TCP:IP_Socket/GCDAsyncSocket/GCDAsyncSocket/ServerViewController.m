//
//  ServerViewController.m
//  GCDAsyncSocket
//
//  Created by apple on 2/23/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ServerViewController.h"
#import "JQSocket.h"

@interface ServerViewController ()

@end
@implementation ServerViewController
@synthesize portTF = _portTF;
@synthesize contentTF = _contentTF;
@synthesize message = _message;
@synthesize serverSocket = _serverSocket;
@synthesize clientSocket = _clientSocket;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _portTF = [[UITextField alloc] initWithFrame:CGRectMake(60, 60, 150, 40)];
    
    _portTF.borderStyle = UITextBorderStyleLine;
    
    _portTF.text = @"Port";
    
    [self.view addSubview:_portTF];
    
    _contentTF = [[UITextField alloc] initWithFrame:CGRectMake(60, 120, 150, 40)];
    
    _contentTF.borderStyle = UITextBorderStyleLine;
    
    _contentTF.text = @"Content";
    
    [self.view addSubview:_contentTF];
    
    _message = [[UITextView alloc] initWithFrame:CGRectMake(60, 180, 200, 200)];
    
    _message.text = @"Message....";
    
    _message.font = [UIFont systemFontOfSize:15];
    
    [self.view addSubview:_message];
    
    
    UIButton *lisBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    lisBtn.frame = CGRectMake(150, 400, 40, 60);
    
    [lisBtn setTitle:@"listen" forState:UIControlStateNormal];
    
    [lisBtn addTarget:self action:@selector(listen:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:lisBtn];
    
    UIButton *send = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    send.frame = CGRectMake(150, 480, 40, 60);
    
    [send setTitle:@"send" forState:UIControlStateNormal];
    
    [send addTarget:self action:@selector(sendMessage:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:send];
    
    UIButton *rece = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    rece.frame = CGRectMake(150, 560, 40, 60);
    
    [rece setTitle:@"receive" forState:UIControlStateNormal];
    
    [rece addTarget:self action:@selector(receiveMessage:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:rece];
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.title = @"服務器視圖";
    self.view.tintColor = [UIColor blackColor];
    
    [_message scrollRangeToVisible:NSMakeRange(_message.text.length, 1)];
    _message.layoutManager.allowsNonContiguousLayout = NO;//
    
}

//服務器監聽某個端口
- (void)listen:(id)sender {
    
    //1. 創建服務器 socket
    self.serverSocket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    //2. 開放端口
    
    NSError *error = nil;
    BOOL result = [self.serverSocket acceptOnPort:self.portTF.text.integerValue error:&error];
    
    if (result) {
        [self addText:@"端口開放成功"];
    }else{
        [self addText:@"端口開放失敗"];
    }
        
    [self hidTheKeyword];
    
}

- (void) addText:(NSString *) text{
    
    self.message.text = [self.message.text stringByAppendingFormat:@"%@\n", text];
}

- (void)hidTheKeyword{
    
    [self.contentTF resignFirstResponder];
    [self.portTF resignFirstResponder];
    [self.message endEditing:YES];
}

- (void)sendMessage:(id)sender {
    
    NSData *data = [self.contentTF.text dataUsingEncoding:NSUTF8StringEncoding];
    [self.clientSocket writeData:data withTimeout:-1 tag:0];
    
    JQSocket *socket = [JQSocket defaultSocket];
    [socket.mySocket readDataWithTimeout:-1 tag:0];
}


- (void)receiveMessage:(id)sender {
    
    [self.clientSocket readDataWithTimeout:-1 tag:0];
    [self hidTheKeyword];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self hidTheKeyword];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - GCDAsyncSocketDelegate
// 当客户端链接服务器端的socket, 为客户端单生成一个socket
- (void)socket:(GCDAsyncSocket *)sock didAcceptNewSocket:(GCDAsyncSocket *)newSocket
{
    [self addText:@"链接成功"];
    //IP: newSocket.connectedHost
    //端口号: newSocket.connectedPort
    
    NSLog(@"%@",newSocket.connectedHost);
    [self addText:[NSString stringWithFormat:@"链接地址:%@", newSocket.connectedHost]];
    [self addText:[NSString stringWithFormat:@"端口号:%hu", newSocket.connectedPort]];
    // short: %hd
    // unsigned short: %hu
    
    // 存储新的端口号
    self.clientSocket = newSocket;
}

// 服务端接收到消息
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    NSString *message = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    [self addText:message];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
