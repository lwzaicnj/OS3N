//
//  ClientViewController.h
//  GCDAsyncSocket
//
//  Created by apple on 2/23/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCDAsyncSocket.h"
#import "JQSocket.h"

@interface ClientViewController : UIViewController<GCDAsyncSocketDelegate>{
    
    UITextField *_addressTF;
    UITextField *_portTF;
    UITextField *_message;
    UITextView *_content;
    GCDAsyncSocket *_socket;
}

@property (retain, nonatomic)  UITextField *addressTF;

@property (retain, nonatomic)  UITextField *portTF;

@property (retain, nonatomic)  UITextField *message;

@property (retain, nonatomic)  UITextView *content;  // 多行文本输入

@property (nonatomic, strong) GCDAsyncSocket *socket;

@end
