//
//  ClientViewController.m
//  GCDAsyncSocket
//
//  Created by apple on 2/23/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "ClientViewController.h"


@interface ClientViewController ()

@end

@implementation ClientViewController
@synthesize addressTF = _addressTF;
@synthesize portTF = _portTF;
@synthesize message = _message;
@synthesize content = _content;
@synthesize socket = _socket;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //////// 客户端 ////////
    
    
    _portTF = [[UITextField alloc] initWithFrame:CGRectMake(60, 60, 150, 40)];
    
    _portTF.borderStyle = UITextBorderStyleLine;
    
    _portTF.text = @"Port";
    
    [self.view addSubview:_portTF];
    
    _addressTF = [[UITextField alloc] initWithFrame:CGRectMake(60, 120, 150, 40)];
    
    _addressTF.borderStyle = UITextBorderStyleLine;
    
    _addressTF.text = @"address";
    
    [self.view addSubview:_addressTF];
    
    _message = [[UITextField alloc] initWithFrame:CGRectMake(60, 180, 150, 40)];
    
    _message.borderStyle = UITextBorderStyleLine;
    
    _message.text = @"message";
    
    [self.view addSubview:_message];
    
    _content = [[UITextView alloc] initWithFrame:CGRectMake(60, 250, 200, 200)];
    
    _content.text = @"Content....";
    
    [self.view addSubview:_content];
    
    
    UIButton *lisBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    lisBtn.frame = CGRectMake(150, 400, 40, 60);
    
    [lisBtn setTitle:@"connect" forState:UIControlStateNormal];
    
    [lisBtn addTarget:self action:@selector(connect:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:lisBtn];
    
    UIButton *send = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    send.frame = CGRectMake(150, 480, 40, 60);
    
    [send setTitle:@"send" forState:UIControlStateNormal];
    
    [send addTarget:self action:@selector(sendMassage:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:send];
    
    UIButton *rece = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    rece.frame = CGRectMake(150, 560, 40, 60);
    
    [rece setTitle:@"receive" forState:UIControlStateNormal];
    
    [rece addTarget:self action:@selector(receiveMassage:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:rece];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.title = @"客戶端視圖";
    
     self.view.tintColor = [UIColor blackColor];
    
    [_content scrollRangeToVisible:NSMakeRange(_content.text.length, 1)];
    _content.layoutManager.allowsNonContiguousLayout = NO;
}

// 和服务器进行链接
- (void)connect:(UIButton *)sender
{
    // 1. 创建socket
    self.socket = [[GCDAsyncSocket alloc] initWithDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    // 2. 与服务器的socket链接起来
    NSError *error = nil;
    BOOL result = [self.socket connectToHost:self.addressTF.text onPort:self.portTF.text.integerValue error:&error];
    
    // 3. 判断链接是否成功
    if (result) {
        [self addText:@"客户端链接服务器成功"];
    } else {
        [self addText:@"客户端链接服务器失败"];
    }
    [self hidTheKeyword];
}

// 接收数据
- (void)receiveMassage:(UIButton *)sender
{
    [self.socket readDataWithTimeout:-1 tag:0];
    [self hidTheKeyword];
}

// 发送消息
- (void)sendMassage:(UIButton *)sender
{
    NSData *data = [self.message.text dataUsingEncoding:NSUTF8StringEncoding];
    [self.socket writeData:data withTimeout:-1 tag:0];
    
    JQSocket *socket = [JQSocket defaultSocket];
    [socket.mySocket readDataWithTimeout:-1 tag:0];
    [self hidTheKeyword];
}

#pragma mark - GCDAsyncSocketDelegate
// 客户端链接服务器端成功, 客户端获取地址和端口号
- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port
{
    [self addText:[NSString stringWithFormat:@"链接服务器%@", host]];
    
    JQSocket *socket = [JQSocket defaultSocket];
    socket.mySocket = self.socket;
}

// 客户端已经获取到内容
- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    [self addText:content];
}

// textView填写内容
- (void)addText:(NSString *)text
{
    self.content.text = [self.content.text stringByAppendingFormat:@"%@\n", text];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self hidTheKeyword];
}

// hiddenKeyword
- (void)hidTheKeyword
{
    [self.addressTF resignFirstResponder];
    [self.portTF resignFirstResponder];
    [self.message resignFirstResponder];
    [self.content endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
