#ifndef RCClient_HWTE_RobotDriverLib_h
#define RCClient_HWTE_RobotDriverLib_h

/*
 * All APIs herein conform to “transfer” or “create"
 * ownership rules: the caller owns the memory returned.
 * The only exception is HWTE_RobotDescriptor_t, see below.
 */

#include <stdint.h>
#include "HWTE_RobotProtoDefs.h"
#include <stdbool.h>
#include <stddef.h>

#define ERRORCODE_NUM   14                              //error code number
#define CMP_STR         "HWTE_"                         //all error code contain HWTE_ string
#define STOP_PRESSED    "HWTE_RobotResponseStopPressed"
#define NOT_DTRAINED    "HWTE_RobotResponseDestinationNotTrained"

#define NOT_STRAINED    "HWTE_RobotResponseSourceNotTrained"
#define NOT_HOMED       "HWTE_RobotResponseNotHomed"
#define LOCAL_MODE      "HWTE_RobotResponseLocalMode"
#define QUEUE_FULL      "HWTE_RobotResponseTransferQueueFull"
#define INVALID_DES     "HWTE_RobotResponseInvalidDestination"
#define INVALID_SOURCE  "HWTE_RobotResponseInvalidSource"
#define INVALID_JOBTYPE "HWTE_RobotResponseInvalidJobType"
#define INVALID_JOBID   "HWTE_RobotResponseInvalidJobID"
#define INVALID_CMD     "HWTE_RobotResponseInvalidCommand"
#define MESSAGE_ID      "HWTE_RobotResponseInvalidMessageID"
#define ACKNOWLEDGE     "HWTE_RobotResponseAcknowledge"

typedef void *HWTE_RobotResponseData_t;

/* Type definitions and enumerations */

//typedef void *HWTE_RobotHandle_t;
typedef void *HWTE_RobotConfigValue_t;
typedef uint16_t HWTE_LocationID_t;
typedef uint16_t HWTE_RobotJobID_t;
typedef uint16_t HWTE_RobotGripperID_t;
typedef uint16_t HWTE_RobotTimerHandle_t;

typedef enum {
	HWTE_RobotNotifyStatusMessage = 0,
	HWTE_RobotNotifyModeChangeRemote = 1,
	HWTE_RobotNotifyModeChangeLocal = 2,
	HWTE_RobotNotifyJobStarted = 3,
	HWTE_RobotNotifyJobCompleted = 4
} HWTE_RobotNotificationType_t;

typedef enum {
	HWTE_RobotJobTypePick = 0,
	HWTE_RobotJobTypePlace = 1,
	HWTE_RobotJobTypePickPlace = 2,
	HWTE_RobotJobTypeGoto = 3
} HWTE_RobotMovementType_t;

typedef enum {
	HWTE_RobotModeLocal = 0,
	HWTE_RobotModeRemote = 1
} HWTE_RobotMode_t;

typedef enum {
	HWTE_RobotMotorsOff = 0,
	HWTE_RobotMotorsOn = 1
} HWTE_RobotMotorState_t;

typedef enum {
	HWTE_RobotUnGrip = 0,
	HWTE_RobotGrip = 1
} HWTE_RobotGripperPosition_t;

typedef enum {
	HWTE_RobotConfigManufacturerID = 0,
	HWTE_RobotConfigConfigID = 1,
	HWTE_RobotConfigNumLocations = 2,
	HWTE_RobotConfigProtocolVersion = 3,
	HWTE_RobotConfigControllerVersion = 4,
	HWTE_RobotConfigMaxTCPConnections = 5,
	HWTE_RobotConfigNumOpenTCPConnections = 6,
    HWTE_RobotConfigNumGrippers = 7
} HWTE_RobotConfigParameter_t;

// memory is *not* owned by the caller
typedef struct {
	char const 				*name;
	char const				*location;	// tbd, but will likely be a URL scheme e.g. robot://192.168.1.10:28100
} HWTE_RobotDescriptor_t;

typedef struct
{
    bool lock;
    HWTE_RobotDescriptor_t descriptor;
} HWTE_RobotHandle_t;

typedef struct {
	HWTE_RobotNotificationType_t    type;
	HWTE_RobotHandle_t              robot;
	HWTE_RobotJobID_t				jobID;
	HWTE_RobotMode_t				robotMode;
	HWTE_RobotTimerHandle_t	        timer;
	void                            *data;
	size_t                          dataSize;
	void                            *userInfo;
} HWTE_RobotNotification_t;

typedef struct {
	// filled in by the consumer requesting a transfer
	HWTE_RobotMovementType_t	type;
	// in transfer jobs where only one location is needed, 'source' should be used
	// and 'destination' should be left set to zero
	HWTE_LocationID_t			source;
	HWTE_LocationID_t           destination;
	// filled in after a transfer request completes successfully
	HWTE_RobotJobID_t           jobID;
	uint16_t                    queuePosition;
	uint16_t                    jobsEnqueued;
} HWTE_RobotTransferRequest_t;

typedef void (*HWTE_RobotNotificationCallback_t)(HWTE_RobotNotification_t notification);

//Add by FX team
typedef enum {
    HWTE_RobotStatusType = 0,
    HWTE_RobotStatusTypeStart = 1,
    HWTE_RobotStatusTypeStop = 2,
} HWTE_RobotStatusType_t;

typedef enum {
    HWTE_RobotStatusMode = 0,
    HWTE_RobotStatusState = 1,
    HWTE_RobotStatusHomed = 2,
    HWTE_RobotStatusCurrentJobID = 3,
    HWTE_RobotStatusMotorStatus = 4,
    HWTE_RobotStatusJobsInQueue = 5,
    HWTE_RobotStatusEstop = 6,
    HWTE_RobotStatusTotalLocationIDs = 7,
    HWTE_RobotStatusTaughtPositions = 8,
    HWTE_RobotStatusActiveConnections = 9,
    HWTE_RobotStatusGripper1 = 10,
    HWTE_RobotStatusVacuumgen1 = 11,
    HWTE_RobotStatusVacuumsensor1 = 12,
    HWTE_RobotStatusCurrentPosition = 13,
    HWTE_RobotStatusPositionAxis1 = 14,
    HWTE_RobotStatusPositionAxis2 = 15,
    HWTE_RobotStatusPositionAxis3 = 16,
    HWTE_RobotStatusPositionAxis4 = 17,
    HWTE_RobotStatusPositionAxis5 = 18,
    HWTE_RobotStatusPositionAxis6 = 19
} HWTE_RobotStatusParameter_t;
#endif