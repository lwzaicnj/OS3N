//
//  CCCOnnection.c
//  RCClient
//
//  Created by karl on 12/17/13.
//  Copyright (c) 2013 Jenwei Peng. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
//#include "RobotDriver.h"
#include <pthread.h>

#define MESSAGE_ID_MIN  0
#define MESSAGE_ID_MAX  32767
#define LOCATION_ID_MAX 65535
#define SERVER_IP       "192.168.0.1"//"17.207.129.127"                     //Server IP
#define PORT            28100                           //Service port
#define BUFFER_SIZE     256                             //Buffer size


int s_fd = -1;                                          //Socket descriptors

char ack_buffer[BUFFER_SIZE];
char notification_buffer[BUFFER_SIZE];
/*
 create a thread to invoke this function to receive data without stop
 */
void* rece_fun()
{
    char buffer[1024] = {0};
    ssize_t br = 0;
    while (1) {
        memset(buffer, 0, 1024);
        br = recv(s_fd, buffer, sizeof(buffer), 0);
        if(br == -1)
            continue;//connection lost
        else
        {
            char bufferValue[sizeof(buffer)]={0};
            strcpy(bufferValue, buffer);
            char *messageID = strtok(bufferValue, ",");
            if (messageID) {
                long mId = strtol(messageID,NULL,10);
                if (MESSAGE_ID_MIN <= mId & mId <= MESSAGE_ID_MAX) {    //seperate ack and notification messages
                    strcpy(ack_buffer, buffer);
                    printf("ACK : %s\n",buffer);
                }
                else{
                    strcpy(notification_buffer, buffer);
                    printf("notification : %s\n",buffer);
                }
            }
            else
            {
                printf("Maybe server is power off");
                exit(1);
            }
            
        }
    }
}
/**
 * void build_connectioin()
 * return: void
 * parameter: void
 * this function resets, connects and opens a socket.
 **/
void build_connection(char *serverIp, long port){
    struct sockaddr_in sin;                             //Socket structure for server
    
    bzero(&sin, sizeof(sin));                           //Set socket structures with null values.
    inet_pton(AF_INET, serverIp, &sin.sin_addr);
    sin.sin_port = htons(port);                         //Service Port: 28100
    
    if((s_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0){   //Open socket
        perror("Fail to open client socket!");
        exit(1);
    }
    
    /**
     * Connect to server.
     * int connect(int sock_desc, struct sockaddr *server_addr, int addrlen);
     * sock_desc: is client_desc.
     * server_addr: is a pointer to struct sockaddr that contains destination IP address and port.
     * addrlen: sizeof(struct sockaddr).
     **/
    if(connect(s_fd, (struct sockaddr *)&sin, sizeof(sin)) < 0){
        perror("Fail to connect!");
        exit(1);
    }
    else{
        puts("Connection established...");
        pthread_t rece_thread;
        memset(ack_buffer, 0, BUFFER_SIZE);
        memset(notification_buffer,0, BUFFER_SIZE);
        pthread_create(&rece_thread, NULL, &rece_fun, NULL);
    }
}

/**
 * void close_connectioin()
 * return: void
 * parameter: void
 * this function closes the socket, and sets s_fd to -1
 **/
void close_connection(){
    if(close(s_fd) < 0){
        perror("Fail to close connection!");
        exit(1);
    }
    s_fd = -1;
}

/**
 * void send_command(char *buffer)
 * return: void
 * parameter: buffer, a formatted string which contains the command to be sent
 * this function sends the command, and receives an acknowledment from the server.
 **/
void send_command(char *buffer){
    ssize_t len = 0;
    
    /**
     * Send data. Rreturns the number of bytes sent out, otherwise it will return -1 on error.
     * int send(int sock_desc, const void *msg, int len, int flags);
     * sock_desc: is client_desc returned by the socket function.
     * msg: is a pointer to the data, buffer is an array of characters.
     * len: is the length of the data you want to send (in bytes).
     * flags: is set to 0.
     **/
    len = send(s_fd, buffer, strlen(buffer) + 1, 1);
    if(len < 0){
        perror("Fail to send to data!");
        exit(1);
    }
}

/*
 get ack response
 */
char *receive_ack()
{
    char *buffer = malloc(BUFFER_SIZE);
    while (!strlen(ack_buffer));
    strcpy(buffer, ack_buffer);
    memset(ack_buffer, 0, BUFFER_SIZE);
//    printf("ACK : %s",buffer);
    return buffer;
}

/*
 get the notification data.
 */
char *receive_notification()
{
    char *buffer = malloc(BUFFER_SIZE);
    while (!strlen(notification_buffer));
    strcpy(buffer, notification_buffer);
    memset(notification_buffer, 0, BUFFER_SIZE);
//    printf("notification : %s",buffer);
    return buffer;
}
