//
//  RobotDriver.h
//  RobotDriver
//
//  Created by Judith Luo on 1/15/14.
//  Copyright (c) 2014 Judith Luo. All rights reserved.
//

#include "HWTE_RobotDriverLib.h"


/* getStatus */
HWTE_RobotResponse_t getStatus(HWTE_RobotHandle_t robot,
                               HWTE_RobotStatusType_t status,float period,HWTE_RobotStatusParameter_t *para,void *response);



#pragma mark Robot APIs

HWTE_RobotResponse_t enumerateDevices(HWTE_RobotDescriptor_t **devices, size_t *numDevices);
HWTE_RobotResponse_t getRobot(HWTE_RobotDescriptor_t const *descriptor, HWTE_RobotHandle_t *handle);
void                 putRobot(HWTE_RobotHandle_t *handle, HWTE_RobotDescriptor_t *descriptor);

#pragma mark Basic state control APIs

/* home */
HWTE_RobotResponse_t home(HWTE_RobotHandle_t robot);
HWTE_RobotResponse_t initialize(HWTE_RobotHandle_t robot);
HWTE_RobotResponse_t abortr(HWTE_RobotHandle_t robot);
HWTE_RobotResponse_t reset(HWTE_RobotHandle_t robot);

#pragma mark Transfer APIs

/* Create Transfer Jobs - pick, place, pp, go */
HWTE_RobotResponse_t requestTransfer(HWTE_RobotHandle_t robot, HWTE_RobotTransferRequest_t *xferRequest);

/* listjobs */
HWTE_RobotResponse_t listTransferJobs(HWTE_RobotHandle_t robot, HWTE_RobotTransferRequest_t **listedJobs, size_t *numListedJobs);

#pragma mark Notification APIs
/*
 * Notification APIs
 *
 * Calling registerForNotification() with an interval of 0
 * and a repeat of 'false' executes a single immediate callback.
 *
 * Implementation will require a run loop of some type in order
 * to service these notifications.
 */

HWTE_RobotResponse_t registerForNotification(HWTE_RobotHandle_t robot, HWTE_RobotNotificationType_t type, HWTE_RobotNotificationCallback_t cb, float interval, bool repeat, void* userInfo, HWTE_RobotTimerHandle_t *handle);
HWTE_RobotResponse_t cancelNotification(HWTE_RobotResponse_t robot, HWTE_RobotTimerHandle_t timer);

#pragma mark Mutator APIs

/* setMotorState */
HWTE_RobotResponse_t setMotorState(HWTE_RobotHandle_t robot, HWTE_RobotMotorState_t motorState);

/* setRopbotMode */
HWTE_RobotResponse_t setRobotMode(HWTE_RobotHandle_t robot, HWTE_RobotMode_t mode);

HWTE_RobotResponse_t setMaxSpeed(HWTE_RobotHandle_t robot, uint16_t maxSpeed);
/* setGripperPosition */
HWTE_RobotResponse_t setGripperPosition(HWTE_RobotHandle_t robot, HWTE_RobotGripperID_t gripper, HWTE_RobotGripperPosition_t gripperPosition);

#pragma mark Accessor APIs

HWTE_RobotResponse_t getMotorState(HWTE_RobotHandle_t robot, HWTE_RobotMotorState_t *motorState);
HWTE_RobotResponse_t getRobotMode(HWTE_RobotHandle_t robot, HWTE_RobotMode_t *mode);
/* getConfig */
HWTE_RobotResponse_t getConfig(HWTE_RobotHandle_t robot, HWTE_RobotConfigParameter_t param, HWTE_RobotConfigValue_t *configResponse, size_t *configSize);
HWTE_RobotResponse_t getErrors(HWTE_RobotHandle_t robot, HWTE_RobotResponse_t **errorList, size_t *numErrors);
HWTE_RobotResponse_t getMaxSpeed(HWTE_RobotHandle_t robot, uint16_t *maxSpeed);