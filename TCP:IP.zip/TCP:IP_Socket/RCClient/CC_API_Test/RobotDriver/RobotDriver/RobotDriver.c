//
//  RobotDriver.m
//  RobotDriver
//
//  Created by Judith Luo on 1/15/14.
//  Copyright (c) 2014 Judith Luo. All rights reserved.
//

#import "RobotDriver.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "CCConnection.h"

#define MESSAGE_ID_MIN  1
#define MESSAGE_ID_MAX  32767
#define LOCATION_ID_MAX 65535
#define BUFFER_SIZE     256                             //Buffer size

static unsigned int messageID = 1;                      //A unique number that identifies a command-response relationship

/* 
 responsestring likes "HWTE_RobotResponseAcknowledge"...
 convert enum string to int value
 */
int convert_chartoint(char *responsestring){
    int enumvalue = 0;
    if (!strcmp(responsestring, ACKNOWLEDGE)){
        enumvalue = 0;
    }
    else if(!strcmp(responsestring, MESSAGE_ID)){
        enumvalue = -1;
    }
    else if(!strcmp(responsestring, INVALID_CMD)){
        enumvalue = -2;
    }
    else if(!strcmp(responsestring, INVALID_JOBID)){
        enumvalue = -3;
    }
    else if(!strcmp(responsestring, INVALID_JOBTYPE)){
        enumvalue = -4;
    }
    else if(!strcmp(responsestring, INVALID_SOURCE)){
        enumvalue = -5;
    }
    else if(!strcmp(responsestring, INVALID_DES)){
        enumvalue = -6;
    }
    else if(!strcmp(responsestring, QUEUE_FULL)){
        enumvalue = -7;
    }
    else if(!strcmp(responsestring, LOCAL_MODE)){
        enumvalue = -8;
    }
    else if(!strcmp(responsestring, NOT_HOMED)){
        enumvalue = -9;
    }
    else if(!strcmp(responsestring, NOT_STRAINED)){
        enumvalue = -10;
    }
    else if(!strcmp(responsestring, NOT_DTRAINED)){
        enumvalue = -11;
    }
    else if(!strcmp(responsestring, STOP_PRESSED)){
        enumvalue = -12;
    }
    else{
        enumvalue = 1;
    }
    return enumvalue;
}

/* 
 parse ack, cut out the errorcode
 for pick/pp/place/goto action,response format :CmessageID,ack,jobID,errorCode<CR>
 */
HWTE_RobotResponse_t get_receivedata(){
    char *receivedata = receive_ack();
    char *response = strrchr(receivedata, ',');
    response++;
    char *errorcode = (char *)malloc(strlen(response)-2);   //delete /r/n
    snprintf(errorcode, strlen(response)-1,"%s", response);
    HWTE_RobotResponse_t responsevalue = atoi(errorcode);//convert_chartoint(errorcode);
//    if (response > 0) {                                  //in case of errorcode is nil or other abnormal
//        printf("%s -> %d",errorcode,responsevalue);
//    }
    free(receivedata);
    return responsevalue;
}


/* setConfigResponse */
void setConfigResponse(char* buffer, HWTE_RobotConfigValue_t *configResponse){
    *configResponse = strrchr(buffer, ',') + 1;
}


/* getStatus */
HWTE_RobotResponse_t getStatus(HWTE_RobotHandle_t robot,
                               HWTE_RobotStatusType_t status,float period,HWTE_RobotStatusParameter_t *para,void *response){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    char *period_string = (char *)malloc(sizeof(period) + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        
        switch (status) {
            case HWTE_RobotStatusType:
            {
                strcat(buffer, ",status");
                
                do {
                    switch (*para) {
                        case HWTE_RobotStatusMode:
                            strcat(buffer, ",mode");
                            break;
                        case HWTE_RobotStatusState:
                            strcat(buffer, ",state");
                            break;
                        case HWTE_RobotStatusHomed:
                            strcat(buffer, ",homed");
                            break;
                        case HWTE_RobotStatusCurrentJobID:
                            strcat(buffer, ",currentjobid");
                            break;
                        case HWTE_RobotStatusMotorStatus:
                            strcat(buffer, ",motorstatus");
                            break;
                        case HWTE_RobotStatusJobsInQueue:
                            strcat(buffer, ",jobsinqueue");
                            break;
                        case HWTE_RobotStatusEstop:
                            strcat(buffer, ",estop");
                            break;
                        case HWTE_RobotStatusTotalLocationIDs:
                            strcat(buffer, ",totallocationids");
                            break;
                        case HWTE_RobotStatusTaughtPositions:
                            strcat(buffer, ",taughtpositions");
                            break;
                        case HWTE_RobotStatusActiveConnections:
                            strcat(buffer, ",activeconnections");
                            break;
                        case HWTE_RobotStatusGripper1:
                            strcat(buffer, ",gripper1");
                            break;
                        case HWTE_RobotStatusVacuumgen1:
                            strcat(buffer, ",vacuumgen1");
                            break;
                        case HWTE_RobotStatusVacuumsensor1:
                            strcat(buffer, ",vacuumsensor1");
                            break;
                        case HWTE_RobotStatusCurrentPosition:
                            strcat(buffer, ",currentposition");
                            break;
                        case HWTE_RobotStatusPositionAxis1:
                            strcat(buffer, ",positionaxis1");
                            break;
                        case HWTE_RobotStatusPositionAxis2:
                            strcat(buffer, ",positionaxis2");
                            break;
                        case HWTE_RobotStatusPositionAxis3:
                            strcat(buffer, ",positionaxis3");
                            break;
                        case HWTE_RobotStatusPositionAxis4:
                            strcat(buffer, ",positionaxis4");
                            break;
                        case HWTE_RobotStatusPositionAxis5:
                            strcat(buffer, ",positionaxis5");
                            break;
                        case HWTE_RobotStatusPositionAxis6:
                            strcat(buffer, ",positionaxis6");
                            break;
                        default:
                            break;
                    }
                    
                    para++;
                }while(*para);
                break;
            }
            case HWTE_RobotStatusTypeStart:
            {
                strcat(buffer, ",statusstart,");
                snprintf(period_string, 10, "%g ", period);
                strcat(buffer, period_string);
                break;
            }
            case HWTE_RobotStatusTypeStop:
            {
                strcat(buffer, ",statusstop");
                break;
            }
            default:
                break;
        }
    }
    
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(period_string);
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}

#pragma mark Robot APIs

/*
 * send a command to server,
 * server should return a list of available robots, store those robots to an array devices
 */
HWTE_RobotResponse_t enumerateDevices(HWTE_RobotDescriptor_t **devices, size_t *numDevices)
{
    return 0;
}


HWTE_RobotResponse_t getRobot(HWTE_RobotDescriptor_t const *descriptor, HWTE_RobotHandle_t *handle)
{
    HWTE_RobotResponse_t response;
    /* compare handle information with descriptor */
    const char *name = descriptor->name;
    const char *location = descriptor->location;
    
    if((!strcmp(name, handle->descriptor.name) && !strcmp(location, handle->descriptor.location))
       && handle->lock == false)
    {
        handle->lock = true;
        response = 0;
    }
    else
        response = -2;
        
    return response;
}

void putRobot(HWTE_RobotHandle_t *handle, HWTE_RobotDescriptor_t *descriptor){
    
    /* compare handle information with descriptor */
    const char *name = descriptor->name;
    const char *location = descriptor->location;
    
    if(!strcmp(name, handle->descriptor.name) && !strcmp(location, handle->descriptor.location))
        handle->lock = false;
        
    return;
}

#pragma mark Basic state control APIs

HWTE_RobotResponse_t home(HWTE_RobotHandle_t robot){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",Home");
        
        messageID++;
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}
HWTE_RobotResponse_t initialize(HWTE_RobotHandle_t robot){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",initialize");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}
HWTE_RobotResponse_t abortr(HWTE_RobotHandle_t robot){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",abort");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}
HWTE_RobotResponse_t reset(HWTE_RobotHandle_t robot){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",reset");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}

#pragma mark Transfer APIs

/*
 send pick/place/pp cmd to robot
 */
HWTE_RobotResponse_t requestTransfer(HWTE_RobotHandle_t robot,
                                     HWTE_RobotTransferRequest_t *xferRequest){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    char *s_id = (char *)malloc(sizeof(xferRequest->source) + 1);
    char *d_id = (char *)malloc(sizeof(xferRequest->destination) + 1);
    snprintf(command_id, sizeof(command_id), "%d", messageID);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else
    {
        HWTE_RobotMovementType_t action_type = xferRequest->type;
        switch (action_type) {
            case HWTE_RobotJobTypePick:
            {
                snprintf(s_id, 10, "%d", xferRequest->source);
                strcpy(buffer, command_id);
                strcat(buffer, ",createjob,pick,");
                strcat(buffer,s_id);
                break;
            }
            case HWTE_RobotJobTypePlace:
            {
                snprintf(d_id, 10, "%d", xferRequest->destination);
                strcpy(buffer, command_id);
                strcat(buffer, ",createjob,place,");
                strcat(buffer,d_id);
                break;
            }
            case HWTE_RobotJobTypePickPlace:
            {
                snprintf(s_id, 10, "%d", xferRequest->source);
                snprintf(d_id, 10, "%d", xferRequest->destination);
                strcpy(buffer, command_id);
                strcat(buffer, ",createjob,pp,");
                strcat(buffer, s_id);
                strcat(buffer, ",");
                strcat(buffer, d_id);
                break;
            }
            case HWTE_RobotJobTypeGoto:
            {
                snprintf(d_id, 10, "%d", xferRequest->destination);
                strcpy(buffer, command_id);
                strcat(buffer, ",createjob,go,");
                strcat(buffer,d_id);
                break;
            }
            default:
                break;
        }
        
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(d_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    return receive_cmd;
}

/*
 send listjobs cmd to robot,still didn't parse the response.
 */
HWTE_RobotResponse_t listTransferJobs(HWTE_RobotHandle_t robot,
                                      HWTE_RobotTransferRequest_t **listedJobs,
                                      size_t *numListedJobs){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",listjobs");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();//need
    messageID++;
    return receive_cmd;
}
#pragma mark Notification APIs
HWTE_RobotResponse_t registerForNotification(HWTE_RobotHandle_t robot, HWTE_RobotNotificationType_t type, HWTE_RobotNotificationCallback_t cb, float interval, bool repeat, void* userInfo, HWTE_RobotTimerHandle_t *handle)
{
    return 0;
}
HWTE_RobotResponse_t cancelNotification(HWTE_RobotResponse_t robot, HWTE_RobotTimerHandle_t timer)
{
    return 0;
}

#pragma mark Mutator APIs

/*
 send motorsoff/motorson cmd to robot
 */

HWTE_RobotResponse_t setMotorState(HWTE_RobotHandle_t robot,
                                   HWTE_RobotMotorState_t motorState){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        
        switch (motorState)
        {
            case HWTE_RobotMotorsOff:
                strcat(buffer, ",motorsoff");
                break;
            case HWTE_RobotMotorsOn:
                strcat(buffer, ",motorson");
                break;
            default:
                break;
        }
    }
    
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}


/*
 send local/remote cmd to robot
 */
HWTE_RobotResponse_t setRobotMode(HWTE_RobotHandle_t robot,
                                  HWTE_RobotMode_t mode){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        switch (mode) {
            case HWTE_RobotModeLocal:
                strcat(buffer, ",local");
                break;
            case HWTE_RobotModeRemote:
                strcat(buffer, ",remote");
                break;
            default:
                break;
        }
    }
    
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}

HWTE_RobotResponse_t setMaxSpeed(HWTE_RobotHandle_t robot, uint16_t maxSpeed){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    char *sMaxSpeed = (char *)malloc(sizeof(maxSpeed)+1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",setmaxspeed,");
        sprintf(sMaxSpeed,"%d",maxSpeed);
        strcat(buffer,sMaxSpeed);
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    free(sMaxSpeed);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}
/* setGripperPosition */
HWTE_RobotResponse_t setGripperPosition(HWTE_RobotHandle_t robot,
                                        HWTE_RobotGripperID_t gripper,
                                        HWTE_RobotGripperPosition_t gripperPosition){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *gripper_id = (char *)malloc(sizeof(gripper) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        snprintf(gripper_id, sizeof(gripper_id), "%d", gripper);
        strcpy(buffer, command_id);
        
        switch (gripperPosition) {
            case HWTE_RobotUnGrip:
                strcat(buffer, ",ungrip,");
                break;
            case HWTE_RobotGrip:
                strcat(buffer, ",grip,");
                break;
            default:
                break;
        }
        
    }
    strcat(buffer, gripper_id);
    
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(gripper_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}

#pragma mark Accessor APIs

HWTE_RobotResponse_t getMotorState(HWTE_RobotHandle_t robot, HWTE_RobotMotorState_t *motorState){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",status,motorstatus");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;

}
HWTE_RobotResponse_t getRobotMode(HWTE_RobotHandle_t robot, HWTE_RobotMode_t *mode){
    
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",status,mode");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}
/* getConfig */
HWTE_RobotResponse_t getConfig(HWTE_RobotHandle_t robot,
                               HWTE_RobotConfigParameter_t param,
                               HWTE_RobotConfigValue_t *configResponse,
                               size_t *configSize){
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",reportconfig,");
        
        switch (param) {
            case HWTE_RobotConfigManufacturerID:
                strcat(buffer, ",ManufacturerID");
                break;
            case HWTE_RobotConfigConfigID:
                strcat(buffer, ",ConfigurationID");
                break;
            case HWTE_RobotConfigNumLocations:
                strcat(buffer, ",NumberOfLocations");
                break;
            case HWTE_RobotConfigProtocolVersion:
                strcat(buffer, ",ProtocolVersion");
                break;
            case HWTE_RobotConfigControllerVersion:
                strcat(buffer, ",RCSoftwareVersion");
                break;
            case HWTE_RobotConfigMaxTCPConnections:
                strcat(buffer, ",maxTCPconnections");
                break;
            case HWTE_RobotConfigNumOpenTCPConnections:
                strcat(buffer, ",currentlyOpenTCPconnections");
                break;
            default:
                break;
        }
    }
    
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    /* call setConfigResponse somewhere after a thread handles recv() */
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;
}

/*
 In case of multiple errorcodes
 */
HWTE_RobotResponse_t getErrors(HWTE_RobotHandle_t robot, HWTE_RobotResponse_t **errorList, size_t *numErrors){
    int i = 0;
    HWTE_RobotResponse_t errorcode[ERRORCODE_NUM];
    char buffer[] = "4,act,jobID,HWTE_RobotResponseInvalidMessageID,HWTE_RobotResponseAcknowledge,HWTE_RobotResponseInvalidCommand";
    char *seperator = strtok(buffer, ",");
    printf("seperator is %s",seperator);
    while (seperator) {
        if (strstr(seperator, CMP_STR)) {
            HWTE_RobotResponse_t  responsevalue = atoi(seperator);
            errorcode[i++] = responsevalue;
        }
        seperator = strtok(NULL, ",");
    }
    *errorList = errorcode;
    for (int j = 0; j < 3; j++) {
        printf("test result is %d,%d \n",j,*(*errorList+j));
    }
    *numErrors = i;
    
    return 0;
}
HWTE_RobotResponse_t getMaxSpeed(HWTE_RobotHandle_t robot, uint16_t *maxSpeed)
{
    char *command_id = (char *)malloc(sizeof(messageID) + 1);
    char *buffer = (char *)malloc(BUFFER_SIZE + 1);
    if(messageID >= MESSAGE_ID_MAX){
        messageID = MESSAGE_ID_MIN;
    }
    else{
        snprintf(command_id, sizeof(command_id), "%d", messageID);
        strcpy(buffer, command_id);
        strcat(buffer, ",getmaxspeed");
    }
    strcat(buffer, "\r");
    send_command(buffer);
    
    free(command_id);
    free(buffer);
    
    HWTE_RobotResponse_t receive_cmd = get_receivedata();
    messageID++;
    
    return receive_cmd;

}