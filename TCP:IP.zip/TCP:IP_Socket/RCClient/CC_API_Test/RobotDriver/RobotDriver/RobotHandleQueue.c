//
//  commandQueue.c
//  RCSimulator
//
//  Created by Jen-Wei Peng on 1/8/14.
//  Copyright (c) 2014 Jen-Wei Peng. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "RobotHandleQueue.h"

/* Allocate the head queue node */
QUEUE* createQueue(void) {
    
    QUEUE* handleQueue = (QUEUE*)malloc(sizeof(QUEUE));
    
    /* Initialize the allocated head */
    if(handleQueue) {
        handleQueue->front = NULL;
        handleQueue->rear = NULL;
        handleQueue->count = 0;
    }
    
    return handleQueue;
} /* createQueue */

/* Insert command to command queue */
bool Enqueue(QUEUE* handleQueue, HWTE_RobotHandle_t *handlePtr) {
    
    QUEUE_NODE* newHandle;
    
    /* Return false if fall to allocate memory for newCommand */
    if( !(newHandle = (QUEUE_NODE*)malloc(sizeof(QUEUE_NODE))) ) {
        return false;
    }
    /* Initialize newCommand */
    newHandle->index = -1;
    newHandle->next = NULL;
    newHandle->handlePtr = handlePtr;
    
    newHandle->index = handleQueue->count;
    
    if(handleQueue->count == 0)
        handleQueue->front = newHandle;
    else
        handleQueue->rear->next = newHandle;
    
    handleQueue->rear = newHandle;
    (handleQueue->count)++;
    
    return true;
} /* enqueue */

/* Don't use for handleQueue.
 * Delete command from command queue 
 */
bool dequeue(QUEUE* handleQueue, HWTE_RobotHandle_t **handlePtr) {
    
    QUEUE_NODE* nodeToBeDeleted;
    
    /* Return false if command queue is empty */
    if(!handleQueue->count)
        return false;
    
    *handlePtr = handleQueue->front->handlePtr;
    nodeToBeDeleted = handleQueue->front;
    
    /* Just delete first node if there is only command in the queue */
    if(handleQueue->count == 1){
        handleQueue->front = NULL;
        handleQueue->rear = NULL;
    }
    else {
        handleQueue->front = handleQueue->front->next;
    }
    
    /* Update count and free nodeToBeDeleted */
    (handleQueue->count)--;
    free(nodeToBeDeleted);
    
    return true;
} /* dequeue */

/* Check if command queue is empty */
bool emptyQueue(QUEUE* handleQueue){
    
    return (handleQueue->count == EMPTY_QUEUE);
} /* emptyQueue */

/* Check if command queue is full */
bool fullQueue(QUEUE* handleQueue){
    
    return (handleQueue->count == COMMAND_QUEUE_SIZE);
} /* fullQueue */

/* Return the number of commands in the queue */
int queueCount(QUEUE* handleQueue){
    
    return (handleQueue->count);
} /* queueCount */

int getIndex(QUEUE* handleQueue, HWTE_RobotHandle_t *handle)
{
    QUEUE_NODE *walker = handleQueue->front;
    
    while(walker->next != NULL)
    {
        const char *name = walker->handlePtr->descriptor.name;
        const char *location = walker->handlePtr->descriptor.location;
        
        if(!strcmp(name, handle->descriptor.name) && !strcmp(location, handle->descriptor.location))
            return walker->index;
        
        walker = walker->next;
    }
    
    return -1;
}

/* Free all data from the command queue, then free the command queue */
QUEUE* destroyQueue(QUEUE* handleQueue) {
    
    QUEUE_NODE* nodeToBeDeleted;
    
    /* if command queue is allocated */
    if(handleQueue) {
        while(handleQueue->front) {
            free(handleQueue->front->handlePtr);
            nodeToBeDeleted = handleQueue->front;
            handleQueue->front = handleQueue->front->next;
            free(nodeToBeDeleted);
        }
        
        free(handleQueue);
    }
    
    return NULL;
} /* destroyQueue */






