//
//  CCConnection.h
//  RCClient
//
//  Created by karl on 12/17/13.
//  Copyright (c) 2013 Jenwei Peng. All rights reserved.
//

#ifndef RCClient_CCConnection_h
#define RCClient_CCConnection_h

/* send pick/place/pp ...cmds to RC server */
void send_command(char *buffer);

/* connect RC server with specified IP and Port */
void build_connection(char *serverIp, long port);

/* disconnect RC server */
void close_connection();

/* receive acknowledge response */
char *receive_ack();

/* receive notification response */
char *receive_notification();
#endif
