//
//  commandQueue.h
//  RCSimulator
//
//  Created by Jen-Wei Peng on 1/8/14.
//  Copyright (c) 2014 Jen-Wei Peng. All rights reserved.
//

#ifndef RCSimulator_commandQueue_h
#define RCSimulator_commandQueue_h
#define COMMAND_QUEUE_SIZE 4
#define EMPTY_QUEUE 0

#include <stdbool.h>
#include "HWTE_RobotDriverLib.h"

typedef struct node {
    int                 index;
    HWTE_RobotHandle_t  *handlePtr;
    struct node         *next;
} QUEUE_NODE;

typedef struct {
    int         count;
    QUEUE_NODE  *front;
    QUEUE_NODE  *rear;
} QUEUE;

/* Helper function declarations */

QUEUE *createQueue(void);
QUEUE *destroyQueue(QUEUE *handleQueue);
int   getIndex(QUEUE* handleQueue, HWTE_RobotHandle_t *handle);
bool  Enqueue(QUEUE *handleQueue, HWTE_RobotHandle_t *handlePtr);
bool  dequeue(QUEUE *handleQueue, HWTE_RobotHandle_t **handlePtr);
bool  emptyQueue(QUEUE *handleQueue);
bool  fullQueue(QUEUE *handleQueue);
int   queueCount(QUEUE *handleQueue);

#endif
