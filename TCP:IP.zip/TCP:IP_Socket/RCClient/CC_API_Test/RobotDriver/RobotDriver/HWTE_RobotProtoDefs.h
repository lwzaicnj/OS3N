#ifndef RCClient_HWTE_RobotProtoDefs_h
#define RCClient_HWTE_RobotProtoDefs_h

#include <stdint.h>

// negative values denote errors, non-negative values denote success

typedef enum {
    HWTE_RobotResponseMultipleErrors = -13,
    HWTE_RobotResponseStopPressed = -12,
    HWTE_RobotResponseDestinationNotTrained = -11,
    HWTE_RobotResponseSourceNotTrained = -10,
    HWTE_RobotResponseNotHomed = -9,
    HWTE_RobotResponseLocalMode = -8,
    HWTE_RobotResponseTransferQueueFull = -7,
    HWTE_RobotResponseInvalidDestination = -6,
    HWTE_RobotResponseInvalidSource = -5,
    HWTE_RobotResponseInvalidJobType = -4,
    HWTE_RobotResponseInvalidJobID = -3,
    HWTE_RobotResponseInvalidCommand = -2,
    HWTE_RobotResponseInvalidMessageID = -1,
    HWTE_RobotResponseAcknowledge = 0,
    HWTE_RobotResponseOK = 0
} HWTE_RobotResponse_t;

#endif
