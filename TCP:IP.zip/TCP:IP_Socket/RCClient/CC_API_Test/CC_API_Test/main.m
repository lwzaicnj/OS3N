//
//  main.m
//  CC_API_Test
//
//  Created by Judith Luo on 1/14/14.
//  Copyright (c) 2014 Judith Luo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
