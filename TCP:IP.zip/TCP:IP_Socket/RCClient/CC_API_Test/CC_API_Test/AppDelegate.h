//
//  AppDelegate.h
//  CC_API_Test
//
//  Created by Judith Luo on 1/14/14.
//  Copyright (c) 2014 Judith Luo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
    NSMutableArray *actionArray;
    __weak NSTextField *_serverIP;
    __weak NSTextField *_serverPort;
    
    __weak NSTextField *_pickLocationID;
    __weak NSTextField *_placeLocationID;
    __weak NSTextField *_ppSLocation;
    __weak NSTextField *_ppDLocation;
    
    __weak NSMatrix *_motorSwitch;
    __weak NSMatrix *_modeSwitch;
    __weak NSMatrix *_gripSwitch;
    
    __weak NSMatrix *_statusSwitch;
    
    __weak NSComboBox *_configPara;
    
    __weak NSTextField *_gripID;
    __weak NSTextField *_statusPeriod;
    __weak NSTextField *_statusPata;
    
    __unsafe_unretained NSTextView *_showResponse;
    
}

@property (assign) IBOutlet NSWindow *window;


@property (weak) IBOutlet NSTextField *serverIP;
@property (weak) IBOutlet NSTextField *serverPort;
@property (weak) IBOutlet NSTextField *pickLocationID;
@property (weak) IBOutlet NSTextField *placeLocationID;
@property (weak) IBOutlet NSTextField *ppSLocation;
@property (weak) IBOutlet NSTextField *ppDLocation;
@property (weak) IBOutlet NSMatrix *motorSwitch;
@property (weak) IBOutlet NSMatrix *modeSwitch;
@property (weak) IBOutlet NSMatrix *gripSwitch;
@property (weak) IBOutlet NSComboBox *configPara;
@property (weak) IBOutlet NSTextField *statusPeriod;
@property (weak) IBOutlet NSMatrix *statusSwitch;
@property (weak) IBOutlet NSTextField *statusPata;
@property (unsafe_unretained)IBOutlet NSTextView *textView;

- (IBAction)Choose_action:(id)sender;
- (IBAction)Connect_server:(id)sender;
- (IBAction)Disconnect_server:(id)sender;

- (IBAction)Run_allActions:(id)sender;


@property (unsafe_unretained) IBOutlet NSTextView *showResponse;
@property (weak) IBOutlet NSTextField *gripID;
@end
