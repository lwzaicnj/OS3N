//
//  AppDelegate.m
//  CC_API_Test
//
//  Created by Judith Luo on 1/14/14.
//  Copyright (c) 2014 Judith Luo. All rights reserved.
//

#import "AppDelegate.h"
#import <RobotDriver/RobotDriver.h>
#import <RobotDriver/CCConnection.h>
@implementation AppDelegate
#define TIMERINTERVEL_REFRESH 0.1

@synthesize serverIP = _serverIP;
@synthesize serverPort = _serverPort;
@synthesize pickLocationID = _pickLocationID;
@synthesize placeLocationID = _placeLocationID;
@synthesize ppSLocation = _ppSLocation;
@synthesize ppDLocation = _ppDLocation;

@synthesize showResponse = _showResponse;


//bool contin = YES;
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    actionArray = [[NSMutableArray alloc] init];
    // Insert code here to initialize your application

}
-(void)refreshResult
{
    char *value = receive_notification();
    while (1)
    {
        if(value)
        {
            [_showResponse setString:[NSString stringWithFormat:@"%@\n %s",_showResponse.string,value]];
            value = nil;
        }
        else
        {
            value = receive_notification();
//            NSString *complete = [NSString stringWithUTF8String:value];
//            if ([complete rangeOfString:@",jobcompleted,"].length)
//            {
//                contin = YES;
//            }
            
        }
    }
    
}
- (IBAction)Choose_action:(id)sender {
    NSButton *selected = (NSButton *)sender;
    NSString *selectedTitle = selected.title;
    if (selected.state)
    {
        [actionArray addObject:selectedTitle];
    }
    else
    {
        [actionArray removeObject:selectedTitle];
    }
}

- (IBAction)Connect_server:(id)sender {
    const char *serIp = [[_serverIP stringValue] UTF8String];
    long port = [_serverPort.stringValue longLongValue];
    build_connection((char *)serIp, port);
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(refreshResult) object:nil];
    [thread start];
    

}

- (IBAction)Disconnect_server:(id)sender {
    close_connection();
    
}

- (IBAction)Run_allActions:(id)sender
{
    HWTE_RobotTransferRequest_t xfre;
    HWTE_RobotResponse_t responseAck;
    HWTE_RobotHandle_t robot ;
    
    for(NSString *title in actionArray)
    {
        if ([title isEqualToString:@"Pick"])
        {
            int locationID = [_pickLocationID.stringValue intValue];
            xfre.source =locationID;
            xfre.type = HWTE_RobotJobTypePick;
            responseAck = requestTransfer(robot, &xfre);
        }
        else if ([title isEqualToString:@"Place"])
        {
            int locationID = [_placeLocationID.stringValue intValue];
            xfre.destination =locationID;
            xfre.type = HWTE_RobotJobTypePlace;
            responseAck = requestTransfer(robot, &xfre);
        }
        else if ([title isEqualToString:@"PickPlace"])
        {
            int sLocationID = [_ppSLocation.stringValue intValue];
            int dLocationID = [_ppDLocation.stringValue intValue];
            xfre.source =sLocationID;
            xfre.destination = dLocationID;
            xfre.type = HWTE_RobotJobTypePickPlace;
            responseAck = requestTransfer(robot, &xfre);
        }
        else if ([title isEqualToString:@"Motor Power"])
        {
            HWTE_RobotMotorState_t state = (int)_motorSwitch.selectedTag;
            responseAck = setMotorState(robot, state);
        }
        else if ([title isEqualToString:@"Robot Mode"])
        {
            HWTE_RobotMode_t mode = (int)_modeSwitch.selectedTag;
            responseAck = setRobotMode(robot, mode);
        }
        else if ([title isEqualToString:@"Gripper control"])
        {
            HWTE_RobotGripperID_t gripID = [_gripID.stringValue intValue];
            HWTE_RobotGripperPosition_t gripPosition = (int)_gripSwitch.selectedTag;
            responseAck = setGripperPosition(robot, gripID, gripPosition);
        }
        else if ([title isEqualToString:@"Home"])
        {
            responseAck = home(robot);
        }
        else if ([title isEqualToString:@"List Jobs"])
        {
            HWTE_RobotTransferRequest_t *listJobs;
            size_t numJobs;
            responseAck = listTransferJobs(robot, &listJobs, &numJobs);
        }
        else if ([title isEqualToString:@"Report Configuration"])
        {
            HWTE_RobotConfigParameter_t config = [_configPara.objectValueOfSelectedItem intValue];
            HWTE_RobotConfigValue_t configResponse;
            size_t size;
            responseAck = getConfig(robot, config, &configResponse,&size);
        }
        else if ([title isEqualToString:@"Status Commands"])
        {
            HWTE_RobotStatusType_t statusType = (int)_statusSwitch.selectedTag;
            void *responseVaule;
            switch (statusType) {
                case 0:     //status
                {
                    NSArray *arrayPara = [_statusPata.stringValue componentsSeparatedByString:@","];
                    NSUInteger size = [arrayPara count];
                    HWTE_RobotStatusParameter_t statusPara[size];
                    for (int i = 0; i < size; i++)
                    {
                        statusPara[i] = (int)[arrayPara objectAtIndex:i];
                    }
                    responseAck = getStatus(robot, statusType, 0, statusPara,&responseVaule);
                    break;
                }
                case 1: //statusstart
                {
                   float period = [_statusPeriod.stringValue floatValue];
                    responseAck = getStatus(robot, statusType, period, nil,&responseVaule);
                    break;
                }
                case 2: //statusstop
                {
                    responseAck = getStatus(robot, statusType, 0, nil,&responseVaule);
                    break;
                }
                default:
                    break;
            }
        }
        [_showResponse setString:[NSString stringWithFormat:@"%@\nAck is %d\n",_showResponse.string,responseAck]];
    }
}

- (IBAction)Run_loop:(id)sender {
    HWTE_RobotTransferRequest_t xfre;
    HWTE_RobotResponse_t responseAck;
    HWTE_RobotHandle_t robot;
    int sLocationID = [_pickLocationID.stringValue intValue];
    int dLocationID = [_placeLocationID.stringValue intValue];
    int status = 0;
    int failCount = 0;
    while (1)
    {
        for(NSString *title in actionArray)
        {
            sleep(3);
//            while (!contin)
//            {
//                usleep(1000);
//            }
            //contin = NO;
            if ([title isEqualToString:@"Pick"])
            {
                
                xfre.source =sLocationID;
                xfre.type = HWTE_RobotJobTypePick;
                responseAck = requestTransfer(robot, &xfre);
            }
            else if ([title isEqualToString:@"Place"])
            {
                xfre.destination =dLocationID;
                xfre.type = HWTE_RobotJobTypePlace;
                
                responseAck = requestTransfer(robot, &xfre);
                
                int value = 0;
                value = dLocationID;
                dLocationID = sLocationID;
                sLocationID = value;
//                dLocationID = [_pickLocationID.stringValue intValue];
//                sLocationID = [_placeLocationID.stringValue intValue];
            }
            else if ([title isEqualToString:@"PickPlace"])
            {
                int sLocationID = 0;
                int dLocationID = 0;
                switch (status) {
                    case 0:
                    {
                        sLocationID = 17;
                        dLocationID = 1;
                        xfre.source =sLocationID;
                        xfre.destination = dLocationID;
                        xfre.type = HWTE_RobotJobTypePickPlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 1:
                    {
                        sLocationID = 17;
                        dLocationID = 2;
                        xfre.source =sLocationID;
                        xfre.destination = dLocationID;
                        xfre.type = HWTE_RobotJobTypePickPlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 2:
                    {
                        sLocationID = 17;
                        dLocationID = 3;
                        xfre.source =sLocationID;
                        xfre.destination = dLocationID;
                        xfre.type = HWTE_RobotJobTypePickPlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 3:
                    {
                        sLocationID = 17;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 4:
                    {
                        sLocationID = 1;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 5:
                    {
                        sLocationID = 0;
                        dLocationID = 1;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 6:
                    {
                        if (failCount == 5)
                        {
                            dLocationID = 22;
                            failCount = 0;
                        }
                        else
                            dLocationID = 21;
                        sLocationID = 0;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        failCount++;
                        break;
                    }
                    case 7:
                    {
                        sLocationID = 17;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 8:
                    {
                        sLocationID = 2;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 9:
                    {
                        sLocationID = 0;
                        dLocationID = 2;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 10:
                    {
                        if (failCount == 5)
                        {
                            dLocationID = 22;
                            failCount = 0;
                        }
                        else
                            dLocationID = 21;
                        sLocationID = 0;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        failCount++;
                        break;
                    }
                    case 11:
                    {
                        sLocationID = 17;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 12:
                    {
                        sLocationID = 3;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 13:
                    {
                        sLocationID = 0;
                        dLocationID = 3;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        break;
                    }
                    case 14:
                    {
                        if (failCount == 5)
                        {
                            dLocationID = 22;
                            failCount = 0;
                        }
                        else
                            dLocationID = 21;
                        sLocationID = 0;
                        xfre.destination =dLocationID;
                        xfre.type = HWTE_RobotJobTypePlace;
                        responseAck = requestTransfer(robot, &xfre);
                        status++;
                        failCount++;
                        break;
                    }
                    case 15:
                    {
                        sLocationID = 17;
                        dLocationID = 0;
                        xfre.source =sLocationID;
                        xfre.type = HWTE_RobotJobTypePick;
                        responseAck = requestTransfer(robot, &xfre);
                        status = 4;
                        break;
                    }
                        
                    default:
                        break;
                }
                /*int sLocationID = [_ppSLocation.stringValue intValue];
                int dLocationID = [_ppDLocation.stringValue intValue];
                xfre.source =sLocationID;
                xfre.destination = dLocationID;
                xfre.type = HWTE_RobotJobTypePickPlace;
                responseAck = requestTransfer(robot, &xfre);*/
            }
//            else
//            {
//                contin = YES;
//            }

            
        }
    }
    
}

@end
