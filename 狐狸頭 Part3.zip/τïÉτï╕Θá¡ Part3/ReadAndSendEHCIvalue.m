//
//  ReadAndSendEHICvalue.m
//  iFTS
//
//  Created by Ray Hsu on 2011/11/22.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ReadAndSendEHCIvalue.h"
#import "Pudding.h"


@implementation TestItemParse(ReadAndSendEHCIvalueFun)

+(void)ReadAndSendEHCIvalue:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	
	NSString *mXactErr = nil;
	NSString *mBabble = nil;
	NSString *mBufferError = nil;
	NSString *mHalted = nil;
	NSString *mActive = nil;
	NSString *mIterations = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	/********************************************************************************************************/
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString* mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" "  withString:@""];
	/********************************************************************************************************/
	
	NSArray *counterArray = [mReferenceBufferValue componentsSeparatedByString:@"counter"];
	
	int counterNum = [counterArray count];
	
	/********************************************************************************************************/
	NSRange range;
	//1
	range = [mReferenceBufferValue rangeOfString: @"XactErr-"];
	if(range.length > 0)
		mXactErr = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"XactErr-" Postfix:@"counter"];
	else
		mXactErr = nil;
	//2	
	range = [mReferenceBufferValue rangeOfString: @"Babble-"];
	if(range.length > 0)
		mBabble = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"Babble-" Postfix:@"counter"];
	else
		mBabble = nil;
	//3
	range = [mReferenceBufferValue rangeOfString: @"BufferError-"];
	if(range.length > 0)
		mBufferError = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"BufferError-" Postfix:@"counter"];
	else
		mBufferError = nil;
	//4
	range = [mReferenceBufferValue rangeOfString: @"Halted-"];
	if(range.length > 0)
		mHalted = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"Halted-" Postfix:@"counter"];
	else
		mHalted = nil;
	//5
	range = [mReferenceBufferValue rangeOfString: @"Active-"];
	if(range.length > 0)
	{
		if(counterNum > 6)
			mActive = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"Active-" Postfix:@"counter"];
		else
			mActive = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"Active-" Postfix:@":-)"];
	}
	else
		mActive = nil;
	//6
	range = [mReferenceBufferValue rangeOfString: @"Iterations-"];
	if(range.length > 0)
		mIterations = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"Iterations-" Postfix: @":-)"];
	else
		mIterations = nil;
	/********************************************************************************************************/

	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.XactErr":nil:nil:nil:mXactErr:nil:IP_PASS:@"PASS"];
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.Babble":nil:nil:nil:mBabble:nil:IP_PASS:@"PASS"];
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.BufferError":nil:nil:nil:mBufferError:nil:IP_PASS:@"PASS"];
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.Halted":nil:nil:nil:mHalted:nil:IP_PASS:@"PASS"];
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.Active":nil:nil:nil:mActive:nil:IP_PASS:@"PASS"];
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"QtdStatus.Iterations":nil:nil:nil:mIterations:nil:IP_PASS:@"PASS"];

	/********************************************************************************************************/
	
	NSString *tmpUIInfo = @"Pass, ActiveCounter:";
	tmpUIInfo = [tmpUIInfo stringByAppendingString:mActive];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS: tmpUIInfo];
	
	
}

@end
