//
//  RS232ReadStrOnlyFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "RS232ReadStrOnlyFunction.h"


@implementation TestItemParse(RS232ReadStrOnlyFunction)

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: SpecialParseMK.m 
 | $Author::CaiJunbo                    $Revision:: 1               
 | CREATED: 2010.03.24                  $Modtime::  16:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :RS232 communication Method
 
 PURPOSE :Read strigs from communication channel,without sending strings out.
 
 $History:: SpecialParseMK.m                                              
 * *****************  Version 1  *****************
 * User: CaiJunbo           Date: 2010.03.24   Time: 16:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

+(void)RS232ReadStrOnly:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	
	NSString *mDevice		= nil    ;
	NSString *mBufferName	= nil    ;
	NSString *mPDCAWrite	= @"no"  ;
    NSString *mTimeOut		= @"6"   ;
	NSString *mTestItemName	= nil    ;
	NSString *mPostfix		= nil	 ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [DictionaryPtr objectForKey:strKey] ;
			mDevice = [TestItemParse getDeviceID:mDevice :DictionaryPtr] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	if (mDevice==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	/*
	 SCRID:128
	 add by caijunbo on 2011-08-07
	 Description:It is mainly used to enable postfix for RS232ReadStrOnly parser
	 */
	if(mPostfix!=nil)
	{
		NSString* nsstrDeviceID=nil;
		if([mDevice rangeOfString:@"IPad"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"UNITDevice"];
		}
		if([mDevice rangeOfString:@"Fixture"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"FixtureDevice"];
		}
		NSString* nsstrKey=@"EndString";
		CommManage *commTmp=[self getCommManage] ;
		[commTmp SetCurrentKeyUsed:nsstrDeviceID :nsstrKey :mPostfix];
	}
	/*
	 SCRID:128
	 END
	 */
	
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = [mTimeOut intValue] ;
    if(iTmp != 0)//Rick add to read data for no delay 20131127
    {
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:DictionaryPtr]) 
                break ;
            else
                // modify by Evan on 2011-08-09;
                //	usleep(500000) ; //delay 500
                usleep(100000) ;
            // modify end;
        }
    }
	//read data
	NSString *dataResult = [self ReceData:DictionaryPtr] ;
	if (dataResult!=nil)
	{
		
		if (mBufferName !=nil)
		{
			[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
		}
	}
	else
    {
        if (mBufferName != nil) 
            [TestItemManage setBufferValue:DictionaryPtr :mBufferName :@""];//blake add for different parse use the same buffer name result fade pass.
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Port have no data"] ;
    }
	return ;

}
//RS232ReadStrOnlyEvery50ms,and judge if contain some string that not be allowed    ---add by Annie 2012-11-23
+(void)RS232ReadStrOnlyEvery50ms:(NSDictionary*) DictionaryPtr
{
	
    NSDate *dateTimeTmp=[[[NSDate alloc] init] autorelease] ;
    
	NSString *mTestItemName	= nil    ;
	NSString *mDevice		= nil    ;
	NSString *mBufferName	= nil    ;
	//NSString *mPDCAWrite	= @"no"  ;
    NSString *mTimeOut		= @"2.4"   ;	
	NSString *mPostfix		= nil	 ;
	NSString *mContainString=@"";
	NSString *mNotContainString=nil;
	NSString *mBufferNameTestTime		= nil	 ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [DictionaryPtr objectForKey:strKey] ;
			mDevice = [TestItemParse getDeviceID:mDevice :DictionaryPtr] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameTestTime"])
		{
			mBufferNameTestTime = [DictionaryPtr objectForKey:strKey] ;
		}
		/*else if ([strKey isEqualToString:@"PDCAWrite"])
         {
         mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
         }*/
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ContainString"])
		{
			mContainString = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"NotContainString"])
		{
			mNotContainString = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	if (mDevice==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	/*
	 SCRID:128
	 add by caijunbo on 2011-08-07
	 Description:It is mainly used to enable postfix for RS232ReadStrOnly parser
	 */
	if(mPostfix!=nil)
	{
		NSString* nsstrDeviceID=nil;
		if([mDevice rangeOfString:@"IPad"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"UNITDevice"];
		}
		if([mDevice rangeOfString:@"Fixture"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"FixtureDevice"];
		}
		NSString* nsstrKey=@"EndString";
		CommManage *commTmp=[self getCommManage] ;
		[commTmp SetCurrentKeyUsed:nsstrDeviceID :nsstrKey :mPostfix];
	}
	/*
	 SCRID:128
	 END
	 */
	
	float floatTestTime = 0;
	
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	float iTmp = [mTimeOut floatValue] ;
	float timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:DictionaryPtr]) 
			break ;
		else
		{
			usleep(20000) ; //delay 20
			[TestItemManage setUnitLogInfo:DictionaryPtr :@"----> wait for 20ms":true];
			//floatTestTime = floatTestTime + 0.02;
			[TestItemManage setUnitLogInfo:DictionaryPtr :[NSString stringWithFormat:@"---->%f",floatTestTime]:true];
		}
	}
	
	usleep(400000) ; //delay 400ms
	//if([mTestItemName rangeOfString:@"Center"].length <= 0 )
	//	floatTestTime = floatTestTime + 0.4;
	
	//read data
	NSString *dataResult = [self ReceData:DictionaryPtr] ;
	
	//////////////////////////////////////
	//NSString *fileName = @"/456.rtf";
    //dataResult = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	//////////////////////////////////////////////		
	[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
    
	if (dataResult!=nil)
	{
		if(([dataResult rangeOfString:mContainString].length > 0) && ([dataResult rangeOfString:mNotContainString].length <= 0))
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS:@"1"] ;
		}
		else
		{
			
			NSArray *arraryTmp = [dataResult componentsSeparatedByString:@"Menu gets pressed "];
			if([arraryTmp count] <= 0 )
			{
				[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"please check diag return"] ;
				return;
			}
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:[NSString stringWithFormat:@"%d",[arraryTmp count] - 1]];
		}		
		/*if (mBufferName !=nil)
         {
         [TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
         [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
         }*/
	}
	else 
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Port have no data"] ;
    
    float TestTimeTmp=-[dateTimeTmp timeIntervalSinceNow];
    
    if([mTestItemName isEqualToString:@"Menu Button Location_Center Press Times"])
        TestTimeTmp = TestTimeTmp - 0.4;
	
	if(mBufferNameTestTime != nil)
		[TestItemManage setBufferValue:DictionaryPtr :mBufferNameTestTime :[NSString stringWithFormat:@"%f",TestTimeTmp]] ;
    //在字典 mutDictTestItemActionInfo 中取得 key 值为 UnitBufferInfo 的字典mutdictTmp1，并在mutdictTmp1中以key为strKey将strValue的值添加进去
	return ;
    
}

//phantom click no trigger parse function----Added by Annie 2014.10.07
+(void)RS232PhantomNoTrigger:(NSDictionary*) DictionaryPtr
{
	
    NSDate *dateTimeTmp=[[[NSDate alloc] init] autorelease] ;
    
	NSString *mTestItemName	= nil    ;
	NSString *mDevice		= nil    ;
	NSString *mBufferName	= nil    ;
	//NSString *mPDCAWrite	= @"no"  ;
    NSString *mTimeOut		= @"2.4"   ;
	NSString *mPostfix		= nil	 ;
	NSString *mContainString=@"";
	NSString *mNotContainString=nil;
	NSString *mBufferNameTestTime		= nil	 ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [DictionaryPtr objectForKey:strKey] ;
			mDevice = [TestItemParse getDeviceID:mDevice :DictionaryPtr] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameTestTime"])
		{
			mBufferNameTestTime = [DictionaryPtr objectForKey:strKey] ;
		}
		/*else if ([strKey isEqualToString:@"PDCAWrite"])
         {
         mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
         }*/
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ContainString"])
		{
			mContainString = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"NotContainString"])
		{
			mNotContainString = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	if (mDevice==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	/*
	 SCRID:128
	 add by caijunbo on 2011-08-07
	 Description:It is mainly used to enable postfix for RS232ReadStrOnly parser
	 */
	if(mPostfix!=nil)
	{
		NSString* nsstrDeviceID=nil;
		if([mDevice rangeOfString:@"IPad"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"UNITDevice"];
		}
		if([mDevice rangeOfString:@"Fixture"].length>0)
		{
			nsstrDeviceID=[DictionaryPtr objectForKey:@"FixtureDevice"];
		}
		NSString* nsstrKey=@"EndString";
		CommManage *commTmp=[self getCommManage] ;
		[commTmp SetCurrentKeyUsed:nsstrDeviceID :nsstrKey :mPostfix];
	}
	/*
	 SCRID:128
	 END
	 */
	
	float floatTestTime = 0;
	
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	float iTmp = [mTimeOut floatValue] ;
	float timeInterval = - [dateTmp timeIntervalSinceNow] ;
	while (timeInterval<=iTmp)
	{
		timeInterval = -[dateTmp timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:DictionaryPtr])
			break ;
		else
		{
			usleep(20000) ; //delay 20
			[TestItemManage setUnitLogInfo:DictionaryPtr :@"----> wait for 20ms":true];
			//floatTestTime = floatTestTime + 0.02;
			[TestItemManage setUnitLogInfo:DictionaryPtr :[NSString stringWithFormat:@"---->%f",floatTestTime]:true];
		}
	}
	
	usleep(400000) ; //delay 400ms
	//if([mTestItemName rangeOfString:@"Center"].length <= 0 )
	//	floatTestTime = floatTestTime + 0.4;
	
	//read data
	NSString *dataResult = [self ReceData:DictionaryPtr] ;
	
	//////////////////////////////////////
	//NSString *fileName = @"/456.rtf";
    //dataResult = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	//////////////////////////////////////////////
	[TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
    
	if (dataResult!=nil)
	{
		if(([dataResult rangeOfString:mContainString].length > 0) && ([dataResult rangeOfString:mNotContainString].length <= 0))
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"1"] ;
		}
		else
		{
			
			NSArray *arraryTmp = [dataResult componentsSeparatedByString:@"Menu gets pressed "];
			if([arraryTmp count] <= 0 )
			{
				[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:@"please check diag return"] ;
				return;
			}
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:[NSString stringWithFormat:@"%lu",[arraryTmp count] - 1]];
            
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL:[NSString stringWithFormat:@"%lu",(unsigned long)[arraryTmp count]]] ;
		}
		/*if (mBufferName !=nil)
         {
         [TestItemManage setBufferValue:DictionaryPtr :mBufferName :dataResult] ;
         [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
         }*/
	}
	else
    {
		//[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Port have no data"] ;
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
    }
    
    float TestTimeTmp=-[dateTimeTmp timeIntervalSinceNow];
    
    if([mTestItemName isEqualToString:@"Menu Button Location_Center Press Times"])
        TestTimeTmp = TestTimeTmp - 0.4;
	
	if(mBufferNameTestTime != nil)
		[TestItemManage setBufferValue:DictionaryPtr :mBufferNameTestTime :[NSString stringWithFormat:@"%f",TestTimeTmp]] ;
    //在字典 mutDictTestItemActionInfo 中取得 key 值为 UnitBufferInfo 的字典mutdictTmp1，并在mutdictTmp1中以key为strKey将strValue的值添加进去
	return ;
    
}

@end
