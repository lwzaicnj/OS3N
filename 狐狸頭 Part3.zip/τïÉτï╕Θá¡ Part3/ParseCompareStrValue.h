/*
 SCRID:12
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseCompareStrValue.m 
 | $Author::Caijunbo                    $Revision:: 1               
 | CREATED: 2010.11.09                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to compare two string buffer to see if they are the same.
 
 */
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseCompareStrValueFunction)

+(void)ParseCompareStrValue:(NSDictionary*)dictKeyDefined;

@end
