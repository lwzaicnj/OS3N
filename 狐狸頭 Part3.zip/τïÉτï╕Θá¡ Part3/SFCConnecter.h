//
//  SFCConnecter.h
//  QTSFC
//
//  Created by Kingking on 3/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
//#import <iostream>
#import "sql.h"
#import "sqlext.h"
//#import <string>

@interface SFCConnecter : NSObject {
		SQLHENV			 V_OD_Env;
		SQLHDBC			 V_OD_hdbc;	
		SQLHSTMT         V_OD_hstmt;
		SQLINTEGER		 V_OD_err,V_OD_rowanz,V_OD_id;
		SQLSMALLINT		 V_OD_mlen,V_OD_colanz;
		SQLRETURN		 V_OD_erg;
		SQLCHAR		     *V_OD_stat;
	    char            V_OD_buffer[400],V_OD_msg[200];
	
}
-(bool) ConnectSFCWithUserName:(NSString *)UserName
					  PassWord:(NSString *)PassWord
						   DSN:(NSString *)DNS;

-(NSString *) QueryResultWithSql:(NSString *)sql;
-(bool)insertSQL:(NSString*)Sql;
-(void) CloseConnect;
@end
