//
//  ParseToQuiteReadcb.m
//  iFTS
//
//  Created by jinn on 7/26/11.
//  Copyright 2011 Vincent-changes.com. All rights reserved.
//

#import "ParseToQuiteReadcb.h"
#import "Pudding.h"





@implementation TestItemParse(ParseToQuiteReadcb)

+(void)ParseToQuiteReadcb:(NSDictionary*)dictKeyDefined//vincent 08-03
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString * mReferenceBufferValue=nil;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	//NSString *mResultBuf =@"";
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
//	mReferenceBufferValue=@"0x03 Passed 3";
	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	NSRange getPass,getFail,getUnTest,getInCompleteTest;
	
	int failCount;
	
	getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
	getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
	getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
    getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
	
	if(getPass.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
	
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Passed [FAIL %d times]",failCount];
		
		enumResult = RESULT_FOR_PASS;
		
		
	}
	
	
	else if(getFail.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Failed [FAIL %d times]",failCount];
		
		enumResult = RESULT_FOR_FAIL;
		
	}
	
	else if(getUnTest.length>0)
	{
		
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Untested"];
		
				enumResult = RESULT_FOR_FAIL;
		
		
	}
	
	else if(getInCompleteTest.length>0)
	{
		
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete"];
		
				enumResult = RESULT_FOR_FAIL;
		
		
		
	}
	
	else 
	{
	
		strTestResultForUIinfo=mReferenceBufferValue;
		enumResult=RESULT_FOR_FAIL;
		
		
	}
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

//Add by Tiffany 20151229 for Pre-QT0a-Repair
+(void)ParseToQuiteReadcbForRepair:(NSDictionary*)dictKeyDefined//vincent 08-03
{
    NSString *strTestResultForUIinfo ;
    enum TestResutStatus enumResult ;
    
    //key parse
    NSString *mTestItemName=nil        ;
    NSString *mReferenceBufferName=nil ;
    NSString *mReferenceBufferValue=nil;
    NSString *mReferenceBufferName2=nil ;
    NSString *mReferenceBufferValue2=nil;
    NSString *mPrefix=nil ;
    NSString *mPostfix=nil ;
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    //NSString *mResultBuf =@"";
    
    if (dictKeyDefined==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
        return ;
    }
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
        {
            mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName==nil||mReferenceBufferName2==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //	mReferenceBufferValue=@"0x03 Passed 3";
    mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    if (mReferenceBufferValue==nil || mReferenceBufferValue2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    if (mPrefix==nil || mPostfix==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
        return ;
    }
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue2 Prefix
                                                           :mPrefix Postfix
                                                           :mPostfix] ;
    
    if([strFind isEqualToString:@""])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
        return ;
    }
    
    if([strFind rangeOfString:@"J127"].length > 0)
    {
        strTestResultForUIinfo=[NSString stringWithFormat:@"Pass"];
        enumResult = RESULT_FOR_PASS;
    }
    else if([strFind rangeOfString:@"J128"].length > 0)
    {
        NSRange getPass,getFail,getUnTest,getInCompleteTest;
        
        int failCount;
        
        getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
        getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
        getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
        getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
        
        if(getPass.length>0)
        {
            failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Passed [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_PASS;
            
        }
        
        
        else if(getFail.length>0)
        {
            failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Failed [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_FAIL;
        }
        
        else if(getUnTest.length>0)
        {
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Untested"];
            enumResult = RESULT_FOR_FAIL;
        }
        
        else if(getInCompleteTest.length>0)
        {
            
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete"];
            
            enumResult = RESULT_FOR_FAIL;
            
        }
        else
        {
            strTestResultForUIinfo=mReferenceBufferValue;
            enumResult=RESULT_FOR_FAIL;
        }
    }
    else
    {
        strTestResultForUIinfo=[NSString stringWithFormat:@"Fail"];
        enumResult = RESULT_FOR_FAIL;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    return ;
}

//Added by Annie for erase CB with password then check with "cbread xx quiet"   2014.10.07
+(void)ParseToEraseCheckCB:(NSDictionary*)dictKeyDefined//
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString * mReferenceBufferValue=nil;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	//NSString *mResultBuf =@"";
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    	//mReferenceBufferValue=@"0x03 Untested 3";
	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	NSRange getPass,getFail,getUnTest,getInCompleteTest;
	
	int failCount;
	
	getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
	getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
	getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
    getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
	
	if(getPass.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
        
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Passed [FAIL %d times]",failCount];
        
		enumResult = RESULT_FOR_FAIL;
		//enumResult = RESULT_FOR_PASS;
		
		
	}
	
	
	else if(getFail.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Failed [FAIL %d times]",failCount];
		
		enumResult = RESULT_FOR_FAIL;
		
	}
	
	else if(getUnTest.length>0)
	{
		
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Untested"];
		
        enumResult = RESULT_FOR_PASS;
        //enumResult = RESULT_FOR_FAIL;
		
	}
	
	else if(getInCompleteTest.length>0)
	{
		
		strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete"];
		
        enumResult = RESULT_FOR_FAIL;
		
		
		
	}
	
	else
	{
        
		strTestResultForUIinfo=mReferenceBufferValue;
		enumResult=RESULT_FOR_FAIL;
		
		
	}
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

+(void)ParseToQuiteReadcbOnlyIncompletePass:(NSDictionary*)dictKeyDefined//JianSheng Li
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString * mReferenceBufferValue=nil;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	//NSString *mResultBuf =@"";
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //	mReferenceBufferValue=@"0x03 Passed 3";
	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	
	NSRange getPass,getFail,getUnTest,getInCompleteTest;
	
	int failCount;
	
	getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
	getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
	getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
    getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
	
	if(getPass.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
        
		strTestResultForUIinfo=@"1";
		
		enumResult = RESULT_FOR_FAIL;
		
		
	}
	
	
	else if(getFail.length>0)
	{
		failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
		strTestResultForUIinfo=@"2";
		
		enumResult = RESULT_FOR_FAIL;
		
	}
	
	else if(getUnTest.length>0)
	{
		
		strTestResultForUIinfo=@"3";
		
        enumResult = RESULT_FOR_FAIL;
		
		
	}
	
	else if(getInCompleteTest.length>0)
	{
		
		strTestResultForUIinfo=@"0";
		
        enumResult = RESULT_FOR_PASS;
		
		
		
	}
	
	else 
	{
        
		strTestResultForUIinfo=mReferenceBufferValue;
		enumResult=RESULT_FOR_FAIL;
		
		
	}
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

+(void)ParseBackUpStatus:(NSDictionary*)dictKeyDefined//Evan 08-03
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpecOne=nil      ;// write cmd
	NSString *mStrSpecTwo=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpecOne"])
		{
			mStrSpecOne = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"StrSpecTwo"])
		{
			mStrSpecTwo = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mStrSpecOne==nil ||
		mReferenceBufferName==nil
		|| mStrSpecTwo == nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no received data"] ;
		return ;
	}
	
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"." withString:@""];

	NSRange rangeOne = [mReferenceBufferValue rangeOfString:mStrSpecOne];
	NSRange rangeTwo = [mReferenceBufferValue rangeOfString:mStrSpecTwo];
	
	if (rangeOne.length > 0 || rangeTwo.length > 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}
	else
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Fail" ;
	}
		
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

+(void)ParRevCal:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpecOne=nil      ;// write cmd
	NSString *mStrSpecTwo=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpecOne"])
		{
			mStrSpecOne = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"StrSpecTwo"])
		{
			mStrSpecTwo = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	/*
	if (mStrSpecOne==nil ||
		mReferenceBufferName==nil
		|| mStrSpecTwo == nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	 */
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no received data"] ;
		return ;
	}
	
	NSMutableArray *mutarr=(NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@" "];
	NSLog([mutarr objectAtIndex:3]);
		NSLog([mutarr objectAtIndex:4]);
	if([[mutarr objectAtIndex:3] isEqualToString:@"00"]&&[[mutarr objectAtIndex:4] isEqualToString:@"00"])
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Fail" ;
	}
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}
	/*
	
	NSRange rangeOne = [mReferenceBufferValue rangeOfString:mStrSpecOne];
	NSRange rangeTwo = [mReferenceBufferValue rangeOfString:mStrSpecTwo];
	
	if (rangeOne.length > 0 || rangeTwo.length > 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}
	else
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Fail" ;
	}
	*/
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}


//added by justin shang @ 2016-4-20 for pre-QT0a
+(void)ParseToQuiteReadcbForGrapeCond:(NSDictionary*)dictKeyDefined
{
    NSString *strTestResultForUIinfo ;
    enum TestResutStatus enumResult ;
    
    NSString *mTestItemName=nil        ;
    NSString *mReferenceBufferName=nil ;
    NSString * mReferenceBufferValue=nil;
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    
    if (dictKeyDefined==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
        return ;
    }
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //	mReferenceBufferValue=@"0x03 Passed 3";
    
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    
    NSRange getPass,getFail,getUnTest,getInCompleteTest;
    
    int failCount;
    
    getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
    getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
    getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
    getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
    
    if(getPass.length>0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
        
        strTestResultForUIinfo=[NSString  stringWithFormat:@"Passed [FAIL %d times]",failCount];
        
        enumResult = RESULT_FOR_PASS;
        
        
    }else if(getFail.length>0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
        if (failCount >= 3) {
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Pass [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_PASS;
        }else{
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Failed [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_FAIL;
        }
    }else if(getInCompleteTest.length > 0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getInCompleteTest.location+getInCompleteTest.length]intValue];
        if (failCount >= 3) {
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_PASS;
        }else{
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_FAIL;
        }
    }else if(getUnTest.length > 0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getUnTest.location+getUnTest.length]intValue];
        if (failCount >= 3) {
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Untest [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_PASS;
        }else{
            strTestResultForUIinfo=[NSString  stringWithFormat:@"Untest [FAIL %d times]",failCount];
            enumResult = RESULT_FOR_FAIL;
        }
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    return ;
}

+(void)ParseAIMCB:(NSDictionary*)dictKeyDefined//justin shang 2016-5-6
{
    NSString *strTestResultForUIinfo ;
    enum TestResutStatus enumResult ;
    
    //key parse
    NSString *mTestItemName=nil        ;
    NSString *mReferenceBufferName=nil ;
    NSString * mReferenceBufferValue=nil;
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    //NSString *mResultBuf =@"";
    
    if (dictKeyDefined==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
        return ;
    }
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName==nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //	mReferenceBufferValue=@"0x03 Passed 3";
    
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return ;
    }
    
    
    NSRange getPass,getFail,getUnTest,getInCompleteTest;
    
    int failCount;
    
    getPass=[mReferenceBufferValue rangeOfString:@"Passed"];
    getFail=[mReferenceBufferValue rangeOfString:@"Failed"];
    getUnTest=[mReferenceBufferValue rangeOfString:@"Untested"];
    getInCompleteTest=[mReferenceBufferValue rangeOfString:@"Incomplete"];
    
    if(getPass.length>0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getPass.location+getPass.length]intValue];
        
        strTestResultForUIinfo=[NSString  stringWithFormat:@"Passed [FAIL %d times]",failCount];
        
        enumResult = RESULT_FOR_PASS;
        
        
    }
    
    
    else if(getFail.length>0)
    {
        failCount=[[mReferenceBufferValue substringFromIndex:getFail.location+getFail.length]intValue];
        strTestResultForUIinfo=[NSString  stringWithFormat:@"Failed [FAIL %d times]",failCount];
        
        enumResult = RESULT_FOR_FAIL;
        
    }
    
    else if(getUnTest.length>0)
    {
        
        strTestResultForUIinfo=[NSString  stringWithFormat:@"Untested"];
        
        enumResult = RESULT_FOR_PASS;
        
        
    }
    
    else if(getInCompleteTest.length>0)
    {
        
        strTestResultForUIinfo=[NSString  stringWithFormat:@"Incomplete"];
        
        enumResult = RESULT_FOR_FAIL;
        
        
        
    }
    
    else
    {
        
        strTestResultForUIinfo=mReferenceBufferValue;
        enumResult=RESULT_FOR_FAIL;
        
        
    }
    
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    return ;
}






@end
