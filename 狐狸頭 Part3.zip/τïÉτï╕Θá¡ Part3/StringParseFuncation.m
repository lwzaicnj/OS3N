//
//  StringParseFuncation.m
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "StringParseFuncation.h"
#import "toolFun.h"
#import "CommManage.h"
#import "ParseMagnetFunction.h"

int timesOfPressButton = 1;

extern NSMutableString *CSVFileNameValue;
@implementation TestItemParse(StringParseFuncation)

static const float sensor_full_scale = 220.0; //add by judith for HES distance count
//add by bruce for ALS CT799 2015.5.20
//add by bruce for ALS CT799 2015.5.20
+(void)SL_ALSCT711_leftUp:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
    NSString *mStrSpec=nil      ;
    NSString *mReferenceBufferName=nil ;
    
    
    NSString *mBufferName1=nil    ;
    NSString *mBufferName2=nil    ;
    NSString *mBufferName3=nil    ;
    NSString *mBufferName4=nil    ;
    NSString *mBufferName5=nil    ;
    NSString *mBufferName6=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mCondition =@"Yes"  ;
    NSString *mTimeOut=@"6";
    NSString *mWriteCmdArray=nil;
    NSString *mWriteCmdEnd=@"\r"  ;
    NSString *mPrefix=nil ;
    NSString *mPostfix=@":-)";
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
    
    
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName1"])
        {
            mBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName2"])
        {
            mBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName3"])
        {
            mBufferName3 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName4"])
        {
            mBufferName4 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName5"])
        {
            mBufferName5 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName6"])
        {
            mBufferName6 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Condition"])
        {
            mCondition = [dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmdArray = [dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
        
    }
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([mVendorName rangeOfString:@"|"].length>0) {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
    if (mBufferName1==nil&&mBufferName2==nil&&mBufferName3==nil&&mBufferName4==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    NSMutableString *cmd =[[NSMutableString alloc] autorelease];
    //-----------------------------------------------------------------------------------------------
    //--------------------------Send Diag command--Start ADC-----------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x29 0x80 0x03"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp2 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp2==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x29 0x80 0x03 fail "] ;
        return ;
    }
    NSString *dataResult11=nil;
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult11 = [self ReceData:dictKeyDefined] ;
    usleep(2000000) ;
    //-----------------------------------------------------------------------------------------------
    //------------------------------Send Diag command (Stop ADC)-------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x29 0x80 0x01"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp3 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp3==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x29 0x80 0x01 fail "] ;
        return ;
    }
    NSString *dataResult13=nil;
    NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
    int iTmp3 = [mTimeOut intValue] ;
    int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
    while (timeInterval3<=iTmp3)
    {
        timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult13 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //------------------Get four buffer value (int_A) -----------------------------------------------
    //-----------------------------------------------------------------------------------------------
    NSMutableArray *writeCmdArray = [[[NSMutableArray alloc]init]autorelease];
    [writeCmdArray addObjectsFromArray: [mWriteCmdArray componentsSeparatedByString:@","]];
    NSArray *dataResultArray =[[[NSArray alloc]init]autorelease];
    NSArray *dataResultBArray =[[[NSArray alloc]init]autorelease];
    NSString *dataResultString=@"";
    NSString *dataResultBString=@"";
    for(int i = 0;i < [writeCmdArray count]; i++)
    {
        NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:i]];
        NSLog(@"send the data is string %@",string);
        if (mWriteCmdEnd!=nil)
        {
            [string appendString:mWriteCmdEnd] ;
        }
        
        bool bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
            return ;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined];
        dataResult=[ToolFun getStrFromPrefixAndPostfix:dataResult Prefix:@"Data:" Postfix:@":-)"];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@" " withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        NSLog(@"dataResult is %@",dataResult);
        dataResultString=[dataResultString stringByAppendingString:dataResult];
    }
    //-----------------------------------------------------------------------------------------------
    //-----------------Calculate the 4 value and put to Arrary-(int_A[4])----------------------------
    //-----------------------------------------------------------------------------------------------
    NSLog(@"dataResultStringA is %@",dataResultString);
    dataResultArray=[dataResultString componentsSeparatedByString:@"0x"];
    //NSMutableArray *intDataResultArray_PD_A =[[[NSMutableArray alloc]init]autorelease];
    int int_A[4];
    for (int i=1,j=0; i<([dataResultArray count]-1); i+=2,j++)
    {
        NSString *stringTemp=[dataResultArray objectAtIndex:i+1];
        stringTemp=[stringTemp stringByAppendingString:[dataResultArray objectAtIndex:i]];
        int intTemp=strtol([stringTemp UTF8String], NULL, 16);
        //        NSString *stringTep=[NSString stringWithFormat:@"%d",intTemp];
        //        [intDataResultArray_PD_A addObject:stringTep];
        int_A[j]=intTemp;
    }
    NSLog(@"int_A is %d,%d,%d,%d",int_A[0],int_A[1],int_A[2],int_A[3]);
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command (Change the photodiode selection)---------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x29 0xC0 0xF0"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"i2c --devwrite 3 0x29 0xC0 0xF0 fail "] ;
        return ;
    }
    NSString *dataResult12=nil;
    NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
    int iTmp1 = [mTimeOut intValue] ;
    int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
    while (timeInterval1<=iTmp1)
    {
        timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult12 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command (Start ADC)-------------------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x29 0x80 0x03"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bTmp = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x29 0x80 0x03 fail "] ;
        return ;
    }
    dataResult12=nil;
    dateTmp1=[[[NSDate alloc] init] autorelease] ;
    iTmp1 = [mTimeOut intValue] ;
    timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
    while (timeInterval1<=iTmp1)
    {
        timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult12 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command --Stop ADC--------------------------------------------------
    usleep(2000000) ;
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x29 0x80 0x01"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp1 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp1==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x29 0x80 0x01 fail "] ;
        return ;
    }
    NSString *dataResult14=nil;
    NSDate *dateTmp4=[[[NSDate alloc] init] autorelease] ;
    int iTmp4 = [mTimeOut intValue] ;
    int timeInterval4 = - [dateTmp4 timeIntervalSinceNow] ;
    while (timeInterval4<=iTmp4)
    {
        timeInterval4 = -[dateTmp4 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult14 = [self ReceData:dictKeyDefined] ;
    
    usleep(2000000) ;
    //-----------------------------------------------------------------------------------------------
    //------------------Get four buffer value (Int_B) -----------------------------------------------
    //-----------------------------------------------------------------------------------------------
    for(int i = 0;i < [writeCmdArray count]; i++)
    {
        NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:i]];
        NSLog(@"send the data is string %@",string);
        if (mWriteCmdEnd!=nil)
        {
            [string appendString:mWriteCmdEnd] ;
        }
        
        bool bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
            return ;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined];
        dataResult=[ToolFun getStrFromPrefixAndPostfix:dataResult Prefix:@"Data:" Postfix:@":-)"];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@" " withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        NSLog(@"dataResult is %@",dataResult);
        dataResultBString=[dataResultBString stringByAppendingString:dataResult];
    }
    //-----------------------------------------------------------------------------------------------
    //-----------------Calculate the 4 value and put to Arrary-(int_B[4])----------------------------
    //-----------------------------------------------------------------------------------------------
    NSLog(@"dataResultStringB is %@",dataResultBString);
    dataResultBArray=[dataResultBString componentsSeparatedByString:@"0x"];
    int int_B[4];
    //NSMutableArray *intDataResultArray_PD_B =[[[NSMutableArray alloc]init]autorelease];
    for (int i=1,j=0; i<([dataResultBArray count]-1); i+=2,j++)
    {
        NSString *stringTemp=[dataResultBArray objectAtIndex:i+1];
        stringTemp=[stringTemp stringByAppendingString:[dataResultBArray objectAtIndex:i]];
        int intTemp=strtol([stringTemp UTF8String], NULL, 16);
        //NSString *stringTep=[NSString stringWithFormat:@"%d",intTemp];
        //[intDataResultArray_PD_B addObject:stringTep];
        int_B[j]=intTemp;
    }
    NSLog(@"int_B is %d,%d,%d,%d",int_B[0],int_B[1],int_B[2],int_B[3]);
    //-----------------------------------------------------------------------------------------------
    //--------------SynthesizeData PD1 PD2 PD3 PD4 PD5 PD6-------------------------------------------
    //int_A[0]=PD4_A,int_A[1]=PD2_A,int_A[2]=PD1_A,int_A[3]=PD6_A----int_B[0]=PD4_B,int_B[1]=PD3_B,int_B[2]=PD5_B,int_B[3]=PD6_B
    if (int_A[0]==0||int_A[3]==0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"int_A[0] || int_A[3]=0"] ;
        return;
    }
    int scalingF;
    scalingF=(int_B[0]/int_A[0]+int_B[3]/int_A[3])/2;
    int PD1=scalingF*int_A[2];
    int PD2=scalingF*int_A[1];
    int PD3=int_B[1];
    int PD4=int_B[0];
    int PD5=int_B[2];
    int PD6=int_B[3];
    //-----------------------------------------------------------------------------------------------
    //-------------Set buffer value------------------------------------------------------------------
    NSString *stringTepPD1=[NSString stringWithFormat:@"%d",PD1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :stringTepPD1] ;
    NSLog(@"mBufferName1 is %@",stringTepPD1);
    NSString *stringTepPD2=[NSString stringWithFormat:@"%d",PD2];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :stringTepPD2] ;
    NSLog(@"mBufferName2 is %@",stringTepPD2);
    NSString *stringTepPD3=[NSString stringWithFormat:@"%d",PD3];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName3 :stringTepPD3] ;
    NSLog(@"mBufferName3 is %@",stringTepPD3);
    NSString *stringTepPD4=[NSString stringWithFormat:@"%d",PD4];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName4 :stringTepPD4] ;
    NSLog(@"mBufferName4 is %@",stringTepPD4);
    NSString *stringTepPD5=[NSString stringWithFormat:@"%d",PD5];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName5 :stringTepPD5] ;
    NSLog(@"mBufferName5 is %@",stringTepPD5);
    NSString *stringTepPD6=[NSString stringWithFormat:@"%d",PD6];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName6 :stringTepPD6] ;
    NSLog(@"mBufferName6 is %@",stringTepPD6);
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    
}
+(void)SL_ALSCT711_rightDown:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
    NSString *mStrSpec=nil      ;
    NSString *mReferenceBufferName=nil ;
    
    
    NSString *mBufferName1=nil    ;
    NSString *mBufferName2=nil    ;
    NSString *mBufferName3=nil    ;
    NSString *mBufferName4=nil    ;
    NSString *mBufferName5=nil    ;
    NSString *mBufferName6=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mCondition =@"Yes"  ;
    NSString *mTimeOut=@"6";
    NSString *mWriteCmdArray=nil;
    NSString *mWriteCmdEnd=@"\r"  ;
    NSString *mPrefix=nil ;
    NSString *mPostfix=@":-)";
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
    
    
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName1"])
        {
            mBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName2"])
        {
            mBufferName2 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName3"])
        {
            mBufferName3 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName4"])
        {
            mBufferName4 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName5"])
        {
            mBufferName5 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName6"])
        {
            mBufferName6 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Condition"])
        {
            mCondition = [dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmdArray = [dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
        
    }
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([mVendorName rangeOfString:@"|"].length>0) {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
    if (mBufferName1==nil&&mBufferName2==nil&&mBufferName3==nil&&mBufferName4==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    NSMutableString *cmd =[[NSMutableString alloc] autorelease];
    //-----------------------------------------------------------------------------------------------
    //--------------------------Send Diag command--Start ADC-----------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x39 0x80 0x03"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp2 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp2==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x39 0x80 0x03 fail "] ;
        return ;
    }
    NSString *dataResult11=nil;
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult11 = [self ReceData:dictKeyDefined] ;
    usleep(2000000) ;
    //-----------------------------------------------------------------------------------------------
    //------------------------------Send Diag command (Stop ADC)-------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x39 0x80 0x01"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp3 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp3==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x39 0x80 0x01 fail "] ;
        return ;
    }
    NSString *dataResult13=nil;
    NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
    int iTmp3 = [mTimeOut intValue] ;
    int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
    while (timeInterval3<=iTmp3)
    {
        timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult13 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //------------------Get four buffer value (int_A) -----------------------------------------------
    //-----------------------------------------------------------------------------------------------
    NSMutableArray *writeCmdArray = [[[NSMutableArray alloc]init]autorelease];
    [writeCmdArray addObjectsFromArray: [mWriteCmdArray componentsSeparatedByString:@","]];
    NSArray *dataResultArray =[[[NSArray alloc]init]autorelease];
    NSArray *dataResultBArray =[[[NSArray alloc]init]autorelease];
    NSString *dataResultString=@"";
    NSString *dataResultBString=@"";
    for(int i = 0;i < [writeCmdArray count]; i++)
    {
        NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:i]];
        NSLog(@"send the data is string %@",string);
        if (mWriteCmdEnd!=nil)
        {
            [string appendString:mWriteCmdEnd] ;
        }
        
        bool bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
            return ;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined];
        dataResult=[ToolFun getStrFromPrefixAndPostfix:dataResult Prefix:@"Data:" Postfix:@":-)"];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@" " withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        NSLog(@"dataResult is %@",dataResult);
        dataResultString=[dataResultString stringByAppendingString:dataResult];
    }
    //-----------------------------------------------------------------------------------------------
    //-----------------Calculate the 4 value and put to Arrary-(int_A[4])----------------------------
    //-----------------------------------------------------------------------------------------------
    NSLog(@"dataResultStringA is %@",dataResultString);
    dataResultArray=[dataResultString componentsSeparatedByString:@"0x"];
    //NSMutableArray *intDataResultArray_PD_A =[[[NSMutableArray alloc]init]autorelease];
    int int_A[4];
    for (int i=1,j=0; i<([dataResultArray count]-1); i+=2,j++)
    {
        NSString *stringTemp=[dataResultArray objectAtIndex:i+1];
        stringTemp=[stringTemp stringByAppendingString:[dataResultArray objectAtIndex:i]];
        int intTemp=strtol([stringTemp UTF8String], NULL, 16);
        //        NSString *stringTep=[NSString stringWithFormat:@"%d",intTemp];
        //        [intDataResultArray_PD_A addObject:stringTep];
        int_A[j]=intTemp;
    }
    NSLog(@"int_A is %d,%d,%d,%d",int_A[0],int_A[1],int_A[2],int_A[3]);
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command (Change the photodiode selection)---------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x39 0xC0 0xF0"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"i2c --devwrite 3 0x39 0xC0 0xF0 fail "] ;
        return ;
    }
    NSString *dataResult12=nil;
    NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
    int iTmp1 = [mTimeOut intValue] ;
    int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
    while (timeInterval1<=iTmp1)
    {
        timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult12 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command (Start ADC)-------------------------------------------------
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x39 0x80 0x03"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bTmp = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x39 0x80 0x03 fail "] ;
        return ;
    }
    dataResult12=nil;
    dateTmp1=[[[NSDate alloc] init] autorelease] ;
    iTmp1 = [mTimeOut intValue] ;
    timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
    while (timeInterval1<=iTmp1)
    {
        timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult12 = [self ReceData:dictKeyDefined] ;
    //-----------------------------------------------------------------------------------------------
    //-----------------Send Diag command --Stop ADC--------------------------------------------------
    usleep(2000000) ;
    if (cmd!=nil)
    {
        cmd=nil;
        [cmd release];
    }
    cmd =[[NSMutableString alloc] autorelease];
    
    cmd =[NSMutableString stringWithString:@"i2c --devwrite 3 0x39 0x80 0x01"];
    [cmd appendString:mWriteCmdEnd];
    NSLog(@"cmd1 = %@",cmd);
    bool bTmp1 = [self SendData:dictKeyDefined :cmd :@":-)"] ;
    
    if (bTmp1==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send i2c --devwrite 3 0x39 0x80 0x01 fail "] ;
        return ;
    }
    NSString *dataResult14=nil;
    NSDate *dateTmp4=[[[NSDate alloc] init] autorelease] ;
    int iTmp4 = [mTimeOut intValue] ;
    int timeInterval4 = - [dateTmp4 timeIntervalSinceNow] ;
    while (timeInterval4<=iTmp4)
    {
        timeInterval4 = -[dateTmp4 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    dataResult14 = [self ReceData:dictKeyDefined] ;
    
    usleep(2000000) ;
    //-----------------------------------------------------------------------------------------------
    //------------------Get four buffer value (Int_B) -----------------------------------------------
    //-----------------------------------------------------------------------------------------------
    for(int i = 0;i < [writeCmdArray count]; i++)
    {
        NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:i]];
        NSLog(@"send the data is string %@",string);
        if (mWriteCmdEnd!=nil)
        {
            [string appendString:mWriteCmdEnd] ;
        }
        
        bool bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
            return ;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined];
        dataResult=[ToolFun getStrFromPrefixAndPostfix:dataResult Prefix:@"Data:" Postfix:@":-)"];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@" " withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        dataResult=[dataResult stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        NSLog(@"dataResult is %@",dataResult);
        dataResultBString=[dataResultBString stringByAppendingString:dataResult];
    }
    //-----------------------------------------------------------------------------------------------
    //-----------------Calculate the 4 value and put to Arrary-(int_B[4])----------------------------
    //-----------------------------------------------------------------------------------------------
    NSLog(@"dataResultStringB is %@",dataResultBString);
    dataResultBArray=[dataResultBString componentsSeparatedByString:@"0x"];
    int int_B[4];
    //NSMutableArray *intDataResultArray_PD_B =[[[NSMutableArray alloc]init]autorelease];
    for (int i=1,j=0; i<([dataResultBArray count]-1); i+=2,j++)
    {
        NSString *stringTemp=[dataResultBArray objectAtIndex:i+1];
        stringTemp=[stringTemp stringByAppendingString:[dataResultBArray objectAtIndex:i]];
        int intTemp=strtol([stringTemp UTF8String], NULL, 16);
        //NSString *stringTep=[NSString stringWithFormat:@"%d",intTemp];
        //[intDataResultArray_PD_B addObject:stringTep];
        int_B[j]=intTemp;
    }
    NSLog(@"int_B is %d,%d,%d,%d",int_B[0],int_B[1],int_B[2],int_B[3]);
    //-----------------------------------------------------------------------------------------------
    //--------------SynthesizeData PD1 PD2 PD3 PD4 PD5 PD6-------------------------------------------
    //int_A[0]=PD4_A,int_A[1]=PD2_A,int_A[2]=PD1_A,int_A[3]=PD6_A----int_B[0]=PD4_B,int_B[1]=PD3_B,int_B[2]=PD5_B,int_B[3]=PD6_B
    if (int_A[0]==0||int_A[3]==0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"int_A[0] || int_A[3]=0"] ;
        return;
    }
    int scalingF;
    scalingF=(int_B[0]/int_A[0]+int_B[3]/int_A[3])/2;
    int PD1=scalingF*int_A[2];
    int PD2=scalingF*int_A[1];
    int PD3=int_B[1];
    int PD4=int_B[0];
    int PD5=int_B[2];
    int PD6=int_B[3];
    //-----------------------------------------------------------------------------------------------
    //-------------Set buffer value------------------------------------------------------------------
    NSString *stringTepPD1=[NSString stringWithFormat:@"%d",PD1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :stringTepPD1] ;
    NSLog(@"mBufferName1 is %@",stringTepPD1);
    NSString *stringTepPD2=[NSString stringWithFormat:@"%d",PD2];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :stringTepPD2] ;
    NSLog(@"mBufferName2 is %@",stringTepPD2);
    NSString *stringTepPD3=[NSString stringWithFormat:@"%d",PD3];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName3 :stringTepPD3] ;
    NSLog(@"mBufferName3 is %@",stringTepPD3);
    NSString *stringTepPD4=[NSString stringWithFormat:@"%d",PD4];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName4 :stringTepPD4] ;
    NSLog(@"mBufferName4 is %@",stringTepPD4);
    NSString *stringTepPD5=[NSString stringWithFormat:@"%d",PD5];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName5 :stringTepPD5] ;
    NSLog(@"mBufferName5 is %@",stringTepPD5);
    NSString *stringTepPD6=[NSString stringWithFormat:@"%d",PD6];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName6 :stringTepPD6] ;
    NSLog(@"mBufferName6 is %@",stringTepPD6);
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    
}
//ended by bruce for ALS CT799 2015.5.20
+(void)ParseStrWithStrSpec:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
    // add by annie for two buffer
    NSString *mStrSpec2=nil;
	NSString *mReferenceBufferName=nil ;
    NSString *mReferenceBufferName2=nil ;
    NSString *mReferenceBufferName3=nil ;
    
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
    
    
    NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
    NSString *mCheckMdlcKey=nil;//add by kevin at 20140717
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
	NSString *mReferenceErrorBuffer=nil; //Add by andy for Development_9, 20160312.
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec2"])
		{
			mStrSpec2 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName3"])
		{
			mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CheckMdlcKey"])
		{
			mCheckMdlcKey = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
            if([mReferenceBufferNameVendorValue rangeOfString:@"NoValue"].length>0)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Fail"] ;//Unknown BoardID or Regn code -- Add by Andy for SL QT0b, 20160130 
                return;
            }
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
        else if([strKey isEqualToString:@"ReferenceErrorBuffer"]) // Add by andy for Development_9, 20160312.
        {
            mReferenceErrorBuffer=[dictKeyDefined objectForKey:strKey];
        }
        

	}
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        
//        if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
//            return;
//        }
        
        
        if ([mVendorName rangeOfString:@"|"].length>0) {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }

        
    }
    if([mTestItemName isEqualToString:@"Gyro self test"])
    {
        NSString *GyroSeltTestByPass = [TestItemManage getBufferValue:dictKeyDefined :@"Gyro Selt Test Bypass"];
        if([GyroSeltTestByPass rangeOfString:@"ByPass"].length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Bosch, need ByPass"] ;
            return  ;
        }
    }
    
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //Annie debug
    //mReferenceBufferValue=@"Display subsystem has already been powered on [0;31mERROR: MoPED Failed matcwith all SNs found[0m   Result = FAIL ";
    //Annie debug
    /*
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
        return ;
    }
     */
    NSString *mReferenceBufferValue2;
    NSString *mReferenceErrorBufferValue;
    mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    mReferenceErrorBufferValue= [TestItemManage getBufferValue:dictKeyDefined :mReferenceErrorBuffer] ;
    /*
    if (mReferenceBufferValue2==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
        return ;
    }
    */
    // Add by Andy for Abnormal Display Recovery station, 20160305.
    if([mTestItemName isEqualToString:@"Check LUTs And PMIC"])
    {
        if ([mReferenceBufferValue rangeOfString:@"FAIL"].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Fail"];
            return ;
        }
    }
    
    if([mTestItemName isEqualToString:@"Fix PGMA"])
    {
        if ([mReferenceBufferValue2 rangeOfString:@"OK"].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"Bypass"];
            return ;
        }
        
        else
        {
            if ([mReferenceBufferValue rangeOfString:@"OK"].length>0)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Pass"] ;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
                return;
            }
            else if ([mReferenceErrorBufferValue rangeOfString:@"item 4"].length>0) //Add by Andy and Peter 20160312 for Delelopment9.
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Error:item 4 return abnormal!"];
                return;
            }
            else
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fail"] ;//peter 20160305
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"];
                
                return;
            }
        }
        
    }//End.
    
	NSString *mReferenceBufferValue3 ;
	mReferenceBufferValue3 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3] ;
    
    //add by kevin for RL qt0a start
    if([mTestItemName isEqualToString:@"CheckUnitPaste"] || [mTestItemName isEqualToString:@"CheckUnitFace"])
    {
        if([mReferenceBufferValue3 rangeOfString:@"V01"].length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS:@"byPass"] ;
            return ;
        }
    }
    //add by kevin for RL qt0a end
    
	/*Owner:Jack DATE :11.16.2010
	 SCRID :017
	 Desc  :add for test unit shutdown --audo .
	 */
	//SCRID-155:avoid the right sn but wrong barcode(J1 use J2 or J2a barcode etc)issue.Judith.2012-01-04.
	//    NSString *mReferenceBufferValue = @"setting accessory rail to high mode\nsetting switch to output power on acc1\nOK\n:)";
	if([mTestItemName isEqualToString:@"Burn Matrix and Special Builds"])
	{
		NSRange whetherBypass  = [mReferenceBufferValue rangeOfString:@"BYPASS"];
		NSRange whetherFail  = [mReferenceBufferValue rangeOfString:@"FAIL"];
		if(whetherBypass.length > 0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS:mReferenceBufferValue] ;
			return;
		}
		else if(whetherFail.length > 0)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:mReferenceBufferValue] ;
			return;
		}
	}
    
	//SCRID-155:End
    if([mTestItemName isEqualToString:@"Check Unit Sleep"])
	{
		if (mReferenceBufferValue==nil || [mReferenceBufferValue length] <= 0 || mReferenceBufferValue==NULL)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
			return ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
			return ;
		}
	}

	if([mTestItemName isEqualToString:@"Check Unit Shut Down"])
	{
		if (mReferenceBufferValue==nil || [mReferenceBufferValue length] <= 0 || mReferenceBufferValue==NULL)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
			return ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
			return ;
		}
	}

    //20160304 SL new station Abnormal Display Recovery by Andy.
    NSString *subname1 = @"PGAMMA/PMIC Check";
    NSString *subname2 = @"TCON EEPROM Check";
    if([mTestItemName isEqualToString:@"Check LUTs And PMIC"])
        
    {
        if ([mReferenceBufferValue rangeOfString:@"OK"].length>0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
            [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname1:nil:@"NA":@"NA":@"1":nil:RESULT_FOR_PASS:@"PASS"];
            [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname2:nil:@"NA":@"NA":@"1":nil:RESULT_FOR_PASS:@"PASS"];
            return ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
            if ([mReferenceBufferValue rangeOfString:@"PGMA - FAIL"].length>0&&([mReferenceBufferValue rangeOfString:@"LUT0 - PASS"].length>0&&[mReferenceBufferValue rangeOfString:@"LUT1 - PASS"].length>0)) {
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname1:nil:@"NA":@"NA":@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname2:nil:@"NA":@"NA":@"1":nil:RESULT_FOR_PASS:@"PASS"];
                return ;
            }
            else if ([mReferenceBufferValue rangeOfString:@"PGMA - PASS"].length>0&&([mReferenceBufferValue rangeOfString:@"LUT0 - FAIL"].length>0||[mReferenceBufferValue rangeOfString:@"LUT1 - FAIL"].length>0))
            {
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname1:nil:@"NA":@"NA":@"1":nil:RESULT_FOR_PASS:@"PASS"];
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname2:nil:@"NA":@"NA":@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
                return ;
            }
            else if([mReferenceBufferValue rangeOfString:@"PGMA - FAIL"].length>0&&([mReferenceBufferValue rangeOfString:@"LUT0 - FAIL"].length>0||[mReferenceBufferValue rangeOfString:@"LUT1 - FAIL"].length>0))
            {
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname1:nil:@"NA":@"NA":@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
                [TestItemManage setSubItemPDCAInfo :dictKeyDefined:subname2:nil:@"NA":@"NA":@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
                return ;
            }
        }
    }// End 20160304.
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
        return ;
    }
    //add by kevin at 20140717(should add "CheckMdlcKey=Yes" at test script) end
    // if ([mReferenceBufferName isEqualToString:@"hashMopedBufferCheck"]) {
    if ([mCheckMdlcKey isEqualToString:@"Yes"]) {
        NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
        if (rangeTmp.length <= 0)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"MopadHashFail"];
        }
        else
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"MopadHashPass"];
            enumResult =RESULT_FOR_PASS ;
            strTestResultForUIinfo = @"Pass" ;
        }
    }
    
    //add by kevin at 20140717(should add "CheckMdlcKey=Yes" at test script) end
    if(mPrefix != nil && mPostfix != nil)
    {
        mReferenceBufferValue=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix];
        if (mReferenceBufferValue==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"received data error"] ;
            return ;
        }
    }
   
	//Jack add end
	/************************dengshouxiu 2010-03-30********begin*****************/
	if ([mTestItemName isEqualToString:@"Audio Decoder Test"])
	{
		NSRange rangeTmp=[mReferenceBufferValue rangeOfString:@":-)"] ;
		if (rangeTmp.length > 0)
		{
			NSRange rangeTmp1=[mReferenceBufferValue rangeOfString:mStrSpec] ;
			if (rangeTmp1.length > 0)
			{
				
				enumResult =RESULT_FOR_PASS ;
				strTestResultForUIinfo = @"Pass" ;
			}
			else
			{
				enumResult =RESULT_FOR_FAIL ;
				strTestResultForUIinfo = @"Fail" ;
			}
		}
		else
		{
			
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = @"TimeOut" ;
		}
		
	}
	
	else
	{
		/************************dengshouxiu 2010-03-30******end*******************/	
		NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
        NSRange rangeTmp2;
        if(mReferenceBufferValue2 != nil && mStrSpec2 != nil)
        {
            rangeTmp2=[mReferenceBufferValue2 rangeOfString:mStrSpec2] ;
        }
		
		if ([mCondition boolValue])
		{	
			if (rangeTmp.length > 0)  //PASS  conditional 
			{
                if (mReferenceBufferValue2 != nil ) //add by annie 2014.06.07
                {
                    if ( rangeTmp2.length>0)
                    {
                        enumResult =RESULT_FOR_PASS ;
                        strTestResultForUIinfo = @"Pass" ;
                    }
                    else
                    {
                        enumResult =RESULT_FOR_FAIL ;
                        strTestResultForUIinfo = @"Fail" ;
                    }
                }
                else
                {
                    enumResult =RESULT_FOR_PASS ;
                    strTestResultForUIinfo = @"Pass" ;
                }
            }
			else //failse conditional
			{
				enumResult =RESULT_FOR_FAIL ;
				strTestResultForUIinfo = @"Fail" ;
			}
		}
		else
		{
			if (rangeTmp.length > 0)  //PASS  conditional 
			{
				enumResult =RESULT_FOR_FAIL ;
				strTestResultForUIinfo = @"Fail" ;
			}
			else //failse conditional
			{
				enumResult =RESULT_FOR_PASS ;
				strTestResultForUIinfo = @"Pass" ;
			}
		}
	}
	
    if (mBufferName!=nil)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strTestResultForUIinfo];
    }
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

// add by Luke 20160526
+(void)ParseStrWithStrSpec_UninitFixture:(NSDictionary*)dictKeyDefined
{
    NSString *strTestResultForUIinfo ;
    enum TestResutStatus enumResult ;
    
    //key parse
    NSString *mTestItemName=nil        ;
    NSString *mStrSpec=nil      ;// write cmd
    
    NSArray *mReferenceBufferNameArray=nil;
    NSArray *mStrSpecArray=nil;
    
    for(int i=0;i<[dictKeyDefined count];i++)
    {
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferNameArray"])
        {
            mReferenceBufferNameArray = [[dictKeyDefined objectForKey:strKey] componentsSeparatedByString:@","];
        }
        else if ([strKey isEqualToString:@"StrSpecArray"])
        {
            mStrSpecArray = [[dictKeyDefined objectForKey:strKey] componentsSeparatedByString:@"|"];
        }
    }
    
    
    if (mReferenceBufferNameArray==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    
    //    for (NSString *resultStr in mReferenceBufferNameArray) {
    //        [TestItemManage setBufferValue:dictKeyDefined :resultStr :@"fsdfsdf"];
    //        //NSString *flagStr = [TestItemManage getBufferValue:dictKeyDefined :resultStr];
    //    }
    if (mStrSpecArray==nil) {
        for (NSString *resultStr in mReferenceBufferNameArray) {
            NSString *flagStr = [TestItemManage getBufferValue:dictKeyDefined :resultStr];//通過 key去取生成的結果
            if ([flagStr rangeOfString:mStrSpec].length <= 0) {
                enumResult =RESULT_FOR_FAIL ;
                strTestResultForUIinfo = @"Fail" ;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
                return ;
            }
        }
    }
    else
    {
        for (NSString *resultStr in mReferenceBufferNameArray)
        {
            NSString *flagStr = [TestItemManage getBufferValue:dictKeyDefined :resultStr];
            if ([flagStr rangeOfString:mStrSpecArray[0]].length > 0|[flagStr rangeOfString:mStrSpecArray[1]].length > 0)
            {
                continue;
            }
            else
            {
                enumResult =RESULT_FOR_FAIL;
                strTestResultForUIinfo = @"Fail" ;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
                return ;
            }
        }
    }
    
    
    enumResult =RESULT_FOR_PASS ;
    strTestResultForUIinfo = @"Pass" ;
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    return ;
    
}


+(void)ParseStrWithStrSpec_RGBW:(NSDictionary*)dictKeyDefined
{
    NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
    
  	
    if (rangeTmp.length > 0)  
    {
        enumResult =RESULT_FOR_PASS ;
        strTestResultForUIinfo = mReferenceBufferValue ;
    }
    else 
    {
        enumResult =RESULT_FOR_FAIL ;
        strTestResultForUIinfo = @"Fail" ;
        while (1) {
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert setAlertStyle:NSInformationalAlertStyle];
            if([mTestItemName rangeOfString:@"MLBSN"].length>0)
            {
                [alert setMessageText:@"MLB change, PLS calibrate the LED current firstly!"];
            }
            if([mTestItemName rangeOfString:@"OS Version"].length>0)
            {
                [alert setMessageText:@"OS version change! PLS calibrate the LED current firstly"];
            }
            [alert addButtonWithTitle:@"Yes"];
            [alert runModal];
        }
        
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
    
    
}

+(void)ParseStrWithMultiStrSpecForRGBW:(NSDictionary*)dictKeyDefined
{
    
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mNumberType=nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[dictKeyDefined objectForKey:strKey];
		}
	}
	
    //	if (
    //		mReferenceBufferName==nil
    //		)
    //	{
    //		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
    //	    return  ;
    //	}
	
	
    //mReferenceBufferValue =@"0x0331";
	
	
    if([mTestItemName isEqualToString:@"default LED current(mA)"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mStrSpec] ;
        return  ;
    }
    if([mTestItemName isEqualToString:@"Full LED current(mA)"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mStrSpec] ;
        return  ;
    }
    if([mTestItemName isEqualToString:@"LGD default LED current(mA)"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mStrSpec] ;
        return  ;
    }
    if([mTestItemName isEqualToString:@"Sharp default LED current(mA)"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mStrSpec] ;
        return  ;
    }
    
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
    strFind = [strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
    if([mTestItemName isEqualToString:@"MLBSN"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
        return  ;
    }
    if([mTestItemName isEqualToString:@"product name"])
    {
        
        if([strFind rangeOfString:@"08"].length > 0)
            strFind = @"J98";
        else if([strFind rangeOfString:@"04"].length > 0)
            strFind = @"J99";                      
    }
	NSArray *arraySpecString = [mStrSpec componentsSeparatedByString:@"||"];
	
	if([arraySpecString count] < 1)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	BOOL flag = FALSE;
	for(int i=0; i<[arraySpecString count];i++)
	{
		if([[arraySpecString objectAtIndex:i] isEqualToString: strFind])
		{
			flag = TRUE;
			break;
		}
	}
	if([mNumberType isEqualToString:@"Hex"]||[mNumberType isEqualToString:@"hex"])
	{
		int resultValue = (int)strtol([strFind UTF8String], NULL, 16);
		if(flag)
		{
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",resultValue]] ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",resultValue]] ;	
		}
	}
	else
	{
        
        
        
        if(flag)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFind] ;
        }
        
	}
}


+(void)ParseStrWithMultiStrSpec:(NSDictionary*)dictKeyDefined
{
    
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mNumberType=nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"NumberType"])
		{
			mNumberType=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //mReferenceBufferValue =@"0x0331";
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
    strFind = [strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
	NSArray *arraySpecString = [mStrSpec componentsSeparatedByString:@"||"];
	
	if([arraySpecString count] < 1)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	BOOL flag = FALSE;
	for(int i=0; i<[arraySpecString count];i++)
	{
		if([[arraySpecString objectAtIndex:i] isEqualToString: strFind])
		{
			flag = TRUE;
			break;
		}
	}
	if([mNumberType isEqualToString:@"Hex"]||[mNumberType isEqualToString:@"hex"])
	{
		int resultValue = (int)strtol([strFind UTF8String], NULL, 16);
		if(flag)
		{
			 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",resultValue]] ;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",resultValue]] ;	
		}
	}
	else
	{
		if(flag)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
            if (mBufferName!=nil)  //add by Bruce 2015.7.20
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strFind] ;

		}
		else
		{
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFind] ;
            if (mBufferName!=nil)  //add by Bruce 2015.7.20
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :strFind] ;

		}
	}
}

+(void)ParseCompareTwoBuffers:(NSDictionary*)dictKeyDefined
{
	
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mReferenceBufferName2=nil;
    NSString *mStrLength=nil;
    NSString *mKeyType = nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StrLength"])
		{
			mStrLength = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"KeyType"])
		{
			mKeyType = [dictKeyDefined objectForKey:strKey] ;
		}
        
	}
	
	if (mReferenceBufferName2==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
	NSString *mReferenceBufferValue2 ;
	mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	if (mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
    
    /*
     Add by Andy&Peter,20160226, for SL CT2 Check VINYL_Present With Region code Test item.
     Logic:
     
     1). Query SFC on region code. Regn_Code is NULL --> Error out: Region_Code is NULL.
     
     2). Query SFC on region code. Regn_Code = CH/A (China 3G) && UICC_VINYL_Present = 1 --> Error out: Vinyl_Present Status mismatch the Region_Code.
     
     3). Query SFC on region code. Regn_Code ≠CH/A(Non-China 3G) && UICC_VINYL_Present = 0 --> Error out: Vinyl_Present Status mismatch the Region_Code.
     
     4). Otherwise, test normal and Pass.
     */
    if([mKeyType isEqualToString:@"Vinyl"])
    {
        if ([mReferenceBufferValue rangeOfString:@"region_code= "].length>0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"Region_Code is NULL"];
            return;
        }
        else
        {
            if(([mReferenceBufferValue rangeOfString:@"region_code=CH/A"].length>0)&&([mReferenceBufferValue2 rangeOfString:@"UICC_VINYL_Present=1"].length>0))
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"Vinyl_Present Status mismatch the Region_Code"];
                return;
            }
            else if(([mReferenceBufferValue rangeOfString:@"region_code=CH/A"].length<1)&&([mReferenceBufferValue2 rangeOfString:@"UICC_VINYL_Present=0"].length>0))
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"Vinyl_Present Status mismatch the Region_Code"];
                return;
            }
        }
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"Pass"] ;
        
        return ;
    }//end 20160226
    
    NSString *uiI = mReferenceBufferValue2;
    
    if([mStrLength intValue] > 0)
    {
        if([mReferenceBufferValue2 length] >= [mStrLength intValue])
        {
            mReferenceBufferValue2 = [mReferenceBufferValue2 substringToIndex:[mStrLength intValue]];
        }
        //20150806 peter add
        if([mReferenceBufferValue length] >= [mStrLength intValue])
        {
            mReferenceBufferValue = [mReferenceBufferValue substringToIndex:[mStrLength intValue]];
        }
        
    }
    
    if([mKeyType isEqualToString:@"CaseInsensitive"])
    {
        mReferenceBufferValue2 = [mReferenceBufferValue2 uppercaseString];
        mReferenceBufferValue = [mReferenceBufferValue uppercaseString];
    }
    
	if([mReferenceBufferValue2 isEqualToString:mReferenceBufferValue])
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:uiI] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:uiI] ;
	}

}


+(void)ParseStrWithStrSpecPostfix:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mRecord=@"no";
    NSString *mNeedWriteCSVFile=@"no";
    NSString *mNeedNotContainStr=nil;
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//

    //20160220 peter QT0b Vinyl smokey test
    NSString *mReferenceBufferName1=nil;
    NSString *mReferenceBufferName2=nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if([strKey isEqualToString:@"Record"])
		{
			mRecord=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"NeedWriteCSVFile"])
		{
			mNeedWriteCSVFile=[dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"NeedNotContainStr"])
		{
			mNeedNotContainStr=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])  //20160220 SL QT0b Vinyl smokey test by Peter
        {
            mReferenceBufferName1= [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])  //20160220 SL QT0b Vinyl smokey test by Peter
        {
            mReferenceBufferName2= [dictKeyDefined objectForKey:strKey] ;
        }
	}
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([mVendorName rangeOfString:@"|"].length>0)
        {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
	
    //20160220 SL QT0b Vinyl smokey test by Peter
    NSString *mReferenceBufferNameValue1=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    NSString *mReferenceBufferNameValue2 =[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
    if([stationName rangeOfString:@"QT0b"].length>0)
    {
        if([mReferenceBufferNameValue2 rangeOfString:@"region_code= "].length>0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_FAIL :@"No Regn code"] ;//Unknown BoardID or Regn code -- Add by Andy for SL QT0b, 20160220
            return;
        }
        if (([mReferenceBufferNameValue1 rangeOfString:@"0x08"].length>0)||([mReferenceBufferNameValue2 rangeOfString:@"region_code=CH/A"].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"J127 or China config, no need test"] ;
            return;
        }
    }//end
    
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
        if([mNeedWriteCSVFile boolValue])
        {
            NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
            if (filehandTmp!=nil)
            {
                [filehandTmp seekToEndOfFile] ;
                [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp closeFile] ;
            } 
        } //add by Rick for magine map station to write csv file 2012-10-26
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
        
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//mReferenceBufferValue = @"0 SFC_OK \n grp_sn=D2C3246007FFF56699B2 \n lcg_sn=";
	
	if (mReferenceBufferValue==nil)
	{
        if([mNeedWriteCSVFile boolValue])
        {
            NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
            if (filehandTmp!=nil)
            {
                [filehandTmp seekToEndOfFile] ;
                [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp closeFile] ;
            } 
        } //add by Rick for magine map station to write csv file 2012-10-26
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    //end
    
    //JianSheng add, 2014-09-01 : can not contain below strings
    if(mNeedNotContainStr != nil)
    {
        NSArray *notContainsStrArray = [mNeedNotContainStr componentsSeparatedByString:@"|"];
        for(int i=0; i<[notContainsStrArray count]; i++)
        {
            if([mReferenceBufferValue rangeOfString:[notContainsStrArray objectAtIndex:i]].length > 0)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diags return unexpected/fail info."] ;
                return ;
            }
        }
    }
    //JianSheng add, 2014-09-01 :
    
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	
    strFind = [ToolFun allTrimFromString:strFind trimStr:@"\t" leftTrim:TRUE rightTrim:TRUE];
    strFind = [ToolFun allTrimFromString:strFind trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
    
	NSString *tmp = strFind;
	
	tmp = [tmp stringByReplacingOccurrencesOfString:@" " withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	tmp = [tmp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
    
    if ([tmp isEqualToString:@""]||(tmp==nil))
	{
		//	NSLog(@"%@",mReferenceBufferValue) ;
        if([mNeedWriteCSVFile boolValue])
        {
            NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
            if (filehandTmp!=nil)
            {
                [filehandTmp seekToEndOfFile] ;
                [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                [filehandTmp closeFile] ;
            } 
        } //add by Rick for magine map station to write csv file 2012-10-26
		//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no valid data"] ;//Modify by Annie
	    return  ;
	}
	
	if (mBufferName!=nil)
	{
		//SCRID:14
		//added by caijunbo on 2010-11-05
		if ([mBufferName isEqualToString:@"NANDID"])
		{
			strFind=[strFind stringByReplacingOccurrencesOfString:@";" withString:@""];
		}
		////added end
		//SCRID:14
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :strFind] ;
	}
	
	//Ray add for read SoC temperature before test and after test
	if([mTestItemName isEqualToString:@"SoC Sensor 0 Temperature Before Test"]
	   ||[mTestItemName isEqualToString:@"SoC Sensor 1 Temperature Before Test"]
	   ||[mTestItemName isEqualToString:@"SoC Sensor 0 Temperature After Test"]
	   ||[mTestItemName isEqualToString:@"SoC Sensor 1 Temperature After Test"])
	{
		strFind = [strFind stringByReplacingOccurrencesOfString:@"\n" withString:@""];
		strFind = [strFind stringByReplacingOccurrencesOfString:@"\r" withString:@""];
		strFind = [strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
		strFind = [strFind stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		
		NSRange rangeTmp=[strFind rangeOfString:@"Max:0x"] ;
		if(rangeTmp.length > 0)
		{
			NSString *tmpPrefix=@"Max:";
			NSString *tmpPostfix=@"Min:";
			NSString *temperature = [ToolFun getStrFromPrefixAndPostfix:strFind Prefix:tmpPrefix Postfix:tmpPostfix];
			
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :temperature] ;
			return;
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Temperature"] ;
			return;
		}
	}
	//Ray add for read SoC temperature before test and after test
	
	if (mStrSpec==nil)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = strFind ; 
	}else
	{
		NSRange rangeTmp=[strFind rangeOfString:mStrSpec] ;
		
		if (rangeTmp.length > 0)  //PASS  conditional 
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = strFind ;
		}else //failse conditional
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = strFind ;
		}
	}
    if ([mRecord isEqualToString:@"yes"] || [mRecord isEqualToString:@"Yes"]) //add by judith 2012-05-17
    {
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined :mTestItemName :nil :nil :nil :strTestResultForUIinfo :nil:1:@"PASS"];
        NSLog(@"setSubItemPDCAInfo PASS");
    }
    
    if([mNeedWriteCSVFile boolValue])
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[strFind dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        } 
    } //add by Rick for magine map station to write csv file 2012-10-26
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

/** SCRID-40: Read PMU Temperature Items test need judge UpLimit and LowLimit,then upload UpLimit and LowLimit to PDCA. Tony  2010-12-15 **/
+(void)ParseStrWithStrSpecPostfixUpLowLimit:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *Value = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														 :mPrefix Postfix
														 :mPostfix] ;
	Value = [ToolFun deleteFromString:Value trimStr:@" "];
	
	
	if ([Value integerValue] < [mUpLimit integerValue] && [Value integerValue] > [mLowLimit integerValue])
	{
		enumResult = RESULT_FOR_PASS;
		strTestResultForUIinfo = @"PASS ";
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		strTestResultForUIinfo = @"FAIL ";
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:Value];
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}
/** SCRID-40 end **/
//search the Max and Min value from 4 buffer,and then calulate Max-Min value.-----add by Annie 2013-0504
+(void)ParseCalculateMaxSubtractMinValueForMBT:(NSDictionary*)dictKeyDefined
{
    NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName1=nil ;
    NSString *mReferenceBufferName2=nil ;
    NSString *mReferenceBufferName3=nil ;
    NSString *mReferenceBufferName4=nil ;
    NSString *mBufferName=nil;
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName3"])
		{
			mReferenceBufferName3 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName4"])
		{
			mReferenceBufferName4 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName1==nil ||mReferenceBufferName2==nil ||mReferenceBufferName3==nil ||
		mReferenceBufferName4==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    NSString *mReferenceBufferValue3 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3] ;
    NSString *mReferenceBufferValue4 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName4] ;
    
	
	
	//NSString *fileName = @"/123.txt";
	//mReferenceBufferValue = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
    
	if (mReferenceBufferValue1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data_Ts1"] ;
		return ;
	}
    if (mReferenceBufferValue2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data_Ts2"] ;
		return ;
	}
    if (mReferenceBufferValue3==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data_Ts3"] ;
		return ;
	}
    if (mReferenceBufferValue4==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data_Ts4"] ;
		return ;
	}
    
    double maxTsTmp=[mReferenceBufferValue1 doubleValue];
    if (maxTsTmp<[mReferenceBufferValue2 doubleValue]) {
        maxTsTmp=[mReferenceBufferValue2 doubleValue];
    }
    if (maxTsTmp<[mReferenceBufferValue3 doubleValue]) {
        maxTsTmp=[mReferenceBufferValue3 doubleValue];
    }
    if (maxTsTmp<[mReferenceBufferValue4 doubleValue]) {
        maxTsTmp=[mReferenceBufferValue4 doubleValue];
    }
    
    double minTsTmp=[mReferenceBufferValue4 doubleValue];
    if (minTsTmp>[mReferenceBufferValue3 doubleValue]) {
        minTsTmp=[mReferenceBufferValue3 doubleValue];
    }
    if (minTsTmp>[mReferenceBufferValue2 doubleValue]) {
        minTsTmp=[mReferenceBufferValue2 doubleValue];
    }
    if (minTsTmp>[mReferenceBufferValue1 doubleValue]) {
        minTsTmp=[mReferenceBufferValue1 doubleValue];
    }
    
    
    double TsRangeValue=maxTsTmp-minTsTmp;
    NSString *Value=[NSString stringWithFormat:@"%f",TsRangeValue];
    
	//if ([Value integerValue] < [mUpLimit integerValue] && [Value integerValue] > [mLowLimit integerValue])
	if(((mLowLimit==nil||[mLowLimit length]<=0)?1:([Value doubleValue] >=[mLowLimit doubleValue]))&&
	   ((mUpLimit==nil||[mUpLimit length]<=0)?1:([Value doubleValue]<=[mUpLimit doubleValue])))
	{
		enumResult = RESULT_FOR_PASS;
		//strTestResultForUIinfo = @"PASS ";
		strTestResultForUIinfo = [NSString stringWithFormat:@"%f",TsRangeValue];
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		//strTestResultForUIinfo = @"FAIL ";
		//strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:Value];
		strTestResultForUIinfo=[NSString stringWithFormat:@"%f",TsRangeValue];
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :Value] ; ///write test result and uiinfo.
	
	if(mBufferName != nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :Value] ;
	
	return ;
    
    
}
+(void)ParseStrWithStrSpecForMagnetBackSide:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mPrefix=nil ;
    NSString *mPostfix=nil ;
    NSString *mReferenceBufferName=nil ;
    NSString *mReferenceBufferName1F=nil ;
    NSString *mReferenceBufferName2F=nil ;
    NSString *mReferenceBufferName3F=nil ;
    NSString *mReferenceBufferName4F=nil ;
    NSString *mBufferName=nil;
    
    
    if (dictKeyDefined==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return ;
    }
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Prefix"])
        {
            mPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName1F"])
        {
            mReferenceBufferName1F = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2F"])
        {
            mReferenceBufferName2F = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName3F"])
        {
            mReferenceBufferName3F = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName4F"])
        {
            mReferenceBufferName4F = [dictKeyDefined objectForKey:strKey] ;
        }
        
    }
    
    //Added by Annie in 2015.9.9 for detecting fixture return
    NSString *mReferenceBufferName1FValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1F];
    //Annie Debug
    //mReferenceBufferName1FValue=@"Fail";
    //Annie degug
    NSString *mReferenceBufferName2FValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2F];
    //Annie Debug
    //mReferenceBufferName2FValue=@"FAIL";
    //Annie Debug
    NSString *mReferenceBufferName3FValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName3F];
    NSString *mReferenceBufferName4FValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName4F];
    
    if ([mReferenceBufferName1FValue rangeOfString:@"Fail"].length>0|| [mReferenceBufferName1FValue rangeOfString:@"FAIL"].length>0 || [mReferenceBufferName2FValue rangeOfString:@"Fail"].length>0 || [mReferenceBufferName2FValue rangeOfString:@"FAIL"].length>0 || [mReferenceBufferName3FValue rangeOfString:@"Fail"].length>0 || [mReferenceBufferName3FValue rangeOfString:@"FAIL"].length>0 || [mReferenceBufferName4FValue rangeOfString:@"Fail"].length>0||[mReferenceBufferName4FValue rangeOfString:@"FAIL"].length>0)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fixture fail"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    }//Modified by Lorne on 20151203
    /*
    else if (mReferenceBufferName1FValue == nil || [mReferenceBufferName1FValue isEqualToString:@""]|| mReferenceBufferName2FValue == nil || [mReferenceBufferName2FValue isEqualToString:@""] || mReferenceBufferName3FValue == nil || [mReferenceBufferName3FValue isEqualToString:@""]|| mReferenceBufferName4FValue == nil||[mReferenceBufferName4FValue  isEqualToString:@""])
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fixture fail"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    }
     */
    else if(mReferenceBufferName1FValue == nil || [mReferenceBufferName1FValue isEqualToString:@""])
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CYLINDER1ON fail"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    } else if(mReferenceBufferName2FValue == nil || [mReferenceBufferName2FValue isEqualToString:@""] )
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CYLINDER2ON fail"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    } else if(mReferenceBufferName3FValue == nil || [mReferenceBufferName3FValue isEqualToString:@""])
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CYLINDER2OFF fail"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    } else if(mReferenceBufferName4FValue == nil||[mReferenceBufferName4FValue  isEqualToString:@""])
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Fixture fail"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CYLINDER1OFF"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        return;
    }
    
    
    NSString *mReferenceBufferValue ;
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                           :mPrefix Postfix
                                                           :mPostfix] ;
    
    if (([strFind rangeOfString:@"detect"].length == 0)&&([strFind rangeOfString:@"missed"].length > 0))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"1":nil:RESULT_FOR_PASS:@"PASS"];
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"PASS"] ;
        return;
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"];
        [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL"] ;
        return;
    }
}

// Read MBT fixture information need judge UpLimit and LowLimit,then upload UpLimit and LowLimit to PDCA.and put key value to BufferName,add by Annie  2012-11-15 
+(void)ParseStrWithStrSpecPostfixUpLowLimitForMBT:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	
	//NSString *fileName = @"/123.txt";
	//mReferenceBufferValue = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	//	
	NSLog(@"++++++++++++++++++++++++++++%@",mReferenceBufferValue);
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\\" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	NSLog(@"++++++++++++++++++++++++++++%@",mReferenceBufferValue);
	
	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *Value = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														 :mPrefix Postfix
														 :mPostfix] ;
	Value = [ToolFun deleteFromString:Value trimStr:@" "];//从字符串strKey 中删除字符 @"\t"
	
	
	if (Value==nil || [Value length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"can not get the normal data from fixture"] ;
		return ;
	}
	
	
	//if ([Value integerValue] < [mUpLimit integerValue] && [Value integerValue] > [mLowLimit integerValue])
	if(((mLowLimit==nil||[mLowLimit length]<=0)?1:([Value doubleValue] >=[mLowLimit doubleValue]))&&
	   ((mUpLimit==nil||[mUpLimit length]<=0)?1:([Value doubleValue]<=[mUpLimit doubleValue])))
	{
		enumResult = RESULT_FOR_PASS;
		//strTestResultForUIinfo = @"PASS ";
		strTestResultForUIinfo = Value;
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		//strTestResultForUIinfo = @"FAIL ";
		//strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:Value];
		strTestResultForUIinfo=Value;
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :Value] ; ///write test result and uiinfo.
	
	if(mBufferName != nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :Value] ;
	
	return ;
}

// Read string only from buffer,put the value of (BufferName-ReferenceBufferName) to BufferName address, and display the value to UI-------add by Annie  2012-11-21 
+(void)ParseStrOnlyFromBuffer:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	//NSString *mPDCAWrite =@"no"  ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		/*else if ([strKey isEqualToString:@"PDCAWrite"])
         {
         mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
         }*/
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	float BufferValue=[[TestItemManage getBufferValue:dictKeyDefined :mBufferName] floatValue];//get mBufferName value,and change it to floatvalue.
	float mReferenceBufferValue = [[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] floatValue];//get mReferenceBufferName value,and change it to floatvalue.
 	
	float Value=BufferValue-mReferenceBufferValue;
	//if ([Value integerValue] < [mUpLimit integerValue] && [Value integerValue] > [mLowLimit integerValue])
	if(((mLowLimit==nil||[mLowLimit length]<=0)?1:(Value >=[mLowLimit doubleValue]))&&
	   ((mUpLimit==nil||[mUpLimit length]<=0)?1:(Value <=[mUpLimit doubleValue])))
	{
		enumResult = RESULT_FOR_PASS;
		//strTestResultForUIinfo = @"PASS ";
		strTestResultForUIinfo =[NSString stringWithFormat:@"%f", Value];
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		strTestResultForUIinfo=[NSString stringWithFormat:@"%f", Value];;
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :[NSString stringWithFormat:@"%f", Value]] ; ///write test result and uiinfo.
	return ;
}
// Read string only from buffer,get the BufferName value, and display the value to UI-------add by Annie  2013-7-13
+(void)ParseStrFromBuffer:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	
	NSString *mBufferName=nil    ;
	//NSString *mPDCAWrite =@"no"  ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString * BufferValue=[TestItemManage getBufferValue:dictKeyDefined :mBufferName];//get mBufferName value,
    
    BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    BufferValue = [BufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if([BufferValue length] <= 0)
    {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"no receive data"] ;
	    return  ;
	}
 	
    //	float Value=BufferValue-mReferenceBufferValue;
    //	//if ([Value integerValue] < [mUpLimit integerValue] && [Value integerValue] > [mLowLimit integerValue])
    //	if(((mLowLimit==nil||[mLowLimit length]<=0)?1:(Value >=[mLowLimit doubleValue]))&&
    //	   ((mUpLimit==nil||[mUpLimit length]<=0)?1:(Value <=[mUpLimit doubleValue])))
    //	{
    //
    //		//strTestResultForUIinfo = @"PASS ";
    //		strTestResultForUIinfo =[NSString stringWithFormat:@"%f", Value];
    //	}
    //	else
    //	{
    //		enumResult = RESULT_FOR_FAIL;
    //		strTestResultForUIinfo=[NSString stringWithFormat:@"%f", Value];;
    //	}
	enumResult = RESULT_FOR_PASS;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :BufferValue] ; ///write test result and uiinfo.
	return ;
}


+(void)ParseStrWithStrSpec_CB:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil;
	NSString *mStrSpec=nil;// write cmd
	NSString *mReferenceBufferName=nil ;
	NSString *mBufferName=@"";
	NSString *mDevice=nil;
	NSString *mWriteCmd=nil;
	NSString *mWriteCmdEnd=@"\n";
	NSString *mEndString=@":-)";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"EndString"])
		{
			mEndString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		//if Fail, writ CB
		if(mWriteCmd == nil)
			mWriteCmd=@"fg 0x05 2";
		
		NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
		if (mWriteCmdEnd!=nil)
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
		
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mEndString] ;
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return ;
		}
		return ;
	}
	NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;
	
	if (rangeTmp.length > 0)  //PASS  conditional 
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}else //failse conditional
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Fail" ;
		//if Fail, writ CB
		if(mWriteCmd == nil)
			mWriteCmd=@"fg 0x05 2";
		
		NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
		if (mWriteCmdEnd!=nil)
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
		
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mEndString] ;
		
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return ;
		}
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

// add by Evan on 2010-12-19
+(void)ParseJudgeRevision:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	// add by Evan on 2010-12-21
	NSString* mICConfig=nil;
	// end;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		// add by Evan on 2010-12-21
		else if ([strKey isEqualToString:@"ICConfig"])
		{
			mICConfig=[dictKeyDefined objectForKey:strKey] ;
		}
		// end;
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	// add by Evan on 2010-12-21
	if (mICConfig==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"script error,No ICConfig"] ; 
		return ;
	}
	// end;
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;// modify by Evan on 2010-12-21 "mStrSpec --> mPostfix"
	
	// add by Evan on 2010-12-21
	NSString *value = [ToolFun allTrimFromString:strFind trimStr:@" " leftTrim:TRUE rightTrim:TRUE];
	
	NSRange rangeTmp = [mICConfig rangeOfString: value];
	
	if (rangeTmp.length > 0)  
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :value] ;
		return;
	}
	// end;
	
	// delete by Evan on 2010-12-21
	/*
	 NSRange rangeTmp=[strFind rangeOfString:@"B0"] ;
	 
	 if (rangeTmp.length > 0)  
	 {
	 [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
	 return;
	 }
	 */
	// end
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :value] ;// modify by Evan on 2010-12-21 "strFind --> value"
	return;
	
}

// end
//dsx 03-08 special string at testscript contain string that from diag is pass,eg.LG,CMI contain LG
+(void)ParseStrWithStrSpecPostfixLCDVendor:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	if (strFind==nil)
	{
		//	NSLog(@"%@",mReferenceBufferValue) ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	if (mStrSpec==nil)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = strFind ; 
	}else
	{
		strFind = [strFind stringByReplacingOccurrencesOfString:@" " withString:@""];
		
		NSRange rangeTmp=[mStrSpec rangeOfString:strFind] ;
		
		if (rangeTmp.length > 0)  //PASS  conditional 
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = strFind ;
		}else //failse conditional
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = strFind ;
		}
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

/*********************SCRID:156 Add the BBSN check by Kenshin 2012/01/04****/
+(void)ParseStrWithStrSpecPostfixBaseBand_SN:(NSDictionary*)dictKeyDefined
{
	//NSString *strTestResultForUIinfo ;
	//enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mReferenceBufferName1=nil;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName == nil || mReferenceBufferName1==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue =  nil;
	NSString *mReferenceBufferValue1 = nil;
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];
	//mReferenceBufferValue = @"0x1165FA8A";
	//mReferenceBufferValue1 = @"-g production-mode 0 :-)";
	
	if ((mReferenceBufferValue == nil) || (mReferenceBufferValue1==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *productionMode = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue1 Prefix
																  :mPrefix Postfix
																  :mPostfix];
	if (productionMode==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	productionMode = [productionMode stringByReplacingOccurrencesOfString:@" " withString:@""];
	productionMode = [productionMode stringByReplacingOccurrencesOfString:@"	" withString:@""];
	productionMode = [productionMode stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	productionMode = [productionMode stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	productionMode = [productionMode stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	
	if ( mReferenceBufferValue.length < 3)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	}
	
	NSString *strbbsn = [mReferenceBufferValue substringToIndex:3];
	
	if([strbbsn isEqualToString:@"0x2"])
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return ;
	}
	
	
	
	if ((([productionMode isEqualToString:@"0"]) && ([strbbsn isEqualToString:@"0x1"])) || (([productionMode isEqualToString:@"1"]) && ([strbbsn isEqualToString:@"0x4"])))
	{
		
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
		
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"AP not match BBSN"] ;
		
	}	
	
}

/*********************SCRID:156 Add the BBSN check by Kenshin 2012/01/04****/


+(void)CalculateAverageOfArray:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mReferenceBufferName=nil;
	NSString *mBufferName=nil;
	NSString *mFlag=nil;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"Flag"])
			mFlag = [dictKeyDefined objectForKey:strKey];
		else if ([strKey isEqualToString:@"Prefix"])
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"Postfix"])
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue = @"0,     4,    -9,  -949\n1,     4,    -9,  -946\n2,     3,   -11,  -947\n3,     4,    -5,  -945";
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSLog(@"mReferenceBufferValue= %@",mReferenceBufferValue);
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	
	NSArray* arrayTmp = [mReferenceBufferValue componentsSeparatedByString:@","] ;
	if (arrayTmp==nil || [arrayTmp count]<4)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no sample value or sample value less than 4"] ;
		return;
	}
	
	NSString *X=nil;
	NSString *Y=nil;
	NSString *Z=nil;
	
	X = [NSString stringWithFormat:@"%d",[[arrayTmp objectAtIndex:1] integerValue]];
	Y = [NSString stringWithFormat:@"%d",[[arrayTmp objectAtIndex:2] integerValue]];
	Z = [NSString stringWithFormat:@"%d",[[arrayTmp objectAtIndex:3] integerValue]];
	
	if (mBufferName!=nil)
	{
		if ([mFlag isEqualToString:@"X"])
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :X];
		else if ([mFlag isEqualToString:@"Y"])
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :Y];
		else if ([mFlag isEqualToString:@"Z"])
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :Z];
	}
	
	
	
}

+(void)CaculateSimulateAngleValueForHEFF:(NSDictionary*)dictKeyDefined
{
	NSString *mReferenceBufferName=nil;
    NSString *mTestItemName=nil;
    NSString *mBaseValue=nil;
	
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TestItemName"])
        {
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BaseValue"])
        {
			mBaseValue = [dictKeyDefined objectForKey:strKey] ;
        }
    }	
	if (mReferenceBufferName==nil || mBaseValue==nil)
    {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
    }
	
    //NSString *mReferenceBufferValue = @"9";
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
    {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
    }
	NSLog(@"mReferenceBufferValue= %@",mReferenceBufferValue);
    double simulateAngle = (360/(2*M_PI))*atan([mReferenceBufferValue doubleValue]/[mBaseValue doubleValue]);
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",simulateAngle]] ;
    return;
}
//add by judith 2012-05-17
+(void)ParseStrWithStrSpecForHellEffect:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	//NSString *mStrSpec=nil      ;// write cmd
    NSString *mCenterStrSpec=nil      ;// write cmd
    NSString *mEdgeStrSpec=nil      ;// write cmd
	
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;
	NSString *mByPassBufferName = nil;
    NSString *mSetByPassBufferName = nil;
    NSString *mWriteCmdArray = nil;
	NSString *mWriteCmdEnd = @"\n";
    NSString *mPostfix = @"RS=";
    NSString *mWhetherRead = @"yes" ;
    NSString *mTimeOut=@"2"      ;
    NSString *mDevice=nil     ;
    NSString *mBufferName0=nil     ;
    NSString *mBufferName1=nil     ;
    NSString *mBufferName2=nil     ;
    NSString *motorCmd = nil    ;
    BOOL moveDoneFlag = TRUE    ;
	NSString *mBufferNameInitDistance=nil     ;
    //int updateDistanceCount = 0;
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"ItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"writeCmd"])
		{
			mWriteCmdArray = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName0"])
		{
			mBufferName0 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName1"])
		{
			mBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName2"])
		{
			mBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
        /*
         else if ([strKey isEqualToString:@"StrSpec"])
         {
         mStrSpec = [dictKeyDefined objectForKey:strKey] ;
         }
         */
        else if ([strKey isEqualToString:@"CenterStrSpec"])
		{
			mCenterStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"EdgeStrSpec"])
		{
			mEdgeStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"ByPassBufferName"])
		{
			mByPassBufferName = [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"writeCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"setByPassBufferName"])
		{
			mSetByPassBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"motorCmdFL"])
		{
			motorCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameInitDistance"])
		{
			mBufferNameInitDistance = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	NSString * mByPassBufferNameValue = [TestItemManage getBufferValue:dictKeyDefined :mByPassBufferName];
    if([mByPassBufferNameValue isEqualToString:@"BYPASS"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"Not been triggered, bypass this item"] ;
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName0 :@"Not been triggered, bypass this item"] ;
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :@"Not been triggered, bypass this item"] ;
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :@"Not been triggered, bypass this item"] ;
        return ;
    }
    
	/*Set the offset value to a file and get from this file, 2012-08-16 ,Robert*/
	NSString *strPath = @"/vault/CalibrationData_Hall.txt";
	NSString *strFileContent = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (strFileContent==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no calibration file or no offset/initDistance Value, please calibrate firstly"] ;
		return;
	}
	mBufferNameInitDistance = strFileContent;
	/*Set the offset value to a file and get from this file, 2012-08-16 ,Robert, end*/
	
    if (mCenterStrSpec==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    if (mEdgeStrSpec==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	NSMutableArray *writeCmdArray = [[[NSMutableArray alloc]init]autorelease];
    [writeCmdArray addObjectsFromArray: [mWriteCmdArray componentsSeparatedByString:@","]];
    
    
    NSMutableArray *dataResultArray = [self SendManyCmds:dictKeyDefined Cmds:writeCmdArray WriteCmdEnd:mWriteCmdEnd Postfix:@":-)" TimeOut:mTimeOut];
    
	
	NSString *mReferenceBufferValue0 = nil,*mReferenceBufferValue1 = nil,*mReferenceBufferValue2 = nil;
    int count = [writeCmdArray count];
	
	for(int i = 0; i < [dataResultArray count];i++)
	{
		NSString *resultString = [dataResultArray objectAtIndex:i];
		if([resultString rangeOfString:@"hallsensor --meas 1 --irq 0"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName0] == nil)
			mReferenceBufferValue0 = resultString ;
		else if([resultString rangeOfString:@"hallsensor --meas 1 --irq 1"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName1] == nil)
			mReferenceBufferValue1 = resultString ;
		else if([resultString rangeOfString:@"hallsensor --meas 1 --irq 2"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName2] == nil)
			mReferenceBufferValue2 = resultString ;
	}
    [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
    float distance =[self CalculatDistanceUsingProximity:dictKeyDefined];
	[dictKeyDefined setValue:@"IPad" forKey:@"Device"];
    
    BOOL flag1 =TRUE;   //guarantee the fist value set into the buffer and only set once
    BOOL flag0 = TRUE;
    BOOL flag2 = TRUE;
    
    float triggerLimit = 0;
    float releaseLimit = 82;
	
    if([mTestItemName rangeOfString:@"trigger"].length > 0 ||[mTestItemName rangeOfString:@"Trigger"].length > 0)
    {
        triggerLimit = 1;
        //motorCmd = @"FL1000\r\n";
        if(distance < triggerLimit)              //if the distance < 1mm fail
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HHHHHHHHHHHHHHHHH distance is < 1.0"] ;
            return;
        }
        
    }
    else if([mTestItemName rangeOfString:@"Release"].length > 0 ||[mTestItemName rangeOfString:@"release"].length > 0)
    {
        releaseLimit = 19.5;
        //motorCmd = @"FL-1000\r\n";
        //timesRelease = 0;
        if(distance > releaseLimit)              //if the distance < 1mm fail
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HHHHHHHHHHHHHHHHH distance is > 19.5"] ;
            return;
        }
    }
	int countSendTimes = 0;
	while((triggerLimit == 1 && distance > triggerLimit) || (releaseLimit == 19.5 && distance < releaseLimit))
	{
		//if([mReferenceBufferValue0 rangeOfString:mStrSpec].length > 0 && flag0)
        //modifid by Annie for polarity reversed altering of "hall sensor 0" and "hall sensor 1" 20140403
        if([mReferenceBufferValue0 rangeOfString:mEdgeStrSpec].length > 0 && flag0)
		{
			flag0 = FALSE;
			if(mBufferName0 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName0] == nil)
			{
				[dictKeyDefined setValue:@"Prox" forKey:@"Device"];
				distance =[self CalculatDistanceUsingProximity:dictKeyDefined];
				[dictKeyDefined setValue:@"IPad" forKey:@"Device"];
				[writeCmdArray removeObject:@"hallsensor --meas 1 --irq 0"];
				//float tmpDistance = distance + 0.5 - [mBufferNameInitDistanceValue floatValue];
				distance = distance + 0.5 - [mBufferNameInitDistance floatValue];
                NSLog(@"hell log ParseInitPositionHESTest  distance 5 =  %f initDistance = %f",distance,[mBufferNameInitDistance floatValue]);
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName0 :[NSString stringWithFormat:@"%f",distance]] ;
			}
			
		}
        if([mReferenceBufferValue1 rangeOfString:mCenterStrSpec].length > 0 && flag1)
            //modifid by Annie for polarity reversed altering of "hall sensor 0" and "hall sensor 1" 20140403
            //if([mReferenceBufferValue1 rangeOfString:mStrSpec].length > 0 && flag1)
		{
			flag1 = FALSE;
			if(mBufferName1 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName1] == nil)
			{
				[dictKeyDefined setValue:@"Prox" forKey:@"Device"];
				distance =[self CalculatDistanceUsingProximity:dictKeyDefined];
				[dictKeyDefined setValue:@"IPad" forKey:@"Device"];
				[writeCmdArray removeObject:@"hallsensor --meas 1 --irq 1"];
				//float tmpDistance = distance + 0.5 - [mBufferNameInitDistanceValue floatValue];
				distance = distance + 0.5 - [mBufferNameInitDistance floatValue];
				NSLog(@"hell log ParseInitPositionHESTest  distance 5 =  %f initDistance = %f",distance,[mBufferNameInitDistance floatValue]);
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :[NSString stringWithFormat:@"%f",distance]] ;
			}
		}
		if([mReferenceBufferValue2 rangeOfString:mCenterStrSpec].length > 0 && flag2)
		{
			flag2 = FALSE;
			if(mBufferName2 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName2] == nil)
			{
				[dictKeyDefined setValue:@"Prox" forKey:@"Device"];
				distance =[self CalculatDistanceUsingProximity:dictKeyDefined];// count distance in case of < 1mm
				[dictKeyDefined setValue:@"IPad" forKey:@"Device"];
				[writeCmdArray removeObject:@"hallsensor --meas 1 --irq 2"];
				//float tmpDistance = distance + 0.5 - [mBufferNameInitDistanceValue floatValue];
				distance = distance + 0.5 - [mBufferNameInitDistance floatValue];
				NSLog(@"hell log ParseInitPositionHESTest  distance 5 =  %f initDistance = %f",distance,[mBufferNameInitDistance floatValue]);
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :[NSString stringWithFormat:@"%f",distance]] ;
			}
		}
		else if((mReferenceBufferValue0 != nil && [mReferenceBufferValue0 rangeOfString:@"0x1"].length == 0 && [mReferenceBufferValue0 rangeOfString:@"0x0"].length == 0) ||
                (mReferenceBufferValue1 != nil && [mReferenceBufferValue1 rangeOfString:@"0x1"].length == 0 && [mReferenceBufferValue1 rangeOfString:@"0x0"].length == 0) ||
                (mReferenceBufferValue2 != nil && [mReferenceBufferValue2 rangeOfString:@"0x1"].length == 0 && [mReferenceBufferValue2 rangeOfString:@"0x0"].length == 0))//in case of the receive data is garbage
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The recedata is abnormal!maybe received data is messy code,see the console log(find 'dataResult is')and Please be careful your operation or check the tray"] ;
            return;
        }
		BOOL mark = FALSE;
		NSMutableString *markContent = [[[NSMutableString alloc]init]autorelease];
		
		switch (count) {
			case 1:
				if (!flag0 || !flag1) {
					mark = TRUE;
					[markContent appendString:@"only 1 sensor"];
				}
				break;
			case 2:
				if (!flag0 && !flag1) {
					mark = TRUE;
					[markContent appendString:@"only 2 sensors"];
				}
				break;
			case 3:
				if (!flag0 && !flag1 && !flag2) {
					mark = TRUE;
					[markContent appendString:@"3 sensors"];
				}
				break;
			default:
				break;
		}
		if(mark)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :markContent] ;
			return;
		}
		NSLog(@"motor = %@",motorCmd);
		[dictKeyDefined setValue:@"Motor" forKey:@"Device"];
		bool bTmp = [self SendData:dictKeyDefined :motorCmd :@"%"] ;        // move 1 mm then read again
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return;
		}
        moveDoneFlag = TRUE  ;
        while (moveDoneFlag)
        {
            bool bTmp1 = [self SendData:dictKeyDefined :@"RS\r\n" :mPostfix] ;
            
            if (bTmp1==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return ;
            }
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ;
                }
                
            }
            NSString *dataResult = [self ReceData:dictKeyDefined] ;
            if (dataResult==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
                return ;
            }
            if ([dataResult rangeOfString:@"RS=R"].length > 0)
            {
                moveDoneFlag = FALSE;
            }
            
        }
		
		[dictKeyDefined setValue:@"IPad" forKey:@"Device"];
		dataResultArray = [self SendManyCmds:dictKeyDefined Cmds:writeCmdArray WriteCmdEnd:mWriteCmdEnd Postfix:@":-)" TimeOut:mTimeOut];
		if(dataResultArray == nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail/NO Receive Data"] ;
			return;
		}
		for(int i = 0; i < [dataResultArray count];i++)
		{
			NSString *resultString = [dataResultArray objectAtIndex:i];
			if([resultString rangeOfString:@"hallsensor --meas 1 --irq 0"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName0] == nil)
				mReferenceBufferValue0 = resultString ;
			else if([resultString rangeOfString:@"hallsensor --meas 1 --irq 1"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName1] == nil)
				mReferenceBufferValue1 = resultString ;
			else if([resultString rangeOfString:@"hallsensor --meas 1 --irq 2"].length > 0 && [TestItemManage getBufferValue:dictKeyDefined :mBufferName2] == nil)
				mReferenceBufferValue2 = resultString ;
		}
        //add by judith to reduce the CT 20130326
        countSendTimes ++;
        if (countSendTimes >= 20)
        {
            [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
            distance =[self CalculatDistanceUsingProximity:dictKeyDefined];
            [dictKeyDefined setValue:@"IPad" forKey:@"Device"];
        }
        //add end 20130326
		NSLog(@" mReferenceBufferValue0 = %@,mReferenceBufferValue1 = %@,mReferenceBufferValue2 = %@,",mReferenceBufferValue0,mReferenceBufferValue1,mReferenceBufferValue2);
    }
	
    if([mTestItemName rangeOfString:@"trigger"].length > 0 ||[mTestItemName rangeOfString:@"Trigger"].length > 0)
    {
        if(mBufferName0 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName0] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName0 :@"0"] ;
        if(mBufferName1 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName1] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :@"0"] ;
        if(mBufferName2 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName2] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :@"0"] ;
        [TestItemManage setBufferValue:dictKeyDefined :mByPassBufferName :@"BYPASS"] ;
    }
    else
    {
        if(mBufferName0 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName0] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName0 :@"20"] ;
        if(mBufferName1 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName1] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName1 :@"20"] ;
        if(mBufferName2 != nil && [TestItemManage getBufferValue:dictKeyDefined :mBufferName2] == nil)
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName2 :@"20"] ;
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
    return;
    
}

+(NSMutableArray *)SendManyCmds:(NSDictionary *)dictKeyDefined
                    Cmds       :(NSMutableArray*)writeCmdArray 
                    WriteCmdEnd:(NSString *)mWriteCmdEnd
                    Postfix    :(NSString *)mPostfix
                    TimeOut    :(NSString *)mTimeOut
{
    
    NSMutableArray *dataResultArray =[[[NSMutableArray alloc]init]autorelease];
    for(int i = 0;i < [writeCmdArray count]; i++)
    {
        NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:i]];
        NSLog(@"send the data is string %@",string);
        if (mWriteCmdEnd!=nil)
        {
            if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
            {
                NSLog(@"NOCMDEND");
            }
            else
                [string appendString:mWriteCmdEnd] ;
        }
        
        bool bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
            return nil;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined];
        NSLog(@"dataResult is %@",dataResult);
        //dataResult=@"0x0";
        int count = 0;
        while ([dataResult rangeOfString:@"0x1"].length == 0 && [dataResult rangeOfString:@"0x0"].length == 0)
        {
            count++;
            usleep(100000);
            bTmp = [self SendData:dictKeyDefined :string :mPostfix] ;
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmdsTwo: send data fail "] ;
                return nil;
            }
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(100000) ;
                }
            }
            
            dataResult = [self ReceData:dictKeyDefined];
            if (count == 3) {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
                return nil;
            }
            
        }
        [dataResultArray addObject:dataResult] ;
    }
    
    return dataResultArray;
}

+ (float)CalculatDistanceUsingProximity:(NSDictionary*)dictKeyDefined
{
    unsigned char singleByteArray[] = {0x81,0x04,0x41,0x44};
    NSData *singleByteData = [NSData dataWithBytes:singleByteArray length:4];
    NSLog(@"singleByteData = %@",singleByteData);
    bool bTmp = [self SendDataAsNSData:dictKeyDefined :singleByteData :nil];
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send 0x81 data fail "] ;
        return 0;
    }
    usleep(125000);//125ms modified from 150 to 125 by Judith 20130402
    NSData *dataReceTmp = [self ReceDataAsNSData:dictKeyDefined] ;
	//NSLog(@"DDDDDDDDDDDdataReceTmp = %d",[dataReceTmp length]);
    // NSLog(@"DDDDDDDDDDDDDDDDDdataReceTmp = %@",dataReceTmp);
    //unsigned char test[] = {0x81,0x06,0x59,0x71,0x66,0x49};
    //dataReceTmp =[NSData dataWithBytes:test length:6];
	NSLog(@"[dataReceTmp length] = %d",[dataReceTmp length]);
	if([dataReceTmp length] < 6)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"CalculatDistanceUsingProximity:Receive data length < 6 "] ;
        return 0;
	}
    NSData *fourthData = [dataReceTmp subdataWithRange:NSMakeRange(3, 1)];
    NSData *fifthData = [dataReceTmp subdataWithRange:NSMakeRange(4, 1)];
    unsigned char *resp3 =[fourthData bytes];
    unsigned char *resp4 =[fifthData bytes];
    NSLog(@"resp3 = %hhu,resp4 = %hhu",*resp3,*resp4);
    float distance_actual = [self CalculateDistanceFromBytes:*resp3 low:*resp4];
    float sensor_cal_distance =82;
    float distance = (distance_actual * -1.0) + sensor_cal_distance;
    NSLog(@"distance is %f",distance);
    return distance;
}


+(float) CalculateDistanceFromBytes:(unsigned char) high low:(unsigned char) low
{
    float sensor_scale_factor =(sensor_full_scale / 4095); //220/4095 = 0.053724
    unsigned short acc = 0; 
    // drop bits 7 and 6 from high
    NSLog(@"resp3 = %hhu,resp4 = %hhu",high,low);
    acc = (0x3F & high); 
    // move high niblet up 6 bits
    acc <<= 6; 
    // drop bits 7 and 6 from low
    acc |= (0x3F & low); 
    // scale and return mm's
    return (fabs(sensor_full_scale - (acc * sensor_scale_factor)));//(220-(acc * 0.053724))
}
//end add judith 2012-05-17

//joko add a parser ParseStrWithStrSpecForButtonsTest, 2012-04-09
+(void)ParseStrWithStrSpecForButtonsTest:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mNotContainString=nil    ;
	NSString *mContainString =nil    ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ContainString"])
		{
			mContainString = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"NotContainString"])
		{
			mNotContainString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue = @" Press 'Q'/'q' To Stop TestMenu gets pressed 1 times. VolDn gets pressed 1 times. Menu gets pressed 2 times. Button Count Test Done.";
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
	
	
	if(([mReferenceBufferValue rangeOfString:mContainString].length > 0) && ([mReferenceBufferValue rangeOfString:mNotContainString].length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
	}
}
//joko add end

//add by jduith 2012-0804 for HES Init Position test item
+(void)ParseInitPositionHESTest:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
    
	NSString *mUpperValue=nil   ;
	NSString *mLowerValue=nil   ;
	NSString *mBufferName=nil    ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mPostfix =@"RS=";
	NSString *mTestItemName=nil     ;
	NSString *mReferenceBufferName=nil     ;
    float mInitLocation = 0.5   ;
	BOOL moveDoneFlag = TRUE;
    enum TestResutStatus enumResult = RESULT_FOR_FAIL;
    int loopTimes = 0 ;
	NSString *mHeffDistance=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"initLocation"])  
		{
			mInitLocation= [[dictKeyDefined objectForKey:strKey] floatValue] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"HeffDistance"])
        {
            mHeffDistance = [dictKeyDefined objectForKey:strKey] ;
        }
	}
	
    [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
    float distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
    
    NSLog(@"hell log ParseInitPositionHESTest  distance 0 =  %f",distance);
	//return;
	
    
    NSString *strPath = @"/vault/CalibrationData_Hall.txt";
	NSString *strFileContent = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (strFileContent==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no calibration file or no offset/initDistance Value, please calibrate firstly"] ;
		return;
	}
    //15 < realDistance = Distance + 0.5 - CallibrationData < 15.25  ->Distance -15 should be in [CallibrationData-0.5,CallibrationData - 0.25] 
    float mCallibrationData = [strFileContent floatValue];
    NSLog(@"mCallibrationData = %f",mCallibrationData);
    
    float fromUnitDistanceSub15mm = (distance  + mInitLocation - mCallibrationData) - [mHeffDistance floatValue];

    
    while (fromUnitDistanceSub15mm < 0 || fromUnitDistanceSub15mm > 0.25) 
    {
		
        if(fromUnitDistanceSub15mm > -1 && fromUnitDistanceSub15mm < 0)
        {
            mWriteCmd = @"FL-250\r"; 
        }
        else if(fromUnitDistanceSub15mm <= -1)
        {
            mWriteCmd = @"FL-500\r"; 
        }
        else if (fromUnitDistanceSub15mm >=1 ) 
        {
            mWriteCmd = @"FL500\r";
        }
        else
            mWriteCmd = @"FL250\r";
        
        NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
        
        if (mWriteCmdEnd!=nil)
        {
            if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
            {
                NSLog(@"NOCMDEND");
            }
            else
                [strMutSendBuffer appendString:mWriteCmdEnd] ;
        }
        
        loopTimes++    ;
        if (loopTimes == 10) 
        {
            break;
        }
        
        [dictKeyDefined setValue:@"Motor" forKey:@"Device"];
        
        bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        moveDoneFlag = TRUE ;
		[self SendData:dictKeyDefined :@"clean\r" :@"%"] ;
        /*add for receive the info after send the clean*/
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(100000) ; 
            }
            
        }
        /*add for receive the info after send the clean*/
        while (moveDoneFlag) // check if the motor complete moving
        {
            bool bTmp1 = [self SendData:dictKeyDefined :@"RS\r\n" :mPostfix] ;
            
            if (bTmp1==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return ;
            }
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(100000) ; 
                }
                
            }
            NSString *dataResult = [self ReceData:dictKeyDefined] ;
            if (dataResult==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
                return ;
            }
            if ([dataResult rangeOfString:@"RS=R"].length > 0) 
            {
                moveDoneFlag = FALSE;
            }
			
        }
        [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
        distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
        fromUnitDistanceSub15mm = (distance  + mInitLocation - mCallibrationData) - [mHeffDistance floatValue];
        
        NSLog(@"hall log ParseInitPositionHESTest  distance 1 =  %f",distance);
    }
    if( mBufferName != nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",distance]] ;
	
	float realDistance = 0;
    realDistance = distance + mInitLocation - mCallibrationData  ;
    
    NSLog(@"hall log ParseInitPositionHESTest  distance 3 %f =  %f + 0.5 - %f",realDistance,distance,mCallibrationData);
    if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(realDistance >=[mLowerValue floatValue]))
       && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(realDistance<=[mUpperValue floatValue])))
    {
        enumResult =RESULT_FOR_PASS ;
    }else 
    {
        enumResult =RESULT_FOR_FAIL ;
    }
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :[NSString stringWithFormat:@"%f",realDistance]] ;
    return ;
	
}

+(void)ParseCompareDevieColor:(NSDictionary*)dictKeyDefined
{
    //key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mRecord=@"no";
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if([strKey isEqualToString:@"Record"])
		{
			mRecord=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//mReferenceBufferValue = @"0,     4,    -9,  -949\n1,     4,    -9,  -946\n2,     3,   -11,  -947\n3,     4,    -5,  -945";
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :strFind] ;
	}
    
    if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
    {
        NSString *HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
        //HWCofig = @"HWCONFIG:WIFI&BT/LG100MHz/NAND,SIZE=64G/RAM,SIZE=1G/WHITE";
        if([HWCofig length] < 1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HWCofig is Null"] ;
            return ;
        }
            // gray:        000200009B9899003C3B3B0000000000  black
            // gold:        00020000B3C5D400E3E4E10000000000
            // silver:      00020000D8D9D700E3E4E10000000000  whit
        //disable by kevin 20151001 start
        
        if(([strFind rangeOfString:@"0x00000200 0x00D7D9D8 0x00E1E4E3 0x00000000"].length > 0) &&
           ([HWCofig rangeOfString:@"White"].length > 0 || [HWCofig rangeOfString:@"WHITE"].length > 0 || [HWCofig rangeOfString:@"white"].length > 0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00B4B5B9 0x003B3B3C 0x00000000"].length > 0) &&
                ([HWCofig rangeOfString:@"Black"].length > 0 || [HWCofig rangeOfString:@"BLACK"].length > 0 || [HWCofig rangeOfString:@"black"].length > 0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ; 
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00E1CCB5 0x00E1E4E3 0x00000000"].length > 0) &&
                ([HWCofig rangeOfString:@"Cashmere"].length > 0 || [HWCofig rangeOfString:@"CASHMERE"].length > 0 || [HWCofig rangeOfString:@"cashmere"].length > 0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
        }
        else if(([strFind rangeOfString:@"0x00000200 0x00E4C1B9 0x00E1E4E3 0x00000000"].length > 0) &&
                ([HWCofig rangeOfString:@"Rose Gold"].length > 0 || [HWCofig rangeOfString:@"rose gold"].length > 0 || [HWCofig rangeOfString:@"ROSE GOLD"].length > 0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
        }
        
        //disable by kevin 20151001 end
//        //add by kevin 20151001 start
//        if(([strFind rangeOfString:@"0x00000200 0x00B9B7BA 0x00272728 0x00000000"].length > 0) &&
//           ([HWCofig rangeOfString:@"White"].length > 0 || [HWCofig rangeOfString:@"WHITE"].length > 0 || [HWCofig rangeOfString:@"white"].length > 0))
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
//        }
//        else if(([strFind rangeOfString:@"0x00000200 0x00DADCDB 0x00E4E7E8 0x00000000"].length > 0) &&
//                ([HWCofig rangeOfString:@"Black"].length > 0 || [HWCofig rangeOfString:@"BLACK"].length > 0 || [HWCofig rangeOfString:@"black"].length > 0))
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
//        }
//        else if(([strFind rangeOfString:@"0x00000200 0x00E1CCB7 0x00E4E7E8 0x00000000"].length > 0) &&
//                ([HWCofig rangeOfString:@"Cashmere"].length > 0 || [HWCofig rangeOfString:@"CASHMERE"].length > 0 || [HWCofig rangeOfString:@"cashmere"].length > 0))
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
//        }
//        else if(([strFind rangeOfString:@"0x00000200 0x00E4C1B9 0x00E4E7E8 0x00000000"].length > 0) &&
//                ([HWCofig rangeOfString:@"Cashmere"].length > 0 || [HWCofig rangeOfString:@"CASHMERE"].length > 0 || [HWCofig rangeOfString:@"cashmere"].length > 0))
//        {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind] ;
//        }
//        
//        //add by kevin 20151001 end 
        
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFind] ;
        }
    }
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFind] ;
	
}

+(void)ParseGrapeSubItem:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = @"";
    NSString *mReferenceBufferName = @"";
    NSString *mStrSpec = @"";
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
    }
    
    BOOL resFlag = TRUE;
    NSString *failUIIfnfo = @"Fail,";
    
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/AppConfig copy.txt" encoding:NSASCIIStringEncoding error:nil] ;
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    
    NSArray *arraySubItems = [mReferenceBufferValue componentsSeparatedByString:@"Limits check for"];
    for(int i=1; i<[arraySubItems count]; i++)
    {
        NSString *subItemContent = [arraySubItems objectAtIndex:i];
//        subItemContent = [subItemContent stringByAppendingFormat:@"_%d",i];
        NSString *strFindValue = [ToolFun getStrFromPrefixAndPostfix:subItemContent Prefix
                                                                    :@"VALUE =" Postfix
                                                                    :@","] ;
        NSString *strFindLow = [ToolFun getStrFromPrefixAndPostfix:subItemContent Prefix
                                                                  :@"LOW =" Postfix
                                                                  :@","] ;
        NSString *strFindHigh = [ToolFun getStrFromPrefixAndPostfix:subItemContent Prefix
                                                                   :@"HIGH =" Postfix
                                                                   :@","] ;
        NSString *sutItemName = [ToolFun getStrFromPrefixAndPostfix:subItemContent Prefix
                                                                   :@"\'" Postfix
                                                                   :@"\'"] ;
        NSString *strColumn = [ToolFun getStrFromPrefixAndPostfix:subItemContent Prefix
                                                                 :@"Column " Postfix
                                                                 :@":"];
        strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strFindValue = [strFindValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        strFindHigh = [strFindHigh stringByReplacingOccurrencesOfString:@" " withString:@""];
        strFindHigh = [strFindHigh stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        strFindHigh = [strFindHigh stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strFindHigh = [strFindHigh stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        strFindLow = [strFindLow stringByReplacingOccurrencesOfString:@" " withString:@""];
        strFindLow = [strFindLow stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        strFindLow = [strFindLow stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strFindLow = [strFindLow stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        sutItemName = [sutItemName stringByReplacingOccurrencesOfString:@" " withString:@""];
        sutItemName = [sutItemName stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        sutItemName = [sutItemName stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        sutItemName = [sutItemName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        strColumn = [strColumn stringByReplacingOccurrencesOfString:@" " withString:@""];
        strColumn = [strColumn stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        strColumn = [strColumn stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        strColumn = [strColumn stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        
        if (strColumn !=nil)
        {
            sutItemName = [sutItemName stringByAppendingString:@"_"];
            sutItemName = [sutItemName stringByAppendingString:strColumn];
        }
        
        
        if([strFindLow rangeOfString:@"N/A"].length > 0)
            strFindLow=nil;
        if([strFindHigh rangeOfString:@"N/A"].length > 0)
            strFindHigh=nil;
        if([strFindValue rangeOfString:@"N/A"].length > 0)
            strFindValue=nil;
        
        if(((strFindLow==nil||[strFindLow length]<=0)?1:([strFindValue floatValue] >= [strFindLow floatValue]))
           && ((strFindHigh==nil||[strFindHigh length]<=0)?1:([strFindValue floatValue] <= [strFindHigh floatValue])))
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined :sutItemName :nil :strFindLow :strFindHigh :strFindValue :nil:RESULT_FOR_PASS:nil];
        }else
        {
            resFlag = FALSE;
            failUIIfnfo = [failUIIfnfo stringByAppendingString:sutItemName];
            failUIIfnfo = [failUIIfnfo stringByAppendingString:@","];
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined :sutItemName :nil :strFindLow :strFindHigh :strFindValue :nil:RESULT_FOR_FAIL:@"Fail"];
        }
    }
    
    
    if([mReferenceBufferValue rangeOfString:mStrSpec].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
        if(!resFlag)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failUIIfnfo] ;
        }
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failUIIfnfo] ;
    }
    
}


//joko add a parser ParseStrWithStrSpecForButtonsTest, 2012-11-13
+(void)ParseStrWithStrSpecForButtonsTestV2:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mNotContainString=nil    ;
	NSString *mContainString =nil    ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ContainString"])
		{
			mContainString = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"NotContainString"])
		{
			mNotContainString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	if([mContainString rangeOfString:@"gets pressed 1 times"].length > 0)
        timesOfPressButton = 1;
    else
        mContainString=[mContainString stringByReplacingOccurrencesOfString:@"NNN" withString:[NSString stringWithFormat:@"%d",timesOfPressButton]];
    
    if([mNotContainString rangeOfString:@"gets pressed 2 times"].length > 0)
        ;
    else
        mNotContainString=[mNotContainString stringByReplacingOccurrencesOfString:@"NNN+1" withString:[NSString stringWithFormat:@"%d",timesOfPressButton+1]];
    
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	//NSString *mReferenceBufferValue = @" Press 'Q'/'q' To Stop TestMenu gets pressed 1 times. VolDn gets pressed 1 times. Menu gets pressed 2 times. Button Count Test Done.";
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
	
	
	if(([mReferenceBufferValue rangeOfString:mContainString].length > 0) && ([mReferenceBufferValue rangeOfString:mNotContainString].length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
        timesOfPressButton++;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
	}
}
//joko add end
//add by judith 20130129
/*---------------------------------delete by Annie-------------------------
+(void)ParseStrCompoForNVTest:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    NSArray *mStrSpecArray = [mStrSpec componentsSeparatedByString:@","];
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //mReferenceBufferValue = @"4B FD 30 00 00 00 0F 00 43 84 00 00 9F 00 00 00  K.0.....C.......";
    NSArray *mReferenceBufferValueArray = [mReferenceBufferValue componentsSeparatedByString:@" "];
    if ([mReferenceBufferValueArray count] < 6) 
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Recieve data is error"] ;
	    return  ;
    }
    NSString *specString = [mReferenceBufferValueArray objectAtIndex:4];
    NSString *tmp = [mReferenceBufferValueArray objectAtIndex:5];
    specString = [specString stringByAppendingString:tmp];
    
    
    BOOL flag = FALSE;
    for (int i = 0; i < [mStrSpecArray count]; i++) 
    {
        if ([specString isEqualToString:[mStrSpecArray objectAtIndex:i]])
        {
            flag = TRUE;
        }
    }
    if (flag) 
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:specString] ;
        return;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:specString] ;
        return; 
    }
    
}
 */
//add end
+(void)ParseStrCompoForNVTest:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
    //	if (mStrSpec==nil ||
    //		mReferenceBufferName==nil
    //		)
    //	{
    //		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
    //	    return  ;
    //	}
    //NSArray *mStrSpecArray = [mStrSpec componentsSeparatedByString:@","];
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //mReferenceBufferValue = @"Response: 0000000: 4B FD 30 00 00 00 0F 00 43 84 00 00 9B 00 00 00  K.0.....C....... 0000010: 00 00 00 00 DF 10 0F 03 00 00 00 00 0F 00 43 84  ..............C. 0000020: 00 00 9F 00 00 00 00 00 00 00 DF 10 0F 03 00 00  ................ 0000030: 00 00";
    if ([mReferenceBufferValue rangeOfString:@"0000000: 4B FD 30 00 01 00"].length > 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
        return;
    } else {
//        if ([mReferenceBufferValue rangeOfString:@"0000000: 4B FD 30 00 00 00 0F 00 43 84 00 00 9B 00 00 00  K.0.....C....... 0000010: 00 00 00 00 DF 10 0F 03 00 00 00 00 0F 00 43 84  ..............C. 0000020: 00 00 9F 00 00 00 00 00 00 00 DF 10 0F 03 00 00  ................ 0000030: 00 00"].length > 0) {
//            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"PASS"] ;
//            return;
//        } else {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"FAIL"] ;
            return;
//        }
    }
    
    //    NSArray *mReferenceBufferValueArray = [mReferenceBufferValue componentsSeparatedByString:@" "];
    //    if ([mReferenceBufferValueArray count] < 6)
    //    {
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Recieve data is error"] ;
    //	    return  ;
    //    }
    //    NSString *specString = [mReferenceBufferValueArray objectAtIndex:4];
    //    NSString *tmp = [mReferenceBufferValueArray objectAtIndex:5];
    //    specString = [specString stringByAppendingString:tmp];
    //
    //
    //    BOOL flag = FALSE;
    //    for (int i = 0; i < [mStrSpecArray count]; i++)
    //    {
    //        if ([specString isEqualToString:[mStrSpecArray objectAtIndex:i]])
    //        {
    //            flag = TRUE;
    //        }
    //    }
    //    if (flag)
    //    {
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:specString] ;
    //        return;
    //    }
    //    else
    //    {
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:specString] ;
    //        return; 
    //    }
    
}

+(void)ParsePlistTestItems:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;
	NSString *mReferenceBufferName=nil ;
    NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
    NSString *mTheKeyOfTheTestItemDictionary=nil ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpecKK"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TheKeyOfTheTestItemDictionary"])
		{
			mTheKeyOfTheTestItemDictionary = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
    if (mStrSpec==nil ||
        mReferenceBufferName==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Users/lijiansheng/Desktop/A-1.txt" encoding:NSASCIIStringEncoding error:nil] ;
    
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No receive data"] ;
        return  ;
    }
    
    
    
    if ([mReferenceBufferValue rangeOfString:mStrSpec].length <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return unexpected data"] ;
        return  ;
    }
    
    NSString *fileContent = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                               :mPrefix Postfix
                                                               :mPostfix] ;
    
    NSString *fileName= @"/GyroSanity.plist";
    FILE* fp=NULL;
    fp=fopen([fileName UTF8String],"wr");
    fclose(fp);
    
    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:fileName];
    if (filehandTmp==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"cann't create a plist file in root path"] ;
        return  ;
    }
    
    [filehandTmp seekToEndOfFile] ;
    [filehandTmp writeData:[NSData dataWithData:[fileContent dataUsingEncoding:NSASCIIStringEncoding]]] ;
    [filehandTmp closeFile] ;
    
    NSDictionary *referenceDict = [NSDictionary dictionaryWithContentsOfFile:fileName];
    
    NSArray *arrayTmp = [referenceDict allKeys];
    
    if ([arrayTmp count] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no test item 1"] ;
        return  ;
    }
    
    BOOL boolAllResult = FALSE;
    
    for(int i=0; i<[arrayTmp count]; i++)
    {
        NSDictionary *referenceDict222 = [referenceDict objectForKey:[arrayTmp objectAtIndex:i]];
        
        NSArray *arrayTmp333 = [referenceDict222 allKeys];
        
        for(int i=0; i<[arrayTmp count]; i++)
        {
            if([[arrayTmp333 objectAtIndex:i] isEqualToString :mTheKeyOfTheTestItemDictionary])
            {
                NSArray *arrayTestItems = [referenceDict222 objectForKey:[arrayTmp333 objectAtIndex:i]];
                
                
                
                for(int j=0; j<[arrayTestItems count]; j++)
                {
                    if(j == 0)
                    {
                        boolAllResult = TRUE;
                    }
                    
                    NSDictionary *DictionaryTestItem = [arrayTestItems objectAtIndex:j];
                    
                    NSString *result = [DictionaryTestItem objectForKey:@"result"];
                    NSString *subtestname = [DictionaryTestItem objectForKey:@"subtestname"];
                    NSString *subsubtestname = [DictionaryTestItem objectForKey:@"subsubtestname"];
                    //NSString *testname = [DictionaryTestItem objectForKey:@"testname"];
                    NSString *units = [DictionaryTestItem objectForKey:@"units"];
                    NSString *upperlimit = [DictionaryTestItem objectForKey:@"upperlimit"];
                    //NSString *priority = [DictionaryTestItem objectForKey:@"priority"];
                    NSString *lowerlimit = [DictionaryTestItem objectForKey:@"lowerlimit"];
                    NSString *value = [DictionaryTestItem objectForKey:@"value"];
                    NSString *failure_message = [DictionaryTestItem objectForKey:@"failure_message"];
                    
                    if([result isEqualToString:@"PASS"])
                    {
                        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subtestname:subsubtestname:lowerlimit:upperlimit:value:units:RESULT_FOR_PASS:nil];
                    }
                    else if([result isEqualToString:@"FAIL"])
                    {
                        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subtestname:subsubtestname:lowerlimit:upperlimit:value:units:RESULT_FOR_FAIL:failure_message];
                        
                        boolAllResult = FALSE;
                    }
                    else
                    {
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"fail/pass string change"] ;
                        return  ;
                    }
                }
                
            }
        }
        
        
        
    }
    if(boolAllResult)
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
}

+(void)ParseLoopOscarInit:(NSDictionary*)dictKeyDefined
{

	
	//key parse
	NSString *mTestItemName=nil        ;

	NSString *mReferenceBufferName=nil ;

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;

    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"no received data"] ;
	    return  ;
	}
    
    if([mReferenceBufferValue rangeOfString:@"firmware loaded"].length > 0 && [mReferenceBufferValue rangeOfString:@"OK"].length > 0
       && [mReferenceBufferValue rangeOfString:@"error"].length <= 0 && [mReferenceBufferValue rangeOfString:@"Error"].length <= 0
       && [mReferenceBufferValue rangeOfString:@"ERROR"].length <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"1"] ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"0"] ;
    }

}

+(void)SetSelfTestByPass:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictKeyDefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	

    [TestItemManage setBufferValue:dictKeyDefined :@"ACC Selt Test Bypass" :@""];

    [TestItemManage setBufferValue:dictKeyDefined :@"ACC Selt Test Bypass" :@""];
    
    
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no receive data!"] ;
		return ;
	}
	
    NSString *strFindAcc = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :@"accel" Postfix
														   :@"Name"] ;
    
    NSString *strFindGyro = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                              :@"gyro" Postfix
                                                              :@"Name"] ;
    
//    if ([strFindAcc rangeOfString:@"Bosch"].length > 0)  
//    {
//        [TestItemManage setBufferValue:dictKeyDefined :@"ACC Selt Test Bypass" :@"ByPass"];
//    }
    if ([strFindGyro rangeOfString:@"Bosch"].length > 0)
    {
        [TestItemManage setBufferValue:dictKeyDefined :@"Gyro Selt Test Bypass" :@"ByPass"];
    }
		
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"pass"] ;
}

//add 2014.3.26 by kevin for rottern test in QT0a //Copy from A-1
+(void)ParseStrWithBBLib:(NSDictionary*)dictKeyDefined
{
    //NSString *strTestResultForUIinfo ;
	//enum TestResutStatus enumResult ;
	
	//key parse
    int failCount = 0;
	NSString *mTestItemName=nil        ;
    NSString *mReferenceBufferName=nil ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mCondition =@"Yes"  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/BBLib.txt" encoding:NSASCIIStringEncoding error:nil];
    if (mReferenceBufferValue==nil || [mReferenceBufferValue length] <= 0 || mReferenceBufferValue==NULL)
	{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no received data"] ;
        return ;
	}
	
	NSString *resultStr = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                             :mPrefix Postfix
                                                             :mPostfix] ;
	if (resultStr==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
	    return  ;
	}
    //add by kevin 20140705 start
    if([resultStr rangeOfString:@"errorCount"].location == NSNotFound)
    {
        NSString *FailMsg = [ToolFun getStrFromPrefixAndPostfix:resultStr Prefix:@"[BBMTE]: ERROR:" Postfix:@"ERROR:"];
        //FailMsg = [ToolFun getStrFromPrefixAndPostfix:FailMsg Prefix:nil Postfix:@"ERROR:"];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        //        NSLog(@"FailMsg is ddddd %@",FailMsg);
        if (FailMsg == nil || [FailMsg length] == 0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:FailMsg] ;
            return;
        }

    }
    //add by kevin 20140705 end(as it have no data to upload PDCA,so can directly return)
    NSArray *resultArray = [resultStr componentsSeparatedByString:@"smtqt results:"];
    for (int i = 1 ; i < [resultArray count]; i ++)
    {
        NSString *strTmp = [resultArray objectAtIndex:i];
        NSArray *ItemArray = [strTmp componentsSeparatedByString:@"="];
        if ([ItemArray count] < 3) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid data format!"] ;
            return;
        }
        
        NSString *subItemName = [ItemArray objectAtIndex:0];
        NSString *subItemValue = [ItemArray objectAtIndex:1];
        NSRange TmpRange1 = [subItemValue rangeOfString:@"["];
        subItemValue = [subItemValue substringToIndex:TmpRange1.location];
        subItemValue = [subItemValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([subItemName rangeOfString:@"execTime"].length > 0) {
            subItemValue = [subItemValue stringByReplacingOccurrencesOfString:@"s" withString:@""];
        }
        
        if ([subItemName rangeOfString:@"errorCount"].length > 0)
        {
            failCount = [subItemValue intValue];
        }
       
        NSString *subItemResult = [ItemArray objectAtIndex:2];
        NSString *strLimit = [ToolFun getStrFromPrefixAndPostfix:subItemResult Prefix:@"[" Postfix:@"]"];
        NSRange TmpRange2 = [strLimit rangeOfString:@","];
        if (TmpRange2.length == 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid data format!"] ;
            return;
        }
        NSString *LowLimit = [strLimit substringToIndex:TmpRange2.location];
        NSString *UpLimist = [strLimit substringFromIndex:TmpRange2.location +TmpRange2.length ];
        NSString *TmpResult = [ToolFun getStrFromPrefixAndPostfix:subItemResult Prefix:@"]" Postfix:nil];
        if ([TmpResult length] > 6) {
            TmpResult = [TmpResult substringToIndex:6];
        }
        if ([TmpResult rangeOfString:@"Pass"].length > 0
            || [TmpResult rangeOfString:@"PASS"].length > 0
            || [TmpResult rangeOfString:@"pass"].length > 0)
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subItemName:nil:LowLimit:UpLimist:subItemValue:nil:IP_PASS:nil];
        }
        else
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subItemName:nil:LowLimit:UpLimist:subItemValue:nil:IP_FAIL:nil];
        }
    }
    if (failCount > 0)
    {
        NSString *FailMsg = [ToolFun getStrFromPrefixAndPostfix:resultStr Prefix:@"[BBMTE]: ERROR:" Postfix:@"ERROR:"];
        //FailMsg = [ToolFun getStrFromPrefixAndPostfix:FailMsg Prefix:nil Postfix:@"ERROR:"];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        //        NSLog(@"FailMsg is ddddd %@",FailMsg);
        if (FailMsg == nil || [FailMsg length] == 0) {
            FailMsg = @"UnKnown Error!";
        }
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:FailMsg] ;
        return;
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    return  ;
}
+(void)ParseStrWithBBLibWithOutSimCard:(NSDictionary*)dictKeyDefined
{
    //NSString *strTestResultForUIinfo ;
	//enum TestResutStatus enumResult ;
	
	//key parse
    int failCount = 0;
	NSString *mTestItemName=nil        ;
    NSString *mReferenceBufferName=nil ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mCondition =@"Yes"  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/BBLib.txt" encoding:NSASCIIStringEncoding error:nil];
    if (mReferenceBufferValue==nil || [mReferenceBufferValue length] <= 0 || mReferenceBufferValue==NULL)
	{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no received data"] ;
        return ;
	}
	
	NSString *resultStr = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                             :mPrefix Postfix
                                                             :mPostfix] ;
	if (resultStr==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
	    return  ;
	}
    NSArray *resultArray = [resultStr componentsSeparatedByString:@"smtqt results:"];
    for (int i = 1 ; i < [resultArray count]; i ++)
    {
        NSString *strTmp = [resultArray objectAtIndex:i];
        NSArray *ItemArray = [strTmp componentsSeparatedByString:@"="];
        if ([ItemArray count] < 3) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid data format!"] ;
            return;
        }
        
        NSString *subItemName = [ItemArray objectAtIndex:0];
        NSString *subItemValue = [ItemArray objectAtIndex:1];
        NSRange TmpRange1 = [subItemValue rangeOfString:@"["];
        subItemValue = [subItemValue substringToIndex:TmpRange1.location];
        subItemValue = [subItemValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([subItemName rangeOfString:@"execTime"].length > 0) {
            subItemValue = [subItemValue stringByReplacingOccurrencesOfString:@"s" withString:@""];
        }
        
        if ([subItemName rangeOfString:@"errorCount"].length > 0)
        {
            failCount = [subItemValue intValue];
        }
        NSString *subItemResult = [ItemArray objectAtIndex:2];
        NSString *strLimit = [ToolFun getStrFromPrefixAndPostfix:subItemResult Prefix:@"[" Postfix:@"]"];
        NSRange TmpRange2 = [strLimit rangeOfString:@","];
        if (TmpRange2.length == 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid data format!"] ;
            return;
        }
        NSString *LowLimit = [strLimit substringToIndex:TmpRange2.location];
        NSString *UpLimist = [strLimit substringFromIndex:TmpRange2.location +TmpRange2.length ];
        NSString *TmpResult = [ToolFun getStrFromPrefixAndPostfix:subItemResult Prefix:@"]" Postfix:nil];
        if ([TmpResult length] > 6) {
            TmpResult = [TmpResult substringToIndex:6];
        }
        if ([TmpResult rangeOfString:@"Pass"].length > 0
            || [TmpResult rangeOfString:@"PASS"].length > 0
            || [TmpResult rangeOfString:@"pass"].length > 0)
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subItemName:nil:LowLimit:UpLimist:subItemValue:nil:IP_PASS:nil];
        }
        else
        {
            if ([subItemName rangeOfString:@"baseband.sim"].length>0)
            {
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subItemName:nil:LowLimit:UpLimist:subItemValue:nil:IP_PASS:nil];
            }
            else
            {
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:subItemName:nil:LowLimit:UpLimist:subItemValue:nil:IP_FAIL:nil];
            }
        }
    }
    if (failCount > 0)
    {
        NSString *FailMsg = [ToolFun getStrFromPrefixAndPostfix:resultStr Prefix:@"[BBMTE]: ERROR:" Postfix:@"ERROR:"];
        //FailMsg = [ToolFun getStrFromPrefixAndPostfix:FailMsg Prefix:nil Postfix:@"ERROR:"];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        FailMsg = [FailMsg stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        //        NSLog(@"FailMsg is ddddd %@",FailMsg);
        if (FailMsg == nil || [FailMsg length] == 0) {
            FailMsg = @"UnKnown Error!";
        }
        if (([FailMsg rangeOfString:@"SIM Test Failed with tray status = true, card = false"].length>0) && (failCount == 1))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:@"Pass"] ;
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:FailMsg] ;
            return;
        }
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    return  ;
}

// justin  add 2013-08-28 for Incoming station  --->>>>>>start...
+(void)CompareBobcatWithQueryOracle:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil       ;
	NSString *mResultStrSpec1=nil      ;
	NSString *mResultStrSpec2=nil      ;
    NSString *mResultStrSpec3=nil      ;
	NSString *mReferenceBufferName=nil   ;
    NSString *mReferenceBufferName2=nil  ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ResultStrSpec1"])
		{
			mResultStrSpec1 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ResultStrSpec2"])
		{
			mResultStrSpec2 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ResultStrSpec3"])
		{
			mResultStrSpec3 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    if (mReferenceBufferName==nil || mReferenceBufferName2 ==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
	NSString *mReferenceBufferValue ;
    int mDateLength = [@"yyyy-MM-dd HH:mm:ss" length];
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/11.txt" encoding:NSASCIIStringEncoding error:nil] ;
    
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if ([mReferenceBufferValue length] < 1)
    {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BobcatReferceBuffer return value is null"] ;
        return;
    }
    
    int lengthStrSpec2;
    NSRange mBobcatResultStrSpec2 = [mReferenceBufferValue rangeOfString:mResultStrSpec2];//@"start_time="
    // start_time = ""  all "PASS or FAIL" are display "Untested" on UI
    if([mReferenceBufferValue length] < (mBobcatResultStrSpec2.location +mBobcatResultStrSpec2.length + mDateLength) )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Untested"] ;
        return;
    }
    
    NSRange mBobcatResultPass = [mReferenceBufferValue rangeOfString:mResultStrSpec1];//@"result=PASS"
    NSRange mBobcatResultFail = [mReferenceBufferValue rangeOfString:@"result=FAIL"];//@"result=FAIL"
    
    
    NSString *mReferenceBufferValue2 ;
    NSString *mStartTimeString;
    
	mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    if ([mReferenceBufferValue length] < 1)
    {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"QueryOracle return value is null"] ;
        return;
    }
    
    //get start_time
    lengthStrSpec2 = mBobcatResultStrSpec2.location+mBobcatResultStrSpec2.length   ;
    mStartTimeString = [mReferenceBufferValue substringFromIndex:lengthStrSpec2];
    mStartTimeString = [mStartTimeString substringToIndex:mDateLength];
    
    NSString *mCheckInTimeString = [mReferenceBufferValue2 substringToIndex:mDateLength];
    
    
    if ([mCheckInTimeString length] < mDateLength)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Untested"] ;
        return;
    }
    
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@" " withString:@""];
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@":" withString:@""];
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mStartTimeString = [mStartTimeString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@" " withString:@""];
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@":" withString:@""];
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mCheckInTimeString = [mCheckInTimeString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    long long longStartTimeString = [mStartTimeString longLongValue];
    long long longCheckInTimeString = [mCheckInTimeString longLongValue];
    //    tmpTmpUIInfo = @"";
    //        tmpTmpUIInfo = [tmpTmpUIInfo stringByAppendingString:@"Pass: mStartTimeString="];
    //        tmpTmpUIInfo = [tmpTmpUIInfo stringByAppendingString:[NSString stringWithFormat:@"%lld",longStartTimeString]];
    //        tmpTmpUIInfo = [tmpTmpUIInfo stringByAppendingString:@"  mCheckInTimeString="];
    //        tmpTmpUIInfo = [tmpTmpUIInfo stringByAppendingString:[NSString stringWithFormat:@"%lld",longCheckInTimeString]];
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
    
    
    //    Bobcat 的返回状态：result=PASS ,start_time=A      A<B(checkin_time)   UI显示结果Untested    /   A>B   UI显示结果PASS
    //    Bobcat 的返回状态：result=FAIL ,start_time=A      A<B(checkin_time)   UI显示结果Untested    /   A>B   UI显示结果FAIL
    //    Bobcat 的返回状态：result=             ,start_time=                      UI显示结果Untested
    //    Bobcat 的返回状态：result=PASS ,start_time=           UI显示结果Untested
    //    Bobcat 的返回状态：result=FAIL    ,start_time=           UI显示结果Untested
    //    Bobcat 的返回状态：result=             ,start_time=           UI显示结果Untested
    if ( (mBobcatResultPass.length > 0 ) && (longStartTimeString > longCheckInTimeString))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        return;
    }
    
    if ( (mBobcatResultFail.length > 0 ) && (longStartTimeString > longCheckInTimeString))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        return;
    }
    
    if (longStartTimeString < longCheckInTimeString)
    {
        if ((mBobcatResultPass.length > 0 ) || (mBobcatResultFail.length > 0 ))
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Untested"] ;
            return;
        }
    }
    return;
}

//Justin add ...end<<<<<<---

//kevin add  for A-1 orion FW show on UI 20150925 start
+(void)ParseOrionFW:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil       ;
    NSString *mReferenceBufferName=nil   ;
    NSString *mReferenceBufferValue = nil;
    NSString *resultString1 = nil;
    NSString *resultString2 = nil;
    NSString *resultString3 = nil;
    NSString *resultString4 = nil;
    NSString *result = nil;
    
    NSString* mspec=nil;
    
    NSString *UIShowResult = nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"spec"])
        {
            mspec = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mReferenceBufferName==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
        return  ;
    }
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //mReferenceBufferValue = @"script orion_read_fw_versscript: tristar --pick orion_mcu>> pickscript: tristar -r 0xf4 -r 0xf5 -r 0xf6 -r 0xf7>> readreg 0xF4 = 0x1>> readreg 0xF5 = 0x5>> readreg 0xF6 = 0x0>> readreg 0xF7 = 0x9[001809C6:00C2E626] :-)";
    
    
    if ([mReferenceBufferValue length] < 1 || mReferenceBufferValue == nil)
    {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"mReferenceBufferValue is nil!"] ;
        return;
    }
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    mReferenceBufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                               :@"reg" Postfix
                                                               :@":-)"] ;
    
    
    resultString1 = [[mReferenceBufferValue substringFromIndex:7]substringToIndex:1];
    resultString2 = [[mReferenceBufferValue substringFromIndex:24]substringToIndex:1];
    resultString3 = [[mReferenceBufferValue substringFromIndex:41]substringToIndex:1];
    resultString4 = [[mReferenceBufferValue substringFromIndex:58]substringToIndex:2];
    //    NSLog(@"resultString1 = @%,resultString2= %, resultString3=%@, resultString4 = %@",resultString1,resultString2,resultString3,resultString4);
    
    //    result = [[[[result stringByAppendingString:resultString1]stringByAppendingString:resultString2]stringByAppendingString:resultString3]stringByAppendingString:resultString4];
    
    result=[NSString stringWithFormat:@"%@%@%@%@",resultString1,resultString2,resultString3,resultString4];
    
    //    UIShowResult = [[mReferenceBufferValue substringFromIndex:56]substringToIndex:3];
    
   // if([result isEqualToString:mspec])
     if([mspec rangeOfString:result].length>0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS:result] ;
        return ;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:result] ;
    return ;
    
}
//kevin add  for A-1 orion FW show on UI 20150925 end

@end
