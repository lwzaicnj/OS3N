//
//  TestItemParse+EZLinkParse.m
//  iFTS
//
//  Created by Annie Zhang on 6/20/14.
//
//
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "ezlink-host.h"

#include <fstream>
#include <iostream>
#include <stdint.h>
#include "TestItemParse+EZLinkParse.h"
#import "termios.h"


//------------------------------------------

//class ezlinks{
    

    static ssize_t _Serial_Read (
                                 int filedes,
                                 void *buf,
                                 size_t nbytes,
                                 unsigned int timeout_ms
                                 )
    {
        struct timeval tv;
        fd_set fds;
        int ret;
        
        tv.tv_sec = timeout_ms  / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        
        FD_ZERO(&fds);
        FD_SET(filedes, &fds);
        
        // Use select to wait till a read descriptor is set
        ret = select(filedes + 1, &fds, NULL, NULL, &tv);
        
        // We got data - read as much as we can and return to the user
        if (ret > 0) {
            ret = read(filedes, buf, nbytes);
            return ret;
        }
        else {
            return -ETIMEDOUT;
        }
    }
    

    int Serial_Open (
                     char            *Port,
                     int             *Fd,
                     int             BaudRate
                     )
    {
        struct termios OldTio;
        struct termios NewTio;
        int SerialFd;
        int Ret;
        
        SerialFd = open(Port, O_RDWR | O_NOCTTY);
        if (SerialFd < 0) {
            printf("Could not open serial port: %d\n", errno);
            return -1;
        }
        
        *Fd = SerialFd;
        
        // Get old attributes
        tcgetattr(SerialFd, &OldTio);
        bzero(&NewTio, sizeof(NewTio));
        
        // Setup the serial port attributes
        NewTio.c_cflag = CS8 | CREAD;
        NewTio.c_oflag = 0;
        NewTio.c_iflag = IGNPAR;
        NewTio.c_lflag = 0;
        NewTio.c_cc[VMIN] = 0;
        NewTio.c_cc[VTIME] = 0;
        
        // Mac OS/X requires a special ioctl to set higher baud rates
        if (BaudRate <= 115200) {
            if (cfsetospeed(&NewTio, BaudRate) < 0) {
                printf("Couldn't set speed!\n");
                return -1;
            }
            
            cfmakeraw(&NewTio);
            tcsetattr(SerialFd, TCSANOW, &NewTio);
            Ret = tcflush(SerialFd, TCIOFLUSH);
            if (Ret < 0) {
                printf("Couldn't flush serial port!\n");
                return Ret;
            }
        }
        else {
            tcsetattr(SerialFd, TCSANOW, &NewTio);
            
#ifndef IOSSIOSPEED
#define IOSSIOSPEED _IOW('T', 2, speed_t)
#endif
            Ret = ioctl(SerialFd, IOSSIOSPEED, &BaudRate);
            if (Ret < 0) {
                printf("Canot set speed!\n");
                return -1;
            }
        }
        
        // This delay is needed to stabilize the serial port
        usleep(50 * 1000);
        
        return 0;
    }
    

    int Serial_ReadBytes (
                          void        *Context,
                          void        *Buf,
                          uint32_t    NumBytes,
                          int32_t     TimeOutInMs
                          )
    {
        int Ret;
        unsigned char *Ptr = (unsigned char *)Buf;
        unsigned int TotalBytes = 0;
        SerialContext_t *SerialContext = (SerialContext_t *)Context;
        
        while (NumBytes) {
            Ret = _Serial_Read(SerialContext->Fd, Ptr, NumBytes, TimeOutInMs);
            if (Ret < 0) {
                return Ret;
            }
            
            Ptr += Ret;
            NumBytes -= Ret;
            TotalBytes += Ret;
        }
        
        return 0;
    }
    

    static
    void
    PrintBytes (
                void        *Buf,
                uint32_t    NumBytes
                )
    {
        int i;
        
        for (i = 0; i < NumBytes; i++) {
            printf("0x%02x ", ((uint8_t*)Buf)[i]);
            if ((i != 0) && (i % 8 == 0)) {
                printf("\n");
            }
        }
    }
    
    int Serial_WriteBytes (
                           void        *Context,
                           void        *Buf,
                           uint32_t    NumBytes
                           )
    {
        SerialContext_t *SerialContext = (SerialContext_t *)Context;
        if (!Context) {
            return -1;
        }
        
        //PrintBytes(Buf, NumBytes);
        return write(SerialContext->Fd, Buf, NumBytes);
    }
//};




#import "TestItemParse+EZLinkParse.h"
#import "testItemParse.h"

#pragma mark EZLink
@implementation TestItemParse (EZLinkParse)

+(void)EZLinkParseFunction:(NSDictionary*)dictKeyDefined
{
    NSString *mArgvStr=nil      ;// write cmd
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@"$";
	NSString *mTestItemName=nil     ;
    NSString *mFileURL=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"ArgvStr"])
		{
			mArgvStr= [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"FileURL"])
		{
			mFileURL = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    if (mTestItemName==nil ||
		mBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    //----disconnect UART cable logic ----------------------
    //[TestItemParse openCurrPort:dictKeyDefined];
    [TestItemParse closeCurrPort:dictKeyDefined];
    usleep(80000);
   //-------------------------------------------------------
    
    EzLinkTransport_t Methods;
    SerialContext_t SerialContext;
    EzLink_t EzLinkInfo;
    ErrorInfo_t *ErrorInfo = NULL;
    int Status;
    int i;
    uint8_t *RxBuf0;
    uint32_t RxBufSize0;
    
    char ReadBuf[2050];
    Methods.TxData = Serial_WriteBytes;
    Methods.RxData = Serial_ReadBytes;
    
    NSMutableString *errorStr=[[[NSMutableString alloc]init] autorelease];
    NSString *ezlinkLogPath=[NSString stringWithFormat:@"%@/ezlinkLog.txt",NSHomeDirectory()];
    
    NSString *UartName=[TestItemParse getCurrUnitDeviceName:dictKeyDefined];
    const char *portName=[UartName UTF8String];
    char *port1=const_cast<char *>(portName);
    Status=Serial_Open(port1, &SerialContext.Fd, 115200);
    usleep(5000);
    bool resultFlag=false;
    //while (!resultFlag)

    //Status=Serial_Open("/dev/cu.usbserial-AD01WECD", &SerialContext.Fd, 115200);
    if (Status < 0) {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Serial_Open=%d",Status]] ;
        
        printf("1.Serial_Open():Status < 0\n");
        //NSLog("HJJJKHLKJG");
        [errorStr appendFormat:@"      1.Serial_Open():Status < 0\n"];
        [TestItemManage setUnitLogInfo:dictKeyDefined :errorStr:true];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        
        close(SerialContext.Fd);
        usleep(5000);
        [TestItemParse openCurrPort:dictKeyDefined];

        [TestItemManage writeEZLinkLog:ezlinkLogPath :errorStr];
        return;
        //continue;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"Serial_Open=%d",Status]] ;
        
        printf("1.Serial_Open():Successs!\n");
        [errorStr appendFormat:@"1.Serial_Open():Successs!\n"];
    }
    
    const char *arg = "tristar --provision";
    string aa= arg;
    string cmd = "\n" + aa + "\r\n";
    write(SerialContext.Fd, cmd.c_str(), cmd.length());
    usleep(200000);
    read(SerialContext.Fd,ReadBuf,2050);
    
    printf(ReadBuf);
    [errorStr appendFormat:@"%s\r\n",ReadBuf];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithCString:ReadBuf]] ;
    
    // 1. Setup the Ezlink with diags
    Status = EzLink_Setup(&EzLinkInfo, &Methods, &SerialContext);
    if (Status < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"EzLink_Setup=%d",Status]] ;
        
        printf("2.EzLink_Setup():Status < 0\r\n");
        [errorStr appendFormat:@"      2.EzLink_Setup():Status < 0\n\r"];
        [TestItemManage setUnitLogInfo:dictKeyDefined :errorStr :true];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        
        close(SerialContext.Fd);
        usleep(5000);
        [TestItemParse openCurrPort:dictKeyDefined];

        [TestItemManage writeEZLinkLog:ezlinkLogPath :errorStr];
        return;
        //continue;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"EzLink_Setup=%d",Status]] ;
        
        printf("2.EzLink_Setup():Successs!\n");
        [errorStr appendFormat:@"      2.EzLink_Setup():Successs!\n\r"];
    }
    
    // Phase 1 - Receive the provisioning request from diags
   // for (int m=0; m<6; m++)
   // {
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf0, &RxBufSize0, 2000, &ErrorInfo);
    //-----method1--not successful------------------------------
//    NSString *RxDataSize=[NSString stringWithFormat:@"%u",RxBufSize0];
//    NSData *RxData=[[NSData alloc]init];
//    RxData=[NSData dataWithBytes:RxBuf0 length:[RxDataSize length]];
    //-----method2---------------------------------------------
    NSString *RxDataSize=[NSString stringWithFormat:@"%u",RxBufSize0];
    int RxSize=[RxDataSize intValue];
    uint8_t *RxBuf2=(unsigned char*)malloc(RxSize);
    bcopy(RxBuf0, RxBuf2, RxSize);
    
    
    //[errorStr appendFormat:@"RxBuf = Received %u bytes = %s\n\r", RxBufSize0, RxBuf0];
    //printf("RxBuf = Received %u bytes = %s\n", RxBufSize0, RxBuf0);
    [errorStr appendFormat:@"RxBuf = Received %u bytes = %s\n\r", RxBufSize0, RxBuf2];
    printf("RxBuf = Received %u bytes = %s\n", RxBufSize0, RxBuf2);
    if (Status < 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"EzLink_RecvData=%d",Status]] ;
        
        printf("3.EzLink_RecvData():Status < 0\n");
        [errorStr appendFormat:@"      3.EzLink_RecvData():Status < 0\n\r"];
        [TestItemManage setUnitLogInfo:dictKeyDefined :errorStr :true];
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        
        //[TestItemParse closeCurrPort:dictKeyDefined];
        [TestItemParse openCurrPort:dictKeyDefined];
        usleep(5000);
        //[TestItemParse testItemParseInit];
        [TestItemManage writeEZLinkLog:ezlinkLogPath :errorStr];
        
        if(RxBuf2 != NULL)
            free(RxBuf2);
        RxBuf2 = NULL;
        return ;
        //continue;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"EzLink_RecvData=%d",Status]] ;
        
        printf("3.EzLink_RecvData():Successs!\n");
        [errorStr appendFormat:@"      3.EzLink_RecvData():Successs!\n\r"];
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"RxBufSize0=%d",RxBufSize0]] ;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%s",RxBuf2]] ;
    
    //--------------------------------------------
    char tx_buf[5000]; tx_buf[0]='\0';
    NSString *pathStr=[NSString stringWithFormat:@"python %@/JMET.py '",NSHomeDirectory()];
    [errorStr appendFormat:@"     python path %@ \n\r",pathStr];
    
    const char *pathChar=[pathStr UTF8String];
    strcat(tx_buf, const_cast<char *>(pathChar));
    //strcat(tx_buf, "python /Users/anniezhang/Downloads/EzLinkProject-FinallyNew/JMET.py '");
    //strcat(tx_buf, (char *)RxBuf0);
    strncat(tx_buf, (char *)RxBuf2, RxSize);
    strcat(tx_buf, "'\0");
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithCString:tx_buf]] ;
    
    printf("$$$$$$$$$$$$$$$$$$$$\n %s\n\n", tx_buf);
    [errorStr appendFormat:@"\n      %s\n\n\r",tx_buf];
    
    FILE *fp=popen(tx_buf, "r");
    if(fp == NULL)
    {
        printf("Fail to CALL python");
        [errorStr appendFormat:@"      Fail to CALL python"];
    }
    
    char buf[2048];
    fgets(buf, sizeof(buf), fp);
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithCString:buf]] ;
    printf("buf = B02 %s ####\n", buf);
    [errorStr appendFormat:@"      buf = B02 %s ####\n\r",buf];
    pclose(fp);
    
    // Phase 2 - Send the provisioning info from JMET to diags /
    Status = EzLink_SendData(&EzLinkInfo, buf, sizeof(buf), 1000, &ErrorInfo);
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithCString:buf]] ;
    printf("RxBuf = Received bytes = %s\n", RxBuf0);
    [errorStr appendFormat:@"      RxBuf = Received bytes = %s\n\r",RxBuf0];
    
    if(Status != 0) // we should chck the status_code be 0  ???
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"EzLink_SendData=%d",Status]] ;
        
        printf("4.EzLink_SendData():Status < 0\n");
        [errorStr appendFormat:@"      4.EzLink_SendData():Status < 0"];
        [TestItemManage setUnitLogInfo:dictKeyDefined :errorStr :true];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        
        close(SerialContext.Fd);
        usleep(5000);
        [TestItemParse openCurrPort:dictKeyDefined];

         [TestItemManage writeEZLinkLog:ezlinkLogPath :errorStr];
        
        if(RxBuf2 != NULL)
            free(RxBuf2);
        RxBuf2 = NULL;
        
        return;
        //continue;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"EzLink_SendData=%d",Status]] ;
        
        printf("4.EzLink_SendData():Successs!\n");
        [errorStr appendFormat:@"      4.EzLink_SendData():Successs!\n"];
    }
    
    //    }
    
    // Zero out the tx_buf, so I can see what Diags is handing up.
    for (i = 0; i < RxBufSize0; i++) {
        RxBuf0[i] = 0;
    }
    
    // Phase 3 - Get the provioning response back from diags
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf0, &RxBufSize0, 2000, &ErrorInfo);
    [errorStr appendFormat:@"      %s\n\r",RxBuf0];
    [errorStr appendFormat:@"      %s\n\r",RxBuf0];
    ErrorInfo = NULL;
    if (Status < 0)
    {
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"EzLink_RecvData=%d",Status]] ;
        if (ErrorInfo != NULL) {
            NSString *errorInfo = [NSString stringWithFormat:@"%s",ErrorInfo->ErrorString];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"EzLink_RecvData.ErrorCode=%@",errorInfo]] ;

        }else{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"ErrorInfo error"]] ;
        }
            
        printf("5.EzLink_RecvData():Status < 0\n");
        [errorStr appendFormat:@"      5.EzLink_RecvData():Status < 0\n\r"];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"] ;
        
        close(SerialContext.Fd);
        usleep(5000);

        [TestItemParse openCurrPort:dictKeyDefined];
        
        
        NSData *logStr=[errorStr dataUsingEncoding:NSUTF8StringEncoding];
        
        [TestItemManage setUnitLogInfo:dictKeyDefined :[NSString stringWithFormat:@"%@",logStr] :true];
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :errorStr] ;
        [TestItemManage writeEZLinkLog:ezlinkLogPath :[NSString stringWithFormat:@"%@",logStr]];
        
        if(RxBuf2 != NULL)
            free(RxBuf2);
        RxBuf2 = NULL;
        
        return ;
        //continue;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"EzLink_RecvData=%d",Status]] ;
        
        printf("5.EzLink_RecvData():Successs!\n");
        [errorStr appendFormat:@"      5.EzLink_RecvData():Successs!\n\r"];
    }
    
    
    tx_buf[0]='\0';
    
    strcat(tx_buf, const_cast<char *>(pathChar));
    strncat(tx_buf, (char *)RxBuf0, RxBufSize0);
    strcat(tx_buf, "'\0");
    
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithCString:tx_buf]] ;
    printf("$$$$$$$$$$$$$$$$$$$$\n %s\n\n", tx_buf);
    [errorStr appendFormat:@"$$$$$$$$$$$$$$$$$$$$\n      %s\n\n", tx_buf];
    
    FILE *fp1=popen(tx_buf, "r");
    if(fp1 == NULL)
    {
        printf("Fail to CALL python");
        [errorStr appendFormat:@"      Fail to CALL python"];
    }
    
    char buf1[2048];
    fgets(buf1, sizeof(buf1), fp1);
    pclose(fp);
    close(SerialContext.Fd);
    usleep(5000);
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"RxBufSize0=%d",RxBufSize0]] ;

    printf("Received %u bytes\n", RxBufSize0);
    [errorStr appendFormat:@"      Received %u bytes\n", RxBufSize0];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :errorStr] ;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    [TestItemParse openCurrPort:dictKeyDefined];
    
    
    if(RxBuf2 != NULL)
        free(RxBuf2);
    RxBuf2 = NULL;
    
    return ;
    
}

-(void)writeEZLinkLog:(NSString*)logPath :(NSString*)logContent
{
    FILE* fp=NULL;
    fp=fopen([logPath UTF8String],"wr");
    fclose(fp);
    
    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:logPath];
    if (filehandTmp!=nil)
    {
        
        [filehandTmp seekToEndOfFile] ;
        [filehandTmp writeData:[NSData dataWithData:[logContent dataUsingEncoding:NSASCIIStringEncoding]]] ;
        [filehandTmp closeFile] ;
        
    }

}

////Upload attribute “tristar_esn” to Bobcat and PDCA, Added by Annie for RL PVT
+(void)TristarESN:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString *mPrefix=@"B64_ESN=";
    NSString *mPostfix=@"==";
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
    }

    if (mReferenceBufferName==nil ||
		mBufferName==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if (mReferenceBufferValue==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"no value in buffer"] ;
    }
    //----------------------------------------------------------
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :[NSString stringWithFormat:@"Receive data :%@",mReferenceBufferValue]] ;
    //debug
    //mReferenceBufferValue =@"COMMAND_CODE=400&SN=DLXNNB2NG5VW&CLIENT_ID=3DF3BF8C-5B66-4D2C-9D08-D4B11A0AD524&STATUS=0&B64_ESN=MDFiODhkNTg1ZDg4M2Y0Ng=='";
    //debug

    NSRange rangeESN=[mReferenceBufferValue rangeOfString:@"B64_ESN="];
    if (rangeESN.length<=0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Ezlink Connected fail,please check"] ;
    }
    
    
   NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                                              :mPrefix Postfix
                                                                              :mPostfix] ;
    NSMutableString *sendStr=[NSMutableString stringWithFormat:@"echo %@== | openssl enc -base64 -d",strFind];
    NSString *decodeCmd=[NSString stringWithFormat:@"%@ >%@/vv.txt",sendStr,NSHomeDirectory()];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :[NSString stringWithFormat:@"Send value:%@",decodeCmd]] ;
    
    system([decodeCmd UTF8String]);

    NSString *ESNStr=[NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/vv.txt"] encoding:NSASCIIStringEncoding error:nil] ;
    if (ESNStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Did not creat ESN file,please check"] ;
    }
    
    if (ESNStr.length<16)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :ESNStr] ;
        return;
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :ESNStr] ;
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :ESNStr] ;
    
    return;
   
  }

//in order to Judge incoming QT0 unit location, eg LH,CD,BZ. 2015.1.19 Annie
+(void)RefurbishProvisionIP:(NSDictionary*)dictKeyDefined
{
    NSString *LHPlantCodeStr=@"DLX,DL9,DQX,DQY,DR2,DR3,DR4,DR5,DR6,DR7,DQT,DQW,DQV";
    NSString *StrSN= [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
    
    //debug
    //StrSN=@"DLX123456789";
    //debug
    
    NSString *subStr=[StrSN substringToIndex:3];
    NSRange rang=[LHPlantCodeStr rangeOfString:subStr];
    if (rang.length>0)
    {
        NSString *strJMET = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/JMET.py"] encoding:NSASCIIStringEncoding error:nil] ;
        if([strJMET length] > 0)
        {
            NSString *IP_JMET = [ToolFun getStrFromPrefixAndPostfix:strJMET Prefix:@"http://" Postfix:@":"] ;
            if([IP_JMET length] > 0)
            {
                //                NSString* jsonFile = [NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
                //                //NSString* jsonFile = [NSString stringWithContentsOfFile:@"/vault/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil];
                //                if([jsonFile length] > 0)
                //                {
                //                    jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\n" withString:@""];
                //                    jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\r" withString:@""];
                //                    jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\t" withString:@""];
                //                    jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@" " withString:@""];
                //                    jsonFile = [jsonFile stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                //
                //                    NSString *IP_jsonFile = [ToolFun getStrFromPrefixAndPostfix:jsonFile Prefix:@"PROV_IP:" Postfix:@","];
                NSString *IP_jsonFile = @"17.239.208.210";
                if([IP_jsonFile length] > 0)
                {
                    if([IP_jsonFile rangeOfString:IP_JMET].length <= 0)
                    {
                        strJMET = [strJMET stringByReplacingOccurrencesOfString:IP_JMET withString:IP_jsonFile];
                        
                        
                        FILE* fp=NULL;
                        fp=fopen([[NSHomeDirectory()stringByAppendingString:@"/JMET.py"] UTF8String],"wr");
                        fclose(fp);
                        
                        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:[NSHomeDirectory()stringByAppendingString:@"/JMET.py"]];
                        if (filehandTmp!=nil)
                        {
                            
                            [filehandTmp seekToEndOfFile] ;
                            [filehandTmp writeData:[NSData dataWithData:[strJMET dataUsingEncoding:NSASCIIStringEncoding]]] ;
                            [filehandTmp closeFile] ;
                            
                        }
                        
                    }
                }
            }
            
        }
    }
}

@end
