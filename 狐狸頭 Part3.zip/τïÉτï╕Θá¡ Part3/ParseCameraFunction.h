/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseCameraFunction.h  $|
 | $Author:: Helen                  $Revision::  1					 $|
 | CREATED: 2011-03-04                $Modtime:: 2011-08-10		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseCameraFunction.h                                       $
 * *****************  Version 1  *****************
 * User: Helen           Date: 2011-08-10
 * Created in 
 * first implementation
 */
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseCameraFunction)
//Ray modified for P105 2012-05-11
//Seperate writing FCMB & BCMB into two function
+(void)FrontParseCamera:(NSDictionary*)dictKeyDefined ;

+(void)BackParseCamera:(NSDictionary*)dictKeyDefined ;
//Ray modified for P105 2012-05-11

+(void)ParseStrWithStrSpecForCameraDli:(NSDictionary*)dictKeyDefined;

@end
