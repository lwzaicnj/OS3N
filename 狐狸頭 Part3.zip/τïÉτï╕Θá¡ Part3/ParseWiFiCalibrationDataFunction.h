//
//  ParseCompassQTFunction.h
//  qt
//
//  Created by Henry on 7/19/10.
//  Copyright 2010-2020 . All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseWiFiCalibrationData)
+(void)ParseWiFiCalibrationData:(NSDictionary*) DictionaryPtr;
@end