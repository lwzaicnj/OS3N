//
//  ParseACFBondingCheck.h
//  iFTS
//	SCRID-36
//  Created by Shou-xiu on 2010-12-13.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"


@interface TestItemParse(ParseACFBondingCheck)
+(void)ParseACFBondingCheck:(NSDictionary*) DictionaryPtr;
@end