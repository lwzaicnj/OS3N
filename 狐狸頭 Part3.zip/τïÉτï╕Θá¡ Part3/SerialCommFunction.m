//
//  SerialCommFunction.m
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "SerialCommFunction.h"
#import "InstantPudding_API.h"
#import "UIAlert.h"
//SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
#import "UICommon.h"
#import "testItemParse.h"
//SCRID:101 end.
#import "StringParseFuncation.h"
#import "UartComm.h"

#include <sys/socket.h>
#import "termios.h"
#include <netdb.h>
#include <arpa/inet.h>
#include <stdio.h>
#import <Cocoa/Cocoa.h>
#import "UIWinManage.h"

#define USE_UIALERT 1

int listenSocket = 0;

@implementation TestItemParse(SerialCommFunction)
//modified by lorne 20150915
+(void)SensorCheck:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=@"Fixture";
    NSString *mWriteCmd=@"START";
    NSString *mErrorSpec=@"_0";
    NSString *mPostfix=@"*_*";
    NSString *mTimeOut=@"2";
    NSString *mRetryDelay=@"1";
    NSString *mSensorNum=nil;
    NSString *mBufferName=nil;
    
    int retryCount = 1;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ErrorSpec"])
        {
            mErrorSpec = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"RetryDelay"])
        {
            mRetryDelay = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"SensorNum"]) //Added by Annie for RX P3 2014.08.20
        {
            mSensorNum = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    //Added by Annie for RX P3 2014.08.20
    if([mSensorNum length] <=  0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"test script error"] ;
        return ;
    }
    
    
    for(int i=0; i <= retryCount; i++)
    {
        for(int i=0; i<[mWriteCmd length]; i++)
        {
            usleep(200) ; //delay 100ms
            NSString *tmpCMD = [mWriteCmd substringFromIndex:i];
            tmpCMD = [tmpCMD substringToIndex:1];
            if(i == [mWriteCmd length] - 1)
                tmpCMD = [tmpCMD stringByAppendingString:@"\r"];
            
            [self SendData:dictKeyDefined :tmpCMD :mPostfix] ;
        }
        
        NSDate *dateTmp=[[NSDate alloc] init] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        [dateTmp release];
        //read data
        
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        //dataResult=@"V0_1 V1_1 V2_1 V3_1 V4_1 V5_1 V6_1 V7_1 V8_1 V9_1 V10_1 V11_1 V12_1 V13_1 V14_1 V15_1 V16_1 V17_1 V18_1 V19_1 V20_1 V21_1 V22_1 V23_1 V24_1 V25_1 V26_1 V27_1 V28_1 V29_1 V30_1 V31_1 V32_1 V33_1 V34_1 V35_1 V36_1 V37_1 V38_1 V39_1 V40_1 V41_1 V42_1 V43_1 V44_1 V45_1 V46_1 V47_1 V48_1 V49_1 V50_1 V51_1 V52_1 V53_1 V54_1 V55_1 V56_1 *_* ";
        //NSArray *NumTmp=[dataResult componentsSeparatedByString:@"_1"];
        
        if([dataResult rangeOfString:mErrorSpec].length >  0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fixture sensor fail 1"] ;
            return ;
        }
        else if (dataResult == nil)
        {
            if(i == 0)
                sleep([mRetryDelay intValue]);
            continue;
        }
        //Modified by Annie for RX P3 2014.08.20
        //else if([[dataResult componentsSeparatedByString:@"_1"] count] == 58)
        else if([[dataResult componentsSeparatedByString:@"_1"] count] == [mSensorNum intValue]+1||[[dataResult componentsSeparatedByString:@"_1"] count] == [mSensorNum intValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
            [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"1":nil:RESULT_FOR_PASS:@"PASS"];
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"PASS"] ;
            return ;
        }
        else ;
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fixture sensor fail 2"] ;
    [TestItemManage setSubItemPDCAInfo :dictKeyDefined:@"FAIL:0/PASS:1":nil:[NSString stringWithFormat:@"%@",@"NA"]:[NSString stringWithFormat:@"%@",@"NA"]:@"0":nil:RESULT_FOR_FAIL:@"FAIL"];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"FAIL"] ;
    return ;
}
+(void)EEPROMV2:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=nil;
   // NSString *strMutSendBuffer = @"";
    NSString *mReferenceBufferName=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    NSString *mReferenceBufferNameValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if(mReferenceBufferNameValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Cann't not get LCD Vendor Info,Check Diags Return"];
        return;
    }   
    else if(([mReferenceBufferNameValue rangeOfString:@"LG"].length) <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Only Check LG LCD"];
        return;
    }
    NSString* mTimeOut = @"3";
    
       
    
    [self SendData:dictKeyDefined :@"mipi longwrite 0x29 0xb8 0x1 0x0 0x63\n" :@":-)"];
    //usleep(100000) ; //delay 100ms
    
    //[self ReceData:dictKeyDefined] ;
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
    //read data
    [self ReceData:dictKeyDefined] ;
    
    // usleep(100000) ; //delay 100ms
    [self SendData:dictKeyDefined :@"mipi read 0x14 0xc4\n" :@":-)"];
    //usleep(100000) ; 
    
    {
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
    NSString *mresturn1 = [self ReceData:dictKeyDefined] ;
    
    
    mresturn1 = [mresturn1 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mresturn1 = [mresturn1 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mresturn1 = [mresturn1 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mresturn1 = [mresturn1 stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    mresturn1 = [ToolFun getStrFromPrefixAndPostfix:mresturn1 Prefix:@"0x15" Postfix:@":-)"] ;
    

    
    
    
    [self SendData:dictKeyDefined :@"mipi longwrite 0x29 0xb8 0x1 0x0 0x64\n" :@":-)"];
    //usleep(100000) ; //delay 100ms
    
    //[self ReceData:dictKeyDefined] ;
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
    //read data
   [self ReceData:dictKeyDefined] ;
    
    // usleep(100000) ; //delay 100ms
    [self SendData:dictKeyDefined :@"mipi read 0x14 0xc4\n" :@":-)"];
    //usleep(100000) ; 
    
    {
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
    NSString *mresturn2 = [self ReceData:dictKeyDefined] ;
    
    
    mresturn2 = [mresturn2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mresturn2 = [mresturn2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mresturn2 = [mresturn2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mresturn2 = [mresturn2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    mresturn2 = [ToolFun getStrFromPrefixAndPostfix:mresturn2 Prefix:@"0x15" Postfix:@":-)"] ;


    
    [self SendData:dictKeyDefined :@"mipi longwrite 0x29 0xb8 0x1 0x0 0xb8\n" :@":-)"];
    //usleep(100000) ; //delay 100ms
    
    //[self ReceData:dictKeyDefined] ;
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
    //read data
    [self ReceData:dictKeyDefined] ;
    
    // usleep(100000) ; //delay 100ms
    [self SendData:dictKeyDefined :@"mipi read 0x14 0xc4\n" :@":-)"];
    //usleep(100000) ; 
    
    {
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(30000) ; //delay 100ms
            }
        }
    }
   NSString *mresturn3 = [self ReceData:dictKeyDefined] ;
    
    
    mresturn3 = [mresturn3 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mresturn3 = [mresturn3 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mresturn3 = [mresturn3 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mresturn3 = [mresturn3 stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    mresturn3 = [ToolFun getStrFromPrefixAndPostfix:mresturn3 Prefix:@"0x15" Postfix:@":-)"] ;
    if(mresturn1 == nil || mresturn2 == nil ||mresturn3 == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data"] ;
        return;
    }
    
    
    
    
    if([mresturn3 isEqualToString:@"0x19"])
    {
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"0x0 0xb8":nil:nil:nil:mresturn3:nil:RESULT_FOR_PASS:nil];
     
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
        return;
    }
    else
    {
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"0x0 0xb8":nil:nil:nil:mresturn3:nil:RESULT_FOR_FAIL:nil];
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"];
        return;
    }

}
+(void)EEPROM:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=nil;
    NSString *strMutSendBuffer = @"";
    NSString *mReferenceBufferName=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    NSString *mReferenceBufferNameValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if(mReferenceBufferNameValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Cann't not get LCD Vendor Info,Check Diags Return"];
        return;
    }   
    else if(([mReferenceBufferNameValue rangeOfString:@"LG"].length) <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Only Check LG LCD"];
        return;
		
    }
    
    
    NSString *EEPROMData0 = @"0x71,0x95,0x19,0x19,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x37,0x10,0x0,0x0,0x0,0x0,0x0,0x0,0x20,0x0,0x3F,0x1,0x7F,0x0,0x8,0x0,0x7,0x0,0x8,0x9,0x24,0xF,0xB,0x51,0x20,0x23,0x18,0xA,0x0,0x9,0x10,0xE,0x19,0x3,0x44,0x2,0x1,0x3,0x0,0x0,0x0,0x0,0xA,0x70,0xFF,0xF,0x0,0x0,0x77,0x77,0x77,0x77,0x77,0x77,0xF,0xF,0xF,0xF,0xF,0xF,0x5,0x7,0x9,0x17,0x17,0x7,0xB0,0x20,0x0,0x0,0x5F,0x5F,0x5F,0x5F,0x0,0xAA,0x0,0x55,0x0,0x0,0x13,0x0,0x1F,0x37,0x3F,0x2F,0x0,0x0,0x8F,0xC0,0x10,0x10,0x10,0x0,0x4,0x3,0xFF,0x7,0xFF,0x0,0x10,0x1,0x7F,0x2,0x2B,0x4,0x0,0x74,0x1,0x4D,0x1,0xB1,0x3,0x48,0x4,0x41,0x9,0x1,0x3,0xF5,0x4,0x9,0x4,0x73,0x41,0x1,0x0,0x0,0x10,0x2,0x0,0x0,0x20,0xFF,0xFF,0x10,0x6,0x4A,0xBE,0x4,0x0,0x10,0x0,0x20,0x0,0xFF,0x14,0x3,0x0,0xF0,0x0,0xF,0x0,0x0,0xF0,0x0,0x0,0xFF,0xF0,0xFF,0x0,0x0,0xD,0x0,0xC,0x1,0x70,0x36,0x5,0x54,0x4,0x0,0x19,0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x7F,0x60,0x60,0x60,0x60,0x0,0x0,0x0,0x10,0x24,0x0,0x0,0x0,0x0,0x0,0x3,0x0,0x3,0x0,0x3,0x0,0x0,0x3,0xC,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x3,0x3E,0x0,0x0,0x2,0x3E";
    NSString *EEPROMData1 = @"0x0,0x0,0x0,0x2,0x0,0x2,0x0,0x0,0x0,0x0,0x4,0x2,0x0,0x0,0x0,0x0,0x0,0x3,0x3E,0x0,0x0,0x2,0x3E,0x0,0x0,0x0,0x2,0x0,0x2,0x0,0x1,0x0,0x0,0x4,0x2,0x0,0x0,0x0,0x0,0x0,0x3,0x3E,0x0,0x0,0x2,0x3E,0x0,0x0,0x0,0x2,0x0,0x2,0x0,0x2,0x0,0x0,0x4,0x0,0x0,0x0,0x0,0x0,0x0,0x3,0x3E,0x0,0x0,0x2,0x3E,0x0,0x0,0x0,0x2,0x0,0x2,0x0,0x3,0x0,0x0,0x4,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0xBD,0x0,0x0,0x3,0x3E,0x0,0x0,0x0,0x0,0x0,0x2,0x0,0x2,0x0,0x0,0x4,0x2,0x0,0x0,0x0,0x0,0x1,0x1,0xBD,0x0,0x0,0x3,0x3E,0x0,0x0,0x0,0x0,0x0,0x2,0x0,0x3,0x0,0x0,0x4,0x2,0x0,0x0,0x0,0x0,0x1,0x0,0x64,0x0,0x0,0x0,0x0,0x0,0x0,0x4,0xB,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x78,0x0,0x0,0x64,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x1,0x32,0x7,0xFF,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,";
    NSArray *ArrayEEPROM0 = [EEPROMData0 componentsSeparatedByString:@","];
    NSArray *ArrayEEPROM1 = [EEPROMData1 componentsSeparatedByString:@","];
    bool Flag=TRUE;
    
    NSString *failInfo = @"failIndex:";
    
	
    
	NSString* mTimeOut = @"3";
    
    for(int i=0;i<=255;i++)
    {
        strMutSendBuffer= @"mipi longwrite 0x29 0xb8 0x1 0x0 0x";
		//  strMutSendBuffer = [strMutSendBuffer stringByAppendingString:[]];
        strMutSendBuffer = [strMutSendBuffer stringByAppendingFormat:@"%X\n",i];
        [self SendData:dictKeyDefined :strMutSendBuffer :@":-)"];
        //usleep(100000) ; //delay 100ms
        
        //[self ReceData:dictKeyDefined] ;
        {
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(30000) ; //delay 100ms
                }
            }
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        
        // usleep(100000) ; //delay 100ms
        [self SendData:dictKeyDefined :@"mipi read 0x14 0xc4\n" :@":-)"];
        //usleep(100000) ; 
		
        {
			
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(30000) ; //delay 100ms
                }
            }
        }
        NSString *mresturn = [self ReceData:dictKeyDefined] ;
        
        
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@" " withString:@""];
		
        mresturn = [ToolFun getStrFromPrefixAndPostfix:mresturn Prefix:@"0x15" Postfix:@":-)"] ;
        if(i == 0 || i == 92 || i == 100)
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_PASS:nil];
            /*if([mresturn isEqualToString:@"0xA1"]||[mresturn isEqualToString:@"0x71"]||[mresturn isEqualToString:@"0x0"])
			 {
			 [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_PASS:nil];
			 }
			 
			 else
			 {
			 Flag = FALSE;
			 failInfo = [failInfo stringByAppendingString:[NSString stringWithFormat:@"0x0 0x%x",i]];
			 [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_FAIL:nil];
			 }*/
			
        }
        else
        {
            if([mresturn isEqualToString:[ArrayEEPROM0 objectAtIndex:i]])
            {
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_PASS:nil];
                
            }
            else
            {
                Flag = FALSE;
                failInfo = [failInfo stringByAppendingString:[NSString stringWithFormat:@"0x0 0x%x,",i]];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_FAIL:nil];
                
            }
        }
	}
    
    for(int i=0;i<=255;i++)
    {
        //strMutSendBuffer= @"mipi longwrite 0x29 0xb8 0x1 0x10 0x";
        strMutSendBuffer= @"mipi longwrite 0x29 0xb8 0x1 0x1 0x";
        //  strMutSendBuffer = [strMutSendBuffer stringByAppendingString:[]];
        strMutSendBuffer = [strMutSendBuffer stringByAppendingFormat:@"%X\n",i];
        [self SendData:dictKeyDefined :strMutSendBuffer :@":-)"];
        //usleep(100000) ; //delay 100ms
        //[self ReceData:dictKeyDefined] ;
        {
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(30000) ; //delay 30ms
                }
            }
        }
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        
        
		//usleep(100000) ; //delay 100ms
        [self SendData:dictKeyDefined :@"mipi read 0x14 0xc4\n" :@":-)"];
        //usleep(100000) ; 
        {
            //NSString *mresturn = [self ReceData:dictKeyDefined] ;
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                    break ;
                else
                {
                    usleep(30000) ; //delay 30ms
                }
            }
        }
        NSString *mresturn = [self ReceData:dictKeyDefined] ;
        
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mresturn = [mresturn stringByReplacingOccurrencesOfString:@" " withString:@""];
		
        mresturn = [ToolFun getStrFromPrefixAndPostfix:mresturn Prefix:@"0x15" Postfix:@":-)"] ;
        if([mresturn isEqualToString:[ArrayEEPROM1 objectAtIndex:i]])
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_PASS:nil];
            
        }
        else
        {
            Flag = FALSE;
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"0x0 0x%x",i]:nil:nil:nil:mresturn:nil:RESULT_FOR_FAIL:nil];
            failInfo = [failInfo stringByAppendingString:[NSString stringWithFormat:@"0x1 0x%x,",i]];
        }
		
    }
    
    if(Flag)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failInfo] ;
		return ;
    }
    
    
}
//send cmd to Fixture,include Unit SN  --add by Annie 2012-11-23
+(void)RS232WriteAndReadStrForMBT:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
	//SCRID:90 2011-03-21 Henry modify end
	
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mReplaceColonWithSemicolon=nil     ;
	NSString *mReferenceBufferName=nil     ;
    //NSString *mFailNoNeedShutDown=@"no";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
			//NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
		}else if ([strKey isEqualToString:@"WriteCmd2"]) 	
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify end
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
		{
			mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}
   	}
    
    
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	if(mWriteCmdTmp2 != nil)
		mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
	else 
		mWriteCmd =mWriteCmdTmp1;
	//SCRID:90 2011-03-21 Henry modify end
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    
	NSString *StrSN= [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];//get ipad SN	
	//NSString *StrSN= [TestItemManage getBufferValue:@"sn1"];//get ipad SN
	
	NSString *TmpSn=@"[sn1]";
	NSRange RangTmp;
	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	
	RangTmp=[strMutSendBuffer rangeOfString:TmpSn];
	if (RangTmp.length<0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fixture init fail!"] ;
		return ;
	}
	
	strMutSendBuffer=[strMutSendBuffer stringByReplacingOccurrencesOfString:@"[sn1]" withString:StrSN];
    
	if(strMutSendBuffer!=nil){
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
		
		if (bTmp==false)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return ;
		}
		
		if ([mWhetherRead boolValue])
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined]) 
					break ;
				else
				{
					usleep(100000) ; //delay 100ms
				}
				
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
            
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
				return ;
			}
			if (mBufferName !=nil)
			{
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
				return ;
			}
		}
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
		return ;
	}
};
+(void)RS232WriteAndReadStrForWV_Phosphorus_Trim_Rev:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferNameValue=nil;
    NSString *mWriteCmd=nil;
    NSString *mBufferName=nil;
    NSString *mTimeOut=nil;
    NSString *mWriteCmdEnd=nil;
    for (int i=0; i<[dictKeyDefined count]; i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
           // mReferenceBufferNameValue=@"0x44";
            mReferenceBufferNameValue	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
    }
        if (mDevice==nil ||
            mWriteCmd==nil
            )
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
            return ;
        }
        
        if([mReferenceBufferNameValue rangeOfString:@"0x45"].length>0)
        {
            return;
        }
        NSMutableArray *dataResultArray =[[[NSMutableArray alloc]init]autorelease];
        NSMutableArray *writeCmdArray = [[[NSMutableArray alloc]init]autorelease];
        [writeCmdArray addObjectsFromArray: [mWriteCmd componentsSeparatedByString:@","]];
        for(int i=0;i<2;i++)
        {
           // NSMutableArray *dataResultArray = [self SendManyCmds:dictKeyDefined Cmds:writeCmdArray WriteCmdEnd:mWriteCmdEnd Postfix:@":-)" TimeOut:mTimeOut];
            for(int j=0;j<[writeCmdArray count];j++)
            {
                NSMutableString *string =[NSMutableString stringWithString:[writeCmdArray objectAtIndex:j]];
                NSLog(@"send the data is string %@",string);
                bool bTmp=[self SendData:dictKeyDefined :string :@":-)"];
                if (bTmp==false)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SendManyCmds: send data fail "] ;
                    return;
                }
                NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
                int iTmp = [mTimeOut intValue] ;
                int timeInterval = - [dateTmp timeIntervalSinceNow] ;
                while (timeInterval<=iTmp)
                {
                    timeInterval = -[dateTmp timeIntervalSinceNow] ;
                    
                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                        break ;
                    else
                    {
                        usleep(100000) ; //delay 100ms
                    }
                    
                }
               NSString *dataResult = [self ReceData:dictKeyDefined];
                if(dataResult!=nil)
                {
                     [dataResultArray addObject:dataResult] ;
                }
             
            }
 
            if([[dataResultArray objectAtIndex:1] rangeOfString:@"0xF5 = 0x02"].length>0)
          // if([@"0xF5 = 0x02" rangeOfString:@"0xF5 = 0x02"].length>0)
            {
                return;
            }
        }
        return;
    };
//RL PVT write WMac,BMac,EMac bypass when Wmac value did not contain "0x00000000 0x00000000 0x00000000 0x00000000", modified by Annie 2014.12.15
+(void)RS232WriteMacAddress:(NSDictionary*)dictKeyDefined
{
    //key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
	//SCRID:90 2011-03-21 Henry modify end
    
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mReplaceColonWithSemicolon=nil     ;
	NSString *mReferenceBufferName=nil     ;
    NSString *mReferenceBufferName1=nil     ;
    NSString *mFixtureType=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
			//NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
		}else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify end
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
		{
			mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName1"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName1= [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"FixtureType"])  //add by kevin for QT0a.20140811
		{
			mFixtureType= [dictKeyDefined objectForKey:strKey] ;
		}
	}
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	if(mWriteCmdTmp2 != nil)
		mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
	else
		mWriteCmd =mWriteCmdTmp1;
	//SCRID:90 2011-03-21 Henry modify end
	
	if (mDevice==nil ||
		mWriteCmd==nil || mReferenceBufferName==nil || mReferenceBufferName1==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	if (mWriteCmdEnd!=nil)
	{
		if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
		{
			NSLog(@"NOCMDEND");
		}
		else
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
	}
    
    
    NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    NSString *mReferenceBufferNameValue1	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    //debug
//    mReferenceBufferNameValue=@"0x00000000 0x00000000 0x00000000 0x00000000";
//    mReferenceBufferNameValue1=@"Not Found!";
    //debug

    if(mReferenceBufferNameValue==nil || mReferenceBufferNameValue1==nil)
	{
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Can't read back WMac BMac address"] ;
		return ;
    }
    else if([mReferenceBufferNameValue rangeOfString:@"0x00000000 0x00000000 0x00000000 0x00000000"].length > 0 ||[mReferenceBufferNameValue rangeOfString:@"Not Found!"].length > 0  ||[mReferenceBufferNameValue rangeOfString:@"not found!"].length > 0 || [mReferenceBufferNameValue1 rangeOfString:@"0x00000000 0x00000000 0x00000000 0x00000000"].length > 0 ||[mReferenceBufferNameValue1 rangeOfString:@"Not Found!"].length > 0  ||[mReferenceBufferNameValue1 rangeOfString:@"not found!"].length > 0)
	{
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
		
		if ([mWhetherRead boolValue])
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined])
					break ;
				else
				{
					usleep(100000) ; //delay 100ms
				}
				
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
				return ;
			}
			if (mBufferName !=nil)
			{
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
				return ;
			}
		}
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
    else
	{
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish!"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
        return ;
    }

    
}

//------------------added bruce 2015.5.12--------------------------
+(void)RS232WriteAndReadStrForSLCT2:(NSDictionary*)dictKeyDefined
{
    //key parse
    bool isPass=NO;
    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;// write cmd
    NSString *mWriteCmd1=nil      ;
    NSString *mWriteCmd2=nil      ;
    
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mWhetherRead = @"yes" ;
    NSString *mPostfix =@":-)";
    NSString *mTestItemName=nil     ;
    NSString *mReplaceColonWithSemicolon=nil     ;
    NSString *mReferenceBufferName=nil     ;
    //added by Annie for RX P3 2014.08.14-----------
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
    //Added end------------------------------
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WhetherRead"])
        {
            mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
        {
            mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
        {
            mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
        }
        else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd1"])
        {
            mWriteCmd1 = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd2"])
        {
            mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
        }
        
        
    }
    if ((mDevice==nil) && (mWriteCmd==nil)&& (mWriteCmd1==nil)&& (mWriteCmd2==nil))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
    NSMutableString *strMutSendBuffer1 = [NSMutableString stringWithString:mWriteCmd1] ;
    NSMutableString *strMutSendBuffer2 = [NSMutableString stringWithString:mWriteCmd2] ;
    
    if (mWriteCmdEnd!=nil)
    {
        [strMutSendBuffer appendString:mWriteCmdEnd] ;
        [strMutSendBuffer1 appendString:mWriteCmdEnd] ;
        [strMutSendBuffer2 appendString:mWriteCmdEnd] ;
        
        
    }
    NSString *dataResult=nil;
    NSString *dataResult1=nil;
    NSString *dataResult2=nil;
    for (int i=0; i<5; i++)
    {
        bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        dataResult = [self ReceData:dictKeyDefined] ;
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        usleep(1000000) ; //delay 100ms
        
        //send cmd1-----------------------------------------------
        bool bTmp1 = [self SendData:dictKeyDefined :strMutSendBuffer1 :mPostfix] ;
        
        if (bTmp1==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data1 fail "] ;
            return ;
        }
        
        NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
        int iTmp1 = [mTimeOut intValue] ;
        int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
        while (timeInterval1<=iTmp1)
        {
            timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        dataResult1 = [self ReceData:dictKeyDefined] ;
        if (dataResult1==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        usleep(1000000) ; //delay 100ms
        
        //send cmd2-----------------------------------------------
        bool bTmp2 = [self SendData:dictKeyDefined :strMutSendBuffer2 :mPostfix] ;
        
        if (bTmp2==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data2 fail "] ;
            return ;
        }
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        dataResult2 = [self ReceData:dictKeyDefined] ;
        if (dataResult2==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        usleep(1000000) ; //delay 100ms
        
        if(([dataResult2 rangeOfString:@":-)"].length > 0) && ([dataResult2 rangeOfString:@"OK"].length > 0)&&([dataResult2 rangeOfString:@"ERROR"].length <= 0))
        {
            isPass=YES;
            break;
        }
    }
    if (isPass)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        isPass=NO;
        return ;
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
        return ;
        
    }
    
    if (mBufferName !=nil)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult2] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        return ;
    }
    
}
//------------------------ended bruce 2015.5.12--------------------
// Modified by Annie for SL P1 Dry run.
+(void)RS232WriteAndReadStr:(NSDictionary*)dictKeyDefined
{
    //key parse
    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;// write cmd
    //SCRID:90 2011-03-21 Henry modify for QT0b new fixture
    NSString *mWriteCmdTmp1=nil      ;
    NSString *mWriteCmdTmp2=nil      ;
    //SCRID:90 2011-03-21 Henry modify end
    
    
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mWhetherRead = @"yes" ;
    NSString *mPostfix =@":-)";
    NSString *mTestItemName=nil     ;
    NSString *mReplaceColonWithSemicolon=nil     ;
    NSString *mReferenceBufferName=nil     ;
    
    /*20160218 peter QT0b Wmac/Bmac*/
    NSString *mReferenceBufferName1=nil     ;
    NSString *mReferenceBufferName2=nil     ;
    
    //added by Annie for RX P3 2014.08.14-----------
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
    //Added end------------------------------
    
    NSString *mErrorBuffer=nil;// Add for SL Development_9 by Andy, 20160312.
    
    NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"]; // Added by Andy, 20160308, for SL Abnormal Display Recovery.
    
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        //SCRID:90 2011-03-21 Henry modify for QT0b new fixture
        else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
            //NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
        }else if ([strKey isEqualToString:@"WriteCmd2"])
        {
            mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
        }
        //SCRID:90 2011-03-21 Henry modify end
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WhetherRead"])
        {
            mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
        {
            mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
        {
            mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
        }
        else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])  //20160218 add by peter for QT0b wmac/bmac check value
        {
            mReferenceBufferName1= [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])  //20160218 add by peter for QT0b wmac/bmac check value
        {
            mReferenceBufferName2= [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ErrorBuffer"])  //20160312 add by peter Development_9.
        {
            mErrorBuffer= [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    //--------------Added by Annie 2014.08.14 for RX P3 DryRun---------------------
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        //SL Vinyl smokey test Paul for CT2 bypass j127 & CH/A --->move to use on QT0b
        if ([mVendorName rangeOfString:@"|"].length>0) {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }

    }
    
    //SCRID:90 2011-03-21 Henry modify for QT0b new fixture
    NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
    if(mWriteCmdTmp2 != nil)
        mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
    else
        mWriteCmd =mWriteCmdTmp1;
    //SCRID:90 2011-03-21 Henry modify end
    
    if (mDevice==nil ||
        mWriteCmd==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    
    
    //battery sn check sum
    if([mWriteCmd isEqualToString:@"batdev -w -g 0x60 -d <CHECKSUM VALUE>"])
    {
        NSString *BufferValue = [TestItemManage getBufferValue:dictKeyDefined :@"batSNCheckSumXYZ"] ;
        mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"<CHECKSUM VALUE>" withString:BufferValue];
    }
    
    //add by lorne for SL gatekepper on 20160308 start
    BOOL flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
    
    if ([mWriteCmd isEqualToString:@"device -k GasGauge -e disconnect_bat"]) {
        if (!flag) {
            mWriteCmd = @"";
        }
        
    }
    //add by lorne for SL gatekepper on 20160308 end
    //SCRID-139: Write Unit SN to Clean All FATP CB in FA. joko 2011-10-21
    if([mWriteCmd isEqualToString:@"Clean All FATP CB"])
    {
        NSString *sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
        mWriteCmd = @"sn ";
        mWriteCmd = [mWriteCmd stringByAppendingString:sN];
    }
    else if([mWriteCmd isEqualToString:@"sleep -h"] || [mWriteCmd isEqualToString:@"sleep --h"])
    {
        if ([stationName rangeOfString:@"AbnormalDisplayRecovery"].length>0) {
            mWriteCmd = @"sleep -h";
        }
        else if(![TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
        {
            mWriteCmd = @"sn";
        }
    }
    //SCRID-139: end
    
    /*SCRID-116: add function Replacing Colon With Semicolon. joko 2011-07-20*/
    if([mReplaceColonWithSemicolon boolValue])
        mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@":" withString:@";"];
    /*SCRID-116:end*/
    
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
    
    //modified by caijunbo on 2011-03-06 used for Mikey 2.0
    if (mWriteCmdEnd!=nil)
    {
        if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
        {
            NSLog(@"NOCMDEND");
        }
        else
            [strMutSendBuffer appendString:mWriteCmdEnd] ;
    }
    //---------------Added by Annie 2015.05.8 for SL P1 DryRun---------------------
    //--For retest "tristar -s "0x74 0x0 0x1" -c "8 100" diag command 5 times-------
    if([mWriteCmd isEqualToString:@"tristar -s \"0x74 0x0 0x1\" -c \"8 100\""])
    {
        NSString *dataResult=nil;
        for (int i=0; i<5; i++)
        {
            bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
            
            if (bTmp==false)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
                return ;
            }
        
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
                
            }
            //read data
            dataResult = [self ReceData:dictKeyDefined] ;
            if ([dataResult rangeOfString:@"0x75 0x0 0x0 0x0 0x0 0x0 0x0 0x1C"].length>0)
                break;
            
        }
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        if (mBufferName !=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
            return ;
        }
    }

    //end modified by caijunbo on 2011-03-06 used for Mikey 2.0
    //SCRID-152: Add parse to resove LCD Align and V8 stations CB clean issue in checkin and checkout.Judith.2011-12-19.
    NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //20160218 peter add for QT0b wmac/bmac check
    
//        NSString *mReferenceBufferNameValue1=@"0x7C709F78 0x0000E3B0 0x00000000 0x00000000";//wmac
//        NSString *mReferenceBufferNameValue2=@"[0;31mNot Found![m";//bmac
    NSString *mReferenceBufferNameValue1=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    NSString *mReferenceBufferNameValue2 =[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
    
    

    
    if([mWriteCmd rangeOfString:@"syscfg add WMac"].length>0 ||[mWriteCmd rangeOfString:@"syscfg add BMac"].length >0)
    {
        if ((![mReferenceBufferNameValue1 rangeOfString:@"Not Found!"].length>0)&(![mReferenceBufferNameValue1 rangeOfString:@"0xBABABABA 0x0000BABA 0x00000000 0x00000000"].length>0)&(![mReferenceBufferNameValue1 rangeOfString:@"0x00000000 0x00000000 0x00000000 0x00000000"].length>0)&(![mReferenceBufferNameValue2 rangeOfString: @"Not Found!"].length>0)&(![mReferenceBufferNameValue2 rangeOfString: @"0xBABABABA 0x0000BABA 0x00000000 0x00000000"].length>0)&(![mReferenceBufferNameValue2 rangeOfString:@"0x00000000 0x00000000 0x00000000 0x00000000"].length>0))
        {
            
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish!"] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"PASS"] ;
            return;
        }
    }//end
    
    
    //20160220 SL QT0b Vinyl smokey test by Peter
    //NSString *stationName =[ScriptParse getValueFromSummary:@"TestStation"];
    if([stationName rangeOfString:@"QT0b"].length>0)
    {
        /*if (mReferenceBufferNameValue2==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"SFC return nil"];
            return;
        }*/
        if([mReferenceBufferNameValue2 rangeOfString:@"region_code= "].length>0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_FAIL :@"No Regn code"] ;//Unknown BoardID or Regn code -- Add by Andy for SL QT0b, 20160220
            return;
        }

        if (([mReferenceBufferNameValue1 rangeOfString:@"0x08"].length>0)||([mReferenceBufferNameValue2 rangeOfString:@"region_code=CH/A"].length>0))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"J127 or China config, no need test"] ;
            return;
        }
    }
    //end
    
    //20160304 SL new station Abnormal Display Recovery by Andy.
    if([stationName rangeOfString:@"AbnormalDisplayRecovery"].length>0 && ([mWriteCmd rangeOfString:@"display -m fix_pgma"].length>0))
    {
        if (mReferenceBufferNameValue==nil) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"No Receive Data"];
            return;
        }
        else
        {
            mWriteCmd = nil;
            
            if ([mReferenceBufferNameValue rangeOfString:@"OK"].length>0)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"Bypass"];
                return ;
            }
            else if ([mReferenceBufferNameValue rangeOfString:@"FAIL"].length>0)//FAIL
            {
                mWriteCmd=@"display -m fix_pgma";
                //                strMutSendBuffer = [[NSMutableString alloc] init];
                //                strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
                //                [strMutSendBuffer appendString:mWriteCmdEnd] ;
            }
            else
            {
                [TestItemManage setBufferValue:dictKeyDefined :mErrorBuffer :@"Error:item 4 return abnormal!"] ;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"];
                return;
            }
        }
    }
    
    if ([stationName rangeOfString:@"AbnormalDisplayRecovery"].length>0 &&[mWriteCmd rangeOfString:@"cbwrite 0xA6 incomplete"].length>0)
    {
        if ([mReferenceBufferNameValue rangeOfString:@"OK"].length>0)
        {
            mWriteCmd=@"cbwrite 0xA6 incomplete";
            
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"Bypass"];
            return;
        }
        
    }
    
    
    if([stationName rangeOfString:@"AbnormalDisplayRecovery"].length>0 && ([mWriteCmd rangeOfString:@"sleep -h"].length>0))
    {
        if ([mReferenceBufferNameValue rangeOfString:@"Fail"].length>0||[mReferenceBufferNameValue1 rangeOfString:@"Fail"].length>0) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"Bypass"];
            return ;
        }
    }// End 20160305.
    
    if([mReferenceBufferNameValue rangeOfString:@"BYPASS"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
        return ;
    }else if([mReferenceBufferNameValue rangeOfString:@"lb_result=0"].length > 0)//if the data which get from sfc contains lb_result=0, do nothing.add by blake 20130802 from PL for judging the unit has tested laser staion.
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish!"] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
        return ;
    }
    else    //SCRID-152:end
    {
        bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if ([mWriteCmd rangeOfString:@"baseband --passthrough"].length > 0)
        {
            usleep(100000);
            [self SendData:dictKeyDefined :@"EXIT" :@":-)"] ;
        }
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        
        if ([mWhetherRead boolValue])
        {
            NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
            int iTmp = [mTimeOut intValue] ;
            int timeInterval = - [dateTmp timeIntervalSinceNow] ;
            while (timeInterval<=iTmp)
            {
                timeInterval = -[dateTmp timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
                
            }
            //read data
            NSString *dataResult = [self ReceData:dictKeyDefined] ;
            
            /*if([mWriteCmd rangeOfString:@"FL"].length > 0) //add by judith 2012-05-17
             {
             sleep(1);
             [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
             float distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
             if (mBufferNameHES !=nil)
             [TestItemManage setBufferValue:dictKeyDefined :mBufferNameHES :[NSString stringWithFormat:@"%f",distance]] ;
             NSLog(@"HEFF Log InitDistance after = %@",[NSString stringWithFormat:@"%f",distance]);
             //int distance1 = (distance - 15)*2000;
             //int distance1 = (distance - [mHeffDistance floatValue])*2000;
             //mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:[NSString stringWithFormat:@"%d",distance1]];
             //[dictKeyDefined setValue:@"Motor" forKey:@"Device"];
             }*/
            
            /*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
            if ([mWriteCmd rangeOfString:@"boardid"].length>0)
            {
                if (dataResult==nil)
                {
                    dataResult=@"boardid unknow";
                }
                [TestItemManage setUnitValue:dictKeyDefined :STRKEYBOARDID : dataResult];
                
            }
            
            /*SCRID-104: end*/
            if([mWriteCmd rangeOfString:@"smokey --run CurrentTest"].length > 0)
            {
                if([dataResult rangeOfString:@"All errors:" ].length <= 0)
                {
                    dataResult = [dataResult stringByAppendingString:@"BYPASS"];
                }
            }
            
            
            if([mWriteCmd rangeOfString:@"--sel als1 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als2 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als3 --init"].length > 0)
            {
                if([dataResult rangeOfString:@"OK"].length <= 0 || [dataResult rangeOfString:@"ERROR"].length > 0
                   || [dataResult rangeOfString:@"Error"].length > 0 || [dataResult rangeOfString:@"error"].length > 0)
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"BYPASS"] ; 
            }
            
            if (dataResult==nil)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
                return ;
            }
            
            
            if (mBufferName !=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
                return ;
            }
        }
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
        return ;
    }
}


// add by Paul 08252014
// Add a new method of "RS232WriteAndReadStrWithFlag:" which is used to distinguish fixture cmd "green led on" and "blue led on".(QSM SA-BUTTONFLEX station)
//Added by bruce 2015.8.12
+(void)RS232WriteAndReadStrForSLOrion:(NSDictionary*)dictKeyDefined
{
    //key parse
    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;// write cmd
    //SCRID:90 2011-03-21 Henry modify for QT0b new fixture
    NSString *mWriteCmdTmp1=nil      ;
    NSString *mWriteCmdTmp2=nil      ;
    //SCRID:90 2011-03-21 Henry modify end
    
    
    NSString *mBufferName=nil    ;
    NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mWhetherRead = @"yes" ;
    NSString *mPostfix =@":-)";
    NSString *mTestItemName=nil     ;
    NSString *mReplaceColonWithSemicolon=nil     ;
    NSString *mReferenceBufferName=nil     ;
    //added by Annie for RX P3 2014.08.14-----------
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//
    //Added end------------------------------
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        //SCRID:90 2011-03-21 Henry modify for QT0b new fixture
        else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
            //NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
        }else if ([strKey isEqualToString:@"WriteCmd2"])
        {
            mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
        }
        //SCRID:90 2011-03-21 Henry modify end
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"PDCAWrite"])
        {
            mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WhetherRead"])
        {
            mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
        {
            mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
        {
            mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
        }
        else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }
    }
    
    //--------------Added by Annie 2014.08.14 for RX P3 DryRun---------------------
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
    
    if (mDevice==nil ||
        mWriteCmdTmp1==nil||mWriteCmdTmp2==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    
    
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmdTmp1] ;
    
    //modified by caijunbo on 2011-03-06 used for Mikey 2.0
    if (mWriteCmdEnd!=nil)
    {
        if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
        {
            NSLog(@"NOCMDEND");
        }
        else
            [strMutSendBuffer appendString:mWriteCmdEnd] ;
    }
    NSMutableString *strMutSendBuffer1 = [NSMutableString stringWithString:mWriteCmdTmp2] ;
    
    //modified by caijunbo on 2011-03-06 used for Mikey 2.0
    if (mWriteCmdEnd!=nil)
    {
        if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
        {
            NSLog(@"NOCMDEND");
        }
        else
            [strMutSendBuffer1 appendString:mWriteCmdEnd] ;
    }
    NSString *dataResult=nil;
    NSString *dataResult1=nil;
    for (int i=0; i<5; i++)
    {
        bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        dataResult = [self ReceData:dictKeyDefined] ;
        
        bool bTmp1 = [self SendData:dictKeyDefined :strMutSendBuffer1 :mPostfix] ;
        
        if (bTmp1==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        
        NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
        int iTmp1 = [mTimeOut intValue] ;
        int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
        while (timeInterval1<=iTmp1)
        {
            timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        dataResult1 = [self ReceData:dictKeyDefined] ;
        
        if ([dataResult1 rangeOfString:@"0x75  0x00  0x00  0x00  0x00  0x00  0x00  0x1C"].length>0)
            break;
        
    }
    if (dataResult1==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
        return ;
    }
    
    if (mBufferName !=nil)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult1] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        return ;
    }
    
};
//Ended by bruce 2015.8.12
+(void)RS232WriteAndReadStrWithFlag:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
    
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
    
    
	
	NSString *mBufferName=nil    ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
    
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
            
		}else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
        
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    
    // add by Paul 08252014
    BOOL flag =NO;
	flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
    if(!flag)
    {
        mWriteCmd = mWriteCmdTmp2;
        
    }else
    {
        mWriteCmd = mWriteCmdTmp1;
    }
    if(mWriteCmd == nil)
        mWriteCmd = @"";
    
    mWriteCmd = [mWriteCmd stringByAppendingString:mWriteCmdEnd];
	// add Paul 08262014
	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	
    
    bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    if ([mWhetherRead boolValue])
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        if (mBufferName !=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
            return ;
        }
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    return ;
	
};
// end 08252014
// add by Paul 08232014
+(void)RS232WriteAndReadStrJudgeFixtureType:(NSDictionary*)dictKeyDefined
{
    //key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
	//SCRID:90 2011-03-21 Henry modify end
    
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mReplaceColonWithSemicolon=nil     ;
	NSString *mReferenceBufferName=nil     ;
    NSString *mFixtureType=nil;
    NSString *mFixtureType2=nil; // add by Paul 08232014
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
			//NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
		}else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify end
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
		{
			mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"FixtureType"])  //add by kevin for QT0a.20140811
		{
			mFixtureType= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"FixtureType2"]) // add by Paul for CG-Button.08232014
        {
            mFixtureType2= [dictKeyDefined objectForKey:strKey] ;
        }
	}
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	if(mWriteCmdTmp2 != nil)
        mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
	else
        mWriteCmd =mWriteCmdTmp1;
	//SCRID:90 2011-03-21 Henry modify end
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	//battery sn check sum
	if([mWriteCmd isEqualToString:@"batdev -w -g 0x60 -d <CHECKSUM VALUE>"])
	{
		NSString *BufferValue = [TestItemManage getBufferValue:dictKeyDefined :@"batSNCheckSumXYZ"] ;
		mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"<CHECKSUM VALUE>" withString:BufferValue];
	}
    
    
	//SCRID-139: Write Unit SN to Clean All FATP CB in FA. joko 2011-10-21
	if([mWriteCmd isEqualToString:@"Clean All FATP CB"])
	{
		NSString *sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
		mWriteCmd = @"sn ";
		mWriteCmd = [mWriteCmd stringByAppendingString:sN];
	}
    else if([mWriteCmd isEqualToString:@"sleep -h"] || [mWriteCmd isEqualToString:@"sleep --h"] || [mWriteCmd isEqualToString:@"device -k GasGauge -e disconnect_bat"])
    {
		if(![TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
		{
			mWriteCmd = @"sn";
		}
    }
	//SCRID-139: end
	
	/*SCRID-116: add function Replacing Colon With Semicolon. joko 2011-07-20*/
	if([mReplaceColonWithSemicolon boolValue])
        mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@":" withString:@";"];
	/*SCRID-116:end*/
	
    // add by Paul 08232014
    NSString *mReferenceBufferNameValue2	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if(mReferenceBufferNameValue2 !=nil && mFixtureType2 !=nil)
    {
        if([mReferenceBufferNameValue2 rangeOfString:mFixtureType2].length<=0)
            mWriteCmd = mWriteCmdTmp2;
        else
            mWriteCmd = mWriteCmdTmp1;
        if(mWriteCmd == nil)
            mWriteCmd = @"";
    }
    // end Paul 08232014
    
	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	
	//modified by caijunbo on 2011-03-06 used for Mikey 2.0
	if (mWriteCmdEnd!=nil)
	{
		if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
		{
			NSLog(@"NOCMDEND");
		}
		else
            [strMutSendBuffer appendString:mWriteCmdEnd] ;
	}
	//end modified by caijunbo on 2011-03-06 used for Mikey 2.0
	//SCRID-152: Add parse to resove LCD Align and V8 stations CB clean issue in checkin and checkout.Judith.2011-12-19.
	NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //add by kevin for QT0a start 20140811
    if(mReferenceBufferNameValue !=nil && mFixtureType !=nil)
    {
        if([mReferenceBufferNameValue rangeOfString:mFixtureType].length<=0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"ByPass"] ;
            return;
        }
    }
    //add by kevin for QT0a end 20140811
    
    
    
    if ([mReferenceBufferNameValue isEqualToString:@"MopadHashPass"]) {
        return;
    }
    if([mReferenceBufferNameValue rangeOfString:@"0x45"].length>0 && [mWriteCmd rangeOfString:@"sensorreg --sel pressure -w 0xF5 0x00"].length>0)
    {
        return;
    }
	if([mReferenceBufferNameValue rangeOfString:@"BYPASS"].length > 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
		return ;
	}else if([mReferenceBufferNameValue rangeOfString:@"lb_result=0"].length > 0)//if the data which get from sfc contains lb_result=0, do nothing.add by blake 20130802 from PL for judging the unit has tested laser staion.
	{
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish!"] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
		return ;
	}
	else    //SCRID-152:end
	{
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
		
        if ([mWriteCmd rangeOfString:@"baseband --passthrough"].length > 0)
        {
            usleep(100000);
            [self SendData:dictKeyDefined :@"EXIT" :@":-)"] ;
        }
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
		
		if ([mWhetherRead boolValue])
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
				else
				{
					usleep(100000) ; //delay 100ms
				}
				
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
			
			/*if([mWriteCmd rangeOfString:@"FL"].length > 0) //add by judith 2012-05-17
             {
             sleep(1);
             [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
             float distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
             if (mBufferNameHES !=nil)
             [TestItemManage setBufferValue:dictKeyDefined :mBufferNameHES :[NSString stringWithFormat:@"%f",distance]] ;
             NSLog(@"HEFF Log InitDistance after = %@",[NSString stringWithFormat:@"%f",distance]);
             //int distance1 = (distance - 15)*2000;
             //int distance1 = (distance - [mHeffDistance floatValue])*2000;
             //mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:[NSString stringWithFormat:@"%d",distance1]];
             //[dictKeyDefined setValue:@"Motor" forKey:@"Device"];
             }*/
			
			/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			if ([mWriteCmd rangeOfString:@"boardid"].length>0)
			{
				if (dataResult==nil)
				{
					dataResult=@"boardid unknow";
				}
				[TestItemManage setUnitValue:dictKeyDefined :STRKEYBOARDID : dataResult];
                
			}
            
			/*SCRID-104: end*/
            if([mWriteCmd rangeOfString:@"smokey --run CurrentTest"].length > 0)
            {
                if([dataResult rangeOfString:@"All errors:" ].length <= 0)
                {
                    dataResult = [dataResult stringByAppendingString:@"BYPASS"];
                }
            }
            
            
            if([mWriteCmd rangeOfString:@"--sel als1 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als2 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als3 --init"].length > 0)
            {
                if([dataResult rangeOfString:@"OK"].length <= 0 || [dataResult rangeOfString:@"ERROR"].length > 0
                   || [dataResult rangeOfString:@"Error"].length > 0 || [dataResult rangeOfString:@"error"].length > 0)
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"BYPASS"] ;
            }
			
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
				return ;
			}
			if (mBufferName !=nil)
			{
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
				return ;
			}
		}
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
}
// end Paul 08252014

+(void)RS232WriteAndReadStrForHES:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mPostfix =@"RS=";
	NSString *mTestItemName=nil     ;
	NSString *mHeffDistance=nil;
    NSString *mWhetherRead = @"yes" ;
	NSString *mNeedCaliData = @"no" ;
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"HeffDistance"])
        {
            mHeffDistance = [dictKeyDefined objectForKey:strKey] ;
        }
        else if([strKey isEqualToString:@"WhetherRead"])
        {
            mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
        }else if([strKey isEqualToString:@"NeedCaliData"])
        {
            mNeedCaliData = [dictKeyDefined objectForKey:strKey] ;
        }
	}
    [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
    float distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
    NSLog(@"RS232WriteAndReadStrForHES distance =%f",distance);
    //add for PS PVT for Init Test item range from [15,15.25] to [12.5,13] by judith 20120924
    BOOL caliFlag = [mNeedCaliData boolValue];
    if (caliFlag) 
    {
        NSString *strPath = @"/vault/CalibrationData_Hall.txt";
        NSString *strFileContent = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
        if (strFileContent==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no calibration file or no offset/initDistance Value, please calibrate firstly"] ;
            return;
        }
        float mCallibrationData = [strFileContent floatValue];
        
        float initDistance = [mHeffDistance floatValue]- 0.5 + mCallibrationData;
        mHeffDistance = [NSString stringWithFormat:@"%f", initDistance];
        NSLog(@"need callibration mHeffDistance = %f",initDistance);
        
    }
    //end add
    int distance1 = (distance - [mHeffDistance floatValue])*2000;
    
    mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:[NSString stringWithFormat:@"%d",distance1]];
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
    
    if (mWriteCmdEnd!=nil)
    {
        if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
        {
            NSLog(@"NOCMDEND");
        }
        else
            [strMutSendBuffer appendString:mWriteCmdEnd] ;
    }
    
    [dictKeyDefined setValue:@"Motor" forKey:@"Device"];
    bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    [self SendData:dictKeyDefined :@"clean\r" :@"%"] ;
    /*add for receive the info after send the clean*/
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined]) 
            break ;
        else
        {
            usleep(100000) ; 
        }
        
    }
    if(![mWhetherRead boolValue])
    {
        return;//return if WhetherRead is no
    }
    /*add for receive the info after send the clean*/
    
    BOOL moveDoneFlag = TRUE ;
    while (moveDoneFlag) // check if the motor complete moving
    {
        bool bTmp1 = [self SendData:dictKeyDefined :@"RS\r\n" :mPostfix] ;
        
        if (bTmp1==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined]) 
                break ;
            else
            {
                usleep(100000) ; 
            }
            
        }
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        if ([dataResult rangeOfString:@"RS=R"].length > 0) 
        {
            moveDoneFlag = FALSE;
        }
        
    }
    
    [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
    distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",distance]] ;	
    return ;
    
    
}
/*SCRID-105: Add Parser RS232WriteAndReadStrMikeyBoard. joko 2011-05-26*/
+(void)RS232WriteAndReadStrMikeyBoard:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
    NSString *mPassStr=@"ok";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PassStr"])
		{
			mPassStr = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	NSString *dataResult=@"";
	int reSendCount = 0;
	
	BOOL bReSend = TRUE;
	while(bReSend)
	{
		reSendCount++;
        
        NSRange Qt3FixtureRange=[mWriteCmd rangeOfString:@"$"];
        if (Qt3FixtureRange.length>0 && reSendCount>1)
        {
            sleep(1);
        }
		for(int i=0; i<[mWriteCmd length]; i++)
		{
			usleep(200) ; //delay 100ms
			NSString *tmpCMD = [mWriteCmd substringFromIndex:i];
			tmpCMD = [tmpCMD substringToIndex:1];
			if(i == [mWriteCmd length] - 1)
				tmpCMD = [tmpCMD stringByAppendingString:mWriteCmdEnd];
			
			[self SendData:dictKeyDefined :tmpCMD :mPostfix] ;
		}
		
		//bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mPostfix] ;
		
		usleep(20000) ;
		
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
			{
				usleep(100000) ; //delay 100ms
			}
		}
		
		dataResult = [self ReceData:dictKeyDefined] ;

        
		if((dataResult != nil) && ([dataResult rangeOfString:mPassStr].length > 0))//justin
		{
            if ([mWriteCmd isEqualToString:@"$GetTH#"])
            {
                NSString *temperaValue=[ToolFun getStrFromPrefixAndPostfix:dataResult
                                                                    Prefix:@"::GetTH="
                                                                   Postfix:@"/"] ;
                NSString *humidiValue=[ToolFun getStrFromPrefixAndPostfix:dataResult
                                                                   Prefix:@"/"
                                                                  Postfix:@" =*="] ;
                if ([temperaValue floatValue]<15 || [temperaValue floatValue]>30 || [humidiValue floatValue]<35 || [humidiValue floatValue]>70)
                {
                    if(reSendCount > 5)
                        bReSend = FALSE;
                    else
                        bReSend = TRUE;
                }
            }
            
			bReSend = FALSE;
			break;
		}
		else
		{
			if(reSendCount > 5)
				bReSend = FALSE;
			else
				bReSend = TRUE;
		}
	}
	
	if (dataResult==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
		return ;
	}
	if (mBufferName !=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;
}
/*SCRID-105: end*/


+(void)RS232WriteAndReadStrIniOSMode:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	NSString *dataResult=@"";
	
	
	
	{
		
		for(int i=0; i<[mWriteCmd length]; i++)
		{
			usleep(20000) ; //delay 10ms
			NSString *tmpCMD = [mWriteCmd substringFromIndex:i];
			tmpCMD = [tmpCMD substringToIndex:1];
			if(i == [mWriteCmd length] - 1)
				tmpCMD = [tmpCMD stringByAppendingString:mWriteCmdEnd];
			
			[self SendData:dictKeyDefined :tmpCMD :mPostfix] ;
		}
		
		//bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mPostfix] ;
		
		usleep(2000000) ;
		
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
			{
				usleep(100000) ; //delay 100ms
			}
		}
		
		
	}
	
    dataResult = [self ReceData:dictKeyDefined] ;
    
	if (dataResult==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
		return ;
	}
	if (mBufferName !=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	return ;
}


+(void)RS232WriteAndReadStrIniOSMode2Times:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	NSString *dataResult=@"";
	
	
	
	{
		
		for(int i=0; i<[mWriteCmd length]; i++)
		{
			usleep(20000) ; //delay 10ms
			NSString *tmpCMD = [mWriteCmd substringFromIndex:i];
			tmpCMD = [tmpCMD substringToIndex:1];
			if(i == [mWriteCmd length] - 1)
				tmpCMD = [tmpCMD stringByAppendingString:mWriteCmdEnd];
			
			[self SendData:dictKeyDefined :tmpCMD :mPostfix] ;
		}
		
		//bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mPostfix] ;
		
		usleep(20000) ;
		
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined])
				break ;
			else
			{
				usleep(100000) ; //delay 100ms
			}
		}
		
		
	}
    
    dataResult = [self ReceData:dictKeyDefined] ;
    
    if([dataResult rangeOfString:mPostfix].length <= 0)
    {
        {
            
            for(int i=0; i<[mWriteCmd length]; i++)
            {
                usleep(20000) ; //delay 10ms
                NSString *tmpCMD = [mWriteCmd substringFromIndex:i];
                tmpCMD = [tmpCMD substringToIndex:1];
                if(i == [mWriteCmd length] - 1)
                    tmpCMD = [tmpCMD stringByAppendingString:mWriteCmdEnd];
                
                [self SendData:dictKeyDefined :tmpCMD :mPostfix] ;
            }
            
            //bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mPostfix] ;
            
            usleep(20000) ;
            
            NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
            int iTmp2 = [mTimeOut intValue] ;
            int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
            while (timeInterval2<=iTmp2)
            {
                timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
                
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(100000) ; //delay 100ms
                }
            }
            
            
        }
        
        dataResult = [self ReceData:dictKeyDefined] ;
    }
    
    
	if (dataResult==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
		return ;
	}
	if (mBufferName !=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	return ;
}

//SCRID:126 add Parser RS232WriteAndReadStrAccelAndCompass by Jack 2011-08-03.
+(void)RS232WriteAndReadStrAccelAndCompass:(NSDictionary*)dictKeyDefined
{
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mLoopTimes=@"1";
	NSString *mUplimit=nil;
	NSString *mPrefix=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"LoopTimes"])
		{
			mLoopTimes=[dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Uplimit"])
		{
			mUplimit=[dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}
	}
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	NSString *dataResult=@"";	
	int RepeatTimes=1;
	while(RepeatTimes<=[mLoopTimes intValue])
	{
		RepeatTimes+=1;
		NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
		if (mWriteCmdEnd!=nil)
		{
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
		}		
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
		if(bTmp==FALSE)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
			return ;
		}
		usleep(20000) ;
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:dictKeyDefined]) 
				break ;
			else
			{
				usleep(100000) ; //delay 100ms
			}
		}		
		dataResult = [self ReceData:dictKeyDefined] ;
		NSLog(@"data is %@",dataResult);
		if((dataResult != nil) && ([dataResult rangeOfString:mPostfix].length > 0))
		{
			NSString *strTemp=[ToolFun getStrFromPrefixAndPostfix:dataResult Prefix: mPrefix Postfix: mPostfix];
			strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\n" withString:@","];
			strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\r" withString:@","];
			strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\t" withString:@","];
			
			NSLog(@"strTemp =%@",strTemp);
			
			NSArray *mutArrayData=[strTemp componentsSeparatedByString:@","];
			NSLog(@"mutArrayData =%@",mutArrayData);
			
			int accelX1,accelY1,accelZ1,accelX2,accelY2,accelZ2;
			int X,Y,Z;
			int i=0;
			if([mTestItemName rangeOfString:@"Compass"].length>0)
			{
				for (i=0;i<99;i++)
				{
					accelX1=[[mutArrayData objectAtIndex:(i*4+2)] intValue];
					accelY1=[[mutArrayData objectAtIndex:(i*4+3)] intValue];
					accelZ1=[[mutArrayData objectAtIndex:(i*4+4)] intValue];
					
					accelX2=[[mutArrayData objectAtIndex:((i+1)*4+2)] intValue];
					accelY2=[[mutArrayData objectAtIndex:((i+1)*4+3)] intValue];
					accelZ2=[[mutArrayData objectAtIndex:((i+1)*4+4)] intValue];
					if(accelX2>=accelX1)
					{
						X=accelX2-accelX1;
					}
					else
					{
						X=accelX1-accelX2;
					}
					if(accelY2>=accelY1)
					{
						Y=accelY2-accelY1;
					}
					else
					{
						Y=accelY1-accelY2;
					}					
					if(accelZ2>=accelZ1)
					{
						Z=accelZ2-accelZ1;
					}
					else
					{
						Z=accelZ1-accelZ2;
					}					
					if (X > [mUplimit intValue] || Y > [mUplimit intValue] || Z > [mUplimit intValue] )
						break;
				}
				if (mBufferName !=nil)
				{
					[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				}				
				if(i==99)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;	
					return ;
				}
			}
			else
			{
				for (i=0;i<99;i++)
				{
					accelX1=[[mutArrayData objectAtIndex:(i*3+1)] intValue];
					accelY1=[[mutArrayData objectAtIndex:(i*3+2)] intValue];
					accelZ1=[[mutArrayData objectAtIndex:(i*3+3)] intValue];
					
					accelX2=[[mutArrayData objectAtIndex:((i+1)*3+1)] intValue];
					accelY2=[[mutArrayData objectAtIndex:((i+1)*3+2)] intValue];
					accelZ2=[[mutArrayData objectAtIndex:((i+1)*3+3)] intValue];
					if(accelX2>=accelX1)
					{
						X=accelX2-accelX1;
					}
					else
					{
						X=accelX1-accelX2;
					}
					if(accelY2>=accelY1)
					{
						Y=accelY2-accelY1;
					}
					else
					{
						Y=accelY1-accelY2;
					}					
					if(accelZ2>=accelZ1)
					{
						Z=accelZ2-accelZ1;
					}
					else
					{
						Z=accelZ1-accelZ2;
					}					
					if (X > [mUplimit intValue] || Y > [mUplimit intValue] || Z > [mUplimit intValue] )
						break;
				}
				if (mBufferName !=nil)
				{
					[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				}				
				if(i==99)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;	
					return ;
				}				
			}
			sleep(10);
		}
	}
	if (dataResult==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
		return ;
	}
	if (mBufferName !=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;	
		return ;
	}
}
//SCRID:126 end

+(void)ConnectEthernetBySocket:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	
	//socket initializing as belowed
    struct protoent *ppe;
    ppe=getprotobyname("tcp");
    listenSocket=socket(AF_INET,SOCK_STREAM,ppe->p_proto);  ///----obtain  the socket handle .
	NSLog(@"Ethernet socket listenSocket=%d",listenSocket);
	NSString *uiInfo = @"Fail,";
    if (listenSocket==-1) //---obtain socket handle fail
	{
		uiInfo = @"Fail, obtain socket handle fail, listenSocket=";
		NSString *tmp = [NSString stringWithFormat:@"%d",listenSocket];
		uiInfo = [uiInfo stringByAppendingString:tmp];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
		return ;
	}
	
	//NSString *strIP=@"169.254.4.10";
	//int iPortID =5025;
	NSString *strIP=[ScriptParse getValueFromSummary:@"EthernetIP"];
	int iPortID =[[ScriptParse getValueFromSummary:@"EthernetPort"] intValue];
	NSLog(@"Ethernet connect strIP=%@",strIP);
	NSLog(@"Ethernet connect iPortID=%d",iPortID);
	struct sockaddr_in daddr;
    memset((void *)&daddr,0,sizeof(daddr));
    daddr.sin_family=AF_INET;
	daddr.sin_port=htons(iPortID);   ////convert port
    daddr.sin_addr.s_addr=inet_addr([strIP cStringUsingEncoding:NSASCIIStringEncoding]) ; ///connect address
	int err ;
    err = connect(listenSocket,(struct sockaddr *)&daddr,sizeof(daddr)) ;
	///....................................................
	NSLog(@"Ethernet connect err=%d",err);
	if (err!=0) ///connected fail .
	{
		uiInfo = @"Fail, Connect Ethernet Fail, error return=";
		NSString *tmp = [NSString stringWithFormat:@"%d",err];
		uiInfo = [uiInfo stringByAppendingString:tmp];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo];
		return;
	}
	else
	{
		
		//==configure port===============//
		int iTimeOut = 5000 ;
		setsockopt(listenSocket,IPPROTO_TCP,SO_RCVTIMEO,(char*)&iTimeOut,sizeof(int)) ;
		setsockopt(listenSocket,IPPROTO_TCP,SO_SNDTIMEO,(char*)&iTimeOut,sizeof(int)) ;
		int iAddr = 1 ;
		setsockopt(listenSocket,SOL_SOCKET,SO_REUSEADDR,(char*)&iAddr,sizeof(int)) ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	
}

+(void)DisconnectEthernetBySocket:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	
	shutdown(listenSocket,0) ;////wait end the data sended.
	close(listenSocket);
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	
}

+(void)SendAndReceiveDataToOrFromEthernetBySocket:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mWriteCmd=nil        ;
	NSString *mBufferName=nil        ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if(mWriteCmd == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"] ;
		return;
	}
	
	//==================send data=====================================
	NSString *uiInfo = @"Fail,";
	long wordsWritten;
	//char *cData= "SYSTem:COMMunicate:ENABle ON,LAN\n" ;
	//mWriteCmd = @"SYST:VERS?\n";
	char *cData= [mWriteCmd UTF8String];
	int sendLen = strlen(cData);
	NSLog(@"Ethernet send len=%d \n",sendLen);
	//memset(cData,'\0',[sendBuffer length]+1) ;
	//[sendBuffer getBytes:cData] ;
	uiInfo = [NSString stringWithFormat:@"\n      [%@]Send:%@",[[NSCalendarDate date] description],mWriteCmd];
	NSLog(@"Ethernet send listenSocket=%d \n",listenSocket);
	wordsWritten = send(listenSocket,cData,sendLen,0) ;
	NSLog(@"Ethernet send return len=%d \n",wordsWritten);
	
	//==================receive data=====================================
	sleep(3);
	int wordsRead = 0;
	char tempRecBuffer[256] ;
	memset(tempRecBuffer, 0, 256);
	wordsRead = recv(listenSocket,tempRecBuffer,255,0) ; //received socket data
	NSLog(@"Ethernet socket comm received len=%d \n",wordsRead);
	NSLog(@"Ethernet socket comm received data=%s \n",tempRecBuffer);
	
	NSString* nsstringReceiveData = [NSString stringWithCString:tempRecBuffer];
	NSLog(@"Ethernet socket comm received nsstringReceiveData=%@ \n",nsstringReceiveData);
	
	if (wordsRead <= 0) //read available data
	{
		uiInfo = @"Fail, Receive data from Ethernet Fail, wordsRead=";
		NSString *tmp = [NSString stringWithFormat:@"%d",wordsRead];
		uiInfo = [uiInfo stringByAppendingString:tmp];
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :uiInfo] ;
		return;
	}
	
	if (mBufferName !=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :nsstringReceiveData] ;
	}
	
	uiInfo = [uiInfo stringByAppendingString:[NSString stringWithFormat:@"\n      [%@]Receive:%@",[[NSCalendarDate date] description],nsstringReceiveData]];
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :uiInfo] ;	
	
}


+(void)Delay:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mMilliSecond=nil        ;
    NSString *mReferenceBufferName=nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"MilliSecond"])
		{
			mMilliSecond = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
	}
        //Lucky add for cog bert test
    if ([[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] isEqualToString:@"FAIL"]) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"];
        return;
    }
    
	if (mMilliSecond==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	int iDelay= [mMilliSecond integerValue]*1000 ;
	usleep(iDelay);
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"Delay %@ ms",mMilliSecond]] ;	
	return ;
};


//SCRID:137 add parser ParserV8Timing by Tony 2011-09-28.
+(void)ParserV8Timing:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	//key parse
	NSString *mMilliSecond=nil        ;	
	NSString *mReferenceBufferName=nil ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"MilliSecond"])
		{
			mMilliSecond = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	if (mMilliSecond==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	[mMilliSecond integerValue]*1000 ;
	int timing = [mMilliSecond integerValue] / 1000;
	int m = -1;
	
	for (int i = 0; i <= timing; i++) 
	{
		usleep(1000000);
		NSString *temp = [TestItemParse ReceData:dictKeyDefined];
		if ([temp rangeOfString:@"EMERGENCY"].length > 0) 
		{
			[TestItemManage setSubItemPDCAInfo:dictKeyDefined:nil:nil:mLowLimit:mUpLimit:[NSString stringWithFormat:@"%d",i]:nil:IP_FAIL:@"FAIL"];
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d", i]] ;
			return;
		}
		m++;
	}
	
	
	if(m >= [mLowLimit integerValue] && m <= [mUpLimit integerValue])
	{
		enumResult = RESULT_FOR_PASS;
		strTestResultForUIinfo = [NSString stringWithFormat:@"%d",m] ;
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		strTestResultForUIinfo = [NSString stringWithFormat:@"%d",m] ;
	}
	
	//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d(s)",timing]] ;
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	return ;
};
//SCRID:137 end


+(void)MessageBox:(NSDictionary*)dictKeyDefined
{
    //SCRID:22
    //Description:proximity verify for GateKeeper
    //added by caijunbo on 2010-11-24
    NSString*stationName =[ScriptParse getValueFromSummary:@"TestStation"];
    if([stationName isEqualToString:@"GateKeeper"])
    {
        NSString* strRetest=[TestItemManage getBufferValue:dictKeyDefined:@"BufferForQT3Retest"];
        if (![strRetest isEqualToString:@"need retest"])// if not contain then quite
            return;
    }
    //added end by caijunbo on 2010-11-24
    
    //Add by Tony
    if([stationName isEqualToString:@"Magnetic Rention Spine"])
    {
        NSString* strRetest=[TestItemManage getBufferValue:dictKeyDefined:@"MagnetRentionSpineRetest"];
        if (![strRetest isEqualToString:@"need retest"])// if not contain then quite
            return;
    }
    
    if([stationName isEqualToString:@"Magnetic Rention Flap"])
    {
        NSString* strRetest=[TestItemManage getBufferValue:dictKeyDefined:@"MagnetRentionFlapRetest"];
        if (![strRetest isEqualToString:@"need retest"])// if not contain then quite
            return;
    }
    //Add by Tony
    
    //SCRID:52
    //added by caijunbo on 2010-12-25
    NSString* mBufferName=nil;
    NSString* mReferenceBufferName=nil;
    
    //added end by caijunbo on 2010-12-25
    
    //key parse
    NSString *mTitle=nil        ;
    NSString *mMessage=nil      ;// write cmd
    
    NSString *mButtons=nil     ;
    NSString *mSpec =nil       ;
    NSString *mAlertStyle=@"1"  ;
    /***********************************************************
     **SCRID:50  delete [1] when only show one UI **
     ***********************************************************/
    NSString *mWinTitle = @"Unit";
    /** SCRID:50 end**/
    NSString *mDesc=@"CHI";
    //SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
    NSString *mWaitTime = nil;
    NSInteger intTime = 0;
    //SCRID:101 end
    NSString *mShowNumber = @"No";
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Title"])
        {
            mTitle = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Message"])
        {
            mMessage = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Buttons"])
        {
            mButtons = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Spec"])
        {
            mSpec = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"AlertStyle"])
        {
            mAlertStyle = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Description"])
        {
            mDesc = [dictKeyDefined objectForKey:strKey] ;//dsx-03-10 switch eng or chinese description
        }
        //SCRID:52
        //aded by caijunbo on 20110-12-25
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        //added end by caijunbo on 20110-12-25
        //SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WaitTime"])
        {
            mWaitTime = [dictKeyDefined objectForKey:strKey] ;
            intTime = [mWaitTime integerValue];
        }
        else if ([strKey isEqualToString:@"ShowNumber"])
        {
            mShowNumber = [dictKeyDefined objectForKey:strKey] ;
        }
        //SCRID:101 end
    }
    
    //Lucky add for cog bert test
    if ([[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] isEqualToString:@"FAIL"]) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"];
        return;
    }
    
    //SCRID:101 Modify parse "messageBox" to make messageBox button work after waiting some senconds by Helen 20110504.
    [UICommon setMessageBoxWaitTime:intTime];
    //SCRID:101 end.
    if (mButtons==nil ||
        mTitle==nil ||
        mMessage==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    
    // add by jack on 2011_03_09
    if([mDesc isEqualToString:@"CHI"])//dsx-03-10 SMT still use english
    {
        int a=[mMessage intValue];
        switch (a)
        {
            case 1:
                mMessage=@"请按所有按键！";
                break;
            case 2:
                mMessage=@"请插上治具线！";
                break;
            case 3:
                mMessage=@"俩个灯是否都亮了？";
                break;
            case 4:
                mMessage=@"俩个灯是否都关了？";
                break;
            case 5:
                mMessage=@"这个测项是否通过？";
                break;
            case 6:
                mMessage=@"请把磁铁放到磁铁感应区!";
                break;
            case 7:
                mMessage=@"请在机台上方来回移动障碍物！";
                break;
            case 8:
                mMessage=@"请按音量＋或音量－键来变换图片！";
                break;
            case 9:
                mMessage=@"测试完成并通过？";
                break;
            case 10:
                mMessage=@"后摄像头预映通过吗？";
                break;
            case 11:
                mMessage=@"前摄像头预映通过吗？";
                break;
            case 12:
                mMessage=@"请按下菜单键的两旁！";
                break;
            case 13:
                mMessage=@"请按下菜单键！";
                break;
            case 14:
                mMessage=@"请按下菜单键、電源鍵、靜音鍵！";
                break;
            case 15:
                mMessage=@"你准备好拔掉 Kong Cable 了吗？";
                break;
            case 16:
                mMessage=@"请把机台从治具中拿出来！";
                break;
            case 17:
                mMessage=@"请把机台放入治具中！";
                break;
            case 18:
                mMessage=@"请再接入 Kong Cable！";
                break;
            case 19://add by judith dry run 20130216 for mesa
                mMessage=@"请触摸菜单键！";
                break;
            case 20://Add by Lucky for cog bert test
                mMessage = @"画面是否少于四根线？";
                break;
            case 21:
                mMessage = @"请仔细检查以下几个画面！";
                break;
            case 22:
                mMessage = @"请按菜单键的右边！";
                break;
            case 23:
                mMessage = @"请按菜单键的下边！";
                break;
            case 24:
                mMessage = @"请按菜单键的左边！";
                break;
            case 25:
                mMessage = @"请按菜单键的上边！";
                break;
            case 26:
                mMessage = @"请按菜单键的中间！";
                break;
            case 27:
                mMessage = @"请打开電源！";
                break;
            case 28:
                mMessage = @"请關閉電源！";
                break;
            case 29:
                mMessage = @"请用手指感應Mesa！";
                break;
            case 100:
                mMessage = @"当OPAS测完后 再按‘是’按钮";
                break;
            default:
                mMessage=@"请检查测试脚本！有错误！";
                break;
        }
        //end  add by jack on 2011_03_09
    }
    
    NSString *strDutid = [dictKeyDefined objectForKey:@"DUTID"] ;
    /*
     NSTextField *textTestResult;
     [textTestResult setStringValue:@"No Unit"];
     [textTestResult setFont:[NSFont userFontOfSize:30]];
     [textTestResult setTextColor:[NSColor grayColor]] ;
     */
    if (strDutid!=nil)
    {
        /***********************************************************
         **SCRID:50  delete [1] when only show one UI **
         ***********************************************************/
        //		mTitle = [NSString stringWithFormat:@"[ %@ ]%@",strDutid,mTitle] ;
        mWinTitle = [mWinTitle stringByAppendingFormat:@" - %@ ",strDutid];
        /** SCRID:50 end**/
    }
    
    //Henry add for set Message Box position 20100914
    NSInteger totalUI;
    NSInteger indexOfDut = [strDutid intValue] ;
    NSString *strUISelected = [ScriptParse getValueFromSummary:STRKEYSWITCHUI];
    if([strUISelected isEqualToString:@"UI4"]||[strUISelected isEqualToString:@"UI4DP"])
        totalUI = 4 ;
    
    else if(([strUISelected isEqualToString:@"UI2"])||([strUISelected isEqualToString:@"UI2QT"]))
        totalUI = 2 ;
    
    else
        totalUI = 1 ;
    
    [UIAlert setInitPosition:totalUI index:indexOfDut] ;
    UIAlert *alert = [[[UIAlert alloc] init] autorelease];
    NSLock *lock = [[NSLock alloc] init];
    [lock lock];
    [alert showWindow:self];
    [lock unlock];
    [alert updatPosition:totalUI index:indexOfDut];
    
    if(totalUI != 1)
        [alert setWindowTitle:mWinTitle];
    
    
    /*
     NSAlert *alert = [[NSAlert alloc] init] autorelease];
     [alert setAlertStyle:NSInformationalAlertStyle];
     */
    
    [alert setMessageText:mMessage];
    [alert setInformativeText:mTitle];
    if ([mButtons isEqualToString:@"Yes|No"])
    {
        [alert addButtonWithTitle:@"是"];//change by jack on 2011_03_09
        [alert addButtonWithTitle:@"否"];//change by jack on 2011_03_09
    }else if ([mButtons isEqualToString:@"Ok|Cancel"])
    {
        [alert addButtonWithTitle:@"是"];//change by jack on 2011_03_09
        [alert addButtonWithTitle:@"否"];//change by jack on 2011_03_09
    }else if([mButtons isEqualToString:@"no need"])
    {
        
        NSLog(@"no need");
        NSInteger result = [alert runModalV2:dictKeyDefined];
        if(result == 0)
        {
            
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"timeout"] ;
        }else if (result == 1)
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"unknow error"];
        }
        //[alert release];
        return ;
        
    }
    else if([mButtons isEqualToString:@"Press Button"])//add by kevin for CG-Button
    {
        
        NSLog(@"no need");
        NSInteger result = [alert runModalV3:dictKeyDefined];
        if(result == 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"timeout"] ;
        }else if (result == 1)
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"unknow error"];
        }
        //[alert release];
        return ;
        
    }
    else
    {
        [alert addButtonWithTitle:@"是"];// change by jack on 2011_03_09
    }
    
    NSInteger result = [alert runModal];
    if(result == NSAlertFirstButtonReturn)
    {
        //SCRID:52
        //added by caijunbon on 2010-12-25
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined:mBufferName:@"PASS"];
        }
        //added end by caijunbo on 2010-12-25
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"Press Button [%@]",[mButtons isEqualToString:@"Yes|No"]?@"Yes":@"OK"]] ;
        if([mShowNumber boolValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"1"] ;
        }
    }else
    {
        
        //SCRID:52
        //added by caijunbon on 2010-12-25
        if (mBufferName!=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined:mBufferName:@"FAIL"];
        }
        
        //added end by caijunbo on 2010-12-25
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Press Button [%@]",[mButtons isEqualToString:@"Yes|No"]?@"No":@"Cancel"]] ;
        if([mShowNumber boolValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"0"] ;
        }
    }
    
    //[alert release];
    return ;
    
}
//Henry modified for Gatekeeper 20100609
+(void)ParseStrWithControlBit:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfoGK ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mResultBuf =@"";
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	mResultBuf = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
													:mPrefix Postfix
													:mPostfix] ;
	
	mResultBuf = [ToolFun getStrFromPrefixAndPostfix:mResultBuf Prefix
													:mPrefix Postfix
													:nil] ;
	mResultBuf = [ToolFun allTrimFromString:mResultBuf trimStr:@" " leftTrim:TRUE rightTrim:TRUE] ;
	if (mResultBuf!=nil)
	{
		// Remove the characters of "0x"
		NSUInteger locationIndexOf0X = -1;
		NSUInteger LenthWithPrefixOX = 0;
		NSRange rangeTmp =[mResultBuf rangeOfString:@"0x"];
		locationIndexOf0X = rangeTmp.location;
		LenthWithPrefixOX = rangeTmp.length;
		if ( locationIndexOf0X >= 0 )
		{
			mResultBuf = [ToolFun deleteFromString:mResultBuf trimStr:@"0x"] ; 
			mResultBuf = [ToolFun allTrimFromString:mResultBuf trimStr:@" " leftTrim:true rightTrim:true] ;
		}
		
		NSString *temResulStr = nil;
		NSString *temFailCntStr = nil;
		NSString *temFailTimeStr = nil;
		temResulStr =[mResultBuf substringWithRange:NSMakeRange(0, 1)];
		temFailCntStr =[mResultBuf substringWithRange:NSMakeRange(1, 1)];
		if([temFailCntStr isEqualToString:@"6"])
		{
			temFailTimeStr = @"1 times";
		}
		else if([temFailCntStr isEqualToString:@"4"])
		{
			temFailTimeStr = @"2 times";
		}	
		else if([temFailCntStr isEqualToString:@"0"])
		{
			temFailTimeStr = @"3 times";
		}
		else if([temFailCntStr isEqualToString:@"3"])
		{
			temFailTimeStr = @"4 times";
		}	
		else if([temFailCntStr isEqualToString:@"1"])
		{
			temFailTimeStr = @"5 times";
		}
		else if([temFailCntStr isEqualToString:@"5"])
		{
			temFailTimeStr = @"6 times";
		}	
		else if([temFailCntStr isEqualToString:@"2"])
		{
			temFailTimeStr = @"7 times";
		}
		else
		{
			temFailTimeStr = @"0 times";
		}
		
		if([temResulStr isEqualToString:@"0"])
		{
			enumResult = RESULT_FOR_PASS;
			strTestResultForUIinfo = @"Pass";
			strTestResultForUIinfoGK = @"Pass";
			NSString *temStrAppend1 = @"[ FAIL ";
			NSString *temStrAppend2 = @" ]";
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temStrAppend1];
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temFailTimeStr];
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temStrAppend2];
			/*SCRID-74: More than 5 times failure will fail in CB Check, joko add 2011-02-09*/
			/* dsx 03-30 no fail count limits for POLO
             if([temFailCntStr isEqualToString:@"5"] || [temFailCntStr isEqualToString:@"2"])
             {
             enumResult = RESULT_FOR_FAIL;
             strTestResultForUIinfo=@"Failure Count:";
             if([temFailCntStr isEqualToString:@"5"])
             strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:@"6, more than 5 times Failure will FAIL, but last time test PASS"];
             else
             strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:@"7, more than 5 times Failure will FAIL, but last time test PASS"];
             }*/
			/*SCRID-74: end*/
		}
		else if([temResulStr isEqualToString:@"2"])
		{
			enumResult = RESULT_FOR_FAIL;
			strTestResultForUIinfo = @"Fail";
			strTestResultForUIinfoGK = @"Fail";
			NSString *temStrAppend1 = @"[ FAIL ";
			NSString *temStrAppend2 = @" ]";
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temStrAppend1];
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temFailTimeStr];
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:temStrAppend2];
		}
		else if([temResulStr isEqualToString:@"1"])
		{
			enumResult = RESULT_FOR_FAIL;
			strTestResultForUIinfo = @"InCompleteTest";
			strTestResultForUIinfoGK = @"InCompleteTest";
		}
		else if([temResulStr isEqualToString:@"3"])
		{
			enumResult = RESULT_FOR_FAIL;
			strTestResultForUIinfo = @"NoTest";
			strTestResultForUIinfoGK = @"NoTest";
		}
		NSString *strStationID=[ScriptParse getValueFromSummary:@"TestStation"] ;
		if (strStationID ==nil)
			strStationID = @"no station ID exist !" ;
		
		if([strStationID isEqualToString:@"GateKeeper"] )
		{
			NSString *subItem1 = [mTestItemName stringByAppendingString:@"Status :"];
			NSString *subItem2 = [mTestItemName stringByAppendingString:@"Failure Count :"];
			temFailTimeStr = [temFailTimeStr substringWithRange:NSMakeRange(0, 1)];
			[TestItemManage setSubItemPDCAInfo:dictKeyDefined 
                                              :subItem1 
                                              :nil 
                                              :nil 
                                              :nil 
                                              :temResulStr 
                                              :nil 
                                              :IP_NA 
                                              :nil];
			[TestItemManage setSubItemPDCAInfo:dictKeyDefined 
                                              :subItem2 
                                              :nil 
                                              :nil 
                                              :nil 
                                              :temFailTimeStr 
                                              :nil 
                                              :IP_NA 
                                              :nil];
		}
		
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

+(void)ParseMultiSpecStrPostfixWithConditions:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mStrSpecPostfix=nil ;
	NSString *mStrSpecPrefix =nil      ;
	NSString *mReferenceBufferName=nil ;
	NSString *mMultiSpecStr=nil;
	NSString *mProject=nil;
	BOOL mIsContainSpecStr = TRUE;
	BOOL bFlag = FALSE;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSArray *mArraySpecPrefix =nil ;
	NSArray *mArraySpecPostfix =nil ;
	NSArray *mArrayMultiSpecStr =nil ;
	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Project"])
		{
			mProject = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"IsContainSpecStr"])
		{
			mIsContainSpecStr = [[dictKeyDefined objectForKey:strKey] boolValue];
		}else if ([strKey isEqualToString:@"MultiSpecStr"])
		{
			mMultiSpecStr = [dictKeyDefined objectForKey:strKey] ;
			mArrayMultiSpecStr =[mMultiSpecStr componentsSeparatedByString:@","];
		}else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"SpecPrefix"])
		{
			mStrSpecPrefix = [dictKeyDefined objectForKey:strKey] ;
			mArraySpecPrefix =[mStrSpecPrefix componentsSeparatedByString:@"|"];
		}else if ([strKey isEqualToString:@"SpecPostfix"])
		{
			mStrSpecPostfix = [dictKeyDefined objectForKey:strKey] ;
			mArraySpecPostfix =[mStrSpecPostfix componentsSeparatedByString:@"|"];
		}
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strBuffer = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
															 :mPrefix Postfix
															 :mPostfix] ;
	if (strBuffer==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	else
	{
		bFlag = TRUE;
	}
	
	strBuffer = [ToolFun allTrimFromString:strBuffer trimStr:@" " leftTrim:true rightTrim:true] ;
	strBuffer = [ToolFun deleteFromString:strBuffer trimStr:@"\r"] ; 
	strBuffer = [ToolFun deleteFromString:strBuffer trimStr:@"\n"] ; 
	strBuffer = [ToolFun deleteFromString:strBuffer trimStr:@"\t"] ; 
	strBuffer = [ToolFun deleteFromString:strBuffer trimStr:@" "] ; 
	
	NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
	NSString *strSN_Sub = @"";
	NSString *strHwConfig = @"";
	
	if([strSN length] > 3)
	{
		strSN_Sub =[strSN substringWithRange:NSMakeRange([strSN length]-3, 3)];
	}
	
	strHwConfig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];
	if(![[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
	{
		strHwConfig = @"UMTS ";//just for dry run.
	}
	if([strHwConfig length]<=0)
	{
		enumResult =RESULT_FOR_FAIL;
		strTestResultForUIinfo = @"No this HWConfig in HWconfig.properties";
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
		return;
	}
	
	BOOL isUnitK48M =FALSE;
	BOOL isUnitContain = FALSE;
	
	NSRange temRange1 =[strHwConfig rangeOfString:@"GPS"];
	NSRange temRange2 =[strHwConfig rangeOfString:@"UMTS"];
    //	NSInteger temLocation = -1;
	if((temRange1.length > 0)||(temRange2.length > 0))
		isUnitK48M = TRUE;
	for(int i=0;i<[mArrayMultiSpecStr count];i++)
	{
		NSString *strSpecTemp = [mArrayMultiSpecStr objectAtIndex:i];
		strSpecTemp = [ToolFun deleteFromString:strSpecTemp trimStr:@" "] ; 
		NSRange temRange3 = [mReferenceBufferValue rangeOfString:strSpecTemp];
		if(temRange3.length > 0)
		{
			isUnitContain = TRUE;
			break;
		}
	}
	
	if(!bFlag)
	{
		enumResult =RESULT_FOR_FAIL;
		strTestResultForUIinfo = @"Get String between Prefix and Postfix  Fail !";
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
		return;
	}
	
	BOOL bContainStangeStr = FALSE;
	BOOL bContainErrorMsg = FALSE;
	NSString *letterAndNumber = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	if([mTestItemName rangeOfString:@"Button"].length > 0 || [mTestItemName rangeOfString:@"button"].length > 0)
		letterAndNumber = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ:-),.";
	
	for(int i=0;i<[strBuffer length];i++)
	{
		NSString *strAb = [strBuffer substringWithRange:NSMakeRange(i,1)];
		if([letterAndNumber rangeOfString:strAb].length <= 0)
		{
			bContainStangeStr = TRUE;
			break;
		}
	}
	
	if([mTestItemName rangeOfString:@"Button"].length > 0 || [mTestItemName rangeOfString:@"button"].length > 0)
	{
		if([strBuffer rangeOfString:@"ERROR"].length > 0 || [strBuffer rangeOfString:@"Error"].length > 0 || [strBuffer rangeOfString:@"erron"].length > 0) 
			bContainErrorMsg = TRUE;
	}
	else
	{
		if(([strBuffer rangeOfString:@"ERROR"].length > 0)||([strBuffer rangeOfString:@"Error"].length > 0)
		   ||([strBuffer rangeOfString:@"error"].length > 0)||([strBuffer rangeOfString:@"FAIL"].length > 0)
		   ||([strBuffer rangeOfString:@"Fail"].length > 0)||([strBuffer rangeOfString:@"fail"].length > 0))
			bContainErrorMsg = TRUE;
	}
	
	int len = [strBuffer length];
	
	if([mProject rangeOfString:@"K48M"].length > 0 )
	{
		if(isUnitK48M)
		{
			if((mIsContainSpecStr && isUnitContain) || (!mIsContainSpecStr && !isUnitContain))
			{
				if(bContainStangeStr || bContainErrorMsg || len< 1)
				{
					enumResult =RESULT_FOR_FAIL;
					strTestResultForUIinfo = mReferenceBufferValue;
				}
				else
				{
					enumResult =RESULT_FOR_PASS;
					strTestResultForUIinfo = mReferenceBufferValue;
				}
			}
			else
			{
				enumResult =RESULT_FOR_FAIL;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
		}
		else
		{
			if(bContainStangeStr || bContainErrorMsg || len< 1)
			{
				enumResult =RESULT_FOR_FAIL;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
			else
			{
				enumResult =RESULT_FOR_PASS;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
		}
	}
	else if([mProject rangeOfString:@"K48"].length > 0)
	{
		if(!isUnitK48M)
		{
			if((mIsContainSpecStr && isUnitContain) || (!mIsContainSpecStr && !isUnitContain))
			{
				if(bContainStangeStr || bContainErrorMsg || len< 1)
				{
					enumResult =RESULT_FOR_FAIL;
					strTestResultForUIinfo = mReferenceBufferValue;
				}
				else
				{
					enumResult =RESULT_FOR_PASS;
					strTestResultForUIinfo = mReferenceBufferValue;
				}
			}
			else
			{
				enumResult =RESULT_FOR_FAIL;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
		}
		else
		{
			if(bContainStangeStr || bContainErrorMsg || len< 1)
			{
				enumResult =RESULT_FOR_FAIL;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
			else
			{
				enumResult =RESULT_FOR_PASS;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
		}
	}
	else
	{
		if((mIsContainSpecStr && isUnitContain) || (!mIsContainSpecStr && !isUnitContain))
		{
			if(bContainStangeStr || bContainErrorMsg || len< 1)
			{
				enumResult =RESULT_FOR_FAIL;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
			else
			{
				enumResult =RESULT_FOR_PASS;
				strTestResultForUIinfo = mReferenceBufferValue;
			}
		}
		else
		{
			enumResult =RESULT_FOR_FAIL;
			strTestResultForUIinfo = mReferenceBufferValue;
		}
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}


+ (void)ParseSendCommandToComputer:(NSDictionary*)dictKeyDefined
{
	NSString *mWriteCmdToPC = nil;
	
	for(int i = 0; i < [dictKeyDefined count]; i++)
	{
		NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"WriteCmdToPC"])
		{
			mWriteCmdToPC = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if([mWriteCmdToPC rangeOfString:@"vbus 0"].length > 0)
	{
		NSString *usbCommand=@"/usr/local/bin/astrisctl --host usb relay vbus 0";///usr/local/bin/
		system([usbCommand UTF8String]);
	}
	else
	{
		NSString *usbCommand1=@"/usr/local/bin/astrisctl --host usb relay vbus 1";
		system([usbCommand1 UTF8String]);
		sleep(2);
	}	
}

+ (void)ParseControlUSBBySendCommandToComputer:(NSDictionary*)dictKeyDefined
{
	NSString *mWriteCmdToPC = nil;
	
	for(int i = 0; i < [dictKeyDefined count]; i++)
	{
		NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"WriteCmdToPC"])
		{
			mWriteCmdToPC = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if([mWriteCmdToPC rangeOfString:@"KongSWD"].length > 0)
	{
		NSArray *mSerialPort = [UartComm ScanKongCable];
		for(int j=0;j < [mSerialPort count];j++)
		{
			NSString *currenPort = [mSerialPort objectAtIndex:j];	
			NSString* mSerialNum = [ToolFun getStrFromPrefixAndPostfix:currenPort Prefix:@"kong-" Postfix:nil];
			NSMutableString *mutStrTmp = [NSMutableString stringWithString:mWriteCmdToPC];
			[mutStrTmp replaceOccurrencesOfString:@"serialnum" withString:mSerialNum options:NSBackwardsSearch range:NSMakeRange(0, [mutStrTmp length])];
			system([mutStrTmp UTF8String]);
			sleep(2);
		}
	}
	else
	{
		system([mWriteCmdToPC UTF8String]);
		sleep(2);
	}
	//	if([mWriteCmdToPC rangeOfString:@"vbus 0"].length > 0)
	//	{
	//		NSString *usbCommand=@"/usr/local/bin/astrisctl --host KongSWD-serialnum relay vbus 0";///usr/local/bin/
	//		NSString* mSerialPort = [self getCurrUnitDeviceName:dictKeyDefined] ;
	//		NSString* mSerialNum = [ToolFun getStrFromPrefixAndPostfix:mSerialPort Prefix:@"kong-" Postfix:nil];
	//		
	//		NSMutableString *mutStrTmp = [NSMutableString stringWithString:usbCommand];
	//		[mutStrTmp replaceOccurrencesOfString:@"serialnum" withString:mSerialNum options:NSBackwardsSearch range:NSMakeRange(0, [mutStrTmp length])];
	//		
	//		NSLog(@"mSerialPort is %@\n",mSerialPort);
	//		NSLog(@"mSerialNum is %@\n",mSerialNum);
	//		NSLog(@"strPra is %@\n",mutStrTmp);
	//		
	//		system([mutStrTmp UTF8String]);
	//	}
	//	else
	//	{
	//		NSString *usbCommand1=@"/usr/local/bin/astrisctl --host usb relay vbus 1";
	//		system([usbCommand1 UTF8String]);
	//		sleep(2);
	//	}	
}
+(void)RS232WriteAndReadStrEnterDiags:(NSDictionary*)dictKeyDefined
{
    //key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd	
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
    NSString *mStrSpec = nil;
    
    int mRetestTimes = 1;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReTimes"])
		{
			mRetestTimes = [[dictKeyDefined objectForKey:strKey]intValue] ;
		}else if ([strKey isEqualToString:@"StrSpec"])
        {
            mStrSpec = [dictKeyDefined objectForKey:strKey] ;
        }
        
	}
    if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	
	//modified by caijunbo on 2011-03-06 used for Mikey 2.0
	if (mWriteCmdEnd!=nil)
        [strMutSendBuffer appendString:mWriteCmdEnd] ;
    for(int i = 0;i < mRetestTimes;i++)
    {
        bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
        usleep(5000000);
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        NSRange range = [dataResult rangeOfString:mStrSpec];
        if(range.length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
            return ;  
        }
    }
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmdEnd :mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send \n fail "] ;
        return ;
    }
    usleep(100000) ; //delay 100ms
    NSString *dataResult = [self ReceData:dictKeyDefined] ;
    NSRange range = [dataResult rangeOfString:@"]"];
    if(range.length > 0)
    {
        [self SendData:dictKeyDefined :@"diags" :mPostfix] ;
        usleep(100000) ; //delay 100ms
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        if([dataResult rangeOfString:mStrSpec].length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
            return ;  
        }
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
    
}
//add by judith 2012-05-29
+(void) RS485ReadSnMotor: (NSDictionary *)dictKeyDefined
{
    NSArray *mSerialPort = [UartComm ScanPort];
    for(int j=0;j < [mSerialPort count];j++)
    {
        NSString *currenPort = [mSerialPort objectAtIndex:j];
		NSLog(@"currenPort = %@",currenPort);
        
        NSString *tmpMagnetHallS = [ScriptParse getValueFromSummary:@"TestStation"];
        NSString *tmp = @"-mh1-";
        if([tmpMagnetHallS rangeOfString:@"Magnet-Hall"].length > 0)
            tmp = @"DATA2";
        
        NSRange range = [currenPort rangeOfString:tmp];
        if([currenPort rangeOfString:tmp].length > 0)
        {
            int sn = [[currenPort substringFromIndex:range.location+range.length] intValue];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",sn]] ;
            return;
        }
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Not Found the Motor"] ;
    return;
}
+(NSString *) dataToString: (NSData *) _data
{
    
    NSMutableString *pStr =[[[NSMutableString alloc] initWithCapacity: 1] autorelease];
    
    UInt8 *p = (UInt8*) [_data bytes];
    int len = [_data length];
    
    for(int i = 0; i < len; i ++)
    {
        [pStr appendFormat:@"%02X", *(p+i)];
    }
    
    return pStr;
}
//end add 2012-05-29

+(void)ParseCheckUnitProcess: (NSDictionary *)dictKeyDefined   //Rick add for check the unit process 2013-02-27
{
    NSString *mTestItemName = nil;
    NSString *mReferenceBufferName = nil;
    NSString *mPrefix = @"0 SFC_OK";
    NSString *mPostfix = nil;
    //NSString *mTestStation = [ScriptParse getValueFromSummary:@"TestStation"];
    
    
//    add by justin 20131116 start...
    NSString *sfcInfo=[NSString stringWithContentsOfFile:@"/vault/data_collection/test_station_config/gh_station_info.json" encoding:NSASCIIStringEncoding error:nil] ;
    if(!sfcInfo)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Get stationInfor fail"] ;
        return;
    }
//     json file to judge Groundhog server Bobcat set status is on or off  if on then implement unit process check,else if   off then by pass the test immediately
//    json file:
//    "SFC_QUERY_UNIT_ON_OFF" : "ON",------Groundhog server Bobcat set is on
//    "SFC_QUERY_UNIT_ON_OFF" : "OFF",-----Groundhog server Bobcat set is off
    NSRange rangSFCOFF = [sfcInfo rangeOfString:@"\"SFC_QUERY_UNIT_ON_OFF\" : \"OFF\""];
    if (rangSFCOFF.length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"By Pass!"] ;
        return;
    }
//    add end...
    
    
    int DUIID = [[dictKeyDefined objectForKey:@"DUTID"] intValue];
    NSString *mWritecmd = nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        
        
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Writecmd"])
		{
			mWritecmd = [dictKeyDefined objectForKey:strKey] ;
		}
    }
    
    if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
    NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	
    if (strFind==nil)
	{
		//	NSLog(@"%@",mReferenceBufferValue) ;
		//[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no valid data"] ;
	    return  ;
	}
    
    NSArray *writeCmd = nil;
    if(mWritecmd != nil)
    {
        writeCmd = [mWritecmd componentsSeparatedByString:@","];
    }
    
    if([strFind rangeOfString:@"OK"].length > 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
	    return  ;
    }
    else if([strFind rangeOfString:@"Goto different"].length > 0)
    {
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"機台測試失敗次數達到兩次，請把機台拿到其他同類工站測試"] ;
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UNIT OUT OF PROCESS  FAIL COUNT OVER 2 TIMES,TAKE THE UNIT TO OTHER SIMILAR STATION"] ;//UNIT OUT OF PROCESS Over fail count. Goto FA-CHECK-IN.
        NSString *failStr=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"check=" Postfix:@"\n" ];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failStr] ;
        if(writeCmd != nil)
        {
            [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
            for (int i = 0; i < [writeCmd count]; i++)
            {
                NSString *tempCmd = [writeCmd objectAtIndex:i];
                tempCmd = [tempCmd stringByAppendingString:@"\r\n"];
                [self SendData:dictKeyDefined :tempCmd :@"*_*"] ;
                NSDate *dateTmp=[[NSDate alloc] init] ;
                
                int timeInterval = - [dateTmp timeIntervalSinceNow] ;
                while (timeInterval<=3)
                {
                    timeInterval = -[dateTmp timeIntervalSinceNow] ;
                    
                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                        break ;
                    else
                    {
                        usleep(100000) ; //delay 100ms
                    }
                }
                [dateTmp release];
                [self ReceData:dictKeyDefined] ;
            }
            
        }
        
        
        //[UIWinManage stopTest:DUIID] ;
	    return  ;
    }
    else if([strFind rangeOfString:@"Over fail count"].length > 0)
    {
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"機台測試失敗次數超過四次，請把幾台拿到FA-CHECK-IN"] ;
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"UNIT OUT OF PROCESS Over fail count. Goto FA-CHECK-IN."] ;
         NSString *failStr=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"check=" Postfix:@"\n" ];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failStr] ;
        if(writeCmd != nil)
        {
            [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
            for (int i = 0; i < [writeCmd count]; i++)
            {
                NSString *tempCmd = [writeCmd objectAtIndex:i];
                tempCmd = [tempCmd stringByAppendingString:@"\r\n"];
                [self SendData:dictKeyDefined :tempCmd :@"*_*"] ;
                NSDate *dateTmp=[[NSDate alloc] init] ;
                
                int timeInterval = - [dateTmp timeIntervalSinceNow] ;
                while (timeInterval<=3)
                {
                    timeInterval = -[dateTmp timeIntervalSinceNow] ;
                    
                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                        break ;
                    else
                    {
                        usleep(100000) ; //delay 100ms
                    }
                }
                [dateTmp release];
                [self ReceData:dictKeyDefined] ;
            }
            
        }
        //[UIWinManage stopTest:DUIID] ;
	    return  ;
    }
    else
    {
//        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SFC return change"] ;
        NSString *failStr=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"check=" Postfix:@"\n" ];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :failStr] ;
                
        if(writeCmd != nil)
        {
            [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
            for (int i = 0; i < [writeCmd count]; i++)
            {
                NSString *tempCmd = [writeCmd objectAtIndex:i];
                tempCmd = [tempCmd stringByAppendingString:@"\r\n"];
                [self SendData:dictKeyDefined :tempCmd :@"*_*"] ;
                NSDate *dateTmp=[[NSDate alloc] init] ;
                
                int timeInterval = - [dateTmp timeIntervalSinceNow] ;
                while (timeInterval<=3)
                {
                    timeInterval = -[dateTmp timeIntervalSinceNow] ;
                    
                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                        break ;
                    else
                    {
                        usleep(100000) ; //delay 100ms
                    }
                }
                [dateTmp release];
                [self ReceData:dictKeyDefined] ;
            }
            
        }
        //[UIWinManage stopTest:DUIID] ;
	    return  ;
    }
    
}

+(void)RS232WriteAndReadStrAICI:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;
    
    
	
	NSString *mBufferName=nil    ;
    
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	
	NSString *mReferenceBufferName=nil     ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    
    NSString *ReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    ReferenceBufferValue = [ReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    ReferenceBufferValue = [ReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    ReferenceBufferValue = [ReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    ReferenceBufferValue = [ReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    NSArray * mutArrayTemp = [ReferenceBufferValue componentsSeparatedByString:@"0x"];
    
    if([mutArrayTemp count] >= 3)
    {
        mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
        mWriteCmd = [mWriteCmd stringByAppendingString:@"0x"];
        mWriteCmd = [mWriteCmd stringByAppendingString:[mutArrayTemp objectAtIndex:1]];
        
        mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
        mWriteCmd = [mWriteCmd stringByAppendingString:@"0x"];
        mWriteCmd = [mWriteCmd stringByAppendingString:[mutArrayTemp objectAtIndex:2]];
        
        mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
        mWriteCmd = [mWriteCmd stringByAppendingString:@"0x000001F4"];
        
        mWriteCmd = [mWriteCmd stringByAppendingString:@" "];
        mWriteCmd = [mWriteCmd stringByAppendingString:@"0x"];
        mWriteCmd = [mWriteCmd stringByAppendingString:[mutArrayTemp objectAtIndex:4]];
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"AICl still don't has value"] ;
		return ; 
    }
    
	mWriteCmd = [mWriteCmd stringByAppendingString:mWriteCmdEnd];
	
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :@":-)"] ;
    
    
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    
    
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined]) 
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *dataResult = [self ReceData:dictKeyDefined] ;
    
    
    if (dataResult==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
        return ;
    }
    
    
    if (mBufferName !=nil)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        return ;
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
    return ;
	
}
//Add by justin 2015-1-01-17 start
+(void)RS232WriteAndReadStrOnlyForMac:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mDevice=nil        ;
	NSString *mWriteCmd=nil      ;// write cmd
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
	//SCRID:90 2011-03-21 Henry modify end
    
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mReplaceColonWithSemicolon=nil     ;
	NSString *mReferenceBufferName=nil     ;
    NSString *mReferenceBufferName1=nil     ;
    NSString *mFixtureType=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
		else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
			//NSLog(@"\n length =%d ,%@ \n",[mWriteCmd length],mWriteCmd);
		}else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
		//SCRID:90 2011-03-21 Henry modify end
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReplaceColonWithSemicolon"])
		{
			mReplaceColonWithSemicolon = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName1"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName1= [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"FixtureType"])  //add by kevin for QT0a.20140811
		{
			mFixtureType= [dictKeyDefined objectForKey:strKey] ;
		}
	}
	//SCRID:90 2011-03-21 Henry modify for QT0b new fixture
	NSString *strDUTID = [dictKeyDefined objectForKey:@"DUTID"] ;
	if(mWriteCmdTmp2 != nil)
		mWriteCmd =([strDUTID isEqualToString:@"2"])?mWriteCmdTmp2:mWriteCmdTmp1;
	else
		mWriteCmd =mWriteCmdTmp1;
	//SCRID:90 2011-03-21 Henry modify end
	
	if (mDevice==nil ||
		mWriteCmd==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	//battery sn check sum
	if([mWriteCmd isEqualToString:@"batdev -w -g 0x60 -d <CHECKSUM VALUE>"])
	{
		NSString *BufferValue = [TestItemManage getBufferValue:dictKeyDefined :@"batSNCheckSumXYZ"] ;
		mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"<CHECKSUM VALUE>" withString:BufferValue];
	}
    
    
	//SCRID-139: Write Unit SN to Clean All FATP CB in FA. joko 2011-10-21
	if([mWriteCmd isEqualToString:@"Clean All FATP CB"])
	{
		NSString *sN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
		mWriteCmd = @"sn ";
		mWriteCmd = [mWriteCmd stringByAppendingString:sN];
	}
    else if([mWriteCmd isEqualToString:@"sleep -h"] || [mWriteCmd isEqualToString:@"sleep --h"] || [mWriteCmd isEqualToString:@"device -k GasGauge -e disconnect_bat"])
    {
		if(![TestItemManage checkPriorAllTestItemResult:dictKeyDefined])
		{
			mWriteCmd = @"sn";
		}
    }
	//SCRID-139: end
    
    if ([mWriteCmd isEqualToString:@"syscfg add WMac 0xBABABABA 0x0000BABA 0x00000000 0x00000000"])
    {
        NSString *mReferenceBufferNameValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
        if (mReferenceBufferNameValue1 == nil) {
            mReferenceBufferNameValue1 = @"0xBABABABA 0x0000BABA 0x00000000 0x00000000";
        }
        
        NSString *mMacAdrrStrFromUnit = nil;
        NSString *mExsitMacAddrStr = nil;
        if (mReferenceBufferNameValue1 !=nil)
        {
            mMacAdrrStrFromUnit = [mReferenceBufferNameValue1 stringByReplacingOccurrencesOfString:@"0x00000000 0x00000000" withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@"0x" withString:@""];
            NSString *tmpAddrStr1 = [mMacAdrrStrFromUnit substringToIndex:8];
            NSString *tmpAddrStr2 = [mMacAdrrStrFromUnit substringFromIndex:12];
            mExsitMacAddrStr = [tmpAddrStr2 stringByAppendingString:tmpAddrStr1];
        }
        
        NSString *mWmacFilePath = [NSHomeDirectory() stringByAppendingString:@"/WMacAddress.txt"];
        NSString *mMutWMacStr = [NSMutableString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding error:nil];
        
        if ( [mMutWMacStr rangeOfString:mExsitMacAddrStr].length < 1)
        {
            NSString *tempstr = [mMutWMacStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\t" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\n" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\r" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";;" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";" withString:@";\n"];
            
            NSArray *mWMacArr = [tempstr componentsSeparatedByString:@";\n"];
            int macAddrCurrent = [mWMacArr count]-1;
            NSLog(@"%@",[mWMacArr objectAtIndex:macAddrCurrent]);
            if ([[mWMacArr objectAtIndex:macAddrCurrent] intValue] <= ([mWMacArr count]-2))
            {
                NSString *currentOrderStr= [mWMacArr objectAtIndex:macAddrCurrent];
                NSString *newOrderStr =[NSString stringWithFormat:@"%d" ,([currentOrderStr intValue]+1)];
                newOrderStr = [@";\n" stringByAppendingString:newOrderStr];
                NSString *asdd =[@";\n" stringByAppendingString:currentOrderStr] ;
                NSRange newOrder = [mMutWMacStr rangeOfString:asdd];
                if (newOrder.length>0)
                {
                    tempstr = [tempstr stringByReplacingOccurrencesOfString:asdd withString:newOrderStr];
                }
                
                FILE *fp;
                fp = fopen([mWmacFilePath UTF8String], "wr");
                fclose(fp);
                
                NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:mWmacFilePath];
                
                [NSString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding  error:nil];
                if (filehandTmp!=nil)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[tempstr dataUsingEncoding:NSASCIIStringEncoding]] ];
                    [filehandTmp closeFile] ;
                }
                
                NSString *currentUseAddr = [mWMacArr objectAtIndex:[currentOrderStr intValue]];
                NSString *tmpAddrStr1 = [currentUseAddr substringFromIndex:4];
                tmpAddrStr1 =[@"0x" stringByAppendingString: tmpAddrStr1];
                NSString *tmpAddrStr2 = [currentUseAddr substringToIndex:4];
                tmpAddrStr2 =[@"0x0000" stringByAppendingString: tmpAddrStr2];
                
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0xBABABABA" withString:tmpAddrStr1];
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0x0000BABA" withString:tmpAddrStr2];
            }
        }
        else if ([mMutWMacStr rangeOfString:mExsitMacAddrStr].length > 1)
        {
            mWriteCmd = [@"syscfg add WMac " stringByAppendingString:mReferenceBufferNameValue1];
        }
    }
    if ([mWriteCmd isEqualToString:@"syscfg add BMac 0xBABABABA 0x0000BABA 0x00000000 0x00000000"])
    {
        NSString *mReferenceBufferNameValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
        if (mReferenceBufferNameValue1 == nil) {
            mReferenceBufferNameValue1 = @"0xBABABABA 0x0000BABA 0x00000000 0x00000000";
        }
        
        NSString *mMacAdrrStrFromUnit = nil;
        NSString *mExsitMacAddrStr = nil;
        if (mReferenceBufferNameValue1 !=nil)
        {
            mMacAdrrStrFromUnit = [mReferenceBufferNameValue1 stringByReplacingOccurrencesOfString:@"0x00000000 0x00000000" withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@"0x" withString:@""];
            NSString *tmpAddrStr1 = [mMacAdrrStrFromUnit substringToIndex:8];
            NSString *tmpAddrStr2 = [mMacAdrrStrFromUnit substringFromIndex:12];
            mExsitMacAddrStr = [tmpAddrStr2 stringByAppendingString:tmpAddrStr1];
        }
        
        NSString *mWmacFilePath = [NSHomeDirectory() stringByAppendingString:@"/BMacAddress.txt"];
        NSString *mMutWMacStr = [NSMutableString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding error:nil];
        
        if ( [mMutWMacStr rangeOfString:mExsitMacAddrStr].length < 1)
        {
            NSString *tempstr = [mMutWMacStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\t" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\n" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\r" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";;" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";" withString:@";\n"];
            
            NSArray *mWMacArr = [tempstr componentsSeparatedByString:@";\n"];
            int macAddrCurrent = [mWMacArr count]-1;
            NSLog(@"%@",[mWMacArr objectAtIndex:macAddrCurrent]);
            if ([[mWMacArr objectAtIndex:macAddrCurrent] intValue] <= ([mWMacArr count]-2))
            {
                NSString *currentOrderStr= [mWMacArr objectAtIndex:macAddrCurrent];
                NSString *newOrderStr =[NSString stringWithFormat:@"%d" ,([currentOrderStr intValue]+1)];
                newOrderStr = [@";\n" stringByAppendingString:newOrderStr];
                NSString *asdd =[@";\n" stringByAppendingString:currentOrderStr] ;
                NSRange newOrder = [mMutWMacStr rangeOfString:asdd];
                if (newOrder.length>0)
                {
                    tempstr = [tempstr stringByReplacingOccurrencesOfString:asdd withString:newOrderStr];
                }
                
                FILE *fp;
                fp = fopen([mWmacFilePath UTF8String], "wr");
                fclose(fp);
                
                NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:mWmacFilePath];
                
                [NSString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding  error:nil];
                if (filehandTmp!=nil)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[tempstr dataUsingEncoding:NSASCIIStringEncoding]] ];
                    [filehandTmp closeFile] ;
                }
                
                NSString *currentUseAddr = [mWMacArr objectAtIndex:[currentOrderStr intValue]];
                NSString *tmpAddrStr1 = [currentUseAddr substringFromIndex:4];
                tmpAddrStr1 =[@"0x" stringByAppendingString: tmpAddrStr1];
                NSString *tmpAddrStr2 = [currentUseAddr substringToIndex:4];
                tmpAddrStr2 =[@"0x0000" stringByAppendingString: tmpAddrStr2];
                
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0xBABABABA" withString:tmpAddrStr1];
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0x0000BABA" withString:tmpAddrStr2];
            }
        }
        else if ([mMutWMacStr rangeOfString:mExsitMacAddrStr].length > 1)
        {
            mWriteCmd = [@"syscfg add BMac " stringByAppendingString:mReferenceBufferNameValue1];
        }
    }
    if ([mWriteCmd isEqualToString:@"syscfg add EMac 0xBABABABA 0x0000BABA 0x00000000 0x00000000"])
    {
        NSString *mReferenceBufferNameValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
        if (mReferenceBufferNameValue1 == nil) {
            mReferenceBufferNameValue1 = @"0xBABABABA 0x0000BABA 0x00000000 0x00000000";
        }
        
        NSString *mMacAdrrStrFromUnit = nil;
        NSString *mExsitMacAddrStr = nil;
        if (mReferenceBufferNameValue1 !=nil)
        {
            mMacAdrrStrFromUnit = [mReferenceBufferNameValue1 stringByReplacingOccurrencesOfString:@"0x00000000 0x00000000" withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@" " withString:@""];
            mMacAdrrStrFromUnit = [mMacAdrrStrFromUnit stringByReplacingOccurrencesOfString:@"0x" withString:@""];
            NSString *tmpAddrStr1 = [mMacAdrrStrFromUnit substringToIndex:8];
            NSString *tmpAddrStr2 = [mMacAdrrStrFromUnit substringFromIndex:12];
            mExsitMacAddrStr = [tmpAddrStr2 stringByAppendingString:tmpAddrStr1];
        }
        
        NSString *mWmacFilePath = [NSHomeDirectory() stringByAppendingString:@"/EMacAddress.txt"];
        NSString *mMutWMacStr = [NSMutableString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding error:nil];
        
        if ( [mMutWMacStr rangeOfString:mExsitMacAddrStr].length < 1)
        {
            NSString *tempstr = [mMutWMacStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\t" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\n" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@"\r" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";;" withString:@";"];
            tempstr = [tempstr stringByReplacingOccurrencesOfString:@";" withString:@";\n"];
            
            NSArray *mWMacArr = [tempstr componentsSeparatedByString:@";\n"];
            int macAddrCurrent = [mWMacArr count]-1;
            NSLog(@"%@",[mWMacArr objectAtIndex:macAddrCurrent]);
            if ([[mWMacArr objectAtIndex:macAddrCurrent] intValue] <= ([mWMacArr count]-2))
            {
                NSString *currentOrderStr= [mWMacArr objectAtIndex:macAddrCurrent];
                NSString *newOrderStr =[NSString stringWithFormat:@"%d" ,([currentOrderStr intValue]+1)];
                newOrderStr = [@";\n" stringByAppendingString:newOrderStr];
                NSString *asdd =[@";\n" stringByAppendingString:currentOrderStr] ;
                NSRange newOrder = [mMutWMacStr rangeOfString:asdd];
                if (newOrder.length>0)
                {
                    tempstr = [tempstr stringByReplacingOccurrencesOfString:asdd withString:newOrderStr];
                }
                
                FILE *fp;
                fp = fopen([mWmacFilePath UTF8String], "wr");
                fclose(fp);
                
                NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:mWmacFilePath];
                
                [NSString stringWithContentsOfFile:mWmacFilePath encoding:NSASCIIStringEncoding  error:nil];
                if (filehandTmp!=nil)
                {
                    [filehandTmp seekToEndOfFile] ;
                    [filehandTmp writeData:[NSData dataWithData:[tempstr dataUsingEncoding:NSASCIIStringEncoding]] ];
                    [filehandTmp closeFile] ;
                }
                
                NSString *currentUseAddr = [mWMacArr objectAtIndex:[currentOrderStr intValue]];
                NSString *tmpAddrStr1 = [currentUseAddr substringFromIndex:4];
                tmpAddrStr1 =[@"0x" stringByAppendingString: tmpAddrStr1];
                NSString *tmpAddrStr2 = [currentUseAddr substringToIndex:4];
                tmpAddrStr2 =[@"0x0000" stringByAppendingString: tmpAddrStr2];
                
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0xBABABABA" withString:tmpAddrStr1];
                mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"0x0000BABA" withString:tmpAddrStr2];
            }
        }
        else if ([mMutWMacStr rangeOfString:mExsitMacAddrStr].length > 1)
        {
            mWriteCmd = [@"syscfg add EMac " stringByAppendingString:mReferenceBufferNameValue1];
        }
    }
    
	/*SCRID-116: add function Replacing Colon With Semicolon. joko 2011-07-20*/
	if([mReplaceColonWithSemicolon boolValue])
		mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@":" withString:@";"];
	/*SCRID-116:end*/
	
	NSMutableString *strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
	
	//modified by caijunbo on 2011-03-06 used for Mikey 2.0
	if (mWriteCmdEnd!=nil)
	{
		if ([mWriteCmdEnd isEqualToString:@"NOCMDEND"])
		{
			NSLog(@"NOCMDEND");
		}
		else
			[strMutSendBuffer appendString:mWriteCmdEnd] ;
	}
	//end modified by caijunbo on 2011-03-06 used for Mikey 2.0
	//SCRID-152: Add parse to resove LCD Align and V8 stations CB clean issue in checkin and checkout.Judith.2011-12-19.
	NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    //add by kevin for QT0a start 20140811
    if(mReferenceBufferNameValue !=nil && mFixtureType !=nil)
    {
        if([mReferenceBufferNameValue rangeOfString:mFixtureType].length<=0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :@"ByPass"] ;
            return;
        }
    }
    //add by kevin for QT0a end 20140811
    
    if ([mReferenceBufferNameValue isEqualToString:@"MopadHashPass"]) {
        return;
    }
    if([mReferenceBufferNameValue rangeOfString:@"0x45"].length>0 && [mWriteCmd rangeOfString:@"sensorreg --sel pressure -w 0xF5 0x00"].length>0)
    {
        return;
    }
	if([mReferenceBufferNameValue rangeOfString:@"BYPASS"].length > 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
		return ;
	}
    else if([mReferenceBufferNameValue rangeOfString:@"lb_result=0"].length > 0)//if the data which get from sfc contains lb_result=0, do nothing.add by blake 20130802 from PL for judging the unit has tested laser staion.
	{
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"Finish!"] ;
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_BYPASS :mReferenceBufferNameValue] ;
		return ;
	}
    
	else    //SCRID-152:end
	{
		bool bTmp = [self SendData:dictKeyDefined :strMutSendBuffer :mPostfix] ;
		
        if ([mWriteCmd rangeOfString:@"baseband --passthrough"].length > 0)
        {
            usleep(100000);
            [self SendData:dictKeyDefined :@"EXIT" :@":-)"] ;
        }
        
        if (bTmp==false)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
            return ;
        }
		
		if ([mWhetherRead boolValue])
		{
			NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
			int iTmp = [mTimeOut intValue] ;
			int timeInterval = - [dateTmp timeIntervalSinceNow] ;
			while (timeInterval<=iTmp)
			{
				timeInterval = -[dateTmp timeIntervalSinceNow] ;
				
				if ([self CheckReceDataIsComplete:dictKeyDefined])
					break ;
				else
				{
					usleep(100000) ; //delay 100ms
				}
				
			}
			//read data
			NSString *dataResult = [self ReceData:dictKeyDefined] ;
			
			/*if([mWriteCmd rangeOfString:@"FL"].length > 0) //add by judith 2012-05-17
             {
             sleep(1);
             [dictKeyDefined setValue:@"Prox" forKey:@"Device"];
             float distance = [self CalculatDistanceUsingProximity:dictKeyDefined];
             if (mBufferNameHES !=nil)
             [TestItemManage setBufferValue:dictKeyDefined :mBufferNameHES :[NSString stringWithFormat:@"%f",distance]] ;
             NSLog(@"HEFF Log InitDistance after = %@",[NSString stringWithFormat:@"%f",distance]);
             //int distance1 = (distance - 15)*2000;
             //int distance1 = (distance - [mHeffDistance floatValue])*2000;
             //mWriteCmd = [mWriteCmd stringByReplacingOccurrencesOfString:@"+" withString:[NSString stringWithFormat:@"%d",distance1]];
             //[dictKeyDefined setValue:@"Motor" forKey:@"Device"];
             }*/
			
			/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
			if ([mWriteCmd rangeOfString:@"boardid"].length>0)
			{
				if (dataResult==nil)
				{
					dataResult=@"boardid unknow";
				}
				[TestItemManage setUnitValue:dictKeyDefined :STRKEYBOARDID : dataResult];
                
			}
            
			/*SCRID-104: end*/
            if([mWriteCmd rangeOfString:@"smokey --run CurrentTest"].length > 0)
            {
                if([dataResult rangeOfString:@"All errors:" ].length <= 0)
                {
                    dataResult = [dataResult stringByAppendingString:@"BYPASS"];
                }
            }
            
            
            if([mWriteCmd rangeOfString:@"--sel als1 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als2 --init"].length > 0
               || [mWriteCmd rangeOfString:@"--sel als3 --init"].length > 0)
            {
                if([dataResult rangeOfString:@"OK"].length <= 0 || [dataResult rangeOfString:@"ERROR"].length > 0
                   || [dataResult rangeOfString:@"Error"].length > 0 || [dataResult rangeOfString:@"error"].length > 0)
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :@"BYPASS"] ;
            }
			
			if (dataResult==nil)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
				return ;
			}
			if (mBufferName !=nil)
			{
				[TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
				return ;
			}
		}
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
		return ;
	}
}
//Add by Justin end 2015-01-17


//add by kevin for SL CT1 accel sensor judge different sensor different diag command on 20150316 start
+(void)RS232WriteAndReadTwoStrAndCondition:(NSDictionary*)dictKeyDefined
{
    NSString *mDevice=nil        ;
	NSString *mWriteCmdTmp1=nil      ;
	NSString *mWriteCmdTmp2=nil      ;
	NSString *mBufferName=nil    ;
    NSString *mReferenceBufferName=nil     ;
    NSString *mTimeOut=@"6"      ;
	NSString *mWriteCmdEnd=@"\n"  ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
    NSString *mCondition1=nil;
    NSString *mCondition2=nil;
    NSString *mWriteCmd=nil;
    NSMutableString *strMutSendBuffer=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd1"])
		{
			mWriteCmdTmp1 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"mCondition1"])
		{
			mCondition1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmdTmp2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"mCondition2"])
		{
			mCondition2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdEnd"])
		{
			mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])  //add by Judith for cleanCB2.20111219
		{
			mReferenceBufferName= [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    if (mDevice==nil || mWriteCmdTmp1==nil || mWriteCmdTmp2==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
    if(mReferenceBufferName ==nil || mReferenceBufferName.length<=0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error!"] ;
		return ;
    }
    NSString *mReferenceBufferNameValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    if(mReferenceBufferNameValue ==nil || mReferenceBufferNameValue.length<=0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"diag return error!"] ;
		return ;
    }
    if([mReferenceBufferNameValue rangeOfString:mCondition1].length>0)
    {
        mWriteCmd=mWriteCmdTmp1;
    }
    if([mReferenceBufferNameValue rangeOfString:mCondition2].length>0)
    {
        mWriteCmd=mWriteCmdTmp2;
    }
    
    if(mWriteCmd ==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"diag is null!"] ;
		return ;
    }
    
    
    //send diag command
    if(mWriteCmd != nil)
    {
        strMutSendBuffer = [NSMutableString stringWithString:mWriteCmd] ;
    }
	if (mWriteCmdEnd!=nil)
    {
        [strMutSendBuffer appendString:mWriteCmdEnd] ;
    }
    bool bTmp = [self SendData:dictKeyDefined :mWriteCmd :mPostfix] ;
    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = [mTimeOut intValue] ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:dictKeyDefined])
            break ;
        else
        {
            usleep(100000) ; //delay 100ms
        }
        
    }
    //read data
    NSString *dataResult = [self ReceData:dictKeyDefined] ;
    if (dataResult==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
        return ;
    }
    if (mBufferName !=nil)
    {
        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
        return ;
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    return ;
}

//add by kevin for SL CT1 accel sensor judge different sensor different diag command on 20150316 end


//add for USB3Test
//add from RX SMT by kevin on 20150318 for A-1 Sation Testitem "usb3 Test" start
+(void)ParseUsb3Test:(NSDictionary*) DictionaryPtr
{
    NSString *mTestItemName=nil ;
    
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
    }
    //send script xbar_off
    bool bTmp = [self SendData:DictionaryPtr :@"script xbar_off\n" :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Send data fail "] ;
		return ;
	}
	
    NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
    int iTmp = 6 ;
    int timeInterval = - [dateTmp timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:DictionaryPtr])
            break ;
        else
            usleep(500000) ; //delay 500
    }
    //read data
    NSString *dataResult = [self ReceData:DictionaryPtr] ;
    
    if ([dataResult componentsSeparatedByString:@"OK"].count != 4)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"receive data fail"] ;
        return;
    }
    
    //send script usb_on
    bTmp = [self SendData:DictionaryPtr :@"script usb_on\n" :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Send data fail "] ;
		//return ;
	}
	
    NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
    
    timeInterval = - [dateTmp2 timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp2 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:DictionaryPtr])
            break ;
        else
            usleep(500000) ; //delay 500
    }
    //read data
    bool busbon = true;
    dataResult = [self ReceData:DictionaryPtr] ;
    
    if (([dataResult componentsSeparatedByString:@"OK"].count != 3)
        || ([dataResult rangeOfString:@"Vendor:106B"].length <= 0)
        || ([dataResult rangeOfString:@"Vendor:1B73"].length <= 0))
    {
        busbon = false;
    }
    //send script usb_off
    bTmp = [self SendData:DictionaryPtr :@"script usb_off\n" :@":-)"] ;
	
	if (bTmp==false)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Send data fail "] ;
		//return ;
	}
	
    NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
    
    timeInterval = - [dateTmp3 timeIntervalSinceNow] ;
    while (timeInterval<=iTmp)
    {
        timeInterval = -[dateTmp3 timeIntervalSinceNow] ;
        
        if ([self CheckReceDataIsComplete:DictionaryPtr])
            break ;
        else
            usleep(500000) ; //delay 500
    }
    //read data
    
    
    bool busbff = true;
    dataResult = [self ReceData:DictionaryPtr] ;
    
    if (([dataResult componentsSeparatedByString:@"OK"].count != 3))
    {
        busbff = false;
    }
    
    if (busbff && busbon) {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL"] ;
        
    }
    
    
}
//add from RX SMT by kevin on 20150318 for A-1 Sation Testitem "usb3 Test" end

+ (NSString *)stringFromHexString:(NSString *)hexString {
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
    NSLog(@"------字符串=======%@",unicodeString);
    return unicodeString;
}
+(void)RS232WriteAndReadStrForCL200A:(NSDictionary*)dictKeyDefined
{

    NSString *mDevice=nil        ;
    NSString *mWriteCmd=nil      ;
    NSString *mWhetherRead = @"yes" ;
    
    NSString *mBufferName=nil    ;
    NSString *mTimeOut=@"6"      ;
    NSString *mWriteCmdEnd=@"\n"  ;
    NSString *mPostfix =@":-)";
    NSString *mTestItemName=nil     ;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"WriteCmdEnd"])
        {
            mWriteCmdEnd = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"Postfix"])
        {
            mPostfix = [dictKeyDefined objectForKey:strKey] ;
        }else if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    
    
    if (mDevice==nil ||
        mWriteCmd==nil
        )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
        return ;
    }
    
    NSString *WriteCmd = [dictKeyDefined objectForKey:@"WriteCmd"];
    WriteCmd = [self stringFromHexString:WriteCmd];

    bool bTmp = [self SendData:dictKeyDefined :WriteCmd :mPostfix] ;

    
    if (bTmp==false)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"send data fail "] ;
        return ;
    }
    
    if ([mWhetherRead boolValue])
    {
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(100000) ; //delay 100ms
            }
            
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ;
        NSLog(@"Receive Data = %@",dataResult);
        
        if (dataResult==nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"NO Receive Data!"] ;
            return ;
        }
        
        
        if (mBufferName !=nil)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :dataResult] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
            return ;
        }
    }
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;
    return ;
    
}
@end
