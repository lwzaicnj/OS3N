//
//  CheckHwyX15Function.m
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ParseSLOPEFunction.h"
#import "Pudding.h"
#import "toolFun.h"

@implementation TestItemParse(ParseSLOPEFunction)
			
		
+(void)ParseStrWithStrSpecPostfix_slop:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil ;
	NSString *mPostfix=nil ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mPostfix2=nil ;
	NSString *mPrefix2=nil      ;
	NSString *mPostfix3=nil ;
	NSString *mPrefix3=nil      ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	NSString *mCondition =@"Yes"  ;

	
	if (dictKeyDefined==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"parse occur exception"] ;
		return ;
	}
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix2"])
		{
			mPrefix2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix2"])
		{
			mPostfix2 = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Prefix3"])
		{
			mPrefix3 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix3"])
		{
			mPostfix3 = [dictKeyDefined objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	NSString *mReferenceBufferValue=nil;
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}

	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	
	NSString *strFind2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix2 Postfix:mPostfix2] ;
	NSString *strFind3= [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix3 Postfix:mPostfix3] ;

	double min=[strFind2 doubleValue];
	double max=[strFind3 doubleValue];

	
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	else
	{	
			NSRange rangeTmp=[mReferenceBufferValue rangeOfString:mStrSpec] ;

			if ([mCondition boolValue])
			{	
				if (rangeTmp.length > 0)  //PASS  conditional 
				{
					enumResult =RESULT_FOR_PASS ;
					strTestResultForUIinfo = @"Pass" ;
				}
				else //failse conditional
				{
					enumResult =RESULT_FOR_FAIL ;
					strTestResultForUIinfo = @"Fail" ;
				}
			}
			else
			{
				if (rangeTmp.length > 0)  //PASS  conditional 
				{
					enumResult =RESULT_FOR_FAIL ;
					strTestResultForUIinfo = @"Fail" ;
				}
				else //failse conditional
				{
					enumResult =RESULT_FOR_PASS ;
					strTestResultForUIinfo = @"Pass" ;
				}

			}
	}
	
	NSArray *Date1 = [strFind componentsSeparatedByString:@"SLOPE"];
	
    int t=0;double sum1=0;
	
	for (int i = 0;i<[Date1 count];i++)
	{
		
		NSArray *Date2 = [[Date1 objectAtIndex:i] componentsSeparatedByString:@"= "];
		
		for (int j = 1;j<[Date2 count];j++)
		{
	
		double temp = [[Date2 objectAtIndex:j] doubleValue];
			
		sum1=sum1+temp;
		t++;
			
		}
	 }
	
	
	double average=sum1/t;
	double sum2=0;
	
	for (int i = 0;i<[Date1 count];i++)
	{
		NSArray *Date2 = [[Date1 objectAtIndex:i] componentsSeparatedByString:@"= "];
		
		for (int j = 1;j<[Date2 count];j++)
		{
			double temp = [[Date2 objectAtIndex:j] doubleValue];
			
			double tmpVal =temp - average;
			sum2 = sum2 + (tmpVal*tmpVal);
		}
	}
	
	double tmpAvg=(sum2/t);
	
    double slope_AD= (pow(tmpAvg,0.5));
	
	/*Owner:Henry DATE :10.20.2010
	 SCRID :006
	 Desc  :Modify ParseSLOPEFunction to print log including Slope SD ,Slope Min,Slope Max.
	 */
	NSString *strSlopeSD = @"\n slope SD:";
	NSString *strSlopeMin = @"\n slope Min:";
	NSString *strSlopeMax = @"\n slope Max:";
	
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:strSlopeSD] ;
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%.3f",slope_AD]] ;
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:strSlopeMin] ;
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%.3f",min]] ;
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:strSlopeMax] ;
	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat:@"%.3f",max]] ;
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"slope SD":nil:nil:nil:[NSString stringWithFormat:@"%.3f",slope_AD]:nil:IP_NA:nil];
	//enable, because have item "Grape Test_Grape_Max" and "Grape Test_Grape_Min" 2010-03-21
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"slope Min":nil:nil:nil:[NSString stringWithFormat:@"%.3f",min]:nil:IP_NA:nil];
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"slope Max":nil:nil:nil:[NSString stringWithFormat:@"%.3f",max]:nil:IP_NA:nil];
	//end Henry 10.20.2010
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	
	return;
	
}


	@end
	
		
	
	
	


  	   

	
	
	
	

	
	
