//
//  ParseCompassQTFunction.h
//  qt
//
//  Created by Henry on 7/19/10.
//  Copyright 2010-2020 . All rights reserved.
//

#import "ParseWiFiCalibrationDataFunction.h"

@implementation TestItemParse(ParseWiFiCalibrationData)


+(void)ParseWiFiCalibrationData:(NSDictionary*) DictionaryPtr
{
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
//	NSString *strTestResultForUIinfo ;
//	enum TestResutStatus enumResult ;
	//end
	
	//Parser Attributes
	NSString *mTestItemName=nil ;
	NSString *mUpperlimit=nil      ;
	NSString *mBufferName1=nil ;
	NSString *mBufferName2=nil ;
	NSString *mReferenceBufferName=nil ;

	
	NSString *mPDCAWrite =@"no"  ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Upperlimit"])
		{
			mUpperlimit = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName1"])
		{
			mBufferName1 = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName2"])
		{
			mBufferName2 = [DictionaryPtr objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mBufferName1==nil ||mBufferName2==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSRange rangTemW24G = [mReferenceBufferValue rangeOfString:@"2/4GHz WIFI Calibration Data:"];
	NSString *strTmpW24G = [mReferenceBufferValue substringFromIndex:rangTemW24G.location] ;
	NSRange rangTemW50G = [strTmpW24G rangeOfString:@"5/8GHz WIFI Calibration Data:"];
	strTmpW24G = [strTmpW24G substringToIndex:rangTemW50G.location];
	if ((rangTemW24G.length<=0)||(rangTemW50G.length<=0))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	// For W24G
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *arryW24G = [strTmpW24G componentsSeparatedByString:@" "];
	NSString *strMutW24G =@" ";
	//end
//	for(int i=1; i<[arryW24G count]; i++)
	for(int i=6; i< 9; i++)
	{
		NSString *tmp = [arryW24G objectAtIndex:i];
		NSString *tmpFirst2Bit = [tmp substringToIndex:2]; 
		NSString *tmpLast2Bit = [tmp substringFromIndex:2]; 
		NSString *strTmp =[tmpLast2Bit stringByAppendingString:tmpFirst2Bit];
		
		strMutW24G = [strMutW24G stringByAppendingString:strTmp];
		strMutW24G = [strMutW24G stringByAppendingString:@" "];
	}
	strMutW24G = [ToolFun allTrimFromString:strMutW24G trimStr:@" " leftTrim:true rightTrim:true] ;

	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *arryW24GTmp = [strMutW24G  componentsSeparatedByString:@" "];
	NSString *strMutW24GTmp =@" ";
	//end
	NSString *strHead = @"0x";
	for(int i=0; i<[arryW24GTmp count]; i=i+2)
	{
		NSString *tmp1 = nil;
		NSString *tmp2 = nil;
		NSString *strTmp = nil;
		
		tmp1 = [arryW24GTmp objectAtIndex:i];
		if(i+1<[arryW24GTmp count])
			tmp2 = [arryW24GTmp objectAtIndex:i+1];
		else
			tmp2 = @"0000";
		tmp2 = [strHead stringByAppendingString:tmp2];

		strTmp = [tmp2 stringByAppendingString:tmp1];
		strMutW24GTmp = [strMutW24GTmp stringByAppendingString:strTmp];
		strMutW24GTmp = [strMutW24GTmp stringByAppendingString:@" "];
	}
	[TestItemManage setBufferValue:DictionaryPtr :mBufferName1 :strMutW24GTmp] ;
	
	NSRange rangTempW50G = [mReferenceBufferValue rangeOfString:@"5/8GHz WIFI Calibration Data:"];
	NSString *strTempW50G = [mReferenceBufferValue substringFromIndex:rangTempW50G.location] ;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	
	//SCRID:70 fixed wifi BT to modify ParseWiFiCalibrationDataFunction by Helen on 2011-01-28
	NSRange rangeFirstW50G = [strTempW50G rangeOfString:@"0000000:"];
	NSRange rangeSecondW50G = [strTempW50G rangeOfString:@"0000010:"];
	NSString *firstPart = [strTempW50G substringFromIndex:rangeFirstW50G.location];
	NSString *secondPart = [strTempW50G substringFromIndex:rangeSecondW50G.location];
//	NSArray *arryW50G = [strTempW50G componentsSeparatedByString:@":"];
	
	
	//end
//	NSString *firstPart = [arryW50G objectAtIndex:2];
//	NSString *secondPart = [arryW50G objectAtIndex:3];
	firstPart = [ToolFun allTrimFromString:firstPart trimStr:@" " leftTrim:true rightTrim:true] ;
	secondPart = [ToolFun allTrimFromString:secondPart trimStr:@" " leftTrim:true rightTrim:true] ;
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *arryW50GFirstPart = [firstPart componentsSeparatedByString:@" "];
	NSArray *arryW50GSecondPart = [secondPart componentsSeparatedByString:@" "];
	NSString *strMutW50G =@" ";
	NSString *strMutW50G2 =@" ";
	//end
	//	for(int i=1; i<[arryW50G count]; i++)
	for(int i=1; i< 9; i++)
	{
		NSString *tmp = [arryW50GFirstPart objectAtIndex:i];
		NSString *tmpFirst2Bit = [tmp substringToIndex:2]; 
		NSString *tmpLast2Bit = [tmp substringFromIndex:2]; 
		NSString *strTmp =[tmpLast2Bit stringByAppendingString:tmpFirst2Bit];
		
		strMutW50G = [strMutW50G stringByAppendingString:strTmp];
		strMutW50G = [strMutW50G stringByAppendingString:@" "];
	}
	strMutW50G = [ToolFun allTrimFromString:strMutW50G trimStr:@" " leftTrim:true rightTrim:true] ;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable

	NSArray *arryW50GTmp = [strMutW50G  componentsSeparatedByString:@" "];
	NSString *strMutW50GTmp =@" ";
	//end
	for(int i=0; i<[arryW50GTmp count]; i=i+2)
	{
		NSString *tmp1 = nil;
		NSString *tmp2 = nil;
		NSString *strTmp = nil;
		NSString *strHead = @"0x";
		
		tmp1 = [arryW50GTmp objectAtIndex:i];
		if(i+1<[arryW50GTmp count])
			tmp2 = [arryW50GTmp objectAtIndex:i+1];
		else
			tmp2 = @"0000";
		tmp2 = [strHead stringByAppendingString:tmp2];
		
		strTmp = [tmp2 stringByAppendingString:tmp1];
		strMutW50GTmp = [strMutW50GTmp stringByAppendingString:strTmp];
		strMutW50GTmp = [strMutW50GTmp stringByAppendingString:@" "];
	}
	
//	for(int i=0; i< [arryW50GSecondPart count]; i++)
	for(int i=1; i< 2; i++)
	{
		NSString *tmp = [arryW50GSecondPart objectAtIndex:i];
		NSString *tmpFirst2Bit = [tmp substringToIndex:2]; 
		NSString *tmpLast2Bit = [tmp substringFromIndex:2]; 
		NSString *strTmp =[tmpLast2Bit stringByAppendingString:tmpFirst2Bit];
		
		strMutW50G2 = [strMutW50G2 stringByAppendingString:strTmp];
		strMutW50G2 = [strMutW50G2 stringByAppendingString:@" "];
	}
	strMutW50G2 = [ToolFun allTrimFromString:strMutW50G2 trimStr:@" " leftTrim:true rightTrim:true] ;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *arryW50GTmp2 = [strMutW50G2  componentsSeparatedByString:@" "];
	NSString *strMutW50GTmp2 =@" ";
	//end
	for(int i=0; i<[arryW50GTmp2 count]; i=i+2)
	{
		NSString *tmp1 = nil;
		NSString *tmp2 = nil;
		NSString *strTmp = nil;
		NSString *strHead = @"0x";
		
		tmp1 = [arryW50GTmp2 objectAtIndex:i];
		if(i+1<[arryW50GTmp2 count])
			tmp2 = [arryW50GTmp2 objectAtIndex:i+1];
		else
			tmp2 = @"0000";
		tmp2 = [strHead stringByAppendingString:tmp2];
		
		strTmp = [tmp2 stringByAppendingString:tmp1];
		strMutW50GTmp2 = [strMutW50GTmp2 stringByAppendingString:strTmp];
		strMutW50GTmp2 = [strMutW50GTmp2 stringByAppendingString:@" "];
	}
	strMutW50GTmp =[strMutW50GTmp stringByAppendingString:strMutW50GTmp2];
	[TestItemManage setBufferValue:DictionaryPtr :mBufferName2 :strMutW50GTmp] ;

	//[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
		
	return ;
	
}

@end
