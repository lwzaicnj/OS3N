/*
 SCRID:31
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseMagnetFunction.h 
 | $Author: Evan						$Revision:: 1               
 | CREATED: 2010.12.10                  $Modtime::  08:43     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to test the Magnetic testItem "The Max value" 
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

#import "StringParseFuncation.h"
#import "Pudding.h"

@interface TestItemParse(ParseMagnetFunction)

+(void)ParseSensorOffsetPS105:(NSDictionary*)dictKeyDefined ;

+(void)ParseSensorTeslaPS105:(NSDictionary*)dictKeyDefined ;

+(void)ParseSensorTeslaPS105Calibration:(NSDictionary*)dictKeyDefined ;

+(void)ParseMagnetFunction:(NSDictionary*)dictKeyDefined ;

@end
