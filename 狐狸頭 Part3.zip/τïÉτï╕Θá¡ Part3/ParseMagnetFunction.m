
/*
 SCRID:31
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ParseMagnetFunction.m  $|
 | $Author:: Evan                        $Revision::  1						$|
 | CREATED: 2010-12-06                   $Modtime:: 2.03.00 08:43			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to test the Magnetic testItem "The Max value" 
 
 */

#import "ParseMagnetFunction.h"
#import "toolFun.h"

BOOL bSetFailCB5Times = FALSE;

int SpecFailCount = 0;

bool needCreatCSVFile=YES;
NSMutableString *CSVFileNameValue;
NSString *MagineCSVFileTitle=@"SN,Fixture Offset 1,Fixture Offset 2,Fixture Offset 3,Fixture Offset 4,Fixture Offset 5,Fixture Offset 6,Fixture Offset 7,Fixture Offset 8,Fixture Offset 9,Fixture Offset 10,Fixture Offset 11,Fixture Offset 12,Fixture Offset 13,Fixture Offset 14,Cover fixture Offset1,Cover fixture Offset2,Cover fixture Offset3,Cover fixture Offset4,Cover fixture Offset5,Spine Voltage 1-1,Spine Voltage 1-2,Spine Voltage 2-1,Spine Voltage 2-2,Spine Voltage 3-1,Spine Voltage 3-2,Spine Voltage 4-1,Spine Voltage 4-2,Spine Voltage 5-1,Spine Voltage 5-2,Spine Voltage 6-1,Spine Voltage 6-2,Spine Voltage 7-1,Spine Voltage 7-2,Cover Voltage1,Cover Voltage2,Cover Voltage3,Cover Voltage4,Cover Voltage5,TeslaSpine1-1,TeslaSpine1-2,TeslaSpine2-1,TeslaSpine2-2,TeslaSpine3-1,TeslaSpine3-2,TeslaSpine4-1,TeslaSpine4-2,TeslaSpine5-1,TeslaSpine5-2,TeslaSpine6-1,TeslaSpine6-2,TeslaSpine7-1,TeslaSpine7-2,TeslaCover1,TeslaCover2,TeslaCover3,TeslaCover4,TeslaCover5";



@implementation TestItemParse(ParseMagnetFunction)

+(void)ParseSensorOffsetPS105:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mAverageValueName=nil ;
    NSString *mBufferName=nil ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
    NSString *mUnit=nil;
    NSString *mFirstRunForCSV=@"no";
    
    enum TestResutStatus enumResult;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"AverageValueName"])
		{
			mAverageValueName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"Unit"])
		{
			mUnit = [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"FirstRunForCSV"])
		{
			mFirstRunForCSV = [dictKeyDefined objectForKey:strKey];
		}
		
	}
    
    if(needCreatCSVFile)
    {
        NSDate *CSVDate =[NSDate date]; 
        NSString *CSVFileName =[CSVDate description];
        CSVFileName=[CSVFileName stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        CSVFileName=[CSVFileName stringByReplacingOccurrencesOfString:@" " withString:@""];
        CSVFileName=[CSVFileName stringByReplacingOccurrencesOfString:@":" withString:@""];
        CSVFileName=[CSVFileName stringByReplacingOccurrencesOfString:@"-" withString:@""];
        CSVFileName=[CSVFileName stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        CSVFileNameValue = [[NSMutableString alloc] initWithString:@"/vault/"];
       [CSVFileNameValue appendString:CSVFileName];
       [CSVFileNameValue appendString:@".csv"];

        FILE* fp=NULL;
        fp=fopen([CSVFileNameValue UTF8String],"wr");
        fclose(fp);
        
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[MagineCSVFileTitle dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
        
        needCreatCSVFile=NO;
    }
	 
    if([mFirstRunForCSV boolValue])
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        NSString *strSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
        //NSString *strSN = @"asdf22";
        if(strSN == nil)
            strSN = @"SN error";
        strSN = [strSN stringByAppendingString:@","];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"\n" dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[strSN dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }  
    }
    
    
    NSString *fileName = @"/vault/CalibrationData.txt";
    NSString *strFileContent = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
    if (strFileContent==nil || [strFileContent length] <= 0)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        } 
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please check file /vault/CalibrationData.txt"] ;
        return  ;
    }
    NSString *strOffset = [ToolFun getStrFromPrefixAndPostfix:strFileContent Prefix
															 :mAverageValueName Postfix
															 :@">"] ;
    if (strOffset==nil)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        } 
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFileContent] ;
        return  ;
    }
    
    if(((mLowLimit==nil||[mLowLimit length]<=0)?1:([strOffset doubleValue] >=[mLowLimit intValue]))
            && ((mUpLimit==nil||[mUpLimit length]<=0)?1:([strOffset doubleValue]<=[mUpLimit intValue])))
    {
        enumResult =RESULT_FOR_PASS ;
    }
    else 
    {
        enumResult =RESULT_FOR_FAIL ;
    }
    
    if (mBufferName!=nil)
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :strOffset] ;
	}
	
    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
    if (filehandTmp!=nil)
    {
        [filehandTmp seekToEndOfFile] ;
        [filehandTmp writeData:[NSData dataWithData:[strOffset dataUsingEncoding:NSASCIIStringEncoding]]] ;
        [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
        [filehandTmp closeFile] ;
    } 
    
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strOffset] ;
    
}


+(void)ParseSensorTeslaPS105:(NSDictionary*)dictKeyDefined
{
    //key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferNameOffset=nil ;
    NSString *mReferenceBufferNameFlap=nil ;
    NSString *mReferenceBufferNameOffsetGolden=nil;
    NSString *mActualValue=nil;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
    NSString *mUnit=nil;
	NSString *mTheFirstOne=@"no";
    
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
        {
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferNameOffsetGolden"])
        {
			mReferenceBufferNameOffsetGolden = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferNameOffset"])
        {
			mReferenceBufferNameOffset = [dictKeyDefined objectForKey:strKey] ;
        }
        
        else if ([strKey isEqualToString:@"ReferenceBufferNameFlap"])
        {
			mReferenceBufferNameFlap = [dictKeyDefined objectForKey:strKey] ;
        }
		else if([strKey isEqualToString:@"UpperValue"])
        {
			mUpLimit = [dictKeyDefined objectForKey:strKey];
        }
		else if([strKey isEqualToString:@"LowerValue"])
        {
			mLowLimit = [dictKeyDefined objectForKey:strKey];
        }
        else if([strKey isEqualToString:@"Unit"])
        {
			mUnit = [dictKeyDefined objectForKey:strKey];
        }
		else if([strKey isEqualToString:@"TheFirstOne"])
        {
			mTheFirstOne = [dictKeyDefined objectForKey:strKey];
        }
        else if([strKey isEqualToString:@"ActualValue"])
        {
			mActualValue = [dictKeyDefined objectForKey:strKey];
        }
    }
    mLowLimit = [mLowLimit stringByReplacingOccurrencesOfString:mUnit withString:@""];
    mUpLimit = [mUpLimit stringByReplacingOccurrencesOfString:mUnit withString:@""];
    
    //JianSheng Add 2013-11-07 : If still fail with the second limits, write fail CB 5 times
    if([mTestItemName rangeOfString:@"TeslaSpine1-1"].length > 0)
        bSetFailCB5Times = FALSE;
    //JianSheng Add end 2013-11-07
	
	if([mTheFirstOne boolValue])
		SpecFailCount=0;
    
	if (mReferenceBufferNameOffsetGolden==nil || mReferenceBufferNameOffset==nil || mReferenceBufferNameFlap==nil)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
    }
    NSString* mReferenceBufferValueOffsetGolden = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOffsetGolden] ;
	if (mReferenceBufferValueOffsetGolden==nil)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
    }
    
	NSString* mReferenceBufferValueOffset = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOffset] ;
	if (mReferenceBufferValueOffset==nil)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
    }
    
    
    NSString* mReferenceBufferValueFlap = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameFlap] ;
	if (mReferenceBufferValueFlap==nil)
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[@"nil," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        }
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
    }
    
    float m = 1;
    float actual = 0.0;
    
    if (mActualValue != nil) {
        actual = [mActualValue doubleValue];
        m = (actual-1500)/([mReferenceBufferValueOffsetGolden doubleValue] - [mReferenceBufferValueOffset doubleValue]);
    }
    
    float floatTesla = m * ([mReferenceBufferValueOffset doubleValue] - [mReferenceBufferValueFlap doubleValue]) / 12.5;
    
    if(((mLowLimit==nil||[mLowLimit length]<=0)?1:(floatTesla >= [mLowLimit doubleValue]))
       && ((mUpLimit==nil||[mUpLimit length]<=0)?1:(floatTesla <= [mUpLimit doubleValue])))
    {
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[[NSString stringWithFormat:@"%f",floatTesla] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        } //add by Rick to wirte the csv file 2012-10-26
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",floatTesla]] ;
    }
    else
    {
        //JianSheng Add 2013-11-07 : If still fail with the second limits, write fail CB 5 times|| 20160114 Remove by Tiffany
//        if([mLowLimit intValue] == 0)
//            mLowLimit = @"-20";
//        if([mUpLimit intValue] == 0)
//            mUpLimit = @"20";
//        
//        if(((mLowLimit==nil||[mLowLimit length]<=0)?1:(floatTesla >= [mLowLimit doubleValue]))
//           && ((mUpLimit==nil||[mUpLimit length]<=0)?1:(floatTesla <= [mUpLimit doubleValue])))
//        {
//            ;
//        }
//        else
//        {
//            bSetFailCB5Times = TRUE;
//        }
        //JianSheng Add end 2013-11-07  ||   20160114 Remove by Tiffany end
        
        //added by Rick for special fail 2012-8-23
		if([mLowLimit doubleValue] > 0)
        {
			if((floatTesla >= 40) && (floatTesla <= 42))// change to[40,42]by Rick 2012-09-28
            {
				SpecFailCount++;
				
				if(SpecFailCount <= 2)
                {
                    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
                    if (filehandTmp!=nil)
                    {
                        [filehandTmp seekToEndOfFile] ;
                        [filehandTmp writeData:[NSData dataWithData:[[NSString stringWithFormat:@"%f",floatTesla] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                        [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                        [filehandTmp closeFile] ;
                    } //add by Rick to wirte the csv file 2012-10-26
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",floatTesla]] ;
					return;
                }
            }
        }
		else if([mUpLimit doubleValue] < 0)
        {
			if((floatTesla >= -42) && (floatTesla <= -40))// change to [-42,-40]by Rick 2012-09-28
            {
				SpecFailCount++;
				
				if(SpecFailCount <= 2)
                {
                    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
                    if (filehandTmp!=nil)
                    {
                        [filehandTmp seekToEndOfFile] ;
                        [filehandTmp writeData:[NSData dataWithData:[[NSString stringWithFormat:@"%f",floatTesla] dataUsingEncoding:NSASCIIStringEncoding]]] ;
                        [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
                        [filehandTmp closeFile] ;
                    } //add by Rick to wirte the csv file 2012-10-26
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",floatTesla]] ;
					return;
                }
            }
        }
        NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:CSVFileNameValue];
        if (filehandTmp!=nil)
        {
            [filehandTmp seekToEndOfFile] ;
            [filehandTmp writeData:[NSData dataWithData:[[NSString stringWithFormat:@"%f",floatTesla] dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp writeData:[NSData dataWithData:[@"," dataUsingEncoding:NSASCIIStringEncoding]]] ;
            [filehandTmp closeFile] ;
        } //add by Rick to wirte the csv file 2012-10-26
        //added by Rick for special fail end 2012-8-23
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",floatTesla]] ;
    }
}

+(void)ParseSensorTeslaPS105Calibration:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mAverageValueName=nil ;
    NSString *mReferenceBufferNameFlap=nil ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
    NSString *mUnit=nil;
    
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"AverageValueName"])
		{
			mAverageValueName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameFlap"])
		{
			mReferenceBufferNameFlap = [dictKeyDefined objectForKey:strKey] ;
		}
		else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"Unit"])
		{
			mUnit = [dictKeyDefined objectForKey:strKey];
		}
	}
    mLowLimit = [mLowLimit stringByReplacingOccurrencesOfString:mUnit withString:@""];
    mUpLimit = [mUpLimit stringByReplacingOccurrencesOfString:mUnit withString:@""];
    
    
	
    
	if (mReferenceBufferNameFlap==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
    NSString* mReferenceBufferValueFlap = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameFlap] ;
	if (mReferenceBufferValueFlap==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
    NSString *fileName = @"/vault/CalibrationData.txt";
    NSString *strFileContent = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
    if (strFileContent==nil || [strFileContent length] <= 0)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please check file /vault/CalibrationData.txt"] ;
        return  ;
    }
    NSString *strOffset = [ToolFun getStrFromPrefixAndPostfix:strFileContent Prefix
                                                           :mAverageValueName Postfix
                                                           :@">"] ;
    if (strOffset==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :strFileContent] ;
        return  ;
    }
    
    float floatTesla = ([strOffset intValue] - [mReferenceBufferValueFlap intValue]) / 12.5;
    
    if(((mLowLimit==nil||[mLowLimit length]<=0)?1:(floatTesla >= [mLowLimit doubleValue]))
       && ((mUpLimit==nil||[mUpLimit length]<=0)?1:(floatTesla <= [mUpLimit doubleValue])))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%f",floatTesla]] ;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%f",floatTesla]] ;
    } 
}

+(void)ParseMagnetFunction:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mPrefix=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	NSString *mUpLimit = nil;
	NSString *mLowLimit = nil;
	/*SCRID:65 Owner:Jack  Date:2011-01-20  Description:add for taking out weight of magnet holder. */
	NSString *mMagnetWeight= nil;
	//end
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
			
		}else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
		
		else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}
		/*SCRID:65 Owner:Jack  Date:2011-01-20  Description:add for taking out weight of magnet holder. */
		else if([strKey isEqualToString:@"MagnetWeight"])
		{
			mMagnetWeight = [dictKeyDefined objectForKey:strKey];
		}
		//end
		
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	//NSString *mReferenceBufferValue=@"BE NA+09.45" ;
	NSString* mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *Value=[mReferenceBufferValue substringFromIndex:[mPrefix length]];
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
	//	NSString *strSubItem =@"";
	//end
	if (Value==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
	
	/*SCRID:65 Owner:Jack  Date:2011-01-20  Description:add for taking out weight of magnet holder. */
	double Value1=0;
	if(mMagnetWeight == nil)
		Value1 = [Value doubleValue];
	else
		Value1= [Value doubleValue]-[mMagnetWeight doubleValue];
	
	NSString *Value2 = [NSString stringWithFormat:@"%.2f",Value1];
	
	if(Value1 >= [mLowLimit doubleValue] && 
	   Value1 <= [mUpLimit doubleValue])
	{
		enumResult = RESULT_FOR_PASS;
		strTestResultForUIinfo = Value2 ;
	}
	else
	{
		enumResult = RESULT_FOR_FAIL;
		strTestResultForUIinfo = Value2 ;
	}
	//end
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	
	
	return;
}

@end
