//
//  ParserBand.h
//  iFTS
//
//  Created by justin on 13-8-2.
//
//

#import <Foundation/Foundation.h>
#import "testItemParse.h"
#import "toolFun.h"

@interface TestItemParse(ParserBand)
//@interface ParserBand : NSObject
+(void)ParserBand:(NSDictionary*)dictKeyDefined;
+(void)ParseTwoBufferTwoSpecStr:(NSDictionary*)dictKeyDefined;
+(void)ParseMaxMinusMin:(NSDictionary*)dictKeyDefined ;
+(void)ParseStrFromMultiBuffer:(NSDictionary*)dictKeyDefined ;
+(void)MesaCalDataVerifyAtFDRServer:(NSDictionary*)dictKeyDefined ;
+(NSString *)runCMD:(NSString *)cmd argument:(NSArray *)argument;
+(void)ShowBarcode:(NSDictionary*)dictKeyDefined ;
+(void)ParseSubStringHexValue:(NSDictionary*)dictKeyDefined ;

//add by kevin for ct1 & ct3 "Orb Init" testitem 20150205
+(void)ParseThreeBufferThreeSpecStr:(NSDictionary*)dictKeyDefined;
//for SL QT1 Strobe test with CL200a communicate with visual RS232port----Added by Annie 2015.5.25
+(void)StrobeCL200A_SL:(NSDictionary*) DictionaryPtr;
//For SL CT1 LcmCal test in SL P2 US Dry Run--Annie added on 2015.8.13
+(void)SmokeyLcmCalGetPlist:(NSDictionary*) dictKeyDefined;
+(void)SmokeyLcmCal:(NSDictionary*) dictKeyDefined;
+(void)StrobeCL200A_SL2:(NSDictionary*) DictionaryPtr; //add by Justin Shang @20151019
@end
