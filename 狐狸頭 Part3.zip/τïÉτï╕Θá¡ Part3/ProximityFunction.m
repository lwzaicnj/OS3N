/*
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa					$Workfile:: ProximityFunction.h		$|
 | $Author:: Serin Yeh					$Revision::  1						$|
 | CREATED: 2010-03-31					$Modtime:: 2.03.00 15:24			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 $History:: ProximityFunction.h                                           $
 * *****************  Version 1  *****************
 * User: Serin Yeh					Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "scriptParse.h"
#import "testItemManage.h"
#import "testItemParse.h"
#import "UIWinManage.h"
#import "UI_LockScript.h"
//extern BOOL isAdmin;


//added by caijunbo on 2010-09-10 for Display Port Test
//#include <stdio.h>
//#include "math.h"
//#include <stdio.h>
#import "iFactoryTest/IFTPlugIn.h"
#import "testExecution.h"
#import "pubFun.h"
#import <Cocoa/Cocoa.h>

#import <Cocoa/Cocoa.h>
#import "ProximityFunction.h"
#import "Pudding.h"
#import "toolFun.h"
//#import "crc.h"
//double preProxAvg=0;
@implementation TestItemParse(ProximityFunction)
//added by caijunbo on 2010-11-24
//SCRID:21
int mBaseCnt = 600;
//end
int mProxCnt = 10;
int mVerifyCnt = 0;

//delete by caijunbo on 2011-10-10
//don't use global variable for multi-Threads
/*
 //added by caijunbo on 2011-09-14
 //used to indicate which Delta is the lowest.
 int gLowestDelta=100000;//100000 is a very big value,and the normal Delta value is smaller than it.
 int gIndicator=-1;//used to indicate which position has the lowest Delta value.0,90,or 180
 int g0DegreeProxValue=0;
 int g90DegreeProxValue=0;
 int g180DegreeProxValue=0;
 //end
 */
+(void)ParseProxBase2:(NSDictionary*)dictKeyDefined
{
    NSString *mReferenceBufferName = nil;
    NSString *mBaselineProx = nil;
    NSString *mBaselineProxSD = nil;
    NSString *mBaselineTemp_CS0 = nil;
    NSString *mBaselineTempSD_CS0 = nil;
    NSString *mBaselineTemp_CS1 = nil;
    NSString *mBaselineTempSD_CS1 = nil;
    NSString *mBaselineTemp_CS2 = nil;
    NSString *mBaselineTempSD_CS2 = nil;
    NSString *mLoopTime= @"50";
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"BaselineProx"])
			mBaselineProx = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"BaselineProxSD"])
		{
			mBaselineProxSD = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BaselineTemp_CS0"])
		{
			mBaselineTemp_CS0 = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BaselineTempSD_CS0"])
		{
			mBaselineTempSD_CS0 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"BaselineTemp_CS1"])
		{
			mBaselineTemp_CS1 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"BaselineTempSD_CS1"])
		{
			mBaselineTempSD_CS1 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"BaselineTemp_CS2"])
		{
			mBaselineTemp_CS2 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"BaselineTempSD_CS2"])
		{
			mBaselineTempSD_CS2 = [dictKeyDefined objectForKey:strKey] ;
			
		}
        
        else if ([strKey isEqualToString:@"LoopTime"])
		{
			mLoopTime = [dictKeyDefined objectForKey:strKey] ;
			
		}
	}
    
    if(mReferenceBufferName == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script error!"] ;
        return ;
    }
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Prox test log.rtf" encoding:NSUTF8StringEncoding error:nil];
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if(mReferenceBufferValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no receive data!"] ;
        return ;
    }
    NSRange prefixRange = [mReferenceBufferValue rangeOfString:@"prox:"];
    mReferenceBufferValue = [mReferenceBufferValue substringFromIndex:(prefixRange.location + prefixRange.length)];
    
    NSRange postfixRange = [mReferenceBufferValue rangeOfString:@"OK"];
    
    mReferenceBufferValue = [mReferenceBufferValue substringToIndex:postfixRange.location];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSArray *proxArray = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    if([proxArray count] != [mLoopTime intValue])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Return not enough"] ;
        return ;
    }
    NSMutableArray *C0Array = [NSMutableArray array];
    NSMutableArray *C1Array = [NSMutableArray array];
    NSMutableArray *C2Array = [NSMutableArray array];
    NSMutableArray *C3Array = [NSMutableArray array];
    for(int i=20; i < [proxArray count]; i++) //get last 30 sample data
    {
        NSString *tmp = nil;
        NSRange tmpRange = [[proxArray objectAtIndex:i] rangeOfString:@"C0:"];  //C0
        
        tmp = [[proxArray objectAtIndex:i] substringFromIndex:(tmpRange.location + tmpRange.length)];
        tmp = [tmp substringToIndex:[tmp rangeOfString:@","].location];
        [C0Array addObject:tmp];
        
        tmpRange = [[proxArray objectAtIndex:i] rangeOfString:@"C1:"];  //C1
        
        tmp = [[proxArray objectAtIndex:i] substringFromIndex:(tmpRange.location + tmpRange.length)];
        tmp = [tmp substringToIndex:[tmp rangeOfString:@","].location];
        [C1Array addObject:tmp];
        
        tmpRange = [[proxArray objectAtIndex:i] rangeOfString:@"C2:"];  //C2
        
        tmp = [[proxArray objectAtIndex:i] substringFromIndex:(tmpRange.location + tmpRange.length)];
        tmp = [tmp substringToIndex:[tmp rangeOfString:@","].location];
        [C2Array addObject:tmp];
        
        tmpRange = [[proxArray objectAtIndex:i] rangeOfString:@"C3:"];  //C3
        
        tmp = [[proxArray objectAtIndex:i] substringFromIndex:(tmpRange.location + tmpRange.length)];
        tmp = [tmp substringToIndex:[tmp rangeOfString:@","].location];
        [C3Array addObject:tmp];
    }
    NSNumber *C0Avg = [C0Array valueForKeyPath:@"@avg.intValue"];
    NSNumber *C1Avg = [C1Array valueForKeyPath:@"@avg.intValue"];
    NSNumber *C2Avg = [C2Array valueForKeyPath:@"@avg.intValue"];
    NSNumber *C3Avg = [C3Array valueForKeyPath:@"@avg.intValue"];
    
    double C0SD = 0;
    double C1SD = 0;
    double C2SD = 0;
    double C3SD = 0;
    C0SD = [self CalculateStdDev2:C0Array :[C0Avg integerValue] :[C0Array count] - 20];
    C1SD = [self CalculateStdDev2:C1Array :[C1Avg integerValue] :[C1Array count] - 20];
    C2SD = [self CalculateStdDev2:C2Array :[C2Avg integerValue] :[C2Array count] - 20];
    C3SD = [self CalculateStdDev2:C3Array :[C3Avg integerValue] :[C3Array count] - 20];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineProx :[NSString stringWithFormat:@"%d",[C3Avg intValue]]];
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineProxSD :[NSString stringWithFormat:@"%.2f",C3SD]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTemp_CS0 :[NSString stringWithFormat:@"%d",[C0Avg intValue]]];
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTempSD_CS0 :[NSString stringWithFormat:@"%.2f",C0SD]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTemp_CS1 :[NSString stringWithFormat:@"%d",[C1Avg intValue]]];
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTempSD_CS1 :[NSString stringWithFormat:@"%.2f",C1SD]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTemp_CS2 :[NSString stringWithFormat:@"%d",[C2Avg intValue]]];
    [TestItemManage setBufferValue:dictKeyDefined :mBaselineTempSD_CS2 :[NSString stringWithFormat:@"%.2f",C2SD]];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
    return ;
    
}

+(void)createCPCl:(NSDictionary *)dictKeyDefined
{
    NSString *mDelta0 = nil;
    NSString *mDelta90 = nil;
    NSString *mDelta180= nil;
    NSString *mProx0 = nil;
    NSString *mProx90 = nil;
    NSString *mProx180 = nil;
    NSString *mBaselineProx = nil;
    NSString *mBaselineTemp = nil;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Delta0"])
			mDelta0 = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Delta90"])
			mDelta90 = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Delta180"])
		{
			mDelta180 = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Prox0"])
		{
			mProx0 = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Prox90"])
		{
			mProx90 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Prox180"])
		{
			mProx180 = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"BaselineProx"])
		{
			mBaselineProx = [dictKeyDefined objectForKey:strKey] ;
			
		}
        else if ([strKey isEqualToString:@"BaselineTemp"])
		{
			mBaselineTemp = [dictKeyDefined objectForKey:strKey] ;
			
		}
    }
    
    mDelta0 = [TestItemManage getBufferValue:dictKeyDefined :mDelta0] ;
    mDelta90 = [TestItemManage getBufferValue:dictKeyDefined :mDelta90] ;
    mDelta180 = [TestItemManage getBufferValue:dictKeyDefined :mDelta180] ;
    mProx0 = [TestItemManage getBufferValue:dictKeyDefined :mProx0] ;
    mProx90 = [TestItemManage getBufferValue:dictKeyDefined :mProx90] ;
    mProx180 = [TestItemManage getBufferValue:dictKeyDefined :mProx180] ;
    mBaselineProx = [TestItemManage getBufferValue:dictKeyDefined :mBaselineProx] ;
    mBaselineTemp = [TestItemManage getBufferValue:dictKeyDefined :mBaselineTemp] ;
    
    double minDelta;
    int criticalPosition;
    NSString *criticalProx = nil;
    if([mDelta0 doubleValue] < [mDelta90 doubleValue])
    {
        minDelta = [mDelta0 doubleValue];
        criticalPosition = 0;
        criticalProx = mProx0;
    }
    else
    {
        minDelta = [mDelta90 doubleValue];
        criticalPosition = 1;
        criticalProx = mProx90;
    }
    if(minDelta < [mDelta180 doubleValue]);
    else
    {
        minDelta = [mDelta180 doubleValue];
        criticalPosition = 2;
        criticalProx = mProx180 ;
    }
    
    //1
    //    NSString *CPClValue = [NSString stringWithFormat:@"0x00%02x0800",criticalPosition];
    NSString *CPClValue = [NSString stringWithFormat:@"0x00000801"];
    //2
    CPClValue = [CPClValue stringByAppendingFormat:@" Checksum"];
    //3
    //    CPClValue = [CPClValue stringByAppendingFormat:@" 0x00001111"];
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x%04x%04x",[criticalProx intValue],[mBaselineProx intValue]];
    //4
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x0104%04x",criticalPosition];
    //5
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x003cfede"];
    //    CPClValue = [CPClValue stringByAppendingFormat:@" 0x0050%04x",[criticalProx intValue]];
    //6
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x000a000f"];
    //    CPClValue = [CPClValue stringByAppendingFormat:@" 0x0105%04x",[mBaselineProx intValue]];
    //7
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x000a0002"];
    //    CPClValue = [CPClValue stringByAppendingFormat:@" 0x%04xfede",[criticalProx intValue]];
    //8
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x01040002"];
    //9
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x00c802ee"];
    //10
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x00610050"];
    //11
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x00000000"];
    //12
    CPClValue = [CPClValue stringByAppendingFormat:@" 0x00000000"];
    
    //CPClValue = @"0x00000801 Checksum 0x267b2647 0x01040002 0x003cfede 0x000a000f 0x000a0002 0x01040002 0x00c802ee 0x00610050 0x00000000 0x00000000";
    
    //CPClValue = @"0x00000801 Checksum 0x3555351d 0x01040002 0x003cfede 0x000a000f 0x000a0002 0x01040002 0x00c802ee 0x00610050 0x00000000 0x00000000";
    
    //get checksum
    NSString *checksum = [CPClValue substringFromIndex:([CPClValue rangeOfString:@"Checksum"].location + [@"Checksum" length])];
    checksum = [checksum stringByReplacingOccurrencesOfString:@"0x" withString:@""];
    checksum = [checksum stringByReplacingOccurrencesOfString:@" " withString:@""];
    long long sum=0;
    
    //for(int i=0; i < ([checksum length]/2); i++)
    while ([checksum length] > 0)
    {
        sum = sum +strtol([[checksum substringToIndex:2] UTF8String],NULL,16);
        checksum = [checksum substringFromIndex:2];
    }
    int iSum = (~sum) + 1;
    NSString *checksumStr = [NSString stringWithFormat:@"%x",iSum];
    if([checksumStr length] > 4)
        checksumStr = [checksumStr substringFromIndex:[checksumStr length] - 4];
    
    
    
    checksum = [NSString stringWithFormat:@"0x%@0030",checksumStr];  //Number of bytes in CPCL is 48
    CPClValue = [CPClValue stringByReplacingOccurrencesOfString:@"Checksum" withString:checksum];
    
    
    [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":CPClValue];
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :CPClValue];
    return;
}

+(void)ParseProxBase:(NSDictionary*)dictKeyDefined
{
	//delete by caijunbo on 2011-10-10
	//don't use global variable for multi-Threads
	/*
	 //added by caijunbo on 2011-09-14
	 //init global gLowestDelta and gIndicator value in free space for each unit.
	 gLowestDelta=100000;
	 gIndicator=-1;
	 g0DegreeProxValue=0;
	 g90DegreeProxValue=0;
	 g180DegreeProxValue=0;
	 */
	//init global gLowestDelta and gIndicator value in free space for each unit.
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue" :[NSString stringWithFormat:@"%d",100000]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator" :[NSString stringWithFormat:@"%d",-1]];
	
	//end
	
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mBufferName = nil;
	NSString *mProjectType = nil;
	
	NSString *mBase_prox_low = nil;
	NSString *mBase_prox_up = nil;
	NSString *mBase_centerpoint_low = nil;
	NSString *mBase_centerpoint_up = nil;
	NSString *mBase_temp_low = nil;
	NSString *mBase_temp_up = nil;
	NSString *mBase_adj_prox_low = nil;
	NSString *mBase_adj_prox_up = nil;
	NSString *mBase_adj_SD_up = nil;
	
	NSString *mReferenceBufferProx=nil;
	NSString *mReferenceBufferCenterpoint=nil;
	NSString *mReferenceBufferTemp=nil;
	
	int iProx_Variation;
	int iCenterpoint_Variation;
	int iTemp_Variation;
	
	int iPBCL;
	int iPBCB;
	int iPBTB;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Prox_Lowlimit"])
		{
			mBase_prox_low = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Prox_Upperlimit"])
		{
			mBase_prox_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Lowlimit"])
		{
			mBase_centerpoint_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Upperlimit"])
		{
			mBase_centerpoint_up = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Temp_Lowlimit"])
		{
			mBase_temp_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Temp_Upperlimit"])
		{
			mBase_temp_up = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Lowlimit"])
		{
			mBase_adj_prox_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Upperlimit"])
		{
			mBase_adj_prox_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_SD_Upperlimit"])
		{
			mBase_adj_SD_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		
		
		//added by caijunbo on 2010-10-17
		else if ([strKey isEqualToString:@"ReferenceBufferProx"])
			mReferenceBufferProx = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferCenterpoint"])
			mReferenceBufferCenterpoint = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferTemp"])
			mReferenceBufferTemp = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Variation"])
			iProx_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
		else if ([strKey isEqualToString:@"Centerpoint_Variation"])
			iCenterpoint_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
		else if ([strKey isEqualToString:@"Temp_Variation"])
			iTemp_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
		/** SCRID-51: Change prox baseline diags-cmd-loop from 600 to 100,change other distant diags-cmd-loop from 10 to 50. **/
		/** Joko 2010-12-23 **/
		else if ([strKey isEqualToString:@"BaseLoop"])
			mBaseCnt = [[dictKeyDefined objectForKey:strKey] intValue];
		/** SCRID-51 end **/
		
		// end
		// serin 20100720 delete
		/*
		 else if ([strKey isEqualToString:@"Base_Temp_Clip_Lowlimit"])
		 mBase_temp_clip_low = [dictKeyDefined objectForKey:strKey] ;
		 
		 else if ([strKey isEqualToString:@"Base_Temp_Clip_Upperlimit"])
		 mBase_temp_clip_up = [dictKeyDefined objectForKey:strKey] ;
		 */
		// end
	}
	
    
	NSMutableArray *BaseProx = nil;
	NSMutableArray *BaseCenterpoint = nil;
	NSMutableArray *BaseTemp = nil;
	NSMutableArray *BaseAdjProx = nil;
	
	// serin 20100720
	NSMutableArray *StageValue = nil;
	NSMutableArray *arrayEachStageValue = [[NSMutableArray alloc] init];
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	//Add by Lucky for grab SOCHOT ERROR
	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
	//Lucky add end
	
	
	//mReferenceBufferValue = @":-) prox --stage all --loops 10 --measure 0	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16415, 32767, 16291, 62268, 47795, 29115, 32322, 31401, 32038, 48013, 7868 - Prox: 44396, Centerpoint: 32767, Temp: 47795, Adjusted_Prox: 11629 1	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32869, 16416, 32771, 16295, 62274, 47794, 29114, 32314, 31397, 32041, 48009, 7876 - Prox: 44394, Centerpoint: 32771, Temp: 47794, Adjusted_Prox: 11623 2	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16414, 32771, 16294, 62268, 47797, 29115, 32319, 31400, 32038, 48020, 7870 - Prox: 44401, Centerpoint: 32771, Temp: 47797, Adjusted_Prox: 11630 3	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16410, 32758, 16289, 62265, 47797, 29117, 32305, 31398, 32037, 48011, 7875 - Prox: 44403, Centerpoint: 32758, Temp: 47797, Adjusted_Prox: 11645 4	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16414, 32768, 16293, 62266, 47792, 29112, 32317, 31400, 32039, 48000, 7870 - Prox: 44391, Centerpoint: 32768, Temp: 47792, Adjusted_Prox: 11623 5	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16417, 32768, 16298, 62263, 47795, 29117, 32310, 31400, 32039, 48012, 7867 - Prox: 44391, Centerpoint: 32768, Temp: 47795, Adjusted_Prox: 11623 6	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16418, 32768, 16291, 62274, 47796, 29113, 32315, 31405, 32035, 48027, 7876 - Prox: 44403, Centerpoint: 32768, Temp: 47796, Adjusted_Prox: 11635 7	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32868, 16410, 32768, 16293, 62269, 47798, 29115, 32322, 31401, 32041, 48007, 7871 - Prox: 44395, Centerpoint: 32768, Temp: 47798, Adjusted_Prox: 11627 8	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16412, 32768, 16292, 62274, 47797, 29111, 32315, 31400, 32039, 48011, 7866 - Prox: 44394, Centerpoint: 32768, Temp: 47797, Adjusted_Prox: 11626 9	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16419, 32770, 16294, 62252, 47792, 29116, 32320, 31400, 32039, 48010, 7865 - Prox: 44389, Centerpoint: 32770, Temp: 47792, Adjusted_Prox: 11619";
    
    //    mReferenceBufferValue = @"prox:		 1026s:476756us (+00s:000000us) = 0: 32455 (0.00) 1: 32460 (0.00) 2: 32486 (0.00) 3: 16074 (0.00) 4: 27617 (0.00) 5: 29289 (0.00) 6: 32671 (0.00) 7: 33385 (0.00) 8: 32469 (0.00) 9: 32465 (0.00) 10: 32463 (0.00) 11: 32461 (0.00) - Prox: 48874, Centerpoint: 32486, Temp: 29289, Adjusted_Prox: 16388 prox:		 1026s:549818us (+00s:073062us) = 0: 32462 (0.00) 1: 32456 (0.00) 2: 32481 (0.00) 3: 16073 (0.00) 4: 27614 (0.00) 5: 29290 (0.00) 6: 32671 (0.00) 7: 33375 (0.00) 8: 32468 (0.00) 9: 32458 (0.00) 10: 32466 (0.00) 11: 32467 (0.00) - Prox: 48870, Centerpoint: 32481, Temp: 29290, Adjusted_Prox: 16389 prox:		 1026s:622870us (+00s:073052us) = 0: 32468 (0.00) 1: 32464 (0.00) 2: 32480 (0.00) 3: 16069 (0.00) 4: 27615 (0.00) 5: 29287 (0.00) 6: 32670 (0.00) 7: 33378 (0.00) 8: 32456 (0.00) 9: 32465 (0.00) 10: 32468 (0.00) 11: 32459 (0.00) - Prox: 48871, Centerpoint: 32480, Temp: 29287, Adjusted_Prox: 16391 prox:		 1026s:695935us (+00s:073065us) = 0: 32468 (0.00) 1: 32460 (0.00) 2: 32485 (0.00) 3: 16070 (0.00) 4: 27619 (0.00) 5: 29288 (0.00) 6: 32666 (0.00) 7: 33379 (0.00) 8: 32468 (0.00) 9: 32460 (0.00) 10: 32460 (0.00) 11: 32457 (0.00) - Prox: 48874, Centerpoint: 32485, Temp: 29288, Adjusted_Prox: 16389 prox:		 1026s:768986us (+00s:073051us) = 0: 32464 (0.00) 1: 32463 (0.00) 2: 32489 (0.00) 3: 16070 (0.00) 4: 27616 (0.00) 5: 29288 (0.00) 6: 32669 (0.00) 7: 33380 (0.00) 8: 32463 (0.00) 9: 32457 (0.00) 10: 32461 (0.00) 11: 32466 (0.00) - Prox: 48878, Centerpoint: 32489, Temp: 29288, Adjusted_Prox: 16389 prox:		 1026s:842053us (+00s:073067us) = 0: 32464 (0.00) 1: 32467 (0.00) 2: 32481 (0.00) 3: 16075 (0.00) 4: 27614 (0.00) 5: 29291 (0.00) 6: 32665 (0.00) 7: 33378 (0.00) 8: 32474 (0.00) 9: 32464 (0.00) 10: 32454 (0.00) 11: 32460 (0.00) - Prox: 48867, Centerpoint: 32481, Temp: 29291, Adjusted_Prox: 16386 prox:		 1026s:915110us (+00s:073057us) = 0: 32455 (0.00) 1: 32470 (0.00) 2: 32477 (0.00) 3: 16070 (0.00) 4: 27616 (0.00) 5: 29285 (0.00) 6: 32673 (0.00) 7: 33380 (0.00) 8: 32466 (0.00) 9: 32461 (0.00) 10: 32459 (0.00) 11: 32466 (0.00) - Prox: 48866, Centerpoint: 32477, Temp: 29285, Adjusted_Prox: 16389 prox:		 1026s:988163us (+00s:073053us) = 0: 32468 (0.00) 1: 32472 (0.00) 2: 32482 (0.00) 3: 16067 (0.00) 4: 27613 (0.00) 5: 29290 (0.00) 6: 32667 (0.00) 7: 33372 (0.00) 8: 32472 (0.00) 9: 32465 (0.00) 10: 32464 (0.00) 11: 32464 (0.00) - Prox: 48879, Centerpoint: 32482, Temp: 29290, Adjusted_Prox: 16397 prox:		 1027s:061221us (+00s:073058us) = 0: 32464 (0.00) 1: 32461 (0.00) 2: 32480 (0.00) 3: 16070 (0.00) 4: 27614 (0.00) 5: 29288 (0.00) 6: 32670 (0.00) 7: 33370 (0.00) 8: 32463 (0.00) 9: 32462 (0.00) 10: 32462 (0.00) 11: 32469 (0.00) - Prox: 48871, Centerpoint: 32480, Temp: 29288, Adjusted_Prox: 16391 prox:		 1027s:134283us (+00s:073062us) = 0: 32466 (0.00) 1: 32463 (0.00) 2: 32489 (0.00) 3: 16073 (0.00) 4: 27615 (0.00) 5: 29286 (0.00) 6: 32668 (0.00) 7: 33376 (0.00) 8: 32456 (0.00) 9: 32471 (0.00) 10: 32466 (0.00) 11: 32474 (0.00) - Prox: 48882, Centerpoint: 32489, Temp: 29286, Adjusted_Prox: 16393 prox:		 1027s:207345us (+00s:073062us) = 0: 32472 (0.00) 1: 32460 (0.00) 2: 32487 (0.00) 3: 16072 (0.00) 4: 27615 (0.00) 5: 29288 (0.00) 6: 32671 (0.00) 7: 33384 (0.00) 8: 32468 (0.00) 9: 32472 (0.00) 10: 32463 (0.00) 11: 32460 (0.00) - Prox: 48877, Centerpoint: 32487, Temp: 29288, Adjusted_Prox: 16390 prox:		 1027s:280403us (+00s:073058us) = 0: 32462 (0.00) 1: 32458 (0.00) 2: 32484 (0.00) 3: 16066 (0.00) 4: 27617 (0.00) 5: 29285 (0.00) 6: 32670 (0.00) 7: 33378 (0.00) 8: 32478 (0.00) 9: 32470 (0.00) 10: 32460 (0.00) 11: 32469 (0.00) - Prox: 48882, Centerpoint: 32484, Temp: 29285, Adjusted_Prox: 16398 prox:		 1027s:353466us (+00s:073063us) = 0: 32458 (0.00) 1: 32469 (0.00) 2: 32479 (0.00) 3: 16071 (0.00) 4: 27616 (0.00) 5: 29290 (0.00) 6: 32670 (0.00) 7: 33377 (0.00) 8: 32468 (0.00) 9: 32458 (0.00) 10: 32466 (0.00) 11: 32472 (0.00) - Prox: 48873, Centerpoint: 32479, Temp: 29290, Adjusted_Prox: 16394 prox:		 1027s:426525us (+00s:073059us) = 0: 32457 (0.00) 1: 32475 (0.00) 2: 32478 (0.00) 3: 16068 (0.00) 4: 27614 (0.00) 5: 29287 (0.00) 6: 32668 (0.00) 7: 33390 (0.00) 8: 32466 (0.00) 9: 32464 (0.00) 10: 32475 (0.00) 11: 32464 (0.00) - Prox: 48874, Centerpoint: 32478, Temp: 29287, Adjusted_Prox: 16396 prox:		 1027s:499588us (+00s:073063us) = 0: 32468 (0.00) 1: 32462 (0.00) 2: 32481 (0.00) 3: 16070 (0.00) 4: 27615 (0.00) 5: 29290 (0.00) 6: 32672 (0.00) 7: 33384 (0.00) 8: 32467 (0.00) 9: 32476 (0.00) 10: 32459 (0.00) 11: 32469 (0.00) - Prox: 48874, Centerpoint: 32481, Temp: 29290, Adjusted_Prox: 16393 prox:		 1027s:572653us (+00s:073065us) = 0: 32469 (0.00) 1: 32457 (0.00) 2: 32485 (0.00) 3: 16070 (0.00) 4: 27615 (0.00) 5: 29284 (0.00) 6: 32672 (0.00) 7: 33380 (0.00) 8: 32455 (0.00) 9: 32467 (0.00) 10: 32461 (0.00) 11: 32462 (0.00) - Prox: 48873, Centerpoint: 32485, Temp: 29284, Adjusted_Prox: 16388 prox:		 1027s:645712us (+00s:073059us) = 0: 32474 (0.00) 1: 32458 (0.00) 2: 32483 (0.00) 3: 16070 (0.00) 4: 27618 (0.00) 5: 29290 (0.00) 6: 32665 (0.00) 7: 33380 (0.00) 8: 32459 (0.00) 9: 32470 (0.00) 10: 32462 (0.00) 11: 32468 (0.00) - Prox: 48877, Centerpoint: 32483, Temp: 29290, Adjusted_Prox: 16394 prox:		 1027s:718775us (+00s:073063us) = 0: 32463 (0.00) 1: 32470 (0.00) 2: 32485 (0.00) 3: 16067 (0.00) 4: 27615 (0.00) 5: 29287 (0.00) 6: 32670 (0.00) 7: 33382 (0.00) 8: 32461 (0.00) 9: 32465 (0.00) 10: 32457 (0.00) 11: 32469 (0.00) - Prox: 48880, Centerpoint: 32485, Temp: 29287, Adjusted_Prox: 16395 prox:		 1027s:791842us (+00s:073067us) = 0: 32462 (0.00) 1: 32465 (0.00) 2: 32483 (0.00) 3: 16069 (0.00) 4: 27615 (0.00) 5: 29287 (0.00) 6: 32667 (0.00) 7: 33373 (0.00) 8: 32467 (0.00) 9: 32457 (0.00) 10: 32468 (0.00) 11: 32460 (0.00) - Prox: 48875, Centerpoint: 32483, Temp: 29287, Adjusted_Prox: 16392 prox:		 1027s:864900us (+00s:073058us) = 0: 32469 (0.00) 1: 32466 (0.00) 2: 32481 (0.00) 3: 16066 (0.00) 4: 27617 (0.00) 5: 29290 (0.00) 6: 32669 (0.00) 7: 33378 (0.00) 8: 32464 (0.00) 9: 32462 (0.00) 10: 32465 (0.00) 11: 32460 (0.00) - Prox: 48876, Centerpoint: 32481, Temp: 29290, Adjusted_Prox: 16395 prox:		 1027s:937961us (+00s:073061us) = 0: 32471 (0.00) 1: 32465 (0.00) 2: 32481 (0.00) 3: 16066 (0.00) 4: 27617 (0.00) 5: 29289 (0.00) 6: 32667 (0.00) 7: 33381 (0.00) 8: 32465 (0.00) 9: 32470 (0.00) 10: 32472 (0.00) 11: 32462 (0.00) - Prox: 48879, Centerpoint: 32481, Temp: 29289, Adjusted_Prox: 16398 prox:		 1028s:011027us (+00s:073066us) = 0: 32466 (0.00) 1: 32459 (0.00) 2: 32480 (0.00) 3: 16070 (0.00) 4: 27616 (0.00) 5: 29287 (0.00) 6: 32669 (0.00) 7: 33384 (0.00) 8: 32467 (0.00) 9: 32474 (0.00) 10: 32467 (0.00) 11: 32462 (0.00) - Prox: 48873, Centerpoint: 32480, Temp: 29287, Adjusted_Prox: 16393 prox:		 1028s:084089us (+00s:073062us) = 0: 32481 (0.00) 1: 32464 (0.00) 2: 32481 (0.00) 3: 16072 (0.00) 4: 27616 (0.00) 5: 29284 (0.00) 6: 32670 (0.00) 7: 33371 (0.00) 8: 32466 (0.00) 9: 32469 (0.00) 10: 32459 (0.00) 11: 32457 (0.00) - Prox: 48874, Centerpoint: 32481, Temp: 29284, Adjusted_Prox: 16393 prox:		 1028s:157154us (+00s:073065us) = 0: 32469 (0.00) 1: 32464 (0.00) 2: 32488 (0.00) 3: 16072 (0.00) 4: 27615 (0.00) 5: 29287 (0.00) 6: 32670 (0.00) 7: 33388 (0.00) 8: 32464 (0.00) 9: 32465 (0.00) 10: 32458 (0.00) 11: 32466 (0.00) - Prox: 48880, Centerpoint: 32488, Temp: 29287, Adjusted_Prox: 16392 prox:		 1028s:230213us (+00s:073059us) = 0: 32471 (0.00) 1: 32464 (0.00) 2: 32483 (0.00) 3: 16068 (0.00) 4: 27616 (0.00) 5: 29287 (0.00) 6: 32669 (0.00) 7: 33373 (0.00) 8: 32471 (0.00) 9: 32457 (0.00) 10: 32472 (0.00) 11: 32460 (0.00) - Prox: 48877, Centerpoint: 32483, Temp: 29287, Adjusted_Prox: 16394 prox:		 1028s:303276us (+00s:073063us) = 0: 32464 (0.00) 1: 32474 (0.00) 2: 32481 (0.00) 3: 16068 (0.00) 4: 27616 (0.00) 5: 29288 (0.00) 6: 32670 (0.00) 7: 33380 (0.00) 8: 32467 (0.00) 9: 32470 (0.00) 10: 32462 (0.00) 11: 32460 (0.00) - Prox: 48878, Centerpoint: 32481, Temp: 29288, Adjusted_Prox: 16397 prox:		 1028s:376338us (+00s:073062us) = 0: 32468 (0.00) 1: 32465 (0.00) 2: 32480 (0.00) 3: 16071 (0.00) 4: 27616 (0.00) 5: 29288 (0.00) 6: 32673 (0.00) 7: 33383 (0.00) 8: 32458 (0.00) 9: 32462 (0.00) 10: 32468 (0.00) 11: 32464 (0.00) - Prox: 48872, Centerpoint: 32480, Temp: 29288, Adjusted_Prox: 16392 prox:		 1028s:449402us (+00s:073064us) = 0: 32465 (0.00) 1: 32460 (0.00) 2: 32480 (0.00) 3: 16066 (0.00) 4: 27614 (0.00) 5: 29287 (0.00) 6: 32668 (0.00) 7: 33378 (0.00) 8: 32463 (0.00) 9: 32459 (0.00) 10: 32469 (0.00) 11: 32461 (0.00) - Prox: 48874, Centerpoint: 32480, Temp: 29287, Adjusted_Prox: 16394 prox:		 1028s:522463us (+00s:073061us) = 0: 32470 (0.00) 1: 32465 (0.00) 2: 32483 (0.00) 3: 16068 (0.00) 4: 27619 (0.00) 5: 29290 (0.00) 6: 32667 (0.00) 7: 33377 (0.00) 8: 32459 (0.00) 9: 32467 (0.00) 10: 32465 (0.00) 11: 32464 (0.00) - Prox: 48877, Centerpoint: 32483, Temp: 29290, Adjusted_Prox: 16394 prox:		 1028s:595531us (+00s:073068us) = 0: 32462 (0.00) 1: 32466 (0.00) 2: 32489 (0.00) 3: 16067 (0.00) 4: 27614 (0.00) 5: 29288 (0.00) 6: 32674 (0.00) 7: 33373 (0.00) 8: 32462 (0.00) 9: 32463 (0.00) 10: 32461 (0.00) 11: 32466 (0.00) - Prox: 48883, Centerpoint: 32489, Temp: 29288, Adjusted_Prox: 16394 prox:		 1028s:668586us (+00s:073055us) = 0: 32462 (0.00) 1: 32470 (0.00) 2: 32479 (0.00) 3: 16070 (0.00) 4: 27619 (0.00) 5: 29289 (0.00) 6: 32671 (0.00) 7: 33385 (0.00) 8: 32465 (0.00) 9: 32461 (0.00) 10: 32457 (0.00) 11: 32467 (0.00) - Prox: 48871, Centerpoint: 32479, Temp: 29289, Adjusted_Prox: 16392 prox:		 1028s:741648us (+00s:073062us) = 0: 32451 (0.00) 1: 32470 (0.00) 2: 32479 (0.00) 3: 16072 (0.00) 4: 27614 (0.00) 5: 29288 (0.00) 6: 32669 (0.00) 7: 33387 (0.00) 8: 32473 (0.00) 9: 32471 (0.00) 10: 32467 (0.00) 11: 32461 (0.00) - Prox: 48869, Centerpoint: 32479, Temp: 29288, Adjusted_Prox: 16390 prox:		 1028s:814709us (+00s:073061us) = 0: 32461 (0.00) 1: 32464 (0.00) 2: 32482 (0.00) 3: 16064 (0.00) 4: 27615 (0.00) 5: 29286 (0.00) 6: 32668 (0.00) 7: 33374 (0.00) 8: 32465 (0.00) 9: 32467 (0.00) 10: 32466 (0.00) 11: 32465 (0.00) - Prox: 48880, Centerpoint: 32482, Temp: 29286, Adjusted_Prox: 16398 prox:		 1028s:887773us (+00s:073064us) = 0: 32467 (0.00) 1: 32460 (0.00) 2: 32483 (0.00) 3: 16070 (0.00) 4: 27614 (0.00) 5: 29286 (0.00) 6: 32666 (0.00) 7: 33380 (0.00) 8: 32459 (0.00) 9: 32466 (0.00) 10: 32457 (0.00) 11: 32465 (0.00) - Prox: 48874, Centerpoint: 32483, Temp: 29286, Adjusted_Prox: 16391 prox:		 1028s:960827us (+00s:073054us) = 0: 32473 (0.00) 1: 32462 (0.00) 2: 32483 (0.00) 3: 16065 (0.00) 4: 27615 (0.00) 5: 29290 (0.00) 6: 32669 (0.00) 7: 33377 (0.00) 8: 32461 (0.00) 9: 32459 (0.00) 10: 32455 (0.00) 11: 32471 (0.00) - Prox: 48879, Centerpoint: 32483, Temp: 29290, Adjusted_Prox: 16396 prox:		 1029s:033885us (+00s:073058us) = 0: 32457 (0.00) 1: 32465 (0.00) 2: 32485 (0.00) 3: 16070 (0.00) 4: 27613 (0.00) 5: 29288 (0.00) 6: 32670 (0.00) 7: 33384 (0.00) 8: 32461 (0.00) 9: 32468 (0.00) 10: 32467 (0.00) 11: 32462 (0.00) - Prox: 48875, Centerpoint: 32485, Temp: 29288, Adjusted_Prox: 16390 prox:		 1029s:106944us (+00s:073059us) = 0: 32451 (0.00) 1: 32467 (0.00) 2: 32479 (0.00) 3: 16071 (0.00) 4: 27614 (0.00) 5: 29288 (0.00) 6: 32670 (0.00) 7: 33380 (0.00) 8: 32467 (0.00) 9: 32454 (0.00) 10: 32465 (0.00) 11: 32460 (0.00) - Prox: 48868, Centerpoint: 32479, Temp: 29288, Adjusted_Prox: 16389 prox:		 1029s:180001us (+00s:073057us) = 0: 32476 (0.00) 1: 32459 (0.00) 2: 32483 (0.00) 3: 16060 (0.00) 4: 27614 (0.00) 5: 29287 (0.00) 6: 32668 (0.00) 7: 33375 (0.00) 8: 32463 (0.00) 9: 32464 (0.00) 10: 32463 (0.00) 11: 32466 (0.00) - Prox: 48885, Centerpoint: 32483, Temp: 29287, Adjusted_Prox: 16402 prox:		 1029s:253065us (+00s:073064us) = 0: 32466 (0.00) 1: 32465 (0.00) 2: 32485 (0.00) 3: 16067 (0.00) 4: 27611 (0.00) 5: 29289 (0.00) 6: 32670 (0.00) 7: 33376 (0.00) 8: 32461 (0.00) 9: 32474 (0.00) 10: 32465 (0.00) 11: 32469 (0.00) - Prox: 48882, Centerpoint: 32485, Temp: 29289, Adjusted_Prox: 16397 prox:		 1029s:326128us (+00s:073063us) = 0: 32467 (0.00) 1: 32459 (0.00) 2: 32484 (0.00) 3: 16070 (0.00) 4: 27616 (0.00) 5: 29288 (0.00) 6: 32671 (0.00) 7: 33379 (0.00) 8: 32467 (0.00) 9: 32468 (0.00) 10: 32460 (0.00) 11: 32467 (0.00) - Prox: 48876, Centerpoint: 32484, Temp: 29288, Adjusted_Prox: 16392 prox:		 1029s:399191us (+00s:073063us) = 0: 32463 (0.00) 1: 32462 (0.00) 2: 32481 (0.00) 3: 16072 (0.00) 4: 27614 (0.00) 5: 29283 (0.00) 6: 32668 (0.00) 7: 33381 (0.00) 8: 32470 (0.00) 9: 32460 (0.00) 10: 32464 (0.00) 11: 32466 (0.00) - Prox: 48872, Centerpoint: 32481, Temp: 29283, Adjusted_Prox: 16391 prox:		 1029s:472253us (+00s:073062us) = 0: 32470 (0.00) 1: 32469 (0.00) 2: 32480 (0.00) 3: 16065 (0.00) 4: 27616 (0.00) 5: 29285 (0.00) 6: 32671 (0.00) 7: 33377 (0.00) 8: 32466 (0.00) 9: 32454 (0.00) 10: 32471 (0.00) 11: 32457 (0.00) - Prox: 48876, Centerpoint: 32480, Temp: 29285, Adjusted_Prox: 16396 prox:		 1029s:545318us (+00s:073065us) = 0: 32469 (0.00) 1: 32466 (0.00) 2: 32481 (0.00) 3: 16072 (0.00) 4: 27616 (0.00) 5: 29285 (0.00) 6: 32669 (0.00) 7: 33376 (0.00) 8: 32466 (0.00) 9: 32460 (0.00) 10: 32466 (0.00) 11: 32464 (0.00) - Prox: 48873, Centerpoint: 32481, Temp: 29285, Adjusted_Prox: 16392 prox:		 1029s:618383us (+00s:073065us) = 0: 32466 (0.00) 1: 32461 (0.00) 2: 32479 (0.00) 3: 16068 (0.00) 4: 27615 (0.00) 5: 29287 (0.00) 6: 32672 (0.00) 7: 33375 (0.00) 8: 32461 (0.00) 9: 32466 (0.00) 10: 32463 (0.00) 11: 32461 (0.00) - Prox: 48871, Centerpoint: 32479, Temp: 29287, Adjusted_Prox: 16392 prox:		 1029s:691444us (+00s:073061us) = 0: 32463 (0.00) 1: 32468 (0.00) 2: 32483 (0.00) 3: 16069 (0.00) 4: 27615 (0.00) 5: 29289 (0.00) 6: 32668 (0.00) 7: 33380 (0.00) 8: 32464 (0.00) 9: 32469 (0.00) 10: 32466 (0.00) 11: 32463 (0.00) - Prox: 48877, Centerpoint: 32483, Temp: 29289, Adjusted_Prox: 16394 prox:		 1029s:764514us (+00s:073070us) = 0: 32468 (0.00) 1: 32468 (0.00) 2: 32488 (0.00) 3: 16067 (0.00) 4: 27618 (0.00) 5: 29287 (0.00) 6: 32670 (0.00) 7: 33381 (0.00) 8: 32461 (0.00) 9: 32463 (0.00) 10: 32465 (0.00) 11: 32469 (0.00) - Prox: 48885, Centerpoint: 32488, Temp: 29287, Adjusted_Prox: 16397 prox:		 1029s:837577us (+00s:073063us) = 0: 32468 (0.00) 1: 32465 (0.00) 2: 32486 (0.00) 3: 16070 (0.00) 4: 27613 (0.00) 5: 29289 (0.00) 6: 32674 (0.00) 7: 33384 (0.00) 8: 32468 (0.00) 9: 32461 (0.00) 10: 32458 (0.00) 11: 32471 (0.00) - Prox: 48881, Centerpoint: 32486, Temp: 29289, Adjusted_Prox: 16395 prox:		 1029s:910641us (+00s:073064us) = 0: 32466 (0.00) 1: 32477 (0.00) 2: 32478 (0.00) 3: 16075 (0.00) 4: 27615 (0.00) 5: 29289 (0.00) 6: 32668 (0.00) 7: 33376 (0.00) 8: 32466 (0.00) 9: 32465 (0.00) 10: 32472 (0.00) 11: 32465 (0.00) - Prox: 48868, Centerpoint: 32478, Temp: 29289, Adjusted_Prox: 16390 prox:		 1029s:983704us (+00s:073063us) = 0: 32462 (0.00) 1: 32469 (0.00) 2: 32482 (0.00) 3: 16068 (0.00) 4: 27611 (0.00) 5: 29287 (0.00) 6: 32670 (0.00) 7: 33381 (0.00) 8: 32464 (0.00) 9: 32461 (0.00) 10: 32463 (0.00) 11: 32460 (0.00) - Prox: 48875, Centerpoint: 32482, Temp: 29287, Adjusted_Prox: 16393 prox:		 1030s:056774us (+00s:073070us) = 0: 32461 (0.00) 1: 32471 (0.00) 2: 32486 (0.00) 3: 16070 (0.00) 4: 27614 (0.00) 5: 29287 (0.00) 6: 32669 (0.00) 7: 33377 (0.00) 8: 32463 (0.00) 9: 32463 (0.00) 10: 32470 (0.00) 11: 32463 (0.00) - Prox: 48881, Centerpoint: 32486, Temp: 29287, Adjusted_Prox: 16395";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		[arrayEachStageValue release]; //henry added to avoid memory leakage 2011-02-22
		return ;
	}
	for (int i = 1; i < 10; i++)
    {
        mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@" %d: ",i] withString:@","];
    }
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 10: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 11: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    
	//added by caijunbo on 2010-10-17
	/*SCRID-8:Proximity Reliability.*/
	/*Mick Modify,2010-10-17*/
	NSString*stationName =[ScriptParse getValueFromSummary:@"ProductLine"];
	if([stationName isEqualToString:@"Reliability"])
	{
		if(mReferenceBufferProx==nil || mReferenceBufferCenterpoint==nil || mReferenceBufferTemp==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Test Script Error!"] ;
			[arrayEachStageValue release]; //henry added to avoid memory leakage 2011-02-22
			return ;
		}
		
		NSString *mReferenceBufferProxValue ;
		NSString *mReferenceBufferCenterpointValue;
		NSString *mReferenceBufferTempValue ;
		
		mReferenceBufferProxValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferProx] ;
		mReferenceBufferCenterpointValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferCenterpoint] ;
		mReferenceBufferTempValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferTemp] ;
		if(mReferenceBufferProxValue==nil || mReferenceBufferCenterpointValue==nil || mReferenceBufferTempValue==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
			[arrayEachStageValue release]; //henry added to avoid memory leakage 2011-02-22
			return ;
		}
		
		iPBCL=strtol([mReferenceBufferProxValue UTF8String], NULL, 16);
		iPBCB=strtol([mReferenceBufferCenterpointValue UTF8String], NULL, 16);
		iPBTB=strtol([mReferenceBufferTempValue UTF8String], NULL, 16);
		
	}
	/*SCRID-8:Modify end*/
	
	// serin 0620 add some criteria
	NSRange rangeCenterpoint = [mReferenceBufferValue rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValue rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		[arrayEachStageValue release]; //henry added to avoid memory leakage 2011-02-22
		return ;
	}
	// end
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
    
	BaseProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"- Prox: "];
	BaseCenterpoint = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Centerpoint: "];
	BaseTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	BaseAdjProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Adjusted_Prox: "];
	//end
	
	//add by judith for improve the exception error 20121201
    if ([mReferenceBufferValue rangeOfString:@"= 0: "].length == 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please Download the Latest Diag which receive data contains string '= 0: '"] ;
		[arrayEachStageValue release];
		return ;
        
    }
    //add ended
	StageValue = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"= 0: "];//modified by judith changed Sensorreading to = 0:
	
	NSRange BaseProxRange = NSMakeRange(0, 5);
	NSRange BaseCenterpointRange = NSMakeRange(0, 5);
	NSRange BaseTempRange = NSMakeRange(0, 5);
	NSRange BaseAdjProxRange = NSMakeRange(0, 5);
	
	// serin 20100720
	NSRange stageLen = [[StageValue objectAtIndex:1] rangeOfString:@" - Prox: "];
	
	NSInteger BaseProxValue=0;
	NSInteger BaseCenterpointValue=0;
	NSInteger BaseTempValue=0;
	NSInteger BaseAdjProxValue=0;
	
	// serin 20100720
	NSMutableString *AllStageValue= [[NSMutableString alloc] init];
    //add by judith for improve the exception error 20121201
	int BaseCount = [BaseProx count];
    int CenterCount = [BaseCenterpoint count];
    int TempCount = [BaseTemp count];
    int AdjCount = [BaseAdjProx count];
    int ProxCount = [StageValue count];
    if (BaseCount > mBaseCnt+1 || CenterCount > mBaseCnt+1 || TempCount > mBaseCnt+1 || AdjCount >mBaseCnt+1 || ProxCount >mBaseCnt+1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"] ;
		[arrayEachStageValue release];
        [AllStageValue release];
		return ;
    }
    //add ended
	for(int i=1 ; i<=mBaseCnt ; i++ )
	{
        //add by judith for improve the exception error 20121201
        NSRange StageValueRange = NSMakeRange(0,stageLen.location);

       if ([[BaseProx objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[BaseCenterpoint objectAtIndex:i] rangeOfString:@","].location < 5 ||
           [[BaseTemp objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[BaseAdjProx objectAtIndex:i] rangeOfString:@","].location < 5 ||
           [[StageValue objectAtIndex:i] rangeOfString:@","].location < 5) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"The Data Length is Less than 5 or %d,Please Check the Data!",StageValueRange.length]] ;
           [arrayEachStageValue release];
           [AllStageValue release];
           return ;
       }
        //add ended
		[BaseProx replaceObjectAtIndex:i
							withObject:[[BaseProx objectAtIndex:i] substringWithRange:BaseProxRange]];
		
		[BaseCenterpoint replaceObjectAtIndex:i
								   withObject:[[BaseCenterpoint objectAtIndex:i] substringWithRange:BaseCenterpointRange]];
		
		[BaseTemp replaceObjectAtIndex:i
							withObject:[[BaseTemp objectAtIndex:i] substringWithRange:BaseTempRange]];
		
		[BaseAdjProx replaceObjectAtIndex:i
							   withObject:[[BaseAdjProx objectAtIndex:i] substringWithRange:BaseAdjProxRange]];
		
		// serin 20100720
		
		[StageValue replaceObjectAtIndex:i
							  withObject:[[StageValue objectAtIndex:i] substringWithRange:StageValueRange]];
		
		BaseProxValue			= BaseProxValue + [[BaseProx objectAtIndex:i]integerValue];
		BaseCenterpointValue	= BaseCenterpointValue + [[BaseCenterpoint objectAtIndex:i]integerValue];
		BaseTempValue			= BaseTempValue + [[BaseTemp objectAtIndex:i]integerValue];
		BaseAdjProxValue		= BaseAdjProxValue + [[BaseAdjProx objectAtIndex:i]integerValue];
		
		// serin 20100720
		[AllStageValue appendString:[StageValue objectAtIndex:i]];
		[AllStageValue appendString:@","];
	}
	
	// ~~~~~~caijunbo 20100721~~~~~~~~~
	NSArray *arrayAllStageValue=nil;
	arrayAllStageValue =[AllStageValue componentsSeparatedByString:@","];
	NSLog(@"arrayAllStageValue = %@",arrayAllStageValue);
	int iAverageValue = 0;
	int StageSD = 0;
	
	// serin 20101006
	int Stage4RefAvg = 0;
	int OffSet = 0;
	
    int MaxValue = 11+(mBaseCnt-1)*12;
	for (int i=0;i<12;i++)
	{
		iAverageValue = 0;
		[arrayEachStageValue removeAllObjects];
        //add by judith for improve the exception error 20121201
        if ([arrayAllStageValue count] < MaxValue)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Sensor Reading Data Count is %d,Less than BaseLoop %d",[arrayAllStageValue count],MaxValue]] ;
            [arrayEachStageValue release];
            [AllStageValue release];
            return ;
            
        }
        //add end
		for(int j=0;j<mBaseCnt;j++)
		{
			iAverageValue+=[[arrayAllStageValue objectAtIndex:(i+j*12)] intValue];
			[arrayEachStageValue addObject:[arrayAllStageValue objectAtIndex:(i+j*12)]];
		}
		
		iAverageValue= iAverageValue/mBaseCnt;
		
		// serin 20101006
		if(i == 4)
			Stage4RefAvg = iAverageValue;
		
		if(i == 2)
			OffSet = iAverageValue;
		
		if(i == 3)
			OffSet = (OffSet - iAverageValue);
		// end
		
        StageSD = [self CalculateStdDev: arrayEachStageValue: iAverageValue:mBaseCnt];
        
		//StageSD = [self CalculateStageStdDev: arrayEachStageValue: iAverageValue:mBaseCnt];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d average",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",iAverageValue]:nil:IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d SD",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",StageSD]:nil:IP_NA:nil];
	}
	
	// serin 20101006
	OffSet= OffSet/4;
	
	[AllStageValue release];
	[arrayEachStageValue release];
	
	double BaseProxAvg			= BaseProxValue / mBaseCnt ;
	double BaseCenterpointAvg	= BaseCenterpointValue / mBaseCnt ;
	double BaseTempAvg			= BaseTempValue / mBaseCnt ;
	double BaseAdjProxAvg		= BaseAdjProxValue / mBaseCnt ;
	double BaseAdjSD				= [self CalculateStdDev: BaseAdjProx: BaseAdjProxAvg:mBaseCnt];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%lf",BaseProxAvg]];
	// serin 20100720 delete
	//NSInteger BaseTrueTemp = 0;
	
	strTestResultForUIinfo = @"";
	
	NSInteger BaseResCnt = 0;
	
	// serin 20100720 delete
	/*
	 BaseTrueTemp = BaseTempAvg;
	 
	 if( (BaseTempAvg < [mBase_temp_low integerValue]) || (BaseTempAvg > [mBase_temp_up integerValue]) )
	 {
	 BaseResCnt++;
	 enumResult =RESULT_FOR_FAIL ;
	 strTestResultForUIinfo = @"Temp Value ;";
	 }
	 else if(BaseTempAvg > [mBase_temp_clip_up integerValue] && BaseTempAvg < [mBase_temp_up integerValue])
	 {
	 //BaseTrueTemp = BaseTempAvg;
	 BaseTempAvg = [mBase_temp_clip_up integerValue] - 10;
	 }
	 else if(BaseTempAvg < [mBase_temp_clip_low integerValue] && BaseTempAvg > [mBase_temp_low integerValue])
	 {
	 //BaseTrueTemp = BaseTempAvg;
	 BaseTempAvg = [mBase_temp_clip_low integerValue] + 10;
	 }
	 else if((BaseTempAvg >= [mBase_temp_clip_low integerValue]) && (BaseTempAvg <= [mBase_temp_clip_up integerValue]))
	 {
	 BaseTrueTemp = BaseTempAvg;
	 }
	 // end
	 */
	// end
	
	NSInteger BaseAdjTemp = BaseTempAvg - BaseCenterpointAvg;
	//Date:2011-01-21  Owner:Helen  Description:show limits on UI when Prox Cal test fail.
	//SCRID:91 Description:Show fail value on UI for Prox cal station by Helen 2011-03-21.
    
    if((mBase_prox_low == nil) && (mBase_prox_up == nil))
    {
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%f;",BaseProxAvg]];
    }
    else
    {
        if( BaseProxAvg < [mBase_prox_low integerValue] || BaseProxAvg > [mBase_prox_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%f [ %@ , %@ ];",BaseProxAvg,mBase_prox_low,mBase_prox_up]];
        }
    }
    if((mBase_centerpoint_low == nil) && (mBase_centerpoint_up == nil))
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%f;",BaseCenterpointAvg]];
    }
    else
    {
        if( BaseCenterpointAvg < [mBase_centerpoint_low integerValue] || BaseCenterpointAvg > [mBase_centerpoint_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%f [ %@ , %@ ];",BaseCenterpointAvg,mBase_centerpoint_low,mBase_centerpoint_up]];
        }
	}
    if((mBase_temp_low == nil) && (mBase_temp_up == nil))
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%f;",BaseTempAvg]];
    }
    else
    {
        if( BaseTempAvg < [mBase_temp_low integerValue] || BaseTempAvg > [mBase_temp_up integerValue])
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%f [ %@ , %@ ];",BaseTempAvg,mBase_temp_low,mBase_temp_up]];
        }
	}
	//if( BaseAdjProxAvg < [mBase_adj_prox_low integerValue] || BaseAdjProxAvg > [mBase_adj_prox_up integerValue])
	//{
	//	BaseResCnt++;
	//	enumResult =RESULT_FOR_FAIL ;
	//	strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Adj Prox Value:%d [ %@ , %@ ];",BaseAdjProxAvg,mBase_adj_prox_low,mBase_adj_prox_up]];
	//}
    if(mBase_adj_SD_up == nil)
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%f;",BaseAdjSD]];
    }
    else
    {
        if( BaseAdjSD > [mBase_adj_SD_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%f [ >= %@ ];",BaseAdjSD,mBase_adj_SD_up]];
        }
    }
	//SCRID:91 end.
	//end
	
	// modified by caijunbo on 2011-10-10
	/*
	 ProxParaBaseProx = BaseProxAvg;
	 
	 
	 ProxParaBaseCenterpoint = BaseCenterpointAvg;
	 ProxParaBaseTemp = BaseTempAvg;
	 ProxParaBaseAdjProx = BaseAdjProxAvg;
	 ProxParaBaseAdjSD = BaseAdjSD;
	 */
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue":[NSString stringWithFormat:@"%f",BaseProxAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineCenterpointAverageValue":[NSString stringWithFormat:@"%f",BaseCenterpointAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineTemperatureAverageValue":[NSString stringWithFormat:@"%f",BaseTempAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineAdjustProximityAverageValue":[NSString stringWithFormat:@"%f",BaseAdjProxAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximitySDValue":[NSString stringWithFormat:@"%f",BaseAdjSD]];
	
	// end
	
	//added by caijunbo on 2010-10-17 for Reliability
	if([stationName isEqualToString:@"Reliability"])
	{
		if ( BaseProxAvg<(iPBCL-iProx_Variation)||BaseProxAvg > (iPBCL+iProx_Variation) )
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBCl Value ;"];
			
		}
		
		
		if ( BaseCenterpointAvg<(iPBCB-iCenterpoint_Variation)||BaseCenterpointAvg > (iPBCB+iCenterpoint_Variation))
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBCb Value ;"];
			
		}
		
		
		if ( BaseTempAvg<(iPBTB-iTemp_Variation)||BaseTempAvg>(iPBTB+iTemp_Variation) )
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBTb Value ;"];
			
		}
		
	}
	
	//end
	
	// serin 20100601
	if(BaseResCnt == 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
		
		/*
		 write baselineProx to PBCl
		 write baselineCenterpoint to PBCb
		 write baselineTemp to PBTb
		 */
		
		// set prox param that write back into sysconfig
		[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%f",BaseProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%f",BaseCenterpointAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%f",BaseTempAvg]];
		
		// serin 20100721 delete
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxTrueTemp Value":[NSString stringWithFormat:@"%d",BaseTrueTemp]];
		
		// for ParseProx
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%ld",(long)BaseAdjTemp]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%f",BaseAdjProxAvg]];
		
		
		// added by caijunbo on 20101010
		/*
		 int iSum=BaseProxAvg+BaseCenterpointAvg+2*BaseTempAvg;
		 int iCheckSum;
		 NSString *p=[NSString stringWithFormat:@"%d",iSum];
		 unsigned const char* buf=[p UTF8String];
		 int len=strlen(buf);
		 crcInit();
		 iCheckSum=crcFast(buf,len);
		 printf("the crc of %d is 0x%X",iSum,iCheckSum);
		 */
		//end
		
		// serin 20101006
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp1 Value":[NSString stringWithFormat:@"%f",BaseTempAvg]];
		
		// serin 20101117
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d",0,0,0,iCheckSum,OffSet,2812,1028,0,Stage4RefAvg]];
		/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",512,0,32,0,OffSet,8173,5603,4,0,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65386,46000,80,800]];
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",768,0,32,0,OffSet,8173,5603,4,45220,65535,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65296,42000,80,550]];
		//end
		
		//SCRID:72 Modify Proximity to change syscfg key CPCl value
		//Modified by caijunbo on 2011-01-29
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1024,0,32,0,OffSet,8173,5603,4,47186,65535,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65316,42000,80,550]];
		//end
		//SCRID: Modify Proximity to change syscfg key CPCl value
		//Modified by caijunbo on 2011-04-28
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1280,0,32,0,OffSet,3082,0,4,0,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65316,42000,80,800]];
		//end
		//Modified by caijunbo on 2011-05-21
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1281,0,32,0,OffSet,3318,3318,4,20316,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65245,42000,80,550]];
		//end
		
		//Modified by Helen 20110715
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1281,0,32,0,OffSet,3318,3318,4,30147,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65251,42000,80,550]];
		//end
		
		//Modified by Helen 2011-09-13
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1282,0,32,0,OffSet,3318,3318,4,33423,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65301,42000,80,550]];
		//end
		
		//SCRID:2	Modified by Ray 2011-11-08
		/*
		 if([mProjectType isEqualToString:@"OnlyQL2"])
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,30802,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65260,42000,80,550]];
		 else
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,45875,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65248,42000,80,550]];
		 */
		//SCRID:2	end
		
		//SCRID:3	Modified Limit for PVT by Ray 2011-12-08
		/*if([mProjectType isEqualToString:@"OnlyQL2"])
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,30801,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,261,65246,42000,80,550]];
		 else
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,42598,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,226,65246,42000,80,550]];
         */
		//SCRID:3	end
        
        //Modified Limit for EVT by Henry 2012-04-26
        //Modified the CPCl key 1795/2303/2303 by judith 20130129
		if([mProjectType isEqualToString:@"OnlyRL2"])
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %f %f %f %d %d %d %d %d %d %d %d %d %d %d",1796,0,48,0,OffSet,1790,1790,4,39322,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,60,261,65246,65000,80,550,0,0,0,0]];    //Modified by judith 20130301
            //NSLog(@"this is Base OnlyQL2 60261 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
		else
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %f %f %f %d %d %d %d %d %d %d %d %d %d %d",1795,0,48,0,OffSet,2303,2303,4,39322,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,60,261,65246,42000,80,550,0,0,0,0]];
            //NSLog(@"this is Base else OnlyQL2 60261 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
		//end
	}
	
	// serin 2010-11-30 add
	else
	{
		// set prox param that write back into sysconfig
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%d",0]];
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%d",0]];
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%d",0]];
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%d",0]];
		//[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%d",0]];
		[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%f",BaseProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%f",BaseCenterpointAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%f",BaseTempAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%ld",(long)BaseAdjTemp]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%f",BaseAdjProxAvg]];
		/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",768,0,32,0,OffSet,8173,5603,4,45220,65535,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65296,42000,80,550]];
		//end
		//SCRID:72 Modify Proximity to change syscfg key CPCl value
		//Modified by Junbo 2011-09-13
		//[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1282,0,32,0,OffSet,3318,3318,4,33423,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65301,42000,80,550]];
		//end
		
		//SCRID:2	Modified by Ray 2011-11-08
		/*
		 if([mProjectType isEqualToString:@"OnlyQL2"])
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,30802,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65260,42000,80,550]];
		 else
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,45875,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,0,65248,42000,80,550]];
		 */
		//SCRID:2	end
		
		//SCRID:3	Modified Limit for PVT by Ray 2011-12-08
		/*if([mProjectType isEqualToString:@"OnlyQL2"])
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,30801,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,261,65246,42000,80,550]];
		 else
		 [TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1283,0,32,0,OffSet,3318,3318,4,42598,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,Stage4RefAvg,226,65246,42000,80,550]];
		 */
		//SCRID:3	end
        
        //Modified Limit for EVT by Henry 2012-04-26
        //Modified the CPCl key 1795/2303/2303 by judith 20130129
		if([mProjectType isEqualToString:@"OnlyRL2"])
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %f %f %f %d %d %d %d %d %d %d %d %d %d %d",1796,0,48,0,OffSet,1790,1790,4,39322,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,60,261,65246,65000,80,550,0,0,0,0]];    //Modified by judith 20130301
            //NSLog(@"this is Base OnlyQL2 70261 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
		else
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %f %f %f %d %d %d %d %d %d %d %d %d %d %d",1795,0,40,0,OffSet,2303,2303,4,36700,0,BaseProxAvg,BaseCenterpointAvg,BaseTempAvg,0,70,226,65246,42000,80,550,33423,0,0,0]];
            //NSLog(@"this is base else OnlyQL2 70226 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
    }
	// end
	
	// set pudding data
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Prox":nil:mBase_prox_low:mBase_prox_up:[NSString stringWithFormat:@"%f",BaseProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Centerpoint":nil:mBase_centerpoint_low:mBase_centerpoint_up:[NSString stringWithFormat:@"%f",BaseCenterpointAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Temp":nil:mBase_temp_low:mBase_temp_up:[NSString stringWithFormat:@"%f",BaseTempAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Prox":nil:mBase_adj_prox_low:mBase_adj_prox_up:[NSString stringWithFormat:@"%f",BaseAdjProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_SD":nil:nil:mBase_adj_SD_up:[NSString stringWithFormat:@"%f",BaseAdjSD]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Temp":nil:nil:nil:[NSString stringWithFormat:@"%ld",(long)BaseAdjTemp]:nil:IP_NA:nil];
	//set pudding data for EVT by Henry 2012-04-26
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"CPCL_SW_Version":nil:nil:nil:@"0703":nil:IP_NA:nil];
    //end
	// serin 20100721 delete
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_True_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",BaseTrueTemp]:nil:IP_NA:nil];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
}
//jake add for QT4 --20130830
// sample prox 50 times, and get the last 30 times to calculate -----delete by Annie 2014.3.10
/*
+(void)ParseProxBaseForQT4:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mBufferName = nil;
    
    NSString *mBufferName_avgBaselineProxCS3 = nil;
    NSString *mBufferName_avgBaselineTempCS0 = nil;
    NSString *mBufferName_avgBaselineTempCS1 = nil;
    NSString *mBufferName_avgBaselineTempCS2 = nil;
    NSString *mBufferName_avgBaselineProxCS3SD = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
        {
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BaseLoop"])
        {
			mBaseCnt = [[dictKeyDefined objectForKey:strKey] intValue];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineProxCS3"])
        {
			mBufferName_avgBaselineProxCS3 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS0"])
        {
			mBufferName_avgBaselineTempCS0 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS1"])
        {
			mBufferName_avgBaselineTempCS1 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS2"])
        {
			mBufferName_avgBaselineTempCS2 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineProxCS3SD"])
        {
			mBufferName_avgBaselineProxCS3SD = [dictKeyDefined objectForKey:strKey];
        }
        
        
	}
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS0:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS1:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS2:nil];
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Prox test log.rtf" encoding:NSASCIIStringEncoding error:nil] ;
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    
    NSArray *BaseProxArray = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    
    long long sumBaselineProxCS3 = 0;
    long long sumBaselineTempCS0 = 0;
    long long sumBaselineTempCS1 = 0;
    long long sumBaselineTempCS2 = 0;
     

    
    if ([BaseProxArray count] < 25)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change 1"] ;
		return ;
	}
    
    for(int i=21; i<[BaseProxArray count]; i++) //get last 30 sample data
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        NSString *BaselineTempCS0 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C0:" Postfix:@","];
        
        NSString *BaselineTempCS1 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C1:" Postfix:@","];
        
        NSString *BaselineTempCS2 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C2:" Postfix:@","];
        
        sumBaselineProxCS3 += [BaselineProxCS3 intValue];
        sumBaselineTempCS0 += [BaselineTempCS0 intValue];
        sumBaselineTempCS1 += [BaselineTempCS1 intValue];
        sumBaselineTempCS2 += [BaselineTempCS2 intValue];
    }
    
    
    double avgBaselineProxCS3 = (double)sumBaselineProxCS3 / (double)([BaseProxArray count]-21);
    double avgBaselineTempCS0 = (double)sumBaselineTempCS0 / (double)([BaseProxArray count]-21);
    double avgBaselineTempCS1 = (double)sumBaselineTempCS1 / (double)([BaseProxArray count]-21);
    double avgBaselineTempCS2 = (double)sumBaselineTempCS2 / (double)([BaseProxArray count]-21);
    
    
    double sqrtSum=0;
    for(int i=21; i<[BaseProxArray count]; i++)
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        double tmpVal = [BaselineProxCS3 intValue] - avgBaselineProxCS3;
        
        sqrtSum += (tmpVal*tmpVal);
    
    }
	double  avgBaselineProxCS3SD = (pow((sqrtSum / ([BaseProxArray count]-21)),0.5));
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",avgBaselineProxCS3]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3:[NSString stringWithFormat:@"%f",avgBaselineProxCS3]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS0:[NSString stringWithFormat:@"%f",avgBaselineTempCS0]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS1:[NSString stringWithFormat:@"%f",avgBaselineTempCS1]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS2:[NSString stringWithFormat:@"%f",avgBaselineTempCS2]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3SD:[NSString stringWithFormat:@"%f",avgBaselineProxCS3SD]];
    
    
   
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
	
    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%lf",BaseProxAvg]];
//    
//    [TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue":[NSString stringWithFormat:@"%f",BaseProxAvg]];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineCenterpointAverageValue":[NSString stringWithFormat:@"%f",BaseCenterpointAvg]];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineTemperatureAverageValue":[NSString stringWithFormat:@"%f",BaseTempAvg]];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProxSDValue":[NSString stringWithFormat:@"%f",BaseProxSD]];
    
}
 */
// sample prox 22 times, and get the last 11 times to calculate
// add by Annie 2014.3.10, request by AA Terry
+(void)ParseProxBaseForQT4:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mBufferName = nil;
    
    NSString *mBufferName_avgBaselineProxCS3 = nil;
    NSString *mBufferName_avgBaselineTempCS0 = nil;
    NSString *mBufferName_avgBaselineTempCS1 = nil;
    NSString *mBufferName_avgBaselineTempCS2 = nil;
    NSString *mBufferName_avgBaselineProxCS3SD = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
        {
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BaseLoop"])
        {
			mBaseCnt = [[dictKeyDefined objectForKey:strKey] intValue];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineProxCS3"])
        {
			mBufferName_avgBaselineProxCS3 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS0"])
        {
			mBufferName_avgBaselineTempCS0 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS1"])
        {
			mBufferName_avgBaselineTempCS1 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineTempCS2"])
        {
			mBufferName_avgBaselineTempCS2 = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferName_avgBaselineProxCS3SD"])
        {
			mBufferName_avgBaselineProxCS3SD = [dictKeyDefined objectForKey:strKey];
        }
        
        
	}
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS0:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS1:nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS2:nil];
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Prox test log.rtf" encoding:NSASCIIStringEncoding error:nil] ;
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    
    NSArray *BaseProxArray = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    
    long long sumBaselineProxCS3 = 0;
    long long sumBaselineTempCS0 = 0;
    long long sumBaselineTempCS1 = 0;
    long long sumBaselineTempCS2 = 0;
    
    
    
    if ([BaseProxArray count] < 10)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change 1"] ;
		return ;
	}
    
    for(int i=11; i<[BaseProxArray count]; i++) //get last 11 sample data
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        NSString *BaselineTempCS0 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C0:" Postfix:@","];
        
        NSString *BaselineTempCS1 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C1:" Postfix:@","];
        
        NSString *BaselineTempCS2 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C2:" Postfix:@","];
        
        sumBaselineProxCS3 += [BaselineProxCS3 intValue];
        sumBaselineTempCS0 += [BaselineTempCS0 intValue];
        sumBaselineTempCS1 += [BaselineTempCS1 intValue];
        sumBaselineTempCS2 += [BaselineTempCS2 intValue];
    }
    
    
    double avgBaselineProxCS3 = (double)sumBaselineProxCS3 / (double)([BaseProxArray count]-11);
    double avgBaselineTempCS0 = (double)sumBaselineTempCS0 / (double)([BaseProxArray count]-11);
    double avgBaselineTempCS1 = (double)sumBaselineTempCS1 / (double)([BaseProxArray count]-11);
    double avgBaselineTempCS2 = (double)sumBaselineTempCS2 / (double)([BaseProxArray count]-11);
    
    
    double sqrtSum=0;
    for(int i=11; i<[BaseProxArray count]; i++)
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        double tmpVal = [BaselineProxCS3 intValue] - avgBaselineProxCS3;
        
        sqrtSum += (tmpVal*tmpVal);
        
    }
	double  avgBaselineProxCS3SD = (pow((sqrtSum / ([BaseProxArray count]-11)),0.5));
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%f",avgBaselineProxCS3]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3:[NSString stringWithFormat:@"%f",avgBaselineProxCS3]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS0:[NSString stringWithFormat:@"%f",avgBaselineTempCS0]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS1:[NSString stringWithFormat:@"%f",avgBaselineTempCS1]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineTempCS2:[NSString stringWithFormat:@"%f",avgBaselineTempCS2]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName_avgBaselineProxCS3SD:[NSString stringWithFormat:@"%f",avgBaselineProxCS3SD]];
    
    
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
	
    
    //	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%lf",BaseProxAvg]];
    //
    //    [TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue":[NSString stringWithFormat:@"%f",BaseProxAvg]];
    //
    //	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineCenterpointAverageValue":[NSString stringWithFormat:@"%f",BaseCenterpointAvg]];
    //
    //	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineTemperatureAverageValue":[NSString stringWithFormat:@"%f",BaseTempAvg]];
    //
    //	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProxSDValue":[NSString stringWithFormat:@"%f",BaseProxSD]];
    
}

// sample prox 50 times, and get the last 30 times to calculate -----delete by Annie 2014.3.10 for new request by AA Terry
/*
+(void)ParseProxSusParam:(NSDictionary*)dictKeyDefined
{
    //NSString *strTestResultForUIinfo = @""; //20100727
	//enum TestResutStatus enumResult ;
	
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferName1 = nil;
    NSString *mBufferNameAvg = nil;
    NSString *mBufferNameMin = nil;
    NSString *mBufferNameMax = nil;
    NSString *mBufferNameSwing = nil;
    NSString *mBufferNameDelta = nil;
    NSString *mBufferNameDev = nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameAvg"])
			mBufferNameAvg = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMin"])
			mBufferNameMin = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMax"])
			mBufferNameMax = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameSwing"])
			mBufferNameSwing = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDelta"])
			mBufferNameDelta = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDev"])
			mBufferNameDev = [dictKeyDefined objectForKey:strKey] ;
    }
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameAvg :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMin :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMax :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameSwing :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDelta :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDev :nil];
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Prox test log.rtf" encoding:NSASCIIStringEncoding error:nil] ;;
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    
    
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change"] ;
		return ;
	}
    
    NSArray *BaseProxArray = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    
    long long sumBaselineProxCS3 = 0;
    
    
    if ([BaseProxArray count] < 25)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change 1"] ;
		return ;
	}
    
    double proxMin=123456789;
    double proxMax=0;
    
    for(int i=21; i<[BaseProxArray count]; i++) //get last 30 sample
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        if([BaselineProxCS3 doubleValue] < proxMin)
            proxMin = [BaselineProxCS3 doubleValue];
        if([BaselineProxCS3 doubleValue] > proxMax)
            proxMax = [BaselineProxCS3 doubleValue];
        
        sumBaselineProxCS3 += [BaselineProxCS3 intValue];
        
    }
    double proxSwing = proxMax-proxMin;
    
    double avgBaselineProxCS3 = (double)sumBaselineProxCS3 / (double)([BaseProxArray count]-21);
    
    double proxAvg = avgBaselineProxCS3;
    double proxDelta = proxAvg - [mReferenceBufferValue1 doubleValue];
    
    double sqrtSum=0;
    for(int i=21; i<[BaseProxArray count]; i++)
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        double tmpVal = [BaselineProxCS3 intValue] - avgBaselineProxCS3;
        
        sqrtSum += (tmpVal*tmpVal);
        
    }
	double  proxStdDevDon = (pow((sqrtSum / ([BaseProxArray count]-21)),0.5));
    
    
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameAvg :[NSString stringWithFormat:@"%lf",proxAvg]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMin :[NSString stringWithFormat:@"%lf",proxMin]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMax :[NSString stringWithFormat:@"%lf",proxMax]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameSwing :[NSString stringWithFormat:@"%lf",proxSwing]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDelta :[NSString stringWithFormat:@"%lf",proxDelta]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDev :[NSString stringWithFormat:@"%lf",proxStdDevDon]];
    
    return ;
}
*/

// sample prox 11 times, and get the last 11 times to calculate
// add by Annie 2014.3.10, request by AA Terry
+(void)ParseProxSusParam:(NSDictionary*)dictKeyDefined
{
    //NSString *strTestResultForUIinfo = @""; //20100727
	//enum TestResutStatus enumResult ;
	
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferName1 = nil;
    NSString *mBufferNameAvg = nil;
    NSString *mBufferNameMin = nil;
    NSString *mBufferNameMax = nil;
    NSString *mBufferNameSwing = nil;
    NSString *mBufferNameDelta = nil;
    NSString *mBufferNameDev = nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameAvg"])
			mBufferNameAvg = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMin"])
			mBufferNameMin = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMax"])
			mBufferNameMax = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameSwing"])
			mBufferNameSwing = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDelta"])
			mBufferNameDelta = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDev"])
			mBufferNameDev = [dictKeyDefined objectForKey:strKey] ;
    }
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameAvg :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMin :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMax :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameSwing :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDelta :nil];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDev :nil];
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    
    NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    
    //mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Prox test log.rtf" encoding:NSASCIIStringEncoding error:nil] ;;
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    
    
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change"] ;
		return ;
	}
    
    NSArray *BaseProxArray = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    
    long long sumBaselineProxCS3 = 0;
    
    
    if ([BaseProxArray count] < 10)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"data format change 1"] ;
		return ;
	}
    
    double proxMin=123456789;
    double proxMax=0;
    
    for(int i=1; i<[BaseProxArray count]; i++) //get 11 sample
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        if([BaselineProxCS3 doubleValue] < proxMin)
            proxMin = [BaselineProxCS3 doubleValue];
        if([BaselineProxCS3 doubleValue] > proxMax)
            proxMax = [BaselineProxCS3 doubleValue];
        
        sumBaselineProxCS3 += [BaselineProxCS3 intValue];
        
    }
    double proxSwing = proxMax-proxMin;
    
    //double avgBaselineProxCS3 = (double)sumBaselineProxCS3 / (double)([BaseProxArray count]-21);
    double avgBaselineProxCS3 = (double)sumBaselineProxCS3 / (double)([BaseProxArray count]-1); //2014.3.8 by Annie
    
    double proxAvg = avgBaselineProxCS3;
    double proxDelta = proxAvg - [mReferenceBufferValue1 doubleValue];
    
    double sqrtSum=0;
    for(int i=1; i<[BaseProxArray count]; i++)
    {
        NSString *tmp = [BaseProxArray objectAtIndex:i];
        
        NSString *BaselineProxCS3 = [ToolFun getStrFromPrefixAndPostfix:tmp Prefix:@"[C3:" Postfix:@","];
        
        double tmpVal = [BaselineProxCS3 intValue] - avgBaselineProxCS3;
        
        sqrtSum += (tmpVal*tmpVal);
        
    }
	double  proxStdDevDon = (pow((sqrtSum / ([BaseProxArray count])),0.5));
    
    
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameAvg :[NSString stringWithFormat:@"%lf",proxAvg]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMin :[NSString stringWithFormat:@"%lf",proxMin]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMax :[NSString stringWithFormat:@"%lf",proxMax]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameSwing :[NSString stringWithFormat:@"%lf",proxSwing]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDelta :[NSString stringWithFormat:@"%lf",proxDelta]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDev :[NSString stringWithFormat:@"%lf",proxStdDevDon]];
    
    return ;
}


//blake add to try new sensor --20130816 --start
+(void)ParseProxBase_NewSensor:(NSDictionary*)dictKeyDefined
{
    [TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue" :[NSString stringWithFormat:@"%d",100000]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator" :[NSString stringWithFormat:@"%d",-1]];
    
	NSMutableArray *ProxArray = [[NSMutableArray alloc] init];
    NSMutableArray *AvgArray = [[NSMutableArray alloc] init];
    NSMutableArray *OffsetArray = [[NSMutableArray alloc] init];
	//end
	
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mBufferName = nil;
	NSString *mProjectType = nil;
	
	NSString *mBase_prox_low = nil;
	NSString *mBase_prox_up = nil;
    //NSString *mBase_SD_low = nil;
	NSString *mBase_SD_up = nil;
	
	NSString *mReferenceBufferProx=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Prox_Lowlimit"])
		{
			mBase_prox_low = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Prox_Upperlimit"])
		{
			mBase_prox_up = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Base_SD_Upperlimit"])
		{
			mBase_SD_up = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferProx"])
			mReferenceBufferProx = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"BaseLoop"])
			mBaseCnt = [[dictKeyDefined objectForKey:strKey] intValue];
        
	}
    
    //    NSString *mSourceValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    //    if (mSourceValue == nil)
    //    {
    //        enumResult = RESULT_FOR_FAIL;
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"no receive date!" ];
    //        [ProxArray release];
    //        [AvgArray release];
    //        [OffsetArray release];
    //        return;
    //    }
    //    NSArray *SourceArray = [mSourceValue componentsSeparatedByString:@"output format = abstime : samplenumber : sensorid : use : avg : diff : offset" ];
    //    if ([SourceArray count] < 3)
    //    {
    //        enumResult = RESULT_FOR_FAIL;
    //        [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"diag return no enough data!"];
    //        [ProxArray release];
    //        [AvgArray release];
    //        [OffsetArray release];
    //        return;
    //    }
    //    NSString *mReferenceBufferValue = [SourceArray objectAtIndex:2];
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    //        mReferenceBufferValue = @"1970.1.1.0.36.55  		  : 1 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 2 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 3 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 4 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 5 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 6 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 7 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 8 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 9 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 10 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 11 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 12 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 13 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 14 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 15 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 16 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 17 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 18 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 19 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.55  		  : 20 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 21 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 22 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 23 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 24 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 25 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 26 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 27 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 28 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 29 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 30 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 31 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 32 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 33 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 34 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 35 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 36 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 37 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 38 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 39 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 40 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 41 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 42 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 43 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 44 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 45 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 46 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 47 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 48 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 49 : 3 : 333 : 250 : 88 : 0  1970.1.1.0.36.56  		  : 50 : 3 : 333 : 250 : 88 : 0 ";
    //    mReferenceBufferValue = @"2013.8.26.20.54.6  		  : 1 : 2 : 176 : 175 : 0 : 361  2013.8.26.20.54.6  		  : 2 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.7  		  : 3 : 2 : 175 : 176 : 0 : 361  2013.8.26.20.54.7  		  : 4 : 2 : 176 : 176 : 0 : 361  2013.8.26.20.54.7  		  : 5 : 2 : 176 : 175 : 0 : 361  2013.8.26.20.54.7  		  : 6 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.7  		  : 7 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.7  		  : 8 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 9 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 10 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 11 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 12 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 13 : 2 : 174 : 175 : 0 : 361  2013.8.26.20.54.8  		  : 14 : 2 : 173 : 173 : 0 : 361  2013.8.26.20.54.8  		  : 15 : 2 : 173 : 173 : 0 : 361  2013.8.26.20.54.9  		  : 16 : 2 : 173 : 173 : 0 : 361  2013.8.26.20.54.9  		  : 17 : 2 : 175 : 176 : 0 : 361  2013.8.26.20.54.9  		  : 18 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.9  		  : 19 : 2 : 176 : 174 : 0 : 361  2013.8.26.20.54.9  		  : 20 : 2 : 176 : 175 : 0 : 361  2013.8.26.20.54.9  		  : 21 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.10  		  : 22 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.10  		  : 23 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.10  		  : 24 : 2 : 174 : 175 : 0 : 361  2013.8.26.20.54.10  		  : 25 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.10  		  : 26 : 2 : 175 : 176 : 0 : 361  2013.8.26.20.54.10  		  : 27 : 2 : 175 : 174 : 0 : 361  2013.8.26.20.54.11  		  : 28 : 2 : 173 : 173 : 0 : 361  2013.8.26.20.54.11  		  : 29 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.11  		  : 30 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.11  		  : 31 : 2 : 175 : 175 : 0 : 361  2013.8.26.20.54.11  		  : 32 : 2 : 175 : 174 : 0 : 361  2013.8.26.20.54.11  		  : 33 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.12  		  : 34 : 2 : 174 : 173 : 0 : 361  2013.8.26.20.54.12  		  : 35 : 2 : 173 : 173 : 0 : 361  2013.8.26.20.54.12  		  : 36 : 2 : 174 : 174 : 0 : 361  2013.8.26.20.54.12  		  : 37 : 2 : 171 : 170 : 0 : 361  2013.8.26.20.54.12  		  : 38 : 2 : 169 : 169 : 0 : 361  2013.8.26.20.54.12  		  : 39 : 2 : 169 : 169 : 0 : 361  2013.8.26.20.54.13  		  : 40 : 2 : 169 : 169 : 0 : 361  2013.8.26.20.54.13  		  : 41 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.13  		  : 42 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.13  		  : 43 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.13  		  : 44 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.13  		  : 45 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.13  		  : 46 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.14  		  : 47 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.14  		  : 48 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.14  		  : 49 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.14  		  : 50 : 2 : 168 : 167 : 0 : 361";
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    
    NSString *abstime = [mReferenceBufferValue substringToIndex:15];
    if (abstime==nil) {
        enumResult = RESULT_FOR_FAIL;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"diag return error!" ];
        [ProxArray release];
        [AvgArray release];
        [OffsetArray release];
        return;
    }
    NSArray *bufferArray = [mReferenceBufferValue componentsSeparatedByString:abstime];
    for (int i = 1; i < [bufferArray count]; i++)
    {
        NSArray *arrayTmp= [[bufferArray objectAtIndex:i] componentsSeparatedByString:@" : "];
        if ([arrayTmp count] < 7)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diag return different data format error!" ];
            [ProxArray removeAllObjects];
            [AvgArray removeAllObjects];
            [OffsetArray removeAllObjects];
            [ProxArray release];
            [AvgArray release];
            [OffsetArray release];
            return;
        }
        [ProxArray addObject:[arrayTmp objectAtIndex:3]];
        [AvgArray addObject:[arrayTmp objectAtIndex:4]];
        [OffsetArray addObject:[arrayTmp objectAtIndex:6]];
    }
    NSInteger BaseProxValue = 0;
    int baseProxCnt = [ProxArray count];
    if (baseProxCnt > mBaseCnt + 1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"];
        [ProxArray removeAllObjects];
        [AvgArray removeAllObjects];
        [OffsetArray removeAllObjects];
        [ProxArray release];
        [AvgArray release];
        [OffsetArray release];
        return;
    }
    for (int i = 0; i < baseProxCnt; i++)
    {
        BaseProxValue  = BaseProxValue + [[ProxArray objectAtIndex:i] intValue];
    }
    double BaseProxAvg = (double)BaseProxValue / baseProxCnt;
    
    double sqrtSum=0;
	for(int j=0; j < baseProxCnt; j++)
	{
		double tmpVal = [[ProxArray objectAtIndex:j] integerValue] - BaseProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/baseProxCnt);
	double BaseSD = pow(tmpAvg,0.5);
    //     = [self CalculateStdDev:ProxArray :BaseProxAvg :baseProxCnt];
    NSLog(@"baseSD = %f",BaseSD);
    int BaseResCnt = 0;
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[NSString stringWithFormat:@"%lf",BaseProxAvg]];
    if((mBase_prox_low == nil) && (mBase_prox_up == nil))
    {
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%f;",BaseProxAvg]];
    }
    else
    {
        if( BaseProxAvg < [mBase_prox_low integerValue] || BaseProxAvg > [mBase_prox_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%f [ %@ , %@ ];",BaseProxAvg,mBase_prox_low,mBase_prox_up]];
        }
    }
    if(mBase_SD_up == nil)
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%f;",BaseSD]];
    }
    else
    {
        if( BaseSD > [mBase_SD_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%f [ >= %@ ];",BaseSD,mBase_SD_up]];
        }
    }
    [TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue":[NSString stringWithFormat:@"%f",BaseProxAvg]];
    [TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximitySDValue":[NSString stringWithFormat:@"%f",BaseSD]];
    if (BaseResCnt == 0)
    {
        enumResult = RESULT_FOR_PASS;
        strTestResultForUIinfo = @"Pass";
        //        [TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%f",BaseProxAvg]];
    }
    [TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%f",BaseProxAvg]];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Prox":nil:mBase_prox_low:mBase_prox_up:[NSString stringWithFormat:@"%f",BaseProxAvg]:nil:IP_NA:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_SD":nil:nil:mBase_SD_up:[NSString stringWithFormat:@"%f",BaseSD]:nil:IP_NA:nil];
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    [ProxArray removeAllObjects];
    [AvgArray removeAllObjects];
    [OffsetArray removeAllObjects];
    [ProxArray release];
    [AvgArray release];
    [OffsetArray release];
	return ;
    
}
//blake add to try new sensor --20130816 --end
+(void)ParseProxBaseForQL2:(NSDictionary*)dictKeyDefined
{
    
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue" :[NSString stringWithFormat:@"%d",100000]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator" :[NSString stringWithFormat:@"%d",-1]];
    
	NSString *strTestResultForUIinfo = @"";
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mProjectType = nil;
	
	NSString *mBase_prox_low = nil;
	NSString *mBase_prox_up = nil;
	NSString *mBase_centerpoint_low = nil;
	NSString *mBase_centerpoint_up = nil;
	NSString *mBase_temp_low = nil;
	NSString *mBase_temp_up = nil;
	NSString *mBase_adj_prox_low = nil;
	NSString *mBase_adj_prox_up = nil;
	NSString *mBase_adj_SD_up = nil;
	
	NSString *mReferenceBufferProx=nil;
	NSString *mReferenceBufferCenterpoint=nil;
	NSString *mReferenceBufferTemp=nil;
	
	int iProx_Variation;
	int iCenterpoint_Variation;
	int iTemp_Variation;
	
	int iPBCL;
	int iPBCB;
	int iPBTB;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Prox_Lowlimit"])
		{
			mBase_prox_low = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Prox_Upperlimit"])
		{
			mBase_prox_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Lowlimit"])
		{
			mBase_centerpoint_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Upperlimit"])
		{
			mBase_centerpoint_up = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Temp_Lowlimit"])
		{
			mBase_temp_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Temp_Upperlimit"])
		{
			mBase_temp_up = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Lowlimit"])
		{
			mBase_adj_prox_low = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_Prox_Upperlimit"])
		{
			mBase_adj_prox_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Base_Adj_SD_Upperlimit"])
		{
			mBase_adj_SD_up = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferProx"])
			mReferenceBufferProx = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferCenterpoint"])
			mReferenceBufferCenterpoint = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ReferenceBufferTemp"])
			mReferenceBufferTemp = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Variation"])
			iProx_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
		else if ([strKey isEqualToString:@"Centerpoint_Variation"])
			iCenterpoint_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
		else if ([strKey isEqualToString:@"Temp_Variation"])
			iTemp_Variation = [[dictKeyDefined objectForKey:strKey] intValue];
        
		else if ([strKey isEqualToString:@"BaseLoop"])
			mBaseCnt = [[dictKeyDefined objectForKey:strKey] intValue];
        
	}
	
    
	NSMutableArray *BaseProx = nil;
	NSMutableArray *BaseCenterpoint = nil;
	NSMutableArray *BaseTemp = nil;
	NSMutableArray *BaseAdjProx = nil;
	
	// serin 20100720
	NSMutableArray *StageValue = nil;
	NSMutableArray *arrayEachStageValue = [[NSMutableArray alloc] init];
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	//Add by Lucky for grab SOCHOT ERROR
	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
    
    //mReferenceBufferValue = @"prox:		 228s:390715us (+00s:000000us) = 0: -17 (0.00) 1: -5725 (0.00) 2: -15613 (0.00) 3: -4806 (0.00) 4: 932 (0.00) 5: -1150 (0.00) 6: 417 (0.00) 7: 408 (0.00) 8: 464 (0.00) 9: 415 (0.00) 10: 458 (0.00) 11: 432 (0.00) 12: 399 (0.00) 13: 470 (0.00) 14: 436 (0.00) 15: 9622 (0.00) - Prox: -19344, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19327 prox:		 228s:788856us (+00s:398141us) = 0: -19 (0.00) 1: -5602 (0.00) 2: -15500 (0.00) 3: -4698 (0.00) 4: 965 (0.00) 5: -1160 (0.00) 6: 344 (0.00) 7: 370 (0.00) 8: 366 (0.00) 9: 375 (0.00) 10: 342 (0.00) 11: 389 (0.00) 12: 396 (0.00) 13: 362 (0.00) 14: 373 (0.00) 15: 9622 (0.00) - Prox: -19424, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19405 prox:		 229s:187006us (+00s:398150us) = 0: -17 (0.00) 1: -5592 (0.00) 2: -15497 (0.00) 3: -4686 (0.00) 4: 946 (0.00) 5: -1163 (0.00) 6: 353 (0.00) 7: 307 (0.00) 8: 356 (0.00) 9: 325 (0.00) 10: 349 (0.00) 11: 373 (0.00) 12: 393 (0.00) 13: 319 (0.00) 14: 342 (0.00) 15: 9622 (0.00) - Prox: -19462, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19445 prox:		 229s:585151us (+00s:398145us) = 0: -17 (0.00) 1: -5590 (0.00) 2: -15489 (0.00) 3: -4684 (0.00) 4: 892 (0.00) 5: -1164 (0.00) 6: 326 (0.00) 7: 335 (0.00) 8: 326 (0.00) 9: 337 (0.00) 10: 329 (0.00) 11: 328 (0.00) 12: 304 (0.00) 13: 347 (0.00) 14: 312 (0.00) 15: 9622 (0.00) - Prox: -19463, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19446 prox:		 229s:983256us (+00s:398105us) = 0: -17 (0.00) 1: -5587 (0.00) 2: -15489 (0.00) 3: -4686 (0.00) 4: 911 (0.00) 5: -1165 (0.00) 6: 309 (0.00) 7: 323 (0.00) 8: 322 (0.00) 9: 287 (0.00) 10: 305 (0.00) 11: 321 (0.00) 12: 334 (0.00) 13: 337 (0.00) 14: 299 (0.00) 15: 9622 (0.00) - Prox: -19483, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19466 prox:		 230s:381376us (+00s:398120us) = 0: -17 (0.00) 1: -5587 (0.00) 2: -15488 (0.00) 3: -4683 (0.00) 4: 898 (0.00) 5: -1166 (0.00) 6: 234 (0.00) 7: 246 (0.00) 8: 277 (0.00) 9: 241 (0.00) 10: 271 (0.00) 11: 298 (0.00) 12: 295 (0.00) 13: 294 (0.00) 14: 280 (0.00) 15: 9622 (0.00) - Prox: -19531, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19514 prox:		 230s:779484us (+00s:398108us) = 0: -16 (0.00) 1: -5585 (0.00) 2: -15487 (0.00) 3: -4688 (0.00) 4: 884 (0.00) 5: -1164 (0.00) 6: 302 (0.00) 7: 291 (0.00) 8: 308 (0.00) 9: 253 (0.00) 10: 267 (0.00) 11: 249 (0.00) 12: 269 (0.00) 13: 202 (0.00) 14: 250 (0.00) 15: 9622 (0.00) - Prox: -19533, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19517 prox:		 231s:177607us (+00s:398123us) = 0: -15 (0.00) 1: -5589 (0.00) 2: -15490 (0.00) 3: -4687 (0.00) 4: 863 (0.00) 5: -1162 (0.00) 6: 284 (0.00) 7: 229 (0.00) 8: 284 (0.00) 9: 278 (0.00) 10: 291 (0.00) 11: 301 (0.00) 12: 281 (0.00) 13: 308 (0.00) 14: 302 (0.00) 15: 9622 (0.00) - Prox: -19518, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19503 prox:		 231s:575712us (+00s:398105us) = 0: -18 (0.00) 1: -5588 (0.00) 2: -15489 (0.00) 3: -4686 (0.00) 4: 878 (0.00) 5: -1167 (0.00) 6: 250 (0.00) 7: 291 (0.00) 8: 247 (0.00) 9: 312 (0.00) 10: 276 (0.00) 11: 261 (0.00) 12: 275 (0.00) 13: 291 (0.00) 14: 284 (0.00) 15: 9622 (0.00) - Prox: -19525, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19507 prox:		 231s:973818us (+00s:398106us) = 0: -19 (0.00) 1: -5591 (0.00) 2: -15489 (0.00) 3: -4685 (0.00) 4: 928 (0.00) 5: -1159 (0.00) 6: 293 (0.00) 7: 305 (0.00) 8: 307 (0.00) 9: 279 (0.00) 10: 284 (0.00) 11: 293 (0.00) 12: 296 (0.00) 13: 307 (0.00) 14: 300 (0.00) 15: 9622 (0.00) - Prox: -19497, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19478 prox:		 232s:371926us (+00s:398108us) = 0: -16 (0.00) 1: -5587 (0.00) 2: -15491 (0.00) 3: -4686 (0.00) 4: 866 (0.00) 5: -1160 (0.00) 6: 281 (0.00) 7: 293 (0.00) 8: 244 (0.00) 9: 236 (0.00) 10: 274 (0.00) 11: 291 (0.00) 12: 272 (0.00) 13: 343 (0.00) 14: 292 (0.00) 15: 9622 (0.00) - Prox: -19529, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19513 prox:		 232s:770059us (+00s:398133us) = 0: -17 (0.00) 1: -5590 (0.00) 2: -15495 (0.00) 3: -4690 (0.00) 4: 840 (0.00) 5: -1162 (0.00) 6: 269 (0.00) 7: 304 (0.00) 8: 305 (0.00) 9: 294 (0.00) 10: 320 (0.00) 11: 280 (0.00) 12: 298 (0.00) 13: 276 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19515, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19498 prox:		 233s:168213us (+00s:398154us) = 0: -18 (0.00) 1: -5592 (0.00) 2: -15488 (0.00) 3: -4689 (0.00) 4: 852 (0.00) 5: -1159 (0.00) 6: 248 (0.00) 7: 252 (0.00) 8: 268 (0.00) 9: 290 (0.00) 10: 315 (0.00) 11: 301 (0.00) 12: 290 (0.00) 13: 249 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19516, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19498 prox:		 233s:566367us (+00s:398154us) = 0: -17 (0.00) 1: -5595 (0.00) 2: -15495 (0.00) 3: -4687 (0.00) 4: 846 (0.00) 5: -1164 (0.00) 6: 269 (0.00) 7: 301 (0.00) 8: 299 (0.00) 9: 270 (0.00) 10: 272 (0.00) 11: 265 (0.00) 12: 264 (0.00) 13: 223 (0.00) 14: 269 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19513 prox:		 233s:964517us (+00s:398150us) = 0: -16 (0.00) 1: -5595 (0.00) 2: -15492 (0.00) 3: -4689 (0.00) 4: 869 (0.00) 5: -1155 (0.00) 6: 311 (0.00) 7: 235 (0.00) 8: 277 (0.00) 9: 260 (0.00) 10: 260 (0.00) 11: 222 (0.00) 12: 295 (0.00) 13: 285 (0.00) 14: 255 (0.00) 15: 9622 (0.00) - Prox: -19524, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19508 prox:		 234s:362657us (+00s:398140us) = 0: -18 (0.00) 1: -5595 (0.00) 2: -15499 (0.00) 3: -4692 (0.00) 4: 893 (0.00) 5: -1160 (0.00) 6: 253 (0.00) 7: 251 (0.00) 8: 278 (0.00) 9: 290 (0.00) 10: 326 (0.00) 11: 305 (0.00) 12: 297 (0.00) 13: 274 (0.00) 14: 297 (0.00) 15: 9622 (0.00) - Prox: -19524, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19506 prox:		 234s:760802us (+00s:398145us) = 0: -17 (0.00) 1: -5595 (0.00) 2: -15497 (0.00) 3: -4693 (0.00) 4: 839 (0.00) 5: -1149 (0.00) 6: 284 (0.00) 7: 272 (0.00) 8: 218 (0.00) 9: 247 (0.00) 10: 218 (0.00) 11: 273 (0.00) 12: 212 (0.00) 13: 241 (0.00) 14: 273 (0.00) 15: 9622 (0.00) - Prox: -19555, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19538 prox:		 235s:158955us (+00s:398153us) = 0: -19 (0.00) 1: -5596 (0.00) 2: -15500 (0.00) 3: -4693 (0.00) 4: 817 (0.00) 5: -1155 (0.00) 6: 232 (0.00) 7: 240 (0.00) 8: 273 (0.00) 9: 214 (0.00) 10: 268 (0.00) 11: 251 (0.00) 12: 238 (0.00) 13: 235 (0.00) 14: 239 (0.00) 15: 9622 (0.00) - Prox: -19565, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19546 prox:		 235s:557098us (+00s:398143us) = 0: -19 (0.00) 1: -5599 (0.00) 2: -15502 (0.00) 3: -4692 (0.00) 4: 815 (0.00) 5: -1149 (0.00) 6: 256 (0.00) 7: 242 (0.00) 8: 221 (0.00) 9: 259 (0.00) 10: 247 (0.00) 11: 251 (0.00) 12: 283 (0.00) 13: 283 (0.00) 14: 268 (0.00) 15: 9622 (0.00) - Prox: -19545, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19526 prox:		 235s:955223us (+00s:398125us) = 0: -17 (0.00) 1: -5600 (0.00) 2: -15496 (0.00) 3: -4694 (0.00) 4: 840 (0.00) 5: -1153 (0.00) 6: 215 (0.00) 7: 220 (0.00) 8: 250 (0.00) 9: 231 (0.00) 10: 225 (0.00) 11: 240 (0.00) 12: 250 (0.00) 13: 244 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19558, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19541 prox:		 236s:353352us (+00s:398129us) = 0: -17 (0.00) 1: -5600 (0.00) 2: -15499 (0.00) 3: -4699 (0.00) 4: 860 (0.00) 5: -1148 (0.00) 6: 221 (0.00) 7: 237 (0.00) 8: 216 (0.00) 9: 271 (0.00) 10: 284 (0.00) 11: 223 (0.00) 12: 263 (0.00) 13: 265 (0.00) 14: 268 (0.00) 15: 9622 (0.00) - Prox: -19545, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19528 prox:		 236s:751512us (+00s:398160us) = 0: -18 (0.00) 1: -5600 (0.00) 2: -15505 (0.00) 3: -4698 (0.00) 4: 850 (0.00) 5: -1146 (0.00) 6: 271 (0.00) 7: 259 (0.00) 8: 227 (0.00) 9: 233 (0.00) 10: 239 (0.00) 11: 266 (0.00) 12: 242 (0.00) 13: 274 (0.00) 14: 244 (0.00) 15: 9622 (0.00) - Prox: -19557, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19539 prox:		 237s:149673us (+00s:398161us) = 0: -20 (0.00) 1: -5601 (0.00) 2: -15500 (0.00) 3: -4700 (0.00) 4: 803 (0.00) 5: -1152 (0.00) 6: 216 (0.00) 7: 217 (0.00) 8: 254 (0.00) 9: 271 (0.00) 10: 282 (0.00) 11: 232 (0.00) 12: 223 (0.00) 13: 253 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19549, Centerpoint: -20, Temp: 0, Adjusted_Prox: -19529 prox:		 237s:547832us (+00s:398159us) = 0: -17 (0.00) 1: -5612 (0.00) 2: -15500 (0.00) 3: -4702 (0.00) 4: 834 (0.00) 5: -1149 (0.00) 6: 250 (0.00) 7: 193 (0.00) 8: 203 (0.00) 9: 259 (0.00) 10: 225 (0.00) 11: 294 (0.00) 12: 275 (0.00) 13: 270 (0.00) 14: 252 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19513 prox:		 237s:945979us (+00s:398147us) = 0: -17 (0.00) 1: -5604 (0.00) 2: -15501 (0.00) 3: -4700 (0.00) 4: 841 (0.00) 5: -1146 (0.00) 6: 228 (0.00) 7: 254 (0.00) 8: 203 (0.00) 9: 247 (0.00) 10: 217 (0.00) 11: 252 (0.00) 12: 275 (0.00) 13: 220 (0.00) 14: 247 (0.00) 15: 9622 (0.00) - Prox: -19555, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19538 prox:		 238s:344120us (+00s:398141us) = 0: -17 (0.00) 1: -5607 (0.00) 2: -15501 (0.00) 3: -4700 (0.00) 4: 847 (0.00) 5: -1144 (0.00) 6: 199 (0.00) 7: 272 (0.00) 8: 273 (0.00) 9: 236 (0.00) 10: 241 (0.00) 11: 276 (0.00) 12: 268 (0.00) 13: 287 (0.00) 14: 266 (0.00) 15: 9622 (0.00) - Prox: -19528, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19511 prox:		 238s:742257us (+00s:398137us) = 0: -19 (0.00) 1: -5610 (0.00) 2: -15503 (0.00) 3: -4703 (0.00) 4: 839 (0.00) 5: -1143 (0.00) 6: 206 (0.00) 7: 237 (0.00) 8: 263 (0.00) 9: 208 (0.00) 10: 239 (0.00) 11: 259 (0.00) 12: 258 (0.00) 13: 259 (0.00) 14: 247 (0.00) 15: 9622 (0.00) - Prox: -19543, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19524 prox:		 239s:140395us (+00s:398138us) = 0: -19 (0.00) 1: -5610 (0.00) 2: -15508 (0.00) 3: -4703 (0.00) 4: 850 (0.00) 5: -1146 (0.00) 6: 293 (0.00) 7: 269 (0.00) 8: 285 (0.00) 9: 261 (0.00) 10: 298 (0.00) 11: 257 (0.00) 12: 259 (0.00) 13: 281 (0.00) 14: 287 (0.00) 15: 9622 (0.00) - Prox: -19517, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19498 prox:		 239s:538539us (+00s:398144us) = 0: -18 (0.00) 1: -5610 (0.00) 2: -15514 (0.00) 3: -4706 (0.00) 4: 845 (0.00) 5: -1143 (0.00) 6: 226 (0.00) 7: 291 (0.00) 8: 284 (0.00) 9: 258 (0.00) 10: 252 (0.00) 11: 242 (0.00) 12: 291 (0.00) 13: 231 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19549, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19531 prox:		 239s:936671us (+00s:398132us) = 0: -16 (0.00) 1: -5610 (0.00) 2: -15508 (0.00) 3: -4708 (0.00) 4: 832 (0.00) 5: -1140 (0.00) 6: 271 (0.00) 7: 301 (0.00) 8: 317 (0.00) 9: 312 (0.00) 10: 269 (0.00) 11: 244 (0.00) 12: 258 (0.00) 13: 278 (0.00) 14: 256 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19495 prox:		 240s:334798us (+00s:398127us) = 0: -17 (0.00) 1: -5609 (0.00) 2: -15513 (0.00) 3: -4716 (0.00) 4: 849 (0.00) 5: -1140 (0.00) 6: 272 (0.00) 7: 276 (0.00) 8: 293 (0.00) 9: 247 (0.00) 10: 253 (0.00) 11: 270 (0.00) 12: 253 (0.00) 13: 253 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19544, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19527 prox:		 240s:732946us (+00s:398148us) = 0: -17 (0.00) 1: -5612 (0.00) 2: -15514 (0.00) 3: -4713 (0.00) 4: 863 (0.00) 5: -1137 (0.00) 6: 292 (0.00) 7: 271 (0.00) 8: 265 (0.00) 9: 258 (0.00) 10: 283 (0.00) 11: 289 (0.00) 12: 285 (0.00) 13: 285 (0.00) 14: 276 (0.00) 15: 9622 (0.00) - Prox: -19522, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19505 prox:		 241s:131088us (+00s:398142us) = 0: -18 (0.00) 1: -5615 (0.00) 2: -15518 (0.00) 3: -4713 (0.00) 4: 845 (0.00) 5: -1135 (0.00) 6: 257 (0.00) 7: 271 (0.00) 8: 265 (0.00) 9: 306 (0.00) 10: 278 (0.00) 11: 286 (0.00) 12: 262 (0.00) 13: 251 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19528, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19510 prox:		 241s:529223us (+00s:398135us) = 0: -16 (0.00) 1: -5621 (0.00) 2: -15515 (0.00) 3: -4715 (0.00) 4: 827 (0.00) 5: -1134 (0.00) 6: 271 (0.00) 7: 270 (0.00) 8: 257 (0.00) 9: 272 (0.00) 10: 294 (0.00) 11: 268 (0.00) 12: 270 (0.00) 13: 223 (0.00) 14: 253 (0.00) 15: 9622 (0.00) - Prox: -19519, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19503 prox:		 241s:927353us (+00s:398130us) = 0: -17 (0.00) 1: -5616 (0.00) 2: -15521 (0.00) 3: -4717 (0.00) 4: 828 (0.00) 5: -1136 (0.00) 6: 280 (0.00) 7: 278 (0.00) 8: 232 (0.00) 9: 279 (0.00) 10: 243 (0.00) 11: 270 (0.00) 12: 247 (0.00) 13: 268 (0.00) 14: 262 (0.00) 15: 9622 (0.00) - Prox: -19546, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19529 prox:		 242s:325499us (+00s:398146us) = 0: -18 (0.00) 1: -5622 (0.00) 2: -15523 (0.00) 3: -4720 (0.00) 4: 798 (0.00) 5: -1132 (0.00) 6: 222 (0.00) 7: 248 (0.00) 8: 258 (0.00) 9: 253 (0.00) 10: 244 (0.00) 11: 258 (0.00) 12: 259 (0.00) 13: 229 (0.00) 14: 248 (0.00) 15: 9622 (0.00) - Prox: -19554, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19536 prox:		 242s:723646us (+00s:398147us) = 0: -16 (0.00) 1: -5626 (0.00) 2: -15528 (0.00) 3: -4722 (0.00) 4: 793 (0.00) 5: -1131 (0.00) 6: 287 (0.00) 7: 232 (0.00) 8: 240 (0.00) 9: 222 (0.00) 10: 223 (0.00) 11: 247 (0.00) 12: 190 (0.00) 13: 219 (0.00) 14: 257 (0.00) 15: 9622 (0.00) - Prox: -19568, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19552 prox:		 243s:121780us (+00s:398134us) = 0: -16 (0.00) 1: -5622 (0.00) 2: -15519 (0.00) 3: -4722 (0.00) 4: 810 (0.00) 5: -1131 (0.00) 6: 208 (0.00) 7: 284 (0.00) 8: 258 (0.00) 9: 239 (0.00) 10: 263 (0.00) 11: 238 (0.00) 12: 286 (0.00) 13: 254 (0.00) 14: 246 (0.00) 15: 9622 (0.00) - Prox: -19539, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19523 prox:		 243s:519910us (+00s:398130us) = 0: -17 (0.00) 1: -5620 (0.00) 2: -15520 (0.00) 3: -4723 (0.00) 4: 843 (0.00) 5: -1130 (0.00) 6: 284 (0.00) 7: 208 (0.00) 8: 243 (0.00) 9: 263 (0.00) 10: 207 (0.00) 11: 228 (0.00) 12: 205 (0.00) 13: 260 (0.00) 14: 245 (0.00) 15: 9622 (0.00) - Prox: -19563, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19546 prox:		 243s:918052us (+00s:398142us) = 0: -17 (0.00) 1: -5625 (0.00) 2: -15521 (0.00) 3: -4724 (0.00) 4: 844 (0.00) 5: -1128 (0.00) 6: 285 (0.00) 7: 229 (0.00) 8: 285 (0.00) 9: 285 (0.00) 10: 262 (0.00) 11: 264 (0.00) 12: 287 (0.00) 13: 270 (0.00) 14: 255 (0.00) 15: 9622 (0.00) - Prox: -19522, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19505 prox:		 244s:316150us (+00s:398098us) = 0: -15 (0.00) 1: -5626 (0.00) 2: -15524 (0.00) 3: -4724 (0.00) 4: 826 (0.00) 5: -1122 (0.00) 6: 287 (0.00) 7: 255 (0.00) 8: 202 (0.00) 9: 306 (0.00) 10: 236 (0.00) 11: 260 (0.00) 12: 237 (0.00) 13: 237 (0.00) 14: 258 (0.00) 15: 9622 (0.00) - Prox: -19540, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19525 prox:		 244s:714254us (+00s:398104us) = 0: -15 (0.00) 1: -5629 (0.00) 2: -15534 (0.00) 3: -4728 (0.00) 4: 820 (0.00) 5: -1122 (0.00) 6: 269 (0.00) 7: 264 (0.00) 8: 292 (0.00) 9: 294 (0.00) 10: 262 (0.00) 11: 260 (0.00) 12: 238 (0.00) 13: 264 (0.00) 14: 269 (0.00) 15: 9622 (0.00) - Prox: -19541, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19526 prox:		 245s:112379us (+00s:398125us) = 0: -17 (0.00) 1: -5632 (0.00) 2: -15528 (0.00) 3: -4727 (0.00) 4: 796 (0.00) 5: -1125 (0.00) 6: 272 (0.00) 7: 282 (0.00) 8: 265 (0.00) 9: 280 (0.00) 10: 308 (0.00) 11: 310 (0.00) 12: 268 (0.00) 13: 264 (0.00) 14: 265 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19494 prox:		 245s:510499us (+00s:398120us) = 0: -18 (0.00) 1: -5629 (0.00) 2: -15538 (0.00) 3: -4729 (0.00) 4: 842 (0.00) 5: -1126 (0.00) 6: 242 (0.00) 7: 317 (0.00) 8: 269 (0.00) 9: 256 (0.00) 10: 305 (0.00) 11: 304 (0.00) 12: 229 (0.00) 13: 297 (0.00) 14: 266 (0.00) 15: 9622 (0.00) - Prox: -19539, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19521 prox:		 245s:908607us (+00s:398108us) = 0: -18 (0.00) 1: -5638 (0.00) 2: -15536 (0.00) 3: -4732 (0.00) 4: 790 (0.00) 5: -1122 (0.00) 6: 287 (0.00) 7: 240 (0.00) 8: 278 (0.00) 9: 251 (0.00) 10: 279 (0.00) 11: 247 (0.00) 12: 245 (0.00) 13: 224 (0.00) 14: 237 (0.00) 15: 9622 (0.00) - Prox: -19536, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19518 prox:		 246s:306718us (+00s:398111us) = 0: -15 (0.00) 1: -5633 (0.00) 2: -15533 (0.00) 3: -4731 (0.00) 4: 821 (0.00) 5: -1123 (0.00) 6: 293 (0.00) 7: 270 (0.00) 8: 268 (0.00) 9: 298 (0.00) 10: 255 (0.00) 11: 248 (0.00) 12: 229 (0.00) 13: 304 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19515 prox:		 246s:704828us (+00s:398110us) = 0: -19 (0.00) 1: -5636 (0.00) 2: -15535 (0.00) 3: -4734 (0.00) 4: 808 (0.00) 5: -1116 (0.00) 6: 262 (0.00) 7: 252 (0.00) 8: 311 (0.00) 9: 303 (0.00) 10: 255 (0.00) 11: 256 (0.00) 12: 291 (0.00) 13: 299 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19514, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19495 prox:		 247s:102958us (+00s:398130us) = 0: -16 (0.00) 1: -5635 (0.00) 2: -15538 (0.00) 3: -4735 (0.00) 4: 806 (0.00) 5: -1117 (0.00) 6: 244 (0.00) 7: 210 (0.00) 8: 233 (0.00) 9: 248 (0.00) 10: 246 (0.00) 11: 268 (0.00) 12: 304 (0.00) 13: 312 (0.00) 14: 262 (0.00) 15: 9622 (0.00) - Prox: -19542, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19526 prox:		 247s:501090us (+00s:398132us) = 0: -18 (0.00) 1: -5640 (0.00) 2: -15537 (0.00) 3: -4737 (0.00) 4: 831 (0.00) 5: -1115 (0.00) 6: 282 (0.00) 7: 292 (0.00) 8: 289 (0.00) 9: 284 (0.00) 10: 304 (0.00) 11: 266 (0.00) 12: 250 (0.00) 13: 286 (0.00) 14: 281 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19493 prox:		 247s:899209us (+00s:398119us) = 0: -16 (0.00) 1: -5637 (0.00) 2: -15539 (0.00) 3: -4740 (0.00) 4: 825 (0.00) 5: -1114 (0.00) 6: 269 (0.00) 7: 229 (0.00) 8: 214 (0.00) 9: 276 (0.00) 10: 280 (0.00) 11: 231 (0.00) 12: 212 (0.00) 13: 184 (0.00) 14: 234 (0.00) 15: 9622 (0.00) - Prox: -19564, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19548 OK ";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		[arrayEachStageValue release];
		return ;
	}
    NSLog(@"before %@",mReferenceBufferValue);
    for (int i = 1; i < 10; i++)
    {
        mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@" %d: ",i] withString:@","];
    }
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 10: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 11: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 12: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 13: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 14: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 15: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"(0.00)" withString:@""];
    
	NSString*stationName =[ScriptParse getValueFromSummary:@"ProductLine"];
	if([stationName isEqualToString:@"Reliability"])
	{
		if(mReferenceBufferProx==nil || mReferenceBufferCenterpoint==nil || mReferenceBufferTemp==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Test Script Error!"] ;
			[arrayEachStageValue release];
			return ;
		}
		
		NSString *mReferenceBufferProxValue ;
		NSString *mReferenceBufferCenterpointValue;
		NSString *mReferenceBufferTempValue ;
		
		mReferenceBufferProxValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferProx] ;
		mReferenceBufferCenterpointValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferCenterpoint] ;
		mReferenceBufferTempValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferTemp] ;
		if(mReferenceBufferProxValue==nil || mReferenceBufferCenterpointValue==nil || mReferenceBufferTempValue==nil)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
			[arrayEachStageValue release];
			return ;
		}
		
		iPBCL=strtol([mReferenceBufferProxValue UTF8String], NULL, 16);
		iPBCB=strtol([mReferenceBufferCenterpointValue UTF8String], NULL, 16);
		iPBTB=strtol([mReferenceBufferTempValue UTF8String], NULL, 16);
		
	}
	
	NSRange rangeCenterpoint = [mReferenceBufferValue rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValue rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		[arrayEachStageValue release];
		return ;
	}
    
	BaseProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"- Prox: "];
	BaseCenterpoint = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Centerpoint: "];
	BaseTemp = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	BaseAdjProx = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Adjusted_Prox: "];
	
    if ([mReferenceBufferValue rangeOfString:@"= 0: "].length == 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please Download the Latest Diag which receive data contains string '= 0: '"] ;
		[arrayEachStageValue release];
		return ;
        
    }
	StageValue = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"= 0: "];//modified by judith changed Sensorreading to = 0:
	
	
	NSRange stageLen = [[StageValue objectAtIndex:1] rangeOfString:@" - Prox: "];
	
	NSInteger BaseProxValue=0;
	NSInteger BaseCenterpointValue=0;
	NSInteger BaseTempValue=0;
	NSInteger BaseAdjProxValue=0;
    NSRange BaseProxRange;
    NSRange BaseCenterpointRange;
    NSRange BaseTempRange;
    NSRange BaseAdjProxRange;
	
	NSMutableString *AllStageValue= [[NSMutableString alloc] init];
	int BaseCount = [BaseProx count];
    int CenterCount = [BaseCenterpoint count];
    int TempCount = [BaseTemp count];
    int AdjCount = [BaseAdjProx count];
    int ProxCount = [StageValue count];
    if (BaseCount > mBaseCnt+1 || CenterCount > mBaseCnt+1 || TempCount > mBaseCnt+1 || AdjCount >mBaseCnt+1 || ProxCount >mBaseCnt+1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"] ;
		[arrayEachStageValue release];
        [AllStageValue release];
		return ;
    }
    //add ended
	for(int i=1 ; i<=mBaseCnt ; i++ )
	{
        NSRange StageValueRange = NSMakeRange(0,stageLen.location);
        BaseProxRange = [[BaseProx objectAtIndex:i] rangeOfString:@","];
        BaseCenterpointRange = [[BaseCenterpoint objectAtIndex:i] rangeOfString:@","];
        BaseTempRange = [[BaseTemp objectAtIndex:i] rangeOfString:@","];
        BaseAdjProxRange = [[BaseAdjProx objectAtIndex:i] rangeOfString:@" "];
        if(BaseProxRange.length == 0 || BaseCenterpointRange.length == 0 || BaseTempRange.length == 0 || BaseAdjProxRange.length == 0 || [[StageValue objectAtIndex:i] length] < stageLen.location)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Data no string ',' or else. in case of below happen exception"] ;
            [arrayEachStageValue release];
            [AllStageValue release];
            return ;
        }
		[BaseProx replaceObjectAtIndex:i
							withObject:[[BaseProx objectAtIndex:i] substringToIndex:BaseProxRange.location]];
		
		[BaseCenterpoint replaceObjectAtIndex:i
								   withObject:[[BaseCenterpoint objectAtIndex:i] substringToIndex:BaseCenterpointRange.location]];
		
		
		[BaseAdjProx replaceObjectAtIndex:i
							   withObject:[[BaseAdjProx objectAtIndex:i] substringToIndex:BaseAdjProxRange.location]];
		
		
		[StageValue replaceObjectAtIndex:i
							  withObject:[[StageValue objectAtIndex:i] substringWithRange:StageValueRange]];
        // add by judith as temperature has new algorithm(use stage 15 as temp value) 20121205
        NSArray *tempArray = [[StageValue objectAtIndex:i] componentsSeparatedByString:@","];
        if ([tempArray count] != 16)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diag not return 16 Stage (0 ~ 15)!"] ;
            [arrayEachStageValue release];
            [AllStageValue release];
            return ;
            
        }
        //[BaseTemp replaceObjectAtIndex:i
		//					withObject:[[BaseTemp objectAtIndex:i] substringToIndex:BaseTempRange.location]];
        [BaseTemp replaceObjectAtIndex:i
							withObject:[tempArray objectAtIndex:15]];
		//add ended 20121205
		BaseProxValue			= BaseProxValue + [[BaseProx objectAtIndex:i]integerValue];
		BaseCenterpointValue	= BaseCenterpointValue + [[BaseCenterpoint objectAtIndex:i]integerValue];
		BaseTempValue			= BaseTempValue + [[BaseTemp objectAtIndex:i]integerValue];
		BaseAdjProxValue		= BaseAdjProxValue + [[BaseAdjProx objectAtIndex:i]integerValue];
		
		[AllStageValue appendString:[StageValue objectAtIndex:i]];
		[AllStageValue appendString:@","];
	}
	
	NSArray *arrayAllStageValue=nil;
	arrayAllStageValue =[AllStageValue componentsSeparatedByString:@","];
	NSLog(@"arrayAllStageValue = %@",arrayAllStageValue);
	int iAverageValue = 0;
	int StageSD = 0;
	
	int Stage4RefAvg = 0;
	int OffSet = 0;
	
    int MaxValue = 15+(mBaseCnt-1)*16;
	for (int i=0;i<16;i++)
	{
		iAverageValue = 0;
		[arrayEachStageValue removeAllObjects];
        if ([arrayAllStageValue count] < MaxValue)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Sensor Reading Data Count is %d,Less than BaseLoop %d",[arrayAllStageValue count],MaxValue]] ;
            [arrayEachStageValue release];
            [AllStageValue release];
            return ;
            
        }
		for(int j=0;j<mBaseCnt;j++)
		{
			iAverageValue+=[[arrayAllStageValue objectAtIndex:(i+j*16)] intValue];
			[arrayEachStageValue addObject:[arrayAllStageValue objectAtIndex:(i+j*16)]];
		}
		
		iAverageValue= iAverageValue/mBaseCnt;
		
		if(i == 4)
			Stage4RefAvg = iAverageValue;
		
		if(i == 2)
			OffSet = iAverageValue;
		
		if(i == 3)
			OffSet = (OffSet - iAverageValue);
		
		StageSD = [self CalculateStageStdDev: arrayEachStageValue: iAverageValue:mBaseCnt];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d average",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",iAverageValue]:nil:IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d SD",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",StageSD]:nil:IP_NA:nil];
	}
	
	OffSet= OffSet/4;
	
	[AllStageValue release];
	[arrayEachStageValue release];
	
	NSInteger BaseProxAvg			= BaseProxValue / mBaseCnt ;
	NSInteger BaseCenterpointAvg	= BaseCenterpointValue / mBaseCnt ;
	NSInteger BaseTempAvg			= BaseTempValue / mBaseCnt ;
	NSInteger BaseAdjProxAvg		= BaseAdjProxValue / mBaseCnt ;
	NSInteger BaseAdjSD				= [self CalculateStdDev: BaseAdjProx: BaseAdjProxAvg:mBaseCnt];
    
	
	strTestResultForUIinfo = @"";
	
	NSInteger BaseResCnt = 0;
    
	
	NSInteger BaseAdjTemp = BaseTempAvg - BaseCenterpointAvg;
    // add by judith as temperature has new algorithm(use stage 15 as temp value) 20121205
    
    float proxTemperatureRaw = 0.0;
    int proxTemperatureC = 0;
    if (BaseTempAvg < 0)
        proxTemperatureRaw = BaseTempAvg + 65536;
    else
        proxTemperatureRaw = BaseTempAvg;
    proxTemperatureC = ((proxTemperatureRaw - 32768) / 64) - 273;
    
    //add ended 20121205
    
    if((mBase_prox_low == nil) && (mBase_prox_up == nil))
    {
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%d;",BaseProxAvg]];
    }
    else
    {
        if( BaseProxAvg < [mBase_prox_low integerValue] || BaseProxAvg > [mBase_prox_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Prox Value:%d [ %@ , %@ ];",BaseProxAvg,mBase_prox_low,mBase_prox_up]];
        }
    }
    if((mBase_centerpoint_low == nil) && (mBase_centerpoint_up == nil))
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%d;",BaseCenterpointAvg]];
    }
    else
    {
        if( BaseCenterpointAvg < [mBase_centerpoint_low integerValue] || BaseCenterpointAvg > [mBase_centerpoint_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%d [ %@ , %@ ];",BaseCenterpointAvg,mBase_centerpoint_low,mBase_centerpoint_up]];
        }
	}
    if((mBase_temp_low == nil) && (mBase_temp_up == nil))
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%d;",proxTemperatureC]];
    }
    else
    {
        if( proxTemperatureC < [mBase_temp_low integerValue] || proxTemperatureC > [mBase_temp_up integerValue])
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%d [ %@ , %@ ];",proxTemperatureC,mBase_temp_low,mBase_temp_up]];
        }
	}
    
    if(mBase_adj_SD_up == nil)
    {
        strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%d;",BaseAdjSD]];
    }
    else
    {
        if( BaseAdjSD > [mBase_adj_SD_up integerValue])
        {
            BaseResCnt++;
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%d [ >= %@ ];",BaseAdjSD,mBase_adj_SD_up]];
        }
    }
    
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue":[NSString stringWithFormat:@"%d",BaseProxAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineCenterpointAverageValue":[NSString stringWithFormat:@"%d",BaseCenterpointAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineTemperatureAverageValue":[NSString stringWithFormat:@"%d",proxTemperatureC]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineAdjustProximityAverageValue":[NSString stringWithFormat:@"%d",BaseAdjProxAvg]];
	
	[TestItemManage setBufferValue:dictKeyDefined :@"FreeBaseLineProximitySDValue":[NSString stringWithFormat:@"%d",BaseAdjSD]];
    
	if([stationName isEqualToString:@"Reliability"])
	{
		if ( BaseProxAvg<(iPBCL-iProx_Variation)||BaseProxAvg > (iPBCL+iProx_Variation) )
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBCl Value ;"];
			
		}
		
		
		if ( BaseCenterpointAvg<(iPBCB-iCenterpoint_Variation)||BaseCenterpointAvg > (iPBCB+iCenterpoint_Variation))
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBCb Value ;"];
			
		}
		
		
		if ( proxTemperatureC<(iPBTB-iTemp_Variation)||proxTemperatureC>(iPBTB+iTemp_Variation) )
			
		{
			BaseResCnt++;
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"PBTb Value ;"];
			
		}
		
	}
	if(BaseResCnt == 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
		
		[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%d",BaseProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%d",BaseCenterpointAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%d",proxTemperatureC]];
        
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%d",BaseAdjTemp]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%d",BaseAdjProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp1 Value":[NSString stringWithFormat:@"%d",proxTemperatureC]];
        //Modified the CPCl key 1795/2303/2303 by judith 20130129
		if([mProjectType isEqualToString:@"OnlyRL2"])
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1797,0,48,0,OffSet,1535,1535,8,39322,0,BaseProxAvg,BaseCenterpointAvg,proxTemperatureC,0,60,261,65246,65000,80,550,0,0,0,0]];//updated 20130423
            //NSLog(@"this is ForQL2 OnlyQL2 60261 my test test result is %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
		else
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1795,0,48,0,OffSet,2303,2303,4,39322,0,BaseProxAvg,BaseCenterpointAvg,proxTemperatureC,0,60,261,65246,42000,80,550,0,0,0,0]];
            //NSLog(@"this is ForQL2 else OnlyQL2 60261 Prox Params Value %0x8",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
	}
	//end
	else
	{
		[TestItemManage setUnitValue:dictKeyDefined :@"Prox Value":[NSString stringWithFormat:@"%d",BaseProxAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxCenterpoint Value":[NSString stringWithFormat:@"%d",BaseCenterpointAvg]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTemp Value":[NSString stringWithFormat:@"%d",proxTemperatureC]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxTempAdj Value":[NSString stringWithFormat:@"%d",BaseAdjTemp]];
		[TestItemManage setUnitValue:dictKeyDefined :@"ProxAdj Value":[NSString stringWithFormat:@"%d",BaseAdjProxAvg]];
        //Modified the CPCl key 1795/2303/2303 by judith 20130129
		if([mProjectType isEqualToString:@"OnlyRL2"])
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1797,0,48,0,OffSet,1535,1535,8,39322,0,BaseProxAvg,BaseCenterpointAvg,proxTemperatureC,0,60,261,65246,65000,80,550,0,0,0,0]];//updated 20130423
            //NSLog(@"this is ForQL2 OnlyQL2 70261 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
		else
        {
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":[NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",1795,0,40,0,OffSet,2303,2303,4,36700,0,BaseProxAvg,BaseCenterpointAvg,proxTemperatureC,0,70,226,65246,42000,80,550,33423,0,0,0]];
            //NSLog(@"this is ForQL2 else OnlyQL2 70226 Prox Params Value %@",[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"]);
        }
        //end
	}
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Prox":nil:mBase_prox_low:mBase_prox_up:[NSString stringWithFormat:@"%d",BaseProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Centerpoint":nil:mBase_centerpoint_low:mBase_centerpoint_up:[NSString stringWithFormat:@"%d",BaseCenterpointAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Temp":nil:mBase_temp_low:mBase_temp_up:[NSString stringWithFormat:@"%d",proxTemperatureC]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Prox":nil:mBase_adj_prox_low:mBase_adj_prox_up:[NSString stringWithFormat:@"%d",BaseAdjProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_SD":nil:nil:mBase_adj_SD_up:[NSString stringWithFormat:@"%d",BaseAdjSD]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Base_Adj_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",BaseAdjTemp]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"CPCL_SW_Version":nil:nil:nil:@"0800":nil:IP_NA:nil];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ;
	return ;
	
}

+(void)ParseProxValCheck:(NSDictionary*)dictKeyDefined
{
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mProjectType = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	/*
	 NSInteger syscfgProxInt = [[TestItemManage getUnitValue:dictKeyDefined :@"Prox Value"] integerValue];
	 NSInteger syscfgCenterpointInt = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxCenterpoint Value"] integerValue];
	 NSInteger syscfgTempInt = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp Value"] integerValue];
	 
	 // convert decimalism to hex string
	 NSString *syscfgProx = [NSString stringWithFormat:@"%02x", syscfgProxInt];
	 NSString *syscfgCenterpoint = [NSString stringWithFormat:@"%02x", syscfgCenterpointInt];
	 NSString *syscfgTemp = [NSString stringWithFormat:@"%02x", syscfgTempInt];
	 */
	
	NSString *syscfgProx = [ NSString stringWithFormat:@"%08x",[[TestItemManage getUnitValue:dictKeyDefined :@"Prox Value"] integerValue] ];
	NSString *syscfgCenterpoint = [ NSString stringWithFormat:@"%08x",[[TestItemManage getUnitValue:dictKeyDefined :@"ProxCenterpoint Value"] integerValue] ];
	NSString *syscfgTemp = [ NSString stringWithFormat:@"%08x",[[TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp Value"] integerValue] ];
	
	// serin 20101001
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
	//	NSString *syscfgStageRef = [ NSString stringWithFormat:@"%08x",[[TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"] integerValue] ];
	//end
	NSRange rangeSyscfgProx = [mReferenceBufferValue rangeOfString:[syscfgProx uppercaseString] ];
	NSRange rangeSyscfgCenterpoint = [mReferenceBufferValue rangeOfString:[syscfgCenterpoint uppercaseString] ];
	NSRange rangeSyscfgTemp = [mReferenceBufferValue rangeOfString:[syscfgTemp uppercaseString] ];
	
	// serin 20101001
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
	//	NSRange rangeSyscfgStageRef = [mReferenceBufferValue rangeOfString:[syscfgStageRef uppercaseString] ];
	//end
	//SCRID:41
	//Modified by caijunbo on 2010-12-16
	if ((rangeSyscfgProx.length <= 0) || (rangeSyscfgCenterpoint.length <= 0) || (rangeSyscfgTemp.length <= 0))
		//if ((rangeSyscfgProx.length <= 0) || (rangeSyscfgCenterpoint.length <= 0) || (rangeSyscfgTemp.length <= 0) || (rangeSyscfgStageRef.length <= 0))
		// end Modified by caijunbo on 2010-12-16
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Sysconfig value not found";
	}
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo];
	return ;
}

+(double)CalculateStdDev2:(NSArray*) AdjProxArray
                         :(NSInteger) AdjProxAvg
                         :(NSInteger) CalCnt
{
	double sqrtSum=0;
	for(int j=0; j<CalCnt; j++)
	{
		int tmpVal = [[AdjProxArray objectAtIndex:j] integerValue] - AdjProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/CalCnt);
	return (pow(tmpAvg,0.5));
}

/*
+(double)CalculateStdDev:(NSArray*) AdjProxArray
                        :(NSInteger) AdjProxAvg
                        :(NSInteger) CalCnt
{
	double sqrtSum=0;
	for(int j=1; j<CalCnt; j++)
	{
		int tmpVal = [[AdjProxArray objectAtIndex:j] integerValue] - AdjProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/[AdjProxArray count]);
	return (pow(tmpAvg,0.5));
}
 */
+(int)CalculateStdDev:(NSArray*) AdjProxArray
					 :(NSInteger) AdjProxAvg
					 :(NSInteger) CalCnt
{
	double sqrtSum=0;
	for(int j=1; j<=CalCnt; j++)
	{
		int tmpVal = [[AdjProxArray objectAtIndex:j] integerValue] - AdjProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/CalCnt);
	return (pow(tmpAvg,0.5));
}

// serin 20100721
+(int)CalculateStageStdDev:(NSArray*) AdjProxArray1
						  :(NSInteger) AdjProxAvg1
						  :(NSInteger) CalCnt1
{
	double sqrtSum=0;
	for(int j=0; j<CalCnt1; j++)
	{
		int tmpVal = [[AdjProxArray1 objectAtIndex:j] integerValue] - AdjProxAvg1;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/CalCnt1);
    //    double tmpAvg=4;
    double possssw = pow(tmpAvg,0.5);
    NSLog(@"%f",possssw);
	return (pow(tmpAvg,0.5));
}
// end


+(void)ParseProxVerification:(NSDictionary*)dictKeyDefined
{
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mReferenceBufferName_1 = nil;
	NSString *mVerification_Prox_Variation = @"";
	NSString *mVerification_Centerpoint_Variation = @"";
	NSString *mVerification_Temp_Variation = @"";
	NSString *mProjectType = nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	//	NSString *mProx_Verification_Loops = nil;
	//end
	
	NSString *mBase_prox_low = nil;
	NSString *mBase_prox_up = nil;
	NSString *mBase_centerpoint_low = nil;
	NSString *mBase_centerpoint_up = nil;
	NSString *mBase_temp_low = nil;
	NSString *mBase_temp_up = nil;
	
	NSString *mReferenceBufferValueSysList = nil;
	NSString *mReferenceBufferValueMeas = nil;
	
	NSInteger PBCl_Val = 0;
	NSInteger PBTb_Val = 0;
	NSInteger PBCb_Val = 0;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName_1"])
			mReferenceBufferName_1 = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Verification_Prox_Variation"])
			mVerification_Prox_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Verification_Centerpoint_Variation"])
			mVerification_Centerpoint_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Verification_Temp_Variation"])
			mVerification_Temp_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Prox_Verification_Loops"])
			mVerifyCnt = [[dictKeyDefined objectForKey:strKey] integerValue];
		
		else if ([strKey isEqualToString:@"Base_Prox_Lowlimit"])
			mBase_prox_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Prox_Upperlimit"])
			mBase_prox_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Lowlimit"])
			mBase_centerpoint_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Centerpoint_Upperlimit"])
			mBase_centerpoint_up = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Temp_Lowlimit"])
			mBase_temp_low = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Base_Temp_Upperlimit"])
			mBase_temp_up = [dictKeyDefined objectForKey:strKey] ;
	}
	
	mReferenceBufferValueSysList = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName_1] ;
	mReferenceBufferValueMeas = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValueSysList==nil || mReferenceBufferValueMeas==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	// serin 0620 add some criteria
	NSRange rangeCenterpoint = [mReferenceBufferValueMeas rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValueMeas rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValueMeas rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		return ;
	}
	// end
	
	/*
	 :-) syscfg list
	 Key: SrNm Value: YM947025DYH
	 Key: MLB# Value: J5946003TDAE0
	 Key: Mod# Value: K48
	 Key: Regn Value: LL/A
	 Key: Batt Value: W0941T0AX96W1
	 .....
	 .....
	 Key: MtSN Value: 359B600534M99CY3
	 Key: OPTS Value: WIFI&BT/GPS/UMTS/NAND,SIZE=32G/RAM,SIZE=256M
	 Key: SwBh Not Found!
	 Key: Teth Not Found!
	 Key: PBCl Value: 0x00008D6D 0x00000000 0x00000000 0x00000000
	 Key: PBTb Value: 0x00009C33 0x00000000 0x00000000 0x00000000
	 Key: PBCb Value: 0x00007FCC 0x00000000 0x00000000 0x00000000
	 Key: LTGO Not Found!
	 Key: HTGO Not Found!
	 Key: GSCl Not Found!
	 Key: ASCl Not Found!
	 Key: LTAO Not Found!
	 */
	
	NSRange rangePBCl_tmp = NSMakeRange([mReferenceBufferValueSysList rangeOfString:@"Key: PBCl Value: 0x"].location+19 , 8);
	NSRange rangePBTb_tmp = NSMakeRange([mReferenceBufferValueSysList rangeOfString:@"Key: PBTb Value: 0x"].location+19 , 8);
	NSRange rangePBCb_tmp = NSMakeRange([mReferenceBufferValueSysList rangeOfString:@"Key: PBCb Value: 0x"].location+19 , 8);
	
	NSString *PBCl_tmp = [mReferenceBufferValueSysList substringWithRange:rangePBCl_tmp];
	NSString *PBTb_tmp = [mReferenceBufferValueSysList substringWithRange:rangePBTb_tmp];
	NSString *PBCb_tmp = [mReferenceBufferValueSysList substringWithRange:rangePBCb_tmp];
	
	// convert hex string to int
	PBCl_Val = [ToolFun ConvertHexStrToInt:PBCl_tmp] ;
	PBTb_Val = [ToolFun ConvertHexStrToInt:PBTb_tmp] ;
	PBCb_Val = [ToolFun ConvertHexStrToInt:PBCb_tmp] ;
	/*
	 if(
	 (( [ToolFun ConvertHexStrToInt:mBase_prox_low] <= PBCl_Val) && (PBCl_Val<= [ToolFun ConvertHexStrToInt:mBase_prox_up]))
	 && ( ( [ToolFun ConvertHexStrToInt:mBase_centerpoint_low] <= PBTb_Val) && (PBTb_Val <= [ToolFun ConvertHexStrToInt:mBase_centerpoint_up]) )
	 && ( ( [ToolFun ConvertHexStrToInt:mBase_temp_low] <= PBCb_Val) && (PBCb_Val<= [ToolFun ConvertHexStrToInt:mBase_temp_up]))
	 )
	 */
	if(
	   (( [mBase_prox_low integerValue] <= PBCl_Val) && (PBCl_Val<= [mBase_prox_up integerValue]))
	   && ( ( [mBase_centerpoint_low integerValue] <=PBCb_Val ) && (PBCb_Val <= [mBase_centerpoint_up integerValue]) )
	   && ( ( [mBase_temp_low integerValue] <=PBTb_Val ) && (PBTb_Val<= [mBase_temp_up integerValue]))
	   )
		//if((PBCl_Val != 0) || (PBTb_Val != 0) || (PBCb_Val != 0) || (PBTa_Val != 0))
	{
		//enumResult =RESULT_FOR_PASS ;
		//strTestResultForUIinfo = @"PASS";
	}
	else
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = @"Sysconfig value not found";
	}
	
	NSMutableArray *mVerifyProx = nil;
	NSMutableArray *mVerifyCenterpoint = nil;
	NSMutableArray *mVerifyTemp = nil;
	
	int VerifyProxValue = 0;
	int VerifyCenterpointValue = 0;
	int VerifyTempValue = 0;
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	mVerifyProx = (NSMutableArray*)[mReferenceBufferValueMeas componentsSeparatedByString:@"- Prox: "];
	mVerifyTemp = (NSMutableArray*)[mReferenceBufferValueMeas componentsSeparatedByString:@"Temp: "];
	mVerifyCenterpoint = (NSMutableArray*)[mReferenceBufferValueMeas componentsSeparatedByString:@"Centerpoint: "];
	//end
	NSRange VerifyValueRange = NSMakeRange(0, 5);
	
	for(int i=1 ; i<=mVerifyCnt ; i++ )
	{
		[mVerifyProx replaceObjectAtIndex:i
							   withObject:[[mVerifyProx objectAtIndex:i] substringWithRange:VerifyValueRange]];
		
		[mVerifyTemp replaceObjectAtIndex:i
							   withObject:[[mVerifyTemp objectAtIndex:i] substringWithRange:VerifyValueRange]];
		
		[mVerifyCenterpoint replaceObjectAtIndex:i
									  withObject:[[mVerifyCenterpoint objectAtIndex:i] substringWithRange:VerifyValueRange]];
		
		VerifyProxValue			= VerifyProxValue + [[mVerifyProx objectAtIndex:i]integerValue];
		VerifyTempValue			= VerifyTempValue + [[mVerifyTemp objectAtIndex:i]integerValue];
		VerifyCenterpointValue	= VerifyCenterpointValue + [[mVerifyCenterpoint objectAtIndex:i]integerValue];
	}
	
	VerifyProxValue			= VerifyProxValue / mVerifyCnt ;
	VerifyTempValue			= VerifyTempValue / mVerifyCnt;
	VerifyCenterpointValue	= VerifyCenterpointValue / mVerifyCnt ;
	
	//SCRID:29
	// serin 20101206 add
	int DeltaProx=0;
	int DeltaCenterpoint=0;
	int DeltaTemp=0;
	DeltaProx = VerifyProxValue - PBCl_Val;
	DeltaTemp = VerifyTempValue - PBTb_Val;
	DeltaCenterpoint = VerifyCenterpointValue - PBCb_Val;
	// end
	
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"SysConfig_Prox":nil:nil:nil:[NSString stringWithFormat:@"%d",PBCl_Val]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"SysConfig_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",PBTb_Val]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"SysConfig_Centerpoint":nil:nil:nil:[NSString stringWithFormat:@"%d",PBCb_Val]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Current_Prox":nil:nil:nil:[NSString stringWithFormat:@"%d",VerifyProxValue]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Current_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",VerifyTempValue]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Current_Centerpoint":nil:nil:nil:[NSString stringWithFormat:@"%d",VerifyCenterpointValue]:nil:IP_NA:nil];
	//SCRID:29
	// serin 20101206 add
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta_Prox":nil:[NSString stringWithFormat:@"-%s",[mVerification_Prox_Variation UTF8String]]:[NSString stringWithFormat:@"%s",[mVerification_Prox_Variation UTF8String]]:[NSString stringWithFormat:@"%d",DeltaProx]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta_Temp":nil:[NSString stringWithFormat:@"-%s",[mVerification_Temp_Variation UTF8String]]:[NSString stringWithFormat:@"%s",[mVerification_Temp_Variation UTF8String]]:[NSString stringWithFormat:@"%d",DeltaTemp]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta_Centerpoint":nil:[NSString stringWithFormat:@"-%s",[mVerification_Centerpoint_Variation UTF8String]]:[NSString stringWithFormat:@"%s",[mVerification_Centerpoint_Variation UTF8String]]:[NSString stringWithFormat:@"%d",DeltaCenterpoint]:nil:IP_NA:nil];
	// end
	
	
	int errCnt = 0;
	if( VerifyProxValue < (PBCl_Val-[mVerification_Prox_Variation integerValue]) || VerifyProxValue > (PBCl_Val+[mVerification_Prox_Variation integerValue]) )
	{
		//SCRID:29
		// 20101206 serin delete
		/*
		 //SCRID:22
		 //Description:proximity verify for GateKeeper
		 //added by caijunbo on 2010-11-24
		 if (  ((VerifyProxValue>PBCl_Val-50)&&(VerifyProxValue < (PBCl_Val-[mVerification_Prox_Variation integerValue])) ) ||  ((VerifyProxValue<PBCl_Val+50)&&(VerifyProxValue > (PBCl_Val+[mVerification_Prox_Variation integerValue]))) )
		 
		 {
		 [TestItemManage setBufferValue:dictKeyDefined:@"BufferForQT3Retest":@"need retest"];
		 
		 }
		 */
		// end serin delete
		
		
		//end added by caijunbo on 2010-11-24
		NSString * strResult = [NSString stringWithFormat:@"CurrentProxValue:%d ,SyscfgProxValue:%d ",VerifyProxValue,PBCl_Val];
		enumResult =RESULT_FOR_FAIL ;
		//			strTestResultForUIinfo = @"Prox Value ;" ;
		strTestResultForUIinfo = strResult;
		errCnt++;
	}
	
	if( VerifyTempValue < (PBTb_Val-[mVerification_Temp_Variation integerValue]) || VerifyTempValue > (PBTb_Val+[mVerification_Temp_Variation integerValue]) )
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Temp Value ;"];
		errCnt++;
	}
	
	if( VerifyCenterpointValue < (PBCb_Val -[mVerification_Centerpoint_Variation integerValue]) || VerifyCenterpointValue > (PBCb_Val +[mVerification_Centerpoint_Variation integerValue]) )
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Centerpoint Value ;"];
		errCnt++;
	}
	
	// serin 20100724 delete
	/*
	 // serin 0512
	 else if(VerifyTempValue < (PBTa_Val-[mVerification_Temp_Variation integerValue]) || VerifyTempValue > (PBTa_Val+[mVerification_Temp_Variation integerValue]))
	 {
	 enumResult =RESULT_FOR_FAIL ;
	 strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Temp Value ;"];
	 }
	 else if(((VerifyTempValue < PBTb_Val-[mVerification_Temp_Variation integerValue]) || (VerifyTempValue > PBTb_Val+[mVerification_Temp_Variation integerValue]))
	 && (PBTb_Val != ( [mVerification_temp_clip_up integerValue] - 10 ))
	 && (PBTb_Val != ( [mVerification_temp_clip_low integerValue] + 10 )))
	 {
	 enumResult =RESULT_FOR_FAIL ;
	 strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"Temp Value ;"];
	 }
	 // end
	 */
	// end
	
	if(errCnt == 0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
}

+(void)ParseProx:(NSDictionary*)dictKeyDefined
{
	int gLowestDelta=100000;
	int gIndicator=-1;
	//NSString *strTestResultForUIinfo;
	NSString *strTestResultForUIinfo = @"" ; //2010-07-27
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mTempAlpha = nil;
	NSString *mDelta_Lowlimit = nil;
	NSString *mDelta_Upperlimit = nil;
	NSString *mCenterpoint_Variation = nil;
	NSString *mTemp_Variation = nil;
	NSString *mAdj_SD_Upperlimit = nil;
	NSString *mProjectType = nil;
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	NSString *mProxNameSpec = nil;
	//SCRID:100 end
	NSString *mTestAngle = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"TempAlpha"])
		{
			mTempAlpha = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Delta_Lowlimit"])
		{
			mDelta_Lowlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Delta_Upperlimit"])
		{
			mDelta_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
			
		}
		else if ([strKey isEqualToString:@"Centerpoint_Variation"])
			mCenterpoint_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Temp_Variation"])
			mTemp_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Adj_SD_Upperlimit"])
		{
			mAdj_SD_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		/** SCRID-51: Change prox baseline diags-cmd-loop from 600 to 100,change other distant diags-cmd-loop from 10 to 50. **/
		/** Joko 2010-12-23 **/
		else if ([strKey isEqualToString:@"ProxLoop"])
			mProxCnt = [[dictKeyDefined objectForKey:strKey] intValue];
		/** SCRID-51 end **/
		//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
		else if ([strKey isEqualToString:@"ProxNameSpec"])
			mProxNameSpec = [dictKeyDefined objectForKey:strKey];
		//SCRID:100 end.
		else if ([strKey isEqualToString:@"TestAngle"])
		{
			mTestAngle = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSMutableArray *ProxArray = nil;
	NSMutableArray *CenterpointArray = nil;
	NSMutableArray *TempArray = nil;
	NSMutableArray *AdjProxArray = nil;
	
	NSString *mReferenceBufferValue ;
	
	// serin 20100721
	NSMutableArray *FullStageValue = nil;
	NSMutableArray *FullarrayEachStageValue= [[NSMutableArray alloc] init];;
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//Add by Lucky for grab SOCHOT ERROR
	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
	//Lucky add end
	
	
    //	mReferenceBufferValue = @" :-) prox --stage all --loops 10 --measure 0	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16415, 32767, 16291, 62268, 47795, 29115, 32322, 31401, 32038, 48013, 7868 - Prox: 44396, Centerpoint: 32767, Temp: 47795, Adjusted_Prox: 11629 1	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32869, 16416, 32771, 16295, 62274, 47794, 29114, 32314, 31397, 32041, 48009, 7876 - Prox: 44394, Centerpoint: 32771, Temp: 47794, Adjusted_Prox: 11623 2	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16414, 32771, 16294, 62268, 47797, 29115, 32319, 31400, 32038, 48020, 7870 - Prox: 44401, Centerpoint: 32771, Temp: 47797, Adjusted_Prox: 11630 3	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16410, 32758, 16289, 62265, 47797, 29117, 32305, 31398, 32037, 48011, 7875 - Prox: 44403, Centerpoint: 32758, Temp: 47797, Adjusted_Prox: 11645 4	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16414, 32768, 16293, 62266, 47792, 29112, 32317, 31400, 32039, 48000, 7870 - Prox: 44391, Centerpoint: 32768, Temp: 47792, Adjusted_Prox: 11623 5	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16417, 32768, 16298, 62263, 47795, 29117, 32310, 31400, 32039, 48012, 7867 - Prox: 44391, Centerpoint: 32768, Temp: 47795, Adjusted_Prox: 11623 6	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16418, 32768, 16291, 62274, 47796, 29113, 32315, 31405, 32035, 48027, 7876 - Prox: 44403, Centerpoint: 32768, Temp: 47796, Adjusted_Prox: 11635 7	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32868, 16410, 32768, 16293, 62269, 47798, 29115, 32322, 31401, 32041, 48007, 7871 - Prox: 44395, Centerpoint: 32768, Temp: 47798, Adjusted_Prox: 11627 8	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16412, 32768, 16292, 62274, 47797, 29111, 32315, 31400, 32039, 48011, 7866 - Prox: 44394, Centerpoint: 32768, Temp: 47797, Adjusted_Prox: 11626 9	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16419, 32770, 16294, 62252, 47792, 29116, 32320, 31400, 32039, 48010, 7865 - Prox: 44389, Centerpoint: 32770, Temp: 47792, Adjusted_Prox: 11619";
    //mReferenceBufferValue = @"prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 prox:		 20s:271659us (+00s:000000us) = 0: 0  1: 0  2: 32486  3: 15904  4: 50000  5: 44095  6: 35207  7: 44265  8: 0  9: 0  10: 0  11: 0  - Prox: 29015, Centerpoint: 32486, Temp: 44095, Adjusted_Prox: -3471 ";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    //add by judith for new diag format 20121201
	for (int i = 1; i < 10; i++)
    {
        mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@" %d: ",i] withString:@","];
    }
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 10: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 11: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    //add ended
	// serin 0620 add some criteria
	NSRange rangeCenterpoint = [mReferenceBufferValue rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValue rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		return ;
	}
    
	ProxArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"- Prox: "];
	CenterpointArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Centerpoint: "];
	TempArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	AdjProxArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Adjusted_Prox: "];
	
    if ([mReferenceBufferValue rangeOfString:@"= 0: "].length == 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please Download the Latest Diag which receive data contains string '= 0: '"] ;
        [FullarrayEachStageValue release];
		return ;
        
    }
	FullStageValue = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"= 0: "];//modified by judith changed Sensorreading to = 0:
    
	
	NSRange ProxRange = NSMakeRange(0, 5);
	NSRange CenterpointRange = NSMakeRange(0, 5);
	NSRange TempRange = NSMakeRange(0, 5);
	NSRange AdjProxRange = NSMakeRange(0, 5);
	
	NSRange FullstageLen = [[FullStageValue objectAtIndex:1] rangeOfString:@" - Prox: "];
	
	NSInteger ProxValue=0;
	NSInteger CenterpointValue=0;
	NSInteger TempValue=0;
	NSInteger AdjProxValue=0;
	
	NSMutableString *FullAllStageValue= [[NSMutableString alloc] init];
	NSLog(@"before replace ProxArray = %@",ProxArray);
    NSLog(@"before replace CenterpointArray = %@",CenterpointArray);
    NSLog(@"before replace TempArray = %@",TempArray);
    NSLog(@"before replace AdjProxArray = %@",AdjProxArray);
    NSLog(@"before replace FullStageValue = %@",FullStageValue);
	int ProxCount = [ProxArray count];
    int CenterCount = [CenterpointArray count];
    int TempCount = [TempArray count];
    int AdjCount = [AdjProxArray count];
    int StageCount = [FullStageValue count];
    if (ProxCount > mProxCnt+1 || CenterCount > mProxCnt+1 || TempCount > mProxCnt+1 || AdjCount >mProxCnt+1 || StageCount >mProxCnt+1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"] ;
        [FullAllStageValue release];
        [FullarrayEachStageValue release];
		return ;
    }
	for(int i=1 ; i<=mProxCnt ; i++ )
	{
        //add by judith for improve the exception error 20121201
        NSRange FullStageValueRange = NSMakeRange(0,FullstageLen.location);
        
        if ([[ProxArray objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[CenterpointArray objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[TempArray objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[AdjProxArray objectAtIndex:i] rangeOfString:@","].location < 5 ||
            [[FullStageValue objectAtIndex:i] rangeOfString:@","].location < 5)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"The Data Length is Less than 5 or %d,Please Check the Data!",FullStageValueRange.length]] ;
            [FullStageValue release];
            [FullarrayEachStageValue release];
            return ;
        }
        
		[ProxArray replaceObjectAtIndex:i
							 withObject:[[ProxArray objectAtIndex:i] substringWithRange:ProxRange]];
		
		[CenterpointArray replaceObjectAtIndex:i
									withObject:[[CenterpointArray objectAtIndex:i] substringWithRange:CenterpointRange]];
		
		[TempArray replaceObjectAtIndex:i
							 withObject:[[TempArray objectAtIndex:i] substringWithRange:TempRange]];
		
		[AdjProxArray replaceObjectAtIndex:i
								withObject:[[AdjProxArray objectAtIndex:i] substringWithRange:AdjProxRange]];
		
		
		[FullStageValue replaceObjectAtIndex:i
								  withObject:[[FullStageValue objectAtIndex:i] substringWithRange:FullStageValueRange]];
		
		ProxValue			= ProxValue + [[ProxArray objectAtIndex:i]integerValue];
		CenterpointValue	= CenterpointValue + [[CenterpointArray objectAtIndex:i]integerValue];
		TempValue			= TempValue + [[TempArray objectAtIndex:i]integerValue];
		AdjProxValue		= AdjProxValue + [[AdjProxArray objectAtIndex:i]integerValue];
		
		[FullAllStageValue appendString:[FullStageValue objectAtIndex:i]];
		[FullAllStageValue appendString:@","];
	}
	NSLog(@"after replace ProxArray = %@",ProxArray);
    NSLog(@"after replace CenterpointArray = %@",CenterpointArray);
    NSLog(@"after replace TempArray = %@",TempArray);
    NSLog(@"after replace AdjProxArray = %@",AdjProxArray);
    NSLog(@"after replace FullStageValue = %@",FullStageValue);
    NSLog(@"after replace FullAllStageValue = %@",FullAllStageValue);
	NSArray *FullarrayAllStageValue=nil;
	FullarrayAllStageValue =[FullAllStageValue componentsSeparatedByString:@","];
	
    NSLog(@"arrayAllStageValue = %@",FullarrayAllStageValue);
	int FullAverageValue = 0;
	int FullStageSD = 0;
	for (int i=0;i<12;i++)
	{
		FullAverageValue=0;
		[FullarrayEachStageValue removeAllObjects];
        int MaxValue = 11+(mProxCnt-1)*12;
        if ([FullarrayAllStageValue count] < MaxValue)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Sensor Reading Data Count is %d,Less than BaseLoop %d",[FullarrayAllStageValue count],MaxValue]] ;
            [FullAllStageValue release];
            [FullarrayEachStageValue release];
            return ;
            
        }
		for(int j=0;j<mProxCnt;j++)
		{
			FullAverageValue+=[[FullarrayAllStageValue objectAtIndex:(i+j*12)] intValue];
			[FullarrayEachStageValue addObject:[FullarrayAllStageValue objectAtIndex:(i+j*12)]];
		}
		FullAverageValue= FullAverageValue/mProxCnt;
		FullStageSD = [self CalculateStageStdDev: FullarrayEachStageValue: FullAverageValue:mProxCnt];
        NSLog(@"FullStageSD = %d",FullStageSD);
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d average",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",FullAverageValue]:nil:IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d SD",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",FullStageSD]:nil:IP_NA:nil];
	}
	[FullAllStageValue release];
	[FullarrayEachStageValue release];
	
	NSInteger ProxAvg			= ProxValue / mProxCnt ;
	
    
	if ([mTestItemName rangeOfString:@"Angle:90"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree90ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"Angle:0"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"2nd Threshold"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree180ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	NSInteger CenterpointAvg	= CenterpointValue / mProxCnt ;
	NSInteger TempAvg			= TempValue / mProxCnt ;
	float AdjProxAvg		= (float)AdjProxValue / mProxCnt; //jiansheng change by Brian request 2012-06-14
	NSInteger AdjSD				= [self CalculateStdDev: AdjProxArray: AdjProxAvg: mProxCnt];
	NSInteger AdjTemp			= TempAvg - CenterpointAvg;
	
	NSInteger BaselineTempAdj = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxTempAdj Value"] integerValue];
	NSLog(@"BaselineTempAdj = %d",BaselineTempAdj);
	// serin 20101120 move
	NSInteger BaselineProxAdj = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxAdj Value"] integerValue];
	NSLog(@"BaselineProxAdj = %d",BaselineProxAdj);
	// serin20110117
	/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
	//NSInteger Prox_FinalAdj = AdjProxAvg - ([mTempAlpha integerValue] * (AdjTemp - BaselineTempAdj) );
	//float Prox_FinalAdj = AdjProxAvg - ([mTempAlpha floatValue] * (AdjTemp - BaselineTempAdj) );//jiansheng change by Brian request 2012-06-14
	// end
	NSInteger Prox_FinalAdj =round(AdjProxAvg); //jiansheng change by Brian request 2012-06-14
	NSInteger Delta = Prox_FinalAdj - BaselineProxAdj;
	//added by caijunbo on 2011-09-14
	//used to get the lowest Delta value
	gIndicator=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue];
	//gIndicator=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue];//modify by henry 20120928 for PoleStar PVT request by Brian
    gLowestDelta=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"]intValue];
    NSLog(@"gIndicator = %d",gIndicator);
    NSLog(@"gIndicator = %d",gIndicator);
	if (gLowestDelta>Delta)
	{
		gLowestDelta=Delta;
		
		if([mTestAngle isEqualToString:@"0degree"])
			gIndicator = 0;
		else if([mTestAngle isEqualToString:@"90degree"])
			gIndicator = 1;
		//else if([mTestAngle isEqualToString:@"180degree"])//modify by henry, for the PoleStar PVT, this should not be counted. request by Brian 20120928
        //gIndicator = 2;
		else
			gIndicator = -1;
		
		//gIndicator++;
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator" :[NSString stringWithFormat:@"%d",gIndicator]];
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue" :[NSString stringWithFormat:@"%d",gLowestDelta]];
	}
	
    if([mTestAngle isEqualToString:@"0degree"])
        
        //judge whether it is the final testitem or not, if true, then upload the latest critical position value
	{
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Critical_Position_value":nil:nil:nil:[NSString stringWithFormat:@"%d",gIndicator]:nil:IP_NA:nil];
	}
    //Henry add end
    
	NSInteger mBaselineCenterpoint = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxCenterpoint Value"] integerValue] ;
	NSInteger mBaselineTemp = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp Value"] integerValue] ;
	// end
	NSLog(@"mBaselineCenterpoint = %d",mBaselineCenterpoint);
    NSLog(@"mBaselineTemp = %d",mBaselineTemp);
	// serin 20101006
	int iSum=0;
	int iCheckSum;
	
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	//NSRange rangeTestItemName = [mTestItemName rangeOfString:@"Angle:90 degree	Distance: 8(mm)"];
	NSRange rangeTestItemName;
	if(mProxNameSpec != nil)
	{
		rangeTestItemName = [mTestItemName rangeOfString:mProxNameSpec];
		//SCRID:100 end.
		if(rangeTestItemName.length > 0)
		{
			NSString *ProxParamsValue = [TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"];
            
            NSLog(@"ProxParamsValue = %@",ProxParamsValue);
            NSLog(@"BufferForTheLowestDeltaIndicator = %d",[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue]);
			NSArray *ParamsArray=nil;
			ParamsArray =[ProxParamsValue componentsSeparatedByString:@" "];
			NSString *ProxParamsValueFin = @"";
			
			//added by caijunbo on 2010-11-18
			//SCRID:21
			for(int arrIndex=0; arrIndex < (ParamsArray.count); arrIndex++)
			{
				//added by caijunbo on 2011-09-14
				//used to write the critical position,where has the lowest Delta value.
				if(arrIndex == 1)
				{
					switch ([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue])
					{
						case 0:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",0]];
							break;
						case 1:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",1]];
							break;
                            //case 2: Modify by henry, request from Brian, for PS PVT 20120928
							//ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",2]];
							//break;
						default:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",0]];
							break;
					}
					
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
				//end
				
				else if(arrIndex == 13 )
				{
					//added by caijunbo on 2011-09-15
					//used to prepare Prox value where we get the lowest Delat value for CPCl
					switch ([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue])
					{
						case 0:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg"]];
							break;
						case 1:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree90ProxAvg"]];
							break;
                            //case 2: Modify by henry, request from Brian, for PS PVT 20120928
                            //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree180ProxAvg"]];
							//break;
						default:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg"]];
							break;
					}
					//end
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
                //Diabled by judith 20130129 this value fixed in CPCl table
				/*
				 else if(arrIndex == 15)
				 {
				 //SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format
				 // serin 20110117
				 //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-360)]];
				 //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-240)]];
				 // end
				 
				 //SCRID:72 Modify Proximity to change syscfg key CPCl value
				 //Modified by caijunbo on 2011-01-29
				 //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-220)]];
				 //end
				 //Modified by caijunbo on 2011-05-21
				 //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-291)]];
				 //end
				 
				 //Modified by Junbo 2011-09-13
				 //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-236)]];
				 //end
				 
				 //SCRID:2	Modified by Ray 2011-11-08
				 
				 //if([mProjectType isEqualToString:@"OnlyQL2"])
				 //	ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-276)]];
				 //else
				 //	ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-288)]];
				 
				 //SCRID:2	end
				 
				 //SCRID:3	Modified Limit for PVT by Ray 2011-11-08
				 if([mProjectType isEqualToString:@"OnlyQL2"])
				 ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-290)]];
				 else
				 ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-290)]];
				 //SCRID:3	end
				 
				 ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				 }
				 */
				// end
				else
				{
					
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[ParamsArray objectAtIndex:arrIndex]];
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
			}
			
			NSString* highByte=@"";
			NSString* lowByte=@"";
			NSString* Struct=@"0x";
			NSString* HexString1=@"";
			NSString* HexString2=@"";
			NSString* FinalProxParams=@"";
			NSArray* tempArray =[ProxParamsValueFin componentsSeparatedByString:@" "];
			
			
			if ([tempArray count] < 2*12)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Prox Params Value Data Count %d < 24,setUnitValue error",[tempArray count]]] ;
                [FullarrayEachStageValue release];
                [FullStageValue release];
                return ;
            }
			// the loop below is used to calculate isum
			for (int loop=2;loop<12;loop++)
			{
				
				HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
				if (HexString1.length>4)
				{
					HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
				}
				
				
				highByte=[HexString1 substringToIndex:2];
				lowByte=[HexString1 substringFromIndex:2];
				
				iSum+=strtol([highByte UTF8String],NULL,16);
				iSum+=strtol([lowByte UTF8String],NULL,16);
				
				
				HexString2=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop+1)] intValue]];
				if (HexString2.length>4)
				{
					HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
				}
				
				highByte=[HexString2 substringToIndex:2];
				lowByte=[HexString2 substringFromIndex:2];
				
				iSum+=strtol([highByte UTF8String],NULL,16);
				iSum+=strtol([lowByte UTF8String],NULL,16);
			}
			iCheckSum=(~iSum)+1;
			
			
			//the loop below is used to generate Prox Params Value
			for (int loop=0;loop<12;loop++)
			{
				if (loop!=1)
				{
					HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
					if (HexString1.length>4)
					{
						HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
					}
					HexString2=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop+1)] intValue]];
					if (HexString2.length>4)
					{
						HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
					}
				}
				
				else
				{
					
					HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
					if (HexString1.length>4)
					{
						HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
					}
					HexString2=[NSString stringWithFormat:@"%04x",iCheckSum];
					if (HexString2.length>4)
					{
						HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
					}
				}
				
				Struct=[Struct stringByAppendingString:HexString2];
				Struct=[Struct stringByAppendingString:HexString1];
				if (loop!=11)
				{
					FinalProxParams=[FinalProxParams stringByAppendingString:Struct];
					FinalProxParams=[FinalProxParams stringByAppendingString:@" "];
				}
				else
					FinalProxParams=[FinalProxParams stringByAppendingString:Struct];
				//after one loop reset Struct to 0x;
				Struct=@"0x";
			}
			//SCRID:21
			//added end by caijunbo on 2010-11-18
			
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":FinalProxParams];
		}
		// end
	}
	
	// set pudding data		[NSString stringWithFormat:@"%d",itemp]
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox":nil:nil:nil:[NSString stringWithFormat:@"%d",ProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Centerpoint":nil:nil:nil:[NSString stringWithFormat:@"%d",CenterpointAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",TempAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_Prox":nil:nil:nil:[NSString stringWithFormat:@"%.2f",AdjProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_SD":nil:nil:mAdj_SD_Upperlimit:[NSString stringWithFormat:@"%d",AdjSD]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",AdjTemp]:nil:IP_NA:nil];
	
    //Add for EVT upload ALPHA value to PDCA by Henry 2012-04-26
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"ALPHA":nil:nil:nil:mTempAlpha:nil:IP_NA:nil];
    //add by Henry end
    
	/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
	// serin 20110119
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox_FinalAdj":nil:nil:nil:[NSString stringWithFormat:@"%d",Prox_FinalAdj]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox_FinalAdj":nil:nil:nil:[NSString stringWithFormat:@"%d",Prox_FinalAdj]:nil:IP_NA:nil];
	// end
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta":nil:mDelta_Lowlimit:mDelta_Upperlimit:[NSString stringWithFormat:@"%d",Delta]:nil:IP_NA:nil];
	
	//Date:2011-01-21  Owner:Helen  Description:show limits on UI when Prox Cal test fail.
	//SCRID:91 Description:Show fail value on UI for Prox cal station by Helen 2011-03-21.
    if(((mDelta_Lowlimit==nil||[mDelta_Lowlimit length]<=0)?0:(Delta < [mDelta_Lowlimit integerValue]))
       || ((mDelta_Upperlimit==nil||[mDelta_Upperlimit length]<=0)?0:(Delta > [mDelta_Upperlimit integerValue])))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [NSString stringWithFormat: @"Delta Value:%d [ %@ , %@ ];",Delta,mDelta_Lowlimit,mDelta_Upperlimit];
	}
	
    else if(((mCenterpoint_Variation==nil||[mCenterpoint_Variation length]<=0)?0:(CenterpointAvg < (mBaselineCenterpoint-[mCenterpoint_Variation integerValue])) || (CenterpointAvg > (mBaselineCenterpoint+[mCenterpoint_Variation integerValue]))))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%d [ %d , %d ];",CenterpointAvg,(mBaselineCenterpoint-[mCenterpoint_Variation integerValue]),(mBaselineCenterpoint+[mCenterpoint_Variation integerValue])]];
	}
    else if(((mTemp_Variation==nil||[mTemp_Variation length]<=0)?0:(TempAvg < (mBaselineTemp-[mTemp_Variation integerValue])) || (TempAvg > (mBaselineTemp+[mTemp_Variation integerValue]))))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%d [ %d , %d ];",TempAvg,(mBaselineTemp-[mTemp_Variation integerValue]),(mBaselineTemp+[mTemp_Variation integerValue])]];
	}
    else if((mAdj_SD_Upperlimit==nil||[mAdj_SD_Upperlimit length]<=0)?0:(AdjSD > [mAdj_SD_Upperlimit integerValue]))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%d [ >= %@ ];",AdjSD,mAdj_SD_Upperlimit]];
	}
	//SCRID:91 end.
	//end
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
	
	
	// modified by caijunbo on 2011-10-10
	/*
	 ProxParaDelta = Delta;
	 ProxParaSD = AdjSD;
	 */
	
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximityDeltaValue":[NSString stringWithFormat:@"%d",Delta]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximitySDValue":[NSString stringWithFormat:@"%d",AdjSD]];
	// end
	
	//SCRID:21
	//added by caijunbo on 2010-11-18
	
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	//SCRID:21
	//added by caijunbo on 2010-11-18
	//rangeTestItemName = [mTestItemName rangeOfString:@"Angle:90 degree	Distance: 8(mm)"];
	if(mProxNameSpec != nil)
	{
		rangeTestItemName = [mTestItemName rangeOfString:mProxNameSpec];
		//SCRID:100 end.
		if(rangeTestItemName.length > 0)
		{
			NSString* TotalValue=[NSString stringWithFormat:@"\nTotal value is: 0x%04x",iSum];
			NSString* complimentValue=[NSString stringWithFormat:@"\n2's compliment value is: 0x%04x\n",iCheckSum];
			strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:TotalValue] ;
			strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:complimentValue] ;
		}
		//SCRID:21
		//added end by caijunbo on 2010-11-18
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return;
}


//add by Blake to try new sensor 20130816--start
+(void)ParseProx_NewSensor:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo = @"" ;
	enum TestResutStatus enumResult ;
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mDelta_Lowlimit = nil;
	NSString *mDelta_Upperlimit = nil;
	NSString *mProx_SD_Upperlimit = nil;
	NSString *mProjectType = nil;
	NSString *mTestAngle = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Delta_Lowlimit"])
		{
			mDelta_Lowlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Delta_Upperlimit"])
		{
			mDelta_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Prox_SD_Upperlimit"])
		{
			mProx_SD_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		else if ([strKey isEqualToString:@"ProxLoop"])
			mProxCnt = [[dictKeyDefined objectForKey:strKey] intValue];
		else if ([strKey isEqualToString:@"TestAngle"])
		{
			mTestAngle = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSMutableArray *ProxArray = [[NSMutableArray alloc] init];
	
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    NSString *abstime = [mReferenceBufferValue substringToIndex:15];
    if (abstime==nil) {
        enumResult = RESULT_FOR_FAIL;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"diag return error!" ];
        [ProxArray release];
        return;
    }
    NSInteger proxValue = 0;
    NSArray *bufferArray = [mReferenceBufferValue componentsSeparatedByString:abstime];
    for (int i = 1; i < [bufferArray count]; i++)
    {
        NSArray *arrayTmp= [[bufferArray objectAtIndex:i] componentsSeparatedByString:@" : "];
        if ([arrayTmp count] < 7) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diag return different format error!"];
            [ProxArray removeAllObjects];
            [ProxArray release];
            return;
        }
        [ProxArray addObject:[arrayTmp objectAtIndex:3]];
        proxValue = proxValue + [[arrayTmp objectAtIndex:3] integerValue];
    }
    int proxCnt = [ProxArray count];
    if (proxCnt > mProxCnt +1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"] ;
        [ProxArray removeAllObjects];
        [ProxArray release];
        return;
    }
    double ProxAvg = (double)proxValue / proxCnt;
    
    if ([mTestItemName rangeOfString:@"Angle:90"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree90ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"Angle:0"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"2nd Threshold"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree180ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
    double BaselineProx = [[TestItemManage getUnitValue:dictKeyDefined :@"Prox Value"] floatValue];
    NSInteger Prox_Final =round(ProxAvg); //jiansheng change by Brian request 2012-06-14
	NSInteger Delta = Prox_Final - BaselineProx;
    
    double sqrtSum=0;
	for(int j=0; j < proxCnt; j++)
	{
		double tmpVal = [[ProxArray objectAtIndex:j] integerValue] - ProxAvg;
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
	double tmpAvg=(sqrtSum/proxCnt);
	NSInteger Prox_SD = pow(tmpAvg,0.5);
    
    //    NSInteger Prox_SD = [self CalculateStdDev:ProxArray :ProxAvg :proxCnt];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox":nil:nil:nil:[NSString stringWithFormat:@"%d",ProxAvg]:nil:IP_NA:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox_SD":nil:nil:mProx_SD_Upperlimit:[NSString stringWithFormat:@"%d",Prox_SD]:nil:IP_NA:nil];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta":nil:mDelta_Lowlimit:mDelta_Upperlimit:[NSString stringWithFormat:@"%d",Delta]:nil:IP_NA:nil];
    if(((mDelta_Lowlimit==nil||[mDelta_Lowlimit length]<=0)?0:(Delta < [mDelta_Lowlimit integerValue]))
       || ((mDelta_Upperlimit==nil||[mDelta_Upperlimit length]<=0)?0:(Delta > [mDelta_Upperlimit integerValue])))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [NSString stringWithFormat: @"Delta Value:%d [ %@ , %@ ];",Delta,mDelta_Lowlimit,mDelta_Upperlimit];
	}
    else if((mProx_SD_Upperlimit==nil||[mProx_SD_Upperlimit length]<=0)?0:(Prox_SD > [mProx_SD_Upperlimit integerValue]))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%d [ >= %@ ];",Prox_SD,mProx_SD_Upperlimit]];
	}
    else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
    [TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximityDeltaValue":[NSString stringWithFormat:@"%d",Delta]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximitySDValue":[NSString stringWithFormat:@"%d",Prox_SD]];
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    [ProxArray removeAllObjects];
    [ProxArray release];
	return;
}
//Blake add end about try new sensor 20130816

+(void)ParseProxForQL2:(NSDictionary*)dictKeyDefined
{
	int gLowestDelta=100000;
	int gIndicator=-1;
	//NSString *strTestResultForUIinfo;
	NSString *strTestResultForUIinfo = @"" ; //2010-07-27
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mTempAlpha = nil;
	NSString *mDelta_Lowlimit = nil;
	NSString *mDelta_Upperlimit = nil;
	NSString *mCenterpoint_Variation = nil;
	NSString *mTemp_Variation = nil;
	NSString *mAdj_SD_Upperlimit = nil;
	NSString *mProjectType = nil;
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	NSString *mProxNameSpec = nil;
	//SCRID:100 end
	NSString *mTestAngle = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"TempAlpha"])
		{
			mTempAlpha = [dictKeyDefined objectForKey:strKey] ;
			
		}
		
		else if ([strKey isEqualToString:@"Delta_Lowlimit"])
		{
			mDelta_Lowlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Delta_Upperlimit"])
		{
			mDelta_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
			
		}
		else if ([strKey isEqualToString:@"Centerpoint_Variation"])
			mCenterpoint_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Temp_Variation"])
			mTemp_Variation = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"Adj_SD_Upperlimit"])
		{
			mAdj_SD_Upperlimit = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		/** SCRID-51: Change prox baseline diags-cmd-loop from 600 to 100,change other distant diags-cmd-loop from 10 to 50. **/
		/** Joko 2010-12-23 **/
		else if ([strKey isEqualToString:@"ProxLoop"])
			mProxCnt = [[dictKeyDefined objectForKey:strKey] intValue];
		/** SCRID-51 end **/
		//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
		else if ([strKey isEqualToString:@"ProxNameSpec"])
			mProxNameSpec = [dictKeyDefined objectForKey:strKey];
		//SCRID:100 end.
		else if ([strKey isEqualToString:@"TestAngle"])
		{
			mTestAngle = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSMutableArray *ProxArray = nil;
	NSMutableArray *CenterpointArray = nil;
	NSMutableArray *TempArray = nil;
	NSMutableArray *AdjProxArray = nil;
	
	NSString *mReferenceBufferValue ;
	
	// serin 20100721
	NSMutableArray *FullStageValue = nil;
	NSMutableArray *FullarrayEachStageValue= [[NSMutableArray alloc] init];;
	
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//Add by Lucky for grab SOCHOT ERROR
	NSRange rangeSocHot = [mReferenceBufferValue rangeOfString:@"SOCHOT0 detected!"];
	NSRange rangeSocHot1 = [mReferenceBufferValue rangeOfString:@"script: device -k ThermalSensor -e read"];
	NSRange rangeSocHot2 = [mReferenceBufferValue rangeOfString:@"script: pmutemp --read all"];
	NSRange rangeSocHot3 = [mReferenceBufferValue rangeOfString:@"script: vbat"];
	NSRange rangeSocHot4 = [mReferenceBufferValue rangeOfString:@"Hanging..."];
	
	if (rangeSocHot.length > 0 || rangeSocHot1.length > 0 || rangeSocHot2.length > 0 || rangeSocHot3.length > 0 || rangeSocHot4.length > 0) {
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"ERROR: SOCHOT0 detected!"] ;
		return ;
	}
    // mReferenceBufferValue = @"prox:		 228s:390715us (+00s:000000us) = 0: -17 (0.00) 1: -5725 (0.00) 2: -15613 (0.00) 3: -4806 (0.00) 4: 932 (0.00) 5: -1150 (0.00) 6: 417 (0.00) 7: 408 (0.00) 8: 464 (0.00) 9: 415 (0.00) 10: 458 (0.00) 11: 432 (0.00) 12: 399 (0.00) 13: 470 (0.00) 14: 436 (0.00) 15: 9622 (0.00) - Prox: -19344, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19327 prox:		 228s:788856us (+00s:398141us) = 0: -19 (0.00) 1: -5602 (0.00) 2: -15500 (0.00) 3: -4698 (0.00) 4: 965 (0.00) 5: -1160 (0.00) 6: 344 (0.00) 7: 370 (0.00) 8: 366 (0.00) 9: 375 (0.00) 10: 342 (0.00) 11: 389 (0.00) 12: 396 (0.00) 13: 362 (0.00) 14: 373 (0.00) 15: 9622 (0.00) - Prox: -19424, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19405 prox:		 229s:187006us (+00s:398150us) = 0: -17 (0.00) 1: -5592 (0.00) 2: -15497 (0.00) 3: -4686 (0.00) 4: 946 (0.00) 5: -1163 (0.00) 6: 353 (0.00) 7: 307 (0.00) 8: 356 (0.00) 9: 325 (0.00) 10: 349 (0.00) 11: 373 (0.00) 12: 393 (0.00) 13: 319 (0.00) 14: 342 (0.00) 15: 9622 (0.00) - Prox: -19462, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19445 prox:		 229s:585151us (+00s:398145us) = 0: -17 (0.00) 1: -5590 (0.00) 2: -15489 (0.00) 3: -4684 (0.00) 4: 892 (0.00) 5: -1164 (0.00) 6: 326 (0.00) 7: 335 (0.00) 8: 326 (0.00) 9: 337 (0.00) 10: 329 (0.00) 11: 328 (0.00) 12: 304 (0.00) 13: 347 (0.00) 14: 312 (0.00) 15: 9622 (0.00) - Prox: -19463, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19446 prox:		 229s:983256us (+00s:398105us) = 0: -17 (0.00) 1: -5587 (0.00) 2: -15489 (0.00) 3: -4686 (0.00) 4: 911 (0.00) 5: -1165 (0.00) 6: 309 (0.00) 7: 323 (0.00) 8: 322 (0.00) 9: 287 (0.00) 10: 305 (0.00) 11: 321 (0.00) 12: 334 (0.00) 13: 337 (0.00) 14: 299 (0.00) 15: 9622 (0.00) - Prox: -19483, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19466 prox:		 230s:381376us (+00s:398120us) = 0: -17 (0.00) 1: -5587 (0.00) 2: -15488 (0.00) 3: -4683 (0.00) 4: 898 (0.00) 5: -1166 (0.00) 6: 234 (0.00) 7: 246 (0.00) 8: 277 (0.00) 9: 241 (0.00) 10: 271 (0.00) 11: 298 (0.00) 12: 295 (0.00) 13: 294 (0.00) 14: 280 (0.00) 15: 9622 (0.00) - Prox: -19531, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19514 prox:		 230s:779484us (+00s:398108us) = 0: -16 (0.00) 1: -5585 (0.00) 2: -15487 (0.00) 3: -4688 (0.00) 4: 884 (0.00) 5: -1164 (0.00) 6: 302 (0.00) 7: 291 (0.00) 8: 308 (0.00) 9: 253 (0.00) 10: 267 (0.00) 11: 249 (0.00) 12: 269 (0.00) 13: 202 (0.00) 14: 250 (0.00) 15: 9622 (0.00) - Prox: -19533, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19517 prox:		 231s:177607us (+00s:398123us) = 0: -15 (0.00) 1: -5589 (0.00) 2: -15490 (0.00) 3: -4687 (0.00) 4: 863 (0.00) 5: -1162 (0.00) 6: 284 (0.00) 7: 229 (0.00) 8: 284 (0.00) 9: 278 (0.00) 10: 291 (0.00) 11: 301 (0.00) 12: 281 (0.00) 13: 308 (0.00) 14: 302 (0.00) 15: 9622 (0.00) - Prox: -19518, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19503 prox:		 231s:575712us (+00s:398105us) = 0: -18 (0.00) 1: -5588 (0.00) 2: -15489 (0.00) 3: -4686 (0.00) 4: 878 (0.00) 5: -1167 (0.00) 6: 250 (0.00) 7: 291 (0.00) 8: 247 (0.00) 9: 312 (0.00) 10: 276 (0.00) 11: 261 (0.00) 12: 275 (0.00) 13: 291 (0.00) 14: 284 (0.00) 15: 9622 (0.00) - Prox: -19525, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19507 prox:		 231s:973818us (+00s:398106us) = 0: -19 (0.00) 1: -5591 (0.00) 2: -15489 (0.00) 3: -4685 (0.00) 4: 928 (0.00) 5: -1159 (0.00) 6: 293 (0.00) 7: 305 (0.00) 8: 307 (0.00) 9: 279 (0.00) 10: 284 (0.00) 11: 293 (0.00) 12: 296 (0.00) 13: 307 (0.00) 14: 300 (0.00) 15: 9622 (0.00) - Prox: -19497, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19478 prox:		 232s:371926us (+00s:398108us) = 0: -16 (0.00) 1: -5587 (0.00) 2: -15491 (0.00) 3: -4686 (0.00) 4: 866 (0.00) 5: -1160 (0.00) 6: 281 (0.00) 7: 293 (0.00) 8: 244 (0.00) 9: 236 (0.00) 10: 274 (0.00) 11: 291 (0.00) 12: 272 (0.00) 13: 343 (0.00) 14: 292 (0.00) 15: 9622 (0.00) - Prox: -19529, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19513 prox:		 232s:770059us (+00s:398133us) = 0: -17 (0.00) 1: -5590 (0.00) 2: -15495 (0.00) 3: -4690 (0.00) 4: 840 (0.00) 5: -1162 (0.00) 6: 269 (0.00) 7: 304 (0.00) 8: 305 (0.00) 9: 294 (0.00) 10: 320 (0.00) 11: 280 (0.00) 12: 298 (0.00) 13: 276 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19515, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19498 prox:		 233s:168213us (+00s:398154us) = 0: -18 (0.00) 1: -5592 (0.00) 2: -15488 (0.00) 3: -4689 (0.00) 4: 852 (0.00) 5: -1159 (0.00) 6: 248 (0.00) 7: 252 (0.00) 8: 268 (0.00) 9: 290 (0.00) 10: 315 (0.00) 11: 301 (0.00) 12: 290 (0.00) 13: 249 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19516, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19498 prox:		 233s:566367us (+00s:398154us) = 0: -17 (0.00) 1: -5595 (0.00) 2: -15495 (0.00) 3: -4687 (0.00) 4: 846 (0.00) 5: -1164 (0.00) 6: 269 (0.00) 7: 301 (0.00) 8: 299 (0.00) 9: 270 (0.00) 10: 272 (0.00) 11: 265 (0.00) 12: 264 (0.00) 13: 223 (0.00) 14: 269 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19513 prox:		 233s:964517us (+00s:398150us) = 0: -16 (0.00) 1: -5595 (0.00) 2: -15492 (0.00) 3: -4689 (0.00) 4: 869 (0.00) 5: -1155 (0.00) 6: 311 (0.00) 7: 235 (0.00) 8: 277 (0.00) 9: 260 (0.00) 10: 260 (0.00) 11: 222 (0.00) 12: 295 (0.00) 13: 285 (0.00) 14: 255 (0.00) 15: 9622 (0.00) - Prox: -19524, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19508 prox:		 234s:362657us (+00s:398140us) = 0: -18 (0.00) 1: -5595 (0.00) 2: -15499 (0.00) 3: -4692 (0.00) 4: 893 (0.00) 5: -1160 (0.00) 6: 253 (0.00) 7: 251 (0.00) 8: 278 (0.00) 9: 290 (0.00) 10: 326 (0.00) 11: 305 (0.00) 12: 297 (0.00) 13: 274 (0.00) 14: 297 (0.00) 15: 9622 (0.00) - Prox: -19524, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19506 prox:		 234s:760802us (+00s:398145us) = 0: -17 (0.00) 1: -5595 (0.00) 2: -15497 (0.00) 3: -4693 (0.00) 4: 839 (0.00) 5: -1149 (0.00) 6: 284 (0.00) 7: 272 (0.00) 8: 218 (0.00) 9: 247 (0.00) 10: 218 (0.00) 11: 273 (0.00) 12: 212 (0.00) 13: 241 (0.00) 14: 273 (0.00) 15: 9622 (0.00) - Prox: -19555, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19538 prox:		 235s:158955us (+00s:398153us) = 0: -19 (0.00) 1: -5596 (0.00) 2: -15500 (0.00) 3: -4693 (0.00) 4: 817 (0.00) 5: -1155 (0.00) 6: 232 (0.00) 7: 240 (0.00) 8: 273 (0.00) 9: 214 (0.00) 10: 268 (0.00) 11: 251 (0.00) 12: 238 (0.00) 13: 235 (0.00) 14: 239 (0.00) 15: 9622 (0.00) - Prox: -19565, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19546 prox:		 235s:557098us (+00s:398143us) = 0: -19 (0.00) 1: -5599 (0.00) 2: -15502 (0.00) 3: -4692 (0.00) 4: 815 (0.00) 5: -1149 (0.00) 6: 256 (0.00) 7: 242 (0.00) 8: 221 (0.00) 9: 259 (0.00) 10: 247 (0.00) 11: 251 (0.00) 12: 283 (0.00) 13: 283 (0.00) 14: 268 (0.00) 15: 9622 (0.00) - Prox: -19545, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19526 prox:		 235s:955223us (+00s:398125us) = 0: -17 (0.00) 1: -5600 (0.00) 2: -15496 (0.00) 3: -4694 (0.00) 4: 840 (0.00) 5: -1153 (0.00) 6: 215 (0.00) 7: 220 (0.00) 8: 250 (0.00) 9: 231 (0.00) 10: 225 (0.00) 11: 240 (0.00) 12: 250 (0.00) 13: 244 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19558, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19541 prox:		 236s:353352us (+00s:398129us) = 0: -17 (0.00) 1: -5600 (0.00) 2: -15499 (0.00) 3: -4699 (0.00) 4: 860 (0.00) 5: -1148 (0.00) 6: 221 (0.00) 7: 237 (0.00) 8: 216 (0.00) 9: 271 (0.00) 10: 284 (0.00) 11: 223 (0.00) 12: 263 (0.00) 13: 265 (0.00) 14: 268 (0.00) 15: 9622 (0.00) - Prox: -19545, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19528 prox:		 236s:751512us (+00s:398160us) = 0: -18 (0.00) 1: -5600 (0.00) 2: -15505 (0.00) 3: -4698 (0.00) 4: 850 (0.00) 5: -1146 (0.00) 6: 271 (0.00) 7: 259 (0.00) 8: 227 (0.00) 9: 233 (0.00) 10: 239 (0.00) 11: 266 (0.00) 12: 242 (0.00) 13: 274 (0.00) 14: 244 (0.00) 15: 9622 (0.00) - Prox: -19557, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19539 prox:		 237s:149673us (+00s:398161us) = 0: -20 (0.00) 1: -5601 (0.00) 2: -15500 (0.00) 3: -4700 (0.00) 4: 803 (0.00) 5: -1152 (0.00) 6: 216 (0.00) 7: 217 (0.00) 8: 254 (0.00) 9: 271 (0.00) 10: 282 (0.00) 11: 232 (0.00) 12: 223 (0.00) 13: 253 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19549, Centerpoint: -20, Temp: 0, Adjusted_Prox: -19529 prox:		 237s:547832us (+00s:398159us) = 0: -17 (0.00) 1: -5612 (0.00) 2: -15500 (0.00) 3: -4702 (0.00) 4: 834 (0.00) 5: -1149 (0.00) 6: 250 (0.00) 7: 193 (0.00) 8: 203 (0.00) 9: 259 (0.00) 10: 225 (0.00) 11: 294 (0.00) 12: 275 (0.00) 13: 270 (0.00) 14: 252 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19513 prox:		 237s:945979us (+00s:398147us) = 0: -17 (0.00) 1: -5604 (0.00) 2: -15501 (0.00) 3: -4700 (0.00) 4: 841 (0.00) 5: -1146 (0.00) 6: 228 (0.00) 7: 254 (0.00) 8: 203 (0.00) 9: 247 (0.00) 10: 217 (0.00) 11: 252 (0.00) 12: 275 (0.00) 13: 220 (0.00) 14: 247 (0.00) 15: 9622 (0.00) - Prox: -19555, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19538 prox:		 238s:344120us (+00s:398141us) = 0: -17 (0.00) 1: -5607 (0.00) 2: -15501 (0.00) 3: -4700 (0.00) 4: 847 (0.00) 5: -1144 (0.00) 6: 199 (0.00) 7: 272 (0.00) 8: 273 (0.00) 9: 236 (0.00) 10: 241 (0.00) 11: 276 (0.00) 12: 268 (0.00) 13: 287 (0.00) 14: 266 (0.00) 15: 9622 (0.00) - Prox: -19528, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19511 prox:		 238s:742257us (+00s:398137us) = 0: -19 (0.00) 1: -5610 (0.00) 2: -15503 (0.00) 3: -4703 (0.00) 4: 839 (0.00) 5: -1143 (0.00) 6: 206 (0.00) 7: 237 (0.00) 8: 263 (0.00) 9: 208 (0.00) 10: 239 (0.00) 11: 259 (0.00) 12: 258 (0.00) 13: 259 (0.00) 14: 247 (0.00) 15: 9622 (0.00) - Prox: -19543, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19524 prox:		 239s:140395us (+00s:398138us) = 0: -19 (0.00) 1: -5610 (0.00) 2: -15508 (0.00) 3: -4703 (0.00) 4: 850 (0.00) 5: -1146 (0.00) 6: 293 (0.00) 7: 269 (0.00) 8: 285 (0.00) 9: 261 (0.00) 10: 298 (0.00) 11: 257 (0.00) 12: 259 (0.00) 13: 281 (0.00) 14: 287 (0.00) 15: 9622 (0.00) - Prox: -19517, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19498 prox:		 239s:538539us (+00s:398144us) = 0: -18 (0.00) 1: -5610 (0.00) 2: -15514 (0.00) 3: -4706 (0.00) 4: 845 (0.00) 5: -1143 (0.00) 6: 226 (0.00) 7: 291 (0.00) 8: 284 (0.00) 9: 258 (0.00) 10: 252 (0.00) 11: 242 (0.00) 12: 291 (0.00) 13: 231 (0.00) 14: 242 (0.00) 15: 9622 (0.00) - Prox: -19549, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19531 prox:		 239s:936671us (+00s:398132us) = 0: -16 (0.00) 1: -5610 (0.00) 2: -15508 (0.00) 3: -4708 (0.00) 4: 832 (0.00) 5: -1140 (0.00) 6: 271 (0.00) 7: 301 (0.00) 8: 317 (0.00) 9: 312 (0.00) 10: 269 (0.00) 11: 244 (0.00) 12: 258 (0.00) 13: 278 (0.00) 14: 256 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19495 prox:		 240s:334798us (+00s:398127us) = 0: -17 (0.00) 1: -5609 (0.00) 2: -15513 (0.00) 3: -4716 (0.00) 4: 849 (0.00) 5: -1140 (0.00) 6: 272 (0.00) 7: 276 (0.00) 8: 293 (0.00) 9: 247 (0.00) 10: 253 (0.00) 11: 270 (0.00) 12: 253 (0.00) 13: 253 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19544, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19527 prox:		 240s:732946us (+00s:398148us) = 0: -17 (0.00) 1: -5612 (0.00) 2: -15514 (0.00) 3: -4713 (0.00) 4: 863 (0.00) 5: -1137 (0.00) 6: 292 (0.00) 7: 271 (0.00) 8: 265 (0.00) 9: 258 (0.00) 10: 283 (0.00) 11: 289 (0.00) 12: 285 (0.00) 13: 285 (0.00) 14: 276 (0.00) 15: 9622 (0.00) - Prox: -19522, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19505 prox:		 241s:131088us (+00s:398142us) = 0: -18 (0.00) 1: -5615 (0.00) 2: -15518 (0.00) 3: -4713 (0.00) 4: 845 (0.00) 5: -1135 (0.00) 6: 257 (0.00) 7: 271 (0.00) 8: 265 (0.00) 9: 306 (0.00) 10: 278 (0.00) 11: 286 (0.00) 12: 262 (0.00) 13: 251 (0.00) 14: 279 (0.00) 15: 9622 (0.00) - Prox: -19528, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19510 prox:		 241s:529223us (+00s:398135us) = 0: -16 (0.00) 1: -5621 (0.00) 2: -15515 (0.00) 3: -4715 (0.00) 4: 827 (0.00) 5: -1134 (0.00) 6: 271 (0.00) 7: 270 (0.00) 8: 257 (0.00) 9: 272 (0.00) 10: 294 (0.00) 11: 268 (0.00) 12: 270 (0.00) 13: 223 (0.00) 14: 253 (0.00) 15: 9622 (0.00) - Prox: -19519, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19503 prox:		 241s:927353us (+00s:398130us) = 0: -17 (0.00) 1: -5616 (0.00) 2: -15521 (0.00) 3: -4717 (0.00) 4: 828 (0.00) 5: -1136 (0.00) 6: 280 (0.00) 7: 278 (0.00) 8: 232 (0.00) 9: 279 (0.00) 10: 243 (0.00) 11: 270 (0.00) 12: 247 (0.00) 13: 268 (0.00) 14: 262 (0.00) 15: 9622 (0.00) - Prox: -19546, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19529 prox:		 242s:325499us (+00s:398146us) = 0: -18 (0.00) 1: -5622 (0.00) 2: -15523 (0.00) 3: -4720 (0.00) 4: 798 (0.00) 5: -1132 (0.00) 6: 222 (0.00) 7: 248 (0.00) 8: 258 (0.00) 9: 253 (0.00) 10: 244 (0.00) 11: 258 (0.00) 12: 259 (0.00) 13: 229 (0.00) 14: 248 (0.00) 15: 9622 (0.00) - Prox: -19554, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19536 prox:		 242s:723646us (+00s:398147us) = 0: -16 (0.00) 1: -5626 (0.00) 2: -15528 (0.00) 3: -4722 (0.00) 4: 793 (0.00) 5: -1131 (0.00) 6: 287 (0.00) 7: 232 (0.00) 8: 240 (0.00) 9: 222 (0.00) 10: 223 (0.00) 11: 247 (0.00) 12: 190 (0.00) 13: 219 (0.00) 14: 257 (0.00) 15: 9622 (0.00) - Prox: -19568, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19552 prox:		 243s:121780us (+00s:398134us) = 0: -16 (0.00) 1: -5622 (0.00) 2: -15519 (0.00) 3: -4722 (0.00) 4: 810 (0.00) 5: -1131 (0.00) 6: 208 (0.00) 7: 284 (0.00) 8: 258 (0.00) 9: 239 (0.00) 10: 263 (0.00) 11: 238 (0.00) 12: 286 (0.00) 13: 254 (0.00) 14: 246 (0.00) 15: 9622 (0.00) - Prox: -19539, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19523 prox:		 243s:519910us (+00s:398130us) = 0: -17 (0.00) 1: -5620 (0.00) 2: -15520 (0.00) 3: -4723 (0.00) 4: 843 (0.00) 5: -1130 (0.00) 6: 284 (0.00) 7: 208 (0.00) 8: 243 (0.00) 9: 263 (0.00) 10: 207 (0.00) 11: 228 (0.00) 12: 205 (0.00) 13: 260 (0.00) 14: 245 (0.00) 15: 9622 (0.00) - Prox: -19563, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19546 prox:		 243s:918052us (+00s:398142us) = 0: -17 (0.00) 1: -5625 (0.00) 2: -15521 (0.00) 3: -4724 (0.00) 4: 844 (0.00) 5: -1128 (0.00) 6: 285 (0.00) 7: 229 (0.00) 8: 285 (0.00) 9: 285 (0.00) 10: 262 (0.00) 11: 264 (0.00) 12: 287 (0.00) 13: 270 (0.00) 14: 255 (0.00) 15: 9622 (0.00) - Prox: -19522, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19505 prox:		 244s:316150us (+00s:398098us) = 0: -15 (0.00) 1: -5626 (0.00) 2: -15524 (0.00) 3: -4724 (0.00) 4: 826 (0.00) 5: -1122 (0.00) 6: 287 (0.00) 7: 255 (0.00) 8: 202 (0.00) 9: 306 (0.00) 10: 236 (0.00) 11: 260 (0.00) 12: 237 (0.00) 13: 237 (0.00) 14: 258 (0.00) 15: 9622 (0.00) - Prox: -19540, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19525 prox:		 244s:714254us (+00s:398104us) = 0: -15 (0.00) 1: -5629 (0.00) 2: -15534 (0.00) 3: -4728 (0.00) 4: 820 (0.00) 5: -1122 (0.00) 6: 269 (0.00) 7: 264 (0.00) 8: 292 (0.00) 9: 294 (0.00) 10: 262 (0.00) 11: 260 (0.00) 12: 238 (0.00) 13: 264 (0.00) 14: 269 (0.00) 15: 9622 (0.00) - Prox: -19541, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19526 prox:		 245s:112379us (+00s:398125us) = 0: -17 (0.00) 1: -5632 (0.00) 2: -15528 (0.00) 3: -4727 (0.00) 4: 796 (0.00) 5: -1125 (0.00) 6: 272 (0.00) 7: 282 (0.00) 8: 265 (0.00) 9: 280 (0.00) 10: 308 (0.00) 11: 310 (0.00) 12: 268 (0.00) 13: 264 (0.00) 14: 265 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -17, Temp: 0, Adjusted_Prox: -19494 prox:		 245s:510499us (+00s:398120us) = 0: -18 (0.00) 1: -5629 (0.00) 2: -15538 (0.00) 3: -4729 (0.00) 4: 842 (0.00) 5: -1126 (0.00) 6: 242 (0.00) 7: 317 (0.00) 8: 269 (0.00) 9: 256 (0.00) 10: 305 (0.00) 11: 304 (0.00) 12: 229 (0.00) 13: 297 (0.00) 14: 266 (0.00) 15: 9622 (0.00) - Prox: -19539, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19521 prox:		 245s:908607us (+00s:398108us) = 0: -18 (0.00) 1: -5638 (0.00) 2: -15536 (0.00) 3: -4732 (0.00) 4: 790 (0.00) 5: -1122 (0.00) 6: 287 (0.00) 7: 240 (0.00) 8: 278 (0.00) 9: 251 (0.00) 10: 279 (0.00) 11: 247 (0.00) 12: 245 (0.00) 13: 224 (0.00) 14: 237 (0.00) 15: 9622 (0.00) - Prox: -19536, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19518 prox:		 246s:306718us (+00s:398111us) = 0: -15 (0.00) 1: -5633 (0.00) 2: -15533 (0.00) 3: -4731 (0.00) 4: 821 (0.00) 5: -1123 (0.00) 6: 293 (0.00) 7: 270 (0.00) 8: 268 (0.00) 9: 298 (0.00) 10: 255 (0.00) 11: 248 (0.00) 12: 229 (0.00) 13: 304 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19530, Centerpoint: -15, Temp: 0, Adjusted_Prox: -19515 prox:		 246s:704828us (+00s:398110us) = 0: -19 (0.00) 1: -5636 (0.00) 2: -15535 (0.00) 3: -4734 (0.00) 4: 808 (0.00) 5: -1116 (0.00) 6: 262 (0.00) 7: 252 (0.00) 8: 311 (0.00) 9: 303 (0.00) 10: 255 (0.00) 11: 256 (0.00) 12: 291 (0.00) 13: 299 (0.00) 14: 275 (0.00) 15: 9622 (0.00) - Prox: -19514, Centerpoint: -19, Temp: 0, Adjusted_Prox: -19495 prox:		 247s:102958us (+00s:398130us) = 0: -16 (0.00) 1: -5635 (0.00) 2: -15538 (0.00) 3: -4735 (0.00) 4: 806 (0.00) 5: -1117 (0.00) 6: 244 (0.00) 7: 210 (0.00) 8: 233 (0.00) 9: 248 (0.00) 10: 246 (0.00) 11: 268 (0.00) 12: 304 (0.00) 13: 312 (0.00) 14: 262 (0.00) 15: 9622 (0.00) - Prox: -19542, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19526 prox:		 247s:501090us (+00s:398132us) = 0: -18 (0.00) 1: -5640 (0.00) 2: -15537 (0.00) 3: -4737 (0.00) 4: 831 (0.00) 5: -1115 (0.00) 6: 282 (0.00) 7: 292 (0.00) 8: 289 (0.00) 9: 284 (0.00) 10: 304 (0.00) 11: 266 (0.00) 12: 250 (0.00) 13: 286 (0.00) 14: 281 (0.00) 15: 9622 (0.00) - Prox: -19511, Centerpoint: -18, Temp: 0, Adjusted_Prox: -19493 prox:		 247s:899209us (+00s:398119us) = 0: -16 (0.00) 1: -5637 (0.00) 2: -15539 (0.00) 3: -4740 (0.00) 4: 825 (0.00) 5: -1114 (0.00) 6: 269 (0.00) 7: 229 (0.00) 8: 214 (0.00) 9: 276 (0.00) 10: 280 (0.00) 11: 231 (0.00) 12: 212 (0.00) 13: 184 (0.00) 14: 234 (0.00) 15: 9622 (0.00) - Prox: -19564, Centerpoint: -16, Temp: 0, Adjusted_Prox: -19548 OK ";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    //add by judith for new diag format 20121201
    NSLog(@"before %@",mReferenceBufferValue);
    for (int i = 1; i < 10; i++)
    {
        mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:[NSString stringWithFormat:@" %d: ",i] withString:@","];
    }
	mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 10: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 11: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 12: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 13: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 14: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" 15: " withString:@","];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"(0.00)" withString:@""];
    
    //add ended
	// serin 0620 add some criteria
	NSRange rangeCenterpoint = [mReferenceBufferValue rangeOfString:@"Centerpoint: "];
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	NSRange rangeAdjProx = [mReferenceBufferValue rangeOfString:@"Adjusted_Prox: "];
	
	if ((rangeCenterpoint.length <= 0) || (rangeTemp.length <= 0) || (rangeAdjProx.length <= 0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		return ;
	}
    
	ProxArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"- Prox: "];
	CenterpointArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Centerpoint: "];
	TempArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	AdjProxArray = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"Adjusted_Prox: "];
	
    if ([mReferenceBufferValue rangeOfString:@"= 0: "].length == 0) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please Download the Latest Diag which receive data contains string '= 0: '"] ;
        [FullarrayEachStageValue release];
		return ;
        
    }
	FullStageValue = (NSMutableArray*)[mReferenceBufferValue componentsSeparatedByString:@"= 0: "];//modified by judith changed Sensorreading to = 0:
    
	
	NSRange ProxRange;
	NSRange CenterpointRange;
	NSRange TempRange;
	NSRange AdjProxRange;
	
	NSRange FullstageLen = [[FullStageValue objectAtIndex:1] rangeOfString:@" - Prox: "];
	
	NSInteger ProxValue=0;
	NSInteger CenterpointValue=0;
	NSInteger TempValue=0;
	NSInteger AdjProxValue=0;
	
	NSMutableString *FullAllStageValue= [[NSMutableString alloc] init];
	NSLog(@"before replace ProxArray = %@",ProxArray);
    NSLog(@"before replace CenterpointArray = %@",CenterpointArray);
    NSLog(@"before replace TempArray = %@",TempArray);
    NSLog(@"before replace AdjProxArray = %@",AdjProxArray);
    NSLog(@"before replace FullStageValue = %@",FullStageValue);
	int ProxCount = [ProxArray count];
    int CenterCount = [CenterpointArray count];
    int TempCount = [TempArray count];
    int AdjCount = [AdjProxArray count];
    int StageCount = [FullStageValue count];
    if (ProxCount > mProxCnt+1 || CenterCount > mProxCnt+1 || TempCount > mProxCnt+1 || AdjCount >mProxCnt+1 || StageCount >mProxCnt+1)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received data Error!the data count shoud be equaled to BaseLoop"] ;
        [FullAllStageValue release];
        [FullarrayEachStageValue release];
		return ;
    }
	for(int i=1 ; i<=mProxCnt ; i++ )
	{
        //add by judith for improve the exception error 20121201
        NSRange FullStageValueRange = NSMakeRange(0,FullstageLen.location);
        
        ProxRange = [[ProxArray objectAtIndex:i] rangeOfString:@","];
        CenterpointRange = [[CenterpointArray objectAtIndex:i] rangeOfString:@","];
        TempRange = [[TempArray objectAtIndex:i] rangeOfString:@","];
        AdjProxRange = [[AdjProxArray objectAtIndex:i] rangeOfString:@" "];
        if(ProxRange.length == 0 || CenterpointRange.length == 0 || TempRange.length == 0 || AdjProxRange.length == 0 || [[FullStageValue objectAtIndex:i] length] < FullStageValueRange.location)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Data no string ',' or else. in case of below happen exception"] ;
            [FullarrayEachStageValue release];
            [FullStageValue release];
            return ;
        }
        
		[ProxArray replaceObjectAtIndex:i
							 withObject:[[ProxArray objectAtIndex:i] substringToIndex:ProxRange.location]];
		
		[CenterpointArray replaceObjectAtIndex:i
									withObject:[[CenterpointArray objectAtIndex:i] substringToIndex:CenterpointRange.location]];
		
		//[TempArray replaceObjectAtIndex:i
		//					 withObject:[[TempArray objectAtIndex:i] substringWithRange:TempRange]];
		
		[AdjProxArray replaceObjectAtIndex:i
								withObject:[[AdjProxArray objectAtIndex:i] substringToIndex:AdjProxRange.location]];
		
		
		[FullStageValue replaceObjectAtIndex:i
								  withObject:[[FullStageValue objectAtIndex:i] substringWithRange:FullStageValueRange]];
		
        // add by judith as temperature has new algorithm(use stage 15 as temp value) 20121205
        NSArray *tempArray = [[FullStageValue objectAtIndex:i] componentsSeparatedByString:@","];
        if ([tempArray count] != 16)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Diag not return 16 Stage (0 ~ 15)!"] ;
            return ;
            
        }
        [TempArray replaceObjectAtIndex:i
                             withObject:[tempArray objectAtIndex:15]];
		//add ended 20121205
        
        ProxValue			= ProxValue + [[ProxArray objectAtIndex:i]integerValue];
		CenterpointValue	= CenterpointValue + [[CenterpointArray objectAtIndex:i]integerValue];
		TempValue			= TempValue + [[TempArray objectAtIndex:i]integerValue];
		AdjProxValue		= AdjProxValue + [[AdjProxArray objectAtIndex:i]integerValue];
		
		[FullAllStageValue appendString:[FullStageValue objectAtIndex:i]];
		[FullAllStageValue appendString:@","];
	}
	NSLog(@"after replace ProxArray = %@",ProxArray);
    NSLog(@"after replace CenterpointArray = %@",CenterpointArray);
    NSLog(@"after replace TempArray = %@",TempArray);
    NSLog(@"after replace AdjProxArray = %@",AdjProxArray);
    NSLog(@"after replace FullStageValue = %@",FullStageValue);
    NSLog(@"after replace FullAllStageValue = %@",FullAllStageValue);
	NSArray *FullarrayAllStageValue=nil;
	FullarrayAllStageValue =[FullAllStageValue componentsSeparatedByString:@","];
	
    NSLog(@"arrayAllStageValue = %@",FullarrayAllStageValue);
	int FullAverageValue = 0;
	int FullStageSD = 0;
	for (int i=0;i<16;i++)
	{
		FullAverageValue=0;
		[FullarrayEachStageValue removeAllObjects];
        int MaxValue = 15+(mProxCnt-1)*16;
        if ([FullarrayAllStageValue count] < MaxValue)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Sensor Reading Data Count is %d,Less than BaseLoop %d",[FullarrayAllStageValue count],MaxValue]] ;
            [FullAllStageValue release];
            [FullarrayEachStageValue release];
            return ;
            
        }
		for(int j=0;j<mProxCnt;j++)
		{
			FullAverageValue+=[[FullarrayAllStageValue objectAtIndex:(i+j*16)] intValue];
			[FullarrayEachStageValue addObject:[FullarrayAllStageValue objectAtIndex:(i+j*16)]];
		}
		FullAverageValue= FullAverageValue/mProxCnt;
		FullStageSD = [self CalculateStageStdDev: FullarrayEachStageValue: FullAverageValue:mProxCnt];
        NSLog(@"FullStageSD = %d",FullStageSD);
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d average",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",FullAverageValue]:nil:IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Stage %d SD",(i+1)]:nil:nil:nil:[NSString stringWithFormat:@"%d",FullStageSD]:nil:IP_NA:nil];
	}
	[FullAllStageValue release];
	[FullarrayEachStageValue release];
	
	NSInteger ProxAvg			= ProxValue / mProxCnt ;
	
    
	if ([mTestItemName rangeOfString:@"Angle:90"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree90ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"Angle:0"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	if ([mTestItemName rangeOfString:@"2nd Threshold"].length>0)
	{
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForDegree180ProxAvg":[NSString stringWithFormat:@"%d",ProxAvg]];
	}
	NSInteger CenterpointAvg	= CenterpointValue / mProxCnt ;
	NSInteger TempAvg			= TempValue / mProxCnt ;
	float AdjProxAvg		= (float)AdjProxValue / mProxCnt; //jiansheng change by Brian request 2012-06-14
	NSInteger AdjSD				= [self CalculateStdDev: AdjProxArray: AdjProxAvg: mProxCnt];
	NSInteger AdjTemp			= TempAvg - CenterpointAvg;
	
    // add by judith as temperature has new algorithm(use stage 15 as temp value) 20121205
    
    float proxTemperatureRaw = 0.0;
    int proxTemperatureC = 0;
    if (TempAvg < 0)
        proxTemperatureRaw = TempAvg + 65536;
    else
        proxTemperatureRaw = TempAvg;
    proxTemperatureC = ((proxTemperatureRaw - 32768) / 64) - 273;
    
    //add ended 20121205
    
	NSInteger BaselineTempAdj = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxTempAdj Value"] integerValue];
	NSLog(@"BaselineTempAdj = %d",BaselineTempAdj);
	// serin 20101120 move
	NSInteger BaselineProxAdj = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxAdj Value"] integerValue];
	NSLog(@"BaselineProxAdj = %d",BaselineProxAdj);
	// serin20110117
	/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
	//NSInteger Prox_FinalAdj = AdjProxAvg - ([mTempAlpha integerValue] * (AdjTemp - BaselineTempAdj) );
	//float Prox_FinalAdj = AdjProxAvg - ([mTempAlpha floatValue] * (AdjTemp - BaselineTempAdj) );//jiansheng change by Brian request 2012-06-14
	// end
	NSInteger Prox_FinalAdj =round(AdjProxAvg); //jiansheng change by Brian request 2012-06-14
	NSInteger Delta = Prox_FinalAdj - BaselineProxAdj;
	//added by caijunbo on 2011-09-14
	//used to get the lowest Delta value
	gIndicator=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue];
	//gIndicator=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue];//modify by henry 20120928 for PoleStar PVT request by Brian
    gLowestDelta=[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"]intValue];
    NSLog(@"gIndicator = %d",gIndicator);
    NSLog(@"gIndicator = %d",gIndicator);
	if (gLowestDelta>Delta)
	{
		gLowestDelta=Delta;
		
		if([mTestAngle isEqualToString:@"0degree"])
			gIndicator = 0;
		else if([mTestAngle isEqualToString:@"90degree"])
			gIndicator = 1;
		//else if([mTestAngle isEqualToString:@"180degree"])//modify by henry, for the PoleStar PVT, this should not be counted. request by Brian 20120928
        //gIndicator = 2;
		else
			gIndicator = -1;
		
		//gIndicator++;
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator" :[NSString stringWithFormat:@"%d",gIndicator]];
		[TestItemManage setBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue" :[NSString stringWithFormat:@"%d",gLowestDelta]];
	}
	
    if([mTestAngle isEqualToString:@"0degree"])
        
        //judge whether it is the final testitem or not, if true, then upload the latest critical position value
	{
		[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Critical_Position_value":nil:nil:nil:[NSString stringWithFormat:@"%d",gIndicator]:nil:IP_NA:nil];
	}
    //Henry add end
    
	NSInteger mBaselineCenterpoint = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxCenterpoint Value"] integerValue] ;
	NSInteger mBaselineTemp = [[TestItemManage getUnitValue:dictKeyDefined :@"ProxTemp Value"] integerValue] ;
	// end
	NSLog(@"mBaselineCenterpoint = %d",mBaselineCenterpoint);
    NSLog(@"mBaselineTemp = %d",mBaselineTemp);
	// serin 20101006
	int iSum=0;
	int iCheckSum;
	
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	//NSRange rangeTestItemName = [mTestItemName rangeOfString:@"Angle:90 degree	Distance: 8(mm)"];
	NSRange rangeTestItemName;
	if(mProxNameSpec != nil)
	{
		rangeTestItemName = [mTestItemName rangeOfString:mProxNameSpec];
		//SCRID:100 end.
		if(rangeTestItemName.length > 0)
		{
			NSString *ProxParamsValue = [TestItemManage getUnitValue:dictKeyDefined :@"Prox Params Value"];
            
            NSLog(@"ProxParamsValue = %@",ProxParamsValue);
            NSLog(@"BufferForTheLowestDeltaIndicator = %d",[[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue]);
			NSArray *ParamsArray=nil;
			ParamsArray =[ProxParamsValue componentsSeparatedByString:@" "];
			NSString *ProxParamsValueFin = @"";
			
			//added by caijunbo on 2010-11-18
			//SCRID:21
			for(int arrIndex=0; arrIndex < (ParamsArray.count); arrIndex++)
			{
				//added by caijunbo on 2011-09-14
				//used to write the critical position,where has the lowest Delta value.
				if(arrIndex == 1)
				{
					switch ([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue])
					{
						case 0:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",0]];
							break;
						case 1:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",1]];
							break;
                            //case 2: Modify by henry, request from Brian, for PS PVT 20120928
							//ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",2]];
							//break;
						default:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",0]];
							break;
					}
					
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
				//end
				
				else if(arrIndex == 13 )
				{
					//added by caijunbo on 2011-09-15
					//used to prepare Prox value where we get the lowest Delat value for CPCl
					switch ([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaIndicator"] intValue])
					{
						case 0:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg"]];
							break;
						case 1:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree90ProxAvg"]];
							break;
                            //case 2: Modify by henry, request from Brian, for PS PVT 20120928
                            //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree180ProxAvg"]];
							//break;
						default:
							ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[TestItemManage getBufferValue:dictKeyDefined :@"BufferForDegree0ProxAvg"]];
							break;
					}
					//end
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
				//Diabled by judith 20130129 this value fixed in CPCl table
                //                else if(arrIndex == 15)
                //                {
                //                    //SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format
                //                    // serin 20110117
                //                    //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-360)]];
                //                    //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-240)]];
                //                    // end
                //
                //                    //SCRID:72 Modify Proximity to change syscfg key CPCl value
                //                    //Modified by caijunbo on 2011-01-29
                //                    //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-220)]];
                //                    //end
                //                    //Modified by caijunbo on 2011-05-21
                //                    //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",(Delta-291)]];
                //                    //end
                //
                //                    //Modified by Junbo 2011-09-13
                //                    //ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-236)]];
                //                    //end
                //
                //                    //SCRID:2	Modified by Ray 2011-11-08
                //
                //                    //if([mProjectType isEqualToString:@"OnlyQL2"])
                //                    //	ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-276)]];
                //                    //else
                //                    //	ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-288)]];
                //
                //                    //SCRID:2	end
                //
                //                    //SCRID:3	Modified Limit for PVT by Ray 2011-11-08
                //                    if([mProjectType isEqualToString:@"OnlyQL2"])
                //                        ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-290)]];
                //                    else
                //                        ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[NSString stringWithFormat:@"%d",([[TestItemManage getBufferValue:dictKeyDefined :@"BufferForTheLowestDeltaValue"] intValue]-290)]];
                //                    //SCRID:3	end
                //
                //                    ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
                //                }
                
				// end
				else
				{
					
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:[ParamsArray objectAtIndex:arrIndex]];
					ProxParamsValueFin = [ProxParamsValueFin stringByAppendingString:@" "];
				}
			}
			
			NSString* highByte=@"";
			NSString* lowByte=@"";
			NSString* Struct=@"0x";
			NSArray* tempArray=@"";
			NSString* HexString1=@"";
			NSString* HexString2=@"";
			NSString* FinalProxParams=@"";
			tempArray =[ProxParamsValueFin componentsSeparatedByString:@" "];
			
			
			if ([tempArray count] < 2*12)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"Prox Params Value Data Count %d < 24,setUnitValue error",[tempArray count]]] ;
                [FullarrayEachStageValue release];
                [FullStageValue release];
                return ;
            }
			// the loop below is used to calculate isum
			for (int loop=2;loop<12;loop++)
			{
				
				HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
				if (HexString1.length>4)
				{
					HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
				}
				
				
				highByte=[HexString1 substringToIndex:2];
				lowByte=[HexString1 substringFromIndex:2];
				
				iSum+=strtol([highByte UTF8String],NULL,16);
				iSum+=strtol([lowByte UTF8String],NULL,16);
				
				
				HexString2=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop+1)] intValue]];
				if (HexString2.length>4)
				{
					HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
				}
				
				highByte=[HexString2 substringToIndex:2];
				lowByte=[HexString2 substringFromIndex:2];
				
				iSum+=strtol([highByte UTF8String],NULL,16);
				iSum+=strtol([lowByte UTF8String],NULL,16);
			}
			iCheckSum=(~iSum)+1;
			
			
			//the loop below is used to generate Prox Params Value
			for (int loop=0;loop<12;loop++)
			{
				if (loop!=1)
				{
					HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
					if (HexString1.length>4)
					{
						HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
					}
					HexString2=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop+1)] intValue]];
					if (HexString2.length>4)
					{
						HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
					}
				}
				
				else
				{
					
					HexString1=[NSString stringWithFormat:@"%04x",[[tempArray objectAtIndex:(2*loop)] intValue]];
					if (HexString1.length>4)
					{
						HexString1=[HexString1 substringFromIndex:([HexString1 length]-4)];
					}
					HexString2=[NSString stringWithFormat:@"%04x",iCheckSum];
					if (HexString2.length>4)
					{
						HexString2=[HexString2 substringFromIndex:([HexString2 length]-4)];
					}
				}
				
				Struct=[Struct stringByAppendingString:HexString2];
				Struct=[Struct stringByAppendingString:HexString1];
				if (loop!=11)
				{
					FinalProxParams=[FinalProxParams stringByAppendingString:Struct];
					FinalProxParams=[FinalProxParams stringByAppendingString:@" "];
				}
				else
					FinalProxParams=[FinalProxParams stringByAppendingString:Struct];
				//after one loop reset Struct to 0x;
				Struct=@"0x";
			}
			//SCRID:21
			//added end by caijunbo on 2010-11-18
			
			[TestItemManage setUnitValue:dictKeyDefined :@"Prox Params Value":FinalProxParams];
		}
		// end
	}
	
	// set pudding data		[NSString stringWithFormat:@"%d",itemp]
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox":nil:nil:nil:[NSString stringWithFormat:@"%d",ProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Centerpoint":nil:nil:nil:[NSString stringWithFormat:@"%d",CenterpointAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",proxTemperatureC]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_Prox":nil:nil:nil:[NSString stringWithFormat:@"%.2f",AdjProxAvg]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_SD":nil:nil:mAdj_SD_Upperlimit:[NSString stringWithFormat:@"%d",AdjSD]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Adj_Temp":nil:nil:nil:[NSString stringWithFormat:@"%d",AdjTemp]:nil:IP_NA:nil];
	
    //Add for EVT upload ALPHA value to PDCA by Henry 2012-04-26
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"ALPHA":nil:nil:nil:mTempAlpha:nil:IP_NA:nil];
    //add by Henry end
    
	/*SCRID:64  Owner:Serin Date: 2011-01-20  Description:Modify Spec of Prox Cal and change upload PDCA format*/
	// serin 20110119
	//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox_FinalAdj":nil:nil:nil:[NSString stringWithFormat:@"%d",Prox_FinalAdj]:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Prox_FinalAdj":nil:nil:nil:[NSString stringWithFormat:@"%d",Prox_FinalAdj]:nil:IP_NA:nil];
	// end
	
	[TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"Delta":nil:mDelta_Lowlimit:mDelta_Upperlimit:[NSString stringWithFormat:@"%d",Delta]:nil:IP_NA:nil];
	
	//Date:2011-01-21  Owner:Helen  Description:show limits on UI when Prox Cal test fail.
	//SCRID:91 Description:Show fail value on UI for Prox cal station by Helen 2011-03-21.
    if(((mDelta_Lowlimit==nil||[mDelta_Lowlimit length]<=0)?0:(Delta < [mDelta_Lowlimit integerValue]))
       || ((mDelta_Upperlimit==nil||[mDelta_Upperlimit length]<=0)?0:(Delta > [mDelta_Upperlimit integerValue])))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [NSString stringWithFormat: @"Delta Value:%d [ %@ , %@ ];",Delta,mDelta_Lowlimit,mDelta_Upperlimit];
	}
	
    else if(((mCenterpoint_Variation==nil||[mCenterpoint_Variation length]<=0)?0:(CenterpointAvg < (mBaselineCenterpoint-[mCenterpoint_Variation integerValue])) || (CenterpointAvg > (mBaselineCenterpoint+[mCenterpoint_Variation integerValue]))))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Centerpoint Value:%d [ %d , %d ];",CenterpointAvg,(mBaselineCenterpoint-[mCenterpoint_Variation integerValue]),(mBaselineCenterpoint+[mCenterpoint_Variation integerValue])]];
	}
    else if(((mTemp_Variation==nil||[mTemp_Variation length]<=0)?0:(proxTemperatureC < (mBaselineTemp-[mTemp_Variation integerValue])) || (proxTemperatureC > (mBaselineTemp+[mTemp_Variation integerValue]))))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"Temp Value:%d [ %d , %d ];",proxTemperatureC,(mBaselineTemp-[mTemp_Variation integerValue]),(mBaselineTemp+[mTemp_Variation integerValue])]];
	}
    else if((mAdj_SD_Upperlimit==nil||[mAdj_SD_Upperlimit length]<=0)?0:(AdjSD > [mAdj_SD_Upperlimit integerValue]))
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:[NSString stringWithFormat: @"SD Value:%d [ >= %@ ];",AdjSD,mAdj_SD_Upperlimit]];
	}
	//SCRID:91 end.
	//end
	else
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"PASS";
	}
	
	
	// modified by caijunbo on 2011-10-10
	/*
	 ProxParaDelta = Delta;
	 ProxParaSD = AdjSD;
	 */
	
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximityDeltaValue":[NSString stringWithFormat:@"%d",Delta]];
	[TestItemManage setBufferValue:dictKeyDefined :@"BufferForPositionProximitySDValue":[NSString stringWithFormat:@"%d",AdjSD]];
	// end
	
	//SCRID:21
	//added by caijunbo on 2010-11-18
	
	//SCRID:100 Add a key value in  parser "ProximityFunction" to update prox testitem name flexible by Helen 20110503
	//SCRID:21
	//added by caijunbo on 2010-11-18
	//rangeTestItemName = [mTestItemName rangeOfString:@"Angle:90 degree	Distance: 8(mm)"];
	if(mProxNameSpec != nil)
	{
		rangeTestItemName = [mTestItemName rangeOfString:mProxNameSpec];
		//SCRID:100 end.
		if(rangeTestItemName.length > 0)
		{
			NSString* TotalValue=[NSString stringWithFormat:@"\nTotal value is: 0x%04x",iSum];
			NSString* complimentValue=[NSString stringWithFormat:@"\n2's compliment value is: 0x%04x\n",iCheckSum];
			strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:TotalValue] ;
			strTestResultForUIinfo=[strTestResultForUIinfo stringByAppendingString:complimentValue] ;
		}
		//SCRID:21
		//added end by caijunbo on 2010-11-18
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return;
}

// serin 20110120
+(void)ParseProxParam:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo = @"";
	enum TestResutStatus enumResult ;
	strTestResultForUIinfo = @"";
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mBufferName=nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferName"])
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
	}
	
	// ============ For Baseline
	if([mTestItemName rangeOfString:@"Base Prox Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseProx];
		 */
        //        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue"]];
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue"];
	}
    else if([mTestItemName rangeOfString:@"Base Prox_SD Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseProx];
		 */
        //        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProximityAverageValue"]];
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProximitySDValue"];
	}
	else if([mTestItemName rangeOfString:@"Base Centerpoint Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseCenterpoint];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineCenterpointAverageValue"];
	}
	else if([mTestItemName rangeOfString:@"Base Temp Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseTemp];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineTemperatureAverageValue"];
	}
	else if([mTestItemName rangeOfString:@"Base AdjProx Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseAdjProx];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineAdjustProximityAverageValue"];
	}
	else if([mTestItemName rangeOfString:@"Base AdjSD Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseAdjSD];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProximitySDValue"];
	}
	else if([mTestItemName rangeOfString:@"Base ProxStd Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*FreeBaseLineProxSDValue
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaBaseAdjProx];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"FreeBaseLineProxSDValue"];
	}
	// ============ For [0 degree, 10mm] and [90 degree, 8mm]
	else if([mTestItemName rangeOfString:@"Delta Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaDelta];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"BufferForPositionProximityDeltaValue"];
		
	}
	else if([mTestItemName rangeOfString:@"SD Value"].length>0)
	{
		enumResult =RESULT_FOR_PASS ;
		//modified by caijunbo on 2011-10-10
		/*
		 strTestResultForUIinfo = [NSString stringWithFormat:@"%d",ProxParaDelta];
		 */
		strTestResultForUIinfo=[TestItemManage getBufferValue:dictKeyDefined :@"BufferForPositionProximitySDValue"];
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return;
}
// end


//blake add to try new sensor --20130816 --start
+(void)ParseProxSusParam_NewSensor:(NSDictionary*)dictKeyDefined
{
    //    NSString *strTestResultForUIinfo = @""; //20100727
	enum TestResutStatus enumResult ;
	
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferName1 = nil;
    NSString *mBufferNameAvg = nil;
    NSString *mBufferNameMin = nil;
    NSString *mBufferNameMax = nil;
    NSString *mBufferNameSwing = nil;
    NSString *mBufferNameDelta = nil;
    NSString *mBufferNameDev = nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameAvg"])
			mBufferNameAvg = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMin"])
			mBufferNameMin = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameMax"])
			mBufferNameMax = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameSwing"])
			mBufferNameSwing = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDelta"])
			mBufferNameDelta = [dictKeyDefined objectForKey:strKey] ;
        
        else if ([strKey isEqualToString:@"BufferNameDev"])
			mBufferNameDev = [dictKeyDefined objectForKey:strKey] ;
    }
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    //    mReferenceBufferValue = @"\n 2013.8.13.14.43  : 1 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 2 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 3 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 4 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 5 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 6 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 7 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 8 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 9 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 10 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 11 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 12 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 13 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 14 : 3 : 334 : 250 : 88 : 0\n 2013.8.13.14.43  : 15 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 16 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 17 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 18 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 19 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 20 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 21 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 22 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 23 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 24 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 25 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 26 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 27 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 28 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 29 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 30 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 31 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 32 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 33 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 34 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 35 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 36 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 37 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 38 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 39 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 40 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 41 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 42 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 43 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 44 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 45 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 46 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 47 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 48 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 49 : 3 : 333 : 250 : 88 : 0\n 2013.8.13.14.43  : 50 : 3 : 333 : 250 : 88 : 0\n [13 14:43:54] N001 Sequence done  \n";
    //    mReferenceBufferValue = @"2013.8.26.20.54.30  		  : 1 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.30  		  : 2 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.30  		  : 3 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.30  		  : 4 : 2 : 166 : 166 : 0 : 361  2013.8.26.20.54.30  		  : 5 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.30  		  : 6 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.31  		  : 7 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.31  		  : 8 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.31  		  : 9 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.31  		  : 10 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.31  		  : 11 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.31  		  : 12 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.32  		  : 13 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.32  		  : 14 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.32  		  : 15 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.32  		  : 16 : 2 : 167 : 169 : 0 : 361  2013.8.26.20.54.32  		  : 17 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.32  		  : 18 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.33  		  : 19 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.33  		  : 20 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.33  		  : 21 : 2 : 170 : 170 : 0 : 361  2013.8.26.20.54.33  		  : 22 : 2 : 169 : 169 : 0 : 361  2013.8.26.20.54.33  		  : 23 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.33  		  : 24 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.34  		  : 25 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.34  		  : 26 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.34  		  : 27 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.34  		  : 28 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.34  		  : 29 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.34  		  : 30 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.34  		  : 31 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.35  		  : 32 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.35  		  : 33 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.35  		  : 34 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.35  		  : 35 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.35  		  : 36 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.35  		  : 37 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.36  		  : 38 : 2 : 166 : 166 : 0 : 361  2013.8.26.20.54.36  		  : 39 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.36  		  : 40 : 2 : 167 : 168 : 0 : 361  2013.8.26.20.54.36  		  : 41 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.36  		  : 42 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.36  		  : 43 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.37  		  : 44 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.37  		  : 45 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.37  		  : 46 : 2 : 167 : 167 : 0 : 361  2013.8.26.20.54.37  		  : 47 : 2 : 168 : 168 : 0 : 361  2013.8.26.20.54.37  		  : 48 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.37  		  : 49 : 2 : 168 : 167 : 0 : 361  2013.8.26.20.54.38  		  : 50 : 2 : 167 : 167 : 0 : 361";
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@"\n" leftTrim:TRUE rightTrim:TRUE ];
    mReferenceBufferValue = [ToolFun allTrimFromString:mReferenceBufferValue trimStr:@" " leftTrim:TRUE rightTrim:TRUE ];
    
    NSString *mReferenceBufferValue1 ;
    mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
    
    NSString *abstime = [mReferenceBufferValue substringToIndex:15];
    if (abstime==nil) {
        enumResult = RESULT_FOR_FAIL;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :@"diag return error!" ];
        return;
    }
    NSMutableArray *ProxStageValue = [[NSMutableArray alloc] init];
    NSArray *bufferArray = [mReferenceBufferValue componentsSeparatedByString:abstime];
    int BaseProxValue = 0;
    for (int i = 1; i < [bufferArray count] ; i++)
    {
        NSArray *arrayTmp= [[bufferArray objectAtIndex:i] componentsSeparatedByString:@" : "];
        if ([arrayTmp count] < 7) {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diag return different format error!"];
            [ProxStageValue removeAllObjects];
            [ProxStageValue release];
            return;
        }
        [ProxStageValue addObject:[arrayTmp objectAtIndex:3]];
        BaseProxValue = BaseProxValue + [[arrayTmp objectAtIndex:3] integerValue];
    }
    NSString *preProxAvg=mReferenceBufferValue1;
    //    NSArray *arrProxStageValue = [ProxStageValue sortedArrayUsingFunction:intSort context:NULL];
    double proxMin=0;
    double proxMax=0;
    NSInteger BaseCount = [ProxStageValue count];
    if ([[ProxStageValue objectAtIndex:0] doubleValue]>[[ProxStageValue objectAtIndex:1] doubleValue])
    {
        proxMax=[[ProxStageValue objectAtIndex:0] doubleValue];
        proxMin=[[ProxStageValue objectAtIndex:1] doubleValue];
    }
    else
    {
        proxMax=[[ProxStageValue objectAtIndex:1] doubleValue];
        proxMin=[[ProxStageValue objectAtIndex:0] doubleValue];
    }
    for (int i=2; i<[ProxStageValue count]; i++)
    {
        NSLog(@"%f",[[ProxStageValue objectAtIndex:i] doubleValue]);
        if ([[ProxStageValue objectAtIndex:i] doubleValue]>proxMax)
        {
            proxMax=[[ProxStageValue objectAtIndex:i] doubleValue];
            
        }
        if ([[ProxStageValue objectAtIndex:i] doubleValue]<proxMin)
        {
            proxMin=[[ProxStageValue objectAtIndex:i] doubleValue];
            
        }
    }
    
    double proxAvg =(double) BaseProxValue / BaseCount;
    double proxSwing = proxMax-proxMin;
    NSLog(@"%f",proxSwing);
    //    int proxStdDev = (pow(4.0,0.5));
    double proxDelta = proxAvg - [preProxAvg doubleValue];
    NSLog(@"%f",proxDelta);
    double sqrtSum=0;
    
	for(int j=0; j<[ProxStageValue count]; j++)
	{
		double tmpVal = [[ProxStageValue objectAtIndex:j] doubleValue] - proxAvg;
        
        //        NSLog(@"[ProxStageValue objectAtIndex:j] = %@",[ProxStageValue objectAtIndex:j]);
        
		sqrtSum = sqrtSum + (tmpVal*tmpVal);
	}
    
    //	double tmpAvg=(sqrtSum/([ProxStageValue count] - 1));
    double tmpAvg= sqrtSum / [ProxStageValue count];
    
	//int iproxStdDev = (pow(4.0,0.5));
    //    sleep(5);
    
    double proxStdDevDon = (powf(tmpAvg,0.5));
    //    int proxStdDev = [self CalculateStageStdDev:ProxStageValue :proxAvg :BaseCount-1];
    //int proxStdDev = [self CalculateStageStdDev:ProxStageValue :proxAvg :BaseCount-1];
    NSLog(@"1111111111111 %@",[NSString stringWithFormat:@"%lf",proxAvg]);
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameAvg :[NSString stringWithFormat:@"%lf",proxAvg]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMin :[NSString stringWithFormat:@"%lf",proxMin]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameMax :[NSString stringWithFormat:@"%lf",proxMax]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameSwing :[NSString stringWithFormat:@"%lf",proxSwing]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDelta :[NSString stringWithFormat:@"%lf",proxDelta]];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDev :[NSString stringWithFormat:@"%.3lf",proxStdDevDon]];
    //    NSString *jjjjjj = [NSString stringWithFormat:@"%.3lf",proxStdDevDon];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
    return ;
}
//blake add to try new sensor --20130816 --end



//float intSort(id num1, id num2, void *context)
//{
//    float v1 = [num1 floatValue];
//    float v2 = [num2 floatValue];
//    if (v1 < v2)
//        return NSOrderedAscending;
//    else if (v1 > v2)
//        return NSOrderedDescending;
//    else
//        return NSOrderedSame;
//}

@end
