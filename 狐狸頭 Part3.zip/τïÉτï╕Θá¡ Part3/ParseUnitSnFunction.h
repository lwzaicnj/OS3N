/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseUnitSnFunction.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 2011-01-20              $Modtime:: 2011-02-15		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseUnitSnFunction.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 2011-01-20   Time: 15:58
 * Created in 
 * first implementation
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseUnitSnFunction)
+(void)ParseUnitSn:(NSDictionary*) DictionaryPtr;
+(void)ParseShowUnitSN:(NSDictionary*)dictKeyDefined ;

@end