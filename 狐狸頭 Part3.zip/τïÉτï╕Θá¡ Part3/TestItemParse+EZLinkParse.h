//
//  TestItemParse+EZLinkParse.h
//  iFTS
//
//  Created by Annie Zhang on 6/20/14.
//
//
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include <fstream>
#include <iostream>
//------------------------------------------------

#ifndef _SERIAL_H
#define _SERIAL_H

#include <stdint.h>



typedef struct {
    int Fd;
} SerialContext_t;


int Serial_Open (
                 char            *Port,
                 int             *Fd,
                 int             BaudRate
                 );


int Serial_ReadBytes (
                      void        *Context,
                      void        *Buf,
                      uint32_t    NumBytes,
                      int32_t     TimeOutInMs
                      );

int Serial_WriteBytes (
                       void        *Context,
                       void        *Buf,
                       uint32_t    NumBytes
                       );
static ssize_t _Serial_Read (
                             int filedes,
                             void *buf,
                             size_t nbytes,
                             unsigned int timeout_ms
                             );

static
void
PrintBytes (
            void        *Buf,
            uint32_t    NumBytes
            );

#endif
//-------------------------------------------------------------
using namespace std;

#define RETURN_ON_ERROR(Status)             \
{                                      \
int _UNIQUE_VAR = (Status);        \
if (_UNIQUE_VAR < 0)        \
{                                  \
return _UNIQUE_VAR;            \
}                                  \
}

#define DIAGS_CMD_TIMEOUT_MS 1000
//---------------------------------------------

#import "testItemParse.h"

@interface TestItemParse (EZLinkParse)

+(void)EZLinkParseFunction:(NSDictionary*)dictKeyDefined;
//Upload attribute “tristar_esn” to Bobcat and PDCA, Added by Annie for RL PVT
+(void)TristarESN:(NSDictionary*)dictKeyDefined;
//in order to Judge incoming QT0 unit location, eg LH,CD,BZ. 2015.1.19
+(void)RefurbishProvisionIP:(NSDictionary*)dictKeyDefined;

-(void)writeEZLinkLog:(NSString*)logPath :(NSString*)logContent;

@end
