//
//  testExecution.m
//  DisplayPort
//
//  Created by Wei on 8/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "testExecution.h"
//added by caijunbo on 2010-11-29

@implementation IFTTestExecution
@synthesize suite;
@synthesize runCount;

-(id)initWithSuite:(IFTestSuite*)p_suite {
	[super init];
	
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[p_suite retain];
	suite = p_suite;
	runCount = 1;
	testFlow = [suite flowForName:@"default"];
	int mCount = [testFlow count];
	mutDicDPResult=[ [NSMutableDictionary alloc] init];
	NSLog(@"testflow for site %@ has %d tests", suite.siteName,mCount);
	testResult=NO;
	//SCRID:45
	//added by caijunbo on 2010-12-18
	HDCPFlag=@"enable";//dsx 03-15 polo all soc type will run hdcp compliance test
	//end
	[pool release];
	return self;
}

-(BOOL)getTestResult
{
	return testResult;
}

 /*SCRID:28
 //added by caijunbo on 2010-11-29
 //Description:Change DisplayPort Test that support freely to add and remove items in Testconfig.plist
 */
-(NSString*)getFirstItemName
{
	return firstItemName;
}

//end

-(NSMutableDictionary*) getSubItemResult
{
	return mutDicDPResult;
}

//SCRID:30
//added by caijunbo on 2010-12-10
-(void)setHDCPFlag:(NSString*)flag
{
	[flag retain];
	HDCPFlag=[NSString stringWithString:flag];
	[flag release];
}

-(NSString*)getHDCPFlag
{
	return HDCPFlag;
}
//end added


-(void)dealloc
{
	[mutDicDPResult release];
    [suite release];
    [super dealloc];
}

-(void)main {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	NSError* error;
	
	NSString* siteName = suite.siteName;
	int count = [testFlow count];
	
	
	for (int index=0; index<runCount; index++) {
		bool didFail = NO;
		NSDictionary* puddingAttributes = [suite onDUTStart:nil returnedError:&e];
		if( !puddingAttributes )
		{
			NSAlert *theAlert = [NSAlert alertWithError:e];
			[theAlert runModal];
			[suite onDUTFinished:&error];  //note that however you exit the thread, you must pair onDUTFinished with onDUTStart
			return;
		}
		else {
			NSLog(@"pudding attribute is:\n%@", puddingAttributes);
		}
		
		NSLog(@"\n\n=============site %@, runIndex:%d=================", siteName, index);
		for(int i=0; i<count; i++){
			if( [self isCancelled] ){ 
				NSLog(@"test cancelled!!!!");
				[suite onDUTFinished:&error]; //note that however you exit the thread, you must pair onDUTFinished with onDUTStart
				return;
			}
			//BOOL continueFlow = YES;//add by Judith 20111205
			 BOOL passed = YES;
			IFTestMethod* test = [testFlow objectAtIndex:i];
			
			//SCRID:30
			//added by caijunbo on 2010-12-10
			NSRange range;
			range=[[test displayName] rangeOfString:@"HDCP Compliant test"];
			if (range.length>0)
			{
				//SCRID:45
				//Modified by caijunbo on 2010-12-18
				/*
				if (![[self getHDCPFlag] isEqualToString:@"C0"]) //modify by shou-xiu
				*/
				if ([[self getHDCPFlag] isEqualToString:@"disable"])
				//end
				{
					NSLog(@"skip HDCP Test!");
					continue;
				}
			}
			
			//end
			
			
			NSLog(@"running sub test %@", [test displayName]);
			if( ![test willRun:i+1 error:&e] )
			{
				NSAlert *theAlert = [NSAlert alertWithError:e];
				[theAlert runModal];
				NSLog(@"site %@ failed at run index %d", siteName, index);
				break;
			}
			passed = [test run:i+1 error:&e];
			if( !passed ){
				NSLog(@"DP DP DP, item %d test fail",i);
				/*SCRID-148:add a retest without any prompt for removing the DAVDP firmware infection. Judith 2011-12-06*/
				if( [test allowRetest] )
				{
					passed = [test retest:i+1 error:&e];
					if(!passed)
				/*SCRID-148:end*/
					{
						NSRunAlertPanel(@"WARNNING", @"DP测试失败,请检查DP线的连接，再重测，\nDP test fail,please check the cable connection and retest it !!!", @"Retest", nil, nil) ;
						NSLog(@"DP DP DP, item %d test fail, will retest it",i);
						passed = [test retest:i+1 error:&e];
					}
				}
			}
			NSArray* results = [test didRun:i+1 error:&e];               
			if( !results )
			{
				NSLog(@"error running test %@", [test displayName]);
				NSAlert *theAlert = [NSAlert alertWithError:e];
				[theAlert runModal];
				[suite onDUTFail:&e];
				break;
			}
			
			//store test result to mutDicDPResult
			//SCRID:28
			//Modified by caijunbo on 2010-11-29
			/*
			switch(i)
			{
				case 0:
					[mutDicDPResult setObject:results forKey:@"Hot Plug Detect"];
					break;
				case 1:
					[mutDicDPResult setObject:results forKey:@"EDID read back"];
					break;
				case 2:
					[mutDicDPResult setObject:results forKey:@"HDCP Compliant"];
					break;
				case 3:
					[mutDicDPResult setObject:results forKey:@"640x480 Pattern Test"];
					break;
				case 4:
					[mutDicDPResult setObject:results forKey:@"1.62 training result"];
					break;
				case 5:
					[mutDicDPResult setObject:results forKey:@"1280x720 Pattern Test"];
					break;
				case 6:
					[mutDicDPResult setObject:results forKey:@"2.7 training result"];
					break;
				case 7:
					[mutDicDPResult setObject:results forKey:@"PRBS test"];
					break;
			}
			 */
			
			[mutDicDPResult setObject:results forKey:[test displayName]];
			
			if (0==i)
			{
				firstItemName=[test displayName];
			}
			//end Modified by caijunbo on 2010-11-29
			
			
			for(IFTestResult* r in results)
			{
				NSLog(@"%@", [r description]);
				if( r.lowLimit ) NSLog(@"low limit is %@", r.lowLimit);
				if( r.highLimit ) NSLog(@"high limit is %@", r.highLimit);
				if( [r result]==IFTResultFail ){
					didFail = YES;
				}
			}
			
			if( !passed ) {
				if( [test shouldStopOnFail] )
				{
					[suite onDUTFail:&e];
					break;
				}
			}
			
			//if( !continueFlow )
			//    break;
		}
		
		testResult=!didFail;
		if( didFail ) {
			NSLog(@"==========%@ test failed===================\n",siteName);
		} else {
			NSLog(@"===========%@ test passed==================\n",siteName);
		}
		[suite onDUTFinished:&error];
	}
	
	[pool release];
}
@end
