//
//  NVMIntegrityCheck.m
//  iFTS
//
//  Created by Ray Hsu on 2012/2/8.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "NVMIntegrityCheck.h"
#import "toolFun.h"


@implementation TestItemParse(NVMIntegrityCheckFun)

//Camera NVM Check for PL
+(void)FrontCameraNVMIntegrityCheck:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
	NSString *mBufferNameNVM = nil;
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameIntegrator = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameID = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameFlex = nil;
	NSString *mBufferNameLens = nil;
	NSString *mBufferNameSensorType = nil;
	NSString *mBufferNameIRFilter = nil;
	NSString *mBufferNameBuildType = nil;
	NSString *mBufferNameColCalRGA = nil;
	NSString *mBufferNameColCalBGA = nil;
	NSString *mBufferNameColCalRGD50 = nil;
	NSString *mBufferNameColCalBGD50 = nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameNVM"])
		{
			mBufferNameNVM = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIntegrator"])
		{
			mBufferNameIntegrator = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameID"])
		{
			mBufferNameID = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameSensorType"])
		{
			mBufferNameSensorType = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIRFilter"])
		{
			mBufferNameIRFilter = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameBuildType"])
		{
			mBufferNameBuildType = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalRGA"])
		{
			mBufferNameColCalRGA = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBGA"])
		{
			mBufferNameColCalBGA = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalRGD50"])
		{
			mBufferNameColCalRGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBGD50"])
		{
			mBufferNameColCalBGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	//NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x32 0x2 0x16 0xA8 0x1 0x0 0x4 0x86 \n0x8 : 0x33 0x4F 0x4C 0x70 0x0 0x0 0x0 0x0 \n0x10 : 0x0 0x0 0x0 0x31 0x11 0x4 0x11 0xEE \n0x18 :";
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message"];
		return;
	}
	
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x0 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x8 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x10 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	
	NSMutableArray *arrayNVM = (NSMutableArray*)[bufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 23)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message,hex number <= 23"];
		return;
	}
	
	NSString *zero = @"0000";
	NSString *binaryTmp = nil;
	
	/******************** NVM Version & Year ********************/
	NSString *binaryNVMAndYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:1]];
	if([binaryNVMAndYear length] < 5)
		binaryNVMAndYear = [zero stringByAppendingString:binaryNVMAndYear];
	
	NSString *binaryNVM = [binaryNVMAndYear substringToIndex:4];
	NSString *binaryYear = [binaryNVMAndYear substringFromIndex:4];
	
	NSLog(@"binaryNVM =%@", binaryNVM);
	NSLog(@"binaryYear =%@", binaryYear);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVM :binaryNVM];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :binaryYear];
	
	/******************** Integrator & Day ********************/
	NSString *binaryIntegratorAndDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:3]];
	if([binaryIntegratorAndDay length] < 5)
		binaryIntegratorAndDay = [zero stringByAppendingString:binaryIntegratorAndDay];
	
	NSString *binaryIntegrator = [binaryIntegratorAndDay substringToIndex:4];
	NSString *binaryDay = [binaryIntegratorAndDay substringFromIndex:4];
	
	NSLog(@"binaryIntegrator =%@", binaryIntegrator);
	NSLog(@"binaryDay =%@", binaryDay);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntegrator :binaryIntegrator];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :binaryDay];
	
	/******************** ID ********************/
	NSString *binaryID = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:6]];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:5]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:4]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	
	NSLog(@"binaryID =%@", binaryID);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameID :binaryID];
	
	/******************** Work Week ********************/
	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:2]];
	if([binaryWeek length] < 5)
		binaryWeek = [zero stringByAppendingString:binaryWeek];
	
	binaryWeek = [binaryWeek substringFromIndex:2];
	
	NSLog(@"binaryWeek =%@", binaryWeek);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
	
	/******************** Flex & Lens ********************/
	NSString *binaryFlexAndLens = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
	if([binaryFlexAndLens length] < 5)
		binaryFlexAndLens = [zero stringByAppendingString:binaryFlexAndLens];
	
	NSString *binaryFlex = [binaryFlexAndLens substringToIndex:4];
	NSString *binaryLens = [binaryFlexAndLens substringFromIndex:4];
	
	NSLog(@"binaryFlex =%@", binaryFlex);
	NSLog(@"binaryLens =%@", binaryLens);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :binaryFlex];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :binaryLens];
	
	/******************** Sensor Type & IR Cut Filter ********************/
	NSString *binarySensorTypeAndIRFilter = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
	if([binarySensorTypeAndIRFilter length] < 5)
		binarySensorTypeAndIRFilter = [zero stringByAppendingString:binarySensorTypeAndIRFilter];
	
	NSString *binarySensorType = [binarySensorTypeAndIRFilter substringToIndex:4];
	NSString *binaryIRFilter = [binarySensorTypeAndIRFilter substringFromIndex:4];
	
	NSLog(@"binarySensorType =%@", binarySensorType);
	NSLog(@"binaryIRFilter =%@", binaryIRFilter);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorType :binarySensorType];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRFilter :binaryIRFilter];
	
	/******************** Camera Build Type ********************/
	NSString *binaryBuildType = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:22]];
	if([binaryBuildType length] < 5)
		binaryBuildType = [zero stringByAppendingString:binaryBuildType];
	
	NSLog(@"binaryBuildType =%@", binaryBuildType);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameBuildType :binaryBuildType];
	
	/******************** Component lookup ********************/
	
	/******************** Col CAL 1 R/G 'A' ********************/
	/******************** Col CAL 1 B/G 'A' ********************/
	/******************** Col Cal 1 R/G 'D50' ********************/
	/******************** Col Cal 1 B/G 'D50' ********************/
	NSString *binaryColCalRGA = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:8]];
	NSString *binaryColCalBGA = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:9]];
	NSString *binaryColCalRGD50 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:10]];
	NSString *binaryColCalBGD50 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:11]];
	NSString *binaryColCal8bits = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:12]];
	
	binaryTmp = [binaryColCal8bits substringToIndex:2];
	binaryColCalRGA = [binaryColCalRGA stringByAppendingString:binaryTmp];
	
	binaryTmp = [binaryColCal8bits substringToIndex:4];
	binaryTmp = [binaryTmp substringFromIndex:2];
	binaryColCalBGA = [binaryColCalBGA stringByAppendingString:binaryTmp];
	
	binaryTmp = [binaryColCal8bits substringToIndex:6];
	binaryTmp = [binaryTmp substringFromIndex:4];
	binaryColCalRGD50 = [binaryColCalRGD50 stringByAppendingString:binaryTmp];
	
	binaryTmp = [binaryColCal8bits substringFromIndex:6];
	binaryColCalBGD50 = [binaryColCalBGD50 stringByAppendingString:binaryTmp];
	
	NSLog(@"binaryColCalRGA =%@", binaryColCalRGA);
	NSLog(@"binaryColCalBGA =%@", binaryColCalBGA);
	NSLog(@"binaryColCalRGD50 =%@", binaryColCalRGD50);
	NSLog(@"binaryColCalBGD50 =%@", binaryColCalBGD50);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGA :binaryColCalRGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGA :binaryColCalBGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGD50 :binaryColCalRGD50];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGD50 :binaryColCalBGD50];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
+(void)BackCameraNVMIntegrityCheck:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameID = nil;
	NSString *mBufferNameLens = nil;
	NSString *mBufferNameIntegrator = nil;
	NSString *mBufferNameActuator = nil;
	NSString *mBufferNameBLC = nil;
	NSString *mBufferNameWaiver = nil;
	NSString *mBufferNameIRFilter = nil;
	NSString *mBufferNameTrim = nil;
	NSString *mBufferNameLED = nil;
	NSString *mBufferNameDriver = nil;
	NSString *mBufferNameInfinityDown = nil;
	NSString *mBufferNameMacroUp = nil;
	NSString *mBufferNameColCalRG1 = nil;
	NSString *mBufferNameColCalBG1 = nil;
	NSString *mBufferNameColCalRG2 = nil;
	NSString *mBufferNameColCalBG2 = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameID"])
		{
			mBufferNameID = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIntegrator"])
		{
			mBufferNameIntegrator = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameActuator"])
		{
			mBufferNameActuator = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameBLC"])
		{
			mBufferNameBLC = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWaiver"])
		{
			mBufferNameWaiver = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIRFilter"])
		{
			mBufferNameIRFilter = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameTrim"])
		{
			mBufferNameTrim = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLED"])
		{
			mBufferNameLED = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDriver"])
		{
			mBufferNameDriver = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameInfinityDown"])
		{
			mBufferNameInfinityDown = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameMacroUp"])
		{
			mBufferNameMacroUp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalRG1"])
		{
			mBufferNameColCalRG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBG1"])
		{
			mBufferNameColCalBG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalRG2"])
		{
			mBufferNameColCalRG2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBG2"])
		{
			mBufferNameColCalBG2 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	//NSString *mReferenceBufferValue = @"NVM Data 256 bytes : \n0x0 : 0xE8 0x5F 0x90 0x40 0x30 0x23 0x83 0xFD \n0x8 : 0x4 0x0 0xED 0x31 0x9D 0x41 0x9E 0x3F \n0x10 : 0x3 0x41 0xCD 0x40 0x0 0x0 0x10 0x87 \n0x18 :";
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message"];
		return;
	}
	
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x0 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x8 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"0x10 :" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
	bufferValue = [bufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	
	NSMutableArray *arrayNVM = (NSMutableArray*)[bufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 23)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message,hex number <= 23"];
		return;
	}
	
	NSString *zero = @"0000";
	NSString *binaryTmp = nil;
	
	/******************** Year & Week & Day********************/
	NSString *binaryYearAndWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:6]];
	if([binaryYearAndWeek length] < 5)
		binaryYearAndWeek = [zero stringByAppendingString:binaryYearAndWeek];
	
	NSString *binaryWeekAndDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:7]];
	if([binaryWeekAndDay length] < 5)
		binaryWeekAndDay = [zero stringByAppendingString:binaryWeekAndDay];
	
	NSString *binaryYear = [[binaryYearAndWeek substringToIndex:7] substringFromIndex:3];
	NSString *binaryWeek = [binaryYearAndWeek substringFromIndex:7];
	binaryWeek = [binaryWeek stringByAppendingString:[binaryWeekAndDay substringToIndex:5]];
	NSString *binaryDay = [binaryWeekAndDay substringFromIndex:5];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :binaryYear];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :binaryDay];
	
	/******************** ID ********************/
	NSString *binaryID = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:10]];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:9]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:8]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameID :binaryID];
	
	/******************** Lens & Integrator & Actuator & BLC ********************/
	NSString *binaryLensIntActBLC = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:11]];
	if([binaryLensIntActBLC length] < 5)
		binaryLensIntActBLC = [zero stringByAppendingString:binaryLensIntActBLC];
	
	NSString *binaryLens = [[binaryLensIntActBLC substringToIndex:6] substringFromIndex:4];
	NSString *binaryIntegrator = [binaryLensIntActBLC substringFromIndex:6];
	NSString *binaryActuator = [[binaryLensIntActBLC substringToIndex:4] substringFromIndex:1];
	NSString *binaryBLC = [binaryLensIntActBLC substringToIndex:1];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :binaryLens];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntegrator :binaryIntegrator];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuator :binaryActuator];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameBLC :binaryBLC];
	
	/******************** Waiver & IRFilter & Trim & LED & Driver ********************/
	NSString *binaryWai_IR_Trim_LED_Driver = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:12]];
	if([binaryWai_IR_Trim_LED_Driver length] < 5)
		binaryWai_IR_Trim_LED_Driver = [zero stringByAppendingString:binaryWai_IR_Trim_LED_Driver];
	
	NSString *binaryWaiver = [binaryWai_IR_Trim_LED_Driver substringToIndex:1];
	NSString *binaryIRFilter = [[binaryWai_IR_Trim_LED_Driver substringToIndex:3] substringFromIndex:1];
	NSString *binaryTrim = [[binaryWai_IR_Trim_LED_Driver substringToIndex:4] substringFromIndex:3];
	NSString *binaryLED = [[binaryWai_IR_Trim_LED_Driver substringToIndex:6] substringFromIndex:4];
	NSString *binaryDriver = [binaryWai_IR_Trim_LED_Driver substringFromIndex:6];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWaiver :binaryWaiver];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRFilter :binaryIRFilter];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrim :binaryTrim];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLED :binaryLED];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDriver :binaryDriver];
	
	/******************** Infinity Down ********************/
	NSString *binaryInfinityDown = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:23]];
	if([binaryInfinityDown length] < 5)
		binaryInfinityDown = [zero stringByAppendingString:binaryInfinityDown];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameInfinityDown :binaryInfinityDown];
	
	/******************** Macro Up ********************/
	NSString *binaryMacroUp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:24]];
	if([binaryMacroUp length] < 5)
		binaryMacroUp = [zero stringByAppendingString:binaryMacroUp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameMacroUp :binaryMacroUp];
	
	/******************** Color Cal R/G1 ********************/
	NSString *binaryColCalRG1 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:14]];
	if([binaryColCalRG1 length] < 5)
		binaryColCalRG1 = [zero stringByAppendingString:binaryColCalRG1];
	
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:13]];
	if([binaryTmp length] < 5)
		binaryTmp = [zero stringByAppendingString:binaryTmp];
	
	binaryColCalRG1 = [binaryColCalRG1 stringByAppendingString:binaryTmp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRG1 :binaryColCalRG1];
	
	/******************** Color Cal B/G1 ********************/
	NSString *binaryColCalBG1 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:16]];
	if([binaryColCalBG1 length] < 5)
		binaryColCalBG1 = [zero stringByAppendingString:binaryColCalBG1];
	
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:15]];
	if([binaryTmp length] < 5)
		binaryTmp = [zero stringByAppendingString:binaryTmp];
	
	binaryColCalBG1 = [binaryColCalBG1 stringByAppendingString:binaryTmp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBG1 :binaryColCalBG1];
	
	/******************** Color Cal R/G2 ********************/
	NSString *binaryColCalRG2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:18]];
	if([binaryColCalRG2 length] < 5)
		binaryColCalRG2 = [zero stringByAppendingString:binaryColCalRG2];
	
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:17]];
	if([binaryTmp length] < 5)
		binaryTmp = [zero stringByAppendingString:binaryTmp];
	
	binaryColCalRG2 = [binaryColCalRG2 stringByAppendingString:binaryTmp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRG2 :binaryColCalRG2];
	
	/******************** Color Cal B/G2 ********************/
	NSString *binaryColCalBG2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
	if([binaryColCalBG2 length] < 5)
		binaryColCalBG2 = [zero stringByAppendingString:binaryColCalBG2];
	
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
	if([binaryTmp length] < 5)
		binaryTmp = [zero stringByAppendingString:binaryTmp];
	
	binaryColCalBG2 = [binaryColCalBG2 stringByAppendingString:binaryTmp];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBG2 :binaryColCalBG2];
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
//End

//Camera NVM Check for PS 2012-05-11
+(void)FrontCameraNVMIntegrityCheckForPS:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
	NSString *mBufferNameNVM = nil;
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameIntegrator = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameID = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameFlex = nil;
	NSString *mBufferNameLens = nil;
	NSString *mBufferNameSensorType = nil;
	NSString *mBufferNameIRFilter = nil;
	NSString *mBufferNameBuildType = nil;
    NSString *mBufferNameLookUp = nil;
	NSString *mBufferNameColCalRGA = nil;
	NSString *mBufferNameColCalBGA = nil;
	NSString *mBufferNameColCalRGD50 = nil;
	NSString *mBufferNameColCalBGD50 = nil;
	NSString *mBufferNameColorCalMode = nil;
    NSString *mBufferNameNVMCheckSum = nil;
    NSString *mBufferNameXcentreOffset = nil;
    NSString *mBufferNameYcentreOffset = nil;
    NSString *mBufferNameCShadingRevision = nil;
    NSString *mBufferNameCShadingPresent = nil;
    NSString *mBufferNameCShadingChecksum = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
        NSLog(@"dictkeydefined = %@",dictKeyDefined);
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameNVM"])
		{
			mBufferNameNVM = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIntegrator"])
		{
			mBufferNameIntegrator = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameID"])
		{
			mBufferNameID = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameSensorType"])
		{
			mBufferNameSensorType = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIRFilter"])
		{
			mBufferNameIRFilter = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameBuildType"])
		{
			mBufferNameBuildType = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLookUp"])
        {
            mBufferNameLookUp = [dictKeyDefined objectForKey:strKey] ;
        }
		else if ([strKey isEqualToString:@"BufferNameColCalRGA"])
		{
			mBufferNameColCalRGA = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBGA"])
		{
			mBufferNameColCalBGA = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalRGD50"])
		{
			mBufferNameColCalRGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameColCalBGD50"])
		{
			mBufferNameColCalBGD50 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameColorCalMode"])
		{
			mBufferNameColorCalMode = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameNVMCheckSum"])
		{
			mBufferNameNVMCheckSum = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameXcentreOffset"])
		{
			mBufferNameXcentreOffset = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameYcentreOffset"])
		{
			mBufferNameYcentreOffset = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameCShadingRevision"])
		{
			mBufferNameCShadingRevision = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameCShadingPresent"])
		{
			mBufferNameCShadingPresent = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferNameCShadingChecksum"])
		{
			mBufferNameCShadingChecksum = [dictKeyDefined objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	//NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x42 0x8 0x26 0xEA 0x1 0x0 0x4 0x7F \n0x8 : 0x2F 0x49 0x48 0x40 0x0 0x0 0x0 0x0 \n0x10 : 0x0 0x0 0x0 0x33 0x11 0x5 0x21 0xB8 \n0x18 : 0x4 0x9 0x23 0x5E 0x71 0x82 0x92 0x9E \n0x20 : 0xA6 0xA9 0xA7 0x9F 0x93 0x84 0x72 0x5E \n0x28 : 0x6D 0x82 0x97 0xA9 0xB8 0xC3 0xC7 0xC3 \n0x30 : 0xB9 0xAA 0x98 0x85 0x6F 0x7A 0x91 0xA8 \n0x38 : 0xBD 0xD0 0xDD 0xE3 0xDE 0xD0 0xBD 0xA8 \n0x40 : 0x93 0x7C 0x82 0x99 0xB3 0xCC 0xE1 0xEF \n0x48 : 0xF4 0xEF 0xE2 0xCC 0xB4 0x9C 0x84 0x86 \n0x50 : 0x9D 0xB7 0xD1 0xE8 0xF5 0xFA 0xF5 0xE9 \n0x58 : 0xD2 0xB9 0x9F 0x87 0x83 0x9A 0xB3 0xCD \n0x60 : 0xE2 0xF1 0xF4 0xF0 0xE4 0xCE 0xB5 0x9C \n0x68 : 0x84 0x7C 0x92 0xA8 0xBF 0xD2 0xE0 0xE5 \n0x70 : 0xE1 0xD5 0xC1 0xAB 0x94 0x7D 0x6E 0x84 \n0x78 : 0x98 0xAB 0xBB 0xC6 0xCA 0xC7 0xBD 0xAC \n0x80 : 0x9B 0x86 0x70 0x60 0x73 0x86 0x95 0xA2 \n0x88 : 0xAA 0xAE 0xAB 0xA4 0x97 0x87 0x75 0x62 \n0x90 : 0x55 0x68 0x79 0x89 0x95 0x9E 0xA1 0x9D \n0x98 : 0x96 0x89 0x7A 0x69 0x56 0x64 0x79 0x8E \n0xA0 : 0xA1 0xB2 0xBF 0xC2 0xBE 0xB2 0xA2 0x8F \n0xA8 : 0x7B 0x66 0x71 0x88 0x9F 0xB7 0xCC 0xDB \n0xB0 : 0xE0 0xDB 0xCC 0xB7 0xA0 0x89 0x72 0x78 \n0xB8 : 0x90 0xAC 0xC6 0xDE 0xEE 0xF4 0xEE 0xDF \n0xC0 : 0xC8 0xAC 0x91 0x79 0x7B 0x94 0xAF 0xCC \n0xC8 : 0xE5 0xF4 0xFA 0xF5 0xE6 0xCD 0xB0 0x95 \n0xD0 : 0x7C 0x79 0x91 0xAC 0xC6 0xDF 0xEF 0xF3 \n0xD8 : 0xED 0xE0 0xC7 0xAC 0x91 0x79 0x71 0x88 \n0xE0 : 0x9F 0xB8 0xCC 0xDC 0xE1 0xDC 0xCD 0xB8 \n0xE8 : 0xA1 0x88 0x72 0x64 0x7A 0x8E 0xA1 0xB2 \n0xF0 : 0xBD 0xC2 0xBE 0xB2 0xA2 0x8F 0x7B 0x66 \n0xF8 : 0x58 0x69 0x7C 0x8B 0x97 0xA0 0xA3 0xA1 \n0x100 : 0x98 0x8B 0x7C 0x6A 0x58 0x60 0x73 0x85 \n0x108 : 0x95 0xA1 0xAA 0xAD 0xAA 0xA2 0x97 0x87 \n0x110 : 0x73 0x60 0x6E 0x85 0x99 0xAB 0xBC 0xC6 \n0x118 : 0xCB 0xC7 0xBC 0xAD 0x9A 0x87 0x70 0x7B \n0x120 : 0x93 0xA9 0xBF 0xD3 0xDF 0xE5 0xE0 0xD4 \n0x128 : 0xC1 0xAA 0x94 0x7D 0x82 0x9C 0xB4 0xCD \n0x130 : 0xE2 0xF0 0xF4 0xF0 0xE4 0xCF 0xB6 0x9D \n0x138 : 0x84 0x84 0x9E 0xB8 0xD1 0xE7 0xF4 0xFA \n0x140 : 0xF5 0xE9 0xD4 0xBA 0xA0 0x87 0x82 0x9B \n0x148 : 0xB4 0xCC 0xE1 0xEF 0xF4 0xEF 0xE3 0xCF \n0x150 : 0xB6 0x9D 0x84 0x7A 0x92 0xA8 0xBE 0xD1 \n0x158 : 0xDE 0xE3 0xDF 0xD4 0xC1 0xAB 0x94 0x7D \n0x160 : 0x6D 0x84 0x98 0xAA 0xBA 0xC5 0xCA 0xC7 \n0x168 : 0xBC 0xAD 0x9A 0x87 0x70 0x63 0x76 0x8A \n0x170 : 0x99 0xA7 0xAE 0xB2 0xAF 0xA8 0x9C 0x8B \n0x178 : 0x77 0x64 0x5E 0x70 0x83 0x93 0x9F 0xA7 \n0x180 : 0xA9 0xA7 0xA0 0x94 0x84 0x73 0x5F 0x6E \n0x188 : 0x84 0x98 0xAA 0xBA 0xC4 0xC8 0xC4 0xBB \n0x190 : 0xAB 0x99 0x85 0x70 0x7C 0x93 0xA9 0xBE \n0x198 : 0xD2 0xDF 0xE4 0xE0 0xD3 0xBF 0xA9 0x93 \n0x1A0 : 0x7D 0x84 0x9C 0xB4 0xCD 0xE3 0xF1 0xF5 \n0x1A8 : 0xF1 0xE4 0xCE 0xB5 0x9C 0x85 0x86 0x9F \n0x1B0 : 0xB9 0xD2 0xE9 0xF6 0xFA 0xF6 0xE9 0xD3 \n0x1B8 : 0xBA 0xA0 0x88 0x84 0x9C 0xB4 0xCD 0xE3 \n0x1C0 : 0xF1 0xF5 0xF0 0xE3 0xCE 0xB6 0x9D 0x85 \n0x1C8 : 0x7C 0x94 0xA9 0xBF 0xD4 0xE0 0xE5 0xE1 \n0x1D0 : 0xD5 0xC1 0xAA 0x94 0x7D 0x6F 0x85 0x99 \n0x1D8 : 0xAB 0xBC 0xC6 0xCB 0xC6 0xBD 0xAD 0x9C \n0x1E0 : 0x86 0x71 0x61 0x73 0x86 0x96 0xA3 0xAC \n0x1E8 : 0xAF 0xAC 0xA4 0x98 0x88 0x75 0x62 0xE9 \n0x1F0 : 0x6E 0x68 0x85 0xA8 0x3A 0x0 0x0 0x0 \n0x1F8 : 0x0 0x0 0x3F 0x0 0x0 0x0 0x0 0x0 \n0x200 : ";
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message"];
		return;
	}
    NSLog(@"buffervalue = %@",bufferValue);
    //add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc]initWithString:bufferValue]autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529 ) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0) {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//end added
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 23)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message,hex number <= 23"];
		return;
	}
	
	NSString *zero = @"0000";
	NSString *binaryTmp = nil;
	
	/******************** NVM Version & Year ********************/
	NSString *binaryNVMAndYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:1]];
	if([binaryNVMAndYear length] < 5)
		binaryNVMAndYear = [zero stringByAppendingString:binaryNVMAndYear];
	
	NSString *binaryNVM = [binaryNVMAndYear substringToIndex:4];
	NSString *binaryYear = [binaryNVMAndYear substringFromIndex:4];
	
	//NSLog(@"binaryNVM =%@", binaryNVM);
	//NSLog(@"binaryYear =%@", binaryYear);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVM :binaryNVM];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :binaryYear];
	
	/******************** Integrator & Day ********************/
	NSString *binaryIntegratorAndDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:3]];
	if([binaryIntegratorAndDay length] < 5)
		binaryIntegratorAndDay = [zero stringByAppendingString:binaryIntegratorAndDay];
	
	NSString *binaryIntegrator = [binaryIntegratorAndDay substringToIndex:4];
	NSString *binaryDay = [binaryIntegratorAndDay substringFromIndex:4];
	
	//NSLog(@"binaryIntegrator =%@", binaryIntegrator);
	//NSLog(@"binaryDay =%@", binaryDay);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntegrator :binaryIntegrator];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :binaryDay];
	
	/******************** ID ********************/
	NSString *binaryID = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:6]];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:5]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:4]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	
	//NSLog(@"binaryID =%@", binaryID);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameID :binaryID];
	
	/******************** Work Week ********************/
	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:2]];
	if([binaryWeek length] < 5)
		binaryWeek = [zero stringByAppendingString:binaryWeek];
	
	binaryWeek = [binaryWeek substringFromIndex:2];
	
	//NSLog(@"binaryWeek =%@", binaryWeek);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
	
    //add by judith for P105 proto2 2012-04-18
    /******************** Color Cal Mode ********************/
    NSString *binaryCoLorCalMode = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:7]];
    binaryCoLorCalMode = [binaryCoLorCalMode substringFromIndex:4];
    binaryCoLorCalMode = [binaryCoLorCalMode substringToIndex:2];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorCalMode :binaryCoLorCalMode];
    
    /******************** NVMCheckSum  ********************/
    NSString *binaryNVMCheckSum = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:24]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVMCheckSum :binaryNVMCheckSum];
    
    /******************** Xcentre  Offset ********************/
    NSString *binaryXcentreOffset = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:25]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameXcentreOffset :binaryXcentreOffset];
    
    /******************** Ycentre  Offset ********************/
    NSString *binaryYcentreOffset = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:26]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameYcentreOffset :binaryYcentreOffset];
    
    /********************Color Shading Revision and Present ********************/
    NSString *binaryCShadingRP = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:27]];
    NSString *binaryCShadingPresent = [binaryCShadingRP substringFromIndex:6];
    NSString *binaryCShadingRevision = [binaryCShadingRP substringToIndex:4];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameCShadingPresent :binaryCShadingPresent];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameCShadingRevision :binaryCShadingRevision];
    
    /******************** Color Shading Checksum ********************/
    NSString *binaryCShadingChecksum = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:496]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameCShadingChecksum :binaryCShadingChecksum];
    //end added
	/******************** Flex & Lens ********************/
	NSString *binaryFlexAndLens = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
	if([binaryFlexAndLens length] < 5)
		binaryFlexAndLens = [zero stringByAppendingString:binaryFlexAndLens];
	
	NSString *binaryFlex = [binaryFlexAndLens substringToIndex:4];
	NSString *binaryLens = [binaryFlexAndLens substringFromIndex:4];
	
	//NSLog(@"binaryFlex =%@", binaryFlex);
	//NSLog(@"binaryLens =%@", binaryLens);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :binaryFlex];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :binaryLens];
	
	/******************** Sensor Type & IR Cut Filter ********************/
	NSString *binarySensorTypeAndIRFilter = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
	if([binarySensorTypeAndIRFilter length] < 5)
		binarySensorTypeAndIRFilter = [zero stringByAppendingString:binarySensorTypeAndIRFilter];
	
	NSString *binarySensorType = [binarySensorTypeAndIRFilter substringToIndex:4];
	NSString *binaryIRFilter = [binarySensorTypeAndIRFilter substringFromIndex:4];
	
	//NSLog(@"binarySensorType =%@", binarySensorType);
	//NSLog(@"binaryIRFilter =%@", binaryIRFilter);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorType :binarySensorType];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRFilter :binaryIRFilter];
	
	/******************** Camera Build Type ********************/
	NSString *binaryBuildType = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:22]];
	if([binaryBuildType length] < 5)
		binaryBuildType = [zero stringByAppendingString:binaryBuildType];
	
	//NSLog(@"binaryBuildType =%@", binaryBuildType);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameBuildType :binaryBuildType];
	
	/******************** Component lookup ********************/
	NSString *hexLookUp = [arrayNVM objectAtIndex:23];
    if([hexLookUp length] < 2)
        hexLookUp = [oneZero stringByAppendingString:hexLookUp];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameLookUp :hexLookUp];
    
	/******************** Col CAL 1 R/G 'A' ********************/
	/******************** Col CAL 1 B/G 'A' ********************/
	/******************** Col Cal 1 R/G 'D50' ********************/
	/******************** Col Cal 1 B/G 'D50' ********************/
	NSString *binaryColCalRGA = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:8]];
	NSString *binaryColCalBGA = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:9]];
	NSString *binaryColCalRGD50 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:10]];
	NSString *binaryColCalBGD50 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:11]];
	NSString *binaryColCal8bits1 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:12]];
    NSString *binaryColCal8bits2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:13]];
	
	binaryTmp = [binaryColCal8bits1 substringToIndex:4];
	binaryColCalRGA = [binaryColCalRGA stringByAppendingString:binaryTmp];
	
    binaryTmp = [binaryColCal8bits1 substringFromIndex:4];
	binaryColCalBGA = [binaryColCalBGA stringByAppendingString:binaryTmp];
	
	binaryTmp = [binaryColCal8bits2 substringToIndex:4];
	binaryColCalRGD50 = [binaryColCalRGD50 stringByAppendingString:binaryTmp];
	
	binaryTmp = [binaryColCal8bits2 substringFromIndex:4];
	binaryColCalBGD50 = [binaryColCalBGD50 stringByAppendingString:binaryTmp];
	
	//NSLog(@"binaryColCalRGA =%@", binaryColCalRGA);
	//NSLog(@"binaryColCalBGA =%@", binaryColCalBGA);
	//NSLog(@"binaryColCalRGD50 =%@", binaryColCalRGD50);
	//NSLog(@"binaryColCalBGD50 =%@", binaryColCalBGD50);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGA :binaryColCalRGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGA :binaryColCalBGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGD50 :binaryColCalRGD50];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGD50 :binaryColCalBGD50];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
+(void)BackCameraNVMIntegrityCheckForPS:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameID = nil;
	NSString *mBufferNameLens = nil;
	NSString *mBufferNameIntegrator = nil;
	NSString *mBufferNameRNVM = nil;
	NSString *mBufferNameCCR = nil;
	NSString *mBufferNameWaiver = nil;
	NSString *mBufferNameIRFilter = nil;
	NSString *mBufferNameTrim = nil;
	NSString *mBufferNameCLookUp = nil;
	NSString *mBufferNamePLookUp = nil;
	NSString *mBufferNameDExperi = nil;
	NSString *mBufferNameTestStation = nil;
	NSString *mBufferNameLSRG1 = nil;
	NSString *mBufferNameLSBG1 = nil;
	NSString *mBufferNameLSRG2 = nil;
    NSString *mBufferNameLSBG2 = nil;
    NSString *mBufferNameDAC2DN = nil;
    NSString *mBufferNameDAC10UP = nil;
    NSString *mBufferNameVCMA = nil;
    NSString *mBufferNameVCMD = nil;
    NSString *mBufferNameRNVMCheckSum = nil;
    NSString *mBufferNameBuildType = nil;
    NSString *mBufferNameSensorType = nil;
	NSString *mBufferNameFlex = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameID"])
		{
			mBufferNameID = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIntegrator"])
		{
			mBufferNameIntegrator = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameRNVM"])
		{
			mBufferNameRNVM = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameCCR"])
		{
			mBufferNameCCR = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWaiver"])
		{
			mBufferNameWaiver = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameIRFilter"])
		{
			mBufferNameIRFilter = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameTrim"])
		{
			mBufferNameTrim = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameCLookUp"])
		{
			mBufferNameCLookUp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNamePLookUp"])
		{
			mBufferNamePLookUp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDExperi"])
		{
			mBufferNameDExperi = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameTestStation"])
		{
			mBufferNameTestStation = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLSRG1"])
		{
			mBufferNameLSRG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLSBG1"])
		{
			mBufferNameLSBG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLSRG2"])
		{
			mBufferNameLSRG2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameLSBG2"])
		{
			mBufferNameLSBG2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDAC2DN"])
		{
			mBufferNameDAC2DN = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDAC10UP"])
		{
			mBufferNameDAC10UP = [dictKeyDefined objectForKey:strKey] ;
		}	
        else if ([strKey isEqualToString:@"BufferNameVCMA"])
		{
			mBufferNameVCMA = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameVCMD"])
		{
			mBufferNameVCMD = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRNVMCheckSum"])
		{
			mBufferNameRNVMCheckSum = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameBuildType"])
		{
			mBufferNameBuildType = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensorType"])
		{
			mBufferNameSensorType = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}

	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
	
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
//	NSString *mReferenceBufferValue = @"NVM Data 256 bytes : \n0x0 : 0x42 0x8 0x26 0x6 0xA 0x0 0x4 0x84 \n0x8 : 0x30 0x4A 0x49 0x56 0x0 0x0 0x0 0x0 \n0x10 : 0x0 0x0 0x0 0x33 0x11 0x5 0x21 0x75 \n0x18 : 0xF5 0xB 0x23 0x5F 0x72 0x84 0x92 0x9D \n0x20 : 0xA4 0xA7 0xA4 0x9C 0x90 0x81 0x6F 0x5C \n0x28 : 0x6E 0x84 0x97 0xA8 0xB7 0xBE 0xC4 0xC0 \n0x30 :";
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message"];
		return;
	}
	    
    //add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc]initWithString:bufferValue]autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529 ) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0) {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//end added

	
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 23)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"diags return difference message,hex number <= 23"];
		return;
	}
	
	NSString *zero = @"0000";
	NSString *binaryTmp = nil;
	/******************** NVM Version & Year ********************/
	NSString *binaryNVMAndYear = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:17]];
	if([binaryNVMAndYear length] < 5)
		binaryNVMAndYear = [zero stringByAppendingString:binaryNVMAndYear];
	
	NSString *binaryNVM = [binaryNVMAndYear substringToIndex:4];
	NSString *binaryYear = [binaryNVMAndYear substringFromIndex:4];
	
	//NSLog(@"binaryNVM =%@", binaryNVM);
	//NSLog(@"binaryYear =%@", binaryYear);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRNVM :binaryNVM];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :binaryYear];

    /******************** Integrator & Day ********************/
	NSString *binaryIntegratorAndDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:18]];
	if([binaryIntegratorAndDay length] < 5)
		binaryIntegratorAndDay = [zero stringByAppendingString:binaryIntegratorAndDay];
	
	NSString *binaryIntegrator = [binaryIntegratorAndDay substringToIndex:4];
	NSString *binaryDay = [binaryIntegratorAndDay substringFromIndex:4];
	
	//NSLog(@"binaryIntegrator =%@", binaryIntegrator);
	//NSLog(@"binaryDay =%@", binaryDay);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntegrator :binaryIntegrator];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :binaryDay];
	
    
    /******************** Work Week ********************/
	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
	if([binaryWeek length] < 5)
		binaryWeek = [zero stringByAppendingString:binaryWeek];
	
	binaryWeek = [binaryWeek substringFromIndex:2];
	
	//NSLog(@"binaryWeek =%@", binaryWeek);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
    
	/******************** ID ********************/
	NSString *binaryID = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:22]];
    if([binaryID length] < 5)
		binaryID = [zero stringByAppendingString:binaryID];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
    if([binaryTmp length] < 5)
		binaryTmp = [zero stringByAppendingString:binaryTmp];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	binaryTmp = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
	binaryID = [binaryID stringByAppendingString:binaryTmp];
	
	//NSLog(@"binaryID =%@", binaryID);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameID :binaryID];
    
   
    
    /******************** Color Cal Revision ********************/
    NSString *binaryCoLorCalRevision = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:23]];
    if([binaryCoLorCalRevision length] < 5)
		binaryCoLorCalRevision = [zero stringByAppendingString:binaryCoLorCalRevision];
    binaryCoLorCalRevision = [binaryCoLorCalRevision substringFromIndex:4];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCCR :binaryCoLorCalRevision];
    
    

    /******************** Flex & Lens ********************/
	NSString *binaryLensAndFlex = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:36]];
	if([binaryLensAndFlex length] < 5)
		binaryLensAndFlex = [zero stringByAppendingString:binaryLensAndFlex];
	
	NSString *binaryFlex = [binaryLensAndFlex substringToIndex:4];
	NSString *binaryLens = [binaryLensAndFlex substringFromIndex:4];
	
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :binaryLens];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :binaryFlex];
    
    
    /******************** Sensor Type & IR Filter ********************/
	NSString *binarySensorTypeAndIRFilter = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:37]];
	if([binarySensorTypeAndIRFilter length] < 5)
		binarySensorTypeAndIRFilter = [zero stringByAppendingString:binarySensorTypeAndIRFilter];
	
    
	NSString *binarySensorType = [binarySensorTypeAndIRFilter substringToIndex:4];
	NSString *binaryIRFilter = [binarySensorTypeAndIRFilter substringFromIndex:4];

    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorType :binarySensorType];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRFilter :binaryIRFilter];
    
    
    
    /******************** Trim & VCM Actuator ********************/
	NSString *binaryTrimAndVCMActuator = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:38]];
	if([binaryTrimAndVCMActuator length] < 5)
		binaryTrimAndVCMActuator = [zero stringByAppendingString:binaryTrimAndVCMActuator];
	
    
	NSString *binaryTrim = [binaryTrimAndVCMActuator substringToIndex:4];
	NSString *binaryVCMActuator = [binaryTrimAndVCMActuator substringFromIndex:4];
    
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrim :binaryTrim];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameVCMA :binaryVCMActuator];
    
    /******************** VCM Driver & Waiver ********************/
	NSString *binaryVCMDriverAndWaiver = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:39]];
	if([binaryVCMDriverAndWaiver length] < 5)
		binaryVCMDriverAndWaiver = [zero stringByAppendingString:binaryTrimAndVCMActuator];
	
    
	NSString *binaryVCMDriver = [binaryVCMDriverAndWaiver substringToIndex:4];
	NSString *binaryWaiver = [binaryVCMDriverAndWaiver substringFromIndex:4];
    
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameVCMD :binaryVCMDriver];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWaiver :binaryWaiver];
    /******************** Camera Build Type & Test Station ********************/
	NSString *binaryBuildAndStation = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:40]];
	if([binaryBuildAndStation length] < 5)
		binaryBuildAndStation = [zero stringByAppendingString:binaryBuildAndStation];
	
    
	NSString *binaryBuild = [binaryBuildAndStation substringToIndex:4];
	NSString *binaryStation = [binaryBuildAndStation substringFromIndex:4];
    
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameBuildType :binaryBuild];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTestStation :binaryStation];
    
    /******************** Check R/G & B/G Light Source 1 & 2 ********************/
    NSString *binaryLSRG1 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:24]];
    if([binaryLSRG1 length] < 5)
		binaryLSRG1 = [zero stringByAppendingString:binaryLSRG1];
    
    NSString *binaryLSBG1 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:25]];
    if([binaryLSBG1 length] < 5)
		binaryLSBG1 = [zero stringByAppendingString:binaryLSBG1];
    
    NSString *binaryLSRG2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:26]];
    if([binaryLSRG2 length] < 5)
		binaryLSRG2 = [zero stringByAppendingString:binaryLSRG2];
    
	
    NSString *binaryLSBG2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:27]];
    if([binaryLSBG2 length] < 5)
		binaryLSBG2 = [zero stringByAppendingString:binaryLSBG2];
     
    NSString *binaryPreLSA = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:28]];
    if([binaryPreLSA length] < 5)
		binaryPreLSA = [zero stringByAppendingString:binaryPreLSA];
    
    NSString *binaryPreLSD = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:29]];
    if([binaryPreLSD length] < 5)
		binaryPreLSD = [zero stringByAppendingString:binaryPreLSD];
    
    NSString *binaryPreLSRGA = [binaryPreLSA substringToIndex:4];
    NSString *binaryPreLSBGA = [binaryPreLSA substringFromIndex:4];
    NSString *binaryPreLSRGD = [binaryPreLSD substringToIndex:4];
    NSString *binaryPreLSBGD = [binaryPreLSD substringFromIndex:4];
    
    binaryLSRG1 = [binaryLSRG1 stringByAppendingString:binaryPreLSRGA];
    binaryLSBG1 = [binaryLSBG1 stringByAppendingString:binaryPreLSBGA];
    binaryLSRG2 = [binaryLSRG2 stringByAppendingString:binaryPreLSRGD];
    binaryLSBG2 = [binaryLSBG2 stringByAppendingString:binaryPreLSBGD];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLSRG1 :binaryLSRG1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameLSBG1 :binaryLSBG1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameLSRG2 :binaryLSRG2];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameLSBG2 :binaryLSBG2];
    
    /******************** Check Component Lookup & Process Lookup********************/
    NSString *binaryLookup = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:41]];
    if([binaryLookup length] < 5)
		binaryLookup = [zero stringByAppendingString:binaryLookup];
    NSString *binaryCLookup = [binaryLookup substringToIndex:4];
    NSString *binaryPLookup = [binaryLookup substringFromIndex:4];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCLookUp :binaryCLookup];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNamePLookUp :binaryPLookup];
    
    
    /******************** Check Design of Experiment ********************/
    NSString *binaryDOExperiment = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:42]];
    if([binaryDOExperiment length] < 5)
		binaryDOExperiment = [zero stringByAppendingString:binaryDOExperiment];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDExperi :binaryDOExperiment];
    
    /******************** Check DAC 2m DN&DAC 10cm UP ********************/
    NSString *binaryDAC = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:45]];
    if([binaryDAC length] < 5)
		binaryDAC = [zero stringByAppendingString:binaryDAC];
    NSString *binaryPreDAC2 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:43]];
    if([binaryPreDAC2 length] < 5)
		binaryPreDAC2 = [zero stringByAppendingString:binaryPreDAC2];
    NSString *binaryPreDAC10 = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:44]];
    if([binaryPreDAC10 length] < 5)
		binaryPreDAC10 = [zero stringByAppendingString:binaryPreDAC10];
    
    binaryDAC = [binaryDAC substringFromIndex:4];
    NSString *binaryDAC2 = [binaryDAC substringToIndex:2];
    binaryDAC2 = [binaryPreDAC2 stringByAppendingString:binaryDAC2];
    NSString *binaryDAC10 = [binaryDAC substringFromIndex:2];
    binaryDAC10 = [binaryPreDAC10 stringByAppendingString:binaryDAC10];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDAC2DN :binaryDAC2];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDAC10UP :binaryDAC10];
    
    /******************** Check NVM CheckSum ********************/
    NSString *binaryNVMChecksum = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:48]];
    if([binaryNVMChecksum length] < 5)
		binaryNVMChecksum = [zero stringByAppendingString:binaryNVMChecksum];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRNVMCheckSum :binaryNVMChecksum];
    

	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
//End

+(void)FrontCameraNVMIntegrityCheckForQL:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
    
	NSString *mBufferNameNVM = nil;
    NSString *mBufferNameProj_Id_Var = nil;//Project Identifier/Variation
    
    NSString *mBufferNameInt_Plant = nil;//Integrator/Plant
    NSString *mBufferNameLens = nil;
    NSString *mBufferNameLensVer = nil;
    NSString *mBufferNameIRCF = nil;
    NSString *mBufferNameIRCFVer = nil;
    NSString *mBufferNameSubstrate = nil;
    NSString *mBufferNameSubstrateVer = nil;
    NSString *mBufferNameSensor = nil;
    NSString *mBufferNameSensorVer = nil;
    NSString *mBufferNameFlex = nil;
    NSString *mBufferNameFlexVer = nil;
    NSString *mBufferNameStiffener = nil;
    NSString *mBufferNameStiffenerVer = nil;
    NSString *mBufferNameBuildType = nil;//Camera Build Type
    NSString *mBufferNameConfigNum = nil;//Config Nmuber
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameSeqNum = nil;//Sequence Number
	NSString *mBufferNameTSAR = nil;//Test Software Algorithm Rivision
	NSString *mBufferNameColCalBGA = nil;
	NSString *mBufferNameColCalRGA = nil;
	NSString *mBufferNameColCalBGD50 = nil;
	NSString *mBufferNameColCalRGD50 = nil;
    NSString *mBufferNameCarrier = nil;
    NSString *mBufferNameCarrierVer = nil;
    NSString *mBufferNameALS = nil;
    NSString *mBufferNameALSVer = nil;
    NSString *mBufferNameDoeLookUp = nil;
    
    NSString *mBufferNameGeneralInfoCS = nil;
    NSString *mBufferNameColorCal1ACS = nil;
    NSString *mBufferNameColorCal1D50CS = nil;
    NSString *mBufferNameColorCal2ACS = nil;
    NSString *mBufferNameColorCal2D50CS = nil;
    NSString *mBufferNameColorShadingCS = nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameNVM"])
		{
			mBufferNameNVM = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameProj_Id_Var"])
		{
			mBufferNameProj_Id_Var = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameInt_Plant"])
		{
			mBufferNameInt_Plant = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLensVer"])
		{
			mBufferNameLensVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIRCF"])
		{
			mBufferNameIRCF = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIRCFVer"])
		{
			mBufferNameIRCFVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSubstrate"])
		{
			mBufferNameSubstrate = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSubstrateVer"])
		{
			mBufferNameSubstrateVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensor"])
		{
			mBufferNameSensor = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensorVer"])
		{
			mBufferNameSensorVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlexVer"])
		{
			mBufferNameFlexVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameStiffener"])
		{
			mBufferNameStiffener = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameStiffenerVer"])
		{
			mBufferNameStiffenerVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameBuildType"])
		{
			mBufferNameBuildType = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameConfigNum"])
		{
			mBufferNameConfigNum = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSeqNum"])
		{
			mBufferNameSeqNum = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameTSAR"])
		{
			mBufferNameTSAR = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColCalBGA"])
		{
			mBufferNameColCalBGA = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColCalRGA"])
		{
			mBufferNameColCalRGA = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColCalBGD50"])
		{
			mBufferNameColCalBGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColCalRGD50"])
		{
			mBufferNameColCalRGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameCarrier"])
        {
            mBufferNameCarrier = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferNameCarrierVer"])
        {
            mBufferNameCarrierVer = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferNameALS"])
        {
            mBufferNameALS = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferNameALSVer"])
        {
            mBufferNameALSVer = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"BufferNameDoeLookUp"])
        {
            mBufferNameDoeLookUp = [dictKeyDefined objectForKey:strKey];
        }
        
        
        else if ([strKey isEqualToString:@"BufferNameGeneralInfoCS"])
		{
			mBufferNameGeneralInfoCS = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColorCal1ACS"])
		{
			mBufferNameColorCal1ACS = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColorCal1D50CS"])
		{
			mBufferNameColorCal1D50CS = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColorCal2ACS"])
		{
			mBufferNameColorCal2ACS = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColorCal2D50CS"])
		{
			mBufferNameColorCal2D50CS = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameColorShadingCS"])
		{
			mBufferNameColorShadingCS = [dictKeyDefined objectForKey:strKey] ;
		}
        //add by kevin on 20150508
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
    //NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x02 0x22 0x61 0x10 0x10 0x11 0x24 0x32 \n0x8 : 0xC1 0x25 0x50 0x32 0xC9 0x0 0x0 0x0 \n0x10 : 0x25 0x33 0x52 0x65 0x27 0xB 0x24 0x00 \n0x18 : 0x02 0x8 0x23 0x6C 0x82 0x96 0xA7 0xB4 \n0x20 : 0xBC 0x73 0x25 0x3E 0x43 0x98 0x78 0x66 \n0x28 :";
    
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
    
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
		return;
	}
    NSLog(@"buffervalue = %@",bufferValue);
    //add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc] initWithString:bufferValue] autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529 ) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0)
    {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//end added
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 40)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 40"];
		return;
	}
	
	/******************** NVM Version ********************/
	NSString *hexNVM = [arrayNVM objectAtIndex:1];
    
	//NSLog(@"hexNVM =%@", hexNVM);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVM :hexNVM];
	
    /******************** Project Identifier/Variation ********************/
	NSString *hexProj_Id_Var = [arrayNVM objectAtIndex:2];
    
	//NSLog(@"hexProj_Id_Var =%@", hexProj_Id_Var);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameProj_Id_Var :hexProj_Id_Var];
    
	/******************** Integrator/Plant ********************/
	NSString *hexInt_Plant = [arrayNVM objectAtIndex:3];
	
	//NSLog(@"hexInt_Plant =%@", hexInt_Plant);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameInt_Plant :hexInt_Plant];
	
    /******************** Lens & Version ********************/
	NSString *hexLensAndVer = [arrayNVM objectAtIndex:4];
	
	NSString *hexLens = [hexLensAndVer substringToIndex:1];
	NSString *hexLensVer = [hexLensAndVer substringFromIndex:1];
	
	//NSLog(@"hexLens =%@", hexLens);
	//NSLog(@"hexLensVer =%@", hexLensVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :hexLens];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLensVer :hexLensVer];
    
    /******************** IRCF & Version ********************/
	NSString *hexIRCFAndVer = [arrayNVM objectAtIndex:5];
	
	NSString *hexIRCF = [hexIRCFAndVer substringToIndex:1];
	NSString *hexIRCFVer = [hexIRCFAndVer substringFromIndex:1];
	
	//NSLog(@"hexIRCF =%@", hexIRCF);
	//NSLog(@"hexIRCFVer =%@", hexIRCFVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCF :hexIRCF];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCFVer :hexIRCFVer];
    
    /******************** Substrate & Version ********************/
	NSString *hexSubstrateAndVer = [arrayNVM objectAtIndex:6];
	
	NSString *hexSubstrate = [hexSubstrateAndVer substringToIndex:1];
	NSString *hexSubstrateVer = [hexSubstrateAndVer substringFromIndex:1];
	
	//NSLog(@"hexSubstrate =%@", hexSubstrate);
	//NSLog(@"hexSubstrateVer =%@", hexSubstrateVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrate :hexSubstrate];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrateVer :hexSubstrateVer];
    
    /******************** Sensor & Version ********************/
	NSString *hexSensorAndVer = [arrayNVM objectAtIndex:7];
	
	NSString *hexSensor = [hexSensorAndVer substringToIndex:1];
	NSString *hexSensorVer = [hexSensorAndVer substringFromIndex:1];
	
	//NSLog(@"hexSensor =%@", hexSensor);
	//NSLog(@"hexSensorVer =%@", hexSensorVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensor :hexSensor];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorVer :hexSensorVer];
    
    /******************** Flex & Version ********************/
	NSString *hexFlexAndVer = [arrayNVM objectAtIndex:8];
	
	NSString *hexFlex = [hexFlexAndVer substringToIndex:1];
	NSString *hexFlexVer = [hexFlexAndVer substringFromIndex:1];
	
	//NSLog(@"hexFlex =%@", hexFlex);
	//NSLog(@"hexFlexVer =%@", hexFlexVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :hexFlex];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlexVer :hexFlexVer];
    
    /******************** Stiffener & Version ********************/
	NSString *hexStiffenerAndVer = [arrayNVM objectAtIndex:9];
	
	NSString *hexStiffener = [hexStiffenerAndVer substringToIndex:1];
	NSString *hexStiffenerVer = [hexStiffenerAndVer substringFromIndex:1];
    
	//NSLog(@"hexStiffener =%@", hexStiffener);
	//NSLog(@"hexStiffenerVer =%@", hexStiffenerVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffener :hexStiffener];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffenerVer :hexStiffenerVer];
    
    
    /********************Carrier Vendor &Carrier Version**********/
    NSString *hexCarrierVendorAndVer = [arrayNVM objectAtIndex:10];
    NSString *hexCarrierVendor = [hexCarrierVendorAndVer substringToIndex:1];
    NSString *hexCarrierVer = [hexCarrierVendorAndVer substringFromIndex:1];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameCarrier :hexCarrierVendor];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameCarrierVer :hexCarrierVer];
    
    /************************ ALS & Version ******************/
    NSString *hexALSAndVer = [arrayNVM objectAtIndex:11];
    NSString *hexALS = [hexALSAndVer substringToIndex:1];
    NSString *hexALSVer = [hexALSAndVer substringFromIndex:1];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameALS :hexALS];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameALSVer :hexALSVer];
    
    
    /******************** Camera Build Type ********************/
	NSString *hexBuildType = [arrayNVM objectAtIndex:17];
	
	//NSLog(@"hexBuildType =%@", hexBuildType);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameBuildType :hexBuildType];
    
    /******************** Config Number ********************/
	NSString *hexConfigNum = [arrayNVM objectAtIndex:18];
	
	//NSLog(@"hexConfigNum =%@", hexConfigNum);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameConfigNum :hexConfigNum];
    
    /******************** Year ********************/
	NSString *hexYear = [arrayNVM objectAtIndex:19];
	
	hexYear = [hexYear substringFromIndex:1];
	
	//NSLog(@"hexYear =%@", hexYear);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :hexYear];
    
    /******************** Week ********************/
	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
	
	binaryWeek = [binaryWeek substringFromIndex:2];
	
	//NSLog(@"binaryWeek =%@", binaryWeek);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
    
    /******************** Day ********************/
	NSString *binaryDay = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
	
	binaryDay = [binaryDay substringFromIndex:5];
	
	//NSLog(@"binaryDay =%@", binaryDay);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :binaryDay];
    
    /******************** DoE Lookup ********************/
    NSString *hexDoeLookUp = [arrayNVM objectAtIndex:27];
    hexDoeLookUp = [hexDoeLookUp stringByAppendingString:[arrayNVM objectAtIndex:26]];
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDoeLookUp :hexDoeLookUp];
    
	/******************** Sequence Number ********************/
	NSString *hexSeqNum = [arrayNVM objectAtIndex:24];
    hexSeqNum = [hexSeqNum stringByAppendingString:[arrayNVM objectAtIndex:23]];
    hexSeqNum = [hexSeqNum stringByAppendingString:[arrayNVM objectAtIndex:22]];
	
	//NSLog(@"hexSeqNum =%@", hexSeqNum);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSeqNum :hexSeqNum];
	
	/******************** General Info CheckSum********************/
	NSString *generalInfoCS = [arrayNVM objectAtIndex:32];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameGeneralInfoCS :generalInfoCS];
    
    /******************** Color Cal 1 A CheckSum ********************/
	NSString *colorCal1 = [arrayNVM objectAtIndex:48];
    NSString *colorCal1ACS = [colorCal1 substringToIndex:1];
	
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorCal1ACS :colorCal1ACS];
    
    /******************** Color Cal 1 D50 CheckSum********************/
	//NSString *colorCal1D50CS = [arrayNVM objectAtIndex:32];
    NSString *colorCal1D50CS = [colorCal1 substringFromIndex:1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorCal1D50CS :colorCal1D50CS];
    
    /******************** Color Cal 2 A CheckSum********************/
	NSString *colorCal2 = [arrayNVM objectAtIndex:64];
    NSString *colorCal2ACS = [colorCal2 substringToIndex:1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorCal2ACS :colorCal2ACS];
    
    /******************** Color Cal 2 D50 CheckSum*********************/
	//NSString *colorCal2D50CS = [arrayNVM objectAtIndex:32];
    NSString *colorCal2D50CS = [colorCal2 substringFromIndex:1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorCal2D50CS :colorCal2D50CS];
    /******************** Color Shading CheckSum********************/
    
	NSString *colorShadingCS = [arrayNVM objectAtIndex:289];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameColorShadingCS :colorShadingCS];
    
    
    
    
    /******************** Test Software Algorithm Revision ********************/
	NSString *hexTSAR = [arrayNVM objectAtIndex:25];
    
    //NSLog(@"hexTSAR =%@", hexTSAR);
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameTSAR :hexTSAR];
    
    /******************** Col CAL 1 B/G 'A' ********************/
	/******************** Col CAL 1 R/G 'A' ********************/
	/******************** Col Cal 1 B/G 'D50' ********************/
	/******************** Col Cal 1 R/G 'D50' ********************/
	NSString *hexColCalRGA = [arrayNVM objectAtIndex:34];
    hexColCalRGA=[hexColCalRGA substringFromIndex:1];
	NSString *hexColCalBGA = [arrayNVM objectAtIndex:36];
    hexColCalBGA=[hexColCalBGA substringFromIndex:1];
	NSString *hexColCalRGD50 = [arrayNVM objectAtIndex:38];
    hexColCalRGD50=[hexColCalRGD50 substringFromIndex:1];
	NSString *hexColCalBGD50 = [arrayNVM objectAtIndex:40];
    hexColCalBGD50=[hexColCalBGD50 substringFromIndex:1];
	//NSString *hexColCal8bits1 = [arrayNVM objectAtIndex:38];
    //NSString *hexColCal8bits2 = [arrayNVM objectAtIndex:39];
    
	
	hexColCalRGA = [hexColCalRGA stringByAppendingString:[arrayNVM objectAtIndex:33]];
	hexColCalBGA = [hexColCalBGA stringByAppendingString:[arrayNVM objectAtIndex:35]];
	hexColCalRGD50 = [hexColCalRGD50 stringByAppendingString:[arrayNVM objectAtIndex:37]];
	hexColCalBGD50 = [hexColCalBGD50 stringByAppendingString:[arrayNVM objectAtIndex:39]];
	
	//NSLog(@"hexColCalRGA =%@", hexColCalRGA);
	//NSLog(@"hexColCalBGA =%@", hexColCalBGA);
	//NSLog(@"hexColCalRGD50 =%@", hexColCalRGD50);
	//NSLog(@"hexColCalBGD50 =%@", hexColCalBGD50);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGA :hexColCalRGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGA :hexColCalBGA];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalRGD50 :hexColCalRGD50];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameColCalBGD50 :hexColCalBGD50];
    
	/*******************************************************************************************/
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
+(void)BackCameraNVMIntegrityCheckForQL:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
    
	NSString *mBufferNameYear = nil;
	NSString *mBufferNameWeek = nil;
	NSString *mBufferNameDay = nil;
	NSString *mBufferNameID = nil;
    NSString *mBufferNameInt = nil;
    NSString *mBufferNameFlex = nil;
    NSString *mBufferNameSensorType = nil;
    NSString *mBufferNameIRFilter = nil;
	NSString *mBufferNameLens = nil;
	NSString *mBufferNameActuator = nil;
    NSString *mBufferNameAFDriver = nil;
    NSString *mBufferNameTrim = nil;
	NSString *mBufferNameWaiver = nil;
	NSString *mBufferNameCLookUp = nil;
    NSString *mBufferNameCameraBuild = nil;
    NSString *mBufferNameDAC2DN = nil;
    NSString *mBufferNameDAC10UP = nil;
    NSString *mBufferNameRG1 = nil;
	NSString *mBufferNameBG1 = nil;
	NSString *mBufferNameRG2 = nil;
    NSString *mBufferNameBG2 = nil;
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameID"])
		{
			mBufferNameID = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameInt"])
		{
			mBufferNameInt = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensorType"])
		{
			mBufferNameSensorType = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIRFilter"])
		{
			mBufferNameIRFilter = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameActuator"])
		{
			mBufferNameActuator = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameAFDriver"])
		{
			mBufferNameAFDriver = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameTrim"])
		{
			mBufferNameTrim = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameWaiver"])
		{
			mBufferNameWaiver = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameCLookUp"])
		{
			mBufferNameCLookUp = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameCameraBuild"])
		{
			mBufferNameCameraBuild = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDAC2DN"])
		{
			mBufferNameDAC2DN = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameDAC10UP"])
		{
			mBufferNameDAC10UP = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRG1"])
		{
			mBufferNameRG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameBG1"])
		{
			mBufferNameBG1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameRG2"])
		{
			mBufferNameRG2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferNameBG2"])
		{
			mBufferNameBG2 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
    //NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x62 0x68 0x61 0xEA 0x52 0x11 0x4 0x7C \n0x8 : 0x35 0x48 0x50 0x32 0xC9 0x0 0x0 0x0 \n0x10 : 0x02 0x26 0x25 0x41 0x31 0xB 0x24 0x61 \n0x18 : 0x35 0x4B 0x56 0xFB 0x0C 0x96 0xA7 0xB4 \n0x20 : 0xBC 0xBE 0xBA 0x52 0x63 0xD7 0x3D 0x66 \n0x28 : 0x79 0x92 0x35 0xB9 0x08 0xD2 0xD5 0xD0 \n0x30 :";
	
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
    
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
		return;
	}
    
    //add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc]initWithString:bufferValue]autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529 ) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0) {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//end added
    
	
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 48)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 48"];
		return;
	}
    
	/********************  Year ********************/
	NSString *hexYear = [arrayNVM objectAtIndex:17];
	
	hexYear = [hexYear substringFromIndex:1];
	
	//NSLog(@"hexYear =%@", hexYear);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :hexYear];
    
    /******************** Work Week ********************///binary
	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:19]];
	
	binaryWeek = [binaryWeek substringFromIndex:2];
	
	//NSLog(@"binaryWeek =%@", binaryWeek);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
    
    /******************** Day ********************/
	NSString *hexDay = [arrayNVM objectAtIndex:18];
	
	hexDay = [hexDay substringFromIndex:1];
	
	//NSLog(@"hexDay =%@", hexDay);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :hexDay];
    
    /******************** ID ********************/
	NSString *hexID = [arrayNVM objectAtIndex:22];
    hexID = [hexID stringByAppendingString:[arrayNVM objectAtIndex:21]];
    hexID = [hexID stringByAppendingString:[arrayNVM objectAtIndex:20]];
	
	//NSLog(@"hexID =%@", hexID);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameID :hexID];
    
    /******************** Integrator ********************/
	NSString *hexInt = [arrayNVM objectAtIndex:18];
	
	hexInt = [hexInt substringToIndex:1];
	
	//NSLog(@"hexInt =%@", hexInt);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameInt :hexInt];
	
    /******************** Flex ********************/
	NSString *hexFlex = [arrayNVM objectAtIndex:36];
	
	hexFlex = [hexFlex substringToIndex:1];
    
    //NSLog(@"hexFlex =%@", hexFlex);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :hexFlex];
    
    /******************** Sensor Type ********************/
	NSString *hexSensorType = [arrayNVM objectAtIndex:37];
	
	hexSensorType = [hexSensorType substringToIndex:1];
    
    //NSLog(@"hexSensorType =%@", hexSensorType);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorType :hexSensorType];
    
    /******************** IR Cut Filter ********************/
	NSString *hexIRFilter = [arrayNVM objectAtIndex:37];
	
	hexIRFilter = [hexIRFilter substringFromIndex:1];
    
    //NSLog(@"hexIRFilter =%@", hexIRFilter);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRFilter :hexIRFilter];
    
    /******************** Lens ********************/
	NSString *hexLens = [arrayNVM objectAtIndex:36];
    
	hexLens = [hexLens substringFromIndex:1];
    
    //NSLog(@"hexLens =%@", hexLens);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :hexLens];
    
	/******************** Actuator ********************/
	NSString *hexActuator = [arrayNVM objectAtIndex:38];
    
	hexActuator = [hexActuator substringFromIndex:1];
    
    //NSLog(@"hexActuator =%@", hexActuator);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuator :hexActuator];
    
    /******************** AF Driver ********************/
	NSString *hexAFDriver = [arrayNVM objectAtIndex:39];
	
    hexAFDriver = [hexAFDriver substringToIndex:1];
    
    //NSLog(@"hexAFDriver =%@", hexAFDriver);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameAFDriver :hexAFDriver];
    
    /******************** Trim ********************/
	NSString *hexTrim = [arrayNVM objectAtIndex:38];
	
    hexTrim = [hexTrim substringToIndex:1];
    
    //NSLog(@"hexTrim =%@", hexTrim);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrim :hexTrim];
    
    /******************** Waiver ********************/
	NSString *hexWaiver = [arrayNVM objectAtIndex:39];
    
	hexWaiver = [hexWaiver substringFromIndex:1];
    
    //NSLog(@"hexWaiver =%@", hexWaiver);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWaiver :hexWaiver];
    
    /******************** Component Lookup ********************/
    NSString *hexCLookupLSB = [arrayNVM objectAtIndex:41];//get Component Lookup LSB
    hexCLookupLSB = [hexCLookupLSB substringToIndex:1];
    
    NSString *hexCLookupMSB = [arrayNVM objectAtIndex:45];//get Component Lookup MSB
    hexCLookupMSB = [hexCLookupMSB substringToIndex:1];
    
    NSString *hexCLookup = [hexCLookupMSB stringByAppendingString:hexCLookupLSB];
    
    //NSLog(@"hexCLookup =%@", hexCLookup);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCLookUp :hexCLookup];
    
    /******************** Camera Build ********************/
	NSString *hexCameraBuild = [arrayNVM objectAtIndex:40];
	
	hexCameraBuild = [hexCameraBuild substringToIndex:1];
    
    //NSLog(@"hexCameraBuild =%@", hexCameraBuild);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCameraBuild :hexCameraBuild];
    
    /******************** DAC 2cm DN & DAC 10cm UP ********************///binary
    NSString *binaryDAC2DN = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:43]];
    NSString *binaryDAC10UP = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:44]];
    NSString *binaryDACLSB = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:45]];
    
    //Get last 2 bits of DAC 2cm DN
    NSString *postDAC2DN = [binaryDACLSB substringFromIndex:4];
    postDAC2DN = [postDAC2DN substringToIndex:2];
    //
    
    binaryDAC2DN = [binaryDAC2DN stringByAppendingString:postDAC2DN];
    binaryDAC10UP = [binaryDAC10UP stringByAppendingString:[binaryDACLSB substringFromIndex:6]];
    
    //NSLog(@"binaryDAC2DN =%@", binaryDAC2DN);
    //NSLog(@"binaryDAC10UP =%@", binaryDAC10UP);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDAC2DN :binaryDAC2DN];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDAC10UP :binaryDAC10UP];
    
    /******************** RG A/BG A/RG2 D50/BG2 D50 ********************/
    NSString *hexRG1 = [arrayNVM objectAtIndex:24];
    NSString *hexBG1 = [arrayNVM objectAtIndex:25];    
    NSString *hexRG2 = [arrayNVM objectAtIndex:26];
    NSString *hexBG2 = [arrayNVM objectAtIndex:27];
    NSString *hexRG1BG1 = [arrayNVM objectAtIndex:28];
    NSString *hexRG2BG2 = [arrayNVM objectAtIndex:29];
    
    hexRG1 = [hexRG1 stringByAppendingString:[hexRG1BG1 substringToIndex:1]];
	hexBG1 = [hexBG1 stringByAppendingString:[hexRG1BG1 substringFromIndex:1]];
	hexRG2 = [hexRG2 stringByAppendingString:[hexRG2BG2 substringToIndex:1]];
	hexBG2 = [hexBG2 stringByAppendingString:[hexRG2BG2 substringFromIndex:1]];
    
    //NSLog(@"hexRG1 =%@", hexRG1);
	//NSLog(@"hexBG1 =%@", hexBG1);
	//NSLog(@"hexRG2 =%@", hexRG2);
	//NSLog(@"hexBG2 =%@", hexBG2);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRG1 :hexRG1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBG1 :hexBG1];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameRG2 :hexRG2];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBG2 :hexBG2];
    
    /**********************Color Shading***************************************/
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
//End

//update by kevin 0331 start
+(void)BackCameraNVMIntegrityCheckForRS:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix = nil;
	NSString *mPostfix = nil;
    
	NSString *mBufferNameNVM = nil;
    NSString *mBufferNameProject = nil;
    NSString *mBufferNameVariant = nil;
    NSString *mBufferNameIntergrator= nil;
    NSString *mBufferNamePlant= nil;
    NSString *mBufferNameActuator = nil;
    NSString * mBufferNameActuatorVer = nil;
    NSString * mBufferNameLens = nil;
    NSString * mBufferNameLensVer = nil;
    NSString * mBufferNameDriver = nil;
    NSString *mBufferNameDriverVer = nil;
    NSString *mBufferNameIRCF = nil;
    NSString *mBufferNameIRCFVer = nil;
    NSString *mBufferNameSubstrate = nil;
    NSString *mBufferNameSubstrateVer = nil;
    NSString *mBufferNameSensor = nil;
    NSString *mBufferNameSensorVer = nil;
    NSString *mBufferNameFlex = nil;
    NSString *mBufferNameFlexVer = nil;
    NSString *mBufferNameStiffener = nil;
    NSString *mBufferNameStiffenerVer = nil;
    NSString *mBufferNameTrim = nil;
    NSString *mBufferNameTrimVer = nil;
    NSString *mBufferNameRail = nil;//add by kevin on 20150321
    NSString *mBufferNameRailVer = nil;//add by kevin on 20150321
    NSString *mBufferNameCameraBuild = nil;
    NSString *mBufferNameConfigNum = nil;
    NSString *mBufferNameYear = nil;
    NSString *mBufferNameWeek = nil;
    NSString *mBufferNameDay = nil;
    NSString *mBufferNameSeqNum = nil;
    NSString *mBufferNameTSVersion = nil;
    NSString *mBufferNameINFD = nil;
    NSString *mBufferNameMCUP = nil;
    NSString *mBufferNameRGA = nil;
    NSString *mBufferNameBGA = nil;
    NSString *mBufferNameRGD50 = nil;
    NSString *mBufferNameBGD50 = nil;
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameNVM"])
		{
			mBufferNameNVM = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameProject"])
		{
			mBufferNameProject = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameVariant"])
		{
			mBufferNameVariant = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIntergrator"])
		{
			mBufferNameIntergrator = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNamePlant"])
		{
			mBufferNamePlant = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameActuator"])
		{
			mBufferNameActuator = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameActuatorVer"])
		{
			mBufferNameActuatorVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLens"])
		{
			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameLensVer"])
		{
			mBufferNameLensVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDriver"])
		{
			mBufferNameDriver = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDriverVer"])
		{
			mBufferNameDriverVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIRCF"])
		{
			mBufferNameIRCF = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameIRCFVer"])
		{
			mBufferNameIRCFVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSubstrate"])
		{
			mBufferNameSubstrate = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSubstrateVer"])
		{
			mBufferNameSubstrateVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensor"])
		{
			mBufferNameSensor = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSensorVer"])
		{
			mBufferNameSensorVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlex"])
		{
			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameFlexVer"])
		{
			mBufferNameFlexVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameStiffener"])
		{
			mBufferNameStiffener = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameStiffenerVer"])
		{
			mBufferNameStiffenerVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameTrim"])
		{
			mBufferNameTrim = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameTrimVer"])
		{
			mBufferNameTrimVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRail"])
		{
			mBufferNameRail = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRailVer"])
		{
			mBufferNameRailVer = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameCameraBuild"])
		{
			mBufferNameCameraBuild = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameConfigNum"])
		{
			mBufferNameConfigNum = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameYear"])
		{
			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameWeek"])
		{
			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameDay"])
		{
			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameSeqNum"])
		{
			mBufferNameSeqNum = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameTSVer"])
		{
			mBufferNameTSVersion = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameINFD"])
		{
			mBufferNameINFD = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameMCUP"])
		{
			mBufferNameMCUP = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRGA"])
		{
			mBufferNameRGA = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameBGA"])
		{
			mBufferNameBGA = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameRGD50"])
		{
			mBufferNameRGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferNameBGD50"])
		{
			mBufferNameBGD50 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
		return;
	}
    //NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x62 0x68 0x61 0xEA 0x52 0x11 0x4 0x7C \n0x8 : 0x35 0x48 0x50 0x32 0xC9 0x0 0x0 0x0 \n0x10 : 0x02 0x26 0x25 0x41 0x31 0xB 0x24 0x61 \n0x18 : 0x35 0x4B 0x56 0xFB 0x0C 0x96 0xA7 0xB4 \n0x20 : 0xBC 0xBE 0xBA 0x52 0x63 0xD7 0x3D 0x66 \n0x28 : 0x79 0x92 0x35 0xB9 0x08 0xD2 0xD5 0xD0 \n0x30 :";
	
	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
    
	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
	if([bufferValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
		return;
	}
    
    //add by judith for P105 proto2 2012-04-18
    NSMutableString *mutaBufferValue = [[[NSMutableString alloc]initWithString:bufferValue]autorelease];
    
    NSRange preRange ;
    NSRange postRange ;
    do
    {
        preRange = [mutaBufferValue rangeOfString:@"\n"];
        postRange = [mutaBufferValue rangeOfString:@":"];
        if(postRange.location >2529 ) //delete the last
        {
            [mutaBufferValue deleteCharactersInRange:preRange];
            break;
        }
        preRange.length = postRange.location - preRange.location+1;
        [mutaBufferValue deleteCharactersInRange:preRange];
    }while (preRange.length >0);
    
    while ([mutaBufferValue rangeOfString:@" "].length > 0) {
        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
    }
    
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	//end added
    
	
	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
	
	NSString *oneZero = @"0";
	for(int i=0; i<[arrayNVM count]; i++)
	{
		NSString * tmp = [arrayNVM objectAtIndex:i];
		if([tmp length] < 2)
		{
			tmp = [oneZero stringByAppendingString:tmp];
			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
		}
	}
	NSLog(@"after add 0, NVM =%@", arrayNVM);
	
	if([arrayNVM count] <= 48)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 48"];
		return;
	}
    
	/******************** NVM Version ********************/
	NSString *hexNVM = [arrayNVM objectAtIndex:1];
    
	//NSLog(@"hexNVM =%@", hexNVM);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVM :hexNVM];
	
    /******************** Project Identifier/Variation ********************/
	NSString *hexProj_Id_Var = [arrayNVM objectAtIndex:2];
    NSString *hexProject = [hexProj_Id_Var substringToIndex:1];
    NSString *hexVariant = [hexProj_Id_Var substringFromIndex:1];
    
	//NSLog(@"hexProj_Id_Var =%@", hexProj_Id_Var);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameProject :hexProject];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameVariant :hexVariant];
    
	/******************** Integrator/Plant ********************/
	NSString *hexInt_Plant = [arrayNVM objectAtIndex:3];
    NSString *hexIntegrator = [hexInt_Plant substringToIndex:1];
    NSString *hexPlant = [hexInt_Plant substringFromIndex:1];
	
	//NSLog(@"hexInt_Plant =%@", hexInt_Plant);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntergrator :hexIntegrator];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNamePlant :hexPlant];
	
	/******************** Actuator ********************/
	NSString *hexActuatorAndVer = [arrayNVM objectAtIndex:4];
    
	NSString *hexActuator = [hexActuatorAndVer substringToIndex:1];
    NSString *hexActuatorVer = [hexActuatorAndVer substringFromIndex:1];
    
    //NSLog(@"hexActuator =%@", hexActuator);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuator :hexActuator];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuatorVer :hexActuatorVer];
    /******************** Lens & Version ********************/
	NSString *hexLensAndVer = [arrayNVM objectAtIndex:5];
	
	NSString *hexLens = [hexLensAndVer substringToIndex:1];
	NSString *hexLensVer = [hexLensAndVer substringFromIndex:1];
	
	//NSLog(@"hexLens =%@", hexLens);
	//NSLog(@"hexLensVer =%@", hexLensVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :hexLens];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLensVer :hexLensVer];
    
    /******************** Driver ********************/
	NSString *hexDriverAndVer = [arrayNVM objectAtIndex:6];
	
    NSString *hexDriver = [hexDriverAndVer substringToIndex:1];
    NSString *hexDriverVer = [hexDriverAndVer substringFromIndex:1];
    
    //NSLog(@"hexAFDriver =%@", hexAFDriver);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDriver :hexDriver];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDriverVer :hexDriverVer];
    
    /******************** IRCF & Version ********************/
	NSString *hexIRCFAndVer = [arrayNVM objectAtIndex:7];
	
	NSString *hexIRCF = [hexIRCFAndVer substringToIndex:1];
	NSString *hexIRCFVer = [hexIRCFAndVer substringFromIndex:1];
	
	//NSLog(@"hexIRCF =%@", hexIRCF);
	//NSLog(@"hexIRCFVer =%@", hexIRCFVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCF :hexIRCF];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCFVer :hexIRCFVer];
    
    /******************** Substrate & Version ********************/
	NSString *hexSubstrateAndVer = [arrayNVM objectAtIndex:8];
	
	NSString *hexSubstrate = [hexSubstrateAndVer substringToIndex:1];
	NSString *hexSubstrateVer = [hexSubstrateAndVer substringFromIndex:1];
	
	//NSLog(@"hexSubstrate =%@", hexSubstrate);
	//NSLog(@"hexSubstrateVer =%@", hexSubstrateVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrate :hexSubstrate];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrateVer :hexSubstrateVer];
    
    /******************** Sensor & Version ********************/
	NSString *hexSensorAndVer = [arrayNVM objectAtIndex:9];
	
	NSString *hexSensor = [hexSensorAndVer substringToIndex:1];
	NSString *hexSensorVer = [hexSensorAndVer substringFromIndex:1];
	
	//NSLog(@"hexSensor =%@", hexSensor);
	//NSLog(@"hexSensorVer =%@", hexSensorVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensor :hexSensor];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorVer :hexSensorVer];
    
    /******************** Flex & Version ********************/
	NSString *hexFlexAndVer = [arrayNVM objectAtIndex:10];
	
	NSString *hexFlex = [hexFlexAndVer substringToIndex:1];
	NSString *hexFlexVer = [hexFlexAndVer substringFromIndex:1];
	
	//NSLog(@"hexFlex =%@", hexFlex);
	//NSLog(@"hexFlexVer =%@", hexFlexVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :hexFlex];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlexVer :hexFlexVer];
    
    /******************** Stiffener & Version ********************/
	NSString *hexStiffenerAndVer = [arrayNVM objectAtIndex:11];
	
	NSString *hexStiffener = [hexStiffenerAndVer substringToIndex:1];
	NSString *hexStiffenerVer = [hexStiffenerAndVer substringFromIndex:1];
	
	//NSLog(@"hexFlex =%@", hexFlex);
	//NSLog(@"hexFlexVer =%@", hexFlexVer);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffener :hexStiffener];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffenerVer :hexStiffenerVer];
    
    /******************** Trim & Version ********************/
	NSString *hexTrimAndVer = [arrayNVM objectAtIndex:12];
	
    NSString *hexTrim = [hexTrimAndVer substringToIndex:1];
    NSString *hexTrimVer = [hexTrimAndVer substringFromIndex:1];
    
    //NSLog(@"hexTrim =%@", hexTrim);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrim :hexTrim];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrimVer :hexTrimVer];
    
    
    //add by kevin on 20150321 base on new backcamera ERS start
    /******************** Rail & Version ********************/
	NSString *hexRailAndVer = [arrayNVM objectAtIndex:13];
	
    NSString *hexRail = [hexRailAndVer substringToIndex:1];
    NSString *hexRailVer = [hexRailAndVer substringFromIndex:1];
    
    //NSLog(@"hexTrim =%@", hexTrim);
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRail :hexRail];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameRailVer :hexRailVer];
    
    //add by kevin on 20150321 base on new backcamera ERS end
    
    /******************** Camera Build ********************/
	//NSString *hexCameraBuild = [arrayNVM objectAtIndex:17];
    NSString *hexCameraBuild = [arrayNVM objectAtIndex:18];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCameraBuild :hexCameraBuild];
    
    /******************** Config Number ********************/
	//NSString *hexConfigNum = [arrayNVM objectAtIndex:18];
	
    NSString *hexConfigNum = [arrayNVM objectAtIndex:19];
	//NSLog(@"hexConfigNum =%@", hexConfigNum);
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameConfigNum :hexConfigNum];
    
    /********************  Year ********************/
	//NSString *hexYear = [arrayNVM objectAtIndex:19];
	NSString *hexYear = [arrayNVM objectAtIndex:20];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :hexYear];
    
    /******************** Work Week ********************///binary
	//NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
    NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:21]];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
    
    /******************** Day ********************/
	//NSString *hexDay = [arrayNVM objectAtIndex:21];
	
    NSString *hexDay = [arrayNVM objectAtIndex:22];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :hexDay];
    
    /******************** Sequence Number ********************/
    //    NSString *hexSeqNum1 = [arrayNVM objectAtIndex:22];
    //    NSString *hexSeqNum2 = [arrayNVM objectAtIndex:23];
    //    NSString *hexSeqNum3 = [arrayNVM objectAtIndex:24];
    
    NSString *hexSeqNum1 = [arrayNVM objectAtIndex:23];
    NSString *hexSeqNum2 = [arrayNVM objectAtIndex:24];
    NSString *hexSeqNum3 = [arrayNVM objectAtIndex:25];
    
    NSString *hexSeqNum = [hexSeqNum3 stringByAppendingString:hexSeqNum2];
    hexSeqNum = [hexSeqNum stringByAppendingString:hexSeqNum1];
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSeqNum :hexSeqNum];
    
    /******************** Test Software Version ********************///add by kevin 201501508 for QT0b
    NSString *tSVersion = [arrayNVM objectAtIndex:32];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTSVersion :tSVersion];
    
    /******************** AF Infinity down(INFD) ********************/
    //NSString *hexINFD = [arrayNVM objectAtIndex:33];
    
    NSString *hexINFD = [arrayNVM objectAtIndex:34];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameINFD :hexINFD];
    
    /******************** AF Macro up(MCUP) ********************/
    //NSString *hexMCUP = [arrayNVM objectAtIndex:34];
    
    NSString *hexMCUP = [arrayNVM objectAtIndex:35];
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameMCUP :hexMCUP];
    
    /******************** RG A/BG A/RG D50/BG D50 ********************/
    //    NSString *hexRGA1 = [arrayNVM objectAtIndex:37];//[11,4]
    //    NSString *hexRGA2 = [arrayNVM objectAtIndex:41];
    //    hexRGA2 = [hexRGA2 substringToIndex:1];//[4,0]
    //    NSString *hexRGA = [hexRGA1 stringByAppendingString:hexRGA2];
    //
    //    NSString *hexBGA1 = [arrayNVM objectAtIndex:38];
    //    NSString *hexBGA2 = [arrayNVM objectAtIndex:41];
    //    hexBGA2 = [hexBGA2 substringFromIndex:1];
    //    NSString *hexBGA = [hexBGA1 stringByAppendingString:hexBGA2];
    //
    //    NSString *hexRGD501 = [arrayNVM objectAtIndex:39];
    //    NSString *hexRGD502 = [arrayNVM objectAtIndex:42];
    //    hexRGD502 = [hexRGD502 substringToIndex:1];
    //    NSString *hexRGD50 = [hexRGD501 stringByAppendingString:hexRGD502];
    //
    //    NSString *hexBGD501 = [arrayNVM objectAtIndex:40];
    //    NSString *hexBGD502 = [arrayNVM objectAtIndex:42];
    //    hexBGD502 = [hexBGD502 substringFromIndex:1];
    //    NSString *hexBGD50 = [hexBGD501 stringByAppendingString:hexBGD502];
    NSString *hexRGA1 = [arrayNVM objectAtIndex:50];//[15,8]
    NSString *hexRGA2 = [arrayNVM objectAtIndex:49];//[0,7]
    hexRGA1 = [hexRGA1 substringToIndex:1];//[11,8]
    NSString *hexRGA = [hexRGA1 stringByAppendingString:hexRGA2];
    
    NSString *hexBGA1 = [arrayNVM objectAtIndex:52];
    NSString *hexBGA2 = [arrayNVM objectAtIndex:51];
    hexBGA1 = [hexBGA1 substringToIndex:1];//[11,8]
    NSString *hexBGA = [hexBGA1 stringByAppendingString:hexBGA2];
    
    NSString *hexRGD501 = [arrayNVM objectAtIndex:54];
    NSString *hexRGD502 = [arrayNVM objectAtIndex:53];
    hexRGD501 = [hexRGD501 substringToIndex:1];
    NSString *hexRGD50 = [hexRGD501 stringByAppendingString:hexRGD502];
    
    NSString *hexBGD501 = [arrayNVM objectAtIndex:56];
    NSString *hexBGD502 = [arrayNVM objectAtIndex:55];
    hexBGD501 = [hexBGD501 substringFromIndex:1];
    NSString *hexBGD50 = [hexBGD501 stringByAppendingString:hexBGD502];
    
    
	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRGA :hexRGA];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBGA :hexBGA];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameRGD50 :hexRGD50];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBGD50 :hexBGD50];
    
    /*******************************************************************************************/
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
	
}
//update by kevin 0331 end



//+(void)BackCameraNVMIntegrityCheckForRS:(NSDictionary*)dictKeyDefined
//{
//	NSString *mTestItemName=nil;
//	NSString *mReferenceBufferName=nil;
//	NSString *mPrefix = nil;
//	NSString *mPostfix = nil;
//    
//	NSString *mBufferNameNVM = nil;
//    NSString *mBufferNameProject = nil;
//    NSString *mBufferNameVariant = nil;
//    NSString *mBufferNameIntergrator= nil;
//    NSString *mBufferNamePlant= nil;
//    NSString *mBufferNameActuator = nil;
//    NSString * mBufferNameActuatorVer = nil;
//    NSString * mBufferNameLens = nil;
//    NSString * mBufferNameLensVer = nil;
//    NSString * mBufferNameDriver = nil;
//    NSString *mBufferNameDriverVer = nil;
//    NSString *mBufferNameIRCF = nil;
//    NSString *mBufferNameIRCFVer = nil;
//    NSString *mBufferNameSubstrate = nil;
//    NSString *mBufferNameSubstrateVer = nil;
//    NSString *mBufferNameSensor = nil;
//    NSString *mBufferNameSensorVer = nil;
//    NSString *mBufferNameFlex = nil;
//    NSString *mBufferNameFlexVer = nil;
//    NSString *mBufferNameStiffener = nil;
//    NSString *mBufferNameStiffenerVer = nil;
//    NSString *mBufferNameTrim = nil;
//    NSString *mBufferNameTrimVer = nil;
//    NSString *mBufferNameRail = nil;//add by kevin on 20150321
//    NSString *mBufferNameRailVer = nil;//add by kevin on 20150321
//    NSString *mBufferNameCameraBuild = nil;
//    NSString *mBufferNameConfigNum = nil;
//    NSString *mBufferNameYear = nil;
//    NSString *mBufferNameWeek = nil;
//    NSString *mBufferNameDay = nil;
//    NSString *mBufferNameSeqNum = nil;
//    NSString *mBufferNameINFD = nil;
//    NSString *mBufferNameMCUP = nil;
//    NSString *mBufferNameRGA = nil;
//    NSString *mBufferNameBGA = nil;
//    NSString *mBufferNameRGD50 = nil;
//    NSString *mBufferNameBGD50 = nil;
//    
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"Prefix"])
//		{
//			mPrefix = [dictKeyDefined objectForKey:strKey] ;
//		}
//		else if ([strKey isEqualToString:@"Postfix"])
//		{
//			mPostfix = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameNVM"])
//		{
//			mBufferNameNVM = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameProject"])
//		{
//			mBufferNameProject = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameVariant"])
//		{
//			mBufferNameVariant = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameIntergrator"])
//		{
//			mBufferNameIntergrator = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNamePlant"])
//		{
//			mBufferNamePlant = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameActuator"])
//		{
//			mBufferNameActuator = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameActuatorVer"])
//		{
//			mBufferNameActuatorVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameLens"])
//		{
//			mBufferNameLens = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameLensVer"])
//		{
//			mBufferNameLensVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameDriver"])
//		{
//			mBufferNameDriver = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameDriverVer"])
//		{
//			mBufferNameDriverVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameIRCF"])
//		{
//			mBufferNameIRCF = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameIRCFVer"])
//		{
//			mBufferNameIRCFVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameSubstrate"])
//		{
//			mBufferNameSubstrate = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameSubstrateVer"])
//		{
//			mBufferNameSubstrateVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameSensor"])
//		{
//			mBufferNameSensor = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameSensorVer"])
//		{
//			mBufferNameSensorVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameFlex"])
//		{
//			mBufferNameFlex = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameFlexVer"])
//		{
//			mBufferNameFlexVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameStiffener"])
//		{
//			mBufferNameStiffener = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameStiffenerVer"])
//		{
//			mBufferNameStiffenerVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameTrim"])
//		{
//			mBufferNameTrim = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameTrimVer"])
//		{
//			mBufferNameTrimVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameRail"])
//		{
//			mBufferNameRail = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameRailVer"])
//		{
//			mBufferNameRailVer = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameCameraBuild"])
//		{
//			mBufferNameCameraBuild = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameConfigNum"])
//		{
//			mBufferNameConfigNum = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameYear"])
//		{
//			mBufferNameYear = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameWeek"])
//		{
//			mBufferNameWeek = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameDay"])
//		{
//			mBufferNameDay = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameSeqNum"])
//		{
//			mBufferNameSeqNum = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameINFD"])
//		{
//			mBufferNameINFD = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameMCUP"])
//		{
//			mBufferNameMCUP = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameRGA"])
//		{
//			mBufferNameRGA = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameBGA"])
//		{
//			mBufferNameBGA = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameRGD50"])
//		{
//			mBufferNameRGD50 = [dictKeyDefined objectForKey:strKey] ;
//		}
//        else if ([strKey isEqualToString:@"BufferNameBGD50"])
//		{
//			mBufferNameBGD50 = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	if (mReferenceBufferName==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Script Error"];
//		return;
//	}
//    //NSString *mReferenceBufferValue = @"NVM Data 512 bytes : \n0x0 : 0x62 0x68 0x61 0xEA 0x52 0x11 0x4 0x7C \n0x8 : 0x35 0x48 0x50 0x32 0xC9 0x0 0x0 0x0 \n0x10 : 0x02 0x26 0x25 0x41 0x31 0xB 0x24 0x61 \n0x18 : 0x35 0x4B 0x56 0xFB 0x0C 0x96 0xA7 0xB4 \n0x20 : 0xBC 0xBE 0xBA 0x52 0x63 0xD7 0x3D 0x66 \n0x28 : 0x79 0x92 0x35 0xB9 0x08 0xD2 0xD5 0xD0 \n0x30 :";
//	
//	NSString *mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
//	if (mReferenceBufferValue==nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
//		return;
//	}
//    
//	NSString *bufferValue = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix] ;
//	if([bufferValue length] <= 0)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message"];
//		return;
//	}
//    
//    //add by judith for P105 proto2 2012-04-18
//    NSMutableString *mutaBufferValue = [[[NSMutableString alloc]initWithString:bufferValue]autorelease];
//    
//    NSRange preRange ;
//    NSRange postRange ;
//    do
//    {
//        preRange = [mutaBufferValue rangeOfString:@"\n"];
//        postRange = [mutaBufferValue rangeOfString:@":"];
//        if(postRange.location >2529 ) //delete the last
//        {
//            [mutaBufferValue deleteCharactersInRange:preRange];
//            break;
//        }
//        preRange.length = postRange.location - preRange.location+1;
//        [mutaBufferValue deleteCharactersInRange:preRange];
//    }while (preRange.length >0);
//    
//    while ([mutaBufferValue rangeOfString:@" "].length > 0) {
//        [mutaBufferValue deleteCharactersInRange:[mutaBufferValue rangeOfString:@" "]];
//    }
//    
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
//	[mutaBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
//	//end added
//    
//	
//	NSMutableArray *arrayNVM = (NSMutableArray*)[mutaBufferValue componentsSeparatedByString:@"0x"];
//	
//	NSString *oneZero = @"0";
//	for(int i=0; i<[arrayNVM count]; i++)
//	{
//		NSString * tmp = [arrayNVM objectAtIndex:i];
//		if([tmp length] < 2)
//		{
//			tmp = [oneZero stringByAppendingString:tmp];
//			[arrayNVM replaceObjectAtIndex:i withObject:tmp];
//		}
//	}
//	NSLog(@"after add 0, NVM =%@", arrayNVM);
//	
//	if([arrayNVM count] <= 48)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"Diag return different message,hex number <= 48"];
//		return;
//	}
//    
//	/******************** NVM Version ********************/
//	NSString *hexNVM = [arrayNVM objectAtIndex:1];
//    
//	//NSLog(@"hexNVM =%@", hexNVM);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameNVM :hexNVM];
//	
//    /******************** Project Identifier/Variation ********************/
//	NSString *hexProj_Id_Var = [arrayNVM objectAtIndex:2];
//    NSString *hexProject = [hexProj_Id_Var substringToIndex:1];
//    NSString *hexVariant = [hexProj_Id_Var substringFromIndex:1];
//    
//	//NSLog(@"hexProj_Id_Var =%@", hexProj_Id_Var);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameProject :hexProject];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameVariant :hexVariant];
//    
//	/******************** Integrator/Plant ********************/
//	NSString *hexInt_Plant = [arrayNVM objectAtIndex:3];
//    NSString *hexIntegrator = [hexInt_Plant substringToIndex:1];
//    NSString *hexPlant = [hexInt_Plant substringFromIndex:1];
//	
//	//NSLog(@"hexInt_Plant =%@", hexInt_Plant);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIntergrator :hexIntegrator];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNamePlant :hexPlant];
//	
//	/******************** Actuator ********************/
//	NSString *hexActuatorAndVer = [arrayNVM objectAtIndex:4];
//    
//	NSString *hexActuator = [hexActuatorAndVer substringToIndex:1];
//    NSString *hexActuatorVer = [hexActuatorAndVer substringFromIndex:1];
//    
//    //NSLog(@"hexActuator =%@", hexActuator);
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuator :hexActuator];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameActuatorVer :hexActuatorVer];
//    /******************** Lens & Version ********************/
//	NSString *hexLensAndVer = [arrayNVM objectAtIndex:5];
//	
//	NSString *hexLens = [hexLensAndVer substringToIndex:1];
//	NSString *hexLensVer = [hexLensAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexLens =%@", hexLens);
//	//NSLog(@"hexLensVer =%@", hexLensVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLens :hexLens];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameLensVer :hexLensVer];
//    
//    /******************** Driver ********************/
//	NSString *hexDriverAndVer = [arrayNVM objectAtIndex:6];
//	
//    NSString *hexDriver = [hexDriverAndVer substringToIndex:1];
//    NSString *hexDriverVer = [hexDriverAndVer substringFromIndex:1];
//    
//    //NSLog(@"hexAFDriver =%@", hexAFDriver);
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDriver :hexDriver];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameDriverVer :hexDriverVer];
//    
//    /******************** IRCF & Version ********************/
//	NSString *hexIRCFAndVer = [arrayNVM objectAtIndex:7];
//	
//	NSString *hexIRCF = [hexIRCFAndVer substringToIndex:1];
//	NSString *hexIRCFVer = [hexIRCFAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexIRCF =%@", hexIRCF);
//	//NSLog(@"hexIRCFVer =%@", hexIRCFVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCF :hexIRCF];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameIRCFVer :hexIRCFVer];
//    
//    /******************** Substrate & Version ********************/
//	NSString *hexSubstrateAndVer = [arrayNVM objectAtIndex:8];
//	
//	NSString *hexSubstrate = [hexSubstrateAndVer substringToIndex:1];
//	NSString *hexSubstrateVer = [hexSubstrateAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexSubstrate =%@", hexSubstrate);
//	//NSLog(@"hexSubstrateVer =%@", hexSubstrateVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrate :hexSubstrate];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSubstrateVer :hexSubstrateVer];
//    
//    /******************** Sensor & Version ********************/
//	NSString *hexSensorAndVer = [arrayNVM objectAtIndex:9];
//	
//	NSString *hexSensor = [hexSensorAndVer substringToIndex:1];
//	NSString *hexSensorVer = [hexSensorAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexSensor =%@", hexSensor);
//	//NSLog(@"hexSensorVer =%@", hexSensorVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensor :hexSensor];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSensorVer :hexSensorVer];
//    
//    /******************** Flex & Version ********************/
//	NSString *hexFlexAndVer = [arrayNVM objectAtIndex:10];
//	
//	NSString *hexFlex = [hexFlexAndVer substringToIndex:1];
//	NSString *hexFlexVer = [hexFlexAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexFlex =%@", hexFlex);
//	//NSLog(@"hexFlexVer =%@", hexFlexVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlex :hexFlex];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameFlexVer :hexFlexVer];
//    
//    /******************** Stiffener & Version ********************/
//	NSString *hexStiffenerAndVer = [arrayNVM objectAtIndex:11];
//	
//	NSString *hexStiffener = [hexStiffenerAndVer substringToIndex:1];
//	NSString *hexStiffenerVer = [hexStiffenerAndVer substringFromIndex:1];
//	
//	//NSLog(@"hexFlex =%@", hexFlex);
//	//NSLog(@"hexFlexVer =%@", hexFlexVer);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffener :hexStiffener];
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameStiffenerVer :hexStiffenerVer];
//    
//    /******************** Trim & Version ********************/
//	NSString *hexTrimAndVer = [arrayNVM objectAtIndex:12];
//	
//    NSString *hexTrim = [hexTrimAndVer substringToIndex:1];
//    NSString *hexTrimVer = [hexTrimAndVer substringFromIndex:1];
//    
//    //NSLog(@"hexTrim =%@", hexTrim);
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrim :hexTrim];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameTrimVer :hexTrimVer];
//    
//    
//    //add by kevin on 20150321 base on new backcamera ERS start
//    /******************** Rail & Version ********************/
//	NSString *hexRailAndVer = [arrayNVM objectAtIndex:13];
//	
//    NSString *hexRail = [hexRailAndVer substringToIndex:1];
//    NSString *hexRailVer = [hexRailAndVer substringFromIndex:1];
//    
//    //NSLog(@"hexTrim =%@", hexTrim);
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRail :hexRail];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameRailVer :hexRailVer];
//    
//    //add by kevin on 20150321 base on new backcamera ERS end
//    
//    /******************** Camera Build ********************/
//	NSString *hexCameraBuild = [arrayNVM objectAtIndex:17];
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameCameraBuild :hexCameraBuild];
//    
//    /******************** Config Number ********************/
//	NSString *hexConfigNum = [arrayNVM objectAtIndex:18];
//	
//	//NSLog(@"hexConfigNum =%@", hexConfigNum);
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameConfigNum :hexConfigNum];
//    
//    /********************  Year ********************/
//	NSString *hexYear = [arrayNVM objectAtIndex:19];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameYear :hexYear];
//    
//    /******************** Work Week ********************///binary
//	NSString *binaryWeek = [ToolFun changeHextoBinary:[arrayNVM objectAtIndex:20]];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameWeek :binaryWeek];
//    
//    /******************** Day ********************/
//	NSString *hexDay = [arrayNVM objectAtIndex:21];
//	
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameDay :hexDay];
//    
//    /******************** Sequence Number ********************/
//    NSString *hexSeqNum1 = [arrayNVM objectAtIndex:22];
//    NSString *hexSeqNum2 = [arrayNVM objectAtIndex:23];
//    NSString *hexSeqNum3 = [arrayNVM objectAtIndex:24];
//    
//    NSString *hexSeqNum = [hexSeqNum3 stringByAppendingString:hexSeqNum2];
//    hexSeqNum = [hexSeqNum stringByAppendingString:hexSeqNum1];
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameSeqNum :hexSeqNum];
//    
//    /******************** AF Infinity down(INFD) ********************/
//    NSString *hexINFD = [arrayNVM objectAtIndex:33];
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameINFD :hexINFD];
//    
//    /******************** AF Macro up(MCUP) ********************/
//    NSString *hexMCUP = [arrayNVM objectAtIndex:34];
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameMCUP :hexMCUP];
//    
//    /******************** RG A/BG A/RG D50/BG D50 ********************/
//    NSString *hexRGA1 = [arrayNVM objectAtIndex:37];//[11,4]
//    NSString *hexRGA2 = [arrayNVM objectAtIndex:41];
//    hexRGA2 = [hexRGA2 substringToIndex:1];//[4,0]
//    NSString *hexRGA = [hexRGA1 stringByAppendingString:hexRGA2];
//    
//    NSString *hexBGA1 = [arrayNVM objectAtIndex:38];
//    NSString *hexBGA2 = [arrayNVM objectAtIndex:41];
//    hexBGA2 = [hexBGA2 substringFromIndex:1];
//    NSString *hexBGA = [hexBGA1 stringByAppendingString:hexBGA2];
//    
//    NSString *hexRGD501 = [arrayNVM objectAtIndex:39];
//    NSString *hexRGD502 = [arrayNVM objectAtIndex:42];
//    hexRGD502 = [hexRGD502 substringToIndex:1];
//    NSString *hexRGD50 = [hexRGD501 stringByAppendingString:hexRGD502];
//    
//    NSString *hexBGD501 = [arrayNVM objectAtIndex:40];
//    NSString *hexBGD502 = [arrayNVM objectAtIndex:42];
//    hexBGD502 = [hexBGD502 substringFromIndex:1];
//    NSString *hexBGD50 = [hexBGD501 stringByAppendingString:hexBGD502];
//    
//	[TestItemManage setBufferValue:dictKeyDefined :mBufferNameRGA :hexRGA];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBGA :hexBGA];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameRGD50 :hexRGD50];
//    [TestItemManage setBufferValue:dictKeyDefined :mBufferNameBGD50 :hexBGD50];
//    
//    /*******************************************************************************************/
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
//	
//}

+(void)ParseNVItem:(NSDictionary *)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	NSString *mNotContainStr=nil;
	
    
	for(int i=0;i<[dictKeyDefined count];i++)
	{
		NSString *strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Prefix"])
		{
			mPrefix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"Postfix"])
		{
			mPostfix=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"NotContainStr"])
		{
			mNotContainStr=[dictKeyDefined objectForKey:strKey];
		}
	}
    
    if(mReferenceBufferName == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER:@"Scrip Occur Error"];
        return;
    }
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    if(mReferenceBufferValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
        return ;
    }
     
    
    //mReferenceBufferValue = @":-) dev -e send_command hex \"0x26 0xc 0x2\"\nResponse:\n0000000: 26 0C 02 F1 00 00 00 00 00 00 00 00 00 00 00 00  &\n...............\n0000010:" ;  
    
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    //mPrefix = [mReferenceBufferValue rangeOfString:mPrefix].location;
    NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue
                                                     Prefix:mPrefix
                                                    Postfix:mPostfix] ;	
    //NSLog(@"strFind=%@",strFind);
    if(strFind == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue];
        return;
    }
    
    NSString *tmpFirst8Bytes = [strFind substringToIndex:16];
    //NSLog(@"tmpFirst8Bytes=%@",tmpFirst8Bytes);
    if([tmpFirst8Bytes isEqualToString:mNotContainStr])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"FAIL"];
        return;
    }
    else 
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"];
        return;
    }
    
    
}	
@end
