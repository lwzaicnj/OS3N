//
//  QTSerialPort.h
//  QTSerialPort
//
//  Created by QT on 8/21/15.
//  Copyright (c) 2015 QT. All rights reserved.
//

#ifndef __QTSerialPort__H
#define __QTSerialPort__H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define QTSP_API   extern
   
/*****************************************************************/
enum {
    kQtBaud1200 = 1200,
    kQtBaud1800 = 1800,
    kQtBaud2400 = 2400,
    kQtBaud4800 = 4800,
    kQtBaud9600 = 9600,
    kQtBaud19200 = 19200,
    kQtBaud38400 = 38400,
    kQtBaud57600 = 57600,
    kQtBaud115200 = 115200,
    kQtBaud230400 = 230400,
    kQtBaudUnknown = -1,
};

enum {
    kQtData5 = 5,
    kQtData6 = 6,
    kQtData7 = 7,
    kQtData8 = 8,
    kQtDataUnknown = -1,
};

enum {
    kQtNoParity = 0,
    kQtEvenParity = 2,
    kQtOddParity = 3,
    kQtSpaceParity = 4,
    kQtMarkParity = 5,
    kQtUnknownParity = -1,
};

enum {
    kQtOneStop = 1,
    kQtOneAndHalfStop = 3,
    kQtTwoStop = 2,
    kQtUnknownStopBits = -1,
};

enum {
    kQtNoFlowControl = 0,
    kQtHardwareControl = 1,
    kQtSoftwareControl = 2,
    kQtUnknownFlowControl = -1,
};

enum {
    kQtOK = 0,
    kQtErrorSys = -1,
    kQtErrorReadZero = -2,
    kQtErrorReadMax = -3,
    kQtErrorSelect = -4,
    kQtErrorCheckType = -5,
    kQtErrorFdSet = -6,
    kQtErrorFdNull = -7,
    kQtErrorNull = -8,
    kQtErrorUnknown = -100,
};

    
/*****************************************************************/
QTSP_API int QT_SerialPortOpen(const char *path);
QTSP_API int QT_SerialPortSend(int fd, const unsigned char *data, size_t len, long sec, int usec);
QTSP_API long QT_SerialPortRecv(int fd, unsigned char *data, size_t len, const char* endStr, long sec, int usec);
QTSP_API int QT_SerialPortClose(int fd);
    
QTSP_API int QT_SetBaudRate(int fd, unsigned long baudRate);
QTSP_API int QT_SetDataBits(int fd, int dataBits);
QTSP_API int QT_SetParity(int fd, char parity);
QTSP_API int QT_SetStopBits(int fd, int stopBits);
QTSP_API int QT_SetFlowControl(int fd, int flowControl);
/*****************************************************************/
    

#ifdef __cplusplus
}
#endif
    
#endif /* defined(__QTSerialPort__H) */
