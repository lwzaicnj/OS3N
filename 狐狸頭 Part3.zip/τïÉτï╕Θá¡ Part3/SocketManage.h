//
//  SocketManage.h
//  iFTS
//
//  Created by SW QT on 11/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CommManage.h"
#import "toolFun.h"

#define SocketDefineDevice     @"socketDefineDeviceID"

#define KEY_Summary         @"Summary"
#define KEY_LogService      @"LogService"
#define KEY_DeviceService   @"DeviceService"
#define KEY_DeviceIDList    @"DeviceIDList"
#define KEY_TestScript      @"TestScript"

enum SocketDataType
{
	SocketDataType_ScriptData  ,
	SocketDataType_VersionList ,
	SocketDataType_StationList ,
	SocketDataType_Appconfig   , 	
	SocketDataType_TestScript  ,
};

@interface SocketManage : NSObject {

}

//outer function .
+(bool)loadDataFromCloudServer:(NSString*) strIP PortID
                              :(int)iPortID  ProtocolStr
							  :(NSString *)strCmd  DataType
                              :(enum SocketDataType) socketDataType TimeOut  
                              :(int) iTimeOut;

+(bool)sendDataToCloudServer:(NSString*) strIP PortID
							:(int)iPortID  ProtocolStr
							:(NSString *)strCmd  TimeOut
							:(int)iTimeOut;

+(void)setCloudErrorMsg:(NSString*)strErr ;
+(NSString*)getCloudErrorMsg ;

+(NSString*)getAppconfigData  ;
+(NSString*)getTestScriptData ;
+(NSArray*)getStationListData ;
+(NSArray*)getVersionListData ;

+(NSDictionary*)getDictSummaryFromScriptData ;
+(NSDictionary*)getDictLogServiceFromScriptData ;
+(NSArray*)getArrayDeviceServiceFromScriptData ;
+(NSArray*)getArrayTestScriptFromScriptData ;
+(NSArray*)getArrayDeviceIDListFromScriptData ;

//inner function
+(bool)fillDataToScriptData:(NSData*)receData  ;
+(bool)fillDataToAppconfig:(NSData*)receData   ;
+(bool)fillDataToTestScript:(NSData*)receData  ;
+(bool)fillDataToStationList:(NSData*)receData ;
+(bool)fillDataToVersionList:(NSData*)receData ;
+(NSMutableArray*)sortArrayWithStrObj:(NSMutableArray*)array;
@end
