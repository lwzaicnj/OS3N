/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParsePreviousItemResult.m  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParsePreviousItemResult.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */

#import "Pudding.h"
#import "ParsePreviousItemResult.h"


@implementation TestItemParse(ParsePreviousItemResult)

+(void)ParsePreviousItemResult:(NSDictionary*) dictKeyDefined
{
	NSString *mBufferName=nil    ;
	NSString *mTimeOut=@"6"      ;
	NSString *mWhetherRead = @"yes" ;
	NSString *mPostfix =@":-)";
	NSString *mTestItemName=nil     ;
	NSString *mCheckPreviousResult = @"yes";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}		
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"WhetherRead"])
		{
			mWhetherRead = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"CheckPreviousResult"])
		{
			mCheckPreviousResult = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	if (mBufferName==nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script error"] ;
		return ;
	}
	
	if([mCheckPreviousResult isEqualToString:@"no"])
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Jump off"] ;
		return ;
	}
		
	
	BOOL flag = YES;
	flag = [TestItemManage checkPriorAllTestItemResult:dictKeyDefined];
		
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"PASS"] ;	
	return ;
}


+(void)EepromVersionCheck:(NSDictionary*) dictKeyDefined
{
    NSString *mReferenceBufferName=nil    ;
    NSString *mReferenceBufferNameMajor=nil    ;
    NSString *mReferenceBufferNameMinor=nil    ;
    
    NSString* msdcMajorLow=nil;
    NSString* msdcMajorHigh=nil;
    
    NSString* msdcMinorLow=nil;
    NSString* msdcMinorHigh=nil;
    
    NSString* mgisMajorLow=nil;
    NSString* mgisMajorHigh=nil;
    
    NSString* mgisMinorLow=nil;
    NSString* mgisMinorHigh=nil;
    
    NSString* mlgdMajorLow=nil;
    NSString* mlgdMajorHigh=nil;
    
    NSString* mlgdMinorLow=nil;
    NSString* mlgdMinorHigh=nil;
    
    NSString* mlgdMajorLow1=nil;
    NSString* mlgdMajorHigh1=nil;
    
    NSString* mlgdMinorLow1=nil;
    NSString* mlgdMinorHigh1=nil;
    
    NSString *strResultForUIinfo =nil;
	enum TestResutStatus enumResult ;
    
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"ReferenceBufferNameMajor"])
		{
			mReferenceBufferNameMajor = [dictKeyDefined objectForKey:strKey] ;
		}
        if ([strKey isEqualToString:@"ReferenceBufferNameMinor"])
		{
			mReferenceBufferNameMinor = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"sdcMajorLow"])
		{
			msdcMajorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"sdcMajorHigh"])
		{
			msdcMajorHigh = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"sdcMinorLow"])
		{
			msdcMinorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"sdcMinorHigh"])
		{
			msdcMinorHigh = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"gisMajorLow"])
		{
			mgisMajorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"gisMajorHigh"])
		{
			mgisMajorHigh = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"gisMinorLow"])
		{
			mgisMinorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"gisMinorHigh"])
		{
			mgisMinorHigh = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"lgdMajorLow"])
		{
			mlgdMajorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMajorHigh"])
		{
			mlgdMajorHigh = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMinorLow"])
		{
			mlgdMinorLow = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMinorHigh"])
		{
			mlgdMinorHigh = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"lgdMajorLow1"])
		{
			mlgdMajorLow1 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMajorHigh1"])
		{
			mlgdMajorHigh1 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMinorLow1"])
		{
			mlgdMinorLow1 = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"lgdMinorHigh1"])
		{
			mlgdMinorHigh1 = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"ReferenceBufferName can't be nil"];
		return;
	}
    
    NSString *strReferenceValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName]; //Get ADR value
    
    strReferenceValue = [strReferenceValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    strReferenceValue = [strReferenceValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    strReferenceValue = [strReferenceValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    NSString* strMajor=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameMajor];
    NSString* strMinor=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameMinor];
    
    
    int major=0,minor=0;
    if (strMajor==nil || strMinor==nil) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:@"ReferenceBufferName can't be nil"];
        return;
    }
    else
    {
        major=strtol([strMajor UTF8String], NULL, 16);
        minor=strtol([strMinor UTF8String], NULL, 16);
    }
    
    
    strResultForUIinfo=[NSString stringWithFormat:@"%d,%d",major,minor];
    if ([strReferenceValue rangeOfString:@"0x61"].length>0)//SDC
    {
        
        strResultForUIinfo=[strResultForUIinfo stringByAppendingString:@" SDC"];
        if ( ([msdcMajorLow intValue]<=major) && (major <=[msdcMajorHigh intValue]) ) {
            if (([msdcMinorLow intValue]<=minor) && (minor <=[msdcMinorHigh intValue]) ) {
                
                [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:strResultForUIinfo];
                return;
            }
            else
            {
                
                [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:strResultForUIinfo];
                return;

            }
            
        }
        else
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:strResultForUIinfo];
            return;
        }
        
    }
    else if([strReferenceValue rangeOfString:@"0x62"].length>0)//LGD
    {
        strResultForUIinfo=[strResultForUIinfo stringByAppendingString:@" LGD"];
        if ( ([mlgdMajorLow intValue]<=major && major <=[mlgdMajorHigh intValue]&&
              [mlgdMinorLow intValue]<=minor && minor <=[mlgdMinorHigh intValue]) ||
            ([mlgdMajorLow1 intValue]<=major && major <=[mlgdMajorHigh1 intValue]&&
             [mlgdMinorLow1 intValue]<=minor && minor <=[mlgdMinorHigh1 intValue]))
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:strResultForUIinfo];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:strResultForUIinfo];
            return;
        }
    }
    else if([strReferenceValue rangeOfString:@"0x64"].length>0)//Sharp
    {
        strResultForUIinfo=[strResultForUIinfo stringByAppendingString:@" Sharp"];
        if ( ([mgisMajorLow intValue]<=major) && (major <=[mgisMajorHigh intValue]) ) {
            if (([mgisMinorLow intValue]<=minor) && (minor <=[mgisMinorHigh intValue]) ) {
                
                [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_PASS:strResultForUIinfo];
                return;
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:strResultForUIinfo];
                return;
            }
        }
        else
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_FAIL:strResultForUIinfo];
            return;
        }
    }
    else
    {
        strResultForUIinfo=@"Unrecongnse vendor ";
        enumResult=RESULT_FOR_FAIL;
        [TestItemParse SetResultAndUIInfo:dictKeyDefined:enumResult:strResultForUIinfo];
    }
    
}
@end
