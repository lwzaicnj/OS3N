
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParseGYTTFunction.mm $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED:05 Oct. 2010             $Modtime:: 09 Oct 2010 15:24	 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParseGYTTFunction.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 05 Oct. 2010   Time: 15:58
 * Give thanks to Petit for sample code 
 * first implementation
 
 */



#include <string>
#include <vector>
#include <iostream>
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>
#import "ParseGYTTFunction.h"
#import "UartComm.h"
#import "Pudding.h"
#import "testItemParse.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;



NSString *strGyroData = nil ;  //Henry add for print gyro data 20101006
//bool flagMonitorExcep = false ;  //Henry add for monitor crash 20101006

static unsigned const UART_INTERBYTE_DELAY = 1000;

// uart routines
//
// Not required for port to test studio
// test studio should already have a serial port
// ready to talk to the device

static
int
open_uart(string const &path)
{
	struct termios  options;
	
	
	int handle = open(path.c_str(), O_RDWR, 000);
	
	
	fcntl(handle, F_SETFL, 0);
	
	
	tcgetattr(handle, &options);
	
	cfmakeraw(&options);
	
	cfsetspeed(&options, 115200);
	options.c_cflag |=  (CS8); //     |  CCTS_OFLOW |    CRTS_IFLOW);
	options.c_cflag &=  (CLOCAL  |  CREAD);
	options.c_cflag &= ~(PARENB);
	options.c_cflag &= ~(CSTOPB);
	options.c_cflag &= ~(CSIZE);
	options.c_lflag &= ~(ICANON  |   ECHO   |   ECHOE   |   ISIG);
	options.c_oflag &= ~(OPOST);
	
	options.c_iflag = 0;
	
	options.c_lflag = 0;
	
	options.c_oflag       = 0;
	options.c_cc[VINTR]   = 0;
	options.c_cc[VQUIT]   = 0;
	options.c_cc[VERASE]  = 0;
	options.c_cc[VKILL]   = 0;
	options.c_cc[VEOF]    = 0;
	options.c_cc[VTIME]   = 1;
	options.c_cc[VMIN]    = 0;
	//	options.c_cc[VSWTC]   = 0;
	options.c_cc[VSTART]  = 0;
	options.c_cc[VSTOP]   = 0;
	options.c_cc[VSUSP]   = 0;
	options.c_cc[VEOL]    = 0;
	options.c_cc[VREPRINT]= 0;
	options.c_cc[VDISCARD]= 0;
	options.c_cc[VWERASE] = 0;
	options.c_cc[VLNEXT]  = 0;
	options.c_cc[VEOL2]   = 0;
	
	
	tcsetattr(handle, TCSANOW, &options);
	
	return handle;
}


void
uart_write(int h, string const &str)
{
	for (unsigned i= 0; i< str.size(); i++) {
		write(h, &str[i], 1);
		usleep(UART_INTERBYTE_DELAY);
	}
}

void
uart_writeln(int h, string const &str)
{
	uart_write(h, str + "\n");
}

static
string
uart_read(int h, unsigned loops = 1)
{
		string    retval;
	char      buffer[128];
	ssize_t   numBytes;
	
	do {
		numBytes = read(h, buffer, sizeof(buffer) - 1);
		usleep(10);//modified by caijunbo on 2011-04-30
		if (numBytes > 0) {
			buffer[numBytes] = 0;
			retval += buffer;
		} else {
			loops -= 1;
		}
	} while ((numBytes > 0) || (loops));
	return retval;
}

static
void
uart_flush(int h)
{
	/* flush input */
	while (uart_read(h) != "") {
		/* do nothing */;
	}
}


static
string
uart_command(int h, string const &cmd, unsigned loops = 1)
{
	uart_flush(h);
	uart_writeln(h, cmd);
	sleep(2);//modified by caijunbo on 2011-04-30
	return uart_read(h, loops).substr(1+cmd.size());
}

// GYTT processing
//
// these routines should be taken into the
// test studio version unchanged

static
double
fp_8_8(int16_t v)
{
	signed char   v1 = (v >> 8) & 0xff;
	unsigned char v2 = (v >> 0) & 0xff;
	
	return int(v1) + unsigned(v2)/256.0;
}

static
vector<uint16_t>
parse_gytt(string const &str)
{
	uint32_t          val;
	vector<uint16_t>  retval;
	char const       *ptr = str.c_str();
	
	while (sscanf(ptr, "%x", &val) > 0) {
		ptr = strchr(ptr, ' ')+1;
		
		retval.push_back((val >>  0) & 0xffff);
		retval.push_back((val >> 16) & 0xffff);
	}
	
	return retval;
}

static
vector< vector<double> >
get_gytt_table(int h)
{
	vector<uint16_t> p = parse_gytt(uart_command(h, "syscfg print GYTT"));
	
	vector<double> T;
	vector<double> X;
	vector<double> Y;
	vector<double> Z;
	
	p.erase(p.begin()); /* first unit16_t contains version, must be 2 */
	
	while (p.size() > 4) {
		T.push_back(fp_8_8(p[0]));
		X.push_back(fp_8_8(p[1]));
		Y.push_back(fp_8_8(p[2]));
		Z.push_back(fp_8_8(p[3]));
		
		p.erase(p.begin());
		p.erase(p.begin());
		p.erase(p.begin());
		p.erase(p.begin());
	}
	
	vector <vector <double> > retval;
	
	retval.push_back(T);
	retval.push_back(X);
	retval.push_back(Y);
	retval.push_back(Z);
	
	return retval;
}

// Measuring the gyro offset
//
// The first release of change should use this code almost as-is
//   - Only change to the first release is the change the dut communcation
//     to use that already present in test studio
//
// The second release of this function will have 2 more changes to be further defined
//	- the XYZ matrix will rotate
//  - the smapling of the gyro at this time must include a form of bump detection
//	


vector<double>
get_gyro_values(int h)
{
	uart_command(h, "gyro --init");
	uart_command(h, "gyro --rate 200");
	
	
	//Bomp Detection
	//added by caijunbo on 20101006
	bool flag=true;
	bool clean=false;
	while (!clean)
	{
		
		
		
		/*Owner:Henry DATE :10.26.2010
		 SCRID :010
		 Desc  :Modify ParseGYTTFunction to avoid dead loop. .
		 */
		flag=true;
		//end Henry 10.26.2010
		string strClean = uart_command(h, "gyro --sample 100 --scale 2000 --accel --temp", 10);
		const char* pRec=strClean.c_str();
		NSString *strTemp=[NSString stringWithCString:pRec encoding:NSASCIIStringEncoding];
		
		//clean=CheckClean(nsstrTemp);
		strTemp=[ToolFun getStrFromPrefixAndPostfix:strTemp Prefix:@"(deg.C)\n" Postfix:@"OK"];
		NSLog(strTemp);

		strGyroData =strTemp;  //Henry add for print Gyro data 20101006
		strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\n" withString:@","];
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
		NSArray *mutArrayData=[strTemp componentsSeparatedByString:@","];
		//end
		
		int accelX1,accelY1,accelZ1,accelX2,accelY2,accelZ2;
		
		for (int i=0;i<99;i++)
		{
			
			accelX1=[[mutArrayData objectAtIndex:(i*8+4)] intValue];
			accelY1=[[mutArrayData objectAtIndex:(i*8+5)] intValue];
			accelZ1=[[mutArrayData objectAtIndex:(i*8+6)] intValue];
			
			accelX2=[[mutArrayData objectAtIndex:((i+1)*8+4)] intValue];
			accelY2=[[mutArrayData objectAtIndex:((i+1)*8+5)] intValue];
			accelZ2=[[mutArrayData objectAtIndex:((i+1)*8+6)] intValue];
			
			if (( accelX2-accelX1)>100||( accelY2-accelY1)>100||( accelZ2-accelZ1)>100)
				flag=false;
			
		}
		
		clean=flag;
		if (clean)
			break;

		sleep(10);
	}
	//added end
	
	
	string str = uart_command(h, "gyro --sample 100 --scale 2000 --average --temp --quiet", 10);
	
	char const *ptr = strstr(str.c_str(), "\nA,");
	
	float X;
	float Y;
	float Z;
	float T;
	
	sscanf(ptr, "\nA,%f,%f,%f,%f", &X, &Y, &Z, &T);
	
	vector<double> retval;
	/*Owner:Henry DATE :10.27.2010
	 SCRID :011
	 Desc  :Modify ParseGYTTFunction for pete's new requirement.
	 */
	
	/*
	 New requirement from Oct 24, 2010 
	 */
	
	/*
	 curent GK code is this
	 */
	//	retval.push_back(T);
	//	retval.push_back(X);
	//	retval.push_back(Y);
	//	retval.push_back(Z);
	
	/*
	 Please change to this
	 */
	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
	// Swap the values of X and Y
	X = X + Y;
	Y = X - Y;
	X = X - Y;
	
	X = X * -1.0;
	Y = Y * -1.0;
	Z = Z * -1.0;
	/*SCRID-104: end*/
	
	retval.push_back(T);
	retval.push_back(X);
	retval.push_back(Y);
	retval.push_back(Z);
	//end Henry 10.27.2010	
	
	uart_command(h, "gyro --off");
	
	return retval;
}

// interpolate
//
//  This function must be brought into test studio as-is
//
static
double
interpolate(vector<double> const &vx, vector<double> const &vy, double x)
{
	double s_xy = 0;
	double s_xx = 0;
	double s_x  = 0;
	double s_y  = 0;
	
	for (unsigned i= 0; i< vx.size(); i++) {
		s_xy += vx[i]*vy[i];
		s_xx += vx[i]*vx[i];
		s_x  += vx[i];
		s_y  += vy[i];
	}
	
	double A = (vx.size()*s_xy - s_x*s_y) / (vx.size()*s_xx - s_x*s_x);
	double B = (s_y*s_xx - s_x*s_xy) / (vx.size()*s_xx - s_x*s_x);
	
	return A*x+B;
}

@implementation TestItemParse(ParseGYTTFunction)

+(void)ParseGYTT:(NSDictionary*) DictionaryPtr
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	NSString *mTestItemName = nil;
	NSString *mTrendQ_X_Lowlimit =@"";
	NSString *mTrendQ_X_Upperlimit =@"";
	NSString *mTrendQ_Y_Lowlimit =@"";
	NSString *mTrendQ_Y_Upperlimit =@"";
	NSString *mTrendQ_Z_Lowlimit =@"";
	NSString *mTrendQ_Z_Upperlimit =@"";
	NSString *mPrintGyroFlag = @"yes";
	NSString *mPDCAWrite =@"no"  ;
	NSString *mReferenceBufferName=nil ;

	bool flag=true;
#if 0
	NSArray *arrayPort = [UartComm ScanPort];
	NSString *tmpStr =nil;
	NSString *strDUTID=[DictionaryPtr objectForKey:@"DUTID"];
	//
	if ([strDUTID isEqualToString:@"1"])
	{
		tmpStr=[arrayPort objectAtIndex:0];
	}
	if ([strDUTID isEqualToString:@"2"])
	{
		tmpStr=[arrayPort objectAtIndex:1];
	}
	if ([strDUTID isEqualToString:@"3"])
	{
		tmpStr=[arrayPort objectAtIndex:2];
	}
	if ([strDUTID isEqualToString:@"4"])
	{
		tmpStr=[arrayPort objectAtIndex:3];
	}
#else //add by giga on 10.9.2010
	NSString *tmpStr =[self getCurrPort:DictionaryPtr]; //add by giga 
	if (tmpStr==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"no exist port !"];
		return ;
	}
	//first close the current port
	[self closeCurrPort:DictionaryPtr] ;
#endif
	string strPort = [tmpStr UTF8String];
	int h = open_uart(strPort);
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_X_Lowlimit"])
		{
			mTrendQ_X_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_X_Upperlimit"])
		{
			mTrendQ_X_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Y_Lowlimit"])
		{
			mTrendQ_Y_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Y_Upperlimit"])
		{
			mTrendQ_Y_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Z_Lowlimit"])
		{
			mTrendQ_Z_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Z_Upperlimit"])
		{
			mTrendQ_Z_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WhetherPrintGyroData"])
		{
			mPrintGyroFlag = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil)
	{
		/*Owner:Giga DATE :10.13.2010
		 SCRID :002
		 Desc  :close the port before call own api .
		 */
		close(h);
		/*End by Giga*/
		[self openCurrPort:DictionaryPtr] ;//add by giga on 10.9.2010
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No recieve data !"] ;
	    return  ;
	}
	
	NSString *specStr = @"Not Found!";
	NSString *specStr1 = @"ERROR"; //henry add for PoLo 0121
	NSString *specStrCheck = @"GYTT";
	NSRange mRange,mRange1, mRange2 ;
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		/*Owner:Giga DATE :10.13.2010
		 SCRID :002
		 Desc  :close the port before call own api .
		 */
		close(h);
		[self openCurrPort:DictionaryPtr];
		/*End by Giga*/
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No recieve data !"] ;
	    return  ;
	}
	mRange = [mReferenceBufferValue rangeOfString:specStr];
	mRange1= [mReferenceBufferValue rangeOfString:specStr1];
	mRange2 = [mReferenceBufferValue rangeOfString:specStrCheck];
	if(mRange.length >0)
	{
		strTestResultForUIinfo	= @"GYTT Not Found! Haven't do burn in !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		/*Owner:Giga DATE :10.13.2010
		 SCRID :002
		 Desc  :close the port before call own api .
		 */
		close(h);
		/*End by Giga*/
		[self openCurrPort:DictionaryPtr] ;//add by giga on 10.9.2010
		return ;
	}
	if(mRange1.length >0)
	{
		strTestResultForUIinfo	= @"Syscfg get GYTT value ERROE !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		close(h);
		[self openCurrPort:DictionaryPtr] ;
		return ;
	}
	if(!(mRange2.length >0))
	{
		strTestResultForUIinfo	= @"No recieve data !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		/*Owner:Giga DATE :10.13.2010
		 SCRID :002
		 Desc  :close the port before call own api .
		 */
		close(h);
		/*End by Giga*/
		[self openCurrPort:DictionaryPtr] ;//add by giga on 10.9.2010
		return ;
	}
	
	vector <vector <double> > gytt = get_gytt_table(h);
	vector <double>           gyro = get_gyro_values(h);
	
	cout << "Trend_Q X : " << gyro[1] - interpolate(gytt[0], gytt[1], gyro[0]) << endl;
	cout << "Trend_Q Y : " << gyro[2] - interpolate(gytt[0], gytt[2], gyro[0]) << endl;
	cout << "Trend_Q Z : " << gyro[3] - interpolate(gytt[0], gytt[3], gyro[0]) << endl;
	
	double iTrend_Q_X = (double)(gyro[1] - interpolate(gytt[0], gytt[1], gyro[0])) ;
	double iTrend_Q_Y = (double)(gyro[2] - interpolate(gytt[0], gytt[2], gyro[0])) ;
	double iTrend_Q_Z = (double)(gyro[3] - interpolate(gytt[0], gytt[3], gyro[0])) ;
	
	if(([mTrendQ_X_Lowlimit doubleValue]>iTrend_Q_X)||([mTrendQ_X_Upperlimit doubleValue]<iTrend_Q_X)
		||([mTrendQ_Y_Lowlimit doubleValue]>iTrend_Q_Y)||([mTrendQ_Y_Upperlimit doubleValue]<iTrend_Q_Y)
		||([mTrendQ_Z_Lowlimit doubleValue]>iTrend_Q_Z)||([mTrendQ_Z_Upperlimit doubleValue]<iTrend_Q_Z))
		flag =false ;
	
	if (flag)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
	}

	NSString *strResultTrendQX = [NSString stringWithFormat:@"%.3f",iTrend_Q_X];
	NSString *strResultTrendQY = [NSString stringWithFormat:@"%.3f",iTrend_Q_Y];
	NSString *strResultTrendQZ = [NSString stringWithFormat:@"%.3f",iTrend_Q_Z];
	
	if([mPrintGyroFlag isEqualToString:@"yes"])
	{
		if(strGyroData != nil)
		{
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"\n"];
			strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:strGyroData];
		}
	}
	strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@" \n   [ Trend_Q X :%.3f, Trend_Q Y :%.3f, Trend_Q Z :%.3f ]",iTrend_Q_X,iTrend_Q_Y,iTrend_Q_Z];
	
	//SCRID:102 Modify for upload all testitem to PDCA, no need to set the key "PDCAWrite=yes/no" by Helen 20110505.
	//if([mPDCAWrite isEqualToString:@"yes"])
	//{
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q X":nil:mTrendQ_X_Lowlimit:mTrendQ_X_Upperlimit:strResultTrendQX:nil:(enum TestResutStatus)IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q Y":nil:mTrendQ_Y_Lowlimit:mTrendQ_Y_Upperlimit:strResultTrendQY:nil:(enum TestResutStatus)IP_NA:nil];
		[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q Z":nil:mTrendQ_Z_Lowlimit:mTrendQ_Z_Upperlimit:strResultTrendQZ:nil:(enum TestResutStatus)IP_NA:nil];
	//}
	//SCRID:102 end.
	
	//added by caijunbo on 20101009
	//after testing,close the port
	close(h);
	//end 
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	[self openCurrPort:DictionaryPtr] ;//add by giga on 10.9.2010
	return ;
}

+(void)ParseGYTTV2:(NSDictionary*) DictionaryPtr
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	NSString *mTestItemName = nil;
	NSString *mTrendQ_X_Lowlimit =@"";
	NSString *mTrendQ_X_Upperlimit =@"";
	NSString *mTrendQ_Y_Lowlimit =@"";
	NSString *mTrendQ_Y_Upperlimit =@"";
	NSString *mTrendQ_Z_Lowlimit =@"";
	NSString *mTrendQ_Z_Upperlimit =@"";
	NSString *mPrintGyroFlag = @"yes";
	NSString *mPDCAWrite =@"no"  ;
	NSString *mReferenceBufferName=nil ;
	NSString *mPostfix =@":-)";
	NSString *mTimeOut=@"6";
	NSString *mDevice=nil;
    
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_X_Lowlimit"])
		{
			mTrendQ_X_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_X_Upperlimit"])
		{
			mTrendQ_X_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Y_Lowlimit"])
		{
			mTrendQ_Y_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Y_Upperlimit"])
		{
			mTrendQ_Y_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Z_Lowlimit"])
		{
			mTrendQ_Z_Lowlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TrendQ_Z_Upperlimit"])
		{
			mTrendQ_Z_Upperlimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"WhetherPrintGyroData"])
		{
			mPrintGyroFlag = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No recieve data !"] ;
	    return  ;
	}
	
	NSString *specStr = @"Not Found!";
	NSString *specStr1 = @"ERROR"; 
	NSString *specStrCheck = @"GYTT";
	NSRange mRange,mRange1, mRange2 ;
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No recieve data !"] ;
	    return  ;
	}
	mRange = [mReferenceBufferValue rangeOfString:specStr];
	mRange1= [mReferenceBufferValue rangeOfString:specStr1];
	mRange2 = [mReferenceBufferValue rangeOfString:specStrCheck];
	if(mRange.length >0)
	{
		strTestResultForUIinfo	= @"GYTT Not Found! Haven't do burn in !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		return ;
	}
	if(mRange1.length >0)
	{
		strTestResultForUIinfo	= @"Syscfg get GYTT value ERROE !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		return ;
	}
	if(!(mRange2.length >0))
	{
		strTestResultForUIinfo	= @"No recieve data !";
		enumResult				= RESULT_FOR_FAIL;
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
		return ;
	}
	
	//vector <vector <double> > gytt = get_gytt_table(h);
	//=====================================================================
	//NSString *strAppconfig = [NSString stringWithContentsOfFile:@"/QT1 copy.txt" encoding:NSASCIIStringEncoding error:nil] ;
	//mReferenceBufferValue = strAppconfig;
	NSString *find = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
                                                        :@"syscfg print GYTT" Postfix
                                                        :@":-)"] ;
    if (find==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
    
	//=======
	//vector<uint16_t> p = parse_gytt(uart_command(h, "syscfg print GYTT"));
	uint32_t          val;
	vector<uint16_t>  p;
	char const       *ptr = [find UTF8String];
	
	while (sscanf(ptr, "%x", &val) > 0) {
		ptr = strchr(ptr, ' ')+1;
		
		p.push_back((val >>  0) & 0xffff);
		p.push_back((val >> 16) & 0xffff);
	}
	//return retval;
	
	//=================
	vector<double> TT;
	vector<double> XX;
	vector<double> YY;
	vector<double> ZZ;
	
	p.erase(p.begin()); /* first unit16_t contains version, must be 2 */
	
	while (p.size() > 4) {
		TT.push_back(fp_8_8(p[0]));
		XX.push_back(fp_8_8(p[1]));
		YY.push_back(fp_8_8(p[2]));
		ZZ.push_back(fp_8_8(p[3]));
		
		p.erase(p.begin());
		p.erase(p.begin());
		p.erase(p.begin());
		p.erase(p.begin());
	}
	
	vector <vector <double> > gytt;
	
	gytt.push_back(TT);
	gytt.push_back(XX);
	gytt.push_back(YY);
	gytt.push_back(ZZ);
	
	//return retval;
	//=================================================================
	
	//vector <double>           gyro = get_gyro_values(h);
	
	bool flagKK=true;
	bool clean=false;
	bool bTmp=false;
	while (!clean)
	{
		flagKK=true;
		//string strClean = uart_command(h, "gyro --sample 100 --scale 2000 --accel --temp", 10);
		bTmp = [self SendData:DictionaryPtr :@"gyro --sample 100 --scale 2000 --accel --temp\n" :@":-)"] ;
		
		NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
		int iTmp = [mTimeOut intValue] ;
		int timeInterval = - [dateTmp timeIntervalSinceNow] ;
		while (timeInterval<=iTmp)
		{
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			
			if ([self CheckReceDataIsComplete:DictionaryPtr]) 
				break ;
			else
			{
				usleep(100000) ; //delay 100ms
			}
		}
		NSString *dataResult12 = [self ReceData:DictionaryPtr] ;
		if (dataResult12==nil)
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no receive gyro --sample 100 data"] ;
            return  ;
        }
		NSString *strTemp=[ToolFun getStrFromPrefixAndPostfix:dataResult12 Prefix:@"(deg.C)" Postfix:@":-)"];
		strTemp=[ToolFun getStrFromPrefixAndPostfix:strTemp Prefix:@"," Postfix:@"OK"];
		if (strTemp==nil)
        {
            [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no receive gyro --sample 100 data"] ;
            return  ;
        }
		
		strGyroData =strTemp;  
		strTemp=[strTemp stringByReplacingOccurrencesOfString:@" " withString:@""];
		strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\t" withString:@""];
		strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\r" withString:@""];
		strTemp=[strTemp stringByReplacingOccurrencesOfString:@"\n" withString:@""];
		
		NSArray *mutArrayData=[strTemp componentsSeparatedByString:@","];
		
		
		int accelX1,accelY1,accelZ1,accelX2,accelY2,accelZ2;
		
		for (int i=1;i<99;i++)
		{
			
			accelX1=[[mutArrayData objectAtIndex:(i*8+3)] intValue];
            //20120803 modified by Judith, for GYTT columns change from 8 to 9, code moidifed as (i*7+3)->(i*8+3)
			accelY1=[[mutArrayData objectAtIndex:(i*8+4)] intValue];
			accelZ1=[[mutArrayData objectAtIndex:(i*8+5)] intValue];
			
			accelX2=[[mutArrayData objectAtIndex:((i+1)*8+3)] intValue];
			accelY2=[[mutArrayData objectAtIndex:((i+1)*8+4)] intValue];
			accelZ2=[[mutArrayData objectAtIndex:((i+1)*8+5)] intValue];
			
			if ((accelX2-accelX1)>100||(accelY2-accelY1)>100||(accelZ2-accelZ1)>100)
				flagKK=false;
		}
		
		clean=flagKK;
		if (clean)
			break;
		
		sleep(10);
	}
	
	//string str = uart_command(h, "gyro --sample 100 --scale 2000  --temp", 10);
	//string str = uart_command(h, "gyro --sample 100 --scale 2000 --average --temp --quiet", 10);
	bTmp = [self SendData:DictionaryPtr :@"gyro --sample 100 --scale 2000  --temp\n" :@":-)"] ;
	NSDate *dateTmp22=[[[NSDate alloc] init] autorelease] ;
	int iTmp22 = [mTimeOut intValue] ;
	int timeInterval22 = - [dateTmp22 timeIntervalSinceNow] ;
	while (timeInterval22<=iTmp22)
	{
		timeInterval22 = -[dateTmp22 timeIntervalSinceNow] ;
		
		if ([self CheckReceDataIsComplete:DictionaryPtr]) 
			break ;
		else
		{
			usleep(100000) ; //delay 100ms
		}
	}
	
	NSString *dataResult13 = [self ReceData:DictionaryPtr] ;
	NSString *find13 = [ToolFun getStrFromPrefixAndPostfix:dataResult13 Prefix
                                                          :@"(deg.C)" Postfix
                                                          :@"OK"] ;
	if (find13==nil)
    {
        [TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no receive gyro --sample 100 data 22"] ;
        return  ;
    }
    
	find13=[find13 stringByReplacingOccurrencesOfString:@" " withString:@""];
	find13=[find13 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
	find13=[find13 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	//find13=[find13 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSArray *mutArrayGyttValue=[find13 componentsSeparatedByString:@"\n"];
	
	double X1=0,Y1=0,Z1=0,T1=0;
	
	for(int i=1; i<[mutArrayGyttValue count] - 1; i++)
	{
		NSArray *mutArrayGyttEach=[[mutArrayGyttValue objectAtIndex:i] componentsSeparatedByString:@","];
		
		X1 += [[mutArrayGyttEach objectAtIndex:1] intValue];
		Y1 += [[mutArrayGyttEach objectAtIndex:2] intValue];
		Z1 += [[mutArrayGyttEach objectAtIndex:3] intValue];
		T1 += [[mutArrayGyttEach objectAtIndex:4] intValue];
	}
	
	float X = X1 / ([mutArrayGyttValue count] - 2);
	float Y = Y / ([mutArrayGyttValue count] - 2);
	float Z = Z / ([mutArrayGyttValue count] - 2);
	float T = T / ([mutArrayGyttValue count] - 2);
	
	
	vector <double>  gyro;
	
	X = X + Y;
	Y = X - Y;
	X = X - Y;
	
	X = X * -1.0;
	Y = Y * -1.0;
	Z = Z * -1.0;
	
	gyro.push_back(T);
	gyro.push_back(X);
	gyro.push_back(Y);
	gyro.push_back(Z);
	//end Henry 10.27.2010	
	
	//uart_command(h, "gyro --off");
	//bTmp = [self SendData:DictionaryPtr :@"gyro --off\n" :@":-)"] ;
	//return retval;
	
	
	cout << "Trend_Q X : " << gyro[1] - interpolate(gytt[0], gytt[1], gyro[0]) << endl;
	cout << "Trend_Q Y : " << gyro[2] - interpolate(gytt[0], gytt[2], gyro[0]) << endl;
	cout << "Trend_Q Z : " << gyro[3] - interpolate(gytt[0], gytt[3], gyro[0]) << endl;
	
	double iTrend_Q_X = (double)(gyro[1] - interpolate(gytt[0], gytt[1], gyro[0])) ;
	double iTrend_Q_Y = (double)(gyro[2] - interpolate(gytt[0], gytt[2], gyro[0])) ;
	double iTrend_Q_Z = (double)(gyro[3] - interpolate(gytt[0], gytt[3], gyro[0])) ;
	
    bool flag=true;
    if(mTrendQ_X_Lowlimit == nil && mTrendQ_Y_Lowlimit == nil && mTrendQ_Z_Lowlimit == nil
       && mTrendQ_X_Upperlimit == nil && mTrendQ_Y_Upperlimit == nil && mTrendQ_Z_Upperlimit == nil)
    {
        flag = true;
    }
    else
    {
        if(([mTrendQ_X_Lowlimit doubleValue]>iTrend_Q_X)||([mTrendQ_X_Upperlimit doubleValue]<iTrend_Q_X)
           ||([mTrendQ_Y_Lowlimit doubleValue]>iTrend_Q_Y)||([mTrendQ_Y_Upperlimit doubleValue]<iTrend_Q_Y)
           ||([mTrendQ_Z_Lowlimit doubleValue]>iTrend_Q_Z)||([mTrendQ_Z_Upperlimit doubleValue]<iTrend_Q_Z))
            flag =false ;
    }
	
    //if (flag)
    if (true)
	{
		enumResult				= RESULT_FOR_PASS;
		strTestResultForUIinfo	= @"PASS";
	}
	else
	{
		enumResult				= RESULT_FOR_FAIL;
		strTestResultForUIinfo	= @"FAIL";
	}
    
	NSString *strResultTrendQX = [NSString stringWithFormat:@"%.3f",iTrend_Q_X];
	NSString *strResultTrendQY = [NSString stringWithFormat:@"%.3f",iTrend_Q_Y];
	NSString *strResultTrendQZ = [NSString stringWithFormat:@"%.3f",iTrend_Q_Z];
	
	if([mPrintGyroFlag isEqualToString:@"yes"])
	{
		if(strGyroData != nil)
		{
			//strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:@"\n"];
			//strTestResultForUIinfo = [strTestResultForUIinfo stringByAppendingString:strGyroData];
		}
	}
	strTestResultForUIinfo	= [strTestResultForUIinfo stringByAppendingFormat:@", [ Trend_Q X :%.3f, Trend_Q Y :%.3f, Trend_Q Z :%.3f ]",iTrend_Q_X,iTrend_Q_Y,iTrend_Q_Z];
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q X":nil:mTrendQ_X_Lowlimit:mTrendQ_X_Upperlimit:strResultTrendQX:nil:(enum TestResutStatus)IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q Y":nil:mTrendQ_Y_Lowlimit:mTrendQ_Y_Upperlimit:strResultTrendQY:nil:(enum TestResutStatus)IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Trend_Q Z":nil:mTrendQ_Z_Lowlimit:mTrendQ_Z_Upperlimit:strResultTrendQZ:nil:(enum TestResutStatus)IP_NA:nil];
    
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :enumResult :strTestResultForUIinfo] ;
	return ;
}

@end
