//
//  SpecDataParseFun.m
//  qt_simulator
//
//  Created by diags on 3/24/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "SpecDataParseFun.h"

@implementation TestItemParse(SpecDataParseFun)


@end
