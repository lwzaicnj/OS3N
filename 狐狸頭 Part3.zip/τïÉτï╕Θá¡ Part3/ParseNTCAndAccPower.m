
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ParseNTCAndAccPower.h  $|
 | $Author:: Dengshouxiu                 $Revision::  1              $|
 | CREATED: 2010-04-02                  $Modtime:: 2.03.00 15:24    $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 $History:: ParseNTCAndAccPower.h                                              $
 * *****************  Version 1  *****************
 * User: Dengshouxiu          Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "ParseNTCAndAccPower.h"


@implementation TestItemParse(ParseNTCAndAccPower)

+(void)ParseNTCAndAccPower:(NSDictionary*)dictKeyDefined 
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mLowValue=nil      ;// write cmd
	NSString *mUpperValue =nil;
	
	double mDoubleLowValue = 0.0;
	double mDoubleUpperValue = 0.0;
	
    NSString *mPrefix =nil;
	NSString *mPostfix =nil;
	
	NSString *mResultType = @"Int";
	NSString *mReferenceBufferName=nil ;
	
	NSString *mDivision =nil;
	double mDoubleDivision =1;
	double zero =0.000000001;
	
	// add by Evan on 2011-08-01;
	BOOL bUseValueLimit = YES;
	// add end;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Lowlimit"])
		{
			mLowValue = [dictKeyDefined objectForKey:strKey] ;
			mDoubleLowValue = [mLowValue doubleValue];
		}
		else if ([strKey isEqualToString:@"Uplimit"])
		{
			mUpperValue = [dictKeyDefined objectForKey:strKey] ;
			mDoubleUpperValue = [mUpperValue doubleValue];
		}

		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ResultType"])
		{
			mResultType = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Division"])
		{
			mDivision = [dictKeyDefined objectForKey:strKey] ;
			mDoubleDivision =[mDivision doubleValue];
		}
		// add by Evan on 2011-08-01;
		else if ([strKey isEqualToString:@"UseValueLimit"])
			bUseValueLimit = [ [dictKeyDefined objectForKey:strKey] boolValue];
		// add end;
		
	}
	
	// modify by Evan on 2011-08-01;
/*	if (((mLowValue==nil)&&(mUpperValue ==nil)) ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		return  ;
	}
	*/
	if (YES == bUseValueLimit) 
	{
		if (((mLowValue==nil)&&(mUpperValue ==nil)) ||
			mReferenceBufferName==nil
			)
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
			return  ;
		}
	}
	if (nil == mReferenceBufferName)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
		return  ;
	}
	// modify end;
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	//mReferenceBufferValue = @"bat --tem 0xbed:-)";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	if (strFind==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mReferenceBufferValue] ;
	    return  ;
	}
    else
	{
		double value =0.0;
		
		if([mResultType isEqualToString:@"Hex"])
		{
			char* stopEnd;
			int resultValue = (int)strtol([strFind UTF8String], &stopEnd, 16);
					
			//strFind =[NSString stringWithFormat:@"%d",resultValue];
			value = resultValue/mDoubleDivision;
		}	
		else
		{
			value =[strFind doubleValue]/mDoubleDivision;
		}
		strFind =[NSString stringWithFormat:@"%12.2f",value];
		strFind = [ToolFun allTrimFromString:strFind trimStr:@" " leftTrim:YES rightTrim:YES] ;
		
		// modify by Evan on 2011-08-01;
		if (NO == bUseValueLimit)
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = strFind;
			
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
			return ;
		}
		// modify end;
		
		if(((value - mDoubleLowValue)>=zero)&&((value - mDoubleUpperValue)<zero))
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = strFind;
		}
		else
		{
			enumResult =RESULT_FOR_FAIL ;
			//strTestResultForUIinfo = @"Out of Spec";
			strTestResultForUIinfo = strFind;
		}
	}
    
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
	
}
@end
