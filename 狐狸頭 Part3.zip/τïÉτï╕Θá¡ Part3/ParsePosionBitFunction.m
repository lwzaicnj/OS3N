//
//  ParsePosionBitFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParsePosionBitFunction.h"


@implementation TestItemParse(ParsePosionBitFunction)

+(void)ParsePosionBit:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mPrefix				= nil    ;
	NSString *mPostfix				= nil    ;
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil || mPrefix==nil || mPostfix==nil )
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error!"] ;
		return;
	}
	
	NSString *mBufferValue = nil;

	mBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	//mBufferValue = @"a0x1A :-)";
	
	if (mBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
		return;
	}
	
	int icount = [ToolFun numberOfOccurrences:mBufferValue searchStr:mPrefix];
	if (icount==0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"return string from diag error!"] ;
		return;
		
	}
	
	
	NSRange range;
	
	for (int i=1;i<icount;i++)
	{
		
		range			= [mBufferValue rangeOfString:mPrefix];
		mBufferValue	= [mBufferValue substringFromIndex:(range.location+range.length)];
	}
	
	NSString *resultbuf = nil;
	resultbuf			= [ToolFun getStrFromPrefixAndPostfix:mBufferValue Prefix:mPrefix Postfix:mPostfix];
	
	range				= [resultbuf rangeOfString:@"0x"];
	
	// 0701
	if(resultbuf.length <= (range.location + range.length))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Diags response not expect"] ;
		return;
	}
	// end
	resultbuf = [resultbuf substringFromIndex:(range.location+range.length)];
	resultbuf = [resultbuf stringByReplacingOccurrencesOfString:@" " withString:@""];
	resultbuf = [resultbuf substringFromIndex:1];
	
	int iLastBit		= strtol([resultbuf UTF8String],NULL,16);
	
	if ( (iLastBit & 3) == 2)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"FAIL! Poison Bit Detecte"] ;
	
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	
	}

}

@end
