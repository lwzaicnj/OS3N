//
//  scriptParse.m
//  qt_simulator
//
//  Created by diags on 2/22/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "scriptParse.h"
#import "UartComm.h"
#import "UICommon.h"
#import "pubFun.h"

//key define 
NSString* const TSName =@"TestScriptName" ; 
//NSString* const TestItemName =@"TestItemName" ; 
extern NSString* const TestItemName ; 

NSMutableDictionary *mutDictSummary= nil ;
NSMutableDictionary *mutDictLogService =nil ;
NSMutableArray      *mutArrayDeviceService =nil ;
NSMutableArray      *mutArrayTestScript=nil ;
NSMutableArray      *mutArrayDeviceIDList=nil ;

NSMutableDictionary *mutDictHWConfigInfo=nil ;

/* SCRID-60: Record the Debug Log for crash analize. Joko 2011-1-8*/
bool bReLaunchIFTS = true;
NSString* logForCrashFileName = @"";
/* SCRID-60 end */

@implementation ScriptParse
//public function
+(bool)parseAppConfig:(NSString*)strPath 
{
	if (strPath==nil)
		return false ;
	
	NSString *strAppconfig = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
    
    // Paul add by 08132014 : change china “ to english "
    //strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"“" withString:@"\""];
    //strAppconfig = [strAppconfig stringByReplacingOccurrencesOfString:@"”" withString:@"\""];
    // end 08132014
    
	if (strAppconfig==nil)
	{
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"NO Exist file :%@",strPath]] ;
		return false ;
	}
	//clear comment on appconfig .
	strAppconfig = [ToolFun clearCommentFromStr:strAppconfig] ;
	//NSLog(@"%@",strAppconfig) ;
	if (strAppconfig==nil)
		return false ;
	
	NSString *strSummary,*strLogService ,*strDeviceService ;
	strSummary = [ToolFun getStrFromPrefixAndPostfix:strAppconfig Prefix:@"Summary" Postfix:@"LogService"] ;
	strLogService = [ToolFun getStrFromPrefixAndPostfix:strAppconfig Prefix:@"LogService" Postfix:@"DeviceService"] ;
	strDeviceService = [ToolFun getStrFromPrefixAndPostfix:strAppconfig Prefix:@"DeviceService" Postfix:nil] ;
	
	if (strSummary==nil ||
		strLogService==nil ||
		strDeviceService==nil
		)
		return false ;
	//seperation parse each other string 
	if ([self parseSummary:strSummary]==false)
		return false ;
	
	if ([self parseLogService:strLogService]==false)
		return false ;
	
	if ([self parseDeviceService:strDeviceService]==false)
		return false ;
	
	if ([self parseHWConfig:@"/HWconfig.properties"]==false)
		return false ;
	//print nsdictionary
/*
	NSArray *arrTmp=[mutDictSummary allKeys] ;
	for(int i=0 ; i<[arrTmp count] ;i++)
		NSLog(@"\n key= %@ ,value=%@",[arrTmp objectAtIndex:i],[mutDictSummary objectForKey:[arrTmp objectAtIndex:i]]) ;
*/
	
	NSString *strTestScriptPath = [mutDictSummary objectForKey:@"TestScript"] ;
	if (strTestScriptPath==nil)
		return NO ;
	NSRange rangTmp = [strTestScriptPath rangeOfString:@".plist"] ;
	if (rangTmp.length <= 0) //Mean is txt 
		return [self parseTestScript:[NSHomeDirectory()stringByAppendingString:[mutDictSummary objectForKey:@"TestScript"]]] ;
        //return [self parseTestScript:[NSHomeDirectory()stringByAppendingString:@"/Audit.txt"]] ;
	else
    	        return [self parsePlistTestScript:[NSHomeDirectory()stringByAppendingString:[mutDictSummary objectForKey:@"TestScript"]]] ;
}

+(bool)parseTestScript:(NSString*)strPath
{
	if (strPath==nil)
		return false ;
	
	NSString *strTestScript = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
    
    // Paul add by 08132014 : change china “ to english "
    //strTestScript = [strTestScript stringByReplacingOccurrencesOfString:@"“" withString:@"\""];
    //strTestScript = [strTestScript stringByReplacingOccurrencesOfString:@"”" withString:@"\""];
    // end 08132014
    
	if (strTestScript==nil)
		return false ;
	
	//clear comment on appconfig .
	strTestScript = [ToolFun clearCommentFromStr:strTestScript] ;
	//NSLog(@"%@",strTestScript) ;
	if (strTestScript==nil)
		return false ;
	
	NSMutableString *mutStrSource = [[[NSMutableString alloc] initWithString:strTestScript] autorelease];
	if (mutStrSource==nil)
		return false ;
	
	if (mutArrayTestScript!=nil)
	{
		[mutArrayTestScript release] ;
		mutArrayTestScript = nil ;
	} ;
	mutArrayTestScript = [[NSMutableArray alloc] init];
	
	NSString *strTmp = [ToolFun getStrToEndString:mutStrSource EndString:@"}" Option:true] ;
	while (strTmp!=nil)
	{
		NSDictionary *dictTmp = [self genDisctionaryFromStr:strTmp] ;
		if (dictTmp==nil)
			return false ;
		[mutArrayTestScript addObject:dictTmp ] ;
		
		NSRange rangTmp = [mutStrSource rangeOfString:@"}"] ;
		if (rangTmp.length <= 0)
			return false;
		
		NSRange rangClear ;
		rangClear.location = 0 ;
		rangClear.length = rangTmp.location+rangTmp.length ;
		[mutStrSource deleteCharactersInRange:rangClear] ;
		
		strTmp = [ToolFun getStrToEndString:mutStrSource EndString:@"}" Option:true] ;
	}
	
	//print test script
	/*
	int i;
	for(i=0 ;i<[mutArrayTestScript count] ;i++ )
	{
		NSLog(@"\nObject index=%d : member list is :\n",i) ;
		NSDictionary *dictTmp = [mutArrayTestScript objectAtIndex:i] ;
		NSArray *arrayKeys = [dictTmp allKeys];
		int j=0;
		for(j=0;j<[arrayKeys count] ;j++)
			NSLog(@"  %@=%@\n",[arrayKeys objectAtIndex:j],[dictTmp objectForKey:[arrayKeys objectAtIndex:j]]) ;
	}
 */

	return true ;
}

+(bool)parseHWConfig:(NSString*)strPath
{
	
	if (strPath==nil)
		return false ;
	
	NSString *strHWConfig = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (strHWConfig==nil) //no exist the file return true ;
		return true ;
	
	if (mutDictHWConfigInfo!=nil)
	{
		[mutDictHWConfigInfo release] ;
		mutDictHWConfigInfo = nil ;
	} ;
	mutDictHWConfigInfo = [[NSMutableDictionary alloc] init];
	
	NSString *strTmp = [ToolFun getStrToEndString:strHWConfig EndString:@";" Option:false] ;
	while (strTmp!=nil)
	{
		NSRange rangTmp = [strTmp rangeOfString:@"="] ;
		if (rangTmp.length <= 0)
			return false;
		NSString *strKey = [strTmp substringToIndex:rangTmp.location] ;
		//clear \n\r\t ,space 
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\r"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@" "] ;
		
		NSString *strValue = [strTmp substringFromIndex:rangTmp.location+rangTmp.length] ;
		//clear \n\r\t ,space 
		strValue = [ToolFun deleteFromString:strValue trimStr:@"\n"] ;
		strValue = [ToolFun deleteFromString:strValue trimStr:@"\r"] ;
		strValue = [ToolFun deleteFromString:strValue trimStr:@"\t"] ;
		strValue = [ToolFun deleteFromString:strValue trimStr:@" "] ;
		[mutDictHWConfigInfo setObject:strValue forKey:strKey] ;
		
		//clear string
		strHWConfig = [ToolFun deleteToPostfix:strHWConfig EndString:@";" Option:true];
		strTmp = [ToolFun getStrToEndString:strHWConfig EndString:@";" Option:false] ;
		
	}
	
	//print test script
	
	 //NSLog(@"HW Config info is :\n  %@\n",mutDictHWConfigInfo) ;
	
	return true ;
}

+(NSString*)getValueFromSummary:(NSString*)strKey
{
	if (strKey==nil)
		return nil ;
	if (mutDictSummary==nil)
		return nil ;
	return [mutDictSummary objectForKey:strKey] ;
}

+(NSString*)getValueFromHWConfig:(NSString*)strKey
{
	if (strKey==nil)
		return nil ;
	if (mutDictHWConfigInfo==nil)
		return nil ;
	return [mutDictHWConfigInfo objectForKey:strKey] ;	
}

+(NSArray*)getTestItems 
{
	if (mutArrayTestScript==nil)
		return nil ;
	NSMutableArray *mutArrayTmp=[[[NSMutableArray alloc] init] autorelease] ;
	if (mutArrayTmp==nil)
		return nil ;
	for(int i=1 ;i<[mutArrayTestScript count] ;i++)
	{
		NSDictionary *dictTmp=[mutArrayTestScript objectAtIndex:i] ;
		if (dictTmp==nil)
			return nil ;
		NSString *strTestItem = [dictTmp objectForKey:TestItemName] ;
		if (strTestItem!=nil)
			[mutArrayTmp addObject:strTestItem] ;
	}
	
	return mutArrayTmp ;
}

+(NSString*)getUILabel1
{
	if (mutDictSummary==nil ||
		mutArrayTestScript==nil)
		return nil ;
	NSMutableString *mutStringTmp = [[[NSMutableString alloc] init] autorelease] ;
	NSString *strTmp = [mutDictSummary objectForKey:@"ProductionCode"] ;
	if (strTmp==nil)
		return nil ;
	[mutStringTmp appendString:strTmp] ;
	[mutStringTmp appendString:@" "] ;
	strTmp = [mutDictSummary objectForKey:@"TestStation"] ;
	if (strTmp==nil)
		return mutStringTmp ;
	
	[mutStringTmp appendString:strTmp] ;
	[mutStringTmp appendString:@"  V"] ;//version
	
	//dsx 04-27 get sw version from version.txt
	/*
	NSDictionary *dictTmp = [mutArrayTestScript objectAtIndex:0] ;
	if (dictTmp==nil)
		return mutStringTmp ;
	*/
	/*SCRID-97:get the version information from file version.txt but not from test script. joko 2011-04-22*/
	//strTmp = [dictTmp objectForKey:@"Version"] ;
	//strTmp = [NSString stringWithContentsOfFile:@"/version.txt" encoding:NSASCIIStringEncoding error:nil] ;
	/*SCRID-97:end*/
	strTmp = [self getSWVerision];
	//end
	if (strTmp==nil)
		return mutStringTmp ;
	
	[mutStringTmp appendString:strTmp] ;
	
	return mutStringTmp ;
}

+(NSString*)getUILabel2
{
	if (mutDictSummary==nil)
		return nil ;
	NSMutableString *mutStringTmp = [[[NSMutableString alloc] initWithString:@"Test Script location:"] autorelease] ;
	[mutStringTmp appendString:[mutDictSummary objectForKey:@"TestScript"]] ;
	return mutStringTmp ;	
}

+(NSArray*)getDeviceIDList
{
	if (mutArrayDeviceIDList==nil)
		return nil ;
	NSDictionary *dictTmp = [self getDeviceInfo] ;
	if (dictTmp==nil)
		return nil ;
	
	return [dictTmp allKeys];
}

+(bool)parseDeviceParameter //get the device 's parameter
{
	if (mutArrayDeviceService==nil)
		return false ;
	
	if (mutArrayDeviceIDList!=nil)
	{
		[mutArrayDeviceIDList release] ;
		mutArrayDeviceIDList = nil ;
	}
	mutArrayDeviceIDList = [[NSMutableArray alloc] init];
	
	if (mutArrayDeviceIDList==nil)
		return false ;
	
	for (int i=0 ;i<[mutArrayDeviceService count] ;i++)
	{
		NSDictionary *dictTmp = [mutArrayDeviceService objectAtIndex:i] ;
		NSString *strTmp = [[dictTmp allKeys] objectAtIndex:0] ;
		if ([strTmp isEqualToString:@"Name"])
			continue ;
		
		strTmp = [[dictTmp allValues] objectAtIndex:0] ;
		if (strTmp==nil)
			return false ;
		NSArray *arrayTmp = [strTmp componentsSeparatedByString:@","] ;
		if (arrayTmp==nil)
			return false ;
		NSMutableDictionary *mutableDictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		for(int j=0;j<[arrayTmp count] ;j++)
		{
			//NSLog(@"\n %@ \n",[arrayTmp objectAtIndex:j]) ;
			NSString *strTmp = [arrayTmp objectAtIndex:j] ;
			//clear \n\r\t ,space 
			strTmp = [ToolFun deleteFromString:strTmp trimStr:@"\n"] ;
			strTmp = [ToolFun deleteFromString:strTmp trimStr:@"\r"] ;
			strTmp = [ToolFun deleteFromString:strTmp trimStr:@"\t"] ;
			strTmp = [ToolFun deleteFromString:strTmp trimStr:@"\""] ;
			strTmp = [ToolFun deleteFromString:strTmp trimStr:@" "] ;
			if (strTmp==nil)
				return false ;
			
			NSArray *arrayTmp = [strTmp componentsSeparatedByString:@"="] ;
			if (arrayTmp==nil)
				return false ;
			if ([arrayTmp count]<2)
				return false ;
			[mutableDictTmp setObject:[arrayTmp objectAtIndex:1] forKey:[arrayTmp objectAtIndex:0]] ;
		}
		
		[mutArrayDeviceIDList addObject:mutableDictTmp] ;
	}
	
	//check whether have enough devicefile 
	NSArray *arrayDeviceList=[UartComm ScanPort] ;
	if (arrayDeviceList==nil)
		return true ;
	
	int iDeviceCount=0 ;
	if ([arrayDeviceList count]<[mutArrayDeviceIDList count])
		iDeviceCount = [arrayDeviceList count] ;
	else
		iDeviceCount = [mutArrayDeviceIDList count] ;

	//check whether if replace the device file use actual device file
	if (mutDictSummary==nil)
		return false ;
	
	NSString * strAutoTrigger = [mutDictSummary objectForKey:@"AutoTrigger"] ;
	if (strAutoTrigger==nil)
		strAutoTrigger = @"yes" ;
	
	if ([strAutoTrigger boolValue])
	{
		for(int i=0 ;i<iDeviceCount ;i++)
		{
			NSMutableDictionary *mutableDictTmp=[mutArrayDeviceIDList objectAtIndex:i] ;
			if (mutableDictTmp==nil)
				return false ;
			[mutableDictTmp setObject:[arrayDeviceList objectAtIndex:i] forKey:@"DeviceFile"] ;
		}
	} ;
	
	//print list
	/*
	for(int i=0 ;i<[mutArrayDeviceIDList count] ;i++)
	{
		NSLog(@"\n-------------------------------device id is ") ;
		NSDictionary *dictTmp = [mutArrayDeviceIDList objectAtIndex:i] ;
		for(int j=0 ;j<[dictTmp count] ;j++)
		{
			NSLog(@"    %@=%@",[[dictTmp allKeys] objectAtIndex:j] ,[dictTmp objectForKey:[[dictTmp allKeys] objectAtIndex:j]]) ;
		}
	}
	*/	
	return true ;	
}

+(NSDictionary*)getDeviceInfo
{
	if (mutArrayDeviceIDList==nil)
		return nil ;
	NSMutableDictionary *mutDictRtn = [[[NSMutableDictionary alloc] init] autorelease];
	
	for(int i=0 ;i<[mutArrayDeviceIDList count] ;i++)
	{
		NSDictionary *dictTmp = [mutArrayDeviceIDList objectAtIndex:i] ;
		
		//construct the key 
		 NSMutableString *mutableStrTmp=[[[NSMutableString alloc] init] autorelease] ;
		 NSString *strKey = nil ;
		 strKey = [dictTmp objectForKey:@"DeviceType"] ;
		 if (strKey!=nil)
		 [mutableStrTmp appendString:strKey] ;
		 
		 strKey = [dictTmp objectForKey:@"BelongToTester"] ;
		 if (strKey!=nil)
		 [mutableStrTmp appendString:strKey] ;
		 
		 strKey = [dictTmp objectForKey:@"BelongToDUT"] ;
		 if (strKey!=nil)
		     [mutableStrTmp appendString:strKey] ;
		
		 if (mutableStrTmp!=nil)
			 [mutDictRtn setObject:dictTmp forKey:mutableStrTmp] ;
	}
	return mutDictRtn ;
}

+(NSString*)getSWVerision
{
	//dsx 04-27 get sw version from version.txt
	NSString *strTmp = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/version.txt"] encoding:NSASCIIStringEncoding error:nil] ;
	if(strTmp==nil)
		return @"no set version";
	return strTmp;
	/*
	if (mutArrayTestScript==nil)
		return @"no set version" ;
	NSDictionary* dictTmp = [mutArrayTestScript objectAtIndex:0] ;
	if (dictTmp==nil)
		return @"no set version" ;
	NSString *strRetn = [dictTmp objectForKey:@"Version"] ;
	if (strRetn==nil)
		return @"no set version" ;
	else
		return strRetn ;
	 */
}

+(NSString*)getStationID
{
	NSString *strRetn = [self getValueFromSummary:@"TestStation"] ;
	if (strRetn==nil)
		return @"no set StationID" ;
	// 20100908 Henry add fixture ID
	NSString *strFixtureId = [UICommon getFixtureID];
	if(strFixtureId != nil)
	{
		strRetn = [strRetn stringByAppendingString:[UICommon getFixtureID]];
		strRetn = [strRetn stringByAppendingString:@"_"];
	}
	return strRetn ;
}

//inner function
+(bool)parseSummary:(NSString*)strSummary 
{
	if (strSummary==nil)
		return false ;
	
	NSString *strTmp = [ToolFun getStrFromPrefixAndPostfix:strSummary Prefix:@"{" Postfix:@"}"] ;
	if (strTmp==nil)
		return false ;
	
	NSMutableString *mutstrParse = [[[NSMutableString alloc] initWithString:strTmp] autorelease] ;
	NSRange rangPrefix = [mutstrParse rangeOfString:@";"] ;
	
	if (mutDictSummary!=nil)
	{
		[mutDictSummary release] ;
		mutDictSummary = nil ;
	}
	mutDictSummary = [[NSMutableDictionary alloc] init] ;
	
	while (rangPrefix.length > 0) 
	{
		NSString *substrTmp= [mutstrParse substringToIndex:rangPrefix.location] ;
		if (substrTmp==nil)
			return false ;
		//----get key value 
		NSArray* arrayTmp = [substrTmp componentsSeparatedByString:@"="] ;
		if (arrayTmp==nil ||
			[arrayTmp count]<2
			)
			return false ;
		//NSLog(@"\nparse summary  is :%@ , %@ ,  over\n",substrTmp,[substrTmp capitalizedString]) ;
		//save the all key to NSARRAYDICTIONARY .
		
		NSString *strKey=nil ,*strValue=nil ;
		strKey=[arrayTmp objectAtIndex:0] ;
		strKey = [ToolFun deleteFromString :strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ; 
		strKey = [ToolFun allTrimFromString:strKey trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strKey==nil)
			return false ;
		
		strValue = [arrayTmp objectAtIndex:1] ;
		strValue = [ToolFun getStrFromPrefixAndPostfix:strValue Prefix:@"\"" Postfix:@"\""] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strValue==nil)
			return false ;
		
		//write key-value to nsdictionary 
		[mutDictSummary setObject:strValue forKey:strKey] ;
		
		//clear the range string
		NSRange rangDele ;
		rangDele.location =0 ;
		rangDele.length = rangPrefix.location+rangPrefix.length ;
		[mutstrParse deleteCharactersInRange:rangDele] ;
		
		rangPrefix = [mutstrParse rangeOfString:@";"] ;
	}
	
	return true ;
}
+(bool)parseLogService:(NSString*)strLogService 
{
	if (strLogService==nil)
		return false ;
	
	NSString *strTmp = [ToolFun getStrFromPrefixAndPostfix:strLogService Prefix:@"{" Postfix:@"}"] ;
	if (strTmp==nil)
		return false ;
	
	NSMutableString *mutstrParse = [[[NSMutableString alloc] initWithString:strTmp] autorelease] ;
	NSRange rangPrefix = [mutstrParse rangeOfString:@";"] ;
	
	if (mutDictLogService!=nil)
	{
		[mutDictLogService release] ;
		mutDictLogService = nil ;
	}
	mutDictLogService = [[NSMutableDictionary alloc] init] ;
	
	while (rangPrefix.length > 0 ) 
	{
		NSString *substrTmp= [mutstrParse substringToIndex:rangPrefix.location] ;
		if (substrTmp==nil)
			return false ;
		//----get key value 
		NSArray* arrayTmp = [substrTmp componentsSeparatedByString:@"="] ;
		if (arrayTmp==nil ||
			[arrayTmp count]<2
			)
			return false ;
		
		NSString *strKey=nil ,*strValue=nil ;
		strKey=[arrayTmp objectAtIndex:0] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ; 
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\r"] ;
		strKey = [ToolFun allTrimFromString:strKey trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strKey==nil)
			return false ;
		
		strValue = [arrayTmp objectAtIndex:1] ;
		for(int i=2 ;i<[arrayTmp count] ;i++)
		{
			strValue = [strValue stringByAppendingString:@"="] ;
			strValue = [strValue stringByAppendingString:[arrayTmp objectAtIndex:i]] ;
		}	
		
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"\"" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"[" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"]" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strValue==nil)
			return false ;
		
		//write key-value to nsdictionary 
		[mutDictLogService setObject:strValue forKey:strKey] ;
		
		//clear the range string
		NSRange rangDele ;
		rangDele.location =0 ;
		rangDele.length = rangPrefix.location+rangPrefix.length ;
		[mutstrParse deleteCharactersInRange:rangDele] ;
		
		rangPrefix = [mutstrParse rangeOfString:@";"] ;
	}
	
	return true ;
}

+(bool)parseDeviceService:(NSString*)strDeviceService
{
	if (strDeviceService==nil)
		return false ;
	
	NSString *strTmp = [ToolFun getStrFromPrefixAndPostfix:strDeviceService Prefix:@"{" Postfix:@"}"] ;
	if (strTmp==nil)
		return false ;
	
	NSMutableString *mutstrParse = [[[NSMutableString alloc] initWithString:strTmp] autorelease] ;
	NSRange rangPrefix = [mutstrParse rangeOfString:@";"] ;
	
	if (mutArrayDeviceService!=nil)
	{
		[mutArrayDeviceService release] ;
		mutArrayDeviceService = nil ;
	}
	mutArrayDeviceService = [[NSMutableArray alloc] init] ;
	
	while (rangPrefix.length > 0 ) 
	{
		NSString *substrTmp= [mutstrParse substringToIndex:rangPrefix.location] ;
		if (substrTmp==nil)
			return false ;
		//----get key value 
		NSArray* arrayTmp = [substrTmp componentsSeparatedByString:@"="] ;
		if (arrayTmp==nil ||
			[arrayTmp count]<2
			)
			return false ;
		
		NSString *strKey=nil ,*strValue=nil ;
		strKey=[arrayTmp objectAtIndex:0] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\r"] ;
		strKey = [ToolFun allTrimFromString:strKey trimStr:@" " leftTrim:true rightTrim:true] ; 
		if (strKey==nil)
			return false ;
		
		strValue = [arrayTmp objectAtIndex:1] ;
		for(int i=2 ;i<[arrayTmp count] ;i++)
		{
			strValue = [strValue stringByAppendingString:@"="] ;
			strValue = [strValue stringByAppendingString:[arrayTmp objectAtIndex:i]] ;
		}	
		
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"\"" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"[" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"]" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] ; 
		if (strValue==nil)
			return false ;
		
		//write key-value to nsdictionary 
		NSDictionary *dictionaryTmp = [NSDictionary dictionaryWithObject:strValue forKey:strKey] ;
		if (dictionaryTmp==nil)
			return false ;
		[mutArrayDeviceService addObject:dictionaryTmp] ;
		
		//clear the range string
		NSRange rangDele ;
		rangDele.location =0 ;
		rangDele.length = rangPrefix.location+rangPrefix.length ;
		[mutstrParse deleteCharactersInRange:rangDele] ;
		
		rangPrefix = [mutstrParse rangeOfString:@";"] ;
	}	
	return [self parseDeviceParameter] ;
}

+(NSDictionary*)genDisctionaryFromStr:(NSString*)strParameter //format is aaa{.....}
{
	//NSLog(@"\n   %@   \n",strParameter);
	if (strParameter==nil)
		return nil ;
	//NSLog(@"\n  %@ \n",strParameter) ;
	//first to get name string
	NSString *strName = [ToolFun getStrToEndString:strParameter EndString:@"{" Option:false ] ;
	if (strName==nil)
		return nil ;
	NSMutableDictionary* mutDictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
	if (mutDictTmp==nil)
		return nil ;
	//clear comment special handle
	strName = [self DeletePostfixInvisableChar:strName] ;
	strName = [self getVisableStr:strName];
	//-----------------------------------
	strName = [ToolFun allTrimFromString:strName trimStr:@" " leftTrim:true rightTrim:true] ;
	if (strName==nil)
		return nil ;
	
	[mutDictTmp setObject:strName forKey:TSName] ;
	
	NSString *strTmp = [ToolFun getStrFromPrefixAndPostfix:strParameter Prefix:@"{" Postfix:@"}"] ;
	if (strTmp==nil)
		return nil ;
	
	NSMutableString *mutstrParse = [[[NSMutableString alloc] initWithString:strTmp] autorelease] ;
	//NSLog(@"\n   %@   \n",mutstrParse);
	NSRange rangPrefix = [mutstrParse rangeOfString:@";"] ;
	
	
	while (rangPrefix.length > 0 ) 
	{
		NSString *substrTmp= [mutstrParse substringToIndex:rangPrefix.location] ;
		if (substrTmp==nil)
			return nil ;
		//----get key value 
		NSArray* arrayTmp = [substrTmp componentsSeparatedByString:@"="] ;
		if (arrayTmp==nil ||
			[arrayTmp count]<2
			)
			return nil ;
		
		NSString *strKey=nil ,*strValue=nil ;
		strKey=[arrayTmp objectAtIndex:0] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\r"] ;
		strKey = [ToolFun allTrimFromString:strKey trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strKey==nil)
			return nil ;
		
		strValue = [arrayTmp objectAtIndex:1] ;
		for(int i=2 ;i<[arrayTmp count] ;i++)
		{
			strValue = [strValue stringByAppendingString:@"="] ;
			strValue = [strValue stringByAppendingString:[arrayTmp objectAtIndex:i]] ;
		}	
		/*
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"\"" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"[" leftTrim:true rightTrim:true] ;
		strValue = [ToolFun allTrimFromString:strValue trimStr:@"]" leftTrim:true rightTrim:true] ;
		*/
		strValue = [ToolFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] ;
		strValue = [self setHidCharOfScript:strValue] ;
		if (strValue==nil)
			return nil ;
		
		//write key-value to nsdictionary 
		[mutDictTmp setObject:strValue forKey:strKey] ;
		
		//clear the range string
		NSRange rangDele ;
		rangDele.location =0 ;
		rangDele.length = rangPrefix.location+rangPrefix.length ;
		[mutstrParse deleteCharactersInRange:rangDele] ;
		
		rangPrefix = [mutstrParse rangeOfString:@";"] ;
	}	
	return mutDictTmp ;	
}
+(NSString*)DeletePostfixInvisableChar:(NSString*)strSource //specifal handle
{
	if (strSource==nil)
		return nil ;
	NSMutableString *mutStrTmp=[NSMutableString stringWithString:strSource];
	NSRange rangTmp;
	rangTmp.length=1;
	for(int i=[mutStrTmp length]-1 ; i>=0 ;i--)
	{
		rangTmp.location = i ;
		NSString *strTmp = [mutStrTmp substringWithRange:rangTmp] ;
		if (strTmp==nil)
			return nil ;
		if ([strTmp isEqualToString:@"\n"] ||
		    [strTmp isEqualToString:@"\r"] ||
			[strTmp isEqualToString:@"\t"]
			)
			[mutStrTmp deleteCharactersInRange:rangTmp] ;
		else
			break ;
	}
	if (mutStrTmp==nil)
		return nil ;
	else
		return [NSString stringWithString:mutStrTmp] ;
}
+(NSString*)getVisableStr:(NSString*)strSource
{
	if (strSource==nil)
		return nil ;
	NSMutableString *mutStrTmp=[NSMutableString stringWithString:strSource];
	NSRange rangTmp;
	rangTmp.length=1;
	for(int i=[mutStrTmp length]-1 ; i>=0 ;i--)
	{
		rangTmp.location = i ;
		NSString *strTmp = [mutStrTmp substringWithRange:rangTmp] ;
		if (strTmp==nil)
			return nil ;
		if ([strTmp isEqualToString:@"\n"] ||
		    [strTmp isEqualToString:@"\r"] ||
			[strTmp isEqualToString:@"\t"]
			)
		{
			rangTmp.length=rangTmp.location+1 ;
			rangTmp.location=0 ;			
			[mutStrTmp deleteCharactersInRange:rangTmp] ;
			break ;
		}
	}
	if (mutStrTmp==nil)
		return nil ;
	
	return [NSString stringWithString:mutStrTmp] ;	
}

+(bool)convertScriptToPlist:(NSString*)strPath
{
	if (mutArrayTestScript==nil)
		return NO ;
	if (strPath==nil)
		return NO ;
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	
	NSMutableDictionary *mutDictTmp = [[NSMutableDictionary alloc] init] ;
	int j=0 ; //record current NSArray suffix
	for(int i=0;i<[mutArrayTestScript count] ;i++)
	{
		NSDictionary *dictTmp = [mutArrayTestScript objectAtIndex:i] ;
		//NSLog(@" \n the %d list is %@:",i,dictTmp) ;
		if ([[dictTmp objectForKey:TSName] isEqualToString:@"TestScript"])
		{
			[mutDictTmp setObject:dictTmp forKey:[NSString stringWithFormat:@"/*myPrefix[%3d]myPostfix*/%@",j++,@"TestScript"]] ;
		}else if ([dictTmp objectForKey:TestItemName]!=nil) // test item show
		{
			if ([mutDictTmp objectForKey:@"UndefineTestItem"]==nil) //only one test action
			{
				NSMutableArray *arrayTmp = [[NSMutableArray alloc] init] ;
				[mutDictTmp setObject:arrayTmp forKey:[NSString stringWithFormat:@"/*myPrefix[%3d]myPostfix*/%@",j++,[dictTmp objectForKey:TestItemName]]];
				[arrayTmp addObject:[dictTmp objectForKey:TSName]];
				[arrayTmp addObject:dictTmp] ;
				[arrayTmp release] ;
			}else
			{
				NSMutableArray *arrayTmp = [mutDictTmp objectForKey:@"UndefineTestItem"] ;
				[mutDictTmp setObject:arrayTmp forKey:[NSString stringWithFormat:@"/*myPrefix[%3d]myPostfix*/%@",j++,[dictTmp objectForKey:TestItemName]]];
				[arrayTmp addObject:[dictTmp objectForKey:TSName]];
				[arrayTmp addObject:dictTmp] ;
				//clear old UndefineTestItem 
				[mutDictTmp removeObjectForKey:@"UndefineTestItem"];
			}
		}else //only test item action info
		{
			
			NSMutableArray *arrayTmp = [[NSMutableArray alloc] init] ;
			[mutDictTmp setObject:arrayTmp forKey:@"UndefineTestItem"];
			[arrayTmp addObject:[dictTmp objectForKey:TSName]];
			[arrayTmp addObject:dictTmp] ;
			[arrayTmp release] ;
		};
	} ;	
	
	[mutDictTmp writeToFile:strPath atomically:YES] ;
	//read from local file 
	NSMutableString *mutableStrTmp = [NSMutableString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (mutableStrTmp==nil)
	{
		[mutDictTmp release] ;
		[pool release] ;
		return NO ;
	}
	//Clear comment
	NSRange range ;
	range = [mutableStrTmp rangeOfString:@"/*myPrefix"];
	//NSLog(@"\n %@ \n",mutableStrTmp);
	while (range.length > 0 )
	{
		range.length =26 ;// /*myPrefix[%3d]myPostfix*/
		[mutableStrTmp deleteCharactersInRange:range];
		range = [mutableStrTmp rangeOfString:@"/*myPrefix"];
		//NSLog(@"\n %@ \n",mutableStrTmp);
	}
	[mutableStrTmp writeToFile:strPath atomically:YES encoding:NSASCIIStringEncoding error:NULL] ;
	[mutDictTmp release] ;
	[pool release] ;
	return YES;
};

+(bool)parsePlistTestScript:(NSString*)strPath
{
	if (strPath==nil)
		return false ;
	
	NSString *strTestScript = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (strTestScript==nil)
	{
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"NO Exist file :%@",strPath]] ;
		return false ;
	}
	//clear comment on appconfig .
	strTestScript = [ToolFun clearCommentFromPlistStr:strTestScript] ;
	//NSLog(@"%@",strTestScript) ;
	if (strTestScript==nil)
	{	
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"Incorrect file format on :%@",strPath]] ;
		return false ;
	}
	
	strTestScript = [self getSubstrFromPlist:strTestScript Prefix:@"<dict>" Postfix:@"</dict>" isContain:NO] ;

	if (strTestScript==nil)
	{
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"Incorrect file format on :%@",strPath]] ;
		return NO ;
	};
	
	NSMutableString *mutStrSource = [[[NSMutableString alloc] initWithString:strTestScript] autorelease];
	if (mutStrSource==nil)
		return false ;
	
	if (mutArrayTestScript!=nil)
	{
		[mutArrayTestScript release] ;
		mutArrayTestScript = nil ;
	} ;
	mutArrayTestScript = [[NSMutableArray alloc] init];
	
	NSString *strTmp = [ToolFun getStrToEndString:strTestScript EndString:@"</dict>" Option:true] ;
	if (strTmp==nil)
		return NO ;
	else //general TestScript 
	{
		NSDictionary *dictTmp = [self genDisctionaryFromStrPlist:strTmp] ;
		if (dictTmp==nil)
			return false ;
		[mutArrayTestScript addObject:dictTmp ] ;
		
		NSRange rangTmp = [mutStrSource rangeOfString:@"</dict>"] ;
		if (rangTmp.length <= 0)
			return false;
		
		NSRange rangClear ;
		rangClear.location = 0 ;
		rangClear.length = rangTmp.location+rangTmp.length ;
		[mutStrSource deleteCharactersInRange:rangClear] ;
	};
	
	strTmp = [ToolFun getStrToEndString:mutStrSource EndString:@"</array>" Option:true] ;
	while (strTmp!=nil)
	{
		//TestItemName
		NSString *strTestItemName =[ToolFun getStrFromPrefixAndPostfix:strTmp Prefix:@"<key>" Postfix:@"</key>"] ;
		strTestItemName = [ToolFun deleteFromString:strTestItemName trimStr:@"\n"] ;
		strTestItemName = [ToolFun deleteFromString:strTestItemName trimStr:@"\t"] ;
		strTestItemName = [ToolFun deleteFromString:strTestItemName trimStr:@"\r"] ;
		strTestItemName = [ToolFun allTrimFromString:strTestItemName trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strTestItemName==nil)
			return false ;
		
		NSString * subStr = [self getSubstrFromPlist:strTmp Prefix:@"<array>" Postfix:@"</array>" isContain:NO] ;
		if (subStr==nil)
			return NO ;
		NSString *subsubStr = [ToolFun getStrToEndString:subStr EndString:@"</dict>" Option:true] ;
		while (subsubStr!=nil)
		{
			NSMutableDictionary *mutdictTmp = [self genDisctionaryFromStrPlist:subsubStr] ;
			if (mutdictTmp==nil)
				return false ;
			[mutArrayTestScript addObject:mutdictTmp ] ;
			
			NSRange rangTmp = [subStr rangeOfString:@"</dict>"] ;
			if (rangTmp.length <= 0)
				return false;
			
			subStr = [subStr substringFromIndex:rangTmp.length+rangTmp.location] ;
			subsubStr = [ToolFun getStrToEndString:subStr EndString:@"</dict>" Option:true] ;	
			if (subsubStr==nil)
				[mutdictTmp setObject:strTestItemName forKey:TestItemName] ;
		};
		
		//clear <array>----</nsarray>
		NSRange rangTmp = [mutStrSource rangeOfString:@"</array>"] ;
		if (rangTmp.length <= 0)
			return false;
		
		NSRange rangClear ;
		rangClear.location = 0 ;
		rangClear.length = rangTmp.location+rangTmp.length ;
		[mutStrSource deleteCharactersInRange:rangClear] ;
		
		strTmp = [ToolFun getStrToEndString:mutStrSource EndString:@"</array>" Option:true] ;
	}
	
	//print test script
/*
	 int i;
	 for(i=0 ;i<[mutArrayTestScript count] ;i++ )
	 {
	 NSLog(@"\nObject index=%d : member list is :\n",i) ;
	 NSDictionary *dictTmp = [mutArrayTestScript objectAtIndex:i] ;
	 NSArray *arrayKeys = [dictTmp allKeys];
	 int j=0;
	 for(j=0;j<[arrayKeys count] ;j++)
	 NSLog(@"  %@=%@\n",[arrayKeys objectAtIndex:j],[dictTmp objectForKey:[arrayKeys objectAtIndex:j]]) ;
	 }
*/	
	return true ;
};

+(NSString*)getSubstrFromPlist:(NSString*)strSource Prefix:(NSString*)strPrefix Postfix:(NSString*)strPostfix isContain:(bool)bContain
{
	if (strSource==nil)
		return nil ;
	if (strPrefix==nil ||
		strPostfix==nil)
		return strSource ;
	
	NSRange rangPrefix ,rangPostfix ,rangSubStr ;
	rangPrefix = [strSource rangeOfString:strPrefix] ;
	rangPostfix = [strSource rangeOfString:strPostfix options:NSBackwardsSearch];
	if (rangPrefix.length <= 0 ||
		rangPostfix.length <= 0 ||
		rangPrefix.location>=rangPostfix.location)
		return nil ;
	if (bContain)
	{
		rangSubStr.location = rangPrefix.location ;
		rangSubStr.length = rangPostfix.location+rangPostfix.length ;
	}else
	{
		rangSubStr.location = rangPrefix.location+strPrefix.length ;
		rangSubStr.length = rangPostfix.location - rangPrefix.location - rangPrefix.length;
	}
	return [strSource substringWithRange:rangSubStr] ;
};

+(NSMutableDictionary*)genDisctionaryFromStrPlist:(NSString*)strParameter
{
	if (strParameter==nil)
		return nil ;
	//NSLog(@"\n  %@ \n",strParameter) ;
	//first to get name string
	NSString *strName = [ToolFun getStrToEndString:strParameter EndString:@"<dict>" Option:false ] ;
	if (strName==nil)
		return nil ;
	if ([ToolFun getStrFromPrefixAndPostfix:strName Prefix:@"<key>" Postfix:@"</key>"]==nil)
		strName = [ToolFun getStrFromPrefixAndPostfix:strName Prefix:@"<string>" Postfix:@"</string>"] ;
	else
		strName = [ToolFun getStrFromPrefixAndPostfix:strName Prefix:@"<key>" Postfix:@"</key>"] ;
	
	if (strName==nil)
		return nil ;
		
	NSMutableDictionary* mutDictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
	if (mutDictTmp==nil)
		return nil ;
	//clear comment special handle
	strName = [self DeletePostfixInvisableChar:strName] ;
	strName = [self getVisableStr:strName];
	//-----------------------------------
	strName = [ToolFun allTrimFromString:strName trimStr:@" " leftTrim:true rightTrim:true] ;
	if (strName==nil)
		return nil ;
	
	[mutDictTmp setObject:strName forKey:TSName] ;
	
	NSString *strTmp = [ToolFun getStrFromPrefixAndPostfix:strParameter Prefix:@"<dict>" Postfix:@"</dict>"] ;
	if (strTmp==nil)
		return nil ;
	
	NSMutableString *mutstrParse = [[[NSMutableString alloc] initWithString:strTmp] autorelease] ;
	NSRange rangPrefix = [mutstrParse rangeOfString:@"</string>"] ;
	
	
	while (rangPrefix.length > 0) 
	{
		NSString *substrTmp= [mutstrParse substringToIndex:rangPrefix.location+rangPrefix.length] ;
		if (substrTmp==nil)
			return nil ;
		
		NSString *strKey=nil ,*strValue=nil ;
		strKey = [ToolFun getStrFromPrefixAndPostfix:substrTmp Prefix:@"<key>" Postfix:@"</key>"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\n"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\t"] ;
		strKey = [ToolFun deleteFromString:strKey trimStr:@"\r"] ;
		strKey = [ToolFun allTrimFromString:strKey trimStr:@" " leftTrim:true rightTrim:true] ;
		if (strKey==nil)
			return nil ;
		
		strValue =[ToolFun getStrFromPrefixAndPostfix:substrTmp Prefix:@"<string>" Postfix:@"</string>"];
		/*
		 strValue = [ToolFun allTrimFromString:strValue trimStr:@"\"" leftTrim:true rightTrim:true] ;
		 strValue = [ToolFun allTrimFromString:strValue trimStr:@"[" leftTrim:true rightTrim:true] ;
		 strValue = [ToolFun allTrimFromString:strValue trimStr:@"]" leftTrim:true rightTrim:true] ;
		 */ 
		strValue = [ToolFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] ;
		strValue = [self setHidCharOfScript:strValue] ;
		if (strValue==nil)
			return nil ;
		
		//write key-value to nsdictionary 
		[mutDictTmp setObject:strValue forKey:strKey] ;
		
		//clear the range string
		NSRange rangDele ;
		rangDele.location =0 ;
		rangDele.length = rangPrefix.location+rangPrefix.length ;
		[mutstrParse deleteCharactersInRange:rangDele] ;
		
		rangPrefix = [mutstrParse rangeOfString:@"</string>"] ;
	}	
	return mutDictTmp ;	
};

+(NSString*)setHidCharOfScript:(NSString*)strSource  //set hid char \r \n
{
	if (strSource==nil)
		return nil ;
	NSMutableString *mutStrTmp = [NSMutableString stringWithString:strSource];
	NSRange rangTmp ;
	
	rangTmp = [mutStrTmp rangeOfString:@"\\r"] ;
	while(rangTmp.length > 0)
	{
		[mutStrTmp replaceCharactersInRange:rangTmp withString:@"\r"];
		rangTmp = [mutStrTmp rangeOfString:@"\\r"] ;
	}
	
	rangTmp = [mutStrTmp rangeOfString:@"\\n"] ;
	while(rangTmp.length > 0)
	{
		[mutStrTmp replaceCharactersInRange:rangTmp withString:@"\n"];
		rangTmp = [mutStrTmp rangeOfString:@"\\n"] ;
	}
	
	return [NSString stringWithString:mutStrTmp];
}

+(NSArray*)getTestScript
{
	if (mutArrayTestScript==nil)
		return nil ;
	
	return [NSArray arrayWithArray:mutArrayTestScript];
	
}

//public function
+(bool)AppInitFromCloud:(NSString*)strPath 
{
	if (strPath==nil)
		return false ;
	
	NSString *strStationInfor = [NSString stringWithContentsOfFile:strPath encoding:NSASCIIStringEncoding error:nil] ;
	if (strStationInfor==nil)
	{
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"NO Exist file :%@",strPath]];
		return false ;
	}
	//clear comment on appconfig .
	strStationInfor = [ToolFun clearCommentFromStr:strStationInfor] ;
	//NSLog(@"%@",strAppconfig) ;
	if (strStationInfor==nil)
		return false ;
	
	NSString *strSummary ;
	strSummary = [ToolFun getStrFromPrefixAndPostfix:strStationInfor Prefix:@"Summary" Postfix:nil] ;
	
	if (strSummary==nil)
		return false ;
	//seperation parse each other string 
	if ([self parseSummary:strSummary]==false)
		return false ;
	
	if ([self parseHWConfig:@"/HWconfig.properties"]==false)
	{
		[ToolFun setAPPInitLog:[NSString stringWithFormat:@"NO Exist file :%@",strPath]] ;
		return false ;
	}
	//get data from cloud
	NSString *strIP = [self getValueFromSummary:Client_IP] ;
	NSString *strPort = [self getValueFromSummary:Client_PortID] ;
	NSString *strStationID = [self getValueFromSummary:Client_StationID] ;
	NSString *strTimeout = [self getValueFromSummary:Client_TimeOut] ;
	NSString *strVersion = [self getValueFromSummary:Client_Version] ;
	if (strIP==nil || strPort==nil || strStationID==nil)
	{
		[ToolFun setAPPInitLog:@"StationID ,IP ,PortID info not exist! "] ;
		return false ;
	}
	
	if (strTimeout==nil) 
		strTimeout = @"5" ; //DEFINE VALUE
	NSString *strCommand=nil ;
	if (strVersion==nil)
		strCommand = [NSString stringWithFormat:@"%@*_*01*_*:-):-)",strStationID] ;
	else 
		strCommand = [NSString stringWithFormat:@"%@*_*01*_*%@*_*:-):-)",strStationID,strVersion] ;

	
	if (![SocketManage loadDataFromCloudServer:strIP PortID
											  :[strPort intValue] ProtocolStr
											  :strCommand DataType
											  :SocketDataType_ScriptData TimeOut
		                                      :[strTimeout intValue]]
		)
	{
		[ToolFun setAPPInitLog:@"request DATA Fail from Cloud!"] ;
		return false ;
	}
	
	NSDictionary* dictTmp = [SocketManage getDictSummaryFromScriptData] ;
	if (dictTmp)
	{
		if (mutDictSummary==nil)
			mutDictSummary = [[NSMutableDictionary alloc] init] ;
		[mutDictSummary addEntriesFromDictionary:dictTmp] ;
	}
	else
	{
		[ToolFun setAPPInitLog:@"request DATA Fail from Cloud!"] ;
		return false ;
	}
	
	dictTmp = [SocketManage getDictLogServiceFromScriptData] ;
	if (dictTmp)
	{
		if (mutDictLogService==nil)
			mutDictLogService = [[NSMutableDictionary alloc] init] ;
		[mutDictLogService addEntriesFromDictionary:dictTmp] ;
	}else
	{
		[ToolFun setAPPInitLog:@"request DATA Fail from Cloud!"] ;
		return false ;
	}
	
	NSArray* arrayTmp = [SocketManage getArrayDeviceServiceFromScriptData] ;
	if (arrayTmp)
	{
		if (mutArrayDeviceService==nil)
			mutArrayDeviceService = [[NSMutableArray alloc] init] ;
		[mutArrayDeviceService addObjectsFromArray:arrayTmp] ;
	}else
	{
		[ToolFun setAPPInitLog:@"request DATA Fail from Cloud!"] ;
		return false ;
	}
	
	if (![self parseDeviceParameter])
	{
		[ToolFun setAPPInitLog:@"parse Device list error!"] ;
		return false ;
	}
	
	arrayTmp = [SocketManage getArrayTestScriptFromScriptData] ;
	if (arrayTmp)
	{
		if (mutArrayTestScript==nil)
			mutArrayTestScript = [[NSMutableArray alloc] init] ;
		[mutArrayTestScript addObjectsFromArray:arrayTmp] ;
	}else
	{
		[ToolFun setAPPInitLog:@"request DATA Fail from Cloud!"] ;
		return false ;
	}
	//update key "TestScript" of summary with version of test script .
	if ([self getSWVerision])
		[mutDictSummary setObject:[NSString stringWithFormat:@"/%@.txt",[self getSWVerision]] forKey:@"TestScript"] ;
	
	return true ;
}
//add by Justin Shang @20151019 start
+(NSString*)getCL200ADeviceFile{
    for (NSDictionary *dictTemp in mutArrayDeviceService)
    {
        NSString *CL200ADeviceFile = [dictTemp objectForKey:@"CL200A"];
        if (CL200ADeviceFile != nil)
        {
            NSArray *arrayTemp = [CL200ADeviceFile componentsSeparatedByString:@","];
            NSMutableDictionary *mutDictTemp = [[NSMutableDictionary alloc]init];
            for (NSString *strTemp in arrayTemp){
                NSArray *array2 = [strTemp componentsSeparatedByString:@"="];
                NSString *keyTemp = array2[0];
                keyTemp = [keyTemp stringByReplacingOccurrencesOfString:@" " withString:@""];
                keyTemp = [keyTemp stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                NSString *valueTemp = array2[1];
                valueTemp = [valueTemp stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                valueTemp = [valueTemp stringByReplacingOccurrencesOfString:@" " withString:@""];
                [mutDictTemp setObject:valueTemp forKey:keyTemp];
            }
            
            return [mutDictTemp objectForKey:@"DeviceFile"];
        }
    }
    return nil;
}
//add by Justin Shang @20151019 end

@end
