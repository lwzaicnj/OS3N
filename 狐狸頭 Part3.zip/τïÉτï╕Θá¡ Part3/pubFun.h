/************************************************************
//  PFStringTrans.h
//  String manipulate function for common use
//  Created by Public Function team  on 2/24/10.
//  Copyright (c) 2010-2015, PF Team . 
//  All rights reserved.
*************************************************************/

#import <Cocoa/Cocoa.h>


@interface pubFun : NSObject {

}

/* get special substring from a string
 */
+(NSString*)getStrFromPrefixAndPostfix:(NSString*)strSource Prefix:(NSString*)strPrefix Postfix:(NSString*)strPostfix ;
+(NSString*)getStrToEndString:(NSString*)strSource EndString:(NSString*)strEndString Option:(bool)isContainEndString ;
+(NSString*)getStrFromLen:(NSString*)strSource length:(int)truncateLen Option:(bool)bDirection ;
+(NSString*)GetSubStrFrom:(NSString* ) sourcestr BetweenStr:(NSString* ) BeginStr ANDSymbol:( NSString* ) symbol;

/* clear certain string from a string
 */
+(NSString*)clearCommentFromStr:(NSString*) strSource ;
+(NSString*)clearCommentFromPlistStr:(NSString*)strSource ;

/* delete certain string from a string
 */
+(NSString*)allTrimFromString:(NSString*)strSource trimStr:(NSString*)charSet leftTrim:(bool)bLf rightTrim:(bool)bRG ;
+(NSString*)deleteFromString:(NSString*)strSource trimStr:(NSString*)charSet ;
+(NSString*)deleteToPostfix:(NSString*)strSource EndString:(NSString*)charSet Option:(bool)isContainEndString ;

/* get current date time,format defined: yyyymmddhhmmss
 */
+(NSString*)getCurrentDateTime ;

/* translate yyyymmddhhmmss to International format (YYYY-MM-DD HH:MM:SS  HHMM).
 */
+(NSString*)getInternationalStr:(NSString*)strSource offset:(NSString*)strOffset;

/* check if the string is the number
 */
+(bool)isNumber:(NSString*)strParm;

/* convert Hex string to Integer , and delet 0x .
 */
+(NSInteger)ConvertHexStrToInt:(NSString *)strParm; 

/* convert Decimal string to Hex string  .
 */
+(NSString*)ConvertDecimalStrToHexStr:(NSString*)strDec;

/* get the times certain string occurence .
 */
+(int)numberOfOccurrences:(NSString*)strSource searchStr:(NSString*)substr;

/* use it for interact with each other .
 */
+(id)PerformOutInterfaceFun:(NSString*)strClassName FunctionName:(NSString*)strFun withObject:(id)param1:(id)param2;

@end
