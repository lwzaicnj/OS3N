//
//  ProxIQCParse.h
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseWithoutPostfix)

+(void)ParseWithoutPostfix:(NSDictionary*)dictKeyDefined ;

+(void)ParseAvrageBetweenPrefixAndPostfix:(NSDictionary*)dictKeyDefined ;

+(void)ParseMiddleAvrageBetweenPrefixAndPostfix:(NSDictionary*)dictKeyDefined ;

+(void)ParsePanelID:(NSDictionary*)dictKeyDefined;

+(void)CheckEEPROMVER:(NSDictionary*)dictKeyDefined;
//added by caijunbo on 2011-08-17 used to check multi-vendor EEPROM	verson.
+(void)CheckMultiVendorEEPROMVER:(NSDictionary*)dictKeyDefined;
//end

+(void)CalculatePower:(NSDictionary*)dictKeyDefined;

//SCRID-120: Add calculate power with spec parse. 2011-07-29, Tony
+(void)CalculatePowerWithSpec:(NSDictionary*)dictKeyDefined;

+(void)ParseMiddleAvrageBetweenPrefixAndPostfixWithSpec:(NSDictionary*)dictKeyDefined ;

+(void)ParseCurrent:(NSDictionary*)dictKeyDefined ;

@end
