//
//  ParserCompassFunction.m
//  iFTS
//
//  Created by MAC002 on 10-7-19.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Pudding.h"
#import "ParseCompassFctFunction.h"

@implementation TestItemParse(ParseCompassFctFunction)


/*SCRID-117: add Parser ParseDOECompass. joko 2011-07-20*/
+(void)ParseDOECompass:(NSDictionary*) DictionaryPtr
{
	
	//Parser Attributes
	
	NSString *mTestItemName			= nil	;
	NSString *mReferenceBufferName	= nil	;
	NSString *mBufferXAverageValue			= nil	;
	NSString *mBufferYAverageValue			= nil	;
	NSString *mBufferZAverageValue			= nil	;
	NSString *mLoop			= nil	;
	
	
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"BufferXAverageValue"])
		{
			mBufferXAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferYAverageValue"])
		{
			mBufferYAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferZAverageValue"])
		{
			mBufferZAverageValue = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Loop"])
		{
			mLoop = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	NSString *mReferenceBufferNameValue	= [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	
	mReferenceBufferNameValue=[ToolFun getStrFromPrefixAndPostfix:mReferenceBufferNameValue Prefix:@"X, Y, Z" Postfix:@":-)"];
	
	if (mReferenceBufferNameValue==nil || [mReferenceBufferNameValue length] <= 0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return Error "] ;
	    return  ;
	}
	
	//NSMutableArray *temp = (NSMutableArray*)[mReferenceBufferNameValue componentsSeparatedByString:@","];
	NSMutableArray *temp = (NSMutableArray*)[mReferenceBufferNameValue componentsSeparatedByString:@" "];
	
	if([temp count] != ([mLoop intValue] + 2))
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change!"] ;
		return;
	}
	
	double totalXValue = 0;
	double totalYValue = 0;
	double totalZValue = 0;
	for(int i=1; i<=[mLoop intValue]; i++)
	{
		NSString *oneTimeValue = [temp objectAtIndex:i];
		NSMutableArray *arrayValue = (NSMutableArray*)[oneTimeValue componentsSeparatedByString:@","];
		if([arrayValue count] != 5)
		{
			[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"diags return change !!"] ;
			return;
		}
		
		NSString *testValue = @"0";
		
		testValue=[arrayValue objectAtIndex:2];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalXValue += [testValue intValue];
		
		
		testValue=[arrayValue objectAtIndex:3];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalYValue += [testValue intValue];
		
		testValue=[arrayValue objectAtIndex:4];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"+" withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@" " withString:@""];
		testValue = [testValue stringByReplacingOccurrencesOfString:@"	" withString:@""];
		totalZValue += [testValue intValue];
	}
	
	float averageXValue = totalXValue / [mLoop intValue];
	float averageYValue = totalYValue / [mLoop intValue];
	float averageZValue = totalZValue / [mLoop intValue];
	NSString *strAverageXValue = [NSString stringWithFormat:@"%f",averageXValue];
	NSString *strAverageYValue = [NSString stringWithFormat:@"%f",averageYValue];
	NSString *strAverageZValue = [NSString stringWithFormat:@"%f",averageZValue];
	
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"X Average Value":nil:nil:nil:strAverageXValue:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Y Average Value":nil:nil:nil:strAverageYValue:nil:IP_NA:nil];
	[TestItemManage setSubItemPDCAInfo:DictionaryPtr:@"Z Average Value":nil:nil:nil:strAverageZValue:nil:IP_NA:nil];
	
	NSString *testResult = @"X_ave_v:";
	testResult = [testResult stringByAppendingString:strAverageXValue];
	testResult = [testResult stringByAppendingString:@"; Y_ave_v:"];
	testResult = [testResult stringByAppendingString:strAverageYValue];
	testResult = [testResult stringByAppendingString:@"; Z_ave_v:"];
	testResult = [testResult stringByAppendingString:strAverageZValue];
	
	[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :testResult] ;
	return  ;
}
/*SCRID-117:end*/

+(void)ParseCompassFct:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mUpLimit				= nil    ;
	NSString *mLowLimit				= nil    ;
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"UpLimit"])
		{
			mUpLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LowLimit"])
		{
			mLowLimit = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error!"] ;
		return;
	}
	
	NSArray *upLimitArray	= nil;
	NSArray *lowLimitArray	= nil;
	int xLowLimit, xUpLimit;
	int yLowLimit, yUpLimit;
	int zLowLimit, zUpLimit;
	
	// get Low limit
	lowLimitArray = [ mLowLimit componentsSeparatedByString:@","];
	if ([lowLimitArray count]!=3)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;		
	}
	xLowLimit = [ [lowLimitArray objectAtIndex:(NSUInteger) 0 ] intValue ];
	yLowLimit = [ [lowLimitArray objectAtIndex:(NSUInteger) 1 ] intValue ];
	zLowLimit = [ [lowLimitArray objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	// get Upper limit
	upLimitArray = [ mUpLimit componentsSeparatedByString:@","];
	if ([upLimitArray count]!=3)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;		
	}
	xUpLimit = [ [upLimitArray objectAtIndex:(NSUInteger) 0 ] intValue ];
	yUpLimit = [ [upLimitArray objectAtIndex:(NSUInteger) 1 ] intValue ];
	zUpLimit = [ [upLimitArray objectAtIndex:(NSUInteger) 2 ] intValue ];
	
	NSString *buffervalue = nil;
	NSString *valuesStr = nil;
	
	buffervalue = @"DATA: DeviceInfo=\"0x09\" DATA: Sensitivity = \"rtr90, dfd110, 90\" (1:0x0E) - Pass";
	//buffervalue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	
	if (buffervalue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
		return;
	}
	
	valuesStr = [ToolFun getStrFromPrefixAndPostfix:buffervalue Prefix:@"Sensitivity" Postfix:@"("] ;
	valuesStr = [ToolFun getStrFromPrefixAndPostfix:valuesStr Prefix:@"\"" Postfix:@"\""] ;
	if (valuesStr==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :buffervalue] ;
		return;
	}
	
	NSArray *testValuesArray = nil;
	int xValue, yValue, zValue;
	testValuesArray = [ valuesStr componentsSeparatedByString:@","];
	xValue = [[testValuesArray objectAtIndex:(NSUInteger) 0 ] intValue];
	yValue = [[testValuesArray objectAtIndex:(NSUInteger) 1 ] intValue];
	zValue = [[testValuesArray objectAtIndex:(NSUInteger) 2 ] intValue];
	
	if (xValue < xLowLimit || xValue > xUpLimit)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :[NSString stringWithFormat:@"x = %@, range:[%d,%d]", [testValuesArray objectAtIndex:(NSUInteger) 0 ], xLowLimit, xUpLimit]] ;
		return;
	}
	else if (yValue < yLowLimit || yValue > yUpLimit)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :[NSString stringWithFormat:@"y = %@, range:[%d,%d]", [testValuesArray objectAtIndex:(NSUInteger) 1 ], yLowLimit, yUpLimit]] ;
		return;
	}
	else if (zValue < zLowLimit || zValue > zUpLimit)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :[NSString stringWithFormat:@"z = %@, range:[%d,%d]", [testValuesArray objectAtIndex:(NSUInteger) 2 ], zLowLimit, zUpLimit]] ;
		return;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :[NSString stringWithFormat:@"x=%d, y=%d, z=%d ", xValue, yValue, zValue]] ;
	}
	
	return;
	
}


@end

