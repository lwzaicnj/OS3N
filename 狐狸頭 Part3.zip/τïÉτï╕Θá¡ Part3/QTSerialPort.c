//
//  QTSerialPort.c
//  QTSerialPort
//
//  Created by QT on 8/21/15.
//  Copyright (c) 2015 QT. All rights reserved.
//

#include "QTSerialPort.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <paths.h>
#include <termios.h>
#include <assert.h>

enum {
    kQtCheckForRead,
    kQtCheckForWrite,
    kQtCheckForError,
    kQtCheckUnknown,
};

/*****************************************************************/
int QT_SerialPortOpen(const char *path)
{
    int	fd = -1; //file descriptor
    struct termios options = {0};
    bzero(&options, sizeof(struct termios));
    
    fd = open(path, O_RDWR | O_NOCTTY | O_NONBLOCK | O_EXLOCK); //| O_EXLOCK
    if (fd == -1) {
        printf("Error opening serial port %s - %s(%d).\n", path, strerror(errno), errno);
        goto error;
    }
   
    if (ioctl(fd, TIOCEXCL) == -1) {
        printf("Error setting TIOCEXCL on %s - %s(%d).\n", path, strerror(errno), errno);
        goto error;
    }
    
    fcntl(fd, F_SETFL, 0);

    if (fcntl(fd, F_SETFL, F_NOCACHE) == -1) {
        printf("Error set O_NONBLOCK %s - %s(%d).\n", path, strerror(errno), errno);
        goto error;
    }
    
    
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes %s - %s(%d).\n", path, strerror(errno), errno);
        goto error;
    }
    
//    printf("Current input baud rate is %d\n", (int) cfgetispeed(&options));
//    printf("Current output baud rate is %d\n", (int) cfgetospeed(&options));
    
    cfmakeraw(&options);
    options.c_cflag |= (CLOCAL | CREAD);
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG | IEXTEN);
    //options.c_iflag &= ~(IXON | IXOFF | IXANY | ISTRIP | INLCR | IGNCR | ICRNL | IGNBRK | BRKINT |INPCK);
    options.c_oflag &= ~OPOST;
    //options.c_lflag |= (ICANON| ECHO | ECHOE);
    
    options.c_cc[VMIN]  = 0;
    options.c_cc[VTIME] = 10;
//    int bytes;
//    ioctl(fd, FIONREAD, &bytes);
   
    tcflush(fd,TCIOFLUSH);
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        printf("Error setting tty attributes %s - %s(%d).\n", path, strerror(errno), errno);
        goto error;
    }
    tcflush(fd,TCIOFLUSH);
    
    
    int         handshake;
    int kMyErrReturn = -1;
    
    if (ioctl(fd, TIOCSDTR) == kMyErrReturn)
        // Assert Data Terminal Ready (DTR)
    {
        printf("Error asserting DTR %s - %s(%d).\n",
               "deviceFilePath", strerror(errno), errno);
    }
    
    if (ioctl(fd, TIOCCDTR) == kMyErrReturn)
        // Clear Data Terminal Ready (DTR)
    {
        printf("Error clearing DTR %s - %s(%d).\n",
               "deviceFilePath", strerror(errno), errno);
    }
    
    handshake = TIOCM_DTR | TIOCM_RTS | TIOCM_CTS | TIOCM_DSR;
    // Set the modem lines depending on the bits set in handshake.
    if (ioctl(fd, TIOCMSET, &handshake) == kMyErrReturn)
    {
        printf("Error setting handshake lines %s - %s(%d).\n",
               "deviceFilePath", strerror(errno), errno);
    }
    
    // To read the state of the modem lines, use the following ioctl.
    // See tty(4) ("man 4 tty") and ioctl(2) ("man 2 ioctl") for details.
    
    if (ioctl(fd, TIOCMGET, &handshake) == kMyErrReturn)
        // Store the state of the modem lines in handshake.
    {
        printf("Error getting handshake lines %s - %s(%d).\n",
               "deviceFilePath", strerror(errno), errno);
    }
    
    printf("Handshake lines currently set to %d\n", handshake);
    
    //QT_SetFlowControl(fd,2);
    
    
    
    return fd;
    
error:
    if (fd != -1) {
        close(fd);
    }
    
    return -1;
}

int QT_SetBaudRate(int fd, unsigned long baudRate)
{
    const speed_t bauds[][2] = {{B0,0},{B50,50},{B75,75},{B110,110},{B134,134},{B150,150},
        {B200,200},{B300,300},{B600,600},{B1200,1200},{B1800,1800},{B2400,2400},{B4800,4800},
        {B9600,9600},{B19200,19200},{B38400,38400},{B57600,57600},{B115200,115200},{B230400,230400}};
    
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    struct termios options = {0};
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    speed_t speed = -1;
    for (int i = 0; i < (sizeof(bauds)/sizeof(speed_t))/2; i++) {
        if (baudRate == bauds[i][1]) {
            speed = bauds[i][0];
            break;
        }
    }
    
    if (speed != -1) {
        cfsetispeed(&options, speed);
        cfsetospeed(&options, speed);
        options.c_cflag |= (CLOCAL | CREAD);
        tcflush(fd,TCIFLUSH);
        if (tcsetattr(fd, TCSANOW, &options) == -1) {
            printf("Error setting data bits attributes - %s(%d).\n", strerror(errno), errno);
            return -1;
        }
    }
    else {
        printf("Error non-standard baud rate.\n");
        return -1;
    }
    
    return 0;
}

int QT_SetDataBits(int fd, int dataBits)
{
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    struct termios options = {0};
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    const int validCS[4] = {CS5, CS6, CS7, CS8};
    int willCS = CS8;
    if (dataBits>=5 && dataBits<=8) {
        willCS = validCS[dataBits-5];
    }
    
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= willCS;
    
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        printf("Error setting data bits attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    return 0;
}

int QT_SetParity(int fd, char parity)
{
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    struct termios options = {0};
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    switch (parity) {
        case 'n': case 'N': //NoParity
            options.c_cflag &= ~PARENB;
            options.c_iflag &= ~INPCK;
            break;
            
        case 'e': case 'E': //EvenParity
            options.c_cflag |= PARENB;
            options.c_cflag &= ~PARODD;
            options.c_iflag |= INPCK;
            options.c_iflag |= ISTRIP;//
            break;
            
        case 'o': case 'O': //OddParity
            options.c_cflag |= PARENB;
            options.c_cflag |= PARODD;
            options.c_iflag |= INPCK;
            options.c_iflag |= ISTRIP;//
            break;
            
        case 's': case 'S': //SpaceParity
            options.c_cflag &= ~PARENB;
            options.c_iflag &= ~INPCK;//
            options.c_cflag &= ~CSTOPB;//
            break;
            
        default:
            options.c_cflag &= ~PARENB;
            options.c_iflag &= ~INPCK;
            break;
    }
    
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        printf("Error setting data bits attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    return 0;
}

int QT_SetStopBits(int fd, int stopBits)
{
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    struct termios options = {0};
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    switch (stopBits) {
        case 1:
            options.c_cflag &= ~CSTOPB;
            break;
        case 2:
            options.c_cflag |= CSTOPB;
            break;
        default:
            printf("Unsupported stop bits\n");
            break;
    }
    
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        printf("Error setting data bits attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    return 0;
}


int QT_SetFlowControl(int fd, int flowControl)
{
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    struct termios options = {0};
    if (tcgetattr(fd, &options) == -1) {
        printf("Error getting serial port attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    switch(flowControl){
        case 0 : //not flow control
            options.c_cflag &= ~CRTSCTS;
            break;
        case 1 : // hw flow control
            options.c_cflag |= CRTSCTS; //CCTS_OFLOW CRTS_IFLOW
            break;
        case 2 : // sw flow control
            options.c_cflag |= IXON | IXOFF | IXANY;
            break;
        default:
            printf("Unsupported flowControl\n");
            break;
    }
    
    if (tcsetattr(fd, TCSANOW, &options) == -1) {
        printf("Error setting data bits attributes - %s(%d).\n", strerror(errno), errno);
        return -1;
    }
    
    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////
static int CheckSerialPort(int fd, int checkType, long sec, int usec)
{
    int rt = kQtErrorUnknown;
    struct timeval timeout = {sec, usec};
    fd_set fdset = {0};
    FD_ZERO(&fdset);
    FD_SET(fd, &fdset);
    
    switch (checkType) {
        case kQtCheckForRead:
            rt =  select(fd+1, &fdset, NULL, NULL, &timeout);
            break;
            
        case kQtCheckForWrite:
            rt = select(fd+1, NULL, &fdset, NULL, &timeout);
            break;
            
        case kQtCheckForError:
            rt = select(fd+1, NULL, NULL, &fdset, &timeout);
            break;
            
        default:
            rt = kQtErrorCheckType;
            break;
    }
    
    if (rt>0 && !FD_ISSET(fd, &fdset)) {
        rt = kQtErrorFdSet;
    }
    
    if (rt<=0) {
        printf("Error CheckSerialPort(%d).\n", rt);
        if (rt==-1) {
            printf("Error Detail - %s(%d).\n", strerror(errno), errno);
        }
    }
    
    return rt;
}

int QT_SerialPortSend(int fd, const unsigned char *data, size_t len, long sec, int usec)
{
    long havedWrite = 0;
    long oneWrite = 0;
    
    if (fd<=0 || data==NULL || 0==len) {
        return kQtErrorNull;
    }
    
    tcflush(fd, TCIOFLUSH);
    
    //while (CheckSerialPort(fd, kQtCheckForWrite, sec, usec) > 0)
    {
        oneWrite = write(fd, data+havedWrite, len-havedWrite);
        if (oneWrite == -1)
        {
            printf("Error write - %s(%d).\n", strerror(errno), errno);
            return kQtErrorSys;
        }
        havedWrite += oneWrite;
        
        if (havedWrite >= len) {
            return kQtOK;
        }
    }
    
    printf("Error QT_SerialPortSend(%d).\n", kQtErrorSelect);
    return kQtErrorSelect;
}

long QT_SerialPortRecv(int fd, unsigned char *data, size_t len, const char* endStr, long sec, int usec)
{
    //char buffer[255];  /* Input buffer */
    unsigned char *bufptr;      /* Current char in buffer */
    int  nbytes;       /* Number of bytes read */
    long rt = kQtErrorSelect;

    
    /* read characters into our string buffer until we get a CR or NL */
    bufptr = data;
    while ((nbytes = read(fd, bufptr, data + len - bufptr - 1)) > 0)
    {
        bufptr += nbytes;
        if (bufptr[-1] == '\n' /*|| bufptr[-1] == '\r'*/)
        {
           rt = kQtOK;
        break;
        }
    }
    
    /* nul terminate the string and see if we got an OK response */
    *bufptr = '\0';
    
    printf("QT_SerialPortRecv(rtcode:%ld) dataLen:%ld.\n", rt, strlen(data));
    
    return (rt==kQtOK ? strlen(data) : rt);
    
//    if (strncmp(buffer, "OK", 2) == 0)
//    return (0);
//    
//    return (-1);
//    
//    
//    
//    
//    
//    long rt = kQtErrorSelect;
//    long havedRead = 0;
//    long oneRead = 0;
//    int endlen = (endStr!=NULL ? (int)strlen(endStr) : 0);
//    
//    if (fd<=0 || data==NULL || 0==len) {
//        return kQtErrorNull;
//    }
//    
//    //while (CheckSerialPort(fd, kQtCheckForRead, sec, usec) > 0)
//    {
//        oneRead = read(fd, data+havedRead, len-havedRead);
//        if (oneRead < 0) {
//            printf("Error read - %s(%d).\n", strerror(errno), errno);
//            rt = kQtErrorSys;
//            //break;
//        }else if (oneRead == 0) {
//            printf("Nothing read.\n");
//            rt = kQtErrorReadZero;
//            //break;
//        }else{
//            rt = kQtOK;
//        }
//        
//        havedRead += oneRead;
//        
////        long j=endlen-1;
////        for (long i=havedRead-1; i>=0 && j>=0; --i) {
////            /*if (data[i]=='\n' || data[i]=='\r' || data[i]==' ') {
////                continue;
////            }*/
////            if (data[i]!=endStr[j]) {
////                break;
////            }
////            --j;
////        }
////
////        if (endlen != 0 && j < 0) {
////            rt = kQtOK;
////            break;
////        }
////        else if (havedRead >= len) {
////            rt = endlen!=0 ? kQtErrorReadMax : kQtOK;
////            break;
////        }
//    }
//    
//    if (havedRead < len) {
//        //data[havedRead] = '\0';
//        //printf("data:\n%s\n",data);
//    }
//    if (rt == kQtErrorReadMax) {
////        tcflow(fd, TCOOFF);
////        tcflow(fd, TCIOFF);
////        tcflow(fd, TCIOFLUSH);
////        tcdrain(fd);
//        QT_SerialPortClose(fd);
//        
//    }
//    printf("QT_SerialPortRecv(rtcode:%ld) dataLen:%ld.\n", rt, havedRead);
//    
//    return (rt==0 ? havedRead : rt);
}


int                  /* O - 0 = MODEM ok, -1 = MODEM bad */
init_modem(int fd)   /* I - Serial port file */
{
    char buffer[255];  /* Input buffer */
    char *bufptr;      /* Current char in buffer */
    int  nbytes;       /* Number of bytes read */
    int  tries;        /* Number of tries so far */
    
    for (tries = 0; tries < 3; tries ++)
    {
        /* send an AT command followed by a CR */
        if (write(fd, "AT\r", 3) < 3)
        continue;
        
        /* read characters into our string buffer until we get a CR or NL */
        bufptr = buffer;
        while ((nbytes = read(fd, bufptr, buffer + sizeof(buffer) - bufptr - 1)) > 0)
        {
            bufptr += nbytes;
            if (bufptr[-1] == '\n' || bufptr[-1] == '\r')
            break;
        }
        
        /* nul terminate the string and see if we got an OK response */
        *bufptr = '\0';
        
        if (strncmp(buffer, "OK", 2) == 0)
        return (0);
    }
    
    return (-1);
}

int QT_SerialPortClose(int fd)
{
    //assert(fd > 0);
    if (fd <= 0) {
        return kQtErrorFdNull;
    }
    
    if (tcdrain(fd) == -1) {
        printf("Error waiting for drain - %s(%d).\n", strerror(errno), errno);
    }
    
    if (close(fd) == -1) {
        printf("Error close - %s(%d).\n", strerror(errno), errno);
    }
    
    return kQtOK;
}
////////////////////////////////////////////////////////////////////////////////////////

















