/*
 SCRID:32
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseProxTemFunction.h
 | $Author::Evan						$Revision:: 1               
 | CREATED: 2010.12.10                  $Modtime::  09:00    
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to test the Unit's temperature.
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseProxTemFunction)

+(void)ParseProxTem:(NSDictionary*)dictKeyDefined ;

@end
