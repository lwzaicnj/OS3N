/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: ParsePreviousItemResult.h  $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 29.06.10                $Modtime:: 11.04.10 15:24		 $|
 | STATE  : Alpha                                                      |
 +--------------------------------------------------------------------+
 SCRID-35
 MODULE  : 
 
 PURPOSE : 
 
 $History:: ParsePreviousItemResult.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParsePreviousItemResult)
+(void)ParsePreviousItemResult:(NSDictionary*) DictionaryPtr;

+(void)EepromVersionCheck:(NSDictionary*) dictKeyDefined;
@end