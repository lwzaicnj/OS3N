/*
 SCRID:32
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: ParseProxTemFunction.m 
 | $Author::Evan						$Revision:: 1               
 | CREATED: 2010.12.10                  $Modtime::  09:00    
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :Data Parser Method
 
 PURPOSE :used to test the Unit's temperature.
 
 */

#import "ParseProxTemFunction.h"
#import "Pudding.h"
#import "toolFun.h"
//#import "crc.h"

@implementation TestItemParse(ParseProxTemFunction)

+(void)ParseProxTem:(NSDictionary*)dictKeyDefined
{
	
	//NSString *strTestResultForUIinfo ;
	NSString *strTestResultForUIinfo = @""; 
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
	NSString *mProjectType = nil;
	int mLoopcount = 0;
		
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
				
		else if ([strKey isEqualToString:@"ProjectType"])
			mProjectType = [dictKeyDefined objectForKey:strKey] ;
		
		else if ([strKey isEqualToString:@"loopcount"])
			mLoopcount = [[dictKeyDefined objectForKey:strKey] intValue];
	
	}
	
	/*
	 :-) prox --stage all --loops 10 --measure
	 0	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16415, 32767, 16291, 62268, 47795, 29115, 32322, 31401, 32038, 48013, 7868 - Prox: 44396, Centerpoint: 32767, Temp: 47795, Adjusted_Prox: 11629
	 1	2040/07/19 08:46:25 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32869, 16416, 32771, 16295, 62274, 47794, 29114, 32314, 31397, 32041, 48009, 7876 - Prox: 44394, Centerpoint: 32771, Temp: 47794, Adjusted_Prox: 11623
	 2	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16414, 32771, 16294, 62268, 47797, 29115, 32319, 31400, 32038, 48020, 7870 - Prox: 44401, Centerpoint: 32771, Temp: 47797, Adjusted_Prox: 11630
	 3	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16410, 32758, 16289, 62265, 47797, 29117, 32305, 31398, 32037, 48011, 7875 - Prox: 44403, Centerpoint: 32758, Temp: 47797, Adjusted_Prox: 11645
	 4	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16414, 32768, 16293, 62266, 47792, 29112, 32317, 31400, 32039, 48000, 7870 - Prox: 44391, Centerpoint: 32768, Temp: 47792, Adjusted_Prox: 11623
	 5	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16417, 32768, 16298, 62263, 47795, 29117, 32310, 31400, 32039, 48012, 7867 - Prox: 44391, Centerpoint: 32768, Temp: 47795, Adjusted_Prox: 11623
	 6	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32871, 16418, 32768, 16291, 62274, 47796, 29113, 32315, 31405, 32035, 48027, 7876 - Prox: 44403, Centerpoint: 32768, Temp: 47796, Adjusted_Prox: 11635
	 7	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32868, 16410, 32768, 16293, 62269, 47798, 29115, 32322, 31401, 32041, 48007, 7871 - Prox: 44395, Centerpoint: 32768, Temp: 47798, Adjusted_Prox: 11627
	 8	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32870, 16412, 32768, 16292, 62274, 47797, 29111, 32315, 31400, 32039, 48011, 7866 - Prox: 44394, Centerpoint: 32768, Temp: 47797, Adjusted_Prox: 11626
	 9	2040/07/19 08:46:26 Stage(s) 0,1,2,3,4,5,6,7,8,9,10,11  Sensor Reading: 32873, 16419, 32770, 16294, 62252, 47792, 29116, 32320, 31400, 32039, 48010, 7865 - Prox: 44389, Centerpoint: 32770, Temp: 47792, Adjusted_Prox: 11619
	 */
	
	NSMutableArray *BaseTemp = nil;
		
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSRange rangeTemp = [mReferenceBufferValue rangeOfString:@"Temp: "];
	
	if (rangeTemp.length <= 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no diags response"] ;
		return ;
	}
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	BaseTemp = (NSMutableArray *)[mReferenceBufferValue componentsSeparatedByString:@"Temp: "];
	//end
	
	NSRange BaseTempRange = NSMakeRange(0, 5);

	NSInteger BaseTempValue=0;
		
	for(int i=1 ; i<= mLoopcount ; i++ )
	{
		
		[BaseTemp replaceObjectAtIndex:i 
							withObject:[[BaseTemp objectAtIndex:i] substringWithRange:BaseTempRange]];

		BaseTempValue			= BaseTempValue + [[BaseTemp objectAtIndex:i]integerValue];
		
	}
	
	
	NSInteger BaseTempAvg			= BaseTempValue / mLoopcount ;
	
	strTestResultForUIinfo = [NSString stringWithFormat:@"%d", BaseTempAvg];
	
	enumResult = RESULT_FOR_PASS;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
}

@end