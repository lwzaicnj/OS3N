
/*

 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ParseMagnetFunction.m  $|
 | $Author:: Evan                        $Revision::  1						$|
 | CREATED: 2010-12-06                   $Modtime:: 2.03.00 08:43			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
  
 */
//add by Helen for get config 2011-01-28
#import "ParseConfig.h"
#import "toolFun.h"
#import "UICommon.h"



@implementation TestItemParse(ParseConfig)

+(void)ParseConfig:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil ;
	NSString *mBufferName=nil;
		
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
			
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	NSString *stringConfig = [UICommon getconfig];	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :stringConfig] ;
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :stringConfig] ;
	
	return;
}

@end
