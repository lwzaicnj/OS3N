
/*
 +---------------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: SelectScriptAppconfig.h	    $|
 | $Author:: Henry                  $Revision::  1							$|
 | CREATED: 20 Oct. 2010            $Modtime:: 26 Oct. 2010 15:24			$|
 | STATE  : Beta															 |
 +---------------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History: UICommon.h                                       $
 * *****************  Version 1.0  *****************
 * User: Henry           Date: 20 Oct. 2010   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import "SelectScriptAppconfig.h"
#import "UIWinManage.h"
#import "UICommon.h"
#import "toolFun.h"
#import "SocketManage.h"
#import "scriptParse.h"

@implementation SelectScriptAppconfig

-(id)init
{
	mutArrayStation = nil ;
	mutArrayVer = nil ;

	strIP = nil ;
	strPort = nil ;
	isChangeTableViewItem = NO ;
	iTimeOut = 5;//define value
	if (self = [super init])
	{
		mutArrayStation = [[NSMutableArray alloc] init] ;
		mutArrayVer		= [[NSMutableArray alloc] init] ;

		
		if ([ScriptParse getValueFromSummary:Client_IP])
			strIP =[[NSString alloc] initWithString:[ScriptParse getValueFromSummary:Client_IP]] ;
		
		if ([ScriptParse getValueFromSummary:Client_PortID])
			strPort =[[NSString alloc] initWithString:[ScriptParse getValueFromSummary:Client_PortID]] ;
	}
	
	return self ;
}

-(void)dealloc
{
	[mutArrayStation  release] ;
	[mutArrayVer  release] ;

	[strIP release] ;
	[strPort release] ;
	[super dealloc] ;
}

- (void)awakeFromNib
{
	if(indicator != nil)
		[indicator setHidden:NO];

	[indicator startAnimation:nil] ;
	if ([ScriptParse getValueFromSummary:Client_TimeOut])
		iTimeOut = [[ScriptParse getValueFromSummary:Client_TimeOut] intValue] ;
	//load station ID List
	if (![SocketManage loadDataFromCloudServer:strIP PortID
											  :[strPort intValue] ProtocolStr
											  :[NSString stringWithString:@"01*_*03*_*:-):-)"] DataType
											  :SocketDataType_StationList TimeOut
											  :iTimeOut]
		)
	{
		[indicator stopAnimation:nil];
		[indicator setHidden:YES] ;
		
		[ToolFun setAPPInitLog:[SocketManage getCloudErrorMsg]] ;
		[self show_Fail_Panel:[ToolFun getAPPInitLog]];
		
		[comboStationL setEditable:FALSE] ;
		[comboVersionL setEditable:FALSE] ;
		[self lockUIComponent];
		isChangeTableViewItem = YES ;
		[tabview selectFirstTabViewItem:nil] ;
		isChangeTableViewItem = NO ;
		return  ;
	}
	[mutArrayStation addObjectsFromArray:[SocketManage getStationListData]] ;
	[comboStationL addItemsWithObjectValues:mutArrayStation];
	[comboStationL selectItemAtIndex:2];
	[comboStationL setEditable:FALSE] ;
	[comboVersionL setEditable:FALSE] ;

	[self versionInforUpdate] ;	

	[self lockUIComponent];
	isChangeTableViewItem = YES ;
	[tabview selectFirstTabViewItem:nil] ;
	isChangeTableViewItem = NO ;
	
	[indicator stopAnimation:nil];
	[indicator setHidden:YES] ;
}

#pragma mark -
#pragma mark press button action
/* check netstatus, load appconfig , load test script,then  enter test UI 
 */
-(IBAction)btnEnter_Click:(id)sender
{
	NSString *strUsrName = [txtUsrName stringValue];
	NSString *strPassWord = [txtPassword stringValue];
	if(([strUsrName isEqualToString:@"gdadmin"])&&([strPassWord isEqualToString:@"gdadmin"]))
	{
		[txtUsrName becomeFirstResponder];
		[txtUsrName setStringValue:@""];
		[txtPassword setStringValue:@""];
		[self unLockUIComponent] ;
		return ;
	}
	
	[self show_Fail_Panel:@"incorrect user or password!"];
	return ; 
}


/* buttons for load appconfig and test script , all the scripts are something like text .
 * So we can easily read and edit the script . Also when we finish editing ,we can save them to server .
 */
-(IBAction)btnLoadAppconfig_Click:(id)sender
{
	NSString *strStationID = [self getCurrStationID] ;
	if (strStationID==nil)
		return ;
	
	if ([SocketManage loadDataFromCloudServer:strIP PortID
											  :[strPort intValue] ProtocolStr
											  :[NSString stringWithFormat:@"%@*_*04*_*:-):-)",strStationID] DataType
											  :SocketDataType_Appconfig TimeOut
											  :iTimeOut]
		)
	{
		NSString * strAppConfig=[SocketManage getAppconfigData];
		
		[[[[testscript documentView] textStorage] mutableString] setString:@""] ;
		if(strAppConfig != nil)
		{
			[[[[testscript documentView] textStorage] mutableString] appendString:strAppConfig] ;
			isChangeTableViewItem = YES ;
			[tabview selectLastTabViewItem:sender] ;
			isChangeTableViewItem = NO ;
		}
		
	}else 
	{
		[ToolFun setAPPInitLog:[SocketManage getCloudErrorMsg]] ;
		[self show_Fail_Panel:[ToolFun getAPPInitLog]] ;
		return  ;
	}
}

-(IBAction)btnLoadScript_Click:(id)sender
{
	NSString *strStationID = [self getCurrStationID] ;
	if (strStationID==nil)
		return ;
	
	NSString *strVersion = [self getCurrVersion] ;
	if (strVersion==nil)
		return ;
	
	if ([SocketManage loadDataFromCloudServer:strIP PortID
											 :[strPort intValue] ProtocolStr
											 :[NSString stringWithFormat:@"%@*_*05*_*%@*_*:-):-)",strStationID,strVersion] DataType
											 :SocketDataType_TestScript TimeOut
											 :iTimeOut]
		)
	{
		NSString * strTestScript=[SocketManage getTestScriptData];
		
		[[[[testscript documentView] textStorage] mutableString] setString:@""] ;
		if(strTestScript != nil)
		{
			[[[[testscript documentView] textStorage] mutableString] appendString:strTestScript] ;
			isChangeTableViewItem = YES ;
			[tabview selectLastTabViewItem:sender] ;
			isChangeTableViewItem = NO ;
		}
		
	}else 
	{
		[ToolFun setAPPInitLog:[SocketManage getCloudErrorMsg]] ;
		[self show_Fail_Panel:[ToolFun getAPPInitLog]] ;
		return  ;
	}
	return  ;
}

-(IBAction)btnSave_Click:(id)sender
{
	
	NSString *strTem = [[[testscript documentView] textStorage] mutableString] ;
	if (strTem==nil)
		return ;
	if ([strTem length]<1)
		return ;
	
	NSString *strSpec = @"Version";
	NSRange tmpRan = [strTem rangeOfString:strSpec];
	
	NSString *stationId = [self getCurrStationID];
	NSString *strCmd = @"";
	strCmd = [strCmd stringByAppendingString:stationId] ;
	if(tmpRan.location ==NSNotFound)// it is meaning that appconfig . 
	{
		strCmd = [strCmd stringByAppendingString:@"*_*06*_*"] ;
		strCmd = [strCmd stringByAppendingString:strTem] ;
		strCmd = [strCmd stringByAppendingString:@":-):-)"] ;
	}else
	{
		NSArray *arrayScript =[strTem componentsSeparatedByString:@"}"];
		NSString *strScript =[arrayScript objectAtIndex:0];
		NSString *strVerTmp = [ToolFun getStrFromPrefixAndPostfix:strScript Prefix:@"Version" Postfix:@";"] ;
		if (strVerTmp==nil)
		{
			[self show_Fail_Panel:@"incorrect script format!"] ;
			return ;
		}
		
		NSMutableString *mutstrVer =[[[NSMutableString alloc] initWithString:strVerTmp] autorelease];
		NSRange tRange = [mutstrVer rangeOfString:@"="];
		if (tRange.location!=NSNotFound)
			[mutstrVer deleteCharactersInRange:tRange];
		
		while (YES) 
		{
			if ([mutstrVer length]<1)
			{
				[self show_Fail_Panel:@"incorrect script format!"] ;
				return ;
			}
			
			NSRange tRange = [mutstrVer rangeOfString:@" "];
			if (tRange.location!=NSNotFound)
				[mutstrVer deleteCharactersInRange:tRange];
			else 
				break ;

		}

		strCmd = [strCmd stringByAppendingString:@"*_*07*_*"] ;
		strCmd = [strCmd stringByAppendingString:[NSString stringWithFormat:@"%@*_*",mutstrVer]] ;
		strCmd = [strCmd stringByAppendingString:strTem] ;
		strCmd = [strCmd stringByAppendingString:@":-):-)"] ;
	}
	
	if ([SocketManage sendDataToCloudServer:strIP PortID:[strPort intValue] ProtocolStr:strCmd TimeOut:iTimeOut])
	{
		isChangeTableViewItem=YES ;
		[tabview selectFirstTabViewItem:sender] ;
		isChangeTableViewItem=NO ;
	}else 
	{
		[ToolFun setAPPInitLog:[SocketManage getCloudErrorMsg]] ;
		[self show_Fail_Panel:[ToolFun getAPPInitLog]] ;
	}
}

-(IBAction)btnExitEdit_Click:(id)sender
{
	isChangeTableViewItem=YES ;
	[tabview selectFirstTabViewItem:sender] ;
	isChangeTableViewItem=NO ;
}

-(void)comboBoxSelectionDidChange:(NSNotification *)notification
{
	if ([[notification name] isEqualToString:NSComboBoxSelectionDidChangeNotification])
	{
		if ([notification object]==comboStationL)
			[self versionInforUpdate] ;	
	}
}


/* Alert panel for hint where occur error
 */
-(void)show_Fail_Panel:(NSString*)strError 
{
	NSString *mMessage = nil ;
	NSString *mTitle = @"" ;
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setAlertStyle:NSInformationalAlertStyle];
	
	mTitle = @"Error Message" ;
	mMessage = [NSString stringWithString:strError] ;
	
	[alert setMessageText:mMessage];
	[alert setInformativeText:mTitle];
	[alert addButtonWithTitle:@"OK"];
	[alert runModal];
	[alert release];	
}

-(void)versionInforUpdate 
{
	if (mutArrayStation==nil || [mutArrayStation count]<1 ) //no exist station 
	{
		[mutArrayVer removeAllObjects] ;
		[comboVersionL removeAllItems] ;
		return ;
	} ;
	//step 1 :get the current station id ;
	NSString *strCurrStationID = [self getCurrStationID] ;
	if (strCurrStationID==nil)
	{
		[mutArrayVer removeAllObjects] ;
		[comboVersionL removeAllItems] ;
		return ;
	}
	//step 2 :get newest version list from cloud
	if (![SocketManage loadDataFromCloudServer:strIP PortID
											  :[strPort intValue] ProtocolStr
											  :[NSString stringWithFormat:@"%@*_*02*_*:-):-)",strCurrStationID] DataType
											  :SocketDataType_VersionList TimeOut
		                                      :iTimeOut]
		)
	{
		[ToolFun setAPPInitLog:[SocketManage getCloudErrorMsg]] ;
		return  ;
	}
	[mutArrayVer removeAllObjects];
	[comboVersionL removeAllItems] ;
	[mutArrayVer addObjectsFromArray:[SocketManage getVersionListData]] ;
	[comboVersionL addItemsWithObjectValues:mutArrayVer];
	[comboVersionL selectItemAtIndex:0];
	return ;
}

-(void)lockUIComponent
{
	[comboStationL setEnabled:NO];
	[comboVersionL setEnabled:NO];
	[btnLoadScript setEnabled:NO];
	[btnLoadAppConfig setEnabled:NO];
	
	[btnEnter setEnabled:YES];
	[txtUsrName setEnabled:YES];
	[txtPassword setEnabled:YES] ;
	[txtUsrName setStringValue:@""] ;
	[txtPassword setStringValue:@""] ;
}
-(void)unLockUIComponent
{
	[comboStationL setEnabled:YES];
	[comboVersionL setEnabled:YES];
	[btnLoadScript setEnabled:YES];
	[btnLoadAppConfig setEnabled:YES];
	
	[btnEnter setEnabled:NO];
	[txtUsrName setEnabled:NO];
	[txtPassword setEnabled:NO] ;
}

-(NSString*)getCurrStationID
{
	if (comboStationL==nil)
		return nil ;
	int indexSel=[comboStationL indexOfSelectedItem] ;
	if (indexSel<0)
		return nil ;
	
	NSString *strTmp = [mutArrayStation objectAtIndex:indexSel] ;
	if (strTmp==nil)
		return nil ;
	return [ToolFun getStrFromPrefixAndPostfix:strTmp Prefix:@"[" Postfix:@"]"] ;
	
}
-(NSString*)getCurrStationName
{
	if (comboStationL==nil)
		return nil ;
	int indexSel=[comboStationL indexOfSelectedItem] ;
	if (indexSel<0)
		return nil ;
	
	NSString *strTmp = [mutArrayStation objectAtIndex:indexSel] ;
	if (strTmp==nil)
		return nil ;
	return [ToolFun getStrFromPrefixAndPostfix:strTmp Prefix:@"]" Postfix:nil] ;
	
}

-(NSString*)getCurrVersion
{
	if (comboVersionL==nil)
		return nil ;
	int indexSel=[comboVersionL indexOfSelectedItem] ;
	if (indexSel<0)
		return nil ;
	
	NSString *strTmp = [mutArrayVer objectAtIndex:indexSel] ;
	if (strTmp==nil)
		return nil ;
	return strTmp ;	
}

-(NSString*)getLatestVerName
{
	NSString *strTem = [SocketManage getTestScriptData];
	NSArray *arrayScript =[strTem componentsSeparatedByString:@"}"];
	NSString *strScript =[arrayScript objectAtIndex:0];
	NSArray *arrayVer =[strScript componentsSeparatedByString:@"="];
	NSString *strVer =[arrayVer objectAtIndex:1];
	NSRange tRange = [strVer rangeOfString:@";"];
	strVer=[strVer substringToIndex:tRange.location];
	
	strVer=[ToolFun deleteFromString:strVer trimStr:@"\""];
	strVer=[ToolFun deleteFromString:strVer trimStr:@"\""];
	
	return strVer;
}

- (BOOL)tabView:(NSTabView *)tabView shouldSelectTabViewItem:(NSTabViewItem *)tabViewItem
{
	return isChangeTableViewItem ;
}

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication 
{ 
	
    return YES; 
} 

-(BOOL)windowShouldClose:(id)window
{
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setAlertStyle:NSInformationalAlertStyle];
	[alert setMessageText:@"Are you sure that you want to quit ScriptEdit?"];
	[alert addButtonWithTitle:@"Yes"];
	[alert addButtonWithTitle:@"No"];
	
	NSInteger result = [alert runModal];
	if(result == NSAlertFirstButtonReturn)
	{
		[alert release];
		return YES;
	}
	[alert release];
	return NO;
}
@end
