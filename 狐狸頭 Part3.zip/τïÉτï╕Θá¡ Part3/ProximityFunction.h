//
//  ProximityFunction.h
//  qt_simulator
//
//  Created by Serin on 3/30/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"


@interface TestItemParse(ProximityFunction)

+(int)CalculateStdDev:(NSArray*) AdjProxArray
                        :(NSInteger) AdjProxAvg
                        :(NSInteger) CalCnt;

+(int)CalculateStageStdDev:(NSArray*) AdjProxArray1
						  :(NSInteger) AdjProxAvg1
						  :(NSInteger) CalCnt1;

+(double)CalculateStdDev2:(NSArray*) AdjProxArray
                         :(NSInteger) AdjProxAvg
                         :(NSInteger) CalCnt;

+(void)ParseProxBase:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxBaseForQL2:(NSDictionary*)dictKeyDefined;//judith add for QL P1 20121204
+(void)ParseProxBaseForQT4:(NSDictionary*)dictKeyDefined ;
+(void)ParseProx:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxForQL2:(NSDictionary*)dictKeyDefined;//judith add for QL P1 20121204
+(void)ParseProxValCheck:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxVerification:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxBase_NewSensor:(NSDictionary*)dictKeyDefined;
+(void)ParseProx_NewSensor:(NSDictionary*)dictKeyDefined;//Blake add for try new sensor
//+(void)ParseCmdResult:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxSusParam:(NSDictionary*)dictKeyDefined ;
// serin 20110120
+(void)ParseProxParam:(NSDictionary*)dictKeyDefined ;
+(void)ParseProxSusParam_NewSensor:(NSDictionary*)dictKeyDefined;
// end

@end
