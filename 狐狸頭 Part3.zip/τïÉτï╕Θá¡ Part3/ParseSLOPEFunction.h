/*
 *  keysDefine.h
 *  qt_simulator
 *
 *  Created by diags on 3/27/10.
 *  Copyright 2010 Foxconn. All rights reserved.
 *
 */
//-------------------SCript key define--------



#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"




@interface TestItemParse(ParseSLOPEFunction)




+(void)ParseStrWithStrSpecPostfix_slop:(NSDictionary*)dictKeyDefined;

@end

//
//  StringParseFuncation.h
//  qt_simulator
//
//  Created by diags on 3/1/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

//#import <Cocoa/Cocoa.h>
//#import "testItemParse.h"
//#import "scriptParse.h"

//@interface TestItemParse(StringParseFuncation)

//+(void)ParseStrWithStrSpec:(NSDictionary*)dictKeyDefined ;
//+(void)ParseStrWithStrSpecPostfix:(NSDictionary*)dictKeyDefined ;
//+(void)ParseStrWithStrSpec_CB:(NSDictionary*)dictKeyDefined;
//@end





