//
//  ParseCL200AData.m
//  iFTS
//
//  Created by justin on 10/16/15.
//
//

#import "ParseCL200AData.h"
#import "QTSerialPort.h"
#import "scriptParse.h"


NSString* addChar;
NSString* RecvEndString;
int fd;
int fd_Sec;


@implementation ParseCL200AData

//- (void)OpenSerialPort:(NSDictionary*)dictionary {
+(BOOL)OpenSerialPort{
    
    
    NSString *thePath = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/CL200A.txt"] encoding:NSASCIIStringEncoding error:nil] ;
    
    //NSString* thePath = [ScriptParse getCL200ADeviceFile];
    if (thePath == nil) {
        return 0;
    }
    fd = QT_SerialPortOpen([thePath UTF8String]);//"/dev/cu.usbserial-A702HWSG"
    if (fd==-1)
    {
        return 0;
    }
    QT_SetBaudRate(fd, 9600);
    QT_SetDataBits(fd, 7);
    QT_SetParity(fd,'e');
    QT_SetStopBits(fd, 1);
    QT_SetFlowControl(fd, 0);
    addChar = @"\r\n";
    RecvEndString = @"\r\n";
//    self.addChar = [dictionary objectForKey:@"WriteCmdEnd"];
//    self.RecvEndString = [dictionary objectForKey:@"RecvEndString"];
    //QT_SerialPortClose(self.fd);
    return 1;
}
+(BOOL)OpenSecSerialPort{
    
    
    NSString *thePath = [NSString stringWithContentsOfFile:[NSHomeDirectory()stringByAppendingString:@"/CL200ASec.txt"] encoding:NSASCIIStringEncoding error:nil] ;
    
    //NSString* thePath = [ScriptParse getCL200ADeviceFile];
    if (thePath == nil) {
        return 0;
    }
    fd_Sec = QT_SerialPortOpen([thePath UTF8String]);//"/dev/cu.usbserial-A702HWSG"
    if (fd_Sec==-1)
    {
        return 0;
    }
    QT_SetBaudRate(fd_Sec, 9600);
    QT_SetDataBits(fd_Sec, 7);
    QT_SetParity(fd_Sec,'e');
    QT_SetStopBits(fd_Sec, 1);
    QT_SetFlowControl(fd_Sec, 0);
    addChar = @"\r\n";
    RecvEndString = @"\r\n";
    //    self.addChar = [dictionary objectForKey:@"WriteCmdEnd"];
    //    self.RecvEndString = [dictionary objectForKey:@"RecvEndString"];
    //QT_SerialPortClose(self.fd);
    return 1;
}
+(void)CloseSerialPort{
    QT_SerialPortClose(fd);
}
+(void)CloseSecSerialPort{
    QT_SerialPortClose(fd_Sec);
}
//CL-200A Initialize
+(BOOL)CL200AInitialize{
    //NSString *receiveData = nil;
    
    NSLog(@"Test start......");
    NSData* dataCmd = [NSMutableData data];
    unsigned char recvBuffer[1024] = {0};
    size_t recvLen = sizeof(recvBuffer);
    long readLen = 0;
    
    //step 1
    for (int i = 0; i<5; ++i)
    {
        dataCmd = [self dataFromHexString:@"0230303534312020200331330d0a"];
        QT_SerialPortSend(fd, [dataCmd bytes], [dataCmd length], 3, 1);
        readLen = QT_SerialPortRecv(fd, recvBuffer, recvLen, "\n", 6, 1);
        if (readLen > 0)
        {
            NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
            //[theData appendBytes:recvBuffer length:readLen];
            printf("Recv data:");
            for (int i = 0; i< [theData length]; ++i)
            {
                printf("%c",((unsigned char*)[theData bytes])[i]);
            }
            break;
        }
        else
        {
            NSLog(@" recv cmd error!");
        }
    }
    if (readLen<=0)
    {
        return NO;
    }
    usleep(500000);
    
    //step 2
    for (int i=0; i<5; ++i)
    {
        dataCmd = [self dataFromHexString:@"0239393535312020300330320d0a"];
        QT_SerialPortSend(fd, [dataCmd bytes], [dataCmd length], 3, 1);
        usleep(500000);

    //step 3
        
        dataCmd = [self dataFromHexString:@"0230303430313020200330360d0a"];
        QT_SerialPortSend(fd, [dataCmd bytes], [dataCmd length], 3, 1);
        readLen = QT_SerialPortRecv(fd, recvBuffer, recvLen, "\n", 6, 1);
        if (readLen > 0)
        {
            NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
            //[theData appendBytes:recvBuffer length:readLen];
            printf("Recv data:");
            for (int i = 0; i< [theData length]; ++i) {
                printf("%c",((unsigned char*)[theData bytes])[i]);
            }
            if(recvBuffer[6]==' ')
            {
                break;
            }
            if(recvBuffer[6]=='4')
            {
                continue;
            }
        }
        else {
            NSLog(@" recv cmd error!");
        }
    }
    if (recvBuffer[6]=='4'||recvBuffer[6]=='1'||recvBuffer[6]=='2'||recvBuffer[6]=='3')
    {
        return NO;
    }
    return YES;

}
//CL-200A Initialize end
+(BOOL)CL200ASecInitialize
{
    //NSString *receiveData = nil;
    
    NSLog(@"Test start......");
    NSData* dataCmd = [NSMutableData data];
    unsigned char recvBuffer[1024] = {0};
    size_t recvLen = sizeof(recvBuffer);
    long readLen = 0;
    
    //step 1
    for (int i = 0; i<5; ++i)
    {
        dataCmd = [self dataFromHexString:@"0230303534312020200331330d0a"];
        QT_SerialPortSend(fd_Sec, [dataCmd bytes], [dataCmd length], 3, 1);
        readLen = QT_SerialPortRecv(fd_Sec, recvBuffer, recvLen, "\n", 6, 1);
        if (readLen > 0)
        {
            NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
            //[theData appendBytes:recvBuffer length:readLen];
            printf("Recv data:");
            for (int i = 0; i< [theData length]; ++i)
            {
                printf("%c",((unsigned char*)[theData bytes])[i]);
            }
            break;
        }
        else
        {
            NSLog(@" recv cmd error!");
        }
    }
    if (readLen<=0)
    {
        return NO;
    }
    usleep(500000);
    
    //step 2
    for (int i=0; i<5; ++i)
    {
        dataCmd = [self dataFromHexString:@"0239393535312020300330320d0a"];
        QT_SerialPortSend(fd_Sec, [dataCmd bytes], [dataCmd length], 3, 1);
        usleep(500000);
        
        //step 3
        
        dataCmd = [self dataFromHexString:@"0230303430313020200330360d0a"];
        QT_SerialPortSend(fd_Sec, [dataCmd bytes], [dataCmd length], 3, 1);
        readLen = QT_SerialPortRecv(fd_Sec, recvBuffer, recvLen, "\n", 6, 1);
        if (readLen > 0)
        {
            NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
            //[theData appendBytes:recvBuffer length:readLen];
            printf("Recv data:");
            for (int i = 0; i< [theData length]; ++i) {
                printf("%c",((unsigned char*)[theData bytes])[i]);
            }
            if(recvBuffer[6]==' ')
            {
                break;
            }
            if(recvBuffer[6]=='4')
            {
                continue;
            }
        }
        else {
            NSLog(@" recv cmd error!");
        }
    }
    if (recvBuffer[6]=='4'||recvBuffer[6]=='1'||recvBuffer[6]=='2'||recvBuffer[6]=='3')
    {
        return NO;
    }
    return YES;
    
}
//CL-200A Perform Measurement
+(NSString*)CL200APerformMeasurement
{
    NSString* strRecv = nil;
    
    NSData* dataCmd = [NSMutableData data];
    unsigned char recvBuffer[1024] = {0};
    size_t recvLen = sizeof(recvBuffer);
    long readLen = 0;
    
    //step 4
    usleep(175000);
    dataCmd = [self dataFromHexString:@"0239393430323120200330340d0a"];
    QT_SerialPortSend(fd, [dataCmd bytes], [dataCmd length], 3, 1);
    usleep(500000);
    
    //step 5
    dataCmd = [self dataFromHexString:@"0230303032313230300330320d0a"];
    QT_SerialPortSend(fd, [dataCmd bytes], [dataCmd length], 3, 1);
    readLen = QT_SerialPortRecv(fd, recvBuffer, recvLen, "\n", 6, 1);
    if (readLen > 0) {
        NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
        //[theData appendBytes:recvBuffer length:readLen];
        printf("Recv data%i:",0);
        for (int i = 0; i< [theData length]; ++i) {
            printf("%c",((unsigned char*)[theData bytes])[i]);
        }
        
        strRecv = [NSString stringWithUTF8String:(char*)recvBuffer];
        NSLog(@"CL200A >>> %@",strRecv);
        //return strRecv2;
    }
    else {
        NSLog(@" recv cmd error:%i",0);
    }
    
    return strRecv;
    
    //
    //
    //
    //    //step 4 Perform measurement ***********************************************************************************
    //
    //    NSString *sendCmd4 = [ParseCL200AData stringFromHexString:hexCmd4];
    //    QT_SerialPortSend(fd, sendCmd4.UTF8String,0,5,1);
    //    usleep(500000);
    //
    //
    //    //step 5 Read the colorimetric measurement value ***********************************************************************************
    //
    //    NSString *sendCmd5 = [ParseCL200AData stringFromHexString:hexCmd5];
    //    QT_SerialPortSend(fd, sendCmd5.UTF8String,0,5,1);
    //    char temp2[512] = {0};
    //    QT_SerialPortRecv(fd, temp2, sizeof(temp2), [RecvEndString UTF8String],5,1);
    //
    //    strRecv2 = [NSString stringWithUTF8String:temp2];
    //    NSLog(@"CL200A >>> %@",strRecv2);
    //    return strRecv2;
}
//CL-200A Perform Measurement end
+(NSString*)CL200ASecPerformMeasurement
{
    NSString* strRecv = nil;
    
    NSData* dataCmd = [NSMutableData data];
    unsigned char recvBuffer[1024] = {0};
    size_t recvLen = sizeof(recvBuffer);
    long readLen = 0;
    
    //step 4
    usleep(175000);
    dataCmd = [self dataFromHexString:@"0239393430323120200330340d0a"];
    QT_SerialPortSend(fd_Sec, [dataCmd bytes], [dataCmd length], 3, 1);
    usleep(500000);
    
    //step 5
    dataCmd = [self dataFromHexString:@"0230303032313230300330320d0a"];
    QT_SerialPortSend(fd_Sec, [dataCmd bytes], [dataCmd length], 3, 1);
    readLen = QT_SerialPortRecv(fd_Sec, recvBuffer, recvLen, "\n", 6, 1);
    if (readLen > 0) {
        NSData *theData = [NSData dataWithBytes:recvBuffer length:readLen];
        //[theData appendBytes:recvBuffer length:readLen];
        printf("Recv data%i:",0);
        for (int i = 0; i< [theData length]; ++i) {
            printf("%c",((unsigned char*)[theData bytes])[i]);
        }
        
        strRecv = [NSString stringWithUTF8String:(char*)recvBuffer];
        NSLog(@"CL200A >>> %@",strRecv);
        //return strRecv2;
    }
    else {
        NSLog(@" recv cmd error:%i",0);
    }
    
    return strRecv;
}
+ (NSData *)dataFromHexString:(NSString *)hexString
{
    unsigned char *myBuffer = (unsigned char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (unsigned char)anInt;
        //printf("myBuffer:%c\n",(unsigned char)anInt);
    }
    
    NSMutableData *theData = [NSMutableData data];
    [theData appendBytes:myBuffer length:[hexString length]/2];
    //printf("thedata:%c\n",((unsigned char*)[theData bytes])[0]);
    
    free(myBuffer);
    
    return theData;
}

+ (NSString *)hexStringFromData:(NSData *)theData
{
    Byte *bytes = (Byte *)[theData bytes];
    NSString *hexStr=@"";
    
    for(int i=0; i < [theData length]; i++)
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];
        if([newHexStr length] == 1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    
    return hexStr;
}


+ (NSString *)stringFromHexString:(NSString *)hexString {
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
    NSLog(@"------字符串=======%@",unicodeString);
    return unicodeString;
}

+ (NSString *)hexStringFromString:(NSString *)string{
    NSData *myD = [string dataUsingEncoding:NSUTF8StringEncoding];
    Byte *bytes = (Byte *)[myD bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[myD length];i++)
        
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        
        if([newHexStr length]==1)
            
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        
        else
            
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr;
}

@end
