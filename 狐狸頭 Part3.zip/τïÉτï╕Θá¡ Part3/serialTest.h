//
//  serialTest.h
//  qt_simulator
//
//  Created by diags on 12/17/09.
//  Copyright 2009 Foxconn. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "termios.h"
#import "UartComm.h"
#import "CommManage.h"
#import "scriptParse.h"

@interface serialTest : NSObject {
	UartComm *comm ;
	CommManage *commManager ;
	
	bool bPortOpen ; //open--true ,close--fail
	
	int iSendTotal ,iReceTotal ;
	IBOutlet NSButton* btn_Open ;
	IBOutlet NSTextView* textviewRece ;
	IBOutlet NSScrollView* textviewSend ;
	IBOutlet NSTextField* textfieldStatus ;
	IBOutlet NSTextField* textfieldSendandRece ;
	IBOutlet NSTextField* textfieldInput ;
	
	IBOutlet NSComboBox *cbSerialPort ;
	IBOutlet NSComboBox *cbBaudRate ;
	IBOutlet NSComboBox *cbDataBit ;
	IBOutlet NSComboBox *cbStopBit ;
	IBOutlet NSComboBox *cbParityBit ;
	IBOutlet NSComboBox *cbFlowControl ;
	
	IBOutlet NSButton *chkBtn_CycleTime ;
	IBOutlet NSButton *chkBtn_SendAsHEX ;
	IBOutlet NSButton *chkBtn_SendAsNewLine ;
	IBOutlet NSTextField *tfTime ;
}
-(IBAction) btn_start:(id)sender;
-(IBAction)btn_send:(id)sender ;

-(void)myNotificationHandle:(NSNotification*) notification;

@end
