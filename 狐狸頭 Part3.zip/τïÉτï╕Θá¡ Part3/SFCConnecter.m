//
//  SFCConnecter.m
//  QTSFC
//
//  Created by Kingking on 3/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "SFCConnecter.h"
/*SQLRETURN SQL_API SQLGetDiagRec (
 SQLSMALLINT		  HandleType,
 SQLHANDLE		  Handle,
 SQLSMALLINT		  RecNumber,
 SQLCHAR		* Sqlstate,
 SQLINTEGER		* NativeError,
 SQLCHAR		* MessageText,
 SQLSMALLINT		  BufferLength,
 SQLSMALLINT		* TextLength);*/

@implementation SFCConnecter
-(bool) ConnectSFCWithUserName:(NSString *)UserName
					  PassWord:(NSString *)PassWord
						   DSN:(NSString *)DNS
{
	V_OD_erg=SQLAllocHandle(SQL_HANDLE_ENV,SQL_NULL_HANDLE,&V_OD_Env);
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"SQLAllocHandle fail");
		return false ;
	}
		
	 V_OD_erg=SQLSetEnvAttr(V_OD_Env, SQL_ATTR_ODBC_VERSION, (void*)SQL_OV_ODBC3, 0); 
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"SQLSetEnvAttr fail");
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return false;
	}
		
	V_OD_erg = SQLAllocHandle(SQL_HANDLE_DBC, V_OD_Env, &V_OD_hdbc); 
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"SQL Alloc HDB");
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return false;
	}
	
	V_OD_erg = SQLConnect(V_OD_hdbc, (SQLCHAR*)[DNS UTF8String], SQL_NTS,
						  (SQLCHAR*)[UserName UTF8String], SQL_NTS,
						  (SQLCHAR*)[PassWord	UTF8String], SQL_NTS);
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"Error SQLConnect %d\n",V_OD_erg);
		SQLGetDiagRec(SQL_HANDLE_DBC, V_OD_hdbc,1,V_OD_stat, &V_OD_err,(SQLCHAR*)V_OD_msg,100,&V_OD_mlen);
		NSLog(@"%s (%d)\n",V_OD_msg,V_OD_err);
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return false ;
	}
	SQLSetConnectAttr(V_OD_hdbc, SQL_LOGIN_TIMEOUT, (SQLPOINTER *)5, 0);

	NSLog(@"SQLConnect ok !\n");
	V_OD_erg=SQLAllocHandle(SQL_HANDLE_STMT, V_OD_hdbc, &V_OD_hstmt);
	
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"Fehler im AllocStatement %d\n",V_OD_erg);
		SQLGetDiagRec(SQL_HANDLE_DBC, V_OD_hdbc,1, V_OD_stat,&V_OD_err,(SQLCHAR*)V_OD_msg,100,&V_OD_mlen);
		NSLog(@"%s (%d)\n",V_OD_msg,V_OD_err);
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return NO;
	}	
	return true;
	
}

-(NSString *) QueryResultWithSql:(NSString *)sql
{
	 
	SQLBindCol(V_OD_hstmt,1,SQL_C_CHAR, V_OD_buffer,380,&V_OD_err);
	
	V_OD_erg=SQLExecDirect(V_OD_hstmt,(SQLCHAR*)[sql UTF8String],SQL_NTS);   
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		NSLog(@"SQLExecDirect 1 Fail !\n");
		NSLog(@"Error in Select %d\n",V_OD_erg);
		SQLGetDiagRec(SQL_HANDLE_DBC, V_OD_hdbc,1, ( unsigned char*)V_OD_stat,&V_OD_err,( unsigned char*)V_OD_msg,100,&V_OD_mlen);
		NSLog(@"%s (%d)\n",V_OD_msg,V_OD_err);
		SQLFreeHandle(SQL_HANDLE_STMT,V_OD_hstmt);
		SQLFreeHandle(SQL_HANDLE_DBC,V_OD_hdbc);
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return nil;
	}
	
	NSLog(@"SQLExecDirect 1 ok !\n");
    V_OD_erg=SQLNumResultCols(V_OD_hstmt,&V_OD_colanz);
    if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
    {
        SQLFreeHandle(SQL_HANDLE_STMT,V_OD_hstmt);
        SQLDisconnect(V_OD_hdbc);
        SQLFreeHandle(SQL_HANDLE_DBC,V_OD_hdbc);
        SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
        return nil;
    }
	NSLog(@"Number of Columns %d\n",V_OD_colanz);
	
    V_OD_erg=SQLRowCount(V_OD_hstmt,&V_OD_rowanz);
    if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
    {
		NSLog(@"Number of RowCount %d\n",V_OD_erg);
		SQLFreeHandle(SQL_HANDLE_STMT,V_OD_hstmt);
		SQLDisconnect(V_OD_hdbc);
		SQLFreeHandle(SQL_HANDLE_DBC,V_OD_hdbc);
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return nil;
    }
	NSLog(@"Number of Rows %d\n",V_OD_rowanz);
	
    V_OD_erg=SQLFetch(V_OD_hstmt);  

	NSString *strResult=[NSString stringWithCString:V_OD_buffer encoding:NSASCIIStringEncoding] ;
	return strResult;
	
}

-(bool)insertSQL:(NSString*)Sql
{
	V_OD_erg=SQLExecDirect(V_OD_hstmt,(SQLCHAR*)[Sql UTF8String],SQL_NTS);   
	if ((V_OD_erg != SQL_SUCCESS) && (V_OD_erg != SQL_SUCCESS_WITH_INFO))
	{
		printf("Error in Select %d\n",V_OD_erg);
		SQLGetDiagRec(SQL_HANDLE_DBC, V_OD_hdbc,1, ( unsigned char*)V_OD_stat,&V_OD_err,( unsigned char*)V_OD_msg,100,&V_OD_mlen);
		printf("%s (%d)\n",V_OD_msg,V_OD_err);
		SQLFreeHandle(SQL_HANDLE_STMT,V_OD_hstmt);
		SQLFreeHandle(SQL_HANDLE_DBC,V_OD_hdbc);
		SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
		return NO;
	}	
	
	return YES;
}

-(void) CloseConnect
{
	SQLFreeHandle(SQL_HANDLE_STMT,V_OD_hstmt);
    SQLDisconnect(V_OD_hdbc);
    SQLFreeHandle(SQL_HANDLE_DBC,V_OD_hdbc);
    SQLFreeHandle(SQL_HANDLE_ENV, V_OD_Env);
}
@end
