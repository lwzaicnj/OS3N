//
//  Pudding.m
//  QTPudding
//
//  Created by Kingking on 3/17/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Pudding.h"
#import "testItemParse.h"
#import "scriptParse.h"

#import "WritePDCA.h"
#import "ToolFun.h"

extern NSString* ParametricDataFilePath;
extern NSMutableArray *itemNameForCSV;
extern NSMutableArray *upLimitForCSV;
extern NSMutableArray *lowLimitForCSV;
extern NSMutableArray *valueForCSV;

@implementation Pudding
-(NSString* )initPuddingWithSwVersion:(NSString *)SwVersion
						  SwName:(NSString *)SwName
					SerialNumber:(NSString *)SN
				   LimitsVersion:(NSString *)LimitsVersion
			   StationIdentifier:(NSString *)StationIdentifier
                       StartTime:(long)StartTime
{

	failedAtLeastOneTest = false;
	IP_API_Reply reply = IP_UUTStart(&UID);
	NSString* ret=@"FAIL,";
    NSString* strFailMSG=@"Fail ";
    if (IP_success(reply))
    {
      
        
        reply=IP_amIOkay(UID, [SN UTF8String]);
        if (!IP_success(reply))
        {
            const char* DoneError = IP_reply_getError(reply);
            NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
            strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
            NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
            IP_API_Reply cancelreply = IP_UUTCancel(UID);
            IP_reply_destroy(cancelreply);
            IP_reply_destroy(reply);
            IP_UID_destroy(UID);
            return strFailMSG;
        }
        
    }

	
	if ( !IP_success(reply) )
	{
		//SCRID:93 added by caijunbo on 2011-03-24
		//Description:use to ignore warning message.
		if (IP_MSG_CLASS_PROCESS_CONTROL==IP_reply_getClass(reply))
		//SCRID:93 added end 
		{
			const char* DoneError = IP_reply_getError(reply);
			NSString* nsstrError = [NSString stringWithCString:DoneError];
			ret = [ret stringByAppendingString:nsstrError];			
			IP_API_Reply cancelreply = IP_UUTCancel(UID);
			IP_reply_destroy(cancelreply);
			IP_reply_destroy(reply);
			IP_UID_destroy(UID);
			NSLog(@"Pudding IP_UUTStart Fail");
			//return PUDDING_UUT_START_FAIL;
			//SCRID:93 added by caijunbo on 2011-03-24
			//Description:use to ignore warning message.
			return ret;
			//SCRID:93 added end 
		}
	} 
	NSLog(@"Pudding IP_UUTStart Pass");
	
	NSString* irtn = [self puddingAttributeWithKeyName:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWAREVERSION] andKeyValue:SwVersion];
	if([irtn rangeOfString:@"FAIL"].length>0)
	{
		return irtn;
	}
	
	irtn = [self puddingAttributeWithKeyName:[NSString stringWithUTF8String:IP_ATTRIBUTE_STATIONSOFTWARENAME] andKeyValue:SwName];
	if([irtn rangeOfString:@"FAIL"].length>0)
	{
		return irtn;
	}
	
	irtn = [self puddingAttributeWithKeyName:[NSString stringWithUTF8String:IP_ATTRIBUTE_SERIALNUMBER] andKeyValue:SN];
	if([irtn rangeOfString:@"FAIL"].length>0)
	{
		return irtn;
	}
	
	irtn= [self puddingAttributeWithKeyName:[NSString stringWithUTF8String:"limitsversion"] andKeyValue:LimitsVersion];
	if([irtn rangeOfString:@"FAIL"].length>0)
	{
		return irtn;
	}
	
	// remove for J1J2 ,the new puding lib already can set station ID 2011-02-28
	/*
	NSLog(@"Pudding init attribute pass");
	irtn= [self puddingAttributeWithKeyName:[NSString stringWithUTF8String:"STATION_IDENTIFIER"] andKeyValue:StationIdentifier];
	if([irtn rangeOfString:@"FAIL"].length>0)
	{
		return irtn;
	}
	*/
	NSLog(@"Pudding init add Attribute Pass");
    //add by justin for adding start_time & stop_time 2013-10-11 start
    Boolean APIcheck = false;
    time_t stopTime = time(NULL);
    //time_t *startTime = stopTime-3000;
    APIcheck = IP_setStartTime(UID, StartTime);
    APIcheck = IP_setStopTime( UID, stopTime );
    //add by justin for adding start_time & stop_time 2013-10-11 end
	ret = @"PASS";
	return ret;
	//return PUDDING_PASS;
}

-(int )puddingWithParametricDataForTestItem:(NSString *)testName
								SubTestItem:(NSString *)SubTestItem
							 SubSubTestItem:(NSString *)SubSubTestItem
								   LowLimit:(NSString *)LowLimit
									UpLimit:(NSString *)UpLimit	
								  TestValue:(NSString *)TestValue
								   TestUnit:(NSString *)TestUnit
								 TestResult:(enum IP_PASSFAILRESULT)TestResult
									FailMsg:(NSString *)FailMsg
								   Priority:(enum IP_PDCA_PRIORITY)Priority
{
	//added by caijunbo on 2010-09-07
//	if (TestResult==IP_NA)
//	{
//		TestResult=IP_PASS;
		
//	}
	
	//added end by caijunbo on 2010-09-07
	if(!failedAtLeastOneTest&&(IP_FAIL == TestResult))
    {
		failedAtLeastOneTest = true;
	}
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        if((![TestValue isEqualToString:@"N/A"]) || [testName isEqualToString:@"LCD Vendor"]
           || [testName isEqualToString:@"LCD Config"] || [testName isEqualToString:@"LED Vendor"]
           || [testName isEqualToString:@"LED Brt"] || [testName isEqualToString:@"LED Color"])
        {
            if([testName rangeOfString:@"CAS-140 Measure"].length > 0)
            {
                testName = SubTestItem;
                SubTestItem = SubSubTestItem;
            }
            
            if (![SubTestItem isEqualToString:@""]) 
            {
                if(![SubSubTestItem isEqualToString:@""])
                {
                    [itemNameForCSV addObject:[NSString stringWithFormat:@"%@_%@_%@",testName,SubTestItem,SubSubTestItem]];
                }
                else
                {
                    [itemNameForCSV addObject:[NSString stringWithFormat:@"%@_%@",testName,SubTestItem]];
                    
                }
            }
            else
            {
                [itemNameForCSV addObject:[NSString stringWithFormat:@"%@",testName]]; 
            }
            [upLimitForCSV addObject:UpLimit];
            [lowLimitForCSV addObject:LowLimit];
            [valueForCSV addObject:TestValue];
        }  
        
    } //add by Rick for write csvfile 2012-10-27
    
    if(![ToolFun isNumber:TestValue])
        TestValue = @"N/A";
    
	Boolean APIcheck = false;
	IP_TestSpecHandle testSpec = IP_testSpec_create();
	if (nil	!= testSpec)
	{
		//NSLog(@"Pudding nil	== testSpec");
		APIcheck = IP_testSpec_setTestName(testSpec, [testName	UTF8String], [testName length]);
		APIcheck = IP_testSpec_setSubTestName(testSpec, [SubTestItem UTF8String	], [SubTestItem length]);
		APIcheck = IP_testSpec_setSubSubTestName(testSpec, [SubSubTestItem UTF8String], [SubSubTestItem length]);
		APIcheck = IP_testSpec_setLimits(testSpec, [LowLimit UTF8String	],[LowLimit	length],[UpLimit	UTF8String], [UpLimit	length]);
		APIcheck = IP_testSpec_setUnits(testSpec, [TestUnit UTF8String	],[TestUnit length]);
		APIcheck = IP_testSpec_setPriority(testSpec, Priority);
	}
	else
	{
		NSLog(@"Oooops something strange happened");
	}
	
	IP_TestResultHandle testResult = IP_testResult_create();
	if (nil != testResult)
	{
		NSLog(@"Pudding nil	== testResult");
		APIcheck = IP_testResult_setResult(testResult, TestResult);
		/* SCRID-96: cann't pudding the testvalue when they are not digital. joko 2011-04-21 */
		TestValue = [ToolFun allTrimFromString:TestValue trimStr:@" " leftTrim:true rightTrim:true] ;
		if([TestValue rangeOfString:@"N/A"].length <= 0)
			APIcheck = IP_testResult_setValue(testResult, [TestValue	UTF8String], [TestValue length]);
		/* SCRID-96: end */
		/*SCRID-122: error MSG too long. joko 2011-08-01*/
		if([FailMsg length] > 510)
			FailMsg = [FailMsg substringToIndex:510];
		/*SCRID-122: end*/
		APIcheck = IP_testResult_setMessage(testResult, [FailMsg	UTF8String	], [FailMsg	length]);
	}
	
	else
	{
		NSLog(@"Oooops something strange happened");
	}
	   
 
	IP_API_Reply  addResultreply = IP_addResult(UID, testSpec, testResult);
	if (!IP_success(addResultreply))
	{
		//SCRID:93 added by caijunbo on 2011-03-24
		//Description:use to ignore warning message.
		if (IP_MSG_CLASS_PROCESS_CONTROL==IP_reply_getClass(addResultreply))
		//SCRID:93 added end 
		{	
			NSLog(@"Pudding addResultreply fail");
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(addResultreply);
//			IP_UID_destroy(UID);
			return PUDDING_ADD_RLT_FAIL;
		}
	}
	NSLog(@"Pudding addResultreply pass");
	IP_reply_destroy(addResultreply);
	IP_testResult_destroy(testResult);
	IP_testSpec_destroy(testSpec);
	return PUDDING_PASS;

}

//JianSheng
-(int )puddingWithParametricDataForTestItem_NoMLB:(NSString *)testName
                                      SubTestItem:(NSString *)SubTestItem
                                   SubSubTestItem:(NSString *)SubSubTestItem
                                         LowLimit:(NSString *)LowLimit
                                          UpLimit:(NSString *)UpLimit	
                                        TestValue:(NSString *)TestValue
                                         TestUnit:(NSString *)TestUnit
                                       TestResult:(enum IP_PASSFAILRESULT)TestResult
                                          FailMsg:(NSString *)FailMsg
                                         Priority:(enum IP_PDCA_PRIORITY)Priority
{
	//added by caijunbo on 2010-09-07
    //	if (TestResult==IP_NA)
    //	{
    //		TestResult=IP_PASS;
    
    //	}
	
	//added end by caijunbo on 2010-09-07
	if(!failedAtLeastOneTest&&(IP_FAIL == TestResult))
    {
		failedAtLeastOneTest = true;
	}
    if([[ScriptParse getValueFromSummary:@"NeedWriteToCSV"] boolValue])
    {
        if((![TestValue isEqualToString:@"N/A"]) || [testName isEqualToString:@"LCD Vendor"]
           || [testName isEqualToString:@"LCD Config"] || [testName isEqualToString:@"LED Vendor"]
           || [testName isEqualToString:@"LED Brt"] || [testName isEqualToString:@"LED Color"])
        {
            if([testName rangeOfString:@"CAS-140 Measure"].length > 0)
            {
                testName = SubTestItem;
                SubTestItem = SubSubTestItem;
            }
            
            if (![SubTestItem isEqualToString:@""]) 
            {
                if(![SubSubTestItem isEqualToString:@""])
                {
                    [itemNameForCSV addObject:[NSString stringWithFormat:@"%@_%@_%@",testName,SubTestItem,SubSubTestItem]];
                }
                else
                {
                    [itemNameForCSV addObject:[NSString stringWithFormat:@"%@_%@",testName,SubTestItem]];
                    
                }
            }
            else
            {
                [itemNameForCSV addObject:[NSString stringWithFormat:@"%@",testName]]; 
            }
            [upLimitForCSV addObject:UpLimit];
            [lowLimitForCSV addObject:LowLimit];
            [valueForCSV addObject:TestValue];
        }  
        
    } //add by Rick for write csvfile 2012-10-27
    
    if(![ToolFun isNumber:TestValue])
        TestValue = @"N/A";
    
	return PUDDING_PASS;
    
}

-(int )puddingWithoutParametricDataForTestItem:(NSString *)testName
								   SubTestItem:(NSString *)SubTestItem
								SubSubTestItem:(NSString *)SubSubTestItem
									  LowLimit:(NSString *)LowLimit
									   UpLimit:(NSString *)UpLimit	
// TestValue:(NSString *)TestValue
									  TestUnit:(NSString *)TestUnit
									TestResult:(enum IP_PASSFAILRESULT)TestResult
									   FailMsg:(NSString *)FailMsg
									  Priority:(enum IP_PDCA_PRIORITY)Priority
{
	return [self puddingWithParametricDataForTestItem:testName	
										  SubTestItem:SubTestItem
									   SubSubTestItem:SubSubTestItem
											 LowLimit:LowLimit
											  UpLimit:UpLimit
											TestValue:@"N/A"
											 TestUnit:TestUnit
										   TestResult:TestResult
											  FailMsg:FailMsg
											 Priority:Priority];
	
}
-(NSString* )puddingAttributeWithKeyName:(NSString *)KeyName
						andKeyValue:(NSString *)KeyValue
{
	NSString* ret = @"FAIL,";
    KeyValue = [ToolFun deleteFromString:KeyValue trimStr:@"\n"] ;
    KeyValue = [ToolFun deleteFromString:KeyValue trimStr:@"\r"] ;

	/*SCRID-124:if attribute is nul, not upload it to PDCA. joko, 2011-08-03*/
	if((KeyValue == nil) || (KeyValue == @" ") || (KeyValue == @"\t") || ([KeyValue length] <= 0) 
	   || (KeyName == nil) || (KeyName == @" ") || (KeyName == @"\t") || ([KeyName length] <= 0))
	{
		ret = @"PASS";
		return ret;
	}
	/*SCRID-124:end*/
	IP_API_Reply reply = IP_addAttribute( UID,[KeyName	UTF8String] ,[KeyValue	UTF8String]);
	if (!IP_success(reply))
	{
		
		
		//SCRID:93 added by caijunbo on 2011-03-24
		//Description:use to ignore warning message.
		if (IP_MSG_CLASS_PROCESS_CONTROL==IP_reply_getClass(reply))
		//SCRID:93 added end 
		{
			const char* DoneError = IP_reply_getError(reply);
			NSString* nsstrError = [NSString stringWithCString:DoneError];
			ret = [ret stringByAppendingString:nsstrError];
			NSLog(@"Pudding IP_addAttribute fail");
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
			//SCRID:93 added by caijunbo on 2011-03-24
			//Description:use to ignore warning message.
			return ret;
			//SCRID:93 added end
			//return PUDDING_ADD_ATTR_FAIL;
		}
	}
	NSLog(@"Pudding IP_addAttribute pass");
	IP_reply_destroy(reply);
	ret = @"PASS";
	return ret;
	//return PUDDING_PASS;
}
-(int )puddingBlobWithNameInPDCA:(NSString *)NameInPDCA
						 FilePath:(NSString *)FilePath
{
	IP_API_Reply reply = IP_addBlob(UID, [NameInPDCA UTF8String],[FilePath	UTF8String]);
	if (!IP_success(reply))
	{
		//SCRID:93 added by caijunbo on 2011-03-24
		//Description:use to ignore warning message.
		if (IP_MSG_CLASS_PROCESS_CONTROL==IP_reply_getClass(reply))
		//SCRID:93 added end 
		{
			NSLog(@"Pudding IP_addBlob fail");
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(reply);
//			IP_UID_destroy(UID);
			return PUDDING_ADD_BLOB_FAIL;
		}
	}
	NSLog(@"Pudding IP_addBlob pass");
	IP_reply_destroy(reply);
	return PUDDING_PASS;
}
-(NSString* )puddingCommit:(NSString *)strSN
{
	NSString *ret = @"";
    NSString *strFailMSG = @"Fail ";
	IP_API_Reply doneReply = IP_UUTDone(UID);
	
    
	if (!IP_success(doneReply))
	{
		const char* DoneError = IP_reply_getError(doneReply);
		NSString* nsstrDoneError = [NSString stringWithCString:DoneError];
                
        doneReply=IP_amIOkay(UID, [strSN UTF8String]);
        if (!IP_success(doneReply))
        {
        
            const char* DoneError = IP_reply_getError(doneReply);
            NSString* nsstrError = [NSString stringWithCString:DoneError encoding:NSASCIIStringEncoding];
            
            strFailMSG = [strFailMSG stringByAppendingString:nsstrError];
            NSLog(@"Pudding IP_UUTStart Fail:%@",strFailMSG);
            IP_API_Reply cancelreply = IP_UUTCancel(UID);
            IP_reply_destroy(cancelreply);
            IP_reply_destroy(doneReply);
            IP_UID_destroy(UID);
            ret = strFailMSG;
        }

        
        
//		
//		if (IP_MSG_CLASS_PROCESS_CONTROL == IP_reply_getClass(doneReply))
//		{
//			ret = [ret stringByAppendingString: @"FAIL,We have a FATAL ERROR, "];
//			[ret stringByAppendingString: nsstrDoneError];
//		}
//        NSLog(@"function:%s ",__func__);
//		NSLog(@"%@",ret);
		//IP_reply_destroy(doneReply);disable by kevin 20151124
		//return ret;disable by kevin 20151124
	}
	//IP_reply_destroy(doneReply);
	IP_API_Reply commitReply = IP_UUTCommit(UID, ( failedAtLeastOneTest ? IP_FAIL:IP_PASS ));
	const char* commitError = IP_reply_getError(commitReply);
	NSString* nsstrCommitError = [NSString stringWithCString:commitError];

	if (!IP_success(commitReply))
	{
		//SCRID:93 Modified by caijunbo on 2011-03-24
		//Description:use to ignore warning message.
		
		if (IP_MSG_CLASS_PROCESS_CONTROL==IP_reply_getClass(commitReply))
		{
			ret = [ret stringByAppendingString: @"FAIL, "];
			ret = [ret stringByAppendingString: nsstrCommitError];
			NSLog(ret);
			NSLog(@"Pudding IP_UUTCommit fail 1");
//			IP_API_Reply cancelreply = IP_UUTCancel(UID);
//			IP_reply_destroy(cancelreply);
//			IP_reply_destroy(commitReply);
//			IP_UID_destroy(UID);
			return ret;
			//return PUDDING_UUT_COMMIT_FAIL;
		}
		//SCRID:93 Modified end 
	}
	IP_reply_destroy(commitReply);
	IP_UID_destroy(UID);
	//SCRID:93 Modified by caijunbo on 2011-03-24
	//Description:use to ignore warning message.
	/*
	if([nsstrDoneError length]>1||[nsstrCommitError length]>1)
	{
		//return PUDDING_UUT_DONE_FAIL;
		NSLog(@"Pudding IP_UUTCommit fail 2");
		ret = [ret stringByAppendingString: @"FAIL, "];
		ret = [ret stringByAppendingString: nsstrDoneError];
		return ret;
	}
	if([nsstrCommitError length]>1||[nsstrCommitError length]>1)
	{
		//return PUDDING_UUT_COMMIT_FAIL;
		NSLog(@"Pudding IP_UUTCommit fail 3");
		ret = [ret stringByAppendingString: @"FAIL, "];
		ret = [ret stringByAppendingString: nsstrCommitError];
		return ret;
	}
	 */
	//SCRID:93 Modified end
	NSLog(@"Pudding IP_UUTCommit pass");
	return ret;
	//return returnvalue;
}

@end
