//
//  ParseToQuiteReadcb.h
//  iFTS
//
//  Created by jinn on 7/26/11.
//  Copyright 2011 Vincent-changes.com. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"
//#import "CBAuth_API.h"



@interface TestItemParse(ParseToQuiteReadcb)

+(void)ParseToQuiteReadcb:(NSDictionary*)dictKeyDefined;//vincent 08-03

+(void)ParseToQuiteReadcbForRepair:(NSDictionary*)dictKeyDefined;
//Added by Annie for erase CB with password then check with "cbread xx quiet"   2014.10.07
+(void)ParseToEraseCheckCB:(NSDictionary*)dictKeyDefined;

+(void)ParseBackUpStatus:(NSDictionary*)dictKeyDefined;//evan 08-03
+(void)ParRevCal:(NSDictionary*)dictKeyDefined;

+(void)ParseToQuiteReadcbOnlyIncompletePass:(NSDictionary*)dictKeyDefined; //JianSheng Li
+(void)ParseToQuiteReadcbForGrapeCond:(NSDictionary*)dictKeyDefined; // Justin Shang
+(void)ParseAIMCB:(NSDictionary*)dictKeyDefined; //justin shang 2016-5-6
@end
