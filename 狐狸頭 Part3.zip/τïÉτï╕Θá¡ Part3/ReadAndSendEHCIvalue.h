//
//  ReadAndSendEHICvalue.h
//  iFTS
//
//  Created by Ray Hsu on 2011/11/22.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ReadAndSendEHCIvalueFun)

+(void)ReadAndSendEHCIvalue:(NSDictionary*)dictKeyDefined;

@end
