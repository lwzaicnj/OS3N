//
//  ParserCompassFunction.h
//  iFTS
//
//  Created by MAC002 on 10-7-19.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(ParseCompassFctFunction)

+(void)ParseCompassFct:(NSDictionary*) DictionaryPtr;
+(void)ParseDOECompass:(NSDictionary*) DictionaryPtr ;
@end
