//
//  ParseStrwithStrSpec_AllBtnFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ParseStrwithStrSpec_AllBtnFunction.h"


@implementation TestItemParse(ParseStrwithStrSpec_AllBtnFunction)

+(void)ParseStrwithStrSpec_AllBtn:(NSDictionary*) DictionaryPtr
{
	//Parser Attributes
	NSString *mStrSpec				= nil    ;
	NSString *mReferenceBufferName	= nil    ;
	NSString *mTestItemName			= nil    ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		
		if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [DictionaryPtr objectForKey:strKey] ;
		}
		
	}
	
	if (mReferenceBufferName==nil || mStrSpec==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error!"] ;
		return;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	//mReferenceBufferValue = @"buttontButton TestPress Hold, VolUp, VolDown, Menu and Ringer keys!Menu:PASS,Hold:PASS,Vol_up:PASS,Vol_Dw:PASSMENU:Pass!HOLD:Pass!VolUp:Pass!VolDn:Pass!Ringer:Pass!:-) ";
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"No receive data!"] ;
		return;
	
	}
	
	NSRange		range;
	NSString	*strTemp = [NSString stringWithString:mReferenceBufferValue];
	range	= [strTemp rangeOfString:@"MENU"];
	if (range.length<=0)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"return strings from Diag error!"] ;
		return;
	}
	strTemp	= [strTemp substringFromIndex:range.location];
	
	range	= [mReferenceBufferValue rangeOfString:mStrSpec];
	
	if (range.length <= 0)
	{
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"MENU"   withString:@"HOME" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"HOLD"   withString:@"POWER"];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Ringer" withString:@"MUTE" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Menu"   withString:@"HOME" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Hold"   withString:@"POWER"];
		//[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :strTemp] ;
		//SCRID:112  Modified by kenshin 2011-07-14 
		NSArray *listItems = [strTemp componentsSeparatedByString:@"!"];
		NSString *strTemp1 = @"";
		for (int i=0 ; i<5; i++)
		{
			if ([[listItems objectAtIndex:i] rangeOfString:@"Fail"].length > 0)
			{
				strTemp1 = [strTemp1 stringByAppendingString:[listItems objectAtIndex:i]];
				
			}
		}
	    [TestItemParse SetResultAndUIInfo:DictionaryPtr:RESULT_FOR_FAIL:strTemp1];	
		//SCRID:112  Modified by kenshin 2011-07-14 end.
		
	}
	else
	{
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"MENU"   withString:@"HOME" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"HOLD"   withString:@"POWER"];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Ringer" withString:@"MUTE" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Menu"   withString:@"HOME" ];
		strTemp = [strTemp stringByReplacingOccurrencesOfString:@"Hold"   withString:@"POWER"];
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	}
	
}


@end
