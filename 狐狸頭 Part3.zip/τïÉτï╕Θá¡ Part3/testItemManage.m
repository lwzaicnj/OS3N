/************************************************************
 //  testItemManage.m
 //  For UI use
 //  Created  on 5/12/10.
 //  
 //  All rights reserved.
 *************************************************************/

#import "testItemManage.h"
#import "testItemParse.h"
#import "scriptParse.h"
#include <unistd.h>
#import "keysDefine.h"
#import "pubFun.h"
#import "UICommon.h"
#import "ConditionObj.h"
#import "UIWinManage.h"
//SCRID:155 Modify for retesting fail testitem by Ray 20120104
#import "UIAlert.h"
//SCRID:155 end
NSInteger g_TestIndex = 0;

extern NSString* const TSName;
NSRecursiveLock *g_TestItemFunLock = nil;

@implementation MyTestObject


-(void)test1:(NSTableView*)tableView
{
    [tableView scrollRowToVisible:g_TestIndex];
}

-(void)test2:(NSTableView*)tableView
{
    [tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:g_TestIndex] byExtendingSelection:NO];
}

-(void)test3:(NSTableView*)tableView
{
    [tableView scrollColumnToVisible:g_TestIndex];
}

-(void)test4:(NSTableView*)tableView
{
    [tableView selectColumnIndexes:g_TestIndex byExtendingSelection:NO];
}




@end
NSString* const TestItemName =@"TestItemName" ; 
NSString * const TestitemAction = @"TestItemAction" ;
NSString * const TestItemResult = @"TestItemResult" ;

NSString * RetestItemName = @"";

NSMutableArray *mutArrayTestItemList=nil ; //save all test item and test result , corresponse to UI .
NSMutableDictionary *mutDictTestItemActionInfo=nil ;// save test process 's info ,
NSMutableDictionary *mutDictTestItemThread=nil ; //test thread related info manager .

//SCRID:155 Modify for retesting fail testitem by Ray 20120104
//bool retestFlag = true;
//SCRID:155 end

@implementation TestItemManage


+(bool)initTestItemInfo  //general test item and test item action info
{	
	NSArray *mutArrayTestScript = [ScriptParse getTestScript];
	if (mutArrayTestScript==nil)
		return false ;
    ///////////////////////////////////////
    if (g_TestItemFunLock!=nil)
        [g_TestItemFunLock release] ;
    
    g_TestItemFunLock = [[NSRecursiveLock alloc] init];
    if (g_TestItemFunLock==nil)
        return false ;
    //////////////////////////////////////
	if (mutArrayTestItemList!=nil)
	{
		[mutArrayTestItemList release] ;
		mutArrayTestItemList = nil ;
	}
	
	mutArrayTestItemList=[[NSMutableArray alloc] init] ;
	
	NSMutableDictionary *mutDictTmp =nil ;
	
	for(int i=1 ;i<[mutArrayTestScript count] ;i++)
	{
		NSDictionary *dictTmp=[mutArrayTestScript objectAtIndex:i] ;
		if (dictTmp==nil)
			return false ;
		
		if (mutDictTmp==nil)
		{
			mutDictTmp = [[NSMutableDictionary alloc] init]  ;
	    	NSMutableArray* mutArrayTmp = [[[NSMutableArray alloc] init] autorelease] ;
			NSMutableDictionary *dictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
			
			if (mutArrayTmp==nil || dictTmp1==nil)
			{
				[mutDictTmp release] ;
				mutDictTmp = nil ;
				return false ;
			}
			
			[mutDictTmp setObject:mutArrayTmp forKey:TestitemAction] ;
			[mutDictTmp setObject:dictTmp1 forKey:TestItemResult] ;
		}
		[[mutDictTmp objectForKey:TestitemAction] addObject:dictTmp] ; //add current action 
		
		NSString *strTestItem = [dictTmp objectForKey:TestItemName] ;
		if (strTestItem!=nil)
		{
			//create a new testitemname
			NSMutableString *strNewTestItemName = [[NSMutableString alloc] init] ;
			[strNewTestItemName appendString:strTestItem] ;
			
			if ([dictTmp objectForKey:@"StrSpec"]!=nil)
			{
				[strNewTestItemName appendFormat:@" [%@]",[dictTmp objectForKey:@"StrSpec"]] ;
			}else if ([dictTmp objectForKey:@"Uplimit"]!=nil &&
				      [dictTmp objectForKey:@"Lowlimit"]!=nil)
			{
				[strNewTestItemName appendFormat:@" [%@,%@]",[dictTmp objectForKey:@"Lowlimit"],[dictTmp objectForKey:@"Uplimit"]];
			}else if ([dictTmp objectForKey:@"LowerValue"]!=nil &&
				      [dictTmp objectForKey:@"UpperValue"]!=nil)
			{
				[strNewTestItemName appendFormat:@" [%@,%@]",[dictTmp objectForKey:@"LowerValue"],[dictTmp objectForKey:@"UpperValue"]];
			}
            else if ([dictTmp objectForKey:@"Uplimit"]==nil &&
                     [dictTmp objectForKey:@"Lowlimit"]!=nil)
			{
				[strNewTestItemName appendFormat:@" [%@,NA]",[dictTmp objectForKey:@"Lowlimit"]];
			}
            else if ([dictTmp objectForKey:@"Uplimit"]!=nil &&
                     [dictTmp objectForKey:@"Lowlimit"]==nil)
			{
				[strNewTestItemName appendFormat:@" [NA,%@]",[dictTmp objectForKey:@"Uplimit"]];
			}
            else if ([dictTmp objectForKey:@"LowerValue"]==nil &&
                     [dictTmp objectForKey:@"UpperValue"]!=nil)
			{
				[strNewTestItemName appendFormat:@" [NA,%@]",[dictTmp objectForKey:@"UpperValue"]];
			}
            else if ([dictTmp objectForKey:@"LowerValue"]!=nil &&
                     [dictTmp objectForKey:@"UpperValue"]==nil)
			{
				[strNewTestItemName appendFormat:@" [%@,NA]",[dictTmp objectForKey:@"LowerValue"]];
			};
			
			if ([dictTmp objectForKey:@"ProjectType"]!=nil)
			{
				//2011-01-22 delete by henry
			//	[strNewTestItemName appendFormat:@"[Only %@]",[dictTmp objectForKey:@"ProjectType"]] ;
			};
			
			[mutDictTmp setObject:strNewTestItemName forKey:TestItemName] ;
			[mutArrayTestItemList addObject:mutDictTmp] ;
			[mutDictTmp release] ;
			mutDictTmp = nil ;
			[strNewTestItemName release] ;
		}
	}
	
	//print list 
	/*
	 for (int i=0;i<[mutArrayTestItemList count];i++)
	 {
	 NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:i];
	 
	 //print test name
	 NSLog(@"\n Test name = %@" ,[dictTmp objectForKey:TestItemName]) ;
	 //print test item action .
	 NSArray* arrayTmp = [dictTmp objectForKey:TestitemAction];
	 NSLog(@"\n          action list is:") ;
	 for(int j=0; j<[arrayTmp count] ;j++)
	 {
	 NSDictionary *subDictTmp = [arrayTmp objectAtIndex:j] ;
	 NSArray* subArrayTmp = [subDictTmp allKeys] ;
	 NSLog(@"\n            action[%d] =",j+1) ;
	 for (int m=0 ;m<[subArrayTmp count];m++)
	 {
	 NSLog(@"\n             %@ = %@",
	 [subArrayTmp objectAtIndex:m] ,
	 [subDictTmp objectForKey:[subArrayTmp objectAtIndex:m]]) ;
	 }
	 }
	 }
	 */ 
	//print list end
	
	return true ;
}

+(NSUInteger)getTestItemCount 
{
	if (mutArrayTestItemList==nil)
		return 0 ;
	return [mutArrayTestItemList count];
}

+(NSString*)getTestItem:(int)iRow 
{
	if (mutArrayTestItemList==nil)
		return nil ;
	if (iRow>=[mutArrayTestItemList count])
		return nil ;
	
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:iRow] ;
	if (dictTmp==nil)
		return nil ;
	NSString *strTmp = [dictTmp objectForKey:TestItemName];
	if (strTmp==nil)
		return nil ;
	NSString*strRtn = [NSString stringWithFormat:@"%d:%@",iRow+1,strTmp];

	return strRtn ;
}

+(NSAttributedString*)getTestItemResultForUI:(int)DUTID row:(int)iRow
{
	if (mutArrayTestItemList==nil)
		return nil ;
	
	if (iRow>=[mutArrayTestItemList count])
		return nil ;
	
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:iRow] ;
	NSDictionary *dictResult = [dictTmp objectForKey:TestItemResult] ;
	
    NSString *strKey = [[[NSString alloc] initWithFormat:@"%d-UIInfo",DUTID] autorelease];
	return [dictResult objectForKey:strKey] ;
}

+(NSArray*)getTestItemResult:(int)DUTID row:(int)iRow 
{
	if (mutArrayTestItemList==nil)
		return nil ;
	
	if (iRow>=[mutArrayTestItemList count])
		return nil ;
	
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:iRow] ;
	NSDictionary *dictResult = [dictTmp objectForKey:TestItemResult] ;
	
	NSString *strKey = [[[NSString alloc] initWithFormat:@"%d-Result",DUTID] autorelease];
	NSNumber *numResult= [dictResult objectForKey:strKey] ;	
	if (numResult==nil)
		return nil ;
	NSString *strResult=nil ;
	NSString *strUIShow=nil ;
	switch ([numResult intValue]) 
	{
		case RESULT_FOR_PASS:
			strResult = @"Pass";
			break;
		case RESULT_FOR_BYPASS:
			strResult = @"ByPass";
			break;
		default:
			strResult = @"Fail" ;
			break;
	}
	
	NSString *strTestItemName = [dictTmp objectForKey:@"TestItemName"] ;
	NSAttributedString *strAttrTestValue = [dictResult objectForKey:[NSString stringWithFormat:@"%d-UIInfo",DUTID]];
	NSString *strTestValue=nil ;
	if (strAttrTestValue!=nil)
		strTestValue = [strAttrTestValue string] ;
	
	if (strTestValue==nil || strTestItemName==nil)
		return nil ;
	
	if ([strTestItemName isEqualToString:@"SN"] &&
		[strResult isEqualToString:@"Pass"]
		)
		strUIShow = [NSString stringWithString:strTestValue] ;
	else if ([pubFun isNumber:strTestValue])
		strUIShow = [NSString stringWithString:strTestValue] ;
	else
		strUIShow = [NSString stringWithString:strResult] ;
	
    return [NSArray arrayWithObjects:strResult,strUIShow,nil] ;
}

+(void)StartTest:(NSTableView*)tableView :(NSTextField*)ItemTime :(NSTextField*)TotalTime :(NSTextField*)showPassOrFail :(NSDictionary*)dictUNITInfo :(bool)bDirection :(NSDictionary*)scanDataParm
{
	if (tableView==nil ||
		TotalTime==nil ||
		ItemTime ==nil ||
		showPassOrFail==nil  
		)
		return  ;
	if (dictUNITInfo==nil)
		return ;
	int iDutID = [[dictUNITInfo objectForKey:@"BelongToDUT"] intValue] ;
	NSString *strUNDevice = [dictUNITInfo objectForKey:@"UNITDevice"] ;
	NSArray *arrayFixtureDevice =[dictUNITInfo objectForKey:@"FixtureDevice"] ;
	if (strUNDevice==nil)
		return ;
	
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;	
	if (mutDictTestItemThread==nil)
		mutDictTestItemThread = [[NSMutableDictionary alloc] init] ;
	
	
	NSMutableDictionary *mutdictThreadinfo = [mutDictTestItemThread objectForKey:[NSString stringWithFormat:@"%d",iDutID]] ;
	if (mutdictThreadinfo!=nil)
	{
		NSThread *threadTmp = [mutdictThreadinfo objectForKey:@"ThreadID"] ;
		[mutdictThreadinfo setObject:@"cancel" forKey:@"ThreadStatus"] ;
		
		if ([threadTmp isExecuting])
			[threadTmp cancel] ;
		
		NSThread *threadRefreshTimer =[mutdictThreadinfo objectForKey:@"RefreshTime"] ;
		[mutdictThreadinfo setObject:@"NO" forKey:@"RefreshTimeStatus"];
		if ([threadRefreshTimer isExecuting])
			[threadRefreshTimer cancel] ;
		
	} ;
	//clear old thread obect info
	[showPassOrFail setStringValue:@"on going"] ;
	//closed by henry 2011-01-21
	//[showPassOrFail setFont:[NSFont userFontOfSize:14]];
	[self handleNotification:[NSString stringWithFormat:@"%d",iDutID] type:@"backGround"];//dsx-01-18 fix crash issue at begin reset color

	//Henry add 20100723
	NSString *strTmp = [ScriptParse getValueFromSummary:@"SwitchUI"] ;
	if (strTmp!=nil)
	{
		// Owner:Henry DATE :11.30.2010
		// SCRID :026
		// Desc  :modify for iPad-1,add UI2,UI2S 
		if (([strTmp isEqualToString:@"UI1M"])||([strTmp isEqualToString:@"UI1M2"])||([strTmp isEqualToString:@"UI2"])||([strTmp isEqualToString:@"UI2S"]))
			//End by Helen 11.30.2010
			[showPassOrFail setFont:[NSFont userFontOfSize:30]];
	}
	
	[showPassOrFail setTextColor:[NSColor blueColor]] ;
	
	
	[mutDictTestItemThread removeObjectForKey:[NSString stringWithFormat:@"%d",iDutID]] ;
	
	//create new thread info
	mutdictThreadinfo = [[[NSMutableDictionary alloc] init] autorelease] ;
	[mutDictTestItemThread setObject:mutdictThreadinfo forKey:[NSString stringWithFormat:@"%d",iDutID]] ;
	
	NSMutableDictionary *mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
	[mutdictTmp setObject:tableView forKey:@"TableView"]  ;
	[mutdictTmp setObject:[NSString stringWithFormat:@"%d",iDutID] forKey:@"DUTID"] ;
	[mutdictTmp setObject:strUNDevice forKey:@"UNITDevice"]  ;
	if (arrayFixtureDevice!=nil)
		[mutdictTmp setObject:arrayFixtureDevice forKey:@"FixtureDevice"] ;
	
	//set TotalItemtime,itemTime to dictionary .
	if (bDirection)
	{
		[mutdictTmp setObject:@"No" forKey:@"SelectToRow"] ;
	}else
	{
		[mutdictTmp setObject:@"YES" forKey:@"SelectToRow"] ;
	}
	
	[mutdictTmp setObject:ItemTime forKey:@"ItemTimeField"]  ;
	
	[mutdictTmp setObject:TotalTime forKey:@"TotalTimeField"]  ;
	[mutdictTmp setObject:showPassOrFail forKey:@"ShowPassOrFail"]  ;
	
	if (scanDataParm!=nil)
		[mutdictTmp setObject:scanDataParm forKey:@"ScanDataForUI" ];
	
	
	// Owner:Henry DATE :1.19.2011  SCRID:66 Desc  :Add for QT3
	NSThread * threadTmp = nil;
	if([[ScriptParse getValueFromSummary:STRKEYSWITCHUI] isEqualToString:@"UI3Prox"])
		threadTmp = [[[NSThread alloc] initWithTarget:self selector:@selector(testEngineerThreadQT3:) object:mutdictTmp] autorelease] ;
	else 
		threadTmp = [[[NSThread alloc] initWithTarget:self selector:@selector(testEngineerThread:) object:mutdictTmp] autorelease] ;
	
	[mutdictThreadinfo setObject:threadTmp forKey:@"ThreadID"] ;
	[mutdictThreadinfo setObject:@"start" forKey:@"ThreadStatus"] ;
	
	//create a THread to refresh time
	NSDictionary *dictTimerParm = [NSDictionary dictionaryWithObjectsAndKeys:ItemTime,@"ItemTimeField",
								   TotalTime,@"TotalTimeField",
								   [NSString stringWithFormat:@"%d",iDutID],@"DUTID",nil] ;
	NSThread * threadRefTime = [[[NSThread alloc] initWithTarget:self selector:@selector(testTimerRefresh:) object:dictTimerParm] autorelease] ;
	[mutdictThreadinfo setObject:threadRefTime forKey:@"RefreshTime"] ;
	
	[threadTmp start] ;
	
	[pool release] ;
	
	return ;
}

+(void)StopTest:(int)DUTID
{
	if (mutDictTestItemThread==nil)
		return ;
	NSString *strDUTID = [NSString stringWithFormat:@"%d",DUTID] ;
	NSMutableDictionary *mutDictTmp = [mutDictTestItemThread objectForKey:strDUTID] ;
	if (mutDictTmp==nil)
		return  ;
	
	[mutDictTmp setObject:@"cancel" forKey:@"ThreadStatus"] ;
	
	NSThread *threadTmp = [mutDictTmp objectForKey:@"ThreadID"] ;
	if (threadTmp==nil)
		return  ;
	if ([threadTmp isExecuting])  
		[threadTmp cancel] ;
	return ;
}

+(bool)CheckThreadRun:(int)DUTID
{
	if (mutDictTestItemThread==nil)
		return false ;
	NSString *strDUTID = [NSString stringWithFormat:@"%d",DUTID] ;
	NSMutableDictionary *mutDictTmp = [mutDictTestItemThread objectForKey:strDUTID] ;
	if (mutDictTmp==nil)
		return false ;
	
	NSThread *threadTmp = [mutDictTmp objectForKey:@"ThreadID"] ;
	if (threadTmp==nil)
		return false ;
	
	if ([threadTmp isFinished]) //alread run over
		return false ;
	return true ;
}

+(void)testEngineerThread:(NSDictionary*)dictParam /////(NSTableView*)tableView :(int)iDutID 
{
	//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
	//retestFlag=TRUE;
	//SCRID:155 end
	
	int textItemIndexWhenStopFail = 1;
	if (mutDictTestItemActionInfo==nil)
	{
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	}
	
	if (dictParam==nil)
		return ;
	
	//get key value ;
   // MyTestObject * testObject = [[[MyTestObject alloc] init] autorelease];
	NSTableView* tableView = [dictParam objectForKey:@"TableView"] ;
	NSString *strDutID = [dictParam objectForKey:@"DUTID"];
	NSString *strSeleToRow = [dictParam objectForKey:@"SelectToRow"];
	if (tableView==nil ||
		strDutID==nil ||
		strSeleToRow==nil 
		)
		return ;
	//get TOTALITEMTime ,ITEMTime point
	NSTextField *textTotalTime=nil ,*textItemTime =nil, *textPassOrFail=nil ;
	textTotalTime = [dictParam objectForKey:@"TotalTimeField"] ;
	textItemTime = [dictParam objectForKey:@"ItemTimeField"] ;
	textPassOrFail = [dictParam objectForKey:@"ShowPassOrFail"] ;
	if (textItemTime==nil ||
		textTotalTime==nil ||
		textPassOrFail==nil
		)
		return  ;
	
	//clear old message .
	[self clearTestActionInfo:strDutID] ;
	NSAutoreleasePool *tabViewDisplayPool = [[NSAutoreleasePool alloc] init] ; //add by henry 20100828 , if no auto realease pool ,it will lead to memory leak !
	//[tableView reloadData] ; //modified by caijunbo on 20100913 if has no auto realease pool ,it will lead  memory leaking too!
    [tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO ];
    //[tableView performSelectorOnMainThread:@selector(display) withObject:nil waitUntilDone:YES ];
	//[tableView display] ;//add by giga
	[tabViewDisplayPool release];
	
	if (mutArrayTestItemList==nil)
		return ;
	
	//Set Scan data
	NSAutoreleasePool *scandataPool = [[NSAutoreleasePool alloc] init] ;
	NSDictionary *dictScanData = [dictParam objectForKey:@"ScanDataForUI"] ;
	if (dictScanData!=nil)
	{
		NSArray *arrTmpScan = [dictScanData allKeys] ;
		for (int i=0;i<[arrTmpScan count] ;i++)
		{
			NSString *strKey = [arrTmpScan objectAtIndex:i] ;
			NSString *strValue = [dictScanData objectForKey:strKey] ;
			[self setScanValue:[strDutID intValue] :strKey :strValue] ;
		}
	}
	[scandataPool release] ;
	//scan data end 
	
	//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
	NSMutableArray* arrayTestCount = [[[NSMutableArray alloc] init] autorelease] ;
	int retestCount = 0;
	NSString *tmpQWRTT=@"0";
	for(int k=0 ;k<[mutArrayTestItemList count]; k++)
	{
		[arrayTestCount addObject:tmpQWRTT];
	}
    
    NSString *strDutIDStartTime = [strDutID stringByAppendingString:@"_StartTime"];
    time_t startTime = time(NULL);//add by justin for adding start_time & stop_time 2013-10-11
    [mutDictTestItemActionInfo setObject:[NSNumber numberWithLong:startTime] forKey:strDutIDStartTime];//add by justin 20131012 for get the startTime at start time

    //====JianSheng 2014-01-14 Change: ramdom to start test Magnet and Hall Sensor items===========
    NSString *TestItemIndexMagnetHallEnd = [ScriptParse getValueFromSummary:@"TestItemIndexMagnetHallEnd"];
    NSArray *arrayTestItemIndexMagnetHallEnd = [TestItemIndexMagnetHallEnd componentsSeparatedByString:@","];
    BOOL bMagnetHallStation = FALSE;
    NSString *tmpMagnetHallS = [ScriptParse getValueFromSummary:@"TestStation"];
    if([tmpMagnetHallS rangeOfString:@"Magnet-Hall"].length > 0)
        bMagnetHallStation = true;
    
    BOOL randomIsEvenValue = FALSE;
    int t2 = random();
    if(t2%2 == 0)
        randomIsEvenValue = TRUE;
    //====JianSheng 2014-01-14 Change End: ramdom to start test Magnet and Hall Sensor items===========
    
	//SCRID:155 end
	RetestItemName=@"";
	for(int i=0 ;i<[mutArrayTestItemList count]; i++)
	{
        //====JianSheng 2014-01-14 Change: ramdom to start test Magnet and Hall Sensor items===========
        if(bMagnetHallStation)
        {
            if([arrayTestItemIndexMagnetHallEnd count] >= 3)
            {
                if(randomIsEvenValue)
                {
                    if(i == [[arrayTestItemIndexMagnetHallEnd objectAtIndex:0] intValue] - 1)
                        i = [[arrayTestItemIndexMagnetHallEnd objectAtIndex:1] intValue] - 1;
                    else if(i == [[arrayTestItemIndexMagnetHallEnd objectAtIndex:2] intValue])
                        i = [[arrayTestItemIndexMagnetHallEnd objectAtIndex:0] intValue] - 1;
                    else if(i == [[arrayTestItemIndexMagnetHallEnd objectAtIndex:1] intValue] - 1)
                        i = [[arrayTestItemIndexMagnetHallEnd objectAtIndex:2] intValue];
                }
            }
        }
        //====JianSheng 2014-01-14 Change End: ramdom to start test Magnet and Hall Sensor items===========
        
		//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
		if([[arrayTestCount objectAtIndex:i] intValue]<2)
		{
			retestCount=[[arrayTestCount objectAtIndex:i] intValue]+1;
			[arrayTestCount replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%d", retestCount]];
		}
		else
		{
			//retestFlag=TRUE;
			continue;
		}
		//SCRID:155 end
		
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		//refresh the total time and item time 
		if (i==0)
		{
			//begin to refresh timer
			NSMutableDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
			if (dictTmp!=nil)
			{
				[dictTmp setObject:@"YES" forKey:@"RefreshTimeStatus"] ;
				NSThread *threadRefreshTimer = [dictTmp objectForKey:@"RefreshTime"] ;
				if (threadRefreshTimer!=nil)
					[threadRefreshTimer start] ;
			}	
			[textItemTime setStringValue:@"0.0"] ;
			//SCRID:77 Description:Add "UI1GaussDOE1440X900" parser for Magnet Retention by Helen 20110214
			if(![[ScriptParse getValueFromSummary:STRKEYSWITCHUI] isEqualToString:@"UI1GaussDOE"])
			//SCRID:77 end
				[textTotalTime setStringValue:@"0.0"] ;
		}else
		{
			float fItemtime = [[textItemTime stringValue] floatValue] ;
			float fTotaltime = [[textTotalTime stringValue] floatValue] ;
			[textItemTime setStringValue:@"0.0"] ;
			[textTotalTime setStringValue:[NSString stringWithFormat:@"%5.2f",fItemtime+fTotaltime]] ;
			
			///set the cycle time to log 
			NSString *strLogInfo = [NSString stringWithFormat:@"[Cycle Time :%5.2f s]",fItemtime];
			[self setUnitLogInfo:dictParam :strLogInfo :false];
		}
		
		//check current thread status
		NSMutableDictionary *mutdictThreadinfo = [mutDictTestItemThread objectForKey:strDutID] ;
		if (mutdictThreadinfo==nil)
		{
			[pool release];
			break ;
		};
		
		NSString *strThreadStatus=[mutdictThreadinfo objectForKey:@"ThreadStatus"] ;
		if (strThreadStatus==nil)
		{
			[pool release];
			break ;
		};
		
		if ([strThreadStatus isEqualToString:@"cancel"])
		{
			[pool release];
			break ;
		};
		/*SCRID-146: for resove the ui crash. Judith, 2011-12-02*/
		NSAutoreleasePool *tabViewDisplayPool22 = [[NSAutoreleasePool alloc] init] ;
		//[tableView reloadData] ;//dsx 0602
        //[tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES ];
		// set ui current row .
#if 0
        if(!bMagnetHallStation)
        {
            if ([strSeleToRow boolValue])
            {
                [tableView scrollRowToVisible:i];
                if([ScriptParse getValueFromSummary:@"FocusRowIndex"]==nil)//dsx 03-18
                    //[tableView selectRowIndexes:i byExtendingSelection:NO];//remarked by caijunbo on20100913.for that function is Deprecated after 10.3
                    [tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
            }else
            {
                [tableView scrollColumnToVisible:i];
                [tableView selectColumn:i byExtendingSelection:NO];
            }
        }
        
#else
        if(!bMagnetHallStation)
        {
#if 0
            g_TestIndex = i;
            if ([strSeleToRow boolValue])
            {
                //[tableView scrollRowToVisible:i];
                [testObject performSelectorOnMainThread:@selector(test1:) withObject:tableView waitUntilDone:NO ];
                if([ScriptParse getValueFromSummary:@"FocusRowIndex"]==nil)//dsx 03-18
                    //[tableView selectRowIndexes:i byExtendingSelection:NO];//remarked by caijunbo on20100913.for that function is Deprecated after 10.3
                    //[tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
                    [testObject performSelectorOnMainThread:@selector(test2:) withObject:tableView waitUntilDone:NO ];
            }else
            {
                //[tableView scrollColumnToVisible:i];
                //[tableView selectColumn:i byExtendingSelection:NO];
                [testObject performSelectorOnMainThread:@selector(test3:) withObject:tableView waitUntilDone:NO ];
                [testObject performSelectorOnMainThread:@selector(test4:) withObject:tableView waitUntilDone:NO ];
            }
#else
            if ([strSeleToRow boolValue]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    //[tableView reloadDataForRowIndexes:[NSIndexSet indexSetWithIndex:i] columnIndexes:[NSIndexSet indexSetWithIndex:1]];
                    [tableView scrollRowToVisible:i];
                    if([ScriptParse getValueFromSummary:@"FocusRowIndex"] == nil)
                    {
                        [tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
                    }
                });
            }
            else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [tableView scrollColumnToVisible:i];
                    [tableView selectColumnIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
                });
            }
#endif
        }
        
#endif
		//[tableView display] ;
        //[tableView performSelectorOnMainThread:@selector(display) withObject:nil waitUntilDone:YES ];
		[tabViewDisplayPool22 release];
		/*SCRID-146: end*/
		NSMutableDictionary *dictTestItemInfoTmp = [mutArrayTestItemList objectAtIndex:i] ;
		if (dictTestItemInfoTmp==nil)
		{
			[tableView performSelectorOnMainThread:@selector(displayIfNeeded) withObject:nil waitUntilDone:NO ];
            [pool release];
			break ;
		};
		
		//clear current test result info
		//[dictTestItemInfoTmp removeObjectForKey:TestItemResult] ;
		//get the cureent item test action .
		NSArray *arrayActionTmp = [dictTestItemInfoTmp objectForKey:TestitemAction];
		if (arrayActionTmp==nil)
		{
			[tableView performSelectorOnMainThread:@selector(displayIfNeeded) withObject:nil waitUntilDone:NO ];
            [pool release];
			break ;
		};
		[self setUnitLogInfoTitle:dictParam :i:0:0];
		NSMutableDictionary *mutDictTmp =[[NSMutableDictionary alloc] init] ;
		for(int j=0 ;j<[arrayActionTmp count] ;j++)
		{
			textItemIndexWhenStopFail = j;
			if ([strThreadStatus isEqualToString:@"cancel"])
				break ;
			[self setUnitLogInfoTitle:dictParam :i:j:1];
			
			[mutDictTmp removeAllObjects] ;//Clear all old param .
			[mutDictTmp addEntriesFromDictionary:[arrayActionTmp objectAtIndex:j]] ;
			//add device id info
			//dictParam
			NSString *strUNITDevice=[dictParam objectForKey:@"UNITDevice"] ;
			NSArray *arrayFixtureDevice =[dictParam objectForKey:@"FixtureDevice"];
			NSString *strDUTID = [dictParam objectForKey:@"DUTID"] ;
			
			[mutDictTmp setObject:strUNITDevice forKey:@"UNITDevice"]  ;
			[mutDictTmp setObject:strDUTID forKey:@"DUTID"]  ;
			if (arrayFixtureDevice!=nil)
				[mutDictTmp setObject:arrayFixtureDevice forKey:@"FixtureDevice"] ;
			
			//SET current test item index to Dictionary
			NSString *strTestItemIndex=[NSString stringWithFormat:@"%d",i]  ;
			[mutDictTmp setObject:strTestItemIndex forKey:@"TestItemIndex"] ;
			//Set current test action index to dictionary
			NSString *strTestActionIndex =[NSString stringWithFormat:@"%d",j];
			[mutDictTmp setObject:strTestActionIndex forKey:@"TestActionIndex"] ;
			//perform the task 
			//[TestItemParse performParseFunction:mutDictTmp] ;
            @try {
                NSString *strName = [mutDictTmp objectForKey:TSName] ;
                //NSLog(strName);
                if ((strName!=nil && [strName isEqualToString:@"CBCheckAndInit"])||(strName!=nil && [strName isEqualToString:@"HandleFataErrorAndCBToClear"]) ){
                    [g_TestItemFunLock lock];
                    [TestItemParse performParseFunction:mutDictTmp];
                    NSLog(@"strName:%@",strName);
                    [g_TestItemFunLock unlock];
                }else{
                    [TestItemParse performParseFunction:mutDictTmp];
                }
                
            }
            @catch (NSException *exception) {
                NSLog(@"NSException !!!!");
                //[pool release];
                NSString *strName = [mutDictTmp objectForKey:TSName] ;
                if ((strName!=nil && [strName isEqualToString:@"CBCheckAndInit"])||(strName!=nil && [strName isEqualToString:@"HandleFataErrorAndCBToClear"]) ){
                    [g_TestItemFunLock unlock];
                }
                break ;
            }
            @finally {
                ;
            }
		//	[tableView reloadData] ;//dsx 0602  //add by judith 20111202
			
			//set SN value
			[self setSYSSN:mutDictTmp];
		
		}
		
		//set PDCA log .
		[self setPDCAInfo:mutDictTmp :i];
		
		//added by caijunbo on 2011-09-28
		//used to handle Network based CB failure
		[self handleNetWorkCBFail:mutDictTmp newTestItemIndex:&i newTestItemActionIndex:&textItemIndexWhenStopFail];
		//end added by caijunbo on 2011-09-28
		
		//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104
		NSString* strRetestFlag = [mutDictTmp objectForKey:STRKEYRETESTITEMS];
		//SCRID:155 end
		
		if((strRetestFlag == nil) || (retestCount > 1))
		{
			//HANDLE STOP TO FAIL
			//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
			if([UICommon getStopFailFlag])
			{
				[self btnHandleStopFail:mutDictTmp newTestItemIndex:&i newTestItemActionIndex:&textItemIndexWhenStopFail];
				[UICommon setStopFailFlag:NO];
			}
			else
			{
				[self handleStopFail:mutDictTmp newTestItemIndex:&i newTestItemActionIndex:&textItemIndexWhenStopFail] ;
			}
			//SCRID:109 end
		}
		
		//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
		[self handleRetestItems:mutDictTmp newTestItemIndex:&i];
		//SCRID:155 end
		
		[mutDictTmp release] ;
		//set test item result
		/*SCRID-146: for resove the ui crash. Judith, 2011-12-02*/
		NSAutoreleasePool *tabViewDisplayPool33 = [[NSAutoreleasePool alloc] init] ;//add by judith 20111202
        //[tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES ];
        dispatch_async(dispatch_get_main_queue(), ^{
            [tableView reloadDataForRowIndexes:[NSIndexSet indexSetWithIndex:i] columnIndexes:[NSIndexSet indexSetWithIndex:1]];
            //[tableView displayIfNeeded];
        });
        //[tableView reloadData] ;
		//[tableView display] ;//add by judith 20111202
		[tabViewDisplayPool33 release];
		/*SCRID-146: end*/
	}
	
	//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
	[arrayTestCount removeAllObjects];
	//SCRID:155 end
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	
	//cancel refresh thread 
	NSMutableDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
	if (dictTmp!=nil)
		[dictTmp setObject:@"NO" forKey:@"RefreshTimeStatus"] ;
	
	//refresh the total time and item time 
	float fItemtime = [[textItemTime stringValue] floatValue] ;
	float fTotaltime = [[textTotalTime stringValue] floatValue] ;
	[textItemTime setStringValue:@"0.0"] ;
	[textTotalTime setStringValue:[NSString stringWithFormat:@"%5.2f",fItemtime+fTotaltime]] ;	
	///set the cycle time to log 
	NSString *strLogInfo = [NSString stringWithFormat:@"[Cycle Time :%5.2f s]",fItemtime];
	NSString *strLogInfoTotal = [NSString stringWithFormat:@"[Total Cycle Time :%5.2f s]",fItemtime+fTotaltime];
	
	
	[self setUnitLogInfo:dictParam :strLogInfo :false];
	[self setUnitLogInfo:dictParam :strLogInfoTotal :false];
    ///refresh the test result 
	[self amountResultRefresh:strDutID :textPassOrFail ] ;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self amountResultRefresh:strDutID :textPassOrFail] ;
        [textPassOrFail display];
        [tableView display];
    });
    
	[pool release] ;
	
	return ;
}
// Owner:Henry DATE :1.19.2011  SCRID:66 Desc  :Add for QT3
+(void)testEngineerThreadQT3:(NSDictionary*)dictParam 
{	
	int textItemIndexWhenStopFail = 1;
	if (mutDictTestItemActionInfo==nil)
	{
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	}
	
	if (dictParam==nil)
		return ;
	
	//get key value ;
	NSTableView* tableView = [dictParam objectForKey:@"TableView"] ;
	NSString *strDutID = [dictParam objectForKey:@"DUTID"];
	NSString *strSeleToRow = [dictParam objectForKey:@"SelectToRow"];
	if (tableView==nil ||
		strDutID==nil ||
		strSeleToRow==nil 
		)
		return ;
	//get TOTALITEMTime ,ITEMTime point
	NSTextField *textTotalTime=nil ,*textItemTime =nil, *textPassOrFail=nil ;
	textTotalTime = [dictParam objectForKey:@"TotalTimeField"] ;
	textItemTime = [dictParam objectForKey:@"ItemTimeField"] ;
	textPassOrFail = [dictParam objectForKey:@"ShowPassOrFail"] ;
	if (textItemTime==nil ||
		textTotalTime==nil ||
		textPassOrFail==nil
		)
		return  ;
	
	//clear old message .
	[self clearTestActionInfo:strDutID] ;
	NSAutoreleasePool *tabViewDisplayPool = [[NSAutoreleasePool alloc] init] ; //add by henry 20100828 , if no auto realease pool ,it will lead to memory leak !
	[tableView reloadData] ; //modified by caijunbo on 20100913 if has no auto realease pool ,it will lead  memory leaking too!
	
	//[tableView display] ;//add by giga
	[tabViewDisplayPool release];
	
	if (mutArrayTestItemList==nil)
		return ;
	
	//Set Scan data
	NSAutoreleasePool *scandataPool = [[NSAutoreleasePool alloc] init] ;
	NSDictionary *dictScanData = [dictParam objectForKey:@"ScanDataForUI"] ;
	if (dictScanData!=nil)
	{
		NSArray *arrTmpScan = [dictScanData allKeys] ;
		for (int i=0;i<[arrTmpScan count] ;i++)
		{
			NSString *strKey = [arrTmpScan objectAtIndex:i] ;
			NSString *strValue = [dictScanData objectForKey:strKey] ;
			[self setScanValue:[strDutID intValue] :strKey :strValue] ;
		}
	}
	[scandataPool release] ;
	//scan data end 
	
	int mUIItems[3];
	NSString *strUITestItems = [ScriptParse getValueFromSummary:STRKEYQT3UIITEMS] ;
	if(strUITestItems != nil)
	{
		NSArray *tmpAry= [strUITestItems componentsSeparatedByString:@","];
		for(int i=0;i<3;i++)
			mUIItems[i]=[[tmpAry objectAtIndex:i] intValue];
	}
	else 
	{
		for(int i=0;i<3;i++)
			mUIItems[i]=1;
	}
	
	for(int i=0 ;i<[mutArrayTestItemList count]; i++)
	{
/*		if(t1)
			T1ItemIndex
		if
*/		
		
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ; //modified by Henry  2011-02-22

		NSString *strObject=@"statusBar"; 
		strObject=[strObject stringByAppendingString:strDutID];
		
		if(i>(mUIItems[0]+mUIItems[1]-1))
		{
			tableView = [UICommon getObjectFromUIComm:@"tableView13"] ;
		}
		else if(i>(mUIItems[0]-1))
		{
			tableView = [UICommon getObjectFromUIComm:@"tableView12"] ;
		}
		
		//refresh the total time and item time 
		if (i==0)
		{
			//begin to refresh timer
			NSMutableDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
			if (dictTmp!=nil)
			{
				[dictTmp setObject:@"YES" forKey:@"RefreshTimeStatus"] ;
				NSThread *threadRefreshTimer = [dictTmp objectForKey:@"RefreshTime"] ;
				if (threadRefreshTimer!=nil)
					[threadRefreshTimer start] ;
			}	
			[textItemTime setStringValue:@"0.0"] ;
			[textTotalTime setStringValue:@"0.0"] ;
		}else
		{
			float fItemtime = [[textItemTime stringValue] floatValue] ;
			float fTotaltime = [[textTotalTime stringValue] floatValue] ;
			[textItemTime setStringValue:@"0.0"] ;
			[textTotalTime setStringValue:[NSString stringWithFormat:@"%5.2f",fItemtime+fTotaltime]] ;
			
			///set the cycle time to log 
			NSString *strLogInfo = [NSString stringWithFormat:@"[Cycle Time :%5.2f s]",fItemtime];
			[self setUnitLogInfo:dictParam :strLogInfo :false];
		}
		
		//check current thread status
		NSMutableDictionary *mutdictThreadinfo = [mutDictTestItemThread objectForKey:strDutID] ;
		if (mutdictThreadinfo==nil)
		{
			[pool release];
			break ;
		};
		
		NSString *strThreadStatus=[mutdictThreadinfo objectForKey:@"ThreadStatus"] ;
		if (strThreadStatus==nil)
		{
			[pool release];
			break ;
		};
		
		if ([strThreadStatus isEqualToString:@"cancel"])
		{
			[pool release];
			break ;
		};
		
		// set ui current row .
		if ([strSeleToRow boolValue])
		{
			[tableView scrollRowToVisible:i];
			//[tableView selectRowIndexes:i byExtendingSelection:NO];//remarked by caijunbo on20100913.for that function is Deprecated after 10.3
			[tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:i] byExtendingSelection:NO];
		}else
		{
			[tableView scrollColumnToVisible:i];
			[tableView selectColumn:i byExtendingSelection:NO];
		}
		[tableView reloadData] ;
		
		NSMutableDictionary *dictTestItemInfoTmp = [mutArrayTestItemList objectAtIndex:i] ;
		if (dictTestItemInfoTmp==nil)
		{
			[pool release];
			break ;
		};
		
		//clear current test result info
		//[dictTestItemInfoTmp removeObjectForKey:TestItemResult] ;
		//get the cureent item test action .
		NSArray *arrayActionTmp = [dictTestItemInfoTmp objectForKey:TestitemAction];
		if (arrayActionTmp==nil)
		{
			[pool release];
			break ;
		};
		[self setUnitLogInfoTitle:dictParam :i:0:0];
		NSMutableDictionary *mutDictTmp =[[NSMutableDictionary alloc] init] ;
		for(int j=0 ;j<[arrayActionTmp count] ;j++)
		{
			textItemIndexWhenStopFail=j;
			if ([strThreadStatus isEqualToString:@"cancel"])
				break ;
			[self setUnitLogInfoTitle:dictParam :i:j:1];
			
			[mutDictTmp removeAllObjects] ;//Clear all old param .
			[mutDictTmp addEntriesFromDictionary:[arrayActionTmp objectAtIndex:j]] ;
			//add device id info
			//dictParam
			NSString *strUNITDevice=[dictParam objectForKey:@"UNITDevice"] ;
			NSArray *arrayFixtureDevice =[dictParam objectForKey:@"FixtureDevice"];
			NSString *strDUTID = [dictParam objectForKey:@"DUTID"] ;
			
			[mutDictTmp setObject:strUNITDevice forKey:@"UNITDevice"]  ;
			[mutDictTmp setObject:strDUTID forKey:@"DUTID"]  ;
			if (arrayFixtureDevice!=nil)
				[mutDictTmp setObject:arrayFixtureDevice forKey:@"FixtureDevice"] ;
			
			//SET current test item index to Dictionary
			NSString *strTestItemIndex=[NSString stringWithFormat:@"%d",i]  ;
			[mutDictTmp setObject:strTestItemIndex forKey:@"TestItemIndex"] ;
			//Set current test action index to dictionary
			NSString *strTestActionIndex =[NSString stringWithFormat:@"%d",j];
			[mutDictTmp setObject:strTestActionIndex forKey:@"TestActionIndex"] ;
			
			//added by caijunbo on 2011-01-26   used to set uart port status used or unused
			//position one
			
			
			[TestItemParse performParseFunction:mutDictTmp];
			
			//set SN value
			[self setSYSSN:mutDictTmp];
			
			
			//added by caijunbo on 2011-09-28
			//used to handle Network based CB failure
			
			//end added by caijunbo on 2011-09-28
			
			//HANDLE STOP TO FAIL
			
		}
		//set PDCA log .
		[self setPDCAInfo:mutDictTmp :i];
		
		[self handleNetWorkCBFail:mutDictTmp newTestItemIndex:&i newTestItemActionIndex:&textItemIndexWhenStopFail];
		[ self handleStopFail:mutDictTmp newTestItemIndex:&i newTestItemActionIndex:&textItemIndexWhenStopFail] ;
		[mutDictTmp release] ;
		//set test item result
		[tableView reloadData] ;
		[pool release] ;
	}
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
	
	//cancel refresh thread 
	NSMutableDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
	if (dictTmp!=nil)
		[dictTmp setObject:@"NO" forKey:@"RefreshTimeStatus"] ;
	
	//refresh the total time and item time 
	float fItemtime = [[textItemTime stringValue] floatValue] ;
	float fTotaltime = [[textTotalTime stringValue] floatValue] ;
	[textItemTime setStringValue:@"0.0"] ;
	[textTotalTime setStringValue:[NSString stringWithFormat:@"%5.2f",fItemtime+fTotaltime]] ;	
	///set the cycle time to log 
	NSString *strLogInfo = [NSString stringWithFormat:@"[Cycle Time :%5.2f s]",fItemtime];
	NSString *strLogInfoTotal = [NSString stringWithFormat:@"[Total Cycle Time :%5.2f s]",fItemtime+fTotaltime];
	
	[self setUnitLogInfo:dictParam :strLogInfo :false];
	[self setUnitLogInfo:dictParam :strLogInfoTotal :false];
    ///refresh the test result 
	[self amountResultRefresh:strDutID :textPassOrFail ] ;
	
	//henry add 2011-01-24 for proxCal
//	[UICommon objectBlinkStop:[UICommon getObjectFromUIComm:@"statusBar13"] indexBox:([strDutID intValue]-1) indexBar:2];
//	[UICommon objectBlinkStart:[UICommon getObjectFromUIComm:@"statusBar11"] indexBox:([strDutID intValue]-1) indexBar:0];

	[pool release] ;
	
	return ;
}

//+(void)whoAmI

+(void)testTimerRefresh:(NSDictionary*)dictParam //Refresh timer
{
	if (mutDictTestItemThread==nil ||
		dictParam==nil
		)
		return ;
	NSTextField *totalTime =[dictParam objectForKey:@"TotalTimeField"] ;
	NSTextField *itemTime = [dictParam objectForKey:@"ItemTimeField"] ;
	if (totalTime ==nil ||
		itemTime ==nil
		)
		return ;
	NSString *strDutID = [dictParam objectForKey:@"DUTID"];
	if (strDutID==nil)
		return ;
	
	NSDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
	if (dictTmp==nil)
		return ;
	
	NSString *strStatus = [dictTmp objectForKey:@"RefreshTimeStatus"];
	if (strStatus==nil)
		return ;
	while ([strStatus boolValue])
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		
		float fItemtime = [[itemTime stringValue] floatValue] ;
		fItemtime +=0.1 ;
		[itemTime setStringValue:[NSString stringWithFormat:@"%5.2f",fItemtime]] ;
		//[itemTime display];//add by Giga
        
        NSDictionary *dictTmp = [mutDictTestItemThread objectForKey:strDutID] ;
        if (dictTmp==nil){
            [pool release] ;
            break;
        }
        
		strStatus = [dictTmp objectForKey:@"RefreshTimeStatus"];
		if (strStatus==nil)
			strStatus = @"NO" ;
		usleep(100000) ;
		[pool release] ;
	}
};

//set the test result
+(void)setTestItemResult:(int)DUTID :(int)testItemIndex :(enum TestResutStatus)enumResult
{
	if (mutArrayTestItemList==nil)
		return ;
	
	if (testItemIndex >= [mutArrayTestItemList count])
		return ;
	
	NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:testItemIndex] ;
	
	if (mutdictTmp==nil)
		return ;
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestItemResult"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"TestItemResult"] ;
	}
	/*
	 NSString *strResult=nil ;
	 switch (enumResult) 
	 {
	 case RESULT_FOR_PASS:
	 strResult = @"RESULT_FOR_PASS";
	 break;
	 case RESULT_FOR_FAIL:
	 strResult = @"RESULT_FOR_FAIL";
	 break;	
	 case RESULT_FOR_COF:
	 strResult = @"RESULT_FOR_COF";
	 break;
	 case RESULT_FOR_BYPASS:
	 strResult = @"RESULT_FOR_BYPASS";
	 break;	
	 case RESULT_FOR_OTHER:
	 strResult=@"RESULT_FOR_OTHER" ;
	 break ;
	 default:
	 strResult = @"RESULT_FOR_PASS" ;
	 }
	 [mutdictTmp1 setObject:strResult forKey:[NSString stringWithFormat:@"%d-Result",DUTID]] ;
	 */
	[mutdictTmp1 setObject:[NSNumber numberWithInt:enumResult] forKey:[NSString stringWithFormat:@"%d-Result",DUTID]] ;
	return ;	
} ;

+(void)setTestActionResult:(int)DUTID :(int)testItemIndex :(enum TestResutStatus)enumResult
{
	if (mutArrayTestItemList==nil)
		return ;
	
	if (testItemIndex >= [mutArrayTestItemList count])
		return ;
	
	NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:testItemIndex] ;
	
	if (mutdictTmp==nil)
		return ;
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestActionResult"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"TestActionResult"] ;
	}
	[mutdictTmp1 setObject:[NSNumber numberWithInt:enumResult] forKey:[NSString stringWithFormat:@"%d-Result",DUTID]] ;
	return ;	
}

+(void)setTestItemResultForUI:(int)DUTID :(int)testItemIndex :(NSString*)strResultForUI :(enum TestResutStatus)resultParm
{
	if (strResultForUI==nil ||
		mutArrayTestItemList==nil
		)
		return ;
	
	if (testItemIndex >= [mutArrayTestItemList count])
		return ;
	
	NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:testItemIndex] ;
	
	if (mutdictTmp==nil)
		return ;
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestItemResult"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"TestItemResult"] ;
	}
	//set ui show color
	NSColor *color=nil ;
	switch (resultParm) 
	{
		case RESULT_FOR_PASS:
		case RESULT_FOR_COF:	
		case RESULT_FOR_BYPASS:	
			color = [NSColor blueColor];
			break;
		case RESULT_FOR_FAIL:
		case RESULT_FOR_OTHER:		
			color = [NSColor redColor];
			break;	
		default :
			color = [NSColor grayColor];
	}		
	NSDictionary *txtDict = [NSDictionary dictionaryWithObjectsAndKeys:[NSFont userFontOfSize:13],NSFontAttributeName,color,NSForegroundColorAttributeName ,nil];
	NSAttributedString *attrStr1 = [[[NSAttributedString alloc] initWithString:strResultForUI attributes:txtDict] autorelease] ;						 
	[mutdictTmp1 setObject:attrStr1 forKey:[NSString stringWithFormat:@"%d-UIInfo",DUTID]] ;
	return ;	
};


//according with Data parse 
+(NSString*)getBufferValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey ;
{
	if (mutDictTestItemActionInfo==nil ||
		dictUNITInfo==nil ||
		strKey ==nil 
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	dictTmp = [dictTmp objectForKey:@"UnitBufferInfo"] ;
	if (dictTmp==nil)
		return nil ;
	
	return [dictTmp objectForKey:strKey] ;
	
	
};

+(void)setBufferValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue
{
	if (dictUNITInfo==nil ||
		strKey ==nil  ||
		strValue==nil
		)
		return ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"UnitBufferInfo"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"UnitBufferInfo"] ;
	}
	//delete prefix postfix space.
	[mutdictTmp1 setObject:[pubFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] forKey:strKey] ;
	return ;
};

+(NSString*)getSFCValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey
{
	if (mutDictTestItemActionInfo==nil ||
		dictUNITInfo==nil ||
		strKey ==nil 
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	dictTmp = [dictTmp objectForKey:@"UnitSFCInfo"] ;
	if (dictTmp==nil)
		return nil ;
	
	return [dictTmp objectForKey:strKey] ;
	
	
};

+(void)setSFCValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue
{
	if (dictUNITInfo==nil ||
		strKey ==nil  ||
		strValue==nil
		)
		return ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"UnitSFCInfo"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"UnitSFCInfo"] ;
	}
	
	[mutdictTmp1 setObject:[pubFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] forKey:strKey] ;
	return ;
};

+(NSString*)getUnitValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey
{
	if (mutDictTestItemActionInfo==nil ||
		dictUNITInfo==nil ||
		strKey ==nil 
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	dictTmp = [dictTmp objectForKey:@"UnitOwnInfo"] ;
	if (dictTmp==nil)
		return nil ;
	
	//NSLog(@"\n%@",dictTmp) ;
	return [dictTmp objectForKey:strKey] ;
	
};

+(void)setUnitValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey : (NSString*)strValue
{
	if (dictUNITInfo==nil ||
		strKey ==nil  ||
		strValue==nil
		)
		return ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"UnitOwnInfo"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"UnitOwnInfo"] ;
	}
	
	[mutdictTmp1 setObject:[pubFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] forKey:strKey] ;
	return ;
};

+(NSString*)getUnitLogInfo:(int)DUTID
{	
	NSString *strDUTID=[NSString stringWithFormat:@"%d",DUTID] ;
	
	if (mutDictTestItemActionInfo==nil)
		return nil ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	    return nil ;
	
	return [mutdictTmp objectForKey:@"UnitLogInfo"] ;
};

+(void)setUnitLogInfo:(NSDictionary*)dictUNITInfo :(NSString*)strLogInfo :(bool)bWriteDataTime
{
	if (dictUNITInfo==nil ||
		strLogInfo ==nil
		)
		return ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableString *mutStrTmp1 = [mutdictTmp objectForKey:@"UnitLogInfo"] ;
	if (mutStrTmp1==nil)
	{
		mutStrTmp1 = [[[NSMutableString alloc] init] autorelease] ;
		[mutdictTmp setObject:mutStrTmp1 forKey:@"UnitLogInfo"] ;
	}
	
	NSString *strAppLog =  nil ;
	NSString * date = [[NSCalendarDate date] descriptionWithCalendarFormat:@"%Y-%m-%d %H:%M:%S:%F" timeZone:nil locale:nil];
	
	if (bWriteDataTime)
		//strAppLog= [NSString stringWithFormat:@"\n      [%@]:%@",[[NSCalendarDate date] description],strLogInfo];
		strAppLog= [NSString stringWithFormat:@"\n      [%@]:%@",date,strLogInfo];//time print in log precision to millionsecond, add by Annie
	else
		strAppLog= [NSString stringWithFormat:@"\n      %@",strLogInfo];
	
	[mutStrTmp1 appendString:strAppLog] ;
	
	NSString *StrFileName = [self generalLogFileName:dictUNITInfo] ;
	if (StrFileName!=nil)
	{
		NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:StrFileName];
		if (filehandTmp!=nil)
		{
			[filehandTmp seekToEndOfFile] ;
			[filehandTmp writeData:[NSData dataWithData:[strAppLog dataUsingEncoding:NSASCIIStringEncoding]]] ;
			[filehandTmp closeFile] ;
		}
	}
	
	return ;
};

+(NSString*)generalLogFileName:(NSDictionary*)dictUNITInfo //general file name ,and return the filename ;
{
	if (dictUNITInfo==nil)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	//step 1: check whether exist filepath
	NSString *filePathStrTmp1 = [mutdictTmp objectForKey:@"UnitLogFilePath"] ;
	if (filePathStrTmp1==nil)
	{
		//step1.1 check whether exist SN.
		NSString* strSN =[self getUnitValue:dictUNITInfo :STRKEYSYSSN] ;
		if (strSN==nil)
			strSN = [NSString stringWithFormat:@"UUTLog_%@",strDUTID] ;
		NSString *strStationID=[ScriptParse getValueFromSummary:@"TestStation"] ;
		if (strStationID!=nil)
			strSN = [NSString stringWithFormat:@"%@_%@",strStationID,strSN] ;
		//plug date
		//20100902 Henry add fixtureId
		//		strSN = [NSString stringWithFormat:@"/AllLog/%@_%@.txt",strSN,[pubFun getCurrentDateTime]] ;
		NSString *fixtureId = [UICommon getFixtureID];
		if(fixtureId ==nil)
			strSN = [NSString stringWithFormat:@"/AllLog/%@_%@.txt",strSN,[pubFun getCurrentDateTime]] ;
		else
			strSN = [NSString stringWithFormat:@"/AllLog/%@_%@_%@.txt",strSN,fixtureId,[pubFun getCurrentDateTime]] ;
		//create fold //AllLog
		NSString *strFoldtmp = @"mkdir -p /AllLog";
		system([strFoldtmp cStringUsingEncoding:NSASCIIStringEncoding]);
		
        //create a empty file.
		[[NSString string] writeToFile:strSN atomically:NO encoding:NSASCIIStringEncoding error:NULL] ;
		
		[mutdictTmp setObject:strSN forKey:@"UnitLogFilePath"] ;
	}else //exist
	{
		//step1 check whether temp file
		
		NSRange rangTmp = [filePathStrTmp1 rangeOfString:@"UUTLog"] ;
		if (rangTmp.length > 0 && 
			[self getUnitValue:dictUNITInfo :STRKEYSYSSN] !=nil)  // temp file and exist sn
		{
			//re-create a new file and copy the data to new file 
			NSString *strOldFileName = [NSString stringWithString:filePathStrTmp1] ;
			NSMutableString *strNewFileName = [NSMutableString stringWithString:filePathStrTmp1] ;
			[strNewFileName replaceCharactersInRange:rangTmp withString:[self getUnitValue:dictUNITInfo :STRKEYSYSSN]] ; 
			[mutdictTmp setObject:[NSString stringWithString:strNewFileName] forKey:@"UnitLogFilePath"] ;
			rename([strOldFileName cStringUsingEncoding:NSASCIIStringEncoding], [strNewFileName cStringUsingEncoding:NSASCIIStringEncoding]) ;
		}
	}	
	
	return [mutdictTmp objectForKey:@"UnitLogFilePath"] ;
	
};

+(void)setUnitLogInfoTitle:(NSDictionary*)dictUNITInfo :(int)testItemIndex :(int)testActionIndex :(int)Layer  //0 --testitem ,1--testaction
{
	if (dictUNITInfo==nil)
		return ;
	
	if (mutArrayTestItemList==nil)
		return ;
	if (testItemIndex>=[mutArrayTestItemList count])
		return ;
	
	NSDictionary*dictTestItemInfo = [mutArrayTestItemList objectAtIndex:testItemIndex] ;
	if (dictTestItemInfo==nil)
		return ;
	//NSLog(@"%@",dictTestItemInfo);
	NSArray* arrayTestAction = [dictTestItemInfo objectForKey:TestitemAction] ;
	if (arrayTestAction==nil)
		return ;
	
	if (testActionIndex>=[arrayTestAction count])
		return ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableString *mutStrTmp1 = [mutdictTmp objectForKey:@"UnitLogInfo"] ;
	if (mutStrTmp1==nil)
	{
		mutStrTmp1 = [[[NSMutableString alloc] init] autorelease] ;
		[mutdictTmp setObject:mutStrTmp1 forKey:@"UnitLogInfo"] ;
	}
	//prepare header 
	NSString *strAppLog =nil ;
	if (Layer==0)
	{
		strAppLog = [NSString stringWithFormat:@"\n\n%d : %@",testItemIndex+1,[[mutArrayTestItemList objectAtIndex:testItemIndex] objectForKey:@"TestItemName"]];
		//joko add 2010-08-18
		if(strAppLog != nil)
		{
			NSString* ll = @""; 
			//			NSString* ll = [ToolFun getStrFromPrefixAndPostfix:strAppLog Prefix:@"[" Postfix:@"]"] ;
			int starLen = [strAppLog rangeOfString:@"["].location;
			starLen = starLen + 1;
			int endLen = [strAppLog rangeOfString:@"]"].location;
			if(endLen>starLen && [strAppLog length] >= endLen)
			{
				ll = [strAppLog substringFromIndex:starLen];
				endLen = [ll rangeOfString:@"]"].location;
				ll = [ll substringToIndex:endLen];
			}
			
			if(ll != nil && ([ll rangeOfString:@"pass"].length>0 || [ll rangeOfString:@"Pass"].length>0 || [ll rangeOfString:@"PASS"].length>0
							 || [ll rangeOfString:@"fail"].length>0 || [ll rangeOfString:@"Fail"].length>0 || [ll rangeOfString:@"FAIL"].length>0))
			{
				strAppLog = [strAppLog stringByReplacingOccurrencesOfString:ll withString: @""];
				//strAppLog = [strAppLog stringByReplacingOccurrencesOfString:@"]" withString: @""];
				//strAppLog = [strAppLog stringByReplacingOccurrencesOfString:@"[" withString: @""];
			}
		}
		//joko add end
	}
	else // action log title
	{
		strAppLog = [NSString stringWithFormat:@"\n      %d.%d : %@",testItemIndex+1,testActionIndex+1,[[arrayTestAction objectAtIndex:testActionIndex] objectForKey:@"TestScriptName"]];
		//joko add 2010-08-18
		NSString* tpp = [[arrayTestAction objectAtIndex:testActionIndex] objectForKey:@"StrSpec"];
		if(tpp!=nil && strAppLog!=nil)
		{
			strAppLog = [strAppLog stringByAppendingString: @" ["];
			strAppLog = [strAppLog stringByAppendingString: tpp];
			strAppLog = [strAppLog stringByAppendingString: @"]"];
		}
		//joko add end
	}
	[mutStrTmp1 appendString:strAppLog] ;
	
	NSString *StrFileName = [self generalLogFileName:dictUNITInfo] ;
	if (StrFileName!=nil)
	{
		NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:StrFileName];
		if (filehandTmp!=nil)
		{
			[filehandTmp seekToEndOfFile] ;
			[filehandTmp writeData:[NSData dataWithData:[strAppLog dataUsingEncoding:NSUTF8StringEncoding]]] ;
			[filehandTmp closeFile] ;
		}
	}
	
	return ;
};

+(NSString*)getScanValue:(NSDictionary*)dictUNITInfo :(NSString*)strKey 
{
	if (dictUNITInfo==nil ||
		strKey ==nil
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	dictTmp = [dictTmp objectForKey:@"UnitScanInfo"] ;
	if (dictTmp==nil)
		return nil ;
	
	return [dictTmp objectForKey:strKey] ;
};

+(void)setScanValue:(int)DUTID :(NSString*)strKey : (NSString*)strValue
{
	if (strKey ==nil  ||
		strValue==nil
		)
		return ;
	
	NSString *strDUTID=[NSString stringWithFormat:@"%d",DUTID] ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"UnitScanInfo"] ;
	if (mutdictTmp1==nil)
	{
		mutdictTmp1 = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutdictTmp setObject:mutdictTmp1 forKey:@"UnitScanInfo"] ;
	}
	
	[mutdictTmp1 setObject:[pubFun allTrimFromString:strValue trimStr:@" " leftTrim:true rightTrim:true] forKey:strKey] ;
	return ;
};

+(bool)checkPriorTestItemResult:(NSDictionary*)dictUNITInfo //check prior test item result ,fail --false ,
{
	if (mutArrayTestItemList==nil )
		return false ;
	
	NSString *strDUTID,*strTestItemIndex ;
	strDUTID = [dictUNITInfo objectForKey:@"DUTID"] ;
	strTestItemIndex = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
	
	if (strDUTID==nil || strTestItemIndex==nil)
		return false ;
	
	if ([strTestItemIndex intValue] >= [mutArrayTestItemList count])
		return  false ;
    if ([strTestItemIndex intValue]==0)
		return true ;
	
	int iPriorTestIndex = [strTestItemIndex intValue] -1 ;
	//get prior test item result 
	NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:iPriorTestIndex] ;
	
	if (mutdictTmp==nil)
		return false ;
	
	NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestItemResult"] ;
	if (mutdictTmp1==nil)
		return false ;
	
	NSNumber *numberTmp = [mutdictTmp1 objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]];
	if (numberTmp==nil)
		return false ;
	switch ([numberTmp intValue]) 
	{
		case RESULT_FOR_PASS:
		case RESULT_FOR_BYPASS :
			return true ;
			break ;
		default:
			return false ;
	};
	
	return false ;
};

+(bool)checkPriorAllTestItemResult:(NSDictionary*)dictUNITInfo //check prior all test item result .
{
	if (mutArrayTestItemList==nil )
		return false ;
	
	NSString *strDUTID,*strTestItemIndex ;
	strDUTID = [dictUNITInfo objectForKey:@"DUTID"] ;
	strTestItemIndex = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
	
	if (strDUTID==nil || strTestItemIndex==nil)
		return false ;
	
	if ([strTestItemIndex intValue] >= [mutArrayTestItemList count])
		return  false ;
    if ([strTestItemIndex intValue]==0)
		return true ;
	
	int iPriorTestIndex = [strTestItemIndex intValue] -1 ;
	//get prior  all test item result
	for(int i=0 ;i<=iPriorTestIndex ;i++)
	{
		NSMutableDictionary *mutdictTmp=[mutArrayTestItemList objectAtIndex:i] ;
		
		if (mutdictTmp==nil)
			return false ;
		
		NSMutableDictionary *mutdictTmp1 = [mutdictTmp objectForKey:@"TestItemResult"] ;
		if (mutdictTmp1==nil)
			return false ;
		
		NSNumber *numberTmp = [mutdictTmp1 objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]];
		if (numberTmp==nil)
			return false ;
		switch ([numberTmp intValue]) 
		{
			case RESULT_FOR_PASS:
			case RESULT_FOR_BYPASS :
				break ;
			default:
				return false ;
		};
	}
	return true ;
};

+(NSArray*)getPDCAInfo:(NSDictionary*)dictUNITInfo  //get PDCA info
{
	if (mutDictTestItemActionInfo==nil ||
		dictUNITInfo==nil
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	//NSLog(@"\n get PDCA log is %@\n",[dictTmp objectForKey:@"UnitPDCAInfo"]) ;
	return [dictTmp objectForKey:@"UnitPDCAInfo"] ;
};

//set subtest item PDCA Log
+(void)setSubItemPDCAInfo:(NSDictionary*)dictUNITInfo 
						 :(NSString*)SubItem    
						 :(NSString*)SubSubItem
						 :(NSString*)LowLimit 
                         :(NSString*)UpLimit
                         :(NSString*)TestValue
                         :(NSString*)TestUnit
                         :(enum TestResutStatus)enumTestResult
                         :(NSString*)FailMsg  
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil ||
        SubItem==nil ||
		TestValue==nil 
		)
		return ;	
	
	//prepare PDCA data .
	NSString *strTestName=[dictUNITInfo objectForKey:@"TestItemName"] ;
	NSString *strSubTestItem = SubItem ;
	NSString *strSubSubTestItem = SubSubItem ;
	NSString *strLowLimit = LowLimit ;
	NSString *strUpLimit = UpLimit ;
	NSString *strTestUnit = TestUnit ;
	NSString *strTestValue = TestValue ;
	NSNumber *numberResult =[NSNumber numberWithInt:enumTestResult] ;
	NSString *strFailMsg = FailMsg ;
	
	//check PDCA data
	if (strTestName==nil)
		return ;
	
	//write pdca log .
	NSMutableDictionary *mutableTmp = [[NSMutableDictionary alloc] init] ;
	[mutableTmp setValue:strTestName forKey:@"TestName"] ;
	if (strSubTestItem!=nil)
		[mutableTmp setValue:strSubTestItem forKey:@"SubTestName"]  ;
	
	if (strSubSubTestItem!=nil)
    	[mutableTmp setValue:strSubSubTestItem forKey:@"SubSubTestName"] ;
	
	if (strLowLimit!=nil)
    	[mutableTmp setValue:strLowLimit forKey:@"LowLimit"] ;
	
	if (strUpLimit!=nil)
    	[mutableTmp setValue:strUpLimit forKey:@"UpLimit"] ;
	
	if (strTestUnit!=nil)
    	[mutableTmp setValue:strTestUnit forKey:@"TestUnit"] ;
	
	if (strTestValue!=nil)
    	[mutableTmp setValue:strTestValue forKey:@"TestValue"] ;
	
	if (numberResult!=nil)
    	[mutableTmp setValue:numberResult forKey:@"TestResult"] ;
	
	if (strFailMsg!=nil)
    	[mutableTmp setValue:strFailMsg forKey:@"FailMsg"];
	
	////get the PDCA Array point
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
	{
		[mutableTmp release] ;
		return ;
	}
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableArray *mutArray = [mutdictTmp objectForKey:@"UnitPDCAInfo"] ;
	if (mutArray==nil)
	{
		mutArray = [[[NSMutableArray alloc] init] autorelease] ;
		[mutdictTmp setObject:mutArray forKey:@"UnitPDCAInfo"] ;
	}
	
	[mutArray addObject:mutableTmp] ;
	[mutableTmp release] ;
	
	return ;
}

//set PDCA Log
+(void)setPDCAInfo:(NSDictionary*)dictUNITInfo :(int)index
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil 
		)
		return ;
	
	if (index >= [mutArrayTestItemList count])
		return ;
	NSString *strIndex=[NSString stringWithFormat:@"%d",index+1];//dsx 03-08 get testItem index
	//SCRID:102 Modify for upload all testitem to PDCA, no need set the key "PDCAWrite=yes/no" by Helen 20110505.
	/*NSString *strPDCAWrite=nil ;
	strPDCAWrite = [dictUNITInfo objectForKey:@"PDCAWrite"] ;
	if (strPDCAWrite==nil)
		strPDCAWrite = @"yes" ;
	
	if (![strPDCAWrite boolValue])
		return ;
	*/
	//SCRID:102 end.
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return ;
	
	if (mutDictTestItemActionInfo==nil)
		mutDictTestItemActionInfo = [[NSMutableDictionary alloc] init] ;
	
	NSMutableDictionary *mutdictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (mutdictTmp==nil)
	{
		mutdictTmp = [[[NSMutableDictionary alloc] init] autorelease] ;
		[mutDictTestItemActionInfo setObject:mutdictTmp forKey:strDUTID] ;
	}
	
	NSMutableArray *mutArray = [mutdictTmp objectForKey:@"UnitPDCAInfo"] ;
	if (mutArray==nil)
	{
		mutArray = [[[NSMutableArray alloc] init] autorelease] ;
		[mutdictTmp setObject:mutArray forKey:@"UnitPDCAInfo"] ;
	}
	//prepare PDCA data .
	NSString *strTestName=[dictUNITInfo objectForKey:@"TestItemName"] ;
	NSString *strSubTestItem = [dictUNITInfo objectForKey:@"SubTestItem"] ;
	NSString *strSubSubTestItem = [dictUNITInfo objectForKey:@"SubSubTestItem"] ;
	NSString *strLowLimit = [dictUNITInfo objectForKey:@"Lowlimit"] ;
	if (strLowLimit==nil)
		strLowLimit = [dictUNITInfo objectForKey:@"LowerValue"] ;
	
	NSString *strUpLimit = [dictUNITInfo objectForKey:@"Uplimit"] ;
	if (strUpLimit==nil)
		strUpLimit = [dictUNITInfo objectForKey:@"UpperValue"] ;
	
	NSString *strTestUnit = [dictUNITInfo objectForKey:@"TestUnit"] ;
	NSString *strTestValue = nil ;
	NSNumber *numberResult =nil ;
	NSString *strFailMsg = nil ;
	
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:index];
	if (dictTmp==nil)
		return ;
	dictTmp = [dictTmp objectForKey:@"TestItemResult"] ;
	if (dictTmp==nil)
		return ;
	numberResult = [dictTmp objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]] ;
	if (numberResult!=nil)
	{
		strTestValue= [[dictTmp objectForKey:[NSString stringWithFormat:@"%@-UIInfo",strDUTID]] string] ;
		strFailMsg = [[dictTmp objectForKey:[NSString stringWithFormat:@"%@-UIInfo",strDUTID]] string] ;
	}else
		return ;
	
	//check PDCA data
	if (strTestName==nil)
		return ;
	//write pdca log .
	NSMutableDictionary *mutableTmp = [[NSMutableDictionary alloc] init] ;
	[mutableTmp setValue:strTestName forKey:@"TestName"] ;
	if (strSubTestItem!=nil)
		[mutableTmp setValue:strTestName forKey:@"SubTestName"]  ;
	
	if (strSubSubTestItem!=nil)
    	[mutableTmp setValue:strSubSubTestItem forKey:@"SubSubTestName"] ;
	
	if (strLowLimit!=nil)
    	[mutableTmp setValue:strLowLimit forKey:@"LowLimit"] ;
	
	if (strUpLimit!=nil)
    	[mutableTmp setValue:strUpLimit forKey:@"UpLimit"] ;
	
	if (strSubTestItem!=nil)
    	[mutableTmp setValue:strTestName forKey:@"SubTestName"];
	
	if (strTestUnit!=nil)
    	[mutableTmp setValue:strTestUnit forKey:@"TestUnit"] ;
	
	if (strTestValue!=nil)
    	[mutableTmp setValue:strTestValue forKey:@"TestValue"] ;
	if (strIndex!=nil)
    	[mutableTmp setValue:strIndex forKey:@"TestItemIndex"] ;//dsx 03-08 set index to table
	
	if (numberResult!=nil)
	{
		switch ([numberResult intValue]) 
		{
			case RESULT_FOR_PASS:
			case RESULT_FOR_FAIL:	
				[mutableTmp setValue:numberResult forKey:@"TestResult"] ;
				break ;
			case RESULT_FOR_BYPASS :
				[mutableTmp release] ;
				return ; //not set to PDCA when Result=BYPASS.
			default:
				[mutableTmp setValue:[NSNumber numberWithInt:RESULT_FOR_FAIL] forKey:@"TestResult"] ;
				break ;
		}
	}
	
	if (strFailMsg!=nil)
    	[mutableTmp setValue:strFailMsg forKey:@"FailMsg"];
	
	[mutArray addObject:mutableTmp] ;
	[mutableTmp release] ;
	
	return ;
	
}

+(void)clearTestActionInfo:(NSString*)DUTID //Clear old message .
{
	if (DUTID==nil)
		return ;
	
	if (mutArrayTestItemList!=nil)
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		for(int i=0 ;i<[mutArrayTestItemList count] ;i++)
		{
			NSMutableDictionary* dictTmp=[mutArrayTestItemList objectAtIndex:i] ;
			if (dictTmp==nil)
				continue ;
			NSMutableDictionary *dictTmp1=[dictTmp objectForKey:@"TestItemResult"] ;
			if (dictTmp1==nil)
				continue ;
			[dictTmp1 removeObjectForKey:[NSString stringWithFormat:@"%@-UIInfo",DUTID]] ;
			[dictTmp1 removeObjectForKey:[NSString stringWithFormat:@"%@-Result",DUTID]] ;
		}	
		[pool release] ;
	}
	
	if (mutDictTestItemActionInfo!=nil)
	{
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init] ;
		[mutDictTestItemActionInfo removeObjectForKey:DUTID] ;
		[pool release] ;
	}
	
	return ;
}

+(void)amountResultRefresh:(NSString*)DUTID :(NSTextField*)showPassOrFail //refresh The test result
{
	if (mutArrayTestItemList==nil)
		return  ;
	if (DUTID==nil ||
		showPassOrFail==nil
		)
		return  ;
	
	for (int i=0 ;i<[mutArrayTestItemList count] ;i++)
	{
		NSMutableDictionary* dictTmp=[mutArrayTestItemList objectAtIndex:i] ;
		if (dictTmp==nil)
			continue ;
		NSMutableDictionary *dictTmp1=[dictTmp objectForKey:@"TestItemResult"] ;
		if (dictTmp1==nil)
			continue ;
		NSNumber *numberResult = [dictTmp1 objectForKey:[NSString stringWithFormat:@"%@-Result",DUTID]] ;
		switch ([numberResult intValue]) 
		{
			case RESULT_FOR_FAIL:
			case RESULT_FOR_OTHER:
				[showPassOrFail setStringValue:@"Fail"] ;
				//closed by henry 2011-01-21
				//[showPassOrFail setFont:[NSFont userFontOfSize:16]];
				//Henry add 20100723
				NSString *strTmp = [ScriptParse getValueFromSummary:@"SwitchUI"] ;
				if (strTmp!=nil)
				{
					// Owner:Henry DATE :11.30.2010
					// SCRID :026
					// Desc  :modify for iPad-1,add UI2,UI2S 
					if (([strTmp isEqualToString:@"UI1M"])||([strTmp isEqualToString:@"UI1M2"])||([strTmp isEqualToString:@"UI2"])||([strTmp isEqualToString:@"UI2S"]))
						//End by Helen 11.30.2010
						[showPassOrFail setFont:[NSFont userFontOfSize:30]];
				}
				//2011-01-28 henry added for prox cal
				if([strTmp isEqualToString:@"UI3"])
					[showPassOrFail setTextColor:[NSColor whiteColor]] ;
				else	
					[showPassOrFail setTextColor:[NSColor redColor]] ;
				[self handleNotification:DUTID  type:@"backGround"];//dsx-01-18 fix crash issue
				return ;	
		}
	} ;
	
	[showPassOrFail setStringValue:@"PASS"] ;
	//closed by henry 2011-01-21
	//[showPassOrFail setFont:[NSFont userFontOfSize:16]];
	//Henry add 20100723
	NSString *strTmp = [ScriptParse getValueFromSummary:@"SwitchUI"] ;
	if (strTmp!=nil)
	{
		// Owner:Henry DATE :11.30.2010
		// SCRID :026
		// Desc  :modify for iPad-1,add UI2,UI2S 
		if (([strTmp isEqualToString:@"UI1M"])||([strTmp isEqualToString:@"UI1M2"])||([strTmp isEqualToString:@"UI2"])||([strTmp isEqualToString:@"UI2S"]))
			//End by Helen 11.30.2010
			[showPassOrFail setFont:[NSFont userFontOfSize:30]];
	}
	
	[showPassOrFail setTextColor:[NSColor blueColor]] ;
	[self handleNotification:DUTID  type:@"backGround"];//dsx-01-18 fix crash issue
	return;
}

+(void)setSYSSN:(NSDictionary*)dictUNITInfo 
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil)
		return ;
	
	NSString *strSN = [self getUnitValue:dictUNITInfo:STRKEYSYSSN] ;
	if (strSN!=nil)
		return ; //already exist
	//check testitem=SN
	NSString *strTmp = [dictUNITInfo objectForKey:@"TestItemName"] ;
	if (strTmp==nil)
		return ;
	if ([strTmp isEqualToString:@"SN"]) 
	{
		//get current test value
		NSString *strTestItemIndex = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
		NSString *strDUTID = [dictUNITInfo objectForKey:@"DUTID"];
		if (strTestItemIndex==nil ||
			strDUTID==nil)
			return ;
		if ([strTestItemIndex intValue]>=[mutArrayTestItemList count])
			return ;
		NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:[strTestItemIndex intValue]] ;
		if (dictTmp==nil)
			return ;
		dictTmp = [dictTmp objectForKey:@"TestItemResult"] ;
		if (dictTmp==nil)
			return ;
		//get the result
		NSNumber *numberResult=[dictTmp objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]] ;
		NSAttributedString *attribStr = [dictTmp objectForKey:[NSString stringWithFormat:@"%@-UIInfo",strDUTID]];
		if (numberResult==nil ||
			attribStr==nil)
			return ;
		//NSLog(@"\nddddddd==%d ,%d \n",[numberResult intValue] , RESULT_FOR_PASS);
		switch ([numberResult intValue])
		{
			case RESULT_FOR_PASS :
				[self setUnitValue:dictUNITInfo :STRKEYSYSSN :[pubFun allTrimFromString:[attribStr string] trimStr:@" " leftTrim:true rightTrim:true]];
				return ;
		}
	}
	return ;
}

+(void)handleStopFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex ; 
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil)
		return ;
	
	//get stopfail key
	NSString*strStopFail=[dictUNITInfo objectForKey:STRKEYSTOPFAIL] ;
	if (strStopFail==nil)
		strStopFail = @"no" ;
	
	if ([strStopFail boolValue]==false)
		return ;
	
	NSString *strTestItemIndex   = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
	NSString *strTestActionIndex = [dictUNITInfo objectForKey:@"TestActionIndex"] ;
	NSString *strDUTID = [dictUNITInfo objectForKey:@"DUTID"] ;
	if (strTestItemIndex==nil ||
		strTestActionIndex==nil ||
		strDUTID==nil )
		return ;
	
	//get the test result
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:[strTestItemIndex intValue]] ;
	if (dictTmp==nil)
		return ;
	NSDictionary* dictItemResult = [dictTmp  objectForKey:@"TestActionResult"] ;
	if (dictItemResult==nil)
		return ;
	NSNumber *numResult = [dictItemResult objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]] ;
	if (numResult==nil)
		return ;
	
	if ([numResult intValue]==RESULT_FOR_PASS ||
		[numResult intValue]==RESULT_FOR_BYPASS)
		return ;
	
	//jump to correct test item index ,test item action index .
    NSString *strTestItemName = [dictUNITInfo objectForKey:TestItemName] ;
	if (strTestItemName==nil) // jump to current test item action 
	{
		NSArray *arrTmpAction = [dictTmp objectForKey:@"TestItemAction"] ;
		if (arrTmpAction==nil)
			return ;
		if ( *actionIndex<([arrTmpAction count] -1) )
		//SCRID-154:modify handlestopfail to change stopfail test item from 1 to 2.Henry.2011-12-29.
			*actionIndex = [arrTmpAction count] -([[ScriptParse getValueFromSummary:@"StopFailToLastItem"] intValue] + 1);
		//SCRID-154:end
		//jump ,set Log info
		[TestItemManage setUnitLogInfo:dictUNITInfo :@"Stop fail ,Jump to current Test Item Action tail":false];		
		
	}else
	{
		NSArray *arrTmpAction = [dictTmp objectForKey:@"TestItemAction"] ;
		if (arrTmpAction==nil)
			return ;
		if ( *actionIndex<([arrTmpAction count] -1) )
			*actionIndex = [arrTmpAction count] ;
		//SCRID-154:modify handlestopfail to change stopfail test item from 1 to 2.Henry.2011-12-29.
		if([ScriptParse getValueFromSummary:@"StopFailToLastItem"] != nil)
		{
			if (*itemIndex < ([mutArrayTestItemList count] -([[ScriptParse getValueFromSummary:@"StopFailToLastItem"] intValue] + 1)))
				*itemIndex = [mutArrayTestItemList count] -([[ScriptParse getValueFromSummary:@"StopFailToLastItem"] intValue] + 1);
		}
		else
		{
			if ( *itemIndex<([mutArrayTestItemList count] -1) )
                //Modify by Luke 20160526
                *itemIndex = [mutArrayTestItemList count] -3 ;
		}
		//SCRID-154:end
		//jump ,set Log info
		[TestItemManage setUnitLogInfo:dictUNITInfo :@"Stop fail ,Jump to the lastest TestItem":false];		
		
	}
	return ;
}

+(NSString*)getLogPath:(NSDictionary*)dictUNITInfo 
{
	if (mutDictTestItemActionInfo==nil ||
		dictUNITInfo==nil  
		)
		return nil ;
	
	NSString *strDUTID=[dictUNITInfo objectForKey:@"DUTID"] ;
	if (strDUTID==nil)
		return nil ;
	
	NSDictionary *dictTmp=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
	if (dictTmp==nil)
		return nil ;
	
	return [dictTmp objectForKey:@"UnitLogFilePath"] ;
}

+(void)printAllKeys 
{
	NSMutableDictionary *mutDictTmp=[[NSMutableDictionary alloc] init];
	for(int i=0;i<[mutArrayTestItemList count] ;i++)
	{
		NSDictionary*dictTmp = [mutArrayTestItemList objectAtIndex:i] ;
		NSArray *arrayTmp = [dictTmp objectForKey:TestitemAction] ;
		for(int j=0; j<[arrayTmp count] ;j++)
		{
			NSDictionary*dictTmp = [arrayTmp objectAtIndex:j] ;
			[mutDictTmp addEntriesFromDictionary:dictTmp];
		}
	}
	
	//NSLog(@"\n%@\n",mutDictTmp) ;
	[mutDictTmp release] ;
}

+(NSString*)getResultInfo:(int)DUTID
{
	if (mutArrayTestItemList==nil)
		return nil ;
	
	NSMutableString *mutPassStrTmp = [[NSMutableString alloc] initWithString:@""] ;
	NSMutableString *mutFailStrTmp = [[NSMutableString alloc] initWithString:@""] ;
	NSMutableString *mutNoTestStrTmp = [[NSMutableString alloc] initWithString:@""] ;
	for (int i=0 ;i<[mutArrayTestItemList count] ;i++)
	{
		NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:i] ;
		if (dictTmp==nil)
			break ;
		//get the testresult 
		dictTmp = [dictTmp objectForKey:@"TestItemResult"] ;
		if (dictTmp==nil)
			break ;
		
		//get DUTID RESULT  [NSString stringWithFormat:@"%d-Result",DUTID]
		NSNumber *numResult = [dictTmp objectForKey:[NSString stringWithFormat:@"%d-Result",DUTID]] ;
		if (numResult==nil)
			break ; 
		
		switch ([numResult intValue])
		{
			case RESULT_FOR_FAIL:
			case RESULT_FOR_OTHER:
			case RESULT_FOR_COF:
				[mutFailStrTmp appendFormat:@" %d ,",i+1];
		  	    break;
			default :
				[mutPassStrTmp appendFormat:@" %d ,",i+1];
				break;
		}
	};
	
	NSMutableString *mutResultInfo = [[[NSMutableString alloc] initWithString:@""] autorelease];
	if ([mutPassStrTmp isEqualToString:@""])
		[mutResultInfo appendString:@"\nPass Item List :\n No exist Passed TestItem"] ;
	else
		[mutResultInfo appendFormat:@"\nPass Item List :\n%@ ",mutPassStrTmp] ;
	
	if ([mutFailStrTmp isEqualToString:@""])
		[mutResultInfo appendString:@"\n\nFail Item List :\n No exist Fail TestItem"] ;
	else
		[mutResultInfo appendFormat:@"\n\nFail Item List :\n%@ ",mutFailStrTmp] ;
	
	[mutPassStrTmp release] ;
	[mutFailStrTmp release] ;
	[mutNoTestStrTmp release];
	
	return mutResultInfo ;
	
};

//henry modified for prox cal UI3 2011-01-25
+(void)handleNotification:(NSString*)DUTID type:(NSString*)notificationType
{
	if([DUTID isEqualToString:@"1"])
	{
		if([notificationType isEqualToString:@"backGround"])
			[[NSNotificationCenter defaultCenter] postNotificationName:@"SET_UI_BGD_COLOR1" object:self];
	}
	else if([DUTID isEqualToString:@"2"])
	{
		if([notificationType isEqualToString:@"backGround"])
			[[NSNotificationCenter defaultCenter] postNotificationName:@"SET_UI_BGD_COLOR2" object:self];
	}
	else if([DUTID isEqualToString:@"3"])
	{
		if([notificationType isEqualToString:@"backGround"])
			[[NSNotificationCenter defaultCenter] postNotificationName:@"SET_UI_BGD_COLOR3" object:self];
	}
	else if([DUTID isEqualToString:@"4"])
	{
		if([notificationType isEqualToString:@"backGround"])
			[[NSNotificationCenter defaultCenter] postNotificationName:@"SET_UI_BGD_COLOR4" object:self];
	}
}
// Owner:Henry DATE :2.14.2011  for clean old thread
+(void)cleanThread:(NSString*)iDutID 
{
//	[mutDictTestItemThread removeObjectForKey:[NSString stringWithFormat:@"%d",iDutID]] ;
	NSString *strTestResultForUIinfo=@"";
	for(NSInteger i=0;i< 27;i++)
	{
//		[TestItemManage setTestItemResultForUI:[strDUTID intValue] :[strTestItemIndex intValue] :strTestResultForUIinfo :enumResult] ;
		[self setTestItemResultForUI:[iDutID intValue] :i :strTestResultForUIinfo :RESULT_FOR_PASS] ;
	}

}

//SCRID:109 Add a UI for auto test,and change stopFail to jump to Write CB.
+(void)btnHandleStopFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil)
		return ;
	
	NSString *strTestItemIndex   = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
	NSString *strTestActionIndex = [dictUNITInfo objectForKey:@"TestActionIndex"] ;
	NSString *strDUTID = [dictUNITInfo objectForKey:@"DUTID"] ;
	if (strTestItemIndex==nil ||
		strTestActionIndex==nil ||
		strDUTID==nil )
		return ;
	
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:[strTestItemIndex intValue]] ;
	if (dictTmp==nil)
		return ;
	
	NSString *jumpTestItem = nil;
	NSDictionary *jumpDicTmp;
	int i;
	for(i=0; i<[mutArrayTestItemList count]; i++)
	{
		jumpDicTmp = [mutArrayTestItemList objectAtIndex:i];
		jumpTestItem = [jumpDicTmp objectForKey:TestItemName];
		if(([jumpTestItem rangeOfString:@"Write"].length > 0) && ([jumpTestItem rangeOfString:@"CB"].length > 0))
			break;
		else if([jumpTestItem rangeOfString:@"Write PDCA"].length > 0)
			break;
	}
	NSLog(@"%d",i);
	if(i >= [mutArrayTestItemList count] || [strTestItemIndex intValue] > i)
		return;

	//jump to correct test item index ,test item action index . 
	NSArray *arrTmpAction = [dictTmp objectForKey:@"TestItemAction"] ;
	if (arrTmpAction==nil)
		return ;
	if ( *actionIndex<([arrTmpAction count] -1) )
		*actionIndex = [arrTmpAction count];
			
	if ( *itemIndex<([mutArrayTestItemList count] -1) )
	{
		//*itemIndex = [mutArrayTestItemList count] -4;
		*itemIndex = i-1;
	}
		//jump ,set Log info
	[TestItemManage setUnitLogInfo:dictUNITInfo :@"Stop, Jump to the correct TestItem":false];		
	return ;
}
//SCRID:109 end

//SCRID:136
//Added by caijunbo on 2011-09-27
//Description:Used to handle network based cb failure

+(void)handleNetWorkCBFail:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex newTestItemActionIndex:(int*)actionIndex ; 
{
	if (dictUNITInfo==nil ||
		mutArrayTestItemList==nil)
		return ;
	//Check if parser contain HandleNetworkCBFailure=yes
	if (![[dictUNITInfo objectForKey:@"HandleNetworkCBFailure"] isEqualToString:@"yes"])
		return;
	
	NSString *strTestItemIndex   = [dictUNITInfo objectForKey:@"TestItemIndex"] ;
	NSString *strTestActionIndex = [dictUNITInfo objectForKey:@"TestActionIndex"] ;
	NSString *strDUTID = [dictUNITInfo objectForKey:@"DUTID"] ;
	if (strTestItemIndex==nil ||
		strTestActionIndex==nil ||
		strDUTID==nil )
		return ;
	
	//get the test result
	NSDictionary *dictTmp = [mutArrayTestItemList objectAtIndex:[strTestItemIndex intValue]] ;
	if (dictTmp==nil)
		return ;
	NSDictionary* dictItemResult = [dictTmp  objectForKey:@"TestActionResult"] ;
	if (dictItemResult==nil)
		return ;
	NSNumber *numResult = [dictItemResult objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]] ;
	if (numResult==nil)
		return ;
	
	if ([numResult intValue]==RESULT_FOR_PASS ||
		[numResult intValue]==RESULT_FOR_BYPASS)
		return ;
	
	//jump to correct test item index ,test item action index .
	NSArray *arrTmpAction = [dictTmp objectForKey:@"TestItemAction"] ;
	if (arrTmpAction==nil)
		return ;
	if ( *actionIndex<([arrTmpAction count] -1) )
		*actionIndex = [arrTmpAction count] ;
	
	//Jump to the last Item
	if ( *itemIndex<([mutArrayTestItemList count] -1) )
        //Modify by Luke 20160526
        *itemIndex = [mutArrayTestItemList count] -3 ;

	[TestItemManage setUnitLogInfo:dictUNITInfo :@"Network Based CB Error":false];		
		
	return ;
}
//SCRID:136
//end network based CB failure handling

//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
+(void)handleRetestItems:(NSDictionary*)dictUNITInfo newTestItemIndex:(int*)itemIndex 
{
	NSString*strRetestItems=[dictUNITInfo objectForKey:STRKEYRETESTITEMS] ;
	if(strRetestItems == nil || ([strRetestItems rangeOfString:@"R"].length > 0))
		return;
	
	int retestItems = [strRetestItems intValue];
	NSString* strDUTID=[dictUNITInfo objectForKey:@"DUTID"];
	
	int i;
	NSDictionary *dictTmp;
	for(i=*itemIndex; i>*itemIndex - retestItems ; i--)
	{
		dictTmp = [mutArrayTestItemList objectAtIndex:i];
		if (dictTmp==nil)
			return;
		NSDictionary* dictTmpResult = [dictTmp objectForKey:@"TestItemResult"] ;
		if (dictTmpResult==nil)
			return;
		
		NSString* strResult=[dictTmpResult objectForKey:[NSString stringWithFormat:@"%@-Result",strDUTID]];
		NSInteger numberResult = [strResult intValue];
		if ((numberResult!=RESULT_FOR_PASS) && (numberResult!=RESULT_FOR_BYPASS))
			break;
	}
	
	if(i<=*itemIndex - retestItems)
	{
		//retestFlag=TRUE;
		return;
	}
	if([[dictUNITInfo objectForKey:TestItemName] isEqualToString:RetestItemName] == NO)
	{
        RetestItemName = [dictUNITInfo objectForKey:TestItemName];
        //Modify by Luke 20160526
		/*[UIAlert setInitPosition:1 index:1] ;
		UIAlert *alert = [[UIAlert alloc] init];
		[alert showWindow:self];
		[alert updatPosition:1 index:1];
		NSString* itemName = [dictUNITInfo objectForKey:TestItemName];
		if([itemName rangeOfString:@"Mikey_Tone_S0"].length > 0)
		{
			[alert setMessageText:@"請確認治具線是否連接ok,重測此項"];
			[alert setInformativeText:@"Please confirm fixture cable connected OK!"];
		}
        else if([itemName rangeOfString:@"E75"].length > 0)
		{
			[alert setMessageText:@"請按WI重測Kong Cable"];
			[alert setInformativeText:@"According WI retest it!"];
		}
        else if([itemName rangeOfString:@"Button Test"].length > 0)
		{
			[alert setMessageText:@"請按WI重測按鍵"];
			[alert setInformativeText:@"According WI retest it!"];
		}
		else
		{
			[alert setMessageText:@"重測此項"];
			[alert setInformativeText:[NSString stringWithFormat:@"Retest the %d items!",retestItems]];
		}
		
		[alert addButtonWithTitle:@"OK"];
		
		NSInteger result = [alert runModal];
		
		if(result == NSAlertFirstButtonReturn)
		{
			[alert release];*/
			
			*itemIndex = *itemIndex - retestItems;
			//retestFlag=FALSE;
			
			if (mutDictTestItemActionInfo==nil ||
				dictUNITInfo==nil
				)
				return;
			if (strDUTID==nil)
				return;
			
			NSDictionary *dictTmpPDCA=[mutDictTestItemActionInfo objectForKey:strDUTID] ;
			if (dictTmpPDCA==nil)
				return;
			[mutDictTestItemActionInfo setObject:dictTmpPDCA forKey:strDUTID] ;
			
			
			NSMutableArray *pdcaArray = [dictTmpPDCA objectForKey:@"UnitPDCAInfo"] ;
			
			NSLog(@"###### hjhjhj before remove, pdcaArray=%@", pdcaArray);
			for(int g=0; g<retestItems; g++)
			{
				[pdcaArray removeLastObject];
			}
			
			NSLog(@"###### hjhjhj pdcaArray=%@", pdcaArray);
		//}
		return;
	}
	
	return;
	
}
//SCRID:155 end

+(void)writeEZLinkLog:(NSString*)logPath :(NSString*)logContent
{
    FILE* fp=NULL;
    fp=fopen([logPath UTF8String],"wr");
    fclose(fp);
    
    NSFileHandle *filehandTmp = [NSFileHandle fileHandleForWritingAtPath:logPath];
    if (filehandTmp!=nil)
    {
        
        [filehandTmp seekToEndOfFile] ;
        [filehandTmp writeData:[NSData dataWithData:[logContent dataUsingEncoding:NSASCIIStringEncoding]]] ;
        [filehandTmp closeFile] ;
        
    }
    
}


@end
