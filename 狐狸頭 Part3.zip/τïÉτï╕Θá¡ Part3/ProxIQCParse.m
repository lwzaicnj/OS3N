
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: ProxIQCParse.h  $|
 | $Author:: Dengshouxiu                 $Revision::  1              $|
 | CREATED: 2010-03-24                   $Modtime:: 2.03.00 15:24    $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 $History:: ProxIQCParse.h                                              $
 * *****************  Version 1  *****************
 * User: Dengshouxiu          Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */


#import "ProxIQCParse.h"
#import "Pudding.h"

@implementation TestItemParse(ProxIQCParse)
+(void)ParseProxMult_RL:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
	enumResult =RESULT_FOR_FAIL;
	strTestResultForUIinfo = @"Fail";
	
	//key parse
	NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
	NSString *mLowerValue=nil;
	//NSInteger mIntLowerValue = 0;
    NSString *mUpperValue=nil;
	//NSInteger mIntUppValue = 0;
    
    NSString *mReferenceBufferName2=nil;
 
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey];
			//mIntLowerValue = [mLowerValue integerValue];
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue = [dictKeyDefined objectForKey:strKey];
			//mIntUppValue = [mUpperValue integerValue];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey];
		}
	
	}
	
	if (mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
    
    //add by kevin for RL QT0a "Prox Offser Test" 20140328
  	NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue2=[mReferenceBufferValue2 stringByReplacingOccurrencesOfString:@" " withString:@""];
    if((![mReferenceBufferValue2 isEqualToString:@":"])
       &&  ([mTestItemName rangeOfString:@"Unsnap"].length > 0))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Snap, Bypass"];
		return;
    }
    if(([mReferenceBufferValue2 isEqualToString:@":"])
       &&  ([mTestItemName rangeOfString:@"Snap"].length > 0))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Unsnap, Bypass"];
		return;
        
    }
    
    //add by kevin for RL QT0a "Prox Offser Test"
    
	
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    //    mReferenceBufferValue = [NSString stringWithContentsOfFile:@"/Users/gdadmin/1s" encoding:NSASCIIStringEncoding error:nil];
    if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	if([mReferenceBufferValue rangeOfString:@"prox:"].length == 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error"];
		return;
	}
	
    if ([mUpperValue isEqualToString:@"NA"])
        mUpperValue = nil;
    if ([mLowerValue isEqualToString:@"NA"])
        mLowerValue = nil;
	
	NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    NSArray *valueAS;
    
    NSLog(@"mReferenceBufferValue is %@",mReferenceBufferValue);
    NSLog(@"count is %d",[valueResult count]);
    if ([valueResult count] < 20)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 20"];
		return;
	}
    
    //	int count = 0;
    int getProxValue=0;
    int sumOutOfLimit=0;
    int sum = 0 ;
    for (int i=6 ;i<=20 ;i++)
    {
        NSString *proxtmp = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"[C3:" Postfix:@"]"];
        valueAS = [proxtmp componentsSeparatedByString:@","];
        
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXOFFSET", i]:nil:nil:nil:[valueAS objectAtIndex:3 ]:nil:IP_PASS:nil];
        //add by justin for check prox limit value start
        getProxValue = [[valueAS objectAtIndex:0] integerValue];
        
        if(mUpperValue != nil && mLowerValue != nil)
        {
            if ((getProxValue < [mLowerValue intValue]) || (getProxValue > [mUpperValue intValue]))
            {
                sumOutOfLimit++;
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:mLowerValue:mUpperValue:[valueAS objectAtIndex:0]:nil:IP_FAIL:nil];
            }
            else
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:mLowerValue:mUpperValue:[valueAS objectAtIndex:0]:nil:IP_PASS:nil];
        }
        else if(mUpperValue != nil)
        {
            if (getProxValue > [mUpperValue intValue])
            {
                sumOutOfLimit ++;
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:nil:mUpperValue:[valueAS objectAtIndex:0]:nil:IP_FAIL:nil];
            }
            else
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:nil:mUpperValue:[valueAS objectAtIndex:0]:nil:IP_PASS:nil];
            
        }
        else if(mLowerValue != nil)
        {
            if (getProxValue < [mLowerValue intValue])
            {
                sumOutOfLimit++;
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:mLowerValue:nil:[valueAS objectAtIndex:0]:nil:IP_FAIL:nil];
            }
            else
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:mLowerValue:nil:[valueAS objectAtIndex:0]:nil:IP_PASS:nil];
        }
        else
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d C3 PROXUSEFUL", i]:nil:nil:nil:[valueAS objectAtIndex:0]:nil:IP_PASS:nil];
        
        sum = sum + [[valueAS objectAtIndex:0] intValue];
    }
    int averageValue = sum / 15 ;
    
    
    if(mUpperValue != nil && mLowerValue != nil)
    {
        if ((averageValue > [mLowerValue intValue]) && (averageValue < [mUpperValue intValue]))
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"];
    }
    else if(mUpperValue != nil)
    {
        if (averageValue > [mUpperValue intValue])
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
    }
    else if(mLowerValue != nil)
    {
        if (averageValue < [mLowerValue intValue])
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
    }
    //justin add end
    else
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"]; ///write test result and uiinfo.
	return;

}
//Ray add for calculate Prox Average 2012-12-07
+(void)ParseProxMult_QL2:(NSDictionary*)dictKeyDefined
{	
    NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
	enumResult =RESULT_FOR_PASS;
	strTestResultForUIinfo = @"Pass";
    
	//key parse
	NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
	NSString *mStage0UpperValue=nil;
	NSString *mStage0LowerValue=nil;
    NSString *mStage1UpperValue=nil;
	NSString *mStage1LowerValue=nil;
    NSString *mStage2UpperValue=nil;
	NSString *mStage2LowerValue=nil;
    NSString *mStage3UpperValue=nil;
	NSString *mStage3LowerValue=nil;
    NSString *mMoving=@"YES";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Stage0UpperValue"])
        {
            mStage0UpperValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage0LowerValue"])
        {
            mStage0LowerValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage1UpperValue"])
        {
            mStage1UpperValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage1LowerValue"])
        {
            mStage1LowerValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage2UpperValue"])
        {
            mStage2UpperValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage2LowerValue"])
        {
            mStage2LowerValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage3UpperValue"])
        {
            mStage3UpperValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Stage3LowerValue"])
        {
            mStage3LowerValue = [dictKeyDefined objectForKey:strKey];
        }
        else if ([strKey isEqualToString:@"Moving"])
        {
            mMoving = [dictKeyDefined objectForKey:strKey];
        }
	}
	
	//if (mLowerValue == nil || mReferenceBufferName == nil)
    if (mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
	
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	if([mReferenceBufferValue rangeOfString:@"prox:"].length == 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error"];
		return;
	}
	
    NSArray *list = [NSArray arrayWithObjects:@" ",@"\r",@"\t",@"\n",nil];
	for(int i =0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
			mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:tmp withString:@""];
	}
	
	NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    if ([valueResult count] < 6)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 5"];
		return;
	}
    
    if(![mMoving boolValue])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
		return;
    }
    
	//int count = 0;
    for (int i=1 ;i<6 ;i++)
    {
        NSMutableArray *valueAS = [[[NSMutableArray alloc] init] autorelease];
        
        NSString *stage0Ave = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"0:" Postfix:@"1:"];
        NSString *stage1Ave = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"1:" Postfix:@"2:"];
        NSString *stage2Ave = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"2:" Postfix:@"3:"];
        NSString *stage3Ave = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"3:" Postfix:nil];
        
        stage0Ave = [ToolFun getStrFromPrefixAndPostfix:stage0Ave Prefix:nil Postfix:@"("];
        stage1Ave = [ToolFun getStrFromPrefixAndPostfix:stage1Ave Prefix:nil Postfix:@"("];
        stage2Ave = [ToolFun getStrFromPrefixAndPostfix:stage2Ave Prefix:nil Postfix:@"("];
        stage3Ave = [ToolFun getStrFromPrefixAndPostfix:stage3Ave Prefix:nil Postfix:@"("];
        
        //Stage 0
        if(((mStage0LowerValue==nil||[mStage0LowerValue length]<=0)?1:([stage0Ave intValue] < [mStage0LowerValue intValue])) 
           && ((mStage0UpperValue==nil||[mStage0UpperValue length]<=0)?1:([stage0Ave intValue] > [mStage0UpperValue intValue])))
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = @"Fail";
        }
        //Stage 1
        if(((mStage1LowerValue==nil||[mStage1LowerValue length]<=0)?1:([stage1Ave intValue] < [mStage1LowerValue intValue])) 
           && ((mStage1UpperValue==nil||[mStage1UpperValue length]<=0)?1:([stage1Ave intValue] > [mStage1UpperValue intValue])))
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = @"Fail";
        }
        //Stage 2
        if(((mStage2LowerValue==nil||[mStage2LowerValue length]<=0)?1:([stage2Ave intValue] < [mStage2LowerValue intValue])) 
           && ((mStage2UpperValue==nil||[mStage2UpperValue length]<=0)?1:([stage2Ave intValue] > [mStage2UpperValue intValue])))
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = @"Fail";
        }
        //Stage 3
        if(((mStage3LowerValue==nil||[mStage3LowerValue length]<=0)?1:([stage3Ave intValue] < [mStage3LowerValue intValue])) 
           && ((mStage3UpperValue==nil||[mStage3UpperValue length]<=0)?1:([stage3Ave intValue] > [mStage3UpperValue intValue])))
        {
            enumResult =RESULT_FOR_FAIL ;
            strTestResultForUIinfo = @"Fail";
        }
        
        [valueAS addObject:stage0Ave];
        [valueAS addObject:stage1Ave];
        [valueAS addObject:stage2Ave];
        [valueAS addObject:stage3Ave];
        NSLog(@"valueAS = %@", valueAS);
        
        for(int j=0; j<4; j++)
        {
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d Stage %d Ave", i, j]:nil:nil:nil:[valueAS objectAtIndex:j]:nil:IP_PASS:nil];
        }
    }
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]; ///write test result and uiinfo.
	return;
    
}
+(void)ParseProxMult_QL3:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
	enumResult =RESULT_FOR_FAIL;
	strTestResultForUIinfo = @"Fail";
	
	//key parse
	NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
	NSString *mLowerValue=nil;
	NSInteger mIntLowerValue = 0;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey];
			mIntLowerValue = [mLowerValue integerValue];
		}
	}
	
	if (mLowerValue == nil || mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
	
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	if([mReferenceBufferValue rangeOfString:@"prox:"].length == 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error"];
		return;
	}
	
    NSArray *list = [NSArray arrayWithObjects:@" ",@"\r",@"\t",@"\n",nil];
	for(int i =0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
			mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:tmp withString:@""];
	}
	
	NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
    NSArray *valueAS;
    
    if ([valueResult count] < 6)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 5"];
		return;
	}
    
	int count = 0;
    for (int i=1 ;i<6 ;i++)
    {
        NSString *proxtmp = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"1:" Postfix:@"3:"];
        valueAS = [proxtmp componentsSeparatedByString:@"2:"];
        
        for (int j=0 ;j<2 ;j++)
        {
            NSInteger Average = 0;
            NSString *AverageString = [valueAS objectAtIndex:j];
            
            AverageString = [ToolFun getStrFromPrefixAndPostfix:AverageString Prefix:nil Postfix:@"("];
            Average =[AverageString integerValue];
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d Stage %d Ave", i, (j+1)]:nil:nil:nil:AverageString:nil:IP_PASS:nil];
            
            if (Average > mIntLowerValue)
            {
                count++;
            }
        }                
    }
    
    if(count == 10)
    {
        enumResult = RESULT_FOR_PASS;
        strTestResultForUIinfo = @"Pass";
    }
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]; ///write test result and uiinfo.
	return;
}
//Ray add for calculate Prox Deviation 2012-12-07
+(void)ParseProxIQC:(NSDictionary*)dictKeyDefined 
{
	NSString *strTestResultForUIinfo;
	enum TestResutStatus enumResult;
    enumResult =RESULT_FOR_FAIL;
	strTestResultForUIinfo = @"Fail";
	
	//key parse
	NSString *mTestItemName=nil;
    NSString *mReferenceBufferName=nil;
	NSString *mLowerValue=nil;
	NSInteger mIntLowerValue = 0;
    NSString *mMoving=@"NO";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey];
			mIntLowerValue = [mLowerValue integerValue];
		}
		else if ([strKey isEqualToString:@"Moving"])
		{
			mMoving = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	if (mLowerValue==nil || mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
	
	NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
	}
	
	if([mReferenceBufferValue rangeOfString:@"prox:"].length == 0)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Received Data Error"];
		return;
	}
	
	NSArray *list = [NSArray arrayWithObjects:@" ",@"\r",@"\t",@"\n",nil];
	for(int i =0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
			mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:tmp withString:@""];
	}
    
	NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"prox:"];
	NSArray *valueAS;
    
    if ([valueResult count] < 6)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 5"];
		return;
	}
	
	int count = 0;
	for (int i=1 ;i<6 ;i++)
	{
		NSString *proxtmp = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:@"1:" Postfix:@"3:"];
		valueAS = [proxtmp componentsSeparatedByString:@"2:"];
		
		for (int j=0 ;j<2 ;j++)
		{
			NSInteger Deviation = 0;
            NSString *DeviationString = [valueAS objectAtIndex:j];
            
            DeviationString = [ToolFun getStrFromPrefixAndPostfix:DeviationString Prefix:@"(" Postfix:@")"];
			Deviation = [DeviationString integerValue];
            
            [TestItemManage setSubItemPDCAInfo:dictKeyDefined:[NSString stringWithFormat:@"Sample %d Stage %d Std", i, (j+1)]:nil:nil:nil:DeviationString:nil:IP_PASS:nil];
            
			if (Deviation > mIntLowerValue)
			{
                count++;
			}
        }
	}
    
    if([mMoving boolValue])
    {
        if(count >= 6)
        {
            enumResult = RESULT_FOR_PASS;
            strTestResultForUIinfo = @"Pass";
        }
    }
    else
    {
        if(count <= 4)
        {
            enumResult = RESULT_FOR_PASS;
            strTestResultForUIinfo = @"Pass";
        }
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]; ///write test result and uiinfo.
	return ;
}

+(void)ParseAccelerometerIntr:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
			
		}

		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
    if([mTestItemName isEqualToString:@"Sensor Accelerometer Selftest"])
    {
        NSString *AccSeltTestByPass = [TestItemManage getBufferValue:dictKeyDefined :@"ACC Selt Test Bypass"];
        if([AccSeltTestByPass rangeOfString:@"ByPass"].length > 0)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Bosch, need ByPass"] ;
            return  ;
        }
    }
    
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	NSRange Locate1,Locate2;
	Locate1 = [mReferenceBufferValue rangeOfString:@"passed"];
	Locate2 = [mReferenceBufferValue rangeOfString:mStrSpec];
	
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	
	if ((Locate1.length > 0)&&(Locate2.length <= 0))
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo = @"Pass" ;
	}
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
}

+(void)ParseMultStrSpec:(NSDictionary*)dictKeyDefined
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mStrSpec=nil      ;// write cmd
	NSString *mReferenceBufferName=nil ;
	NSString *mCondition=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"StrSpec"])
		{
			mStrSpec = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Condition"])
		{
			mCondition = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mStrSpec==nil ||
		mReferenceBufferName==nil
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	
    //mReferenceBufferValue =@"0	2000/01/01 00:10:00 Average: 53181, 52499, 53479, 52780	Deviation: 1, 0, 1, 1 1	2000/01/01 00:10:01 Average: 53182, 52499, 53480, 52780	Deviation: 1, 0, 0, 1	2	2000/01/01 00:10:01 Average: 53183, 19660, 53480, 52780	Deviation: 1, 1, 0, 1	3	2000/01/01 00:10:02 Average: 53184, 52499, 53479, 52779	Deviation: 0, 0, 1, 2	4	2000/01/01 00:10:03 Average: 53185, 52499, 53479, 52780	Deviation: 0, 0, 1, 0";	
	
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSArray *strSpecArray=[mStrSpec componentsSeparatedByString:@","];
	
	BOOL flag =NO;
	
	for(int i =0;i<[strSpecArray count];i++)
	{
		NSString *tmp = [strSpecArray objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
		{
			flag=YES;
			break;
		}
			
	}
	if([mCondition isEqualToString:@"yes"])
	{
		if(flag)
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = @"Pass" ;
		}
		else
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = @"Fail" ;
		}
			
	}
	else
	{
		if(flag)
		{
			enumResult =RESULT_FOR_FAIL ;
			strTestResultForUIinfo = @"Fail" ;
			
		}
		else
		{
			enumResult =RESULT_FOR_PASS ;
			strTestResultForUIinfo = @"Pass" ;
		}
	}
		
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
}

//Ray add for P105 DVT 2012-07-30
+(void)ParseProxShortAver:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
    NSString *mUpLimit=nil;
    NSString *mLowLimit=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}

	}
    
    if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"];
	    return;
	}
    
    NSString *mReferenceBufferValue ;
    /*mReferenceBufferValue = @"Stage(s) 0,1,2,3 - 20 Samples - Loops: 5\n0	2012/06/12 01:49:30 Average: 31977, 38501, 38437, 29029	Deviation: 2, 2113, 2152, 1\n1	2012/06/12 01:49:30 Average: 31978, 34129, 34122, 29029	Deviation: 3, 103, 98, 2\n2	2012/06/12 01:49:31 Average: 31978, 33848, 33846, 29030	Deviation: 1, 35, 34, 1\n3	2012/06/12 01:49:31 Average: 31976, 33630, 33627, 29030	Deviation: 2, 54, 51, 2\n4	2012/06/12 01:49:31 Average: 31977, 33296, 33293, 29031	Deviation: 2, 69, 70, 1\n:-) ";*/
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
		return;
	}
    
    if(([mReferenceBufferValue rangeOfString:@"Average"].length==0)
       ||([mReferenceBufferValue rangeOfString:@"Deviation"].length==0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"];
		return;
	}
    
	NSArray *list = [NSArray arrayWithObjects:@" ",@":",@"\r",@"\t",@"\n",nil];
	
	for(int i=0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
			mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:tmp withString:@""];
	}    
    
    NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"Average"];
	NSString *valueS;
	NSArray *valueAS;
    
    NSString *Aver10 = @"";
    NSString *Aver20 = @"";
    NSString *Aver11 = @"";
    NSString *Aver21 = @"";
    NSString *Aver12 = @"";
    NSString *Aver22 = @"";
    NSString *Aver13 = @"";
    NSString *Aver23 = @"";
    NSString *Aver14 = @"";
    NSString *Aver24 = @"";
    
    
    for (int i=1;i<[valueResult count];i++)
    {
        NSRange tmpS = [[valueResult objectAtIndex:i] rangeOfString:@"Deviation"];
		valueS = [[valueResult objectAtIndex:i] substringToIndex:tmpS.location];
		valueAS = [valueS componentsSeparatedByString:@","];
        
        for (int j=1;j<[valueAS count]-1;j++)
        {
            NSInteger Average = 0;
			Average = [[valueAS objectAtIndex:j]integerValue];
            
            if(Average >= [mLowLimit integerValue]){
                
                if(i==1 && j==1)
                    Aver10 = [NSString stringWithFormat:@"%d",Average];
                else if(i==1 && j==2)
                    Aver20 = [NSString stringWithFormat:@"%d",Average];
                else if(i==2 && j==1)
                    Aver11 = [NSString stringWithFormat:@"%d",Average];
                else if(i==2 && j==2)
                    Aver21 = [NSString stringWithFormat:@"%d",Average];
                else if(i==3 && j==1)
                    Aver12 = [NSString stringWithFormat:@"%d",Average];
                else if(i==3 && j==2)
                    Aver22 = [NSString stringWithFormat:@"%d",Average];
                else if(i==4 && j==1)
                    Aver13 = [NSString stringWithFormat:@"%d",Average];
                else if(i==4 && j==2)
                    Aver23 = [NSString stringWithFormat:@"%d",Average];
                else if(i==5 && j==1)
                    Aver14 = [NSString stringWithFormat:@"%d",Average];
                else if(i==5 && j==2)
                    Aver24 = [NSString stringWithFormat:@"%d",Average];
            }
            else{
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Average]];
                return;
                
            }
        
        }
    }
    
    if ([mTestItemName isEqualToString:@"Prox Short Aver_1_0"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver10];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_2_0"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver20];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_1_1"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver11];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_2_1"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver21];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_1_2"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver12];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_2_2"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver22];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_1_3"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver13];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_2_3"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver23];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_1_4"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver14];
        return;
    }
    else if ([mTestItemName isEqualToString:@"Prox Short Aver_2_4"])
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :Aver24];
        return;
    }
}

+(void)ParseProxOpenSD:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
    NSString *mUpLimit=nil;
    NSString *mLowLimit=nil;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
        else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey];
		}

	}
    
    if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"];
	    return;
	}
    
    NSString *mReferenceBufferValue ;
    //mReferenceBufferValue = @"Stage(s) 0,1,2,3 - 20 Samples - Loops: 5\n0	2012/06/12 01:49:26 Average: 31977, 40018, 40022, 29029	Deviation: 1, 15, 23, 2\n1	2012/06/12 01:49:27 Average: 31976, 40017, 40017, 29029	Deviation: 2, 266, 260, 2\n2	2012/06/12 01:49:27 Average: 31977, 40016, 40016, 29029	Deviation: 2, 120, 119, 1\n3	2012/06/12 01:49:27 Average: 31978, 40015, 40013, 29029	Deviation: 1, 74, 73, 2\n4	2012/06/12 01:49:27 Average: 31977, 40012, 40013, 29028	Deviation: 1, 44, 44, 2\n:-) ";
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
		return;
	}
    
    if(([mReferenceBufferValue rangeOfString:@"Average"].length==0)
       ||([mReferenceBufferValue rangeOfString:@"Deviation"].length==0))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"];
		return;
	}
    
	NSArray *list = [NSArray arrayWithObjects:@" ",@":",@"\r",@"\t",@"\n",nil];
	
	for(int i=0;i<[list count];i++)
	{
		NSString *tmp = [list objectAtIndex:i];
		NSRange Locate = [mReferenceBufferValue rangeOfString:tmp];
		if (Locate.length > 0)
			mReferenceBufferValue = [mReferenceBufferValue stringByReplacingOccurrencesOfString:tmp withString:@""];
	}    
    
    NSArray *valueResult = [mReferenceBufferValue componentsSeparatedByString:@"Deviation"];
	NSString *valueS;
	NSArray *valueAS;
    
//    NSString *Dev10 = @"";
//    NSString *Dev20 = @"";
//    NSString *Dev11 = @"";
//    NSString *Dev21 = @"";
//    NSString *Dev12 = @"";
//    NSString *Dev22 = @"";
//    NSString *Dev13 = @"";
//    NSString *Dev23 = @"";
//    NSString *Dev14 = @"";
//    NSString *Dev24 = @"";
    
    /*modified by Rick 2012-09-18*/
    NSMutableArray *Dev1 = [[NSMutableArray alloc] init];
    NSMutableArray *Dev2 = [[NSMutableArray alloc] init];
    for (int i=1;i<[valueResult count];i++)
    {
        //NSRange tmpS = [[valueResult objectAtIndex:i] rangeOfString:@"Deviation"];
		valueS = [valueResult objectAtIndex:i];
		valueAS = [valueS componentsSeparatedByString:@","];
        [Dev1 addObject:[valueAS objectAtIndex:1]];
        [Dev2 addObject:[valueAS objectAtIndex:2]];
//        for (int j=1;j<3;j++)
//        {
            //            NSInteger Dev = 0;
//			Dev = [[valueAS objectAtIndex:j]integerValue];
//            
//            if (Dev >= [mLowLimit integerValue]) {
//                
//                if(i==1 && j==1)
//                    Dev10 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==1 && j==2)
//                    Dev20 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==2 && j==1)
//                    Dev11 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==2 && j==2)
//                    Dev21 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==3 && j==1)
//                    Dev12 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==3 && j==2)
//                    Dev22 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==4 && j==1)
//                    Dev13 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==4 && j==2)
//                    Dev23 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==5 && j==1)
//                    Dev14 = [NSString stringWithFormat:@"%d",Dev];
//                else if(i==5 && j==2)
//                    Dev24 = [NSString stringWithFormat:@"%d",Dev];
//            }
//            else{
//                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
//                return;
//                
//            }
            
//            
//        }
    }

    if ([mTestItemName isEqualToString:@"Prox Open SD_1_0"])
    {
        int Dev = 0;
        Dev = [[Dev1 objectAtIndex:0] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_2_0"])
    {
        int Dev = 0;
        Dev = [[Dev2 objectAtIndex:0] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_1_1"])
    {
        int Dev = 0;
        Dev = [[Dev1 objectAtIndex:1] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_2_1"])
    {
        int Dev = 0;
        Dev = [[Dev2 objectAtIndex:1] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_1_2"])
    {
        int Dev = 0;
        Dev = [[Dev1 objectAtIndex:2] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_2_2"])
    {
        int Dev = 0;
        Dev = [[Dev2 objectAtIndex:2] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_1_3"])
    {
        int Dev = 0;
        Dev = [[Dev1 objectAtIndex:3] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_2_3"])
    {
        int Dev = 0;
        Dev = [[Dev2 objectAtIndex:3] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_1_4"])
    {
        int Dev = 0;
        Dev = [[Dev1 objectAtIndex:4] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
    else if ([mTestItemName isEqualToString:@"Prox Open SD_2_4"])
    {
        int Dev = 0;
        Dev = [[Dev2 objectAtIndex:4] integerValue];
        if(Dev >= [mLowLimit integerValue])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :[NSString stringWithFormat:@"%d",Dev]];
            [Dev1 release];
            [Dev2 release];
            return;
        }
    }
     /*modified by Rick end 2012-09-18*/
}
//End

  //add by kevin 20140625 for RL QT0a ALS1 and ALS2 start
+(void)ParseAlsMult_QT0a:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mBufferName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferValue=nil;
    NSString *mLowerValue=nil;
    NSString *mUpperValue=nil;
    NSString *mPrefix=nil;
    NSString *mPostfix=nil;
    NSString *mReferenceBufferNameVendor=nil;
    NSString *mReferenceBufferNameVendorValue=nil;//
    NSString *mVendorName=nil;//

    double sumValue;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"ReferenceBufferNameVendor"])
        {
            mReferenceBufferNameVendor=[dictKeyDefined objectForKey:strKey];
            mReferenceBufferNameVendorValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVendor];
        }
        else if([strKey isEqualToString:@"VendorName"])
        {
            mVendorName=[dictKeyDefined objectForKey:strKey];
        }

    }
    if(mReferenceBufferNameVendorValue != nil && mVendorName != nil)
    {
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
        mReferenceBufferNameVendorValue=[mReferenceBufferNameVendorValue stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([mVendorName rangeOfString:@"|"].length>0) {
            if([mVendorName rangeOfString:mReferenceBufferNameVendorValue].length<1)
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
                return;
            }
            
        }else if([mReferenceBufferNameVendorValue rangeOfString:mVendorName].length<1)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined : RESULT_FOR_BYPASS :@"Not for this vendor, bypass"] ;
            return;
        }
    }
    if (mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
    mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined:mReferenceBufferName];
    //mReferenceBufferValue=@"\n306s:566219us (+00s:000000us) = ir = 0x00007D36, clear = 0x0000FFFF\rals1:\n306s:972543us (+00s:406324us) = ir = 0x00007D15, clear = 0x0000FFFF\nals1:\n307s:378769us (+00s:406226us) = ir = 0x00007CFE, clear = 0x0000FFFF\rOK";
    
    if(mReferenceBufferValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
    }
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([mUpperValue isEqualToString:@"NA"])
        mUpperValue = nil;
    if ([mLowerValue isEqualToString:@"NA"])
        mLowerValue = nil;
    
    
    //add by kevin 20140625 for RL QT0a ALS1 and ALS2 start
    NSString *separatedByString=nil;
    if([mTestItemName rangeOfString:@"ALS1"].length>0)
    {
        separatedByString=@"als1:";
    }
    if([mTestItemName rangeOfString:@"ALS2"].length>0)
    {
        separatedByString=@"als2:";
        
    }
    NSArray *valueResult=[mReferenceBufferValue componentsSeparatedByString:separatedByString];
    if([valueResult count]<3)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 3"];
        return;
    }
    for(int i=0;i<[valueResult count];i++)
    {
        NSString *proxtmp = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:mPrefix Postfix:mPostfix];
        char* stopEnd;
        double resultValue=(double)strtol([proxtmp UTF8String], &stopEnd, 16);
        sumValue=sumValue+resultValue;
    }
    double averageValue=sumValue / 3;
    NSLog(@"averageValue = %f",averageValue);
    NSString *averageValueStr=[NSString stringWithFormat:@"%f",averageValue];
    if(mUpperValue != nil && mLowerValue != nil)
    {
        if ((averageValue > [mLowerValue doubleValue]) && (averageValue < [mUpperValue doubleValue]))
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
    }
    else if(mUpperValue != nil)
    {
        if (averageValue > [mUpperValue doubleValue])
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    else if(mLowerValue != nil)
    {
        if (averageValue < [mLowerValue doubleValue])
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
        else
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    
//    [TestItemManage setSubItemPDCAInfo:dictKeyDefined:mTestItemName:nil:mLowerValue:mUpperValue:averageValueStr:nil:RESULT_FOR_PASS:nil];／／disable by kevin 20151006
    NSString *bufferValue=[NSString stringWithFormat:@"%f",averageValue];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :bufferValue];
    return;
    
    //add by kevin 20140625 for RL QT0a ALS1 and ALS2 end
    
}


//add by kevin 20150311 for SL QT0a ALS1 and ALS2 start
+(void)ParseAlsMult_SL_QT0a:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
    NSString *mBufferName=nil;
    NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferValue=nil;
    NSString *mLowerValue=nil;
    NSString *mUpperValue=nil;
    NSString *mPrefix=nil;
    NSString *mPostfix=nil;
    NSString *mPrefix1=nil;
    NSString *mPostfix1=nil;
    NSString *mPrefix2=nil;
    NSString *mPostfix2=nil;
    BOOL red=false;
    BOOL green=false;
    BOOL blue=false;
    double sumValueRed;
    double sumValueGreen;
    double sumValueBlue;
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Prefix1"])
		{
			mPrefix1 = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Postfix1"])
		{
			mPostfix1 = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Prefix2"])
		{
			mPrefix2 = [dictKeyDefined objectForKey:strKey];
		}
        else if ([strKey isEqualToString:@"Postfix2"])
		{
			mPostfix2 = [dictKeyDefined objectForKey:strKey];
		}
    }
    if (mReferenceBufferName == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"];
	    return;
	}
    mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined:mReferenceBufferName];
    
    if(mReferenceBufferValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No Received Data"];
		return;
    }
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mReferenceBufferValue=[mReferenceBufferValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([mUpperValue isEqualToString:@"NA"])
        mUpperValue = nil;
    if ([mLowerValue isEqualToString:@"NA"])
        mLowerValue = nil;
    
    
    //add by kevin 20140625 for RL QT0a ALS1 and ALS2 start
    NSString *separatedByString=nil;
    if([mTestItemName rangeOfString:@"ALS1"].length>0)
    {
        separatedByString=@"als1:";
    }
    if([mTestItemName rangeOfString:@"ALS2"].length>0)
    {
        separatedByString=@"als2:";
        
    }
    NSArray *valueResult=[mReferenceBufferValue componentsSeparatedByString:separatedByString];
    if([valueResult count]<3)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"The samples less than 3"];
        return;
    }
    
    
    //red
    for(int i=0;i<[valueResult count];i++)
    {
        NSString *proxtmpRed = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:mPrefix Postfix:mPostfix];
        char* stopEnd;
        double resultValueRed=(double)strtol([proxtmpRed UTF8String], &stopEnd, 16);
        sumValueRed=sumValueRed+resultValueRed;
    }
    double averageValueRed=sumValueRed / 3;
    NSLog(@"averageValueRed = %f",averageValueRed);
    NSString *averageValueRedStr=[NSString stringWithFormat:@"%f",averageValueRed];
    if(mUpperValue != nil && mLowerValue != nil)
    {
        if ((averageValueRed > [mLowerValue doubleValue]) && (averageValueRed < [mUpperValue doubleValue]))
        {
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
            red = true;
        }
        else
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            red = false;
    }
    else if(mUpperValue != nil)
    {
        if (averageValueRed > [mUpperValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            red = false;
        else
           red = true;
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    else if(mLowerValue != nil)
    {
        if (averageValueRed < [mLowerValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            red = false;
        else
            red = true;
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    
    //green
    for(int i=0;i<[valueResult count];i++)
    {
        NSString *proxtmpGreen = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:mPrefix1 Postfix:mPostfix1];
        char* stopEnd;
        double resultValueGreen=(double)strtol([proxtmpGreen UTF8String], &stopEnd, 16);
        sumValueGreen=sumValueGreen+resultValueGreen;
    }
    double averageValueGreen=sumValueGreen / 3;
    NSLog(@"sumValueGreen = %f",sumValueGreen);
    NSString *averageValueGreenStr=[NSString stringWithFormat:@"%f",averageValueGreen];
    if(mUpperValue != nil && mLowerValue != nil)
    {
        if ((averageValueGreen > [mLowerValue doubleValue]) && (averageValueGreen < [mUpperValue doubleValue]))
        {
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
            green = true;
        }
        else
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            green = false;
    }
    else if(mUpperValue != nil)
    {
        if (averageValueGreen > [mUpperValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            green = false;
        else
            green = true;
        //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    else if(mLowerValue != nil)
    {
        if (averageValueGreen < [mLowerValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            green = false;
        else
            green = true;
        //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    
    
    //blue
    for(int i=0;i<[valueResult count];i++)
    {
        NSString *proxtmpBlue = [ToolFun getStrFromPrefixAndPostfix:[valueResult objectAtIndex:i] Prefix:mPrefix2 Postfix:mPostfix2];
        char* stopEnd;
        double resultValueBlue=(double)strtol([proxtmpBlue UTF8String], &stopEnd, 16);
        sumValueBlue=sumValueBlue+resultValueBlue;
    }
    double averageValueBlue=sumValueBlue / 3;
    NSLog(@"sumValueBlue = %f",sumValueBlue);
    NSString *averageValueBlueStr=[NSString stringWithFormat:@"%f",averageValueBlue];
    if(mUpperValue != nil && mLowerValue != nil)
    {
        if ((averageValueBlue > [mLowerValue doubleValue]) && (averageValueBlue < [mUpperValue doubleValue]))
        {
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
            blue = true;
        }
        else
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            blue = false;
    }
    else if(mUpperValue != nil)
    {
        if (averageValueBlue > [mUpperValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            blue = false;
        else
            blue = true;
        //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    else if(mLowerValue != nil)
    {
        if (averageValueBlue < [mLowerValue doubleValue])
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
            blue = false;
        else
            blue = true;
        //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }
    NSString *averageValueStr=[NSString stringWithFormat:@"%@,%@,%@",averageValueRedStr,averageValueGreenStr,averageValueBlueStr];
    if(red == true && green == true && blue == true)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :averageValueStr];
    }else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :averageValueStr];
    }
    
    
    
    //[TestItemManage setSubItemPDCAInfo:dictKeyDefined:mTestItemName:nil:mLowerValue:mUpperValue:averageValueStr:nil:RESULT_FOR_PASS:nil];
   // NSString *bufferValue=[NSString stringWithFormat:@"%f",averageValue];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :averageValueStr];
    return;
    
    
}
//add by kevin 20150311 for SL QT0a ALS1 and ALS2 end
@end
