#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "BojayMCU.h"
#include <unistd.h>

int writed_read(char *command){
    int ret = MCUwrite(command);
    if (ret < 0){
        printf("write error : %s\n",command);
        return ret;
    }
    usleep(DELAY_TIME);
    char buffer[BUFFER_SIZE]={0};
    ret = MCUread(buffer, BUFFER_SIZE);
    if (ret < 0) {
        printf("read error : %s\n",command);
        return ret;
    }
    printf("%s",buffer);
    return 0;
}


int main(int argc,char **argv){
	if (argc<2) return 0;
	char *cmd = argv[1];
    int ret = -1;
    
    ret = MCUopen("/dev/cu.Bluetooth-Incoming-Port");
    if (ret!=0) return ret;
    
    if (strcmp(cmd, "test_start")==0) {
        ret = MCUreadStart();
    }else if (strcmp(cmd, "test_finish")==0){
        ret = MCUwriteForuSeconds(TEST_FINISH, TIMEOUT);
    }else if (strcmp(cmd, "maglock_enable")==0){
        ret = MCUwriteForuSeconds(MAGLOCK_ENABLE, TIMEOUT);
    }else if (strcmp(cmd, "maglock_disable")==0){
        ret = MCUwriteForuSeconds(MAGLOCK_DISABLE, TIMEOUT);
    }else if (strcmp(cmd, "shutter_enable")==0){
        ret = MCUwriteForuSeconds(SHUTTER_ENABLE, TIMEOUT);
    }else if (strcmp(cmd, "shutter_disable")==0){
        ret = MCUwriteForuSeconds(SHUTTER_DISABLE, TIMEOUT);
    }else if (strcmp(cmd, "lamp_on")==0){
        ret = MCUwriteForuSeconds(LAMP_ON, TIMEOUT);
    }else if (strcmp(cmd, "lamp_off")==0){
        ret = MCUwriteForuSeconds(LAMP_OFF, TIMEOUT);
    }else if (strcmp(cmd, "cpc_up")==0){
        ret = MCUwriteForuSeconds(CPC_UP, TIMEOUT);
    }else if (strcmp(cmd, "cpc_down")==0){
        ret = MCUwriteForuSeconds(CPC_DOWN, TIMEOUT);
    }else if (strcmp(cmd, "cpc_36")==0){
        ret = MCUwriteForuSeconds(CPC_ROTATE_36, TIMEOUT);
    }else if (strcmp(cmd, "cpc_original")==0){
        ret = MCUwriteForuSeconds(CPC_ROTATE_ORIGINAL, TIMEOUT);
    }else if (strcmp(cmd, "drawer_p1_larger")==0){
        ret = MCUwriteForuSeconds(DRAWER_P1_LARGER, TIMEOUT);
        ret|= MCUwriteForuSeconds(DRAWER_ORIGINAL,TIMEOUT);
    }else if (strcmp(cmd, "drawer_p2_larger")==0){
        ret = MCUwriteForuSeconds(DRAWER_P2_LARGER, TIMEOUT);
    }else if (strcmp(cmd, "drawer_p1_samll")==0){
        ret = MCUwriteForuSeconds(DRAWER_P1_SMALL, TIMEOUT);
        ret|= MCUwriteForuSeconds(DRAWER_ORIGINAL,TIMEOUT);
    }else if (strcmp(cmd, "drawer_p2_small")==0){
        ret = MCUwriteForuSeconds(DRAWER_P2_SMALL, TIMEOUT);
    }else if (strcmp(cmd, "drawer_original")==0){
        ret = MCUwriteForuSeconds(DRAWER_ORIGINAL, TIMEOUT);
    }else if (strcmp(cmd, "help")==0){
        ret = writed_read(HELP);
    }else if (strcmp(cmd, "version")==0){
        ret = writed_read(VERSION);
    }else{
        printf("invalid command:%s\n",cmd);
        return ret;
    }
    
    if (ret >= 0) {
        printf("success\n");
    }else{
        printf("FAIL\n");
    }
    MCUclose();
    return 0;
}
