//
//  BojayMCU.c
//  
//
//  Created by Chen Jin on 5/30/16.
//
//

#include "BojayMCU.h"
#include "SerialPort.h"
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>


int MCUopen(char *devicePath)
{
    return openPort(devicePath, B9600, DATABITS_8, StopBits_1, PARITY_NONE, FLOW_CONTROL_NONE);
}

int MCUisOpen(){
    return isOpen();
}

void MCUclose(){
    return closePort();
}

int MCUwrite(char *buffer){
    char strBuffer[BUFFER_SIZE] = {0};
    strcat(strBuffer, buffer);
    strcat(strBuffer, LINE_END);
    return writeLine(strBuffer);
}

int MCUread(char *buffer,int size){
    return readLine(buffer, size);
}

int MCUreadStart(){
    char readbuffer[BUFFER_SIZE] ={0};
    if(MCUread(readbuffer, BUFFER_SIZE)<0)return -1;
    
    while (1) {
        usleep(DELAY_TIME);
        char cbuffer[BUFFER_SIZE]={0};
        int cret = MCUread(cbuffer, sizeof(cbuffer));
        if (cret < 0) return -1;
        if (strcmp(cbuffer, TEST_START""LINE_END) == 0) return 0;
    }
}

int MCUwriteForuSeconds(char *buffer,int usecond){
    //清空MCU缓存数据
    char readbuffer[BUFFER_SIZE] ={0};
    if(MCUread(readbuffer, BUFFER_SIZE)<0)return -1;
    
    int ret = MCUwrite(buffer);
    if (ret < 0 ) return -2;
    
    struct timeval start,end;
    gettimeofday(&start, NULL);
    
    while (1) {
        usleep(DELAY_TIME);
        char cbuffer[BUFFER_SIZE]={0};
        int cret = MCUread(cbuffer, sizeof(cbuffer));
        if (cret < 0) return -1;
        if (strcmp(cbuffer, INVALID_COMMAND""LINE_END)==0) return -3;
        if (strcmp(cbuffer, OK""LINE_END) == 0) return 0;
        
        gettimeofday(&end, NULL);
        long cost_time = (end.tv_sec-start.tv_sec)*1000000 + end.tv_usec-start.tv_usec;
        if (cost_time >= usecond) return -4;
    }
    return 0;
}




