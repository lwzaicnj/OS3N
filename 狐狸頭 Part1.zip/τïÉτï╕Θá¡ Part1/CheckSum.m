
/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                     $Workfile:: CheckSum.h  $|
 | $Author:: Dengshouxiu                 $Revision::  1              $|
 | CREATED: 2010-04-07                  $Modtime:: 2.03.00 15:24    $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 $History:: CheckSum.h                                              $
 * *****************  Version 1  *****************
 * User: Dengshouxiu          Date: 27.10.98   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */
#import "CheckSum.h"
#import <sys/sysctl.h>
NSTask *task1=nil ;//dsx 05-10 ramdisk test
NSTask *task2=nil ; //dsx 05-10 ramdisk test

NSTask *task[8]={};

@implementation TestItemParse(CheckSum)

+(void)CheckSum:(NSDictionary*)dictKeyDefined 
{
	
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	//NSString *mPassString=@"2057034659"      ;// write cmd
	NSString *mPassString=@"2664755040";  //2010-09-02
	NSString *mDFURseult = @"/vault/DFUTest.txt";
	
	NSString *mDFUFolderLocate =nil;
	NSString *DeletePath = @"rm /vault/DFUTest.txt";
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"DFUFolderLocate"])
		{
			mDFUFolderLocate = [dictKeyDefined objectForKey:strKey] ;
		}
		
	}
	
	if (mDFUFolderLocate==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	
	
	NSString *mSN = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN] ;
	if (mSN==nil)
		mSN = [TestItemManage getScanValue:dictKeyDefined :STRKEYMODULESN];
		
	if (mSN==nil) //add by Giga
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"no sn"] ;
	    return  ;	
	}
	NSString *DFUFullPath =[mDFUFolderLocate stringByAppendingString:mSN] ;
	
	NSFileManager *fileManager = [NSFileManager defaultManager];
	BOOL isDir = YES;
	
	if(![fileManager fileExistsAtPath:DFUFullPath isDirectory:&isDir] && isDir)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Can't find the DFU folder"] ;
	    return  ;

	}
		
	[self closeCurrPort:dictKeyDefined];
	
	NSArray *Paths = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:DFUFullPath error:nil];
	
	NSString *LatestPath = [Paths lastObject];
	
	NSString *CheckSumPath =@"";
	CheckSumPath= [CheckSumPath stringByAppendingFormat:@"CKSUM %@/%@/capture1 > %@",DFUFullPath,LatestPath,mDFURseult];


	int i = 0;
	i =system([CheckSumPath UTF8String]);
	
	NSString* logContent = [NSString stringWithContentsOfFile:mDFURseult encoding:NSASCIIStringEncoding error:nil];
	
	NSRange exist = [logContent rangeOfString:mPassString];
	if(exist.length >0)
	{
		enumResult =RESULT_FOR_PASS ;
		strTestResultForUIinfo =CheckSumPath ; 
	}
	else
	{
		enumResult =RESULT_FOR_FAIL ;
		strTestResultForUIinfo = CheckSumPath ;
	}

    system([DeletePath UTF8String]);
	[self openCurrPort:dictKeyDefined];    
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
	return ;
	
	
}
//Added for P105 by Julian 20120731
+(void)ParseCompareVBSTandVPBR:(NSDictionary*)dictKeyDefined 
{
    NSAutoreleasePool *pool= [[NSAutoreleasePool alloc] init] ;
    NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	
	
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString *mReferenceBufferNameVB=nil ;
	NSString *mReferenceBufferNameVP=nil ;
    
    
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferNameVB"])
		{
			mReferenceBufferNameVB = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferNameVP"])
		{
			mReferenceBufferNameVP = [dictKeyDefined objectForKey:strKey] ;
		}
		
	}
    
    if ((mReferenceBufferName==nil)||(mReferenceBufferNameVB==nil)||(mReferenceBufferNameVP==nil))
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    NSString *VBVPfromSFC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    NSString *VBfromMLB=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVB];
    NSString *VPfromMLB=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVP];
    
    
    VBVPfromSFC = [VBVPfromSFC stringByReplacingOccurrencesOfString:@" " withString:@""];
    VBVPfromSFC = [VBVPfromSFC stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    VBVPfromSFC = [VBVPfromSFC stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    VBVPfromSFC = [VBVPfromSFC stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    VBfromMLB = [VBfromMLB stringByReplacingOccurrencesOfString:@" " withString:@""];
    VPfromMLB = [VPfromMLB stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    NSString *vbl=[ToolFun getStrFromPrefixAndPostfix:VBVPfromSFC Prefix:@"vboost_left=0x" Postfix:@"vboost_right"];
    NSString *vbr=[ToolFun getStrFromPrefixAndPostfix:VBVPfromSFC Prefix:@"vboost_right=0x" Postfix:@"vpbr_left"];
    NSString *vpl=[ToolFun getStrFromPrefixAndPostfix:VBVPfromSFC Prefix:@"vpbr_left=0x" Postfix:@"vpbr_right"];
    NSString *vpr=[ToolFun getStrFromPrefixAndPostfix:VBVPfromSFC Prefix:@"vpbr_right=0x" Postfix:nil];
    
    NSString *vbfromSFC = [vbr stringByAppendingString:vbl];
    NSString *vpfromSFC = [vpr stringByAppendingString:vpl];
    
    VPfromMLB = [ToolFun getStrFromPrefixAndPostfix:VPfromMLB Prefix:@"0x0000" Postfix:@"0x"];
    VBfromMLB = [ToolFun getStrFromPrefixAndPostfix:VBfromMLB Prefix:@"0x0000" Postfix:@"0x"];
    
    if ([vpfromSFC isEqualToString:VPfromMLB] && [vbfromSFC isEqualToString:VBfromMLB]) 
    {
        enumResult =RESULT_FOR_PASS ;
        strTestResultForUIinfo = [NSString stringWithFormat:@"VBOOST %@,VPBR %@",VBfromMLB,VPfromMLB];
    } 
    else 
    {
        enumResult =RESULT_FOR_FAIL ;
        strTestResultForUIinfo = [NSString stringWithFormat:@"VBOOST&VPBR from SFC is %@&%@,but VBOOST&VPBR from MLB is %@&%@",vbfromSFC,vpfromSFC,VBfromMLB,VPfromMLB];
    }
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo] ; ///write test result and uiinfo.
    [pool release];
	return ;
}
//end

+(void)ParseGSMNVStatus:(NSDictionary*)dictKeyDefined//Julian 20120914 added for PS PVT
{
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
    //	NSString *mReferenceBufferValue = @"Response:\n0000000: 4B FE 1C 00 00 00 20 00 01 00 00 00 00 00 00 00  K..... .........\n0000010: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000020: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000030: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000040: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000050: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000060: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000070: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................\n0000080: 00 00 00 00 00 00 00 00                          .......p\n";
    
	if (mReferenceBufferValue == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL:@"no received data"] ;
		return ;
	}
    
    NSString *mReferenceBufferValue1 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"0000000:" Postfix:@"0000010"];
	NSString *mReferenceBufferValue2 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"0000010:" Postfix:@"0000020"];
    NSString *mReferenceBufferValue3 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"0000020:" Postfix:@"0000030"];
    
    
    NSArray * Array1 = [mReferenceBufferValue1 componentsSeparatedByString:@" "];
    NSArray * Array2 = [mReferenceBufferValue2 componentsSeparatedByString:@" "];
    NSArray * Array3 = [mReferenceBufferValue3 componentsSeparatedByString:@" "];
    
    for (int index1=9; index1 <= 16; index1 ++)
    {
        if (![[Array1 objectAtIndex:index1] isEqualToString:@"00"])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; ///write test result and uiinfo.
            return ;
        }
    }
    for (int index2=1; index2 <= 16; index2 ++)
    {
        if (![[Array2 objectAtIndex:index2] isEqualToString:@"00"])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; ///write test result and uiinfo.
            return ;
        }
    }
    for (int index3=1; index3 <= 8; index3 ++)
    {
        if (![[Array3 objectAtIndex:index3] isEqualToString:@"00"])
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; ///write test result and uiinfo.
            return ;
        }
    }
	
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ; ///write test result and uiinfo.
	return ;
    
}

//added by Rick 2012-09-19
+(void)ParseGetTheWifiSN:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName;
    NSString *mReferenceBufferName;
    NSString *mBufferName;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
    
    NSString *mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
    NSString *tmp = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:@"0000020: " Postfix:@"0000030:"] ;
    NSRange WiFiSNBase = NSMakeRange(6, 17);
    NSString *WiFiSN = [tmp substringWithRange:WiFiSNBase];
    if(WiFiSN == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Data Error"] ;
        return;
    }
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :WiFiSN] ;
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :WiFiSN] ;
    return;
    
}

//added by Rick 2012-09-19
+(void)ParseValidateVboostAndVPBR:(NSDictionary*)dictKeyDefined
{
    NSString *mBufferName=nil;
	NSString *mReferenceBufferNameVB=nil;
    NSString *mReferenceBufferNameVP=nil;
	NSString *mTestItemName = nil;
    NSString *mPrefix = @"";
    NSString *mPostfix = @":-)";
    NSString *mReferenceBufferValue = nil;
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"ReferenceBufferNameVB"])
		{
			mReferenceBufferNameVB = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameVP"])
		{
			mReferenceBufferNameVP = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	NSString* mReferenceBufferNameVBValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVB];
	// mReferenceBufferNameVBValue = @"syscfg print VBST#\n0x00000D11 0x00000000 0x00000000 0x00000000\n[461E230F:CE845E18] :-)";
    NSString* mReferenceBufferNameVPValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameVP];
	// mReferenceBufferNameVPValue=@"syscfg print VPBR#\n    0x00000C0D 0x00000000 0x00000000 0x00000000 \n[461E230F:CE845E18] :-)";
    if([mTestItemName isEqualTo:@"Validate Vboost"])
    {
        if(mReferenceBufferNameVBValue == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
            return;
        }
        mPrefix = @"syscfg print VBST";
        mReferenceBufferValue = mReferenceBufferNameVBValue;
    }
    else if([mTestItemName isEqualTo:@"Validate Vpbr"])
    {
        
        if(mReferenceBufferNameVPValue == nil)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
            return;
        }
        mPrefix = @"syscfg print VPBR";
        mReferenceBufferValue = mReferenceBufferNameVPValue;
    }
	else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"the wrong item"];
    }
    
	NSString* striFine = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix:mPrefix Postfix:mPostfix];
	
	if(striFine == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please check diags return"] ;
		return;
	}
    
    striFine = [ToolFun getStrFromPrefixAndPostfix:striFine Prefix:@"0x" Postfix:@"0x"];
	
	if(striFine == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please check diags return"] ;
		return;
	}
	
	
	striFine=[striFine stringByReplacingOccurrencesOfString:@" " withString:@""];
	striFine=[striFine stringByReplacingOccurrencesOfString:@"\t" withString:@""];	
	striFine=[striFine stringByReplacingOccurrencesOfString:@"\r" withString:@""];
	striFine=[striFine stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    if([striFine length] != 8)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"please check diags return"] ;
		return;
    }
    NSString *strLeft = [striFine substringFromIndex:6];
    NSString *strRight = [striFine substringFromIndex:4];
    strRight = [strRight substringToIndex:2];
    NSMutableString *info = [[NSMutableString alloc] initWithFormat:@"left:%@,right:%@",strLeft,strRight];
    if([mTestItemName isEqualTo:@"Validate Vboost"])
    {
        int ValueLeft = (int)strtol([strLeft UTF8String], NULL, 16);
        int ValueRight = (int)strtol([strRight UTF8String], NULL, 16);
        
        if([strLeft isEqualTo:@"01"]||[strLeft isEqualTo:@"05"]||[strLeft isEqualTo:@"09"]||[strLeft isEqualTo:@"0D"]||[strLeft isEqualTo:@"11"]||[strLeft isEqualTo:@"15"]||[strLeft isEqualTo:@"19"]||[strLeft isEqualTo:@"1D"])
        {
            if([strRight isEqualTo:@"01"]||[strRight isEqualTo:@"05"]||[strRight isEqualTo:@"09"]||[strRight isEqualTo:@"0D"]||[strRight isEqualTo:@"11"]||[strRight isEqualTo:@"15"]||[strRight isEqualTo:@"19"]||[strRight isEqualTo:@"1D"])
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :info] ;
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"left":nil:nil:nil:[NSString stringWithFormat:@"%d",ValueLeft]:nil:RESULT_FOR_PASS:@"PASS"];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"right":nil:nil:nil:[NSString stringWithFormat:@"%d",ValueRight]:nil:RESULT_FOR_PASS:@"PASS"];
				
                [info release];
                return;
            }
            else
            {
                [info appendFormat:@",right fail"];
            }
        }
        else
            [info appendFormat:@",left fail"];
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :info] ;
        
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"left":nil:nil:nil:[NSString stringWithFormat:@"%d",ValueLeft]:nil:RESULT_FOR_FAIL:@"Fail"];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"right":nil:nil:nil:[NSString stringWithFormat:@"%d",ValueRight]:nil:RESULT_FOR_FAIL:@"Fail"];
        
        [info release];
        return;
        
        
    }
    else if([mTestItemName isEqualTo:@"Validate Vpbr"])
    {
        int ValueLeft = (int)strtol([strLeft UTF8String], NULL, 16);
        int ValueRight = (int)strtol([strRight UTF8String], NULL, 16);
        if( ( ValueLeft > 0 ) && ( ValueLeft <= 32 ))
        {
            if( ( ValueRight > 0 ) && ( ValueRight <= 32 ) )
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :info] ;
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"left":nil:@"0":@"32":[NSString stringWithFormat:@"%d",ValueLeft]:nil:RESULT_FOR_PASS:@"PASS"];
                [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"right":nil:@"0":@"32":[NSString stringWithFormat:@"%d",ValueRight]:nil:RESULT_FOR_PASS:@"PASS"];
                
                [info release];
                return;
            }
            else
                [info appendFormat:@",right fail"];
        }
        else
            [info appendFormat:@",left fail"];
        
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :info] ;
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"left":nil:@"0":@"32":[NSString stringWithFormat:@"%d",ValueLeft]:nil:RESULT_FOR_FAIL:@"Fail"];
        [TestItemManage setSubItemPDCAInfo:dictKeyDefined:@"right":nil:@"0":@"32":[NSString stringWithFormat:@"%d",ValueRight]:nil:RESULT_FOR_FAIL:@"Fail"];
        [info release];
        return;
    }
    else
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"unknown fail"] ;//should not be here;
        [info release];
        return;
    }
}
//dsx 05-10 ramdisk test
+(void)RamDiskStart:(NSDictionary*)dictKeyDefined 
{
	NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];
	NSString*DfuTiPath =@"";
	NSString *fileContent =@"";
	
	fileContent = [NSString stringWithContentsOfFile:@"/vault/USB_ID.txt" encoding:NSASCIIStringEncoding error:nil] ;
	NSString *usbID1 = [ToolFun getStrFromPrefixAndPostfix:fileContent Prefix:@"USB_ID_1:" Postfix:@";"] ;
	NSString *usbID2 = [ToolFun getStrFromPrefixAndPostfix:fileContent Prefix:@"USB_ID_2:" Postfix:@";"] ;
	
	if([strDUTID isEqualToString:@"1"])
	{
		if([task1 isRunning])
			[task1 terminate];
		if(task1!=nil)
		{
			[task1 release] ;
			task1 = nil ;
		}
				
		task1=[[NSTask alloc] init];
		DfuTiPath = [DfuTiPath stringByAppendingString:usbID1];
		[task1 setLaunchPath: @"/Ramdisk/dfuit"];
		
		NSArray *arguments = [NSArray arrayWithObjects:@"-f",@"/Ramdisk/J2_RamDisk_v4.dmg",@"-l",DfuTiPath, nil];
		[task1 setArguments: arguments];
		[task1 launch];		
	}
	else if([strDUTID isEqualToString:@"2"])
	{
		if([task2 isRunning])
			[task2 terminate];
		if(task2!=nil)
		{
			[task2 release] ;
			task2 = nil ;
		}
		
		task2=[[NSTask alloc] init];
		DfuTiPath = [DfuTiPath stringByAppendingString:usbID2];
		[task2 setLaunchPath: @"/Ramdisk/dfuit"];
		
		NSArray *arguments = [NSArray arrayWithObjects:@"-f",@"/Ramdisk/J2_RamDisk_v4.dmg",@"-l",DfuTiPath, nil];
		[task2 setArguments: arguments];
		[task2 launch];		
		
	}
}
//dsx 05-10 ramdisk test
+(void)RamDiskStop:(NSDictionary*)dictKeyDefined 
{
	
	NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];

	if([strDUTID isEqualToString:@"1"])
	{
		if([task1 isRunning])
			[task1 terminate];
		if(task1!=nil)
		{
			[task1 release] ;
			task1 = nil ;
		}
	}
	else if([strDUTID isEqualToString:@"2"])
	{
		if([task2 isRunning])
			[task2 terminate];
		if(task2!=nil)
		{
			[task2 release] ;
			task2 = nil ;
		}
	}
}

/*SCRID-108: add parser CheckSumBatterySN and MatchBatterySN. joko 2011-11-14*/
+(void)CheckSumBatterySN:(NSDictionary*)dictKeyDefined 
{
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mBufferName=nil;  
	NSString *mReferenceBufferName = nil;
	
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}
		
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strFind = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
														   :mPrefix Postfix
														   :mPostfix] ;
	
	
	//strFind = @"0x44 0x38 0x36 0x31 0x32 0x38 0x33 0x5A 0x41 0x4B 0x59 0x44 0x4D 0x4A 0x32 0x34 0x37 0x01 0x02 0x03 0x04 0x05 0x06 0x07 0x08 0x09 0x0A 0x0B 0x0C 0x0D 0x0E 0x0F";
	
	NSArray *batterySNData = [strFind componentsSeparatedByString:@" "];
	
	
	
	if([batterySNData count] < 16)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return change"] ;
		return ;
	}
	
	int sum = 0;
	for(int i=1; i<= 17; i++)
	{
		NSString *tmp = [batterySNData objectAtIndex:i];
		
		int intTmp = strtol([tmp UTF8String], NULL, 16);
		sum = sum + intTmp;
	}
	
	sum = sum % 256;
	sum = 255 - sum;
	
	NSString *checkSumHex = [NSString stringWithFormat:@"%02X",sum];
	
	NSString *hex0x = @"0x";
	
	checkSumHex = [hex0x stringByAppendingString:checkSumHex];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :checkSumHex] ;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :checkSumHex] ;
	
	return ;
}

+(void)MatchBatterySN:(NSDictionary*)dictKeyDefined 
{
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mBufferName=nil;  
	NSString *mReferenceBufferName = nil;
	NSString *mReferenceBufferName11 = nil;
	
	NSString *mPrefix=nil;
	NSString *mPostfix=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName11"])
		{
			mReferenceBufferName11 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"Prefix"])
		{
			mPrefix = [dictKeyDefined objectForKey:strKey];
		}
		else if ([strKey isEqualToString:@"Postfix"])
		{
			mPostfix = [dictKeyDefined objectForKey:strKey];
		}
		
	}
	
	if (mReferenceBufferName==nil ||
		mPrefix==nil ||
		mPostfix==nil 
		)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strFind22 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue Prefix
															 :mPrefix Postfix
															 :mPostfix] ;
	
	
	//strFind22 = @"0x44 0x38 0x36 0x31 0x32 0x38 0x33 0x5A 0x41 0x4B 0x59 0x44 0x4D 0x4A 0x32 0x34 0x37 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00";
	
	NSString *mReferenceBufferValue11 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName11] ;
	if (mReferenceBufferValue11==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	NSString *strFind11 = [ToolFun getStrFromPrefixAndPostfix:mReferenceBufferValue11 Prefix
															 :mPrefix Postfix
															 :mPostfix] ;
	
	
	//strFind11 = @"0x44 0x38 0x36 0x31 0x32 0x38 0x33 0x5A 0x41 0x4B 0x59 0x44 0x4D 0x4A 0x32 0x34 0x37 0x01 0x02 0x03 0x04 0x05 0x06 0x07 0x08 0x09 0x0A 0x0B 0x0C 0x0D 0x0E 0x0F";
	
	
	NSArray *batterySNData11 = [strFind11 componentsSeparatedByString:@" "];
	if([batterySNData11 count] < 16)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return change"] ;
		return ;
	}
	
	NSArray *batterySNData22 = [strFind22 componentsSeparatedByString:@" "];
	if([batterySNData22 count] < 16)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"diags return change"] ;
		return ;
	}
	
	
	for(int i=18; i<= 32; i++)
	{
		NSString *mmmmm = [batterySNData22 objectAtIndex:i];
		if(![[batterySNData22 objectAtIndex:i] isEqualToString: @"0x00"])
		{
			NSString *result = @"not all last 15 byte are 0: ";
			result = [result stringByAppendingString:strFind22];
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :result] ;
			return ;
		}
	}
	
	for(int i=1; i<= 17; i++)
	{
		NSString *ghjjj = [batterySNData22 objectAtIndex:i];
		NSString *jjklsfdsflklk = [batterySNData11 objectAtIndex:i];
		if(![ghjjj isEqualToString: jjklsfdsflklk])
		{
			NSString *result = @"the first 16 byte are not match: ";
			result = [result stringByAppendingString:strFind22];
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :result] ;
			return ;
		}
	}
	
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strFind22] ;
	
	return ;
}
/*SCRID-108:end*/

+(void)usbpOpen:(NSDictionary*)dictKeyDefined 
{
	NSString *usbCommand=@"/usr/local/bin/astrisctl --host usb relay vbus 0";
		
    system([usbCommand UTF8String]);
	
}

+(void)usbpClose:(NSDictionary*)dictKeyDefined 
{
	NSString *usbCommand=@"/usr/local/bin/astrisctl --host usb relay vbus 1";
		
    system([usbCommand UTF8String]);
	
}

//Julian add for Px 20120210
+(void)SendCmdtoTerminal:(NSDictionary*)dictKeyDefined
{
	NSString* strCmd=@"";
	NSString* strPra=nil;
    NSString* strBuf=nil;
    NSPipe* newpipe = [NSPipe pipe];
    NSFileHandle *readHandle =[newpipe fileHandleForReading];;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"Cmd"])
		{
			strCmd = [strCmd stringByAppendingString:[dictKeyDefined objectForKey:strKey]];
		}else if ([strKey isEqualToString:@"Pra"])
		{
			strPra = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"BufferName"])
        {
            strBuf = [dictKeyDefined objectForKey:strKey];
        }
	}
	
	NSMutableString *mutStrTmp = [NSMutableString stringWithString:strPra];
	NSArray *arguments = [mutStrTmp componentsSeparatedByString:@" "];
	
    int i = [[dictKeyDefined objectForKey:@"DUTID"] intValue];
    
    if([task[i] isRunning])
        [task[i] terminate];
    if(task[i]!=nil)
    {
        task[i]= nil ;
        [task[i] release] ;
    }
    
    task[i]=[[NSTask alloc] init] ;
    [task[i] setStandardOutput:newpipe];
    [task[i] setLaunchPath: strCmd];
    [task[i] setArguments: arguments];
    [task[i] launch];
    NSLog(@"task1 start................\n");
    NSData* revData=[readHandle availableData];
    NSString * strData=[[NSString alloc] initWithData:revData encoding:NSASCIIStringEncoding];
    NSLog(@"strData is %@/n",strData);
    [TestItemManage setBufferValue:dictKeyDefined :strBuf :strData];
//    [task[i] release];
//    [strData release];
    
//	if([strDUTID isEqualToString:@"1"])
//	{
//		if([task1 isRunning])
//			[task1 terminate];
//		if(task1!=nil)
//		{
//			[task1 release] ;
//			task1 = nil ;
//		}
//
//		task1=[[NSTask alloc] init];
//        [task1 setStandardOutput:newpipe];
//		[task1 setLaunchPath: strCmd];
//		[task1 setArguments: arguments];
//		[task1 launch];
//        NSLog(@"task1 start................\n");
//        NSData* revData=[readHandle availableData];
//        NSString * strData=[[NSString alloc] initWithData:revData encoding:NSASCIIStringEncoding];
//        NSLog(@"strData is %@/n",strData);
//        [TestItemManage setBufferValue:dictKeyDefined :strBuf :strData];
//        [task1 release];
//        [strData release];
//	}
//	else if([strDUTID isEqualToString:@"2"])
//	{
//		if([task2 isRunning])
//			[task2 terminate];
//		if(task2!=nil)
//		{
//			[task2 release] ;
//			task2 = nil ;
//		}
//
//		task2=[[NSTask alloc] init];
//		[task2 setLaunchPath:strCmd];
//		[task2 setArguments: arguments];
//		[task2 launch];
//        NSData* revData=[readHandle availableData];
//        NSString * strData=[[NSString alloc] initWithData:revData encoding:NSASCIIStringEncoding];
//        NSLog(@"strData is %@/n",strData);
//        [TestItemManage setBufferValue:dictKeyDefined :strBuf :strData];
//        [task2 release];
//        [strData release];
//	}
    
}

+ (void)ParseTHUMMonior:(NSDictionary*)dictKeyDefined
{
	NSString *strTestResultForUIinfo ;
	enum TestResutStatus enumResult ;
	enumResult =RESULT_FOR_FAIL ;
	strTestResultForUIinfo = @"Fail" ;
	
	//key parse
	NSString *mTestItemName=nil        ;
	NSString *mReferenceBufferName=nil ;
	NSString *mReferenceBufferValue=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
    mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    if (mReferenceBufferValue == nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"] ;
        return;
    }
    
    NSArray *arrValue = [mReferenceBufferValue componentsSeparatedByString:@" "];
    //Make sure the received data is ''strData is 4/22/2014 13:45:10 77.628020 F 59.790362 62.541049 F /n"
    //So we can get temp and humi from right index in arary.
    if ([arrValue count] != 8) {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"received data error"] ;
        return;
    }
    
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"Temperature(F)" :nil :nil :nil :[arrValue objectAtIndex:2] :@"F" :RESULT_FOR_PASS :@"PASS"];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"Humidity(%)" :nil :nil :nil :[arrValue objectAtIndex:4] :@"%" :RESULT_FOR_PASS :@"PASS"];
    [TestItemManage setSubItemPDCAInfo:dictKeyDefined :@"Dew point(F)" :nil :nil :nil :[arrValue objectAtIndex:5] :@"F" :RESULT_FOR_PASS :@"PASS"];
    
    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mReferenceBufferValue] ;
    return;
}

+ (void)ParseControlUSBBySendCommandToComputer:(NSDictionary*)dictKeyDefined
{
	NSString *mWriteCmdToPC = nil;
	
	for(int i = 0; i < [dictKeyDefined count]; i++)
	{
		NSString *strKey = [[dictKeyDefined allKeys] objectAtIndex:i];
		if ([strKey isEqualToString:@"WriteCmdToPC"])
		{
			mWriteCmdToPC = [dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSString* mSerialPort = [self getCurrUnitDeviceName:dictKeyDefined] ;
	NSString* mSerialNum = [ToolFun getStrFromPrefixAndPostfix:mSerialPort Prefix:@"kong-" Postfix:nil];
	
	NSMutableString *mutStrTmp = [NSMutableString stringWithString:mWriteCmdToPC];
	[mutStrTmp replaceOccurrencesOfString:@"serialnum" withString:mSerialNum options:NSBackwardsSearch range:NSMakeRange(0, [mutStrTmp length])];
	
	NSLog(@"mSerialPort is %@\n",mSerialPort);
	NSLog(@"mSerialNum is %@\n",mSerialNum);
	NSLog(@"strPra is %@\n",mutStrTmp);
	
	system([mutStrTmp UTF8String]);
    //	if([mWriteCmdToPC rangeOfString:@"vbus 0"].length > 0)
    //	{
    //		NSString *usbCommand=@"/usr/local/bin/astrisctl --host KongSWD-serialnum relay vbus 0";///usr/local/bin/
    //		NSString* mSerialPort = [self getCurrUnitDeviceName:dictKeyDefined] ;
    //		NSString* mSerialNum = [ToolFun getStrFromPrefixAndPostfix:mSerialPort Prefix:@"kong-" Postfix:nil];
    //
    //		NSMutableString *mutStrTmp = [NSMutableString stringWithString:usbCommand];
    //		[mutStrTmp replaceOccurrencesOfString:@"serialnum" withString:mSerialNum options:NSBackwardsSearch range:NSMakeRange(0, [mutStrTmp length])];
    //
    //		NSLog(@"mSerialPort is %@\n",mSerialPort);
    //		NSLog(@"mSerialNum is %@\n",mSerialNum);
    //		NSLog(@"strPra is %@\n",mutStrTmp);
    //		
    //		system([mutStrTmp UTF8String]);
    //	}
    //	else
    //	{
    //		NSString *usbCommand1=@"/usr/local/bin/astrisctl --host usb relay vbus 1";
    //		system([usbCommand1 UTF8String]);
    //		sleep(2);
    //	}	
}


@end
