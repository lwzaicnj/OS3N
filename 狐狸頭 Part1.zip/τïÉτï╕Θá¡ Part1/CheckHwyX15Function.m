//
//  CheckHwyX15Function.m
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CheckHwyX15Function.h"


@implementation TestItemParse(CheckHwyX15Function)

+(void)CheckHwyX15:(NSDictionary*)dictKeyDefined
{	
	/*SCRID-xxx: try. 2011-12-08 Henry Huang*/
	///try
	/*SCRID-xxx:end*/
	
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mSnType=nil;
	NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferName1=nil;

	//SCRID-138: Add Check Camera SN. 2011-10-21 JianSheng
	//jfdkjkjfkl
	//SCRID-138:end
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;//to get SFC value
		}

		else if ([strKey isEqualToString:@"SnType"])
		{
			mSnType = [dictKeyDefined objectForKey:strKey] ;
		}
	}
/*
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
*/
	NSString *mReferenceBufferValue = @"" ;
	NSString *mBufferValue = @"" ;
	mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName] ;
	mBufferValue = [TestItemManage getBufferValue:dictKeyDefined :@"MLBSN"] ;


	if([mSnType isEqualToString:@"HWY"] || [mSnType isEqualToString:@"hwy"])
	{
		NSString *HWYSNScan = @"" ;
		HWYSNScan = [TestItemManage getScanValue:dictKeyDefined :@"strHwySn"];
		NSString *HWYSNSFC = @"" ;
		HWYSNSFC = [TestItemManage getSFCValue:dictKeyDefined :@"strHwySn"];
		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([HWYSNSFC length]>3 && [HWYSNScan isEqualToString:HWYSNSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :HWYSNSFC] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :HWYSNSFC] ; 
			}
		}
		else
		{	
			if([HWYSNScan length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :HWYSNScan] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :HWYSNScan] ; 
			}
		}
	}
	else if([mSnType isEqualToString:@"X15"] || [mSnType isEqualToString:@"x15"])
	{
		NSString *X15SNScan = @"" ;
		X15SNScan = [TestItemManage getScanValue:dictKeyDefined :@"strX15Sn"];
		NSString *X15SNSFC = @"" ;
		X15SNSFC = [TestItemManage getSFCValue:dictKeyDefined :@"strX15Sn"];
		NSString *HWCofig = @"";
		HWCofig = [TestItemManage getSFCValue:dictKeyDefined :@"strHWCofig"];

		NSRange rangeTmp1=[HWCofig rangeOfString:@"UMTS"];
		NSRange rangeTmp2=[HWCofig rangeOfString:@"GPS"] ;
		if (rangeTmp1.length > 0 || rangeTmp2.length > 0)
		{
			if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
			{
				if([X15SNSFC length]>3 && [X15SNScan isEqualToString:X15SNSFC])
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :X15SNSFC] ; 
				}
				else
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :X15SNSFC] ; 
				}
			}
			else
			{	
				if([X15SNScan length] > 3)
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :X15SNScan] ; 
				}
				else
				{
					[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :X15SNScan] ; 
				}
			}
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"ByPass"] ; 
		}
	}
	else if([mSnType isEqualToString:@"MLBSN"] || [mSnType isEqualToString:@"mlbsn"])
	{
		NSString *UnitMLBSN = @"";
		UnitMLBSN = mBufferValue;
		NSString *MLBSNSFC = @"" ;
		MLBSNSFC = [TestItemManage getSFCValue:dictKeyDefined :@"strMlbSn"];

		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([UnitMLBSN length]>3 && [UnitMLBSN isEqualToString:MLBSNSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :MLBSNSFC] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([UnitMLBSN length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UnitMLBSN] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
	
	//SCRID:107 Add LCDSN by kenshin 2011.05.27 
	else if([mSnType isEqualToString:@"LCDSN"] || [mSnType isEqualToString:@"lcdsn"])
	{
		NSString *UnitLCDSN = @"";
		UnitLCDSN = mReferenceBufferValue;
		NSString *LCDSNSFC = @"" ;
		//LCDSNSFC = [TestItemManage getSFCValue:dictKeyDefined :STRKEYDSPLSN];//remove by justin  and add below get value funtion 20140228
		LCDSNSFC = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];//add by justin 20140228
		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([UnitLCDSN length]>3 && [UnitLCDSN isEqualToString:LCDSNSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :LCDSNSFC] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([UnitLCDSN length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UnitLCDSN] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
	//SCRID:107 end 2011.05.27
    //Henry add 20120801 GrapeSN check, pole star DVT requested
    else if([mSnType isEqualToString:@"GRPSN"] || [mSnType isEqualToString:@"grpsn"])
	{
		NSString *UnitGRPSN = @"";
		UnitGRPSN = mReferenceBufferValue;
		NSString *GRPSNSFC = @"" ;
		//GRPSNSFC = [TestItemManage getSFCValue:dictKeyDefined :STRKEYGRAPESN];//remove by justin  and add below get value funtion 20140228
		GRPSNSFC = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1];//add by justin 20140228

		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([UnitGRPSN length]>3 && [UnitGRPSN isEqualToString:GRPSNSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :GRPSNSFC] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([UnitGRPSN length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :UnitGRPSN] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
    //Henry add end 20120801
	else if([mSnType isEqualToString:@"X23SN"] || [mSnType isEqualToString:@"x23sn"]) //joko add 2010-09-13
	{
		NSString *SNFromUnit = mReferenceBufferValue;
		NSString *SNFromSFC = [TestItemManage getSFCValue:dictKeyDefined :STRKEYX23];
		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([SNFromUnit length]>3 && [SNFromUnit isEqualToString:SNFromSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([SNFromUnit length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
	else if([mSnType isEqualToString:@"X26SN"] || [mSnType isEqualToString:@"x26sn"]) //joko add 2010-09-13
	{
		NSString *SNFromUnit = mReferenceBufferValue;
		NSString *SNFromSFC = [TestItemManage getSFCValue:dictKeyDefined :STRKEYX26];
		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([SNFromUnit length]>3 && [SNFromUnit isEqualToString:SNFromSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([SNFromUnit length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
	else if([mSnType isEqualToString:@"X25SN"] || [mSnType isEqualToString:@"x25sn"]) //joko add 2010-09-13
	{
		NSString *SNFromUnit = mReferenceBufferValue;
		NSString *SNFromSFC = [TestItemManage getSFCValue:dictKeyDefined :STRKEYX25];
		
		if([[ScriptParse getValueFromSummary:@"NeedSFC"] boolValue])
		{
			if([SNFromUnit length]>3 && [SNFromUnit isEqualToString:SNFromSFC])
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
		else
		{	
			if([SNFromUnit length] > 3)
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :SNFromUnit] ; 
			}
			else
			{
				[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ; 
			}
		}
	}
	
}

@end

