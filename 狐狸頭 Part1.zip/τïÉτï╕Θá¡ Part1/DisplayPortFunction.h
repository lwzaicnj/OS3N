//
//  ParseCheckBatDeviceNameFunction.h
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: DisplayPortFunction.h
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.26                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :DisplayPort Parser Method
 
 PURPOSE :Parse DisplayPort function.
 
 $History:: DisplayPortFunction.h                                              
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.26   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */
 
#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(DisplayPortFunction)

//+(void)ExecBundle:(NSDictionary*)dictKeyDefined;
+(void)DPtest:(NSDictionary*)dictKeyDefined;

/*
+(void)DPHotPlugDetectSleepTest:(NSDictionary*)dictKeyDefined;
+(void)DPHotPlugDetectWakeTest:(NSDictionary*)dictKeyDefined;
+(void)DPEDIDReadBack:(NSDictionary*)dictKeyDefined;
+(void)DPHDCPValidKey:(NSDictionary*)dictKeyDefined; //joko add 2010-10-11
+(void)DPHDCPCompliant:(NSDictionary*)dictKeyDefined;

+(void)DP640x480PatternRedCRC:(NSDictionary*)dictKeyDefined;
+(void)DP640x480PatternGreenCRC:(NSDictionary*)dictKeyDefined;
+(void)DP640x480PatternBlueCRC:(NSDictionary*)dictKeyDefined;
+(void)DP640x480PatternLinkStatus:(NSDictionary*)dictKeyDefined;
+(void)DP640x480Patternvideostatus:(NSDictionary*)dictKeyDefined;

+(void)DP162traininglane1swing:(NSDictionary*)dictKeyDefined;
+(void)DP162traininglane1preemphasis:(NSDictionary*)dictKeyDefined;
+(void)DP162traininglane2swing:(NSDictionary*)dictKeyDefined;
+(void)DP162traininglane2preemphasis:(NSDictionary*)dictKeyDefined;

+(void)DP1280x720PatternRedCRC:(NSDictionary*)dictKeyDefined;
+(void)DP1280x720PatternGreenCRC:(NSDictionary*)dictKeyDefined;
+(void)DP1280x720PatternBlueCRC:(NSDictionary*)dictKeyDefined;
+(void)DP1280x720PatternLinkStatus:(NSDictionary*)dictKeyDefined;
+(void)DP1280x720Patternvideostatus:(NSDictionary*)dictKeyDefined;


+(void)DP27traininglane1swing:(NSDictionary*)dictKeyDefined;
+(void)DP27traininglane1preemphasis:(NSDictionary*)dictKeyDefined;
+(void)DP27traininglane2swing:(NSDictionary*)dictKeyDefined;
+(void)DP27traininglane2preemphasis:(NSDictionary*)dictKeyDefined;

+(void)DPPRBSlane1:(NSDictionary*)dictKeyDefined;
+(void)DPPRBSlane2:(NSDictionary*)dictKeyDefined;
*/

@end
