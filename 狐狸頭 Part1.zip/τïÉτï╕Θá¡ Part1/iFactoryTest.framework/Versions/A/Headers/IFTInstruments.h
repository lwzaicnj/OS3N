//
//  IFTInstruments.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 10/14/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTDiags.h"
#import "IFTDavDP.h"
#import "IFTGpib.h"
#import "IFTAgilentDMM.h"
#import "IFTAgilentDCSupply.h"
#import "IFTAgilentIRMeter.h"
#import "IFTKikusuiELoad.h"
#import "IFTAgilentDA34970.h"
#import "IFTAardvarkI2C.h"

@interface IFTInstruments : NSObject {

}

//the return instrument is allocated but not autoreleased
+(id)creaeteInstrument:(NSDictionary*)instInfo error:(NSError**)e;
@end
