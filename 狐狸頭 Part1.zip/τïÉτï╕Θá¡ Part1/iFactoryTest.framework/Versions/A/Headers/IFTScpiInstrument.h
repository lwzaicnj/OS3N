//
//  IFTScpiInstrument.h
//  iFactoryTest
//
//  Created by Wei Wang on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "IFTAsciiReadWriteDevice.h"

extern const NSString* kScpiMeasureTypeDCV;
extern const NSString* kScpiMeasureTypeDCI;
extern const NSString* kScpiMeasureTypeACV;
extern const NSString* kScpiMeasureTypeACI;
extern const NSString* kScpiMeasureTypeR;
extern const NSString* kScpiMeasureTypeR4Wire;
extern const NSString* kScpiMeasureTypeFreq;
extern const NSString* kScpiMeasureTypeCONT;
extern const NSString* kScpiMeasureTypeDIOD;
extern const int kIFTScipInvalidValue;

extern const NSString* kIFTScipErrorDomain;

@interface IFTScpiInstrument : NSObject <IFTAsciiReadWriteDevice> {
	id<IFTAsciiReadWriteDevice> device;
	NSString* lineEnd;
	NSString* identity;
}

@property (readwrite, copy) NSString* lineEnd;

-(id<IFTAsciiReadWriteDevice>)device;
-(id)initWithDevice:(id<IFTAsciiReadWriteDevice>)device;

- (BOOL)close:(NSError**) error;
-(BOOL)write:(NSString*)cmd error:(NSError**)e;
-(NSString*)read:(int)maxLength error:(NSError**)e;

//return value indicates if there is error
-(BOOL)queryError:(NSError**)e;
-(BOOL)clearStatus:(NSError**)e;
-(NSError*)makeError:(int)errCode message:(NSString*)msg;
-(BOOL)reset:(NSError**)e;
-(NSString*)identity:(NSError**)e;
-(NSString*)query:(NSString*)cmd error:(NSError**)e;
-(BOOL)command:(NSString*)cmd waitTillDone:(BOOL)wait error:(NSError**)e;
@end
