//
//  IFTAardvarkI2C.h
//  iFactoryTest
//
//  Created by Wei Wang on 8/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>

@interface IFTAardvarkI2C : NSObject {
	int handle;
	unsigned short port;
	BOOL powerTarget;
	int bitRate;
	BOOL enablePullUp;
	int busTimeoutInMilliSecond;
	
}

@property (readwrite) int bitRate;
@property (readwrite) int busTimeoutInMilliSecond;
@property (readwrite) BOOL powerTarget;
@property (readwrite) BOOL enablePullUp;

+(NSArray*)detectAardvarks;
-(id)initWithAaPort:(int)portNumber;
-(BOOL)open:(NSError**)e;
-(BOOL)close:(NSError**) error;
-(BOOL)write:(unsigned short)slave content:(const unsigned char*)data length:(int)numBytes error:(NSError**)e;
-(NSData*)read:(unsigned short)slave length:(int)numBytes error:(NSError**)e;
-(void)sleepMSecond:(int)milliSecond;

@end
