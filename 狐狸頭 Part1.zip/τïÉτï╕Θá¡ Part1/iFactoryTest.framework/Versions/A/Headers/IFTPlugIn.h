/*
 *  IFTPlugIn.h
 *  iFactoryTestFramework
 *
 *  Created by Wei Wang on 11/2/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */


//This is for client code of the iFactoryTest.framework. It should not be used by
//code in the framework
#import "iFactoryTest/IFTestSiteManager.h"
#import "iFactoryTest/IFTestResult.h"
#import "iFactoryTest/IFTestSuite.h"
#import "iFactoryTest/IFTestMethod.h"
#import "iFactoryTest/IFTSubTestInfo.h"