//
//  IFTSocket.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IFTUtil.h"


@interface IFTSocket : NSObject {
    CFReadStreamRef rStream;
    CFWriteStreamRef wStream;
    int timeOutInSeconds;
    NSString* strIPAddr;
}

@property (readonly) NSString* strIPAddr;
@property (readwrite) int timeOutInSeconds;

-(id)init:(const char*)ipAddr port:(int)port;
-(Boolean) WaitForConnection:(CFWriteStreamRef) wStream;

-(BOOL)write:(NSString*)cmd error:(NSError**)error;
-(NSString*)read:(NSError**)error;
-(NSString*)readUntil:(NSString*)marker error:(NSError**)error;
-(NSString*)readLine:(NSError**)error;
@end
