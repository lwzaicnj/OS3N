//
//  IFTAgilentDA34970.h
//  iFactoryTest
//
//  Created by Wei Wang on 8/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IFTAsciiReadWriteDevice.h"
#import "IFTScpiInstrument.h"
#import "IFTAgilentConstants.h"


@interface IFTAgilentDA34970 :  IFTScpiInstrument {

}

-(id)initWithAsciiReadWriteDevice:(id<IFTAsciiReadWriteDevice>)device;

-(BOOL)config:(const NSString*)channel function:(NSString*)func error:(NSError**)e;
-(float)measure:(const NSString*)channel error:(NSError**)e;
@end
