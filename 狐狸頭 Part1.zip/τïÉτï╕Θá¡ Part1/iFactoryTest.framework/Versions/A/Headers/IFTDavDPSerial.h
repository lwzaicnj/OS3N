//
//  IFTDavDPSerial.h
//  iFactoryTest
//
//  Created by Wei on 8/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTDavDP.h"
#import "IFTDiags.h"


@interface IFTDavDPSerial : IFTDavDP {
	IFTSerial* com;
}
	
	@property (readonly) IFTSerial* com;
	

	-(id)init:(NSString*)bsdPath;
	-(id)initWithPort:(IFTSerial*)p_com;
	
	
	-(NSArray*)sendCommand:(NSString*)cmd timeOutInSeconds:(int)timeOut error:(NSError**)e;

	-(BOOL)resetCommunication:(NSError**)error;
	-(void)initComm:(NSError**)e;

@end
