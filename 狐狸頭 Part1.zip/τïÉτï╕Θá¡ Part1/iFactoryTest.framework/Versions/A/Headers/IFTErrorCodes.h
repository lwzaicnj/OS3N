/*
 *  IFTErrorCodes.h
 *  iFactoryTestFramework
 *
 *  Created by Wei Wang on 10/15/09.
 *  Copyright 2009 Apple. All rights reserved.
 *
 */

#define kIFTConfigDataError -60000
#define kIFTConfigLoadError -40000
#define kIFTConfigUnrecognizedMethodError -40001
#define kIFTInvalidResourceForSite -80001
#define kIFTSocketWriteError -20000
#define kIFTSocketReadError -20001
#define kIFTDAVDPCommandError -21000
#define kIFTDAVDPCommError -21001
#define kIFTDAVDPReadBackTimeoutError -21002
#define kIFTSerialWriteErrorCode -10000
#define kIFTSerialReadErrorCode -10001
#define kIFTSerailOpenErrorCode -10002
#define kIFTGpibErrorCode -15000
#define kIFTIRMeterErrorInvalidState -15100
#define kIFTIRMeterErrorInvalidReturnString -15101
#define kIFTUnknownInstrument -70000
#define kIFTMobDevCopyDeviceValueFail -80000

#pragma mark aardvark_errors
#define kIFTAardvarkOpenError -90001
#define kIFTAardvarkReadError -90002
#define kIFTAardvarkWriteError -90003


