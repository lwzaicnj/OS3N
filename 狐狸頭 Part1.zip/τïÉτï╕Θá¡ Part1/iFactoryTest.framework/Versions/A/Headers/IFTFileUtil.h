//
//  untitled.h
//  iFactoryTest
//
//  Created by Wei Wang on 1/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface IFTFileUtil : NSObject {

}

+(NSArray*)readLines:(NSString*)path error:(NSError**)error;

//assume the input is an array of textual lines, this function disposes of the empty lines in the begining and end 
//of the array, but not empty lines in the middle
+(NSArray*)trimEmptyLines:(NSArray*)lines;

@end
