//
//  IFTAgilentDCSupply.h
//  iFactoryTest
//
//  Created by Wei Wang on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IFTAsciiReadWriteDevice.h"
#import "IFTScpiInstrument.h"
#import "IFTAgilentConstants.h"


@class IFTScpiInstrument;
@interface IFTAgilentDCSupply : IFTScpiInstrument {

}

-(id)initWithAsciiReadWriteDevice:(id<IFTAsciiReadWriteDevice>)device;

-(BOOL)setVolt:(float)volt error:(NSError**)e;
-(BOOL)setCurrent:(float)current error:(NSError**)e;
-(BOOL)setRange:(const NSString*)range error:(NSError**)e;
-(float)measureCurrent:(NSError**)e;
-(float)measureVoltage:(NSError**)e;
-(BOOL)turnOn:(NSError**)e;
-(BOOL)turnOff:(NSError**)e;
-(BOOL)setVoltage:(float)volt current:(float)c inRange:(const NSString*)range error:(NSError**)e;
@end
