//
//  IFTAgilentIRMeter.h
//  iFactoryTest
//
//  Created by Wei Wang on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IFTAsciiReadWriteDevice.h"
#import "IFTScpiInstrument.h"
#import "IFTErrorCodes.h"


@interface IFTAgilentIRMeter : IFTScpiInstrument {

}

-(id)initWithAsciiReadWriteDevice:(id<IFTAsciiReadWriteDevice>)device;
-(BOOL)setCurrent:(float)currentInAmp error:(NSError**)e;
-(BOOL)setAverage:(int)avg error:(NSError**)e;
-(float)measure:(NSError**)e;
@end
