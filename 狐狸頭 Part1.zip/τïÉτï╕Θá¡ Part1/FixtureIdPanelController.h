/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa         $Workfile:: FixtureIdPanelController.h  $|
 | $Author:: Henry           $Revision::  1							 $|
 | CREATED: 29.08.10         $Modtime:: 11.08.10 15:24				 $|
 | STATE  : Alpha                                                     |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIModuleSN.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */

#import <Cocoa/Cocoa.h>
#import "UICommon.h"


@interface FixtureIdPanelController : NSWindowController {
	IBOutlet NSTextField *textFixtureId;
	IBOutlet NSTextField *labelShowFixtureId;
	IBOutlet NSWindow *win;
	NSString* fixtureId;
	IBOutlet NSButton *btnOK ;
	
}
-(BOOL)windowShouldClose:(id)window;
- (IBAction)textFixtureIdChange:(id)sender;
- (IBAction)btnOKClick:(id)sender;
- (IBAction)btnExitClick:(id)sender;

- (NSString *)getFixtureId;
- (void)showFixtureId:(NSString *)strFixId;
@end
