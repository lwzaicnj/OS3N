//
//  CommManage.m
//  qt_simulator
//
//  Created by diags on 1/15/10.
//  Copyright 2010 Foxconn. All rights reserved.
//

#import "CommManage.h"
#import "ScriptParse.h"


NSString* const MACOS_COMM_TIMEOUT            =@"MACOS_COMM_TIMEOUT";  //timeout event 

//Key define
NSString* const KeyDictionary =@"KeyDictionary" ;   //all keys(NSDictionary) value associted with 

NSString* const DeviceID = @"DeviceID"         ;   // Device info value associted with  
NSString* const CommObject =@"CommObject"      ;   //comm object associted with

NSString* const DeviceName =@"DeviceName"      ;   ////device name value associate with
NSString* const BufferName =@"BufferName"      ; 

NSString* const TimeOut = @"TimeOut"           ;  ///
NSString* const ReadOnly = @"ReadOnly"         ;
NSString* const EndString = @"EndString"       ;   

NSString* const TimerObject = @"TimerObject"   ; //assoited with a NSTimer object ;


@implementation CommManage

-(id)init
{
	mdComm = nil ;
	mdReceDatabuffer = nil ;
	mdSendDataBuffer = nil ;
	mdCurrentKeyUsed = nil ;
	if (self=[super init])
	{
		mdComm = [[NSMutableDictionary alloc] init] ;
	}
	return self ;
}

-(void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self] ;
	//close all device
	if (mdComm!=nil)
	{
		NSArray *arrTmp = [mdComm allKeys] ;
		for (int i=0 ;i<[arrTmp count] ;i++)
		{
			[self ClosePort:[arrTmp objectAtIndex:i]] ;
		}
		
	}
	//close all device end
	[mdComm release] ;
	[mdReceDatabuffer release] ;
	[mdSendDataBuffer release] ;
	[mdCurrentKeyUsed release] ;
	[super dealloc] ;
}

-(bool)OpenPort:(NSString*)strDeviceID  PortName
               :(NSString*)portName     BaudRate
               :(enum BaudRate)baudRate DataBits   
               :(enum DataBits)dataBits StopBit
               :(enum StopBit)stopBit   Parity
               :(enum Parity)parity     FlowControl
               :(enum FlowControl)flowControl      KeysDefine    
			   :(NSDictionary*) dKey;
{
	//check parameter
	if ( (strDeviceID==nil) || (portName ==nil) )
		return false ;
	//create a comm object
	
	UartComm *comm=[[UartComm alloc] init] ;
	
	//first register the listen function .
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotificationHandle:) name:nil object:comm ] ;
	[comm setPortID:strDeviceID] ;
	if ([comm OpenPort:portName BaudRate
				  :baudRate DataBits
				  :dataBits  StopBit
				  :stopBit Parity
				  :parity  FlowControl
				  :flowControl]
		) 
	/*create successful*/	
	{
		/*prepare key -value */
		NSMutableDictionary *mdTmp =[[NSMutableDictionary alloc] init] ;
		[mdTmp setObject:comm forKey:CommObject] ;
		if (dKey!=nil)
			[mdTmp setObject:dKey forKey:KeyDictionary] ;

		[mdComm setObject:mdTmp forKey:strDeviceID] ;
		
		//store key - value
		if (mdCurrentKeyUsed==nil)
			mdCurrentKeyUsed = [[NSMutableDictionary alloc] init] ;
		
		[mdCurrentKeyUsed removeObjectForKey:strDeviceID] ; //clear old DeviceID 'S ALL KEY DEFINED .
		
		if ([[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary]!=nil)
			[mdCurrentKeyUsed setObject:[[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary] forKey:strDeviceID];  
		
		
		[mdTmp release] ;
		[comm release] ;
		return true ;
	}else /*create fail*/
	{
		[comm release] ;
		return false ;
	}
}


-(bool)Socket_OpenPort:(NSString*)strDeviceID IPAddress
                      :(NSString*)strIP PortID
                      :(int)iPortID     KeysDefine    
					  :(NSDictionary*) dKey
{
	//check parameter
	if ( (strDeviceID==nil) || (strIP ==nil) )
		return false ;
	//create a comm object
	
	UartComm *comm=[[UartComm alloc] init] ;
	
	//first register the listen function .
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotificationHandle:) name:nil object:comm ] ;
	[comm setPortID:strDeviceID] ;
	if ([comm Socket_OpenPort:strIP PortID:iPortID]) 
	/*create successful*/	
	{
		/*prepare key -value */
		NSMutableDictionary *mdTmp =[[NSMutableDictionary alloc] init] ;
		[mdTmp setObject:comm forKey:CommObject] ;
		if (dKey!=nil)
			[mdTmp setObject:dKey forKey:KeyDictionary] ;
		
		[mdComm setObject:mdTmp forKey:strDeviceID] ;
		
		//store key - value
		if (mdCurrentKeyUsed==nil)
			mdCurrentKeyUsed = [[NSMutableDictionary alloc] init] ;
		
		[mdCurrentKeyUsed removeObjectForKey:strDeviceID] ; //clear old DeviceID 'S ALL KEY DEFINED .
		
		if ([[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary]!=nil)
			[mdCurrentKeyUsed setObject:[[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary] forKey:strDeviceID];  
		
		
		[mdTmp release] ;
		[comm release] ;
		return true ;
	}else /*create fail*/
	{
		[comm release] ;
		return false ;
	}
};

-(bool)IsOpen:(NSString*)strDeviceID
{
	NSDictionary *tmpDict = [mdComm objectForKey:strDeviceID] ;
	if (tmpDict ==nil)
		return false ;
	
	UartComm *tmpComm  = [tmpDict objectForKey:@"CommObject"] ;
	
	if ([[tmpComm className] isEqual:[UartComm className]])
	{
		return [tmpComm IsOpen] ;
	}else
		return false ;
}

-(void)ClosePort:(NSString*)strDeviceID
{
	NSDictionary* dictTmp = [mdComm objectForKey:strDeviceID] ;
	if (dictTmp==nil)
		return ;
	
	
	UartComm *tmpComm = [dictTmp objectForKey:CommObject] ;
	if (tmpComm ==nil)
		return ;
	
	//NSLog(@"\n tmpcomm classname :%@  : %@\n",[tmpComm className] ,[Comm className]);
	if ([[tmpComm className] isEqual:[UartComm className]])
	{
		return [tmpComm ClosePort] ;
	}
}

-(NSString*)getPortName:(NSString*)strDeviceID 
{
	NSDictionary* dictTmp = [mdComm objectForKey:strDeviceID] ;
	if (dictTmp==nil)
		return nil;
	
	
	UartComm *tmpComm = [dictTmp objectForKey:CommObject] ;
	if (tmpComm ==nil)
		return nil;
	
	//NSLog(@"\n tmpcomm classname :%@  : %@\n",[tmpComm className] ,[Comm className]);
	if ([[tmpComm className] isEqual:[UartComm className]])
	{
		return [tmpComm getPortName] ;
	}
	return nil ;
};

-(bool)WriteData:(NSString*)strDeviceID DataBuffer
               :(NSData*)sendBuffer
			   :(NSDictionary*)dtKey
{
	NSDictionary *dictTmp = [mdComm objectForKey:strDeviceID] ;
	if (dictTmp==nil)
		return false ;
	
	UartComm *tmpComm = [dictTmp objectForKey:CommObject] ;
	if (tmpComm ==nil)
		return false ;
	
	if ([[tmpComm className] isEqual:[UartComm className]])
	{
		//store key - value
		if (mdCurrentKeyUsed==nil)
		{
			mdCurrentKeyUsed = [[NSMutableDictionary alloc] init] ;
		}
		if ([[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary]!=nil)
			[mdCurrentKeyUsed setObject:[[mdComm objectForKey:strDeviceID] objectForKey:KeyDictionary] forKey:strDeviceID];  //firset set define key .
		
		if (dtKey!=nil)
			[[mdCurrentKeyUsed objectForKey:strDeviceID] addEntriesFromDictionary:dtKey]; //used new key to replace old key .
		
		[self clearData:strDeviceID] ;//clear data before send buffer
		bool blRtn = [tmpComm SendData:sendBuffer] ;
/*		
    ///cancel by giga	
		if ([self GetCurrentKeyUsed:strDeviceID :TimeOut] !=nil)
		{	
			//open a timer to monitor ,it is used to post a notification when timeout
			NSTimeInterval ti = 3 ;//[self GetCurrentKeyUsed:strDeviceID :TimeOut] ;
			NSTimer *timerTmp =[[NSTimer scheduledTimerWithTimeInterval:ti target
																   :self selector
																   :@selector(timerFireMethod:) userInfo
																   :strDeviceID repeats
																   :NO ] retain] ;
		
			[self SetCurrentKeyUsed:strDeviceID :TimerObject :timerTmp] ;
			[timerTmp release] ;
		}	
*/ 
		return blRtn ;
		
	}else
		return false ;	
}

-(NSData*)ReadData:(NSString*)strDeviceID
{
	NSMutableData *mutabledataTmp = [mdReceDatabuffer objectForKey:strDeviceID] ;
	if (mutabledataTmp!=nil)
	{
		NSData *myData = [[[NSData alloc] initWithBytes:[mutabledataTmp bytes] length:[mutabledataTmp length]] autorelease] ;
		//delete old buffer
		[mutabledataTmp setLength:0] ;
		return myData ;
	}	
	return nil ;
}

- (void)handleNotificationHandle:(NSNotification*)notification
{
	NSAutoreleasePool *pool= [[NSAutoreleasePool alloc] init] ;
	//get the info 
	NSDictionary *ndUserinfo = [notification userInfo] ;
	NSString *nsDeviceID = [ndUserinfo objectForKey:DeviceID] ;
	
	if ([[notification name] isEqualToString:MACOS_COMM_CONNECT_SUCCESS]  ||
		[[notification name] isEqualToString:MACOS_COMM_CONNECT_FAIL]     ||
		[[notification name] isEqualToString:MACOS_COMM_SEND_CHAR]        
	  ) 
	{
/*	
		[[NSNotificationCenter defaultCenter] postNotificationName:[notification name] object:self userInfo:[notification userInfo]] ;
*/		
	}else if ([[notification name] isEqualToString:MACOS_COMM_CONNECT_ABOUT])
	{
        NSString *stationName =[ScriptParse getValueFromSummary:@"TestStation"];
        
        if([stationName rangeOfString:@"iQC RGBW"].length > 0 || [stationName isEqualToString:@"QT0"]){
            ;
        }
//        else if ([nsDeviceID rangeOfString:@"CL200A"].length>0)//add by Justin Shang @ 20151019 for QT1 CL200A Handling
//        {
//            ;
//        }
        else
        {
            NSString *strTmp = [NSString stringWithFormat:@"Device id:%@ \n alreadly Plug out ,program must restart .\n Are you sure ?",nsDeviceID];
            int i =NSRunAlertPanel(@"WARNNING", strTmp, @"Yes", @"No", nil) ;
            if (i)
                exit(1);
            NSLog(@"detect Uart cable unplug");
        }
	}
	else if([[notification name] isEqualToString:MACOS_COMM_RECV_CHAR])
	{
		//get the deviceid 's buffer received
		//step1 get received buffer 
		NSData* nsdTmp =[[[mdComm objectForKey:nsDeviceID] objectForKey:CommObject] ReceiveData] ;
		
		if (mdReceDatabuffer==nil)
			mdReceDatabuffer = [[NSMutableDictionary alloc] init] ;
		
		NSMutableData *nsmdTmp = [mdReceDatabuffer objectForKey:nsDeviceID] ;
		if (nsmdTmp==nil) //for deviceID ,the first received data.
		{	
			nsmdTmp = [[[NSMutableData alloc] initWithData:nsdTmp] autorelease] ;
			[mdReceDatabuffer setValue:nsmdTmp forKey:nsDeviceID] ;
		}else //append data 
		{
			[nsmdTmp appendData:nsdTmp] ;
		}
		//Test used 
		//NSLog(@" \n nsDeviceID=%@ , %@",nsDeviceID,[NSString stringWithCharacters:[nsmdTmp bytes] length:[nsmdTmp length]]) ;
/*		
		if ([self CheckISCompleteDataUsingCurrKey:nsDeviceID]) //yes ,verify receive complete data
		{			
			//clear current device's timer
			[self SetCurrentKeyUsed:nsDeviceID :TimerObject :nil];

			//post a notification associated with deviceID  .
			NSNotification *notificationTmp = [[NSNotification notificationWithName:MACOS_COMM_RECV_CHAR object:self userInfo:[notification userInfo]] retain]  ;
			[[NSNotificationCenter defaultCenter] postNotification:notificationTmp] ;
			[notificationTmp release] ;
		}
 */
	}else
	{
		NSLog(@"\n unknown notification on CommManager object\n");
	}
	[pool release] ;
	
	return ;
};

- (void)timerFireMethod:(NSTimer*)theTimer 
{
	NSString *timerInfo = [theTimer userInfo] ;
	if (timerInfo==nil)
		return ;
/*	
	//post a notification associated with deviceID  .
	NSDictionary *dictTmp = [[NSDictionary dictionaryWithObject:timerInfo forKey:DeviceID] retain];
	NSNotification *notificationTmp = [[NSNotification notificationWithName:MACOS_COMM_TIMEOUT object:self userInfo:dictTmp] retain] ;
	[dictTmp release] ;
	
	[[NSNotificationCenter defaultCenter] postNotification:notificationTmp] ;
	[notificationTmp release] ;
	[self SetCurrentKeyUsed:timerInfo :TimerObject :nil] ;
 */
	return ;
	
}

- (id)GetCurrentKeyUsed:(NSString*)nsstrDeviceID :(NSString*)nsstrKey
{
	NSDictionary *nsdTmp = [mdCurrentKeyUsed objectForKey:nsstrDeviceID] ;
	if (nsdTmp==nil)
		return nil ;
		
	return [nsdTmp objectForKey:nsstrKey] ;
}

- (void)SetCurrentKeyUsed:(NSString*)nsstrDeviceID :(NSString*)nsstrKey:(id)newValue
{
	NSMutableDictionary *nsdTmp = [mdCurrentKeyUsed objectForKey:nsstrDeviceID] ;
	
	if (nsdTmp==nil)
	{
		nsdTmp = [[NSMutableDictionary alloc] init] ;
		[mdCurrentKeyUsed setObject:nsdTmp forKey:nsstrDeviceID] ;
	};
	if (newValue==nil)
		[nsdTmp removeObjectForKey:nsstrKey] ;
	else
		[nsdTmp setObject:newValue forKey:nsstrKey] ;
	
	return  ;
}

- (bool)ISExistOnCurrKeys:(NSString*)nsstrDeviceID :(NSString*)nsstrKey //check whether if the Key
{
	NSDictionary *nsdTmp = [mdCurrentKeyUsed objectForKey:nsstrDeviceID] ;
	if (nsdTmp==nil)
		return false ;
	
	if ([nsdTmp objectForKey:nsstrKey]==nil)
		return false ;
	
	return true ;
};

- (NSString*)CheckISCompleteDataUsingCurrKeyAndGetSN:(NSString*)strDeviceID //true==complete data .flase ==not complete data
{
	NSMutableData*mutdataTmp =[[mdReceDatabuffer objectForKey:strDeviceID] retain] ;
	if (mutdataTmp==nil)
		return @"" ;
	//Check data
	NSString *strOriginal = [[NSString alloc] initWithData:mutdataTmp encoding:NSASCIIStringEncoding];
	NSString *strFind = [[self GetCurrentKeyUsed:strDeviceID :EndString] retain];
	if (strFind==nil) //no ENDSTRING condition.
	{
		[strOriginal release] ;
		[mutdataTmp release];
		return @"" ;
	}
	
	NSRange rangTmp = [strOriginal rangeOfString:strFind]  ;
	if (rangTmp.length <= 0)
	{
		[strOriginal release] ;
		[strFind release];
		[mutdataTmp release];
		return @"" ;
	}
	//[strOriginal release] ;
	[strFind release];
	[mutdataTmp release];
	
	return strOriginal ;
}

- (bool)CheckISCompleteDataUsingCurrKey:(NSString*)strDeviceID //true==complete data .flase ==not complete data
{
	NSMutableData*mutdataTmp =[[mdReceDatabuffer objectForKey:strDeviceID] retain] ;
	if (mutdataTmp==nil)
		return false ;
	//Check data
	NSString *strOriginal = [[NSString alloc] initWithData:mutdataTmp encoding:NSASCIIStringEncoding];
	NSString *strFind = [[self GetCurrentKeyUsed:strDeviceID :EndString] retain];
	if (strFind==nil) //no ENDSTRING condition.
	{
		[strOriginal release] ;
		[mutdataTmp release];
		return true ;
	}
		
	NSRange rangTmp = [strOriginal rangeOfString:strFind]  ;
	if (rangTmp.length <= 0)
	{
		[strOriginal release] ;
		[strFind release];
		[mutdataTmp release];
		return false ;
	}
	[strOriginal release] ;
	[strFind release];
	[mutdataTmp release];
	
	return true ;
}
-(void)clearData:(NSString*)strDeviceID //clear old data
{
	NSMutableData *mutabledataTmp = [mdReceDatabuffer objectForKey:strDeviceID] ;
	if (mutabledataTmp!=nil)
		[mutabledataTmp setLength:0] ;
	return ;
};
+(enum BaudRate)strBaudRateToEnum:(NSString*)strParm
{
	return BAUDRATE_DEFAULT ;
}
+(enum DataBits)strDataBitToEnum:(NSString*)strParm
{
	return DATA_BITS_DEFAULT ;
}
+(enum StopBit)strStopBitToEnum:(NSString*)strParm 
{
	return STOP_BITS_DEFAULT ;
}
+(enum Parity)strParityToEnum:(NSString*)strParm 
{
	return PARITY_DEFAULT;
}
+(enum FlowControl)strFlowControlToEnum:(NSString*)strParm
{
	return FLOW_CONTROL_DEFAULT ;
}

@end
