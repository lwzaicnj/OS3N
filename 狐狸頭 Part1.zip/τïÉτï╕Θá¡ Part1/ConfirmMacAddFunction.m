//
//  CheckMacAddFunction.m
//  qt_simulator
//
//  Created by caijunbo on 3/24/10.DictionaryPtr
//  Copyright 2010 0000000000. All rights reserved.
//
#import "Pudding.h"
#import "ConfirmMacAddFunction.h"


@implementation TestItemParse(ConfirmMacAddFunction)


+(void)ConfirmMacAdd:(NSDictionary*) DictionaryPtr
{
	//key parse
	NSString *mTestItemName=nil ;
	NSString *mReferenceBufferName=nil ;
	
	NSString *mBufferName=nil    ;
	NSString *mPDCAWrite =@"no"  ;
	
	for(int i=0 ;i<[DictionaryPtr count] ;i++)
	{
		NSString* strKey=[[DictionaryPtr allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"PDCAWrite"])
		{
			mPDCAWrite = [DictionaryPtr objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [DictionaryPtr objectForKey:strKey] ;
		}
	}
	
	if (mReferenceBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	}
	
	NSString *mReferenceBufferValue ;
	mReferenceBufferValue = [TestItemManage getBufferValue:DictionaryPtr :mReferenceBufferName] ;
	if (mReferenceBufferValue==nil)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"no received data"] ;
		return ;
	}
	
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\n"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\r"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\t"] ;
	mReferenceBufferValue = [ToolFun deleteFromString:mReferenceBufferValue trimStr:@"\""] ;
	
	BOOL flag =NO;
	
	if ([mReferenceBufferValue length]!=43) 
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Invalid receiving data"] ;
		return ;
	}
	
	if ([mReferenceBufferValue isEqualToString:@"0x00000000 0x00000000 0x00000000 0x00000000"])
		flag=YES;
		
	
	if (flag)
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_FAIL :@"Invalid mac address"] ;
		flag=NO;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:DictionaryPtr :RESULT_FOR_PASS :@"PASS"] ;
	
	}
}

@end
