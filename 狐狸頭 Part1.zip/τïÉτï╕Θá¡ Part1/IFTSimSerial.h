//
//  IFTSimSerial.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/30/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTSerial.h"

@interface IFTSimSerial : IFTSerial {
    NSString* lastCmd;
    double delayTimeInSeconds;
    NSDate* writeDate;
	BOOL isOpen;
}

@property (readwrite, copy) NSString* lastCmd;
@property (readwrite) double delayTimeInSeconds;

-(id)init:(NSString*)_bsdPath;
- (BOOL)open:(NSError**)error;
- (BOOL)close:(NSError**) error;

-(void)setStopBitsFlag:(IFTSerialStopBits)stopBits;
-(void)setParityFlag:(IFTSerialParity)parity;
-(void)setBytesSizeFlag:(IFTSerialByteSize)byteSize;

- (BOOL)write:(NSString*)cmd error:(NSError**)pError;

//the code does not read more than 1000 characters for now. If you need to read
//more than that you have to break up the read yourself.
- (NSString*)read:(int)maxLength error:(NSError**)error;
- (NSString*)readLine:(int)timeOutInSeconds error:(NSError**)error;
-(BOOL)flushBuffer:(NSError**)error;

+(void)setResponseMap:(NSMutableDictionary*)map;
@end
