//
//  ALSFunction.m
//  qt_simulator
//
//  Created by QTeam on 9/28/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "ALSFunction.h"
#import "UIWinManage.h"

@implementation TestItemParse(ALSFunction)


	ALS_Sequencer_API *sequencer;
	bool	waiting_for_sequencer;
	ALS_ERR local_last_error;
	NSString *nowTime = @"";;
	NSString *sn = @"";
	bool bHasInit = false;
	NSString *ALSLogFolderPath = @"";
	

+(id) initALS
{
	//[super init];
	
	waiting_for_sequencer = false;
	
	[[NSNotificationCenter defaultCenter]
	 addObserver:self 
	 selector:@selector(HandleALSSequencerNotification:)
//	 name:alsNotifyName
	 name:(NSString*)alsNotifyName  //SCRID:58 2011-01-05 changed by henry
	 object:nil];	
	
	// Start init and start the sequencer
	sequencer = [[ALS_Sequencer_API alloc] init];
	[sequencer Initialize];
	
	/*SCRID-xxx:jjklfaspjp*/
	
	/*SCRID-xxx:end*/
	
	return self;
}
//jian-sheng li 2013-05-15 : change
/*
 gdfkljals;
 
 */
//change end
+(void) deallocALS
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	
	if(sequencer != nil)
	{
		[sequencer release];
		sequencer=nil;
	}
	//[super dealloc];
}

+(void)ALSParser:(NSDictionary*)dictKeyDefined
{	
    
    /*Jake modify/add ......, 2012-11-23*/
    //......
    
    /*Jake modify/add end ......, 2012-11-23*/
    
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mSnType=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mTimeOut=@"";

	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"SnType"])
		{
			mSnType = [dictKeyDefined objectForKey:strKey] ;
		}else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if(bHasInit == false)
	{
		[self initALS];
		bHasInit = true;
	}
	
	local_last_error = ALS_ERR_FAIL;
	
	nowTime =[self getNowTime];
	sn = [TestItemManage getUnitValue:dictKeyDefined :STRKEYSYSSN];
	ALSLogFolderPath = [NSString stringWithFormat:@"/vault/log/als/"];
	if(sn != nil)
		ALSLogFolderPath = [ALSLogFolderPath stringByAppendingString:sn];
	ALSLogFolderPath = [ALSLogFolderPath stringByAppendingString:@"_"];
	ALSLogFolderPath = [ALSLogFolderPath stringByAppendingString:nowTime];
	//ALSLogFolderPath = [ALSLogFolderPath stringByAppendingString:@"/"];
	
	local_last_error = -1;
	
	[self RunSOP];

	// somewhow need to wait for 
	sleep(3);
	if(local_last_error == ALS_ERR_SUCCESS)
	{
		NSLog(@" ALS the first time SUCCESS, Unit connect and Fixture ready");
	}
	
	local_last_error = -1;
	
	NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
	int iTmp = [mTimeOut intValue] ;
	int timeInterval = - [dateTmp timeIntervalSinceNow] ;
	
		while (timeInterval<=iTmp) {
			timeInterval = -[dateTmp timeIntervalSinceNow] ;
			if(local_last_error != -1)
			//if(local_last_error == ALS_ERR_SUCCESS)
				break;
			sleep(2);   //sleep 2 seconds
		}
	
	// while ! done  AND  ! timedout 
	//	wait for notification to fire
	//		where ! done is last_als_error == -1
	//		where ! timed out is (now - test start time) < timoue from script 

	if(local_last_error == -1)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"testFlowNotDone!"] ;
	}
	else if(local_last_error == ALS_ERR_SUCCESS)
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable	
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :(NSString*)alsErrStrings[local_last_error]];
	else
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :(NSString*)alsErrStrings[local_last_error]] ;
	//end
	

	NSString *strexec= @"ditto -ck --keepParent \"";
	strexec = [strexec stringByAppendingString:ALSLogFolderPath];
	strexec = [strexec stringByAppendingString:@"\" \""];
	strexec = [strexec stringByAppendingString:ALSLogFolderPath];
	strexec = [strexec stringByAppendingString:@".zip\""];
	//strexec = @"ditto -ck --keepParent \"/vault/log\" \"/vault/log.zip\"";
	system([strexec UTF8String]);
	
	NSString *tmp = ALSLogFolderPath;
	tmp = [tmp stringByAppendingString:@".zip"];
	if (mBufferName!=nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :tmp] ;
	
	//[self deallocALS];
}

+(void)ReadALSCsvFileData:(NSDictionary*)dictKeyDefined
{
	/*Jake, Change content,  20112-11-09*/
	//jkkk;;j
	
	/*Jake, Change content,  20112-11-09 end*/
	
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	
	NSString *mReferenceBufferName=nil;

	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	NSString *fileName = [ALSLogFolderPath stringByAppendingString:@"/als_test_data.csv"];
	
	NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	[TestItemManage setBufferValue:dictKeyDefined :@"ALSFILEDATAKEY" :readFData];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
	
}

+(void)ALSCsvFileDataParser:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mLED=nil;
	NSString *mReferenceBufferName=nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	NSString *mTimeOut=@"";
	//end
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LED"])
		{
			mLED = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSString *readFData = [TestItemManage getBufferValue:dictKeyDefined :@"ALSFILEDATAKEY"];
	
	//NSString *fileName = @"/vault/log/als/DLXD5006DFGM_20100929154237/als_test_data.csv";
	//readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	if(readFData == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No get ALS CSV Log File Data"] ;
		return;
	}
	
	NSString *mLow = @"";
	NSString *mChn = @"";
	NSMutableArray *Leds = nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	Leds = (NSMutableArray*)[mLED componentsSeparatedByString:@"&"];
	//end
	if([Leds count] >= 2)
	{
		mLow = [Leds objectAtIndex:0];
		mChn = [Leds objectAtIndex:1];
	}
	
	NSArray *LowValue = nil;
	NSArray *ColumeValue = nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	LowValue = [readFData componentsSeparatedByString:@"\r"];
	//end
	NSString *AlsTestValue = @"";
	//if([LowValue count] > 16)
	if([LowValue count] > [mLow intValue])
	{
		NSString *tmp = [LowValue objectAtIndex:[mLow intValue] - 1];
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning initia variable
		ColumeValue = [tmp componentsSeparatedByString:@","];
		//end
		if([ColumeValue count] > 3)
		{
			AlsTestValue = [ColumeValue objectAtIndex:[mChn intValue] + 2];
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this LED Data in ALS CSV Log File"] ;
		return;
	}
	
	double AlsTestValueD = [AlsTestValue doubleValue];
	if(AlsTestValueD >=[mLowerValue doubleValue] && AlsTestValueD<=[mUpperValue doubleValue])
	{
		enumResult =RESULT_FOR_PASS ;
		if (mBufferName!=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :AlsTestValue] ;
	}else 
	{
		enumResult =RESULT_FOR_FAIL ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :AlsTestValue] ;

}

/*SCRID-7:Add FixtureNuber Parser and CsvFileDataParser.*/
/*Joko Modify,2010-10-21*/
+(void)FixtureNumber:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mRowColume=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"RowColume"])
		{
			mRowColume = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSString *fileName = [ALSLogFolderPath stringByAppendingString:@"/info_als.txt"];
	NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	//NSString *fileName = @"/vault/log/als/DLXD5006DFGM_20100929154237/info_als.txt";
	//NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	if(readFData == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No get info_als File Data"] ;
		return;
	}
	
	if([readFData rangeOfString:@"Fixture Number:"].length > 0)
	{
		//SCRID:58
		//modified by Henry on 2011-01-05 for avoiding warning unused variable
//		int star=[readFData rangeOfString:@"Fixture Number:"].location;
//		int end=[readFData rangeOfString:@"\n"].location;
		//end
		if([readFData rangeOfString:@"\n"].location - [readFData rangeOfString:@"Fixture Number:"].location - 15 >= 1)
		{
			NSString *tmp = [readFData substringFromIndex:[readFData rangeOfString:@"Fixture Number:"].location + 15];
			tmp = [tmp substringToIndex:[tmp rangeOfString:@"\n"].location];
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :tmp] ;
		}
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Invalid Fixture Number"] ;
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Can not find Fixture Number in info_als File"] ;
	}

}


+(void)CsvFileDataParser:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mRowColume=nil;
	NSString *mReferenceBufferName=nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
//	NSString *mTimeOut=@"";
	//end
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"RowColume"])
		{
			mRowColume = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSString *readFData = [TestItemManage getBufferValue:dictKeyDefined :@"ALSFILEDATAKEY"];
	
	//NSString *fileName = @"/vault/log/als/DLXD5006DFGM_20100929154237/als_test_data.csv";
	//NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	if(readFData == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No get CSV Log File Data"] ;
		return;
	}
	
	NSString *mLow = @"";
	NSString *mChn = @"";
	NSMutableArray *Leds = nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initali variable
	Leds = (NSMutableArray*)[mRowColume componentsSeparatedByString:@"&"];
	//end
	if([Leds count] >= 2)
	{
		mLow = [Leds objectAtIndex:0];
		mChn = [Leds objectAtIndex:1];
	}
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *LowValue = nil;
	NSArray *ColumeValue = nil;
	//end
	LowValue = [readFData componentsSeparatedByString:@"\r"];
	NSString *TestValue = @"0.000";
	//if([LowValue count] > 16)
	if([LowValue count] >= [mLow intValue])
	{
		NSString *tmp = [LowValue objectAtIndex:[mLow intValue] - 1];
		ColumeValue = [tmp componentsSeparatedByString:@","];
		if([ColumeValue count] >= [mChn intValue])
		{
			TestValue = [ColumeValue objectAtIndex:[mChn intValue] - 1];
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this Data in CSV Log File"] ;
		return;
	}
	
	double TestValueD = [TestValue doubleValue];
	
	if(((mLowerValue==nil||[mLowerValue length]<=0)?1:(TestValueD >=[mLowerValue intValue]))
	   && ((mUpperValue==nil||[mUpperValue length]<=0)?1:(TestValueD<=[mUpperValue intValue])))
		//if(TestValueD >=[mLowerValue doubleValue] && TestValueD<=[mUpperValue doubleValue])
	{
		enumResult =RESULT_FOR_PASS ;
		if (mBufferName!=nil)
			[TestItemManage setBufferValue:dictKeyDefined :mBufferName :TestValue] ;
	}else 
	{
		enumResult =RESULT_FOR_FAIL ;
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :TestValue] ;
	
}
/*SCRID-7:Modify end*/

+(void)ALSDataRatioParser:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mLED=nil;
	NSString *mReferenceBufferName=nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	NSString *mTimeOut=@"";
	//end
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LED"])
		{
			mLED = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
	}
	NSString *readFData = [TestItemManage getBufferValue:dictKeyDefined :@"ALSFILEDATAKEY"];
	
	//NSString *fileName = @"/vault/log/als/DLXD5006DFGM_20100929154237/als_test_data.csv";
	//readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	if(readFData == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No get ALS CSV Log File Data"] ;
		return;
	}
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *LowValue = nil;
	NSArray *ColumeValue = nil;
	LowValue = [readFData componentsSeparatedByString:@"\r"];
//	NSString *AlsTestValue = @"No Data!";
	//end
	double channel0 = 0;
	double channel1 = 0;
	//if([LowValue count] > 16)
	if([LowValue count] > [mLED intValue])
	{
		NSString *tmp = [LowValue objectAtIndex:[mLED intValue] - 1];
		
		ColumeValue = [tmp componentsSeparatedByString:@","];
		if([ColumeValue count] > 3)
		{
			channel0 = [[ColumeValue objectAtIndex:2] doubleValue];
			channel1 = [[ColumeValue objectAtIndex:3] doubleValue];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this LED Data in ALS CSV Log File"] ;
			return;
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this LED Data in ALS CSV Log File"] ;
		return;
	}
	
	double ratio = 0;
	NSString *SRatio = @"0.000";
	if(channel1 != 0)
	{
		ratio = channel0/channel1;
		SRatio = [NSString stringWithFormat:@"%f",ratio];
	}
	else
		ratio = 0;
	
	if(ratio >=[mLowerValue doubleValue] && ratio<=[mUpperValue doubleValue])
	{
		enumResult =RESULT_FOR_PASS ;
	}else 
	{
		enumResult =RESULT_FOR_FAIL ;
	}
	
	if([SRatio rangeOfString:@"."].length > 0)
	{
		if([SRatio length] >= ([SRatio rangeOfString:@"."].location + 4))
			SRatio = [SRatio substringToIndex:[SRatio rangeOfString:@"."].location + 4];
		else if([SRatio length] == ([SRatio rangeOfString:@"."].location + 3))
			SRatio = [SRatio stringByAppendingString:@"0"];
		else if([SRatio length] == ([SRatio rangeOfString:@"."].location + 2))
			SRatio = [SRatio stringByAppendingString:@"00"];
	}
	else
	{
		SRatio = [SRatio stringByAppendingString:@".000"];
	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :SRatio] ;
	
}

+(void)ALSDataLuxParser:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mLED=nil;
	NSString *mReferenceBufferName=nil;
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	NSString *mTimeOut=@"";
	//end
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LED"])
		{
			mLED = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
	}
	NSString *readFData = [TestItemManage getBufferValue:dictKeyDefined :@"ALSFILEDATAKEY"];
	
	//NSString *fileName = @"/vault/log/als/DLXDH00QDJ2D_20101006221048/als_test_data.csv";
	//NSString *readFData = [NSString stringWithContentsOfFile:fileName encoding:NSASCIIStringEncoding error:nil] ;
	
	if(readFData == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No get ALS CSV Log File Data"] ;
		return;
	}
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
	NSArray *LowValue = nil;
	NSArray *ColumeValue = nil;
	LowValue = [readFData componentsSeparatedByString:@"\r"];
//	NSString *AlsTestValue = @"No Data!";
	//end
	double channel0 = 0;
	double channel1 = 0;
	//if([LowValue count] > 16)
	if([LowValue count] > [mLED intValue])
	{
		NSString *tmp = [LowValue objectAtIndex:[mLED intValue] - 1];
		
		ColumeValue = [tmp componentsSeparatedByString:@","];
		if([ColumeValue count] > 3)
		{
			channel0 = [[ColumeValue objectAtIndex:2] doubleValue];
			channel1 = [[ColumeValue objectAtIndex:3] doubleValue];
		}
		else
		{
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this LED Data in ALS CSV Log File"] ;
			return;
		}
	}
	else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No this LED Data in ALS CSV Log File"] ;
		return;
	}
	
	double lux = 0;
	NSString *SLux = @"0.000000";
	
	lux = 0.13*channel0 - 0.24*channel1;
	SLux = [NSString stringWithFormat:@"%f",lux];
	
	if((mLowerValue==nil || [mLowerValue length] <= 0) && (mUpperValue==nil || [mUpperValue length] <= 0))
		enumResult =RESULT_FOR_PASS ;
	else if(lux>=[mLowerValue doubleValue] && lux<=[mUpperValue doubleValue])
		enumResult =RESULT_FOR_PASS ;
	else 
		enumResult =RESULT_FOR_FAIL ;
	
	/*
	if([SLux rangeOfString:@"."].length > 0)
	{
		if([SLux length] >= ([SLux rangeOfString:@"."].location + 4))
			SLux = [SLux substringToIndex:[SRatio rangeOfString:@"."].location + 4];
		else if([SRatio length] == ([SRatio rangeOfString:@"."].location + 3))
			SLux = [SLux stringByAppendingString:@"0"];
		else if([SLux length] == ([SLux rangeOfString:@"."].location + 2))
			SLux = [SLux stringByAppendingString:@"00"];
	}
	else
	{
		SLux = [SLux stringByAppendingString:@".000"];
	}
	*/
	if (mBufferName!=nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :SLux] ;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :SLux] ;
	
}

+(void)ALSDataBuf1Buf2Parser:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mBufferName=nil;
	NSString *mLED=nil;
	NSString *mReferenceBufferName1=@"";
	NSString *mReferenceBufferName2=@"";
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	NSString *mTimeOut=@"";
	//end
	NSString *mUpperValue=@"";
	NSString *mLowerValue=@"";
	NSString *mType=@"";
	enum TestResutStatus enumResult;
	enumResult = RESULT_FOR_FAIL;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName1"])
		{
			mReferenceBufferName1 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName2"])
		{
			mReferenceBufferName2 = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"LED"])
		{
			mLED = [dictKeyDefined objectForKey:strKey] ;
		}else if([strKey isEqualToString:@"UpperValue"])
		{
			mUpperValue=[dictKeyDefined objectForKey:strKey];
		}else if([strKey isEqualToString:@"LowerValue"])
		{
			mLowerValue=[dictKeyDefined objectForKey:strKey];
		}
		else if([strKey isEqualToString:@"Type"])
		{
			mType=[dictKeyDefined objectForKey:strKey];
		}
	}
	
	NSString *mReferenceBufferValue1 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName1] ;
	NSString *mReferenceBufferValue2 = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName2] ;
	
	if(mReferenceBufferValue1 == nil || mReferenceBufferValue2 == nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"BufferValue is nil"] ;
		return;
	}
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning unused variable
//	NSMutableArray *LowValue = nil;
//	NSMutableArray *ColumeValue = nil;	
//	NSString *AlsTestValue = @"No Data!";
	//end
	double bufferValue1D = [mReferenceBufferValue1 doubleValue];
	double bufferValue2D = [mReferenceBufferValue2 doubleValue];
	double rValue = 0;
	
	if(bufferValue2D != 0)
		rValue = bufferValue1D/bufferValue2D;
	
	NSString *SrValue = @"0.000000";
	
	SrValue = [NSString stringWithFormat:@"%f",rValue];
	
	if((mLowerValue==nil || [mLowerValue length] <= 0) && (mUpperValue==nil || [mUpperValue length] <= 0))
		enumResult =RESULT_FOR_PASS ;
	else if(rValue>=[mLowerValue doubleValue] && rValue<=[mUpperValue doubleValue])
		enumResult =RESULT_FOR_PASS ;
	else 
		enumResult =RESULT_FOR_FAIL ;
	/*
	if((mLowerValue==nil?1:rValue>=[mLowerValue doubleValue]) && (mUpperValue==nil?1:rValue<=[mUpperValue doubleValue]))
		enumResult =RESULT_FOR_PASS ;
	else 
		enumResult =RESULT_FOR_FAIL ;
	*/
	/*
	 if([SLux rangeOfString:@"."].length > 0)
	 {
	 if([SLux length] >= ([SLux rangeOfString:@"."].location + 4))
	 SLux = [SLux substringToIndex:[SRatio rangeOfString:@"."].location + 4];
	 else if([SRatio length] == ([SRatio rangeOfString:@"."].location + 3))
	 SLux = [SLux stringByAppendingString:@"0"];
	 else if([SLux length] == ([SLux rangeOfString:@"."].location + 2))
	 SLux = [SLux stringByAppendingString:@"00"];
	 }
	 else
	 {
	 SLux = [SLux stringByAppendingString:@".000"];
	 }
	 */
	if (mBufferName!=nil)
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :SrValue] ;
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :SrValue] ;
	
}

+(void)ALSCloseOpenAllPort:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBuffer=nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBuffer"])
		{
			mReferenceBuffer = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if([mReferenceBuffer isEqualToString:@"close"])
	{
		//close port for ALS Frameware test
		bool flag = [self closeCurrPort:dictKeyDefined];
		//bool flag = [UIWinManage CloseAllPort];
		if(flag)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
		
	}else if([mReferenceBuffer isEqualToString:@"open"])
	{
		//revert to open port for QT test
		bool flag = [self openCurrPort:dictKeyDefined];
		//bool flag = [UIWinManage OpenAllPort];
		if(flag)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"]	;			
	}else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"]	 ;
	}	
	return;
}

+(void) HandleALSSequencerNotification:(NSNotification *)pNotification 
{ 
	NSString *notificationId = (NSString *)[pNotification object];
	NSComparisonResult result;
	ALS_ERR last_error;
	last_error = ALS_ERR_FAIL;

	/* SCRID:58
	 * 2011-01-05 henry changed for avoiding warning in iFTS
	 */
	//result = [notificationId compare:alsNotifyObject];
	//if (result == NSOrderedSame)
	NSString *strTem = (NSString *)alsNotifyObject;
	result = [notificationId isEqualToString:strTem];
	if (result == YES)
	//end
	{
		last_error = [sequencer LastError];
		
		NSLog(@"iRunner: Sequencer job complete.  Last error = %@", alsErrStrings[last_error]);
		
		if ((last_error != ALS_ERR_SUCCESS) && (last_error !=  ALS_ERR_ABORTED))
		{
			NSString *tmpMsg = [NSString stringWithFormat:@"Sequence aborted due to: --%@--", alsErrStrings[last_error]];
			//SCRID:58
			//modified by Henry on 2011-01-05 for avoiding warning initia variable
			NSLog(tmpMsg);
			//end

			//[self ShowAlert:@"FATAL ERROR" message:tmpMsg];
			
		}
		
		/*
		 if last error is _SUCCESS
			that test item is passsed, and the test item should say "Passed"
		 
		 if last error is NOT _SUCCESS
			that test item fails and the test item sould say alsErrString[last_error]
		 */
		
		if (last_error == ALS_ERR_SUCCESS)
		{
			//[self ShowAlert:@"Information" message:@"Sequence completed normally"];
		}
		
		waiting_for_sequencer = false;
	}
	local_last_error = last_error;
}

+(void) RunSOP
{
	NSLog(@"iRunner: Running SOP");
	
	//SCRID:58
	//modified by Henry on 2011-01-05 for avoiding warning initia variable
//	NSString *path =ALSLogFolderPath;
	//end
	
	[sequencer ALS_RunSOP:ALSLogFolderPath];
	
	waiting_for_sequencer = true;
}
/*
-(void) RunCal
{
	NSLog(@"iRunner: Running cal");
	
	[sequencer ALS_RunCal:ALSLogFolderPath];
	
	waiting_for_sequencer = true;
}
*/
+(void) Abort
{
	NSLog(@"iRunner: Aborting.");
	[sequencer ALS_Abort];
}

		
+(NSString *)getNowTime
{
	NSCalendarDate *now;
	now = [NSCalendarDate calendarDate];
	NSString *dateTime = [now description];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@"-" withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@":" withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@" " withString:@""];
	dateTime = [dateTime stringByReplacingOccurrencesOfString:@"	" withString:@""];
	if([dateTime length] < 14)
	{
		dateTime = @"";
		return dateTime;
	}
	else
	{
		dateTime = [dateTime substringToIndex:14];
	}
	
	return dateTime;
}
		
@end

