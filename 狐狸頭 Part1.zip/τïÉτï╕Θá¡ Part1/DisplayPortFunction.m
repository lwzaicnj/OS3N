//
//  ProxIQCParse.m
//  qt_simulator
//
//  Created by QTeam on 3/23/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: DisplayPortFunction.m
 | $Author::Joko Li                           $Revision:: 1
 | CREATED: 2010.03.26                  $Modtime::  14:20
 | STATE  : Beta
 +--------------------------------------------------------------------+
 
 MODULE  :DisplayPort Parser Method
 
 PURPOSE :Parse DisplayPort function.
 
 $History:: DisplayPortFunction.m
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.26   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */



#import "testExecution.h"
#include <stdio.h>
#import "DisplayPortFunction.h"
NSMutableDictionary* mutArrayDPResultForSiet1;
NSMutableDictionary* mutArrayDPResultForSiet2;


@implementation TestItemParse(DisplayPortFunction)

//+(void)ExecBundle:(NSDictionary*)dictKeyDefined
//{
//	//SCRID:45
//	//added by caijunbo on 2010-12-18
//	
//	//SCRID:47
//	// change CheckUnitType to ICConfig by Helen on 2010-12-18
//	//NSString* mCheckUnitType=nil;
//    NSString* mICConfig=nil;
//	//end
//	
//	//end
//	//SCRID:42
//	//added by caijunbo on 2010-12-16
//	NSString* mEnableHDCP=@"yes";
//	//added end
//	//SCRID:30
//	//added by caijunbo on 2010-12-10
//	NSString* mReferenceBuffer=nil;
//	NSString* mReferenceBufferValue=nil;
//	//end
//	NSString* tempFirstItemName=nil;
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			
//			//mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//			
//			//SCRID:28
//			//added by caijunbo on 2010-11-29
//			//DP Will use the uniform header item name;
//			mTestItemName =@"DP";
//			//end
//			
//		}
//		//SCRID:30
//		//added by caijunbo on 2010-12-10
//		else if ([strKey isEqualToString:@"ReferenceBufferName"])
//		{
//			mReferenceBuffer =[dictKeyDefined objectForKey:strKey] ;
//		}
//		//added end
//		
//		//SCRID:42
//		//added by caijunbo on 2010-12-16
//		else if ([strKey isEqualToString:@"EnableHDCP"])
//		{
//			mEnableHDCP=[dictKeyDefined objectForKey:strKey] ;
//		}
//		//added end
//		
//		//SCRID:45
//		//added by caijunbo on 2010-12-18
//		
//		//SCRID:47
//		// change CheckUnitType to ICConfig by Helen on 2010-12-18
//		else if ([strKey isEqualToString:@"ICConfig"])
//		{
//			mICConfig=[dictKeyDefined objectForKey:strKey] ;
//		}
//		//end
//		
//		//end
//	}
//	
//	//SCRID:42
//	//added by caijunbo on 2010-12-16
//	if ([mEnableHDCP isEqualToString:@"yes"])
//	{
//		//SCRID:30
//		//added by caijunbo on 2010-12-10
//		if (mReferenceBuffer==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"script error!"] ;
//			return ;
//		}
//		
//		mReferenceBufferValue = [TestItemManage getBufferValue:dictKeyDefined :mReferenceBuffer] ;
//		if (mReferenceBufferValue==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"HDCP Flag Data is null"] ;
//			return ;
//		}
//		//end
//		
//		//SCRID:45
//		//added by caijunbo on 2010-12-18
//		
//		
//		//SCRID:47
//		// change CheckUnitType to ICConfig by Helen on 2010-12-18
//		if (mICConfig==nil)
//		{
//			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"script error,No unit type"] ;
//			return ;
//		}
//		//end
//		
//	}
//	
//	//added end
//	
//	
//	NSString* siteName=nil;
//	NSString* strDUTID=[dictKeyDefined objectForKey:@"DUTID"];
//	
//	if ([strDUTID isEqualToString:@"1"])
//		siteName=@"site1" ;
//	else if ([strDUTID isEqualToString:@"2"])
//		siteName=@"site2" ;
//	else if ([strDUTID isEqualToString:@"3"])
//		siteName=@"site3" ;
//	else if ([strDUTID isEqualToString:@"4"])
//		siteName=@"site4" ;
//	else
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"No exist DisplayPort thread occur!"] ; ///write test result and uiinfo.
//		return ;
//	}
//	
//	
//    
//	IFTestSiteManager* siteManager = [IFTestSiteManager sharedInstance];
//	IFTestSuite* suite = [siteManager suiteForSite:siteName];
//	IFTTestExecution* te = [[IFTTestExecution alloc] initWithSuite:suite];
//	
//	//SCRID:42
//	//added by caijunbo on 2010-12-16
//	if ([mEnableHDCP isEqualToString:@"yes"])
//	{
//		//SCRID:45
//		//modified by caijunbo on 2010-12-18
//		/*
//         //SCRID:30
//         //added by caijunbo on 2010-12-10
//         [te setHDCPFlag:mReferenceBufferValue];
//         //end
//		 */
//		
//		/** SCRID-56: HDCP item should be test except "A0" and "B0" unit type. Tony 2010-12-31 **/
//		//SCRID:47
//		// change CheckUnitType to ICConfig by Helen on 2010-12-18
//		if ([mICConfig rangeOfString:mReferenceBufferValue].length>0)
//			[te setHDCPFlag:@"disable"];
//		//end
//		
//		else
//			[te setHDCPFlag:@"enable"];
//		//end modifing
//		/** SCRID-56: end **/
//	}
//	
//	//added end
//	
//	[te start];
//	while( ![te isFinished] )
//	{
//		sleep(1);
//	}
//	
//	//SCRID:28
//	//added by caijunbo on 2010-11-29
//	tempFirstItemName=[te getFirstItemName];
//	[tempFirstItemName retain];
//	//end added by caijunbo on 2010-11-29
//	
//	NSMutableDictionary* mutSubItemResult=nil;
//	mutSubItemResult=[te getSubItemResult];
//	[mutSubItemResult retain];
//	NSArray* results=nil;
//	IFTestResult* r=nil;
//	//Upload subitem result to PDCA
//	//SCRID:28
//	//Modified by caijunbo on 2010-11-29
//	
//	//SCRID-151:to resove upload DP items twice to PDCA.joko.2011-12-14.
//	if(mutSubItemResult == nil)
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"DP Result is nil"] ;
//		return ;
//	}
//	//SCTID-151:end
//	if ([mutSubItemResult count]>=1)
//	{
//		if ([strDUTID isEqualToString:@"1"])
//		{
//			mutArrayDPResultForSiet1=mutSubItemResult;
//			//NSLog(@"@@@@@@@@@@@@ DP SubItemResult=%@",mutSubItemResult);
//			[mutArrayDPResultForSiet1 retain];
//		}
//		
//		if ([strDUTID isEqualToString:@"2"])
//		{
//			mutArrayDPResultForSiet2=mutSubItemResult;
//			//NSLog(@"@@@@@@@@@@@@ DP SubItemResult=%@",mutSubItemResult);
//			[mutArrayDPResultForSiet2 retain];
//			
//		}
//		
//		NSArray* itemNameList=[mutSubItemResult allKeys];
//		
//		for (int iLoop=0;iLoop<[itemNameList count];iLoop++)
//		{
//			results=[mutSubItemResult objectForKey:[itemNameList objectAtIndex:iLoop]];
//			if (results)
//			{
//				for(r in results)
//				{
//					NSString* lowLimit=nil;
//					NSString* highLimit=nil;
//					if (!(lowLimit=r.lowLimit))
//						lowLimit=nil;
//					if (!(highLimit=r.highLimit))
//						highLimit=nil;
//					/* SCRID-147: Give a failMSG parameter to setSubItemPDCAInfo parser for display DP fail messege in PDCA.Judith,2011-12-05 */
//					NSString *failMSG = r.actual;
//					failMSG = [failMSG stringByAppendingString:@" "];
//					failMSG = [failMSG stringByAppendingString:r.failMessage];
//					[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[itemNameList objectAtIndex:iLoop]:r.subTestName:lowLimit:highLimit:r.actual:nil:r.result:failMSG];
//					//[TestItemManage setSubItemPDCAInfo:dictKeyDefined:[itemNameList objectAtIndex:iLoop]:r.subTestName:lowLimit:highLimit:r.actual:nil:r.result:nil];
//					/* SCRID-147:end */
//				}
//			}
//			
//		}//end for loop
//		
//		
//	}
//	//end Modified by caijunbo on 2010-11-29
//	//SCRID-151:to resove upload DP items twice to PDCA.joko.2011-12-14.
//	else
//	{
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"DP havn't start test"] ;
//		return ;
//	}
//	//SCTID-151:end
//	[mutSubItemResult release];
//	[te release];
//	
//	
//	/*Owner:Henry DATE :11.12.2010
//	 SCRID :015
//	 Desc  :Move DP total item .
//	 */
//	
//	
//	//SCRID:28
//	//Modified by caijunbo on 2010-11-29
//	IFTestResult* resulTem=nil;
//	NSArray* arrayResultTem=nil;
//	if (tempFirstItemName==nil)
//	{
//		[tempFirstItemName release];
//		tempFirstItemName=nil;
//		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"error firstItemName null"]	 ;
//		return;
//		
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResultTem=[mutArrayDPResultForSiet1 objectForKey:tempFirstItemName];
//			resulTem=[arrayResultTem objectAtIndex:0];
//			[tempFirstItemName release];
//			tempFirstItemName=nil;
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResultTem=[mutArrayDPResultForSiet2 objectForKey:tempFirstItemName];
//			resulTem=[arrayResultTem objectAtIndex:0];
//			[tempFirstItemName release];
//			tempFirstItemName=nil;
//		}
//	}
//	
//	//end Modified by caijunbo on 2010-11-29
//	
//	if ([resulTem result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//	//henry add end
//	
//	return ;
//    
//}


+(void)DPtest:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBuffer=nil;
	
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBuffer"])
		{
			mReferenceBuffer = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	if([mReferenceBuffer isEqualToString:@"close"])
	{
		//close port for DP test
		bool flag = [self closeCurrPort:dictKeyDefined];
		if(flag)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"] ;
        
	}else if([mReferenceBuffer isEqualToString:@"open"])
	{
		//revert to open port for QT test
		bool flag = [self openCurrPort:dictKeyDefined];
		if(flag)
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"] ;
		else
			[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail"]	;
	}else
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Error"]	 ;
	}
	return;
}
//
//+(void)DPHotPlugDetectSleepTest:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"Hot Plug Detect"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"Hot Plug Detect"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//}
//+(void)DPHotPlugDetectWakeTest:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"Hot Plug Detect"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"Hot Plug Detect"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//    
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//        
//	}
//    
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//	
//}
//+(void)DPEDIDReadBack:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"EDID read back"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"EDID read back"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//	
//}
//
////joko add 2010-10-11 add
//+(void)DPHDCPValidKey:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"HDCP Compliant test"];
//			//SCRID:30
//			//added by caijunbo on 2010-12-10
//			if (arrayResult==nil)
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_BYPASS :@"ByPass"];
//				return;
//			}
//			//end
//			
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"HDCP Compliant test"];
//			//SCRID:30
//			//added by caijunbo on 2010-12-10
//			if (arrayResult==nil)
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_BYPASS :@"ByPass"];
//				return;
//			}
//			//end
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//}
////joko add 2010-10-11 end
//
//
//+(void)DPHDCPCompliant:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	//SCRID:58
//	//modified by Henry on 2011-01-05 for avoiding warning unused variable
//    //	bool byPass = FALSE;
//	//end
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"HDCP Compliant test"];
//			//SCRID:30
//			//added by caijunbo on 2010-12-10
//			if (arrayResult==nil)
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_BYPASS :@"ByPass"];
//				return;
//			}
//			//end
//			
//			/** SCRID-57: Remove code of joko added at 2010-11-10. Tony 2010-12-31 **/
//			/** SCRID-53: Remove QT0b DPHDCPValidKey test item,DPHDCPCompliant only C0 unit need to test,A0,B0 bypass. Tony 2010-12-25 **/
//			r=[arrayResult objectAtIndex:0];
//			/** SCRID-53: end **/
//			/** SCRID-57: end **/
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"HDCP Compliant test"];
//			
//			//SCRID:30
//			//added by caijunbo on 2010-12-10
//			if (arrayResult==nil)
//			{
//				[TestItemParse SetResultAndUIInfo:dictKeyDefined:RESULT_FOR_BYPASS :@"ByPass"];
//				return;
//			}
//			//end
//			/** SCRID-57: Remove code of joko added at 2010-11-10. Tony 2010-12-31 **/
//			/** SCRID-53: Remove QT0b DPHDCPValidKey test item,DPHDCPCompliant only C0 unit need to test,A0,B0 bypass. Tony 2010-12-25 **/
//			r=[arrayResult objectAtIndex:0];
//			/** SCRID-53: end **/
//			/** SCRID-57: end **/
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//	}
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//
//+(void)DP640x480PatternRedCRC:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP640x480PatternGreenCRC:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP640x480PatternBlueCRC:(NSDictionary*)dictKeyDefined
//{
//	
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP640x480PatternLinkStatus:(NSDictionary*)dictKeyDefined
//{
//	
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP640x480Patternvideostatus:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:4];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"640x480 Pattern Test"];
//			r=[arrayResult objectAtIndex:4];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//
//+(void)DP162traininglane1swing:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP162traininglane1preemphasis:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP162traininglane2swing:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP162traininglane2preemphasis:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1.62 training result"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//}
//
//+(void)DP1280x720PatternRedCRC:(NSDictionary*)dictKeyDefined
//{
//	
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP1280x720PatternGreenCRC:(NSDictionary*)dictKeyDefined
//{
//	
//	
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	
//	if([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSString* testname=[r testName];
//	NSLog(testname);
//	NSString* subtestname=[r subTestName];
//	NSLog(subtestname);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//}
//+(void)DP1280x720PatternBlueCRC:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP1280x720PatternLinkStatus:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP1280x720Patternvideostatus:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:4];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{	/*SCRID-104: Merge the code which change in dry-run. Jun-Bo, 2011-05-25*/
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"1920x1200 pattern test"];
//			r=[arrayResult objectAtIndex:4];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//
//
//+(void)DP27traininglane1swing:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP27traininglane1preemphasis:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP27traininglane2swing:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:2];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DP27traininglane2preemphasis:(NSDictionary*)dictKeyDefined
//{
//    
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"2.7 training result"];
//			r=[arrayResult objectAtIndex:3];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//}
//
//+(void)DPPRBSlane1:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"PRBS test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"PRBS test"];
//			r=[arrayResult objectAtIndex:0];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//+(void)DPPRBSlane2:(NSDictionary*)dictKeyDefined
//{
//	NSString *strTestResultForUIinfo=@"Fail";
//	enum TestResutStatus enumResult=RESULT_FOR_FAIL;
//	
//	//key parse
//	NSString *mTestItemName=nil;
//	
//	for(int i=0 ;i<[dictKeyDefined count] ;i++)
//	{
//		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
//		if ([strKey isEqualToString:@"TestItemName"])
//		{
//			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
//		}
//	}
//	
//	IFTestResult* r=nil;
//	NSArray* arrayResult=nil;
//	
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet1 objectForKey:@"PRBS test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			arrayResult=[mutArrayDPResultForSiet2 objectForKey:@"PRBS test"];
//			r=[arrayResult objectAtIndex:1];
//		}
//	}
//	
//	if ([r result]==IFTResultFail)
//	{
//		enumResult=RESULT_FOR_FAIL;
//		strTestResultForUIinfo=@"FAIL";
//		
//	}
//	
//	else
//	{
//		enumResult=RESULT_FOR_PASS;
//		strTestResultForUIinfo=@"PASS";
//	}
//	
//	NSLog(r.testName);
//	
//	NSLog(r.subTestName);
//	
//	///after finished testing release the globle val.
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"1"])
//	{
//		if (mutArrayDPResultForSiet1!=nil)
//		{
//			[mutArrayDPResultForSiet1 release];
//			mutArrayDPResultForSiet1=nil;
//		}
//	}
//	if ([[dictKeyDefined objectForKey:@"DUTID"] isEqualToString:@"2"])
//	{
//		if (mutArrayDPResultForSiet2!=nil)
//		{
//			[mutArrayDPResultForSiet2 release];
//			mutArrayDPResultForSiet2=nil;
//            
//		}
//	}
//	
//	
//	[TestItemParse SetResultAndUIInfo:dictKeyDefined :enumResult :strTestResultForUIinfo]	 ;
//    
//}
//
@end

