
/*
 *  keysDefine.h
 *  qt_simulator
 *
 *  Created by diags on 3/27/10.
 *  Copyright 2010 Foxconn. All rights reserved.
 *
 */
//-------------------SCript key define--------
#define FIXTURETYPE @"FixtureType"   //add by kevin for RL qt0a at 20140811
#define STRKEYPROJECTTYPE    @"ProjectType"
#define STRKEYSTOPFAIL			@"StopFail"
#define STRKEYWHETHERLOCK		@"WhetherLock"
#define STRKEYWHETHERSCANSN		@"NeedSN"
#define STRKEYWHETHERAUTOTEST   @"WhetherAutoTest"
#define STRKEYCHECKDIAGMODE     @"CheckDiagMode"
#define STRKEYWHETHER4SN		@"Whether4Sn"
#define STRKEYWHETHERNEEDBARCODE		@"NeedBarcode"
#define STRKEYNEEDFIXTUREID		@"NeedFixtureID"
#define STRKEYSWITCHUI			@"SwitchUI"
#define STRKEYLOOPTIMES			@"LoopTimes" //20101009 Henry add 
#define STRKEYQT3UIITEMS		@"ProxItemCount"  //20101009 Henry add 
#define STRKEYNEEDCONFIG		@"NeedConfig"//SCRID-71:add by Helen for Add scan WOSN and update it as attribute to PDCA 2011-01-28
//SCRID:155 Modify for retesting more than one fail testitem by Ray 20120104.
#define STRKEYRETESTITEMS		@"RetestItems"
//SCRID:155 end

//---------------------------------------------
#define STRKEYSYSSN   @"strSysSn"
#define STRKEYHWSN    @"strHwySn"
#define STRKEYBCSN    @"strBarcodeSn"
#define STRKEYX15SN   @"strX15Sn"
#define STRKEYX17SN   @"strX17Sn"
#define STRKEYSTAGESIZEHIGH   @"StageSizeHigh"
#define STRKEYCUSTPARTNO      @"CustPartNo"
#define STRKEYMODULESN        @"strMouleSn"
#define STRKEYSSENSORSN        @"strSensorSn"

#define STRKEYBATTERYSN @"strBatterySn"
#define STRKEYHWCOIG    @"strHWCofig"
#define STRKEYGRAPESN   @"strGrapeSn"
#define STRKEYDSPLSN   @"strDSPLSn"
#define STRKEYMPN       @"strMpn"
#define STRKEYREGN      @"strRegn"
#define STRKEYMLBSN     @"strMlbSn"

//SCRID:129 Add burn camera barcode by Helen 20110810
#define STRFCMS			@"strFCMS"
#define STRBCMS			@"strBCMS"
//SCRID:129 end

#define STRKEYX23		@"strX23Sn"
#define STRKEYX24		@"strX24Sn"
#define STRKEYX25		@"strX25Sn"

// J1J2-SCRID:1 add by Evan on 2011-03-17
#define STRKEYX26		@"strX26Sn"
// J1J2-SCRID:1 add end;

#define STRKEYSENSORSN  @"strXSensorSn"

#define STRKEYX23RECORD   @"strX23record"
#define STRKEYX24RECORD   @"strX24record"
#define STRKEYX25RECORD   @"strX25record"
// J1J2-SCRID:1 add by Evan on 2011-03-17
#define STRKEYX26RECORD   @"strX26record"
// J1J2-SCRID:1 add end;
#define STRKEYMLBRECORD   @"strMlbrecord"

#define STRKEYBOARDID		@"strBoardID" //jun-bo 2011-05-25

//add by justin on 2014-05-13 start
#define STRBATTERYH       @"strBatteryH"
#define STRBATTERYZH       @"strBatteryZH"
#define STRBATTERYL       @"strBatteryL"
//end
