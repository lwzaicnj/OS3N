
#ifndef __CAS4_included__
#define __CAS4_included__


#ifdef __MACH__
#define __callconv __cdecl
#else
#define __callconv __stdcall
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* $Revision$ */

// error codes

#define ErrorNoError              0
#define ErrorUnknown              -1
#define ErrorTimeoutRWSNoData     -2
#define ErrorInvalidDeviceType    -3
#define ErrorAcquisition          -4
#define ErrorAccuDataStream       -5
#define ErrorPrivilege            -6
#define ErrorFIFOOverflow         -7
#define ErrorTimeoutEOSScan       -8
#define ErrorCCDTemperatureFail   -13
#define ErrorAdrControl           -14
#define ErrorFloat                -15
#define ErrorTriggerTimeout       -16
#define ErrorAbortWaitTrigger     -17
#define ErrorDarkArray            -18
#define ErrorNoCalibration        -19
#define ErrorCRI                  -21
#define ErrorNoMultiTrack         -25
#define ErrorInvalidTrack         -26
#define ErrorDetectPixel          -31
#define ErrorSelectParamSet       -32
#define ErrorI2CInit              -35
#define ErrorI2CBusy              -36
#define ErrorI2CNotAck            -37
#define ErrorI2CRelease           -38
#define ErrorI2CTimeOut           -39
#define ErrorI2CTransmission      -40
#define ErrorI2CController        -41
#define ErrorDataNotAck           -42
#define ErrorNoExternalADC        -52
#define ErrorShutterPos           -53
#define ErrorFilterPos            -54
#define ErrorConfigSerialMismatch -55
#define ErrorCalibSerialMismatch  -56
#define ErrorInvalidParameter     -57
#define ErrorGetFilterPos         -58
#define ErrorParamOutOfRange      -59

#define errCASOK                 ErrorNoError

#define errCASError              -1000
#define errCasNoConfig           errCASError-3
#define errCASDriverMissing      errCASError-6 //driver stuff missing, returned in INITDevice
#define errCasDeviceNotFound     errCASError-10 //invalid ADevice param

/////////////////////
// Error handling  //
/////////////////////
extern int  casGetError( int ADevice );
extern char*  casGetErrorMessage( int AError, char* Dest, int AMaxLen );
extern unichar*  casGetErrorMessageW( int AError, unichar* Dest, int AMaxLen );

///////////////////////////////////
// Device Handles and Interfaces //
///////////////////////////////////
#define InterfaceISA			0
#define InterfacePCI			1
#define InterfaceTest			3
#define InterfaceCASUSB			5
#define InterfaceNVISCluster	7

extern int  casCreateDevice( void );
extern int  casCreateDeviceEx( int AInterfaceType, int AInterfaceOption );
extern int  casChangeDevice( int ADevice, int AInterfaceType, int AInterfaceOption );
extern int  casDoneDevice( int ADevice );

#define aoAssignDevice     0
#define aoAssignParameters 1
#define aoAssignComplete   2

extern int  casAssignDeviceEx( int ASourceDevice, int ADestDevice, int AOption );

extern int  casGetDeviceTypes( void );
extern char*  casGetDeviceTypeName( int AInterfaceType, char* Dest, int AMaxLen );
extern unichar*  casGetDeviceTypeNameW( int AInterfaceType, unichar* Dest, int AMaxLen );
extern int  casGetDeviceTypeOptions( int AInterfaceType );
extern int  casGetDeviceTypeOption( int AInterfaceType, int AIndex );
extern char*  casGetDeviceTypeOptionName( int AInterfaceType, int AOption, char* Dest, int AMaxLen );
extern unichar*  casGetDeviceTypeOptionNameW( int AInterfaceType, int AOption, unichar* Dest, int AMaxLen );

////////////////////
// Initialization //
////////////////////

#define InitOnce		0
#define InitForced		1
#define InitNoHardware	2

extern int  casInitialize( int ADevice, int Perform );

///////////////////////////
// Instrument properties //
///////////////////////////

//AWhat parameter constants for DeviceParameter methods below
#define dpidIntTimeMin			101
#define dpidIntTimeMax			102
#define dpidDeadPixels			103
#define dpidVisiblePixels		104
#define dpidPixels			105
#define dpidSets			106
#define dpidCurrentSet			107
#define dpidADCRange			108
#define dpidADCBits			109
#define dpidSerialNo			110
#define dpidTOPSerial			111 //TOP200 only, use dpidTOPSerialEx and dpidTOPType for others
#define dpidTransmissionFileName	112
#define dpidConfigFileName		113
#define dpidCalibFileName		114
#define dpidCalibrationUnit		115
#define dpidAccessorySerial		116
#define dpidTriggerCapabilities		118
#define dpidAveragesMax			119
#define dpidFilterType			120
#define dpidRelSaturationMin		123
#define dpidRelSaturationMax		124
#define dpidInterfaceVersion		125
#define dpidTriggerDelayTimeMax		126
#define dpidSpectrometerName		127
#define dpidDigitalIn1			128
#define dpidDigitalIn2			129
#define dpidNeedDarkCurrent		130
#define dpidNeedDensityFilterChange	131
#define dpidSpectrometerModel		132
#define dpidLine1FlipFlop           	133
#define dpidTimer                   	134
#define dpidInterfaceType           	135
#define dpidInterfaceOption         	136
#define dpidInitialized             	137
#define dpidDCRemeasureReasons		138
#define dpidIntTimeAlign        139
#define dpidAbortWaitForTrigger     140
#define dpidGetFilesFromDevice      142
#define dpidTOPType             143
#define dpidTOPSerialEx			144

//TriggerCapabilities constants; see dpidTriggerCapabilities
#define tcoCanTrigger           0x0001
#define tcoTriggerDelay         0x0002
#define tcoTriggerOnlyWhenReady 0x0004
#define tcoAutoRangeTriggering  0x0008
#define tcoShowBusyState        0x0010
#define tcoShowACQState         0x0020
#define tcoFlashOutput          0x0040
#define tcoFlashHardware        0x0080
#define tcoFlashForEachAverage  0x0100
#define tcoFlashDelay           0x0200
#define tcoFlashDelayNegative   0x0400
#define tcoFlashSoftware        0x0800
#define tcoGetFlipFlopState     0x1000

//DCRemeasureReasons constants; see dpidDCRemeasureReasons 
#define todcrrNeedDarkCurrent   0x0001
#define todcrrCCDTemperature    0x0002
    
//TOPType constants; see dpidTOPType
#define ttNone          0
#define ttTOP100        1
#define ttTOP200        2
#define ttTOP150        3

extern double  casGetDeviceParameter( int ADevice, int AWhat );
extern int  casSetDeviceParameter( int ADevice, int AWhat, double AValue );
extern int  casGetDeviceParameterString( int ADevice, int AWhat, char* ADest, int AMaxLen );
extern int  casGetDeviceParameterStringW( int ADevice, int AWhat, unichar* ADest, int AMaxLen );
extern int  casSetDeviceParameterString( int ADevice, int AWhat, char* AValue );
extern int  casSetDeviceParameterStringW( int ADevice, int AWhat, unichar* AValue );

#define casSerialComplete	0
#define casSerialAccessory	1
#define casSerialExtInfo	2
#define casSerialDevice		3
#define casSerialTOP		4

extern int  casGetSerialNumberEx( int ADevice, int AWhat, char* Dest, int AMaxLen );
extern int  casGetSerialNumberExW( int ADevice, int AWhat, unichar* Dest, int AMaxLen );

#define coShutter	               0x00000001
#define coFilter                   0x00000002
#define coGetShutter               0x00000004
#define coGetFilter                0x00000008
#define coGetAccessories           0x00000010
#define coGetTemperature           0x00000020
#define coUseDarkcurrentArray      0x00000040
#define coUseTransmission          0x00000080
#define coAutorangeMeasurement     0x00000100
#define coAutorangeFilter          0x00000200
#define coCheckCalibConfigSerials  0x00000400
#define coTOPHasFieldOfViewConfig  0x00000800
#define coAutoRemeasureDC          0x00001000
#define coCanMultiTrack            0x00008000
#define coCanSwitchLEDOff          0x00010000
#define coLEDOffWhileMeasuring     0x00020000

extern int  casGetOptions( int ADevice );
extern void  casSetOptionsOnOff( int ADevice, int AOptions, int AOnOff );
extern void  casSetOptions( int ADevice, int AOptions );

//////////////////////////
// Measurement Commands //
//////////////////////////
extern int  casMeasure( int ADevice );

extern int  casStart( int ADevice );
extern int  casFIFOHasData( int ADevice );
extern int  casGetFIFOData( int ADevice );

extern int  casMeasureDarkCurrent( int ADevice );

#define paPrepareMeasurement	1
#define paLoadCalibration		3
#define paCheckAccessories		4

extern int  casPerformAction( int ADevice, int AId );

///////////////////////////
// Measurement Parameter //
///////////////////////////

//AWhat parameter constants for MeasurementParameter methods below
#define mpidIntegrationTime        01
#define mpidAverages               02
#define mpidDelayTime              03
#define mpidTriggerTimeout         04
#define mpidCheckStart             05
#define mpidCheckStop              06
#define mpidColormetricStart       07
#define mpidColormetricStop        08
#define mpidEosTime                09
#define mpidACQTime                10
#define mpidMaxADCValue            11
#define mpidMaxADCPixel            12
#define mpidScanMode               13
#define mpidTriggerSource          14
#define mpidAmpOffset              15
#define mpidSkipLevel              16
#define mpidSkipLevelEnabled       17
#define mpidScanStartTime          18
#define mpidAutoRangeMaxIntTime    19
#define mpidAutoRangeLevel         20 //deprecated
#define mpidAutoRangeMinLevel      20
#define mpidDensityFilter          21
#define mpidCurrentDensityFilter   22
#define mpidNewDensityFilter       23
#define mpidLastDCAge              24
#define mpidRelSaturation          25
#define mpidPulseWidth             27
#define mpidRemeasureDCInterval    28
#define mpidFlashDelayTime         29
#define mpidTOPAperture            30
#define mpidTOPDistance            31
#define mpidTOPSpotSize            32
#define mpidTriggerOptions         33
#define mpidForceFilter            34
#define mpidFlashType              35
#define mpidFlashOptions           36
#define mpidACQStateLine           37
#define mpidACQStateLinePolarity   38
#define mpidBusyStateLine          39
#define mpidBusyStateLinePolarity  40
#define mpidAutoFlowTime           41
#define mpidCRIMode                42
#define mpidObserver               43
#define mpidTOPFieldOfView         44
#define mpidCurrentCCDTemperature  46
#define mpidLastCCDTemperature     47
#define mpidDCCCDTemperature       48
#define mpidAutoRangeMaxLevel      49

//mpidTriggerOptions constants
#define toAcceptOnlyWhenReady	0x0001
#define toForEachAutoRangeTrial	0x0002
#define toShowBusyState		0x0004
#define toShowACQState		0x0008

//mpidFlashType constants
#define ftNone      0
#define ftHardware  1
#define ftSoftware  2

//mpidFlashOptions constants
#define foEveryAverage  1

//mpidTriggerSource constants
#define trgSoftware  0
#define trgFlipFlop  3

//mpidCRIMode constants
#define criDIN6169     0
#define criCIE13_3_95  1

//mpidObserver constants
#define cieObserver1931  0
#define cieObserver1964  1

extern double  casGetMeasurementParameter( int ADevice, int AWhat );
extern int  casSetMeasurementParameter( int ADevice, int AWhat, double AValue );
extern int  casClearDarkCurrent( int ADevice );

/////////////////////////////////              
// Filter and Shutter commands //
/////////////////////////////////
#define casShutterInvalid   -1
#define casShutterOpen	    0
#define casShutterClose	    1

extern int  casGetShutter( int ADevice );
extern void  casSetShutter( int ADevice, int OnOff );
extern char*  casGetFilterName( int ADevice, int AFilter, char* Dest, int AMaxLen );
extern unichar*  casGetFilterNameW( int ADevice, int AFilter, unichar* Dest, int AMaxLen );
extern int  casGetDigitalOut( int ADevice, int APort );
extern void  casSetDigitalOut( int ADevice, int APort, int OnOff );
extern int  casGetDigitalIn( int ADevice, int APort );

////////////////////////////
// Parameter Set Commands //
////////////////////////////
extern int  casDeleteParamSet( int ADevice, int AParamSet );

////////////////////////////////////////////
// Calibration and Configuration Commands //
////////////////////////////////////////////
extern void  casCalculateCorrectedData( int ADevice );
extern void  casConvoluteTransmission( int ADevice );

#define gcfDensityFunction        0
#define gcfSensitivityFunction    1
#define gcfTransmissionFunction   2
#define gcfDensityFactor          3
#define gcfTOPApertureFactor      4
#define gcfTOPDistanceFactor      5
	#define gcfTDCount         -1
	#define gcfTDExtraDistance  1
	#define gcfTDExtraFactor    2
#define gcfWLCalibrationChannel   6
	#define gcfWLCalibPointCount           -1
	#define gcfWLExtraCalibrationNone       0
	#define gcfWLExtraCalibrationDelete     1
	#define gcfWLExtraCalibrationDeleteAll  2
#define gcfWLCalibrationAlias     7
#define gcfWLCalibrationSave      8
#define gcfDarkArrayValues        9
	#define gcfDarkArrayDepth    -1  //Extra
	#define gcfDarkArrayIntTime  -2  //Extra
#define gcfTOPParameter          11
	#define gcfTOPApertureSize          0 //Extra
	#define gcfTOPSpotSizeDenominator   1
	#define gcfTOPSpotSizeOffset        2
#define gcfLinearityFunction     12
	#define gcfLinearityCounts  0
	#define gcfLinearityFactor  1

//obsolete (03/2010); backward compatibility after renaming
#define gcfTop100Factor           4 //-> gcfTOPApertureFactor
#define gcfTop100DistanceFactor   5 //-> gcfTOPDistanceFactor

extern double  casGetCalibrationFactors( int ADevice, int What, int Index, int Extra );
extern void  casSetCalibrationFactors( int ADevice, int What, int Index, int Extra, double Value );
extern void  casUpdateCalibrations( int ADevice );
extern void  casSaveCalibration( int ADevice, char* AFileName );
extern void  casSaveCalibrationW( int ADevice, unichar* AFileName );
extern void  casClearCalibration( int ADevice, int What );

/////////////////////////
// Measurement Results //
/////////////////////////
extern double  casGetData( int ADevice, int AIndex );
extern double  casGetXArray( int ADevice, int AIndex );
extern double  casGetDarkCurrent( int ADevice, int AIndex );
extern void  casGetPhotInt( int ADevice, double* APhotInt, char* AUnit, int AUnitMaxLen );
extern void  casGetPhotIntW( int ADevice, double* APhotInt, unichar* AUnit, int AUnitMaxLen );
extern void  casGetRadInt( int ADevice, double* ARadInt, char* AUnit, int AUnitMaxLen );
extern void  casGetRadIntW( int ADevice, double* ARadInt, unichar* AUnit, int AUnitMaxLen );
extern double  casGetCentroid( int ADevice );
extern void  casGetPeak( int ADevice, double* x, double* y );
extern double  casGetWidth( int ADevice );

#define	cLambdaWidth		0
#define	cLambdaLow		1
#define	cLambdaMiddle		2
#define	cLambdaHigh		3
#define	cLambdaOuterWidth	4
#define	cLambdaOuterLow		5
#define	cLambdaOuterMiddle	6
#define	cLambdaOuterHigh	7

extern double  casGetWidthEx( int ADevice, int What ); // call only after casGetWidth
extern void  casGetColorCoordinates( int ADevice, double* x, double* y, double* z, double* u, double* v1976, double* v1960 );
extern double  casGetCCT( int ADevice );
extern double  casGetCRI( int ADevice, int Index );
extern void  casGetTriStimulus( int ADevice, double* X, double* Y, double* Z );

#define	ecvRedPart		 1
#define	ecvVisualEffect		 2
#define	ecvUVA			 3
#define	ecvUVB			 4
#define	ecvUVC			 5
#define	ecvVIS			 6
#define	ecvCRICCT		 7
#define	ecvCDI			 8
#define	ecvDistance		 9
#define	ecvCalibMin		10
#define	ecvCalibMax		11
#define ecvScotopicInt		12

extern double  casGetExtendedColorValues( int ADevice, int What );

/////////////////////////////
// Colormetric Calculation //
/////////////////////////////
extern int  casColorMetric( int ADevice );
extern int  casCalculateCRI( int ADevice );
extern int  cmXYToDominantWavelength( double x, double y, double IllX, double IllY, double* LambdaDom, double* Purity );

///////////////
// Utilities //
///////////////
extern char*  casGetDLLFileName( char* Dest, int AMaxLen );
extern unichar*  casGetDLLFileNameW( unichar* Dest, int AMaxLen );
extern char*  casGetDLLVersionNumber( char* Dest, int AMaxLen );
extern unichar*  casGetDLLVersionNumberW( unichar* Dest, int AMaxLen );
extern int  casSaveSpectrum( int ADevice, char* AFileName );
extern int  casSaveSpectrumW( int ADevice, unichar* AFileName );
extern double  casGetExternalADCValue( int ADevice, int AIndex );

#define extNoError		0
#define extExternalError	1
#define extFilterBlink		2
#define extShutterBlink		4

extern void  casSetStatusLED( int ADevice, int AWhat );
extern int  casStopTime( int ADevice, int ARefTime );
extern int  casNmToPixel( int ADevice, double nm );
extern double  casPixelToNm( int ADevice, int APixel );
extern int  casCalculateTOPParameter( int ADevice, int AAperture, double ADistance, double* ASpotSize, double* AFieldOfView);

////////////////
// MultiTrack //
////////////////
extern int  casMultiTrackInit( int ADevice, int ATracks );
extern int  casMultiTrackDone( int ADevice );
extern int  casMultiTrackCount( int ADevice );
extern void  casMultiTrackCopySet( int ADevice );
extern int  casMultiTrackReadData( int ADevice, int ATrack );
extern int  casMultiTrackCopyData( int ADevice, int ATrack );
extern int  casMultiTrackSaveData( int ADevice, char* AFileName );
extern int  casMultiTrackSaveDataW( int ADevice, unichar* AFileName );
extern int  casMultiTrackLoadData( int ADevice, char* AFileName );
extern int  casMultiTrackLoadDataW( int ADevice, unichar* AFileName );

///////////////////////////
// Spectrum Manipulation //
///////////////////////////
extern void  casSetData( int ADevice, int AIndex, double Value );
extern void  casSetXArray( int ADevice, int AIndex, double Value );
extern void  casSetDarkCurrent( int ADevice, int AIndex, double Value );
extern float*  casGetDataPtr( int ADevice );
extern float*  casGetXPtr( int ADevice );
extern void  casLoadTestData( int ADevice, char* AFileName );
extern void  casLoadTestDataW( int ADevice, unichar* AFileName );

//////////////////////////
// Deprecated methods!! //
//////////////////////////
extern int  casGetInitialized(int ADevice);
extern int  casGetDeviceType( int ADevice );
extern int  casGetDeviceOption( int ADevice );
extern int  casGetAdcBits( int ADevice );
extern int  casGetAdcRange( int ADevice );
extern char*  casGetSerialNumber( int ADevice, char* Dest, int ASize );
extern int  casGetDeadPixels(int ADevice);
extern int  casGetVisiblePixels(int ADevice);
extern int  casGetPixels(int ADevice);
extern int  casGetModel(int ADevice);
extern double  casGetAmpOffset(int ADevice);
extern int  casGetIntTimeMin( int ADevice );
extern int  casGetIntTimeMax( int ADevice );
extern int  casBackgroundMeasure( int ADevice );
extern int  casGetIntegrationTime( int ADevice );
extern void  casSetIntegrationTime( int ADevice, int Value );
extern int  casGetAccumulations( int ADevice );
extern void  casSetAccumulations( int ADevice, int Value );
extern double  casGetAutoIntegrationLevel( int ADevice );
extern void  casSetAutoIntegrationLevel( int ADevice, double ALevel );
extern int  casGetAutoIntegrationTimeMax( int ADevice );
extern void  casSetAutoIntegrationTimeMax( int ADevice, int AMaxTime );
extern int  casClearBackground( int ADevice );
extern int  casGetNeedBackground( int ADevice );
extern void  casSetNeedBackground( int ADevice, int Value );
extern int  casGetTop100( int ADevice );
extern void  casSetTop100( int ADevice, int AIndex );
extern double  casGetTop100Distance( int ADevice );
extern void  casSetTop100Distance( int ADevice, double ADistance );
extern int  casGetFilter( int ADevice );
extern void  casSetFilter( int ADevice, int AFilter );
extern int  casGetActualFilter( int ADevice );
extern int  casGetNewDensityFilter( int ADevice );
extern void  casSetNewDensityFilter( int ADevice, int AFilter );
extern int  casGetForceFilter( int ADevice );
extern void  casSetForceFilter( int ADevice, int AForce );
extern int  casGetParamSets( int ADevice );
extern void  casSetParamSets( int ADevice, int Value );
extern int  casGetParamSet( int ADevice );
extern void  casSetParamSet( int ADevice, int Value );
extern char*  casGetCalibrationFileName( int ADevice, char* Dest, int ASize );
extern void  casSetCalibrationFileName( int ADevice, char* Value );
extern char*  casGetConfigFileName( int ADevice, char* Dest, int ASize );
extern void  casSetConfigFileName( int ADevice, char* Value );
extern char*  casGetTransmissionFileName( int ADevice, char* Dest, int ASize );
extern void  casSetTransmissionFileName( int ADevice, char* Value );
extern int  casValidateConfigAndCalibFile( int ADevice );
extern char*  casGetCalibrationUnit( int ADevice, char* Dest, int ASize );
extern void  casSetCalibrationUnit( int ADevice, char* Value );
extern double  casGetBackground( int ADevice, int AIndex );
extern void  casSetBackground( int ADevice, int AIndex, double Value );
extern int  casGetMaxAdcValue( int ADevice );
extern int  casGetCheckStart( int ADevice );
extern void  casSetCheckStart( int ADevice, int Value );
extern int  casGetCheckStop( int ADevice );
extern void  casSetCheckStop( int ADevice, int Value );
extern double  casGetColormetricStart( int ADevice );
extern void  casSetColormetricStart( int ADevice, double Value );
extern double  casGetColormetricStop( int ADevice );
extern void  casSetColormetricStop( int ADevice, double Value );
extern int  casGetObserver( void );
extern void  casSetObserver( int ADevice );
extern double  casGetSkipLevel( int ADevice );
extern void  casSetSkipLevel( int ADevice, double ASkipLevel );
extern int  casGetSkipLevelEnabled( int ADevice );
extern void  casSetSkipLevelEnabled( int ADevice, int ASkipLevel );
extern int  casGetTriggerSource( int ADevice );
extern void  casSetTriggerSource( int ADevice, int Value );
extern int  casGetLine1FlipFlop( int ADevice );
extern void  casSetLine1FlipFlop( int ADevice, int Value );
extern int  casGetTimeout( int ADevice );
extern void  casSetTimeout( int ADevice, int Value );
extern int  casGetFlash( int ADevice );
extern void  casSetFlash( int ADevice, int Value );
extern int  casGetFlashDelayTime( int ADevice );
extern void  casSetFlashDelayTime( int ADevice, int Value );
extern int  casGetFlashOptions( int ADevice );
extern void  casSetFlashOptions( int ADevice, int Value );
extern int  casGetDelayTime( int ADevice );
extern void  casSetDelayTime( int ADevice, int Value );
extern int  casGetStartTime( int ADevice );
extern int  casGetACQTime( int ADevice );
extern int  casReadWatch( int ADevice );

#ifdef __cplusplus
};
#endif /* __cplusplus */


#endif // __CAS4_included__

