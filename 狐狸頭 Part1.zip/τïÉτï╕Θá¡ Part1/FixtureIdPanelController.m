/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa         $Workfile:: FixtureIdPanelController.m  $|
 | $Author:: Henry           $Revision::  1							 $|
 | CREATED: 29.08.10         $Modtime:: 11.08.10 15:24				 $|
 | STATE  : Alpha                                                     |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: SingleUIModuleSN.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 29.06.10   Time: 15:58
 * Created in 
 * first implementation
 */

#import "FixtureIdPanelController.h"


@implementation FixtureIdPanelController

- (id)init
{
	fixtureId = nil;
	if(![super initWithWindowNibName:@"SetFixtureId"])
		return nil;
	return self;
}

-(void)awakeFromNib
{
	[self showFixtureId:fixtureId];
	[UICommon setFixtureIDScanedFlag:NO];
	[UICommon setShowFixtureIDPanelFlag:YES] ;
}

- (void)windowDidLoad
{
	NSLog(@"Nib SetFixtureId is loaded !");
}
-(BOOL)windowShouldClose:(id)window
{
	if(fixtureId)
	{
		[UICommon setFixtureID:fixtureId];
		[UICommon setFixtureIDScanedFlag:YES];
	}
	[UICommon setShowFixtureIDPanelFlag:NO] ;
	return YES;
}
-(void)dealloc
{
	[UICommon setShowFixtureIDPanelFlag:NO] ;
	[super dealloc] ;
}

- (IBAction)btnOKClick:(id)sender
{
	NSString *inputStr = [textFixtureId stringValue];
	if(inputStr != nil)
	{
		fixtureId = inputStr ;
		[self showFixtureId:inputStr];
	}

}

-(IBAction)textFixtureIdChange:(id)sender
{
	NSString *inputStr = [textFixtureId stringValue];
	if(inputStr != nil)
	{
		fixtureId = inputStr ;
		[self showFixtureId:inputStr];
		[btnOK becomeFirstResponder];
	}
}

- (NSString *)getFixtureId
{
	return fixtureId;
}

- (void)showFixtureId:(NSString *)strFixId
{
	float redValue   =(float)95/255;
	float greenValue =(float)89/255;
	float blueValue  =(float)53/255;
	
	if(strFixId != nil)
	{
		[labelShowFixtureId setStringValue:strFixId];
		[labelShowFixtureId setFont:[NSFont userFontOfSize:28]] ;
		[labelShowFixtureId setFrame:(NSMakeRect(106, 27, 270, 30))];
		[labelShowFixtureId setTextColor:[NSColor colorWithCalibratedRed:redValue green:greenValue blue:blueValue alpha:1.0]];
		
	}
}

- (IBAction)btnExitClick:(id)sender
{
	[win performClose:self];
}
@end
