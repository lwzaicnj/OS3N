//
//  IFTMobileDevice.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 11/6/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "IFTMobDevAFCFile.h"
#import "IFTMobDevAFCConnection.h"

#define kCFTSDeviceUSBLocation	@"kCFTSDeviceUSBLocation"
#define kCFTSDeviceID			@"kCFTSDeviceID"

@interface IFTMobileDevice : NSObject {
    NSString* uuid;
    NSMutableDictionary* deviceInfo;
    UInt16 deviceID;
    UInt32 usbLocation;
    void* device;
}

@property (readwrite, copy) NSString* uuid;
@property (readwrite, copy) NSMutableDictionary* deviceInfo;
@property (readonly) UInt16 deviceID;
@property (readonly) UInt32 usbLocation;

-(id)init:(void*)p_device deviceInfo:(CFTypeRef)amdInfo;
-(BOOL)connect:(NSError**)e;
-(BOOL)disConnect:(NSError**)e;
-(BOOL)startSession:(NSError**)e;
-(BOOL)stopSession:(NSError**)e;
-(NSDictionary*)copyValue:(NSString*)domain key:(NSString*)key error:(NSError**)e;
-(IFTMobDevAFCConnection*)newAFCConnection:(NSError**)e;


@end
