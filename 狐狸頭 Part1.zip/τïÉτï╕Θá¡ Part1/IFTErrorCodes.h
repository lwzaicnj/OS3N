/*
 *  IFTErrorCodes.h
 *  iFactoryTestFramework
 *
 *  Created by Wei Wang on 10/15/09.
 *  Copyright 2009 Apple. All rights reserved.
 *
 */

#define kIFTConfigDataError -60000
#define kIFTConfigLoadError -40000
#define kIFTConfigUnrecognizedMethodError -40001
#define kIFTInvalidResourceForSite -80001
#define kIFTSocketWriteError -20000
#define kIFTSocketReadError -20001
#define kIFTDAVDPCommandError -21000
#define kIFTDAVDPCommError -21001
#define kIFTDAVDPReadBackTimeoutError -21002
#define kIFTSerialWriteErrorCode -10000
#define kIFTSerialReadErrorCode -10001
#define kIFTSerailOpenErrorCode -10002
#define kIFTUnknownInstrument -70000
#define kIFTMobDevCopyDeviceValueFail -80000


