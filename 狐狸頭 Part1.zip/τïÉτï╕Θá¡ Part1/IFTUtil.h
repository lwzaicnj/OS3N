//
//  IFTUtil.h
//  iFactoryTestFramework
//
//  Created by Wei Wang on 9/25/09.
//  Copyright 2009 Apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
extern NSString* const IFTFrameworkErrorDomain;
#import "IFTErrorCodes.h"
#import "IFTSleeper.h"
#import "IFTCSVLogger.h"

#define IFT_MAX_READ_SIZE 5000
@interface IFTUtil : NSObject {

}
+(NSError*) handleError:(int)errorNumber withMessage:(NSString*)msg;
+(NSError*) handleError:(int)errorNaumber domain:(NSString*)errorDomain message:(NSString*)errorMessage;
+(NSError*) handleError:(NSError*)underlyingError extraMessage:(NSString*)errorMessage;

//this function returns an autoreleased string
+(NSString*) arrayToString:(NSArray*)array  delineator:(NSString*)del;
@end
