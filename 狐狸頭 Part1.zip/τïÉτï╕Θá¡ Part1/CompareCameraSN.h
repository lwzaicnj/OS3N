//
//  CompareCameraSN.h
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CompareCameraSNFun)

+(void)CompareCameraSN:(NSDictionary*)dictKeyDefined;
+(void)CompareCameraSN2:(NSDictionary *)dictKeyDefined;

+(NSString *)getCheckSum:(NSString *)unitSN ;

+(void)CompareGrapeColWithHSG:(NSDictionary*)dictKeyDefined;//add by jack 20151116

+(void)ParseCompareHSGColorWithDCLr:(NSDictionary*)dictKeyDefined;//add by jack 20151116

@end
