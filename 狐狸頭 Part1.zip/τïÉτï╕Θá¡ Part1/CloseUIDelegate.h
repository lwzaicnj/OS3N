/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                $Workfile:: CloseUIDelegate.h    $|
 | $Author:: Henry                  $Revision::  1					 $|
 | CREATED: 25.03.10                $Modtime:: 26.03.10 15:24		 $|
 | STATE  : Beta                                                      |
 +--------------------------------------------------------------------+
 
 MODULE  : 
 
 PURPOSE : 
 
 $History:: CloseUIDelegate.h                                       $
 * *****************  Version 1  *****************
 * User: Henry           Date: 25.03.10   Time: 15:58
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>


@interface CloseUIDelegate : NSObject {

}

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication; 
-(BOOL)windowShouldClose:(id)window;
-(void)powerOffFixture;

@end
