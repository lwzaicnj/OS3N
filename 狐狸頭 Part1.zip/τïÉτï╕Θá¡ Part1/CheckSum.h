//
//  CheckSum.h
//  qt_simulator
//
//  Created by QTeam on 4/6/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CheckSum)

+(void)CheckSum:(NSDictionary*)dictKeyDefined ;
+(void)ParseCompareVBSTandVPBR:(NSDictionary*)dictKeyDefined;
+(void)ParseValidateVboostAndVPBR:(NSDictionary*)dictKeyDefined;
+(void)ParseGetTheWifiSN:(NSDictionary*)dictKeyDefined;
+(void)ParseGSMNVStatus:(NSDictionary*)dictKeyDefined;//Julian 20120914 added for PS PVT
+(void)RamDiskStart:(NSDictionary*)dictKeyDefined  ;//dsx 05-10 ramdisk test
+(void)RamDiskStop:(NSDictionary*)dictKeyDefined ;//dsx 05-10 ramdisk test

+(void)CheckSumBatterySN:(NSDictionary*)dictKeyDefined ;

+(void)MatchBatterySN:(NSDictionary*)dictKeyDefined  ;

+(void)usbpOpen:(NSDictionary*)dictKeyDefined;

+(void)usbpClose:(NSDictionary*)dictKeyDefined;

+(void)SendCmdtoTerminal:(NSDictionary*)dictKeyDefined;

+ (void)ParseTHUMMonior:(NSDictionary*)dictKeyDefined;

+ (void)ParseControlUSBBySendCommandToComputer:(NSDictionary*)dictKeyDefined;

@end
