/*
 +--------------------------------------------------------------------+
 | PROJECT: QT-Cocoa                    $Workfile:: CLCDFunction.h
 | $Author::Joko Li                           $Revision:: 1               
 | CREATED: 2010.03.31                  $Modtime::  14:20     
 | STATE  : Beta                                                     
 +--------------------------------------------------------------------+
 
 MODULE  :CLCD Method
 
 PURPOSE :CLCD function.
 
 $History:: CLCDFunction.h                                           
 * *****************  Version 1  *****************
 * User: Joko Li           Date: 2010.03.31   Time: 14:20
 * Created in $/GSM/DEV/MS/SRC/MFW
 * first implementation
 
 */

#import <Cocoa/Cocoa.h>
#import "testItemParse.h"
#import "scriptParse.h"

@interface TestItemParse(CLCDFunction)

+(void)ParseWithCLCD:(NSDictionary*)dictKeyDefined;

@end
