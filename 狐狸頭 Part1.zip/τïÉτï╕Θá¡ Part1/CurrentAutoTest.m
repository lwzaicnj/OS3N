//
//  CurrentAutoTest.m
//  iFTS
//
//  Created by swdiag on 9/24/11.
//  Copyright 2011 sz. All rights reserved.
//

#import "CurrentAutoTest.h"
#import "toolFun.h"
#import "testItemParse.h"

//SCRID:135
//auther:caijunbo 2011-09-27
//description:Used to parse CurrentTestLog.txt file generated in unit.
@implementation TestItemParse(CurrentAutoTestFunction)

+(void)GetCurrentTestLog:(NSDictionary*)dictKeyDefined
{
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	NSString* strExec=@"rm -r /Current/*";
	system([strExec UTF8String]);

	strExec=@"cp /Users/gdlocal/Desktop/DFUCurrent/*/*/CurrentTestLog.txt /Current/CurrentTestLog.txt";
	system([strExec UTF8String]);
	strExec=@"cp -r /Users/gdlocal/Desktop/DFUCurrent/* /AllLog/";
	system([strExec UTF8String]);
	
	NSString *strTmp = [NSString stringWithContentsOfFile:@"/Current/CurrentTestLog.txt" encoding:NSASCIIStringEncoding error:nil] ;
	/*
	FILE* file=open("/Users/mac/Desktop/Test/CurrentTestLog.txt","r");
	char cCurrentBuf[6000];
	cCurrentBuf[5999]='\0';
	fread(cCurrentBuf,1, 5998,file);
	fclose(file);
	NSString *strTmp=[NSString stringWithUTF8String:cCurrentBuf];
	 */
	NSLog(@"%@",strTmp);
	if (strTmp==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Fail to Get Current Log"];
		strExec=@"rm -r /Users/gdlocal/Desktop/DFUCurrent/*";
		system([strExec UTF8String]);
		return;
	}
	[TestItemManage setBufferValue:dictKeyDefined :@"CurrentTestLogBuffer":strTmp];
	strExec=@"rm -r /Users/gdlocal/Desktop/DFUCurrent/*";
	system([strExec UTF8String]);
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
	

}

+(void)GetCurrentValue:(NSDictionary*)dictKeyDefined
{
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBufferName=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
	
	}
	NSString *strTmp=[TestItemManage getBufferValue:dictKeyDefined :@"CurrentTestLogBuffer"];
	
	[TestItemManage setBufferValue:dictKeyDefined :mBufferName :strTmp];
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
	
	
}

+(void)GetVoltageValue:(NSDictionary*)dictKeyDefined
{
	
	//key parse
	NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
	NSString *mBufferName=nil;
	NSString *mVoltageIndext=nil;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
		
		else if ([strKey isEqualToString:@"VoltageIndex"])
		{
			mVoltageIndext = [dictKeyDefined objectForKey:strKey] ;
		}
	}
	
	if (mBufferName==nil)
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;
		
	}
	
	NSString* strTmp=[TestItemManage getBufferValue:dictKeyDefined :@"CurrentTestLogBuffer"];
	NSMutableArray* arrayTemp=(NSMutableArray*)[strTmp componentsSeparatedByString:@"mV"];
	NSMutableArray* arrayAllVoltageValue=[[[NSMutableArray alloc] init] autorelease];
	NSString* strTempVoltage=@"";
	int iLength=0;
	
	for (int i=0;i<[arrayTemp count];i++)
	{
		strTempVoltage=[arrayTemp objectAtIndex:i];
		iLength=[strTempVoltage length];
		strTempVoltage=[strTempVoltage substringFromIndex:iLength-9];
		strTempVoltage=[strTempVoltage stringByAppendingString:@"mV"];
		strTempVoltage=[strTempVoltage stringByReplacingOccurrencesOfString:@"\n" withString:@""];
		[arrayAllVoltageValue addObject:strTempVoltage];
	
	}
	
	if ([mVoltageIndext isEqualToString:@"State 0"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:0]];
	}
	else if([mVoltageIndext isEqualToString:@"State 11"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:1]];
	}
	else if([mVoltageIndext isEqualToString:@"State 12"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:2]];
	}
	
	else if([mVoltageIndext isEqualToString:@"State 1"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:3]];
	}
	else if([mVoltageIndext isEqualToString:@"State 3"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:4]];
	}
	else if([mVoltageIndext isEqualToString:@"State 7"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:5]];
	}
	else if([mVoltageIndext isEqualToString:@"State 10"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:6]];
	}
	
	else if([mVoltageIndext isEqualToString:@"State 13"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:7]];
	}
	else if([mVoltageIndext isEqualToString:@"State 14"])
	{
		[TestItemManage setBufferValue:dictKeyDefined :mBufferName :[arrayAllVoltageValue objectAtIndex:8]];
	}
	
	else 
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_OTHER :@"Script Occur Error"] ;
	    return  ;

	}
	
	[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :@"Pass"];
	
		
	
	
}

/*=================== justin add Orion test items(QT0a & A-1)=================*/
+(void)GetOrionVoltageValue:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName=nil;
	NSString *mReferenceBufferName=nil;
    NSString *mReferenceBufferNameOfACC=nil;
	NSString *mBufferName=nil;
    NSString *mWriteCmd=nil;
    NSString *mWriteCmd2=nil;
    NSString *mWriteCmdTmp=nil;
    NSString *mDevice=nil;
    NSString *mTimeOut=@"6";
    NSString *mADRPrefix=nil;
	NSString *mADRPostfix=nil;
    NSString *mACCPrefix=nil;
	NSString *mACCPostfix=nil;
    NSString *mContainsString=nil;
    NSString *mUpLimit = nil;
    NSString *mLowLimit = nil;
    NSString *mStepString = nil ;
    NSString *mTmpCurr1 = nil;
    NSString *mTmpCurr2 = nil;
    
    int mStep = 1 ;
    bool flag = true;
    //  bool isFirst = true;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdTemp"])
        {
			mWriteCmdTmp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameOfACC"])
		{
			mReferenceBufferNameOfACC = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ContainsString"])
		{
			mContainsString = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ADRPrefix"])
		{
			mADRPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ADRPostfix"])
		{
			mADRPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ACCPrefix"])
		{
			mACCPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ACCPostfix"])
		{
			mACCPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StepValue"])
		{
			mStepString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	if (mBufferName == nil || mReferenceBufferName == nil || mReferenceBufferNameOfACC == nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"] ;
	    return  ;
        
	}
    //  NSString *strmReferenceBufferValueTmp=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    NSString *strTmpValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName]; //Get ADR value
    NSString *mResitorADRValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mADRPrefix Postfix:mADRPostfix];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    //mResitorADRValueStr=164;
    
    NSString *strTmpValueGetACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //Get ACC value
    NSString *mResitorValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValueGetACC Prefix:mACCPrefix Postfix:mACCPostfix];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    //mResitorValueStr=1257
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
    mTmpCurr1 = mResitorValueStr;
    //    NSLog(@"hahahhahahahahahha= %@",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
    
    
    //if (strTmpValue == nil || strTmpValueGetACC==nil)
    if (mResitorADRValueStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Orion ADR value is null."] ;
        return;
    }
    if (![ToolFun isNumber: mResitorADRValueStr])
    {
        NSString *mfailmsg = [@"ADR value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    if (mResitorADRValueStr.length > 3 ) // 0<mResitorADRValueStr<255
    {
        NSString *mfailmsg = [@"Acc value out of 255: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];
        return;
    }
    
    
    int mResitorValue = [mResitorADRValueStr intValue]; ;// init next ADR value : mResitorADRValueStr + 1
    int outCount=0;
    if (mStepString !=nil)
    {
        mStep = [mStepString intValue];
    }
    while (flag)
    {
        mResitorValue = mResitorValue + mStep;
        if (mResitorValue < 0)
        {
            mResitorADRValueStr = @"000";
        }
        if (mResitorValue<10 && mResitorValue>0)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
        }
        else if (mResitorValue>9 && mResitorValue<100)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
        }
        else if (mResitorValue>99 && mResitorValue<256)
        {
            mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
        }
        else if (mResitorValue>255)
        {
            mResitorADRValueStr = @"255";
        }
        
        NSString *mWriteCmdTmp1 = [mWriteCmdTmp stringByAppendingString:@" "];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:mResitorADRValueStr];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:@"\r"];
        
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp1 :@"*_*"] ;//Send CMD:SDR xxx
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(30000) ; //delay 50ms
            }
        }
        
        NSString *dataResult33 = [self ReceData:dictKeyDefined] ;
        NSLog(@"SDR rec str=%@",dataResult33);
        mWriteCmdTmp1 = @"";
        // usleep(100000) ; //delay 50ms
        
        
        [dictKeyDefined setValue:@"IPad" forKey:@"Device"];
        [dictKeyDefined setValue:@":-)" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;//Send CMD:mWriteCmd (script orion_read_oc) to get egpio pin
        
        
        NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
        int iTmp1 = [mTimeOut intValue] ;
        int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
        while (timeInterval1<=iTmp1)
        {
            timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(30000) ; //delay 50ms
            }
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ; //Get egpio pin value
        if (dataResult!=nil )
        {
            if (mContainsString !=nil)
            {
                if([dataResult rangeOfString:mContainsString].length>0)
                {
                    //mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];//get ACC value of the last time
                    // [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strTmpValueGetACC];
                    mTmpCurr2 = [TestItemManage getBufferValue:dictKeyDefined :mBufferName];
                    if ((mUpLimit != nil) && (mLowLimit != nil))
                    {
                        if(([mTmpCurr2 intValue] >= [mLowLimit intValue]) && ([mTmpCurr2 intValue] <= [mUpLimit intValue]))
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                            return;
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                            return;
                        }
                    }
                    if ((mUpLimit != nil) && (mLowLimit == nil))
                    {
                        if( [mTmpCurr2 intValue] <= [mUpLimit intValue] )
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                            return;
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                            return;
                        }
                    }
                    if ((mUpLimit == nil) && (mLowLimit != nil))
                    {
                        if( [mTmpCurr2 intValue] >= [mLowLimit intValue] )
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                            return;
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                            return;
                        }
                    }
                    if ((mUpLimit == nil) && (mLowLimit == nil))
                    {
                        
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                        return;
                    }
                    
                }
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script ontain string is null"];
                return;
            }
            
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received (read_oc) data"];
            return;
        }
        //       usleep(200000) ; //delay 50ms
        
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd2 :@"*_*"] ; //Send CMD :GET ACCxx
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult1 = [self ReceData:dictKeyDefined] ;
        if (dataResult1!=nil )
        {
            //            NSString *mPrefix2 = [mWriteCmd2 stringByAppendingString:@":"];
            //            NSString *mResitorValueStr1 =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            //            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr1] ;
            //            NSString *strTmpValueGetLoopACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //ACC value
            NSString *mResitorValueTempStr =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@" " withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            if (mResitorValueTempStr!=nil)
            {
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueTempStr] ;
            }
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received (get acc) data!"];
            return;
        }
        
        outCount++;
        if (outCount > 50)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Loop test over 50x!"];
            NSLog(@"loop test over 50x");
            return;
        }
        
    }
}

//+(void)GetOverFlowCurrent:(NSDictionary*)dictKeyDefined
+(void)GetOrionLowVoltageValue:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferNameOfACC = nil;
	NSString *mBufferName = nil;
    NSString *mWriteCmd = nil;
    NSString *mWriteCmd2 = nil;
    NSString *mWriteCmdTmp = nil;
    NSString *mDevice = nil;
    NSString *mTimeOut = @"6";
    NSString *mADRPrefix = nil;
	NSString *mADRPostfix = nil;
    NSString *mACCPrefix = nil;
	NSString *mACCPostfix = nil;
    NSString *mContainsString = nil;
    NSString *mTempString1 = nil;
    NSString *mTempString2 = nil;
    NSString *mUpLimit = nil;
    NSString *mLowLimit = nil;
    NSString *mStepString = nil;
    int mStep = 1 ;
    
    bool flag = true;
    int iflag ;
    //  bool isFirst = true;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdTemp"])
        {
			mWriteCmdTmp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameOfACC"])
		{
			mReferenceBufferNameOfACC = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ContainsString"])
		{
			mContainsString = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ADRPrefix"])
		{
			mADRPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ADRPostfix"])
		{
			mADRPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ACCPrefix"])
		{
			mACCPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ACCPostfix"])
		{
			mACCPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StepValue"])
		{
			mStepString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	if (mBufferName == nil || mReferenceBufferName == nil || mReferenceBufferNameOfACC == nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"] ;
	    return  ;
        
	}
    NSString *strTmpValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName]; //get ADR value
    NSString *mResitorADRValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mADRPrefix Postfix:mADRPostfix];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    
    NSString *strTmpValueGetACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //get ACC value
    NSString *mResitorValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValueGetACC Prefix:mACCPrefix Postfix:mACCPostfix];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    
    
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
    
    //if (strTmpValue == nil || strTmpValueGetACC==nil)
    if (mResitorADRValueStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Orion ACC value is null."] ;
        return;
    }
    if (![ToolFun isNumber: mResitorADRValueStr])
    {
        NSString *mfailmsg = [@"ADR value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    if (mResitorADRValueStr.length > 3 )
    {
        NSString *mfailmsg = [@"Acc value length > 3 : " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];
        return;
    }
    if ([ToolFun isNumber: mResitorValueStr])
    {
        mTempString1 = mResitorValueStr;
    }
    else
    {
        NSString *mTmpMsg = [mWriteCmd2 stringByAppendingString:@" reture value1 is not a number."];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpMsg] ;
        return;
    }
    
    
    
    int mResitorValue = [mResitorADRValueStr intValue]; ;// init next ADR value : mResitorADRValueStr + 1
    if (mStepString != nil)
    {
        mStep = [mStepString intValue];
    }
    int outCount=0;
    while (flag)
    {
        mResitorValue = mResitorValue + mStep;
        if (mResitorValue< 0)
        {
            mResitorADRValueStr =@"000";
        }
        else if (mResitorValue<10 && mResitorValue >= 0)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
        }
        else if (mResitorValue>9 && mResitorValue<100)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
        }
        else if (mResitorValue>99 && mResitorValue<256)
        {
            mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
        }
        else if (mResitorValue>255)
        {
            mResitorADRValueStr = @"255";
            return;
        }
        
        NSString *mWriteCmdTmp1 = [mWriteCmdTmp stringByAppendingString:@" "];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:mResitorADRValueStr];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:@"\r"];
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp1 :@"*_*"] ;//Send CMD:SDR xxx
        
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        NSString *dataResult33 = [self ReceData:dictKeyDefined] ;
        NSLog(@"SDR rec str=%@",dataResult33);
        mWriteCmdTmp1 = @"";
        //    usleep(100000) ; //delay 50ms
        
        
        [dictKeyDefined setValue:@"IPad" forKey:@"Device"];
        [dictKeyDefined setValue:@":-)" forKey:@"Postfix"];
        NSLog(@"I get the device = %@ !",[dictKeyDefined valueForKey:@"Device"]);
        [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;//Send CMD:mWriteCmd (script orion_read_oc) to get egpio pin
        NSLog(@"I send CMD = %@ \n",[dictKeyDefined valueForKey:@"WriteCmd"]);
        
        NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
        int iTmp1 = [mTimeOut intValue] ;
        int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
        while (timeInterval1<=iTmp1)
        {
            timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ; //Get egpio pin value
        if (dataResult!=nil )
        {
            if (mContainsString !=nil)
            {
                if([dataResult rangeOfString:mContainsString].length>0)
                {
                    //mReferenceBufferValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];//get ACC value of the last time
                    // [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :strTmpValueGetACC];
                    NSString *mTempValue = [TestItemManage getBufferValue:dictKeyDefined :mBufferName];
                    if ((mUpLimit != nil) && (mLowLimit != nil))
                    {
                        if(([mTempValue intValue] >= [mLowLimit intValue]) && ([mTempValue intValue] <= [mUpLimit intValue]))
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTempValue];
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTempValue];
                            
                        }
                    }
                    if ((mUpLimit != nil) && (mLowLimit == nil))
                    {
                        if( [mTempValue intValue] <= [mUpLimit intValue] )
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTempValue];
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTempValue];
                            
                        }
                    }
                    if ((mUpLimit == nil) && (mLowLimit != nil))
                    {
                        if( [mTempValue intValue] >= [mLowLimit intValue] )
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTempValue];
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTempValue];
                        }
                    }
                    if ((mUpLimit == nil) && (mLowLimit == nil))
                    {
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTempValue];
                    }
                    return;
                    //                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[TestItemManage getBufferValue:dictKeyDefined :mBufferName]];
                    //                    flag = false;
                    //                    return;
                }
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script SontainString is null"];
                return;
            }
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
            return;
        }
        //       usleep(200000) ; //delay 50ms
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd2 :@"*_*"] ; //Send CMD :GET ACCxx
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        int tmpii = 0;
        NSString *dataResult1 = [self ReceData:dictKeyDefined] ;
        if (dataResult1!=nil )
        {
            NSString *mResitorValueTempStr =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@" " withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            if ([ToolFun isNumber: mResitorValueStr])
            {
                mTempString2 = mResitorValueTempStr ;
                iflag = [mTempString2 intValue] - [ mTempString1 intValue];
                if (iflag <= 0)
                {
                    tmpii=1;
                    continue;
                }
                else
                {
                    mTempString1 = mTempString2;
                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTempString1] ;
                }
            }
            else
            {
                NSString *mTmpMsg = [mWriteCmd2 stringByAppendingString:@"Reture value2 is not a number."];
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpMsg] ;
                return;
            }
            
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data!"];
            return;
        }
        outCount =outCount + tmpii;
        if (outCount > 50)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Loop test over 50x!"];
            NSLog(@"loop test over 50x");
            return;
        }
        
    }
}

+(void)GetOrionHighVoltageValue:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferNameOfACC = nil;
	NSString *mBufferName = nil;
    NSString *mWriteCmd = nil;
    NSString *mWriteCmd2 = nil;
    NSString *mWriteCmdTmp = nil;
    NSString *mDevice = nil;
    NSString *mTimeOut = @"6";
    NSString *mADRPrefix = nil;
	NSString *mADRPostfix = nil;
    NSString *mACCPrefix = nil;
	NSString *mACCPostfix = nil;
    NSString *mContainsString = nil;
    NSString *mCurrentValuePostfix = nil;
    NSString *mCurrentValuePrefix = nil;
    NSString *mTmpCurr1 = nil;
    NSString *mTmpCurr2 = nil;
    NSString *mUpLimit = nil;
    NSString *mLowLimit = nil;
    NSString *mStepString = nil;
    int mStep = 1 ;
    
    
    
    bool flag = true;
    //  bool isFirst = true;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdTemp"])
        {
			mWriteCmdTmp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameOfACC"])
		{
			mReferenceBufferNameOfACC = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ContainsString"])
		{
			mContainsString = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ADRPrefix"])
		{
			mADRPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ADRPostfix"])
		{
			mADRPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ACCPrefix"])
		{
			mACCPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ACCPostfix"])
		{
			mACCPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CurrentValuePrefix"])
		{
			mCurrentValuePrefix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CurrentValuePostfix"])
		{
			mCurrentValuePostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StepValue"])
		{
			mStepString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	if (mBufferName == nil || mReferenceBufferName == nil || mReferenceBufferNameOfACC == nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"] ;
	    return  ;
        
	}
    //  NSString *strmReferenceBufferValueTmp=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    NSString *strTmpValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName]; //ADR value
    NSString *mResitorADRValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mADRPrefix Postfix:mADRPostfix];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    //get the set current value (CMD:ADR xxxxx)
    NSString *mADRSetCurrentValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mCurrentValuePrefix Postfix:mCurrentValuePostfix];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if (mADRSetCurrentValueStr == nil || (![ToolFun isNumber: mADRSetCurrentValueStr]))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Set a error current!"] ;
	    return  ;
    }
    
    //read the reality current value from ACC
    NSString *strTmpValueGetACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //ACC value
    NSString *mResitorValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValueGetACC Prefix:mACCPrefix Postfix:mACCPostfix];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
    
    //if (strTmpValue == nil || strTmpValueGetACC==nil)
    if (mResitorADRValueStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Orion ACC trigger value is null."] ;
        return;
    }
    if (![ToolFun isNumber: mResitorADRValueStr])
    {
        NSString *mfailmsg = [@"ADR value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    if (mResitorADRValueStr.length > 3 )
    {
        NSString *mfailmsg = [@"Acc value out of 255 : " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];
        return;
    }
    
    if (![ToolFun isNumber: mResitorValueStr])
    {
        NSLog(@"mResitorValueStr is %@",mResitorValueStr);
        NSString *mfailmsg = [@"ACC value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    
    int inCaseCurrent = [mResitorValueStr intValue] - [mADRSetCurrentValueStr intValue];
    int mResitorValue = [mResitorADRValueStr intValue]; ;// init next ADR value : mResitorADRValueStr + 1
    
    
    mTmpCurr1 = mResitorValueStr ;//the first get acc value
    if (mStepString != nil)
    {
        mStep = [mStepString intValue];
    }
    int outCount=0;
    while (flag)
    {
        if (inCaseCurrent == 0)
        {
            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mResitorValueStr];
            return;
        }
        else if (inCaseCurrent > 0)
        {
            mResitorValue = mResitorValue - mStep;
            if (mResitorValue< 0)
            {
                mResitorADRValueStr =@"000";
            }
            else if (mResitorValue<10 && mResitorValue >= 0)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
            }
            else if (mResitorValue>9 && mResitorValue<100)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
            }
            else if (mResitorValue>99 && mResitorValue<256)
            {
                mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
            }
            else if (mResitorValue>255)
            {
                mResitorADRValueStr = @"255";
                return;
            }
        }
        else if (inCaseCurrent < 0)
        {
            mResitorValue = mResitorValue + mStep;
            if (mResitorValue < 0)
            {
                mResitorADRValueStr = @"000";
            }
            else if (mResitorValue < 10 && mResitorValue >=0)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
            }
            else if (mResitorValue > 9 && mResitorValue < 100)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
            }
            else if (mResitorValue > 99 && mResitorValue < 256)
            {
                mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
            }
            else if (mResitorValue > 255)
            {
                mResitorADRValueStr = @"255";
            }
            
        }
        
        NSString *mWriteCmdTmp1 = [mWriteCmdTmp stringByAppendingString:@" "];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:mResitorADRValueStr];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:@"\r"];
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp1 :@"*_*"] ;//Send CMD:SDR xxx
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult33 = [self ReceData:dictKeyDefined] ;
        NSLog(@"SDR rec str=%@",dataResult33);
        mWriteCmdTmp1 = @"";
        //      usleep(100000) ; //delay 50ms
        
        
        [dictKeyDefined setValue:@"IPad" forKey:@"Device"];
        [dictKeyDefined setValue:@":-)" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;//Send CMD:mWriteCmd (script orion_read_oc) to get egpio pin
        NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
        int iTmp1 = [mTimeOut intValue] ;
        int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
        while (timeInterval1<=iTmp1)
        {
            timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        //read data
        NSString *dataResult = [self ReceData:dictKeyDefined] ; //Get egpio pin value
        if (dataResult!=nil )
        {
            if (mContainsString !=nil)
            {
                if([dataResult rangeOfString:mContainsString].length>0)
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[TestItemManage getBufferValue:dictKeyDefined :mBufferName]];
                    flag = false;
                    return;
                }
            }
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
            return;
        }
        //        usleep(200000) ; //delay 50ms
        
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd2 :@"*_*"] ; //Send CMD :GET ACCxx
        NSLog(@"I have changed the device from %@ to Ipad!",[dictKeyDefined valueForKey:@"Device"]);
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult1 = [self ReceData:dictKeyDefined] ;
        if (dataResult1!=nil )
        {
            NSString *mResitorValueTempStr =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@" " withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            if ([ToolFun isNumber:mResitorValueTempStr])
            {
                mTmpCurr2 = mResitorValueTempStr;
                if (inCaseCurrent < 0)
                {
                    if ( ([mTmpCurr2 intValue] - [mTmpCurr1 intValue] ) >=0 )
                    {
                        if ( ([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue] ) > 0 )
                        {
                            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                            return;
                        }
                    }
                    mTmpCurr1 = mTmpCurr2;
                }
                else if ( inCaseCurrent > 0 )
                {
                    if ( ([mTmpCurr2 intValue] - [mTmpCurr1 intValue] ) < 0 )
                    {
                        if (([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue]) < 0)
                        {
                            if (([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue] ) < 0)
                            {
                                if ((mLowLimit == nil) && (mUpLimit == nil))
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                    NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                }
                                if ((mLowLimit == nil) && (mUpLimit != nil))
                                {
                                    if ([mTmpCurr1 intValue] <= [mUpLimit intValue])
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                    else
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                }
                                if ((mLowLimit != nil) && (mUpLimit == nil))
                                {
                                    if ([mTmpCurr1 intValue] >= [mUpLimit intValue])
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                    else
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                }
                                if ((mLowLimit != nil) && (mUpLimit != nil))
                                {
                                    if (([mTmpCurr1 intValue] <= [mUpLimit intValue]) && ([mTmpCurr1 intValue] >= [mLowLimit intValue]))
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                    else
                                    {
                                        [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                        NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                                    }
                                }
                                
                                
                                mResitorValue = mResitorValue + 1; //if pass ,than set current value back
                                if (mResitorValue < 0)
                                {
                                    mResitorADRValueStr = @"000";
                                }
                                else if (mResitorValue < 10 && mResitorValue >=0)
                                {
                                    mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
                                }
                                else if (mResitorValue > 9 && mResitorValue < 100)
                                {
                                    mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
                                }
                                else if (mResitorValue > 99 && mResitorValue < 256)
                                {
                                    mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
                                }
                                else if (mResitorValue > 255)
                                {
                                    mResitorADRValueStr = @"255";
                                }
                                NSString *mWriteCmdTmp3 = [mWriteCmdTmp stringByAppendingString:@" "];
                                mWriteCmdTmp3 = [mWriteCmdTmp3 stringByAppendingString:mResitorADRValueStr];
                                mWriteCmdTmp3 = [mWriteCmdTmp3 stringByAppendingString:@"\r"];
                                
                                NSLog(@"WriteCmdTmp is %@",mWriteCmdTmp3);
                                
                                [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
                                [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
                                [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp3 :@"*_*"] ;//Send CMD:SDR xxx
                                NSLog(@"I have changed the device from %@ to Ipad!",[dictKeyDefined valueForKey:@"Device"]);
                                
                                NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
                                int iTmp3 = [mTimeOut intValue] ;
                                int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
                                while (timeInterval3<=iTmp3)
                                {
                                    timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
                                    if ([self CheckReceDataIsComplete:dictKeyDefined])
                                        break ;
                                    else
                                    {
                                        usleep(10000) ; //delay 50ms
                                    }
                                }
                                
                                NSString *dataResult123 = [self ReceData:dictKeyDefined] ;
                                NSLog(@"SDR rec str=%@",dataResult123);
                                mWriteCmdTmp3 = @"";
                                
                                return;
                            }
                            else
                                mTmpCurr1 = mTmpCurr2;
                            
                        }
                        //                         else
                        mTmpCurr1 = mTmpCurr2;
                        //                         [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                        //                         NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
                    }
                }
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Get ACC current value is not a number"];
                return;
            }
            //            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueTempStr] ;
            //            NSLog(@"ucccccccccccccccc%@!",[TestItemManage getBufferValue:dictKeyDefined :mBufferName]);
            
        }
        else
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data!"];
            return;
        }
        outCount++;
        if (outCount > 50)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Loop test over 50x!"];
            NSLog(@"loop test over 50x");
            return;
        }
        
    }
}


/*=================== justin add Orion test items(QT0a & A-1)=================*/
/*
+(void)GetTargetSettingCurrentForHigh:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
	NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferNameOfACC = nil;
	NSString *mBufferName = nil;
    NSString *mWriteCmd = nil;
    NSString *mWriteCmd2 = nil;
    NSString *mWriteCmdTmp = nil;
    NSString *mDevice = nil;
    NSString *mTimeOut = @"6";
    NSString *mADRPrefix = nil;
	NSString *mADRPostfix = nil;
    NSString *mACCPrefix = nil;
	NSString *mACCPostfix = nil;
    NSString *mContainsString = nil;
    NSString *mCurrentValuePostfix = nil;
    NSString *mCurrentValuePrefix = nil;
    NSString *mTmpCurr1 = nil;
    NSString *mTmpCurr2 = nil;
    NSString *mUpLimit = nil;
    NSString *mLowLimit = nil;
    NSString *mStepString = nil;
    int mStep = 1 ;
    
    
    
    bool flag = true;
    //  bool isFirst = true;
	
	for(int i=0 ;i<[dictKeyDefined count] ;i++)
	{
		NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
		if ([strKey isEqualToString:@"TestItemName"])
		{
			mTestItemName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"Device"])
		{
			mDevice = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd"])
		{
			mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmd2"])
		{
			mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"WriteCmdTemp"])
        {
			mWriteCmdTmp = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ReferenceBufferName"])
		{
			mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ReferenceBufferNameOfACC"])
		{
			mReferenceBufferNameOfACC = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"BufferName"])
		{
			mBufferName = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"TimeOut"])
		{
			mTimeOut = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ContainsString"])
		{
			mContainsString = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ADRPrefix"])
		{
			mADRPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ADRPostfix"])
		{
			mADRPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"ACCPrefix"])
		{
			mACCPrefix = [dictKeyDefined objectForKey:strKey] ;
		}
		else if ([strKey isEqualToString:@"ACCPostfix"])
		{
			mACCPostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CurrentValuePrefix"])
		{
			mCurrentValuePrefix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"CurrentValuePostfix"])
		{
			mCurrentValuePostfix = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"LowerValue"])
		{
			mLowLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"UpperValue"])
		{
			mUpLimit = [dictKeyDefined objectForKey:strKey] ;
		}
        else if ([strKey isEqualToString:@"StepValue"])
		{
			mStepString = [dictKeyDefined objectForKey:strKey] ;
		}
	}
    
	if (mBufferName == nil || mReferenceBufferName == nil || mReferenceBufferNameOfACC == nil )
	{
		[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"] ;
	    return  ;
        
	}
    //  NSString *strmReferenceBufferValueTmp=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    NSString *strTmpValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName]; //ADR value
    NSString *mResitorADRValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mADRPrefix Postfix:mADRPostfix];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    
    //get the set current value (CMD:ADR xxxxx)
    NSString *mADRSetCurrentValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mCurrentValuePrefix Postfix:mCurrentValuePostfix];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if (mADRSetCurrentValueStr == nil || (![ToolFun isNumber: mADRSetCurrentValueStr]))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Set a error current!"] ;
	    return  ;
    }
    
    //read the reality current value from ACC
    NSString *strTmpValueGetACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //ACC value
    NSString *mResitorValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValueGetACC Prefix:mACCPrefix Postfix:mACCPostfix];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
    
    //if (strTmpValue == nil || strTmpValueGetACC==nil)
    if (mResitorADRValueStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Orion ACC trigger value is null."] ;
        return;
    }
    if (![ToolFun isNumber: mResitorADRValueStr])
    {
        NSString *mfailmsg = [@"ADR value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    if (mResitorADRValueStr.length > 3 )
    {
        NSString *mfailmsg = [@"Acc value out of 255 : " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];
        return;
    }
    
    if (![ToolFun isNumber: mResitorValueStr])
    {
        NSLog(@"mResitorValueStr is %@",mResitorValueStr);
        NSString *mfailmsg = [@"ACC value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    
    int inCaseCurrent = [mResitorValueStr intValue] - [mADRSetCurrentValueStr intValue];
    
    int mResitorValue = [mResitorADRValueStr intValue]; ;// init next ADR value : mResitorADRValueStr + 1
    
    if (mWriteCmd == nil && mContainsString == nil)
    {
        if (inCaseCurrent == 0)
        {
            
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mResitorValueStr];
            return;
        }
        
    }
    
    mTmpCurr1 = mResitorValueStr ;//the first get acc value
    if (mStepString != nil)
    {
        mStep = [mStepString intValue];
    }
    int outCount=0;
    bool mCheckContainString = false;
    if (mWriteCmd != nil &&  mContainsString != nil)
    {
        mCheckContainString = true;
    }
    
    while (flag)
    {
        if ((inCaseCurrent > 0) && !mCheckContainString)
        {
            mResitorValue = mResitorValue - mStep;
            if (mResitorValue< 0)
            {
                mResitorADRValueStr =@"000";
            }
            else if (mResitorValue<10 && mResitorValue>0)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
            }
            else if (mResitorValue>9 && mResitorValue<100)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
            }
            else if (mResitorValue>99 && mResitorValue<256)
            {
                mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
            }
            else if (mResitorValue>255)
            {
                mResitorADRValueStr =@"255";
            }
        }
        else if ((inCaseCurrent < 0) || mCheckContainString)
        {
            mResitorValue = mResitorValue + mStep;
            if (mResitorValue< 0)
            {
                mResitorADRValueStr =@"000";
            }
            else if (mResitorValue < 10)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
            }
            else if (mResitorValue > 9 && mResitorValue < 100)
            {
                mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
            }
            else if (mResitorValue > 99 && mResitorValue < 256)
            {
                mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
            }
            else if (mResitorValue > 255)
            {
                mResitorADRValueStr =@"255";
            }
            
        }
        
        NSString *mWriteCmdTmp1 = [mWriteCmdTmp stringByAppendingString:@" "];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:mResitorADRValueStr];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:@"\r"];
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp1 :@"*_*"] ;//Send CMD:SDR xxx
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult33 = [self ReceData:dictKeyDefined] ;
        NSLog(@"SDR rec str=%@",dataResult33);
        mWriteCmdTmp1 = @"";
        //      usleep(100000) ; //delay 50ms
        
        
        if (mWriteCmd != nil &&  mContainsString != nil)
        {
            [dictKeyDefined setValue:@"IPad" forKey:@"Device"];
            [dictKeyDefined setValue:@":-)" forKey:@"Postfix"];
            [TestItemParse SendData:dictKeyDefined :mWriteCmd :@":-)"] ;//Send CMD:mWriteCmd (script orion_read_oc) to get egpio pin
            NSDate *dateTmp1=[[[NSDate alloc] init] autorelease] ;
            int iTmp1 = [mTimeOut intValue] ;
            int timeInterval1 = - [dateTmp1 timeIntervalSinceNow] ;
            while (timeInterval1<=iTmp1)
            {
                timeInterval1 = -[dateTmp1 timeIntervalSinceNow] ;
                if ([self CheckReceDataIsComplete:dictKeyDefined])
                    break ;
                else
                {
                    usleep(10000) ; //delay 50ms
                }
            }
            //read data
            NSString *dataResult = [self ReceData:dictKeyDefined] ; //Get egpio pin value
            if (dataResult!=nil )
            {
                if (mContainsString !=nil)
                {
                    if([dataResult rangeOfString:mContainsString].length>0)
                    {
                        
                        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :[TestItemManage getBufferValue:dictKeyDefined :mBufferName]];
                        return;
                    }
                }
            }
            else
            {
                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"no received data"];
                return;
            }
            //        usleep(200000) ; //delay 50ms
        }
        
        
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd2 :@"*_*"] ; //Send CMD :GET ACCxx
        NSLog(@"I have changed the device from %@ to Ipad!",[dictKeyDefined valueForKey:@"Device"]);
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult1 = [self ReceData:dictKeyDefined] ;
        if (dataResult1!=nil )
        {
            NSString *mResitorValueTempStr =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@" " withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            
            if (mResitorValueTempStr !=nil)
            {
                mTmpCurr2 = mResitorValueTempStr;
                if ((inCaseCurrent < 0) && !mCheckContainString)
                {
                    if (([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue] ) >=0 )
                    {
                        if (([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue]) <= 10)
                        {
                            if (mLowLimit != nil && mUpLimit != nil)
                            {
                                if ( ([mTmpCurr2 intValue] >= [mLowLimit intValue]) && ([mTmpCurr2 intValue] <= [mUpLimit intValue]))
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                                }
                            }
                            if (mLowLimit == nil && mUpLimit != nil )
                            {
                                if ([mTmpCurr2 intValue] <= [mUpLimit intValue])
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                                }
                            }
                            if (mLowLimit != nil && mUpLimit == nil )
                            {
                                if ([mTmpCurr2 intValue] >= [mLowLimit intValue])
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                                }
                            }
                            if (mLowLimit == nil && mUpLimit == nil)
                            {
                                
                                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2];
                            }
                        }
                        else
                        {
                            [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr2] ;
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr2];
                            
                        }
                        return;
                    }
                }
                else if ((inCaseCurrent > 0 ) && !mCheckContainString)
                {
                    if([mTmpCurr2 intValue] - [mADRSetCurrentValueStr intValue]<0)
                    {
                        if ((([mTmpCurr1 intValue] - [mADRSetCurrentValueStr intValue]) >= 0) && (([mTmpCurr1 intValue] - [mADRSetCurrentValueStr intValue]) <=10))
                        {
                            if (mLowLimit != nil && mUpLimit != nil)
                            {
                                if ( ([mTmpCurr1 intValue] >= [mLowLimit intValue]) && ([mTmpCurr1 intValue] <= [mUpLimit intValue]))
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                }
                            }
                            if ((mLowLimit == nil) && (mUpLimit != nil))
                            {
                                if ([mTmpCurr1 intValue] <= [mUpLimit intValue])
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                }
                            }
                            if ((mLowLimit != nil) && (mUpLimit == nil))
                            {
                                if ([mTmpCurr1 intValue] >= [mUpLimit intValue])
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                                }
                                else
                                {
                                    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1];
                                }
                            }
                            if ((mLowLimit == nil) && (mUpLimit == nil))
                            {
                                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1] ;
                                [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr1];
                            }
                            
                            mResitorValue = mResitorValue + mStep; //if pass ,than set current value back
                            if (mResitorValue < 0)
                            {
                                mResitorADRValueStr = @"000" ;
                            }
                            else if (mResitorValue < 10)
                            {
                                mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
                            }
                            else if (mResitorValue > 9 && mResitorValue < 100)
                            {
                                mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
                            }
                            else if (mResitorValue > 99 && mResitorValue < 256)
                            {
                                mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
                            }
                            else if (mResitorValue > 255)
                            {
                                mResitorValue = @"255";
                            }
                            NSString *mWriteCmdTmp3 = [mWriteCmdTmp stringByAppendingString:@" "];
                            mWriteCmdTmp3 = [mWriteCmdTmp3 stringByAppendingString:mResitorADRValueStr];
                            mWriteCmdTmp3 = [mWriteCmdTmp3 stringByAppendingString:@"\r"];
                            
                            NSLog(@"WriteCmdTmp is %@",mWriteCmdTmp3);
                            
                            [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
                            [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
                            [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp3 :@"*_*"] ;//Send CMD:SDR xxx
                            NSLog(@"I have changed the device from %@ to Ipad!",[dictKeyDefined valueForKey:@"Device"]);
                            
                            NSDate *dateTmp3=[[[NSDate alloc] init] autorelease] ;
                            int iTmp3 = [mTimeOut intValue] ;
                            int timeInterval3 = - [dateTmp3 timeIntervalSinceNow] ;
                            while (timeInterval3<=iTmp3)
                            {
                                timeInterval3 = -[dateTmp3 timeIntervalSinceNow] ;
                                if ([self CheckReceDataIsComplete:dictKeyDefined])
                                    break ;
                                else
                                {
                                    usleep(10000) ; //delay 50ms
                                }
                            }
                            
                            NSString *dataResult123 = [self ReceData:dictKeyDefined] ;
                            NSLog(@"SDR rec str=%@",dataResult123);
                            mWriteCmdTmp3 = @"";
                            return;
                        }
                        else
                        {
                            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mTmpCurr1 ];
                        }
                    }
                }
                mTmpCurr1 = mTmpCurr2 ;
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1 ];
                
            }
        }
        
        outCount++;
        if (outCount > 50)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Loop test over 50x!"];
            NSLog(@"loop test over 50x");
            return;
        }
        
    }
    
}
//justin add end
*/
//Modified by Annie 2015.3.26 RXa P0
//Modified by Annie 2015.3.26 RXa P0
+(void)GetTargetSettingCurrentForHigh:(NSDictionary*)dictKeyDefined
{
    NSString *mTestItemName = nil;
    NSString *mReferenceBufferName = nil;
    NSString *mReferenceBufferNameOfACC = nil;
    NSString *mBufferName = nil;
    NSString *mWriteCmd = nil;
    NSString *mWriteCmd2 = nil;
    NSString *mWriteCmdTmp = nil;
    NSString *mDevice = nil;
    NSString *mTimeOut = @"6";
    NSString *mADRPrefix = nil;
    NSString *mADRPostfix = nil;
    NSString *mACCPrefix = nil;
    NSString *mACCPostfix = nil;
    NSString *mContainsString = nil;
    NSString *mCurrentValuePostfix = nil;
    NSString *mCurrentValuePrefix = nil;
    NSString *mTmpCurr1 = nil;
    NSString *mTmpCurr2 = nil;
    NSString *mUpLimit = nil;
    NSString *mLowLimit = nil;
    NSString *mStepString = nil;
    int mStep = 1 ;
    
    
    
    bool flag = true;
    //  bool isFirst = true;
    
    for(int i=0 ;i<[dictKeyDefined count] ;i++)
    {
        NSString* strKey=[[dictKeyDefined allKeys] objectAtIndex:i] ;
        if ([strKey isEqualToString:@"TestItemName"])
        {
            mTestItemName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"Device"])
        {
            mDevice = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCmd"])
        {
            mWriteCmd = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCmd2"])
        {
            mWriteCmd2 = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"WriteCmdTemp"])
        {
            mWriteCmdTmp = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferName"])
        {
            mReferenceBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ReferenceBufferNameOfACC"])
        {
            mReferenceBufferNameOfACC = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"BufferName"])
        {
            mBufferName = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"TimeOut"])
        {
            mTimeOut = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ContainsString"])
        {
            mContainsString = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ADRPrefix"])
        {
            mADRPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ADRPostfix"])
        {
            mADRPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ACCPrefix"])
        {
            mACCPrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"ACCPostfix"])
        {
            mACCPostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"CurrentValuePrefix"])
        {
            mCurrentValuePrefix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"CurrentValuePostfix"])
        {
            mCurrentValuePostfix = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"LowerValue"])
        {
            mLowLimit = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"UpperValue"])
        {
            mUpLimit = [dictKeyDefined objectForKey:strKey] ;
        }
        else if ([strKey isEqualToString:@"StepValue"])
        {
            mStepString = [dictKeyDefined objectForKey:strKey] ;
        }
    }
    
    if (mBufferName == nil || mReferenceBufferName == nil || mReferenceBufferNameOfACC == nil )
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Script Occur Error"] ;
        return  ;
        
    }
    //  NSString *strmReferenceBufferValueTmp=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    
    NSString *strTmpValue=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferName];
    //Annie debug
    //strTmpValue=@"[2015-03-25 10:26:02:423]:receive: ADR 0500 Current set:500 Digital Resistor set value:85 Digital Resistor ADC1:482mV *_* E-Loader voltage:492mV*_*";
    //Annie debug
    NSString *mResitorADRValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mADRPrefix Postfix:mADRPostfix];
    //mResitorADRValueStr=85
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorADRValueStr = [mResitorADRValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if ([mResitorADRValueStr intValue]>=255)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SDR over 255"];
        return;
    }
    
    //get the set current value (CMD:ADR xxxxx)
    NSString *mADRSetCurrentValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValue Prefix:mCurrentValuePrefix Postfix:mCurrentValuePostfix];
    //mADRSetCurrentValueStr=500
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mADRSetCurrentValueStr = [mADRSetCurrentValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    if (mADRSetCurrentValueStr == nil || (![ToolFun isNumber: mADRSetCurrentValueStr]))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Set a error current!"] ;
        return  ;
    }
    
    //read the reality current value from ACC
    NSString *strTmpValueGetACC=[TestItemManage getBufferValue:dictKeyDefined :mReferenceBufferNameOfACC]; //ACC value
    //Annie debug
    //strTmpValueGetACC=@"ACC2 Voltage:486mV";
    //Annie debug
    NSString *mResitorValueStr =  [ToolFun getStrFromPrefixAndPostfix:strTmpValueGetACC Prefix:mACCPrefix Postfix:mACCPostfix];
    //mResitorValueStr=486
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    mResitorValueStr = [mResitorValueStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mResitorValueStr] ;
    //mBufferName=486
    if(((mLowLimit==nil||[mLowLimit length]<=0)?1:([mResitorValueStr doubleValue] >=[mLowLimit doubleValue]))
       && ((mUpLimit==nil||[mUpLimit length]<=0)?1:([mResitorValueStr doubleValue]<=[mUpLimit doubleValue])))
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mResitorValueStr] ;
        return  ;
        
    }
    
    //if (strTmpValue == nil || strTmpValueGetACC==nil)
    if (mResitorADRValueStr==nil)
    {
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Orion ACC trigger value is null."] ;
        return;
    }
    if (![ToolFun isNumber: mResitorADRValueStr])
    {
        NSString *mfailmsg = [@"ADR value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    if (mResitorADRValueStr.length > 3 )
    {
        NSString *mfailmsg = [@"Acc value out of 255 : " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];
        return;
    }
    
    if (![ToolFun isNumber: mResitorValueStr])
    {
        NSLog(@"mResitorValueStr is %@",mResitorValueStr);
        NSString *mfailmsg = [@"ACC value is not a number: " stringByAppendingString: mResitorADRValueStr];
        [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :mfailmsg];//@"Get OrionACC Trigger Value Error"] ;
        return;
    }
    
    int inCaseCurrent = [mResitorValueStr intValue] - [mADRSetCurrentValueStr intValue];
    //inCaseCurrent=486-500=-14
    //-------------------------mResitorValue = [mResitorADRValueStr intValue]------------------------------
    int mResitorValue = [mResitorADRValueStr intValue];// init next ADR value : mResitorADRValueStr + 1
    //mResitorValue=486
    /*
     if (mWriteCmd == nil && mContainsString == nil)//ContainsString=USB OC: true ||==Read from pin 3: 0 ||=nil
     {
     if (inCaseCurrent == 0)
     {
     
     [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mResitorValueStr];
     return;
     }
     
     }
     */
    mTmpCurr1 = mResitorValueStr ;//the first get acc value
    //mTmpCurr1=486
    if (mStepString != nil)
    {
        mStep = [mStepString intValue];
    }
    int outCount=0;
    bool mCheckContainString = false;
    if (mWriteCmd != nil &&  mContainsString != nil)
    {
        mCheckContainString = true;
    }
    
    while (flag)
    {
        if ((inCaseCurrent > 0) && !mCheckContainString)
        {
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Please check fixture"];
            return;
        }
        //-----------------Send SDR xx to Fixture for setting resitor value ---------------
        mResitorValue = mResitorValue + mStep;
        if (mResitorValue< 0)
        {
            mResitorADRValueStr =@"000";
        }
        else if (mResitorValue < 10)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"00%d",mResitorValue];
        }
        else if (mResitorValue > 9 && mResitorValue < 100)
        {
            mResitorADRValueStr = [NSString stringWithFormat:@"0%d",mResitorValue];
        }
        else if (mResitorValue > 99 && mResitorValue < 256)
        {
            mResitorADRValueStr = [NSString  stringWithFormat:@"%d",mResitorValue];
        }
        else if (mResitorValue > 255)
        {
            mResitorADRValueStr =@"255";
        }
        
        NSString *mWriteCmdTmp1 = [mWriteCmdTmp stringByAppendingString:@" "];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:mResitorADRValueStr];
        mWriteCmdTmp1 = [mWriteCmdTmp1 stringByAppendingString:@"\r"];
        
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmdTmp1 :@"*_*"] ;//Send CMD:SDR xxx
        
        NSDate *dateTmp=[[[NSDate alloc] init] autorelease] ;
        int iTmp = [mTimeOut intValue] ;
        int timeInterval = - [dateTmp timeIntervalSinceNow] ;
        while (timeInterval<=iTmp)
        {
            timeInterval = -[dateTmp timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult33 = [self ReceData:dictKeyDefined] ;
        NSLog(@"SDR rec str=%@",dataResult33);
        mWriteCmdTmp1 = @"";
        
        //-----------------Send get ACCx to get measured value  -----------------------
        [dictKeyDefined setValue:@"Fixture" forKey:@"Device"];
        [dictKeyDefined setValue:@"*_*" forKey:@"Postfix"];
        [TestItemParse SendData:dictKeyDefined :mWriteCmd2 :@"*_*"] ; //Send CMD :GET ACCxx
        NSLog(@"I have changed the device from %@ to Ipad!",[dictKeyDefined valueForKey:@"Device"]);
        
        NSDate *dateTmp2=[[[NSDate alloc] init] autorelease] ;
        int iTmp2 = [mTimeOut intValue] ;
        int timeInterval2 = - [dateTmp2 timeIntervalSinceNow] ;
        while (timeInterval2<=iTmp2)
        {
            timeInterval2 = -[dateTmp2 timeIntervalSinceNow] ;
            if ([self CheckReceDataIsComplete:dictKeyDefined])
                break ;
            else
            {
                usleep(10000) ; //delay 50ms
            }
        }
        
        NSString *dataResult1 = [self ReceData:dictKeyDefined] ;
        //Annie debug
        //dataResult1=@"ACC2 Voltage:488mV";
        //Annie debug
        if (dataResult1!=nil )
        {
            NSString *mResitorValueTempStr =  [ToolFun getStrFromPrefixAndPostfix:dataResult1 Prefix:mACCPrefix Postfix:mACCPostfix];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@" " withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            mResitorValueTempStr = [mResitorValueTempStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            
            //--------------Judge if the result value in spec-----------------------
            if (mResitorValueTempStr !=nil)
            {
                mTmpCurr2 = mResitorValueTempStr;
                if(((mLowLimit==nil||[mLowLimit length]<=0)?1:([mTmpCurr2 doubleValue] >=[mLowLimit doubleValue]))
                   && ((mUpLimit==nil||[mUpLimit length]<=0)?1:([mTmpCurr2 doubleValue]<=[mUpLimit doubleValue])))
                {
                    [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_PASS :mTmpCurr2] ;
                    return  ;
                    
                }
                mTmpCurr1 = mTmpCurr2 ;
                [TestItemManage setBufferValue:dictKeyDefined :mBufferName :mTmpCurr1 ];
            }
        }
        //outCount++;
        //if (outCount > 50) //modified bya Annie 2015.3.25
        if ([mResitorADRValueStr intValue]>=255)
        {
            //[TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"Loop test over 50x!"];
            [TestItemParse SetResultAndUIInfo:dictKeyDefined :RESULT_FOR_FAIL :@"SDR Value arrived 255!"];
            NSLog(@"SDR Value arrived 255!");
            return;
        }
    }
    
}
@end
