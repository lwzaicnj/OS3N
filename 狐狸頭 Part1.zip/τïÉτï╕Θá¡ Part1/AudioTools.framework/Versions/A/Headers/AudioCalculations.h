#ifndef mpetit__clf2__audio_calculations__hh__
#define mpetit__clf2__audio_calculations__hh__


#include <vector>


struct FTKMap;


double loudness_rating(std::vector<double> const &mag, double nyquist, /*FTKArray corrections,*/ FTKMap itu_spec, bool outgoing);

double vrms(std::vector<float> const &wave);
double vrms(std::vector<double> const &wave);

std::vector<double> FFT_to_dB(std::vector<double> const &);
std::vector<double> FFT_to_Deg(std::vector<double> const &fft_phase);

#endif
