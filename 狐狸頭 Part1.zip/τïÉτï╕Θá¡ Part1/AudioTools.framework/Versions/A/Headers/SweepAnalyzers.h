#ifndef mpetit__audio_tools__sweep_analyzers__hh__
#define mpetit__audio_tools__sweep_analyzers__hh__


#include <vector>
#include <AudioTools/SweepGenerators.h>


int
analyzeSweep(
			 std::vector<float> const &unwindowedWave,
			 std::vector<float> const &unwindowedWave2,
			 double                   unitConvFactor,
			 std::vector<double>      correction,
			 double                   THDfreq,
			 double                   RBfreq,
			 int                      spacingOfPointsToReturn,
			 std::vector<double>     &freqRet,
			 std::vector<double>     &magRet,
			 double                  *THD_per,
			 double                  *RB_per,
			 double                  *RLR,
			 double                  *SLR,
			 char const              *testName,
			 char const              *ProductName,
			 sweep_gen_data_t const  *sweep_def
);



/*
 * Harmonic behaviour of a chirp...
 *
 * * harmonic_response_t   -- energy tranferred to Nth Harmonic
 *                            vs frequency
 * * harmonic_behaviour_t  -- collection of all
 *                            harmonic_response_t curves
 * * harmonic_distortion_t -- percentage of distortions vs
 *                            frequency
 *
 * NOTE: all functions below need to be renamed to chir_*
 *
 */
typedef std::vector<double> harmonic_response_t;
typedef std::vector<double> harmonic_distortion_t;
typedef std::vector<double>	total_distortion_t;
typedef struct {
	harmonic_response_t mag;
	harmonic_response_t phase;
} harmonic_response_complex_t;

typedef std::vector<harmonic_response_complex_t> harmonic_behavior_t;


typedef struct {
    harmonic_response_t mag;
    harmonic_response_t phase;
} frequency_response_t;


void                  harmonic_behavior(harmonic_behavior_t &hb, std::vector<float> const &wave, std::vector<float> const &ref, unsigned num_harmonics, sweep_gen_data_t const *sweep_def);
harmonic_behavior_t   harmonic_behavior(                         std::vector<float> const &wave, std::vector<float> const &ref, unsigned num_harmonics, sweep_gen_data_t const *sweep_def);

void                  harmonic_behavior(harmonic_behavior_t &hb, std::vector<float> const &wave, unsigned num_harmonics, sweep_gen_data_t const *sweep_def);
harmonic_behavior_t   harmonic_behavior(                         std::vector<float> const &wave, unsigned num_harmonics, sweep_gen_data_t const *sweep_def);

void                  frequency_response(frequency_response_t &fr, std::vector<float> const &wave, std::vector<float> const &ref, sweep_gen_data_t const *sweep_def);
frequency_response_t  frequency_response(                          std::vector<float> const &wave, std::vector<float> const &ref, sweep_gen_data_t const *sweep_def);

void				  frequency_response(frequency_response_t &fr, std::vector<float> const &wave, sweep_gen_data_t const *sweep_def);
frequency_response_t  frequency_response(						   std::vector<float> const &wave, sweep_gen_data_t const *sweep_def);


enum
{
	DISTORTION_MODE__IEEE,    /* (total distortion power) / (fundamental power) */
	DISTORTION_MODE__IEC,     /* (total distortion power) / (signal power)      */

	/*
	 * TEMME mode is included to please all the SoundCheck fangirls.
	 * It is exactly the same as the so-called "Normalized THD",
	 * which is just a fancy name for:
	 *
	 *    Imagined distortion, measured in Karats of pixie dust.
     *
     */
	DISTORTION_MODE__TEMME,   /* imagined distortion */
};

void                  harmonic_distortion(harmonic_distortion_t &hd, harmonic_behavior_t const &hb, unsigned low_h, unsigned high_h, unsigned mode = DISTORTION_MODE__IEEE);
harmonic_distortion_t harmonic_distortion(                           harmonic_behavior_t const &hb, unsigned low_h, unsigned high_h, unsigned mode = DISTORTION_MODE__IEEE);

void                  total_distortion(total_distortion_t &td, harmonic_behavior_t const &hb, unsigned low_h, unsigned high_h);
total_distortion_t    total_distortion(                        harmonic_behavior_t const &hb, unsigned low_h, unsigned high_h);


#endif