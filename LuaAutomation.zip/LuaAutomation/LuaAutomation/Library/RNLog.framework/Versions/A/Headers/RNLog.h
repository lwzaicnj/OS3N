//
//  RNLog.h
//  Redneck
//
//  Created by Manuel Petit on 3/6/12.
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif


#include <stdarg.h>


enum
{
	RNLOG_ASYNC = 0x10000000,

	RNLOG_WOG = -RNLOG_ASYNC*2,
	RNLOG_ERROR =  0,
	RNLOG_WARNING,
	RNLOG_NOTICE,
	RNLOG_BABBLE,
};

NSString *RNLog  (NSString *fmt, ...) NS_FORMAT_FUNCTION(1,2);
NSString *RNLogXL(int lvl, NSString *fmt, ...) NS_FORMAT_FUNCTION(2,3);
NSString *RNLogV (int lvl, NSString *fmt, va_list va);

/*
 * Async versions of the above
 */
NSString *RNLogA  (NSString *fmt, ...) NS_FORMAT_FUNCTION(1,2);
NSString *RNLogXLA(int lvl, NSString *fmt, ...) NS_FORMAT_FUNCTION(2,3);
NSString *RNLogVA (int lvl, NSString *fmt, va_list va);
 
 
void      RNLogConfig(NSString *prefix, long max);

#ifdef __cplusplus
}
#endif


/*
 * XXX : mpetit : just a convenience overload for lazy old dogs
 */
#ifdef __cplusplus
NSString *RNLog  (int lvl, NSString *fmt, ...) NS_FORMAT_FUNCTION(2,3);
NSString *RNLogA (int lvl, NSString *fmt, ...) NS_FORMAT_FUNCTION(2,3);
#endif

