//
//  LuaAutomation.h
//  LuaAutomation
//
//  Created by admin on 10/14/16.
//  Copyright © 2016 foxconn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppleTestStationAutomation/AppleControlledStation.h>
#import <AppleTestStationAutomation/AppleControlledStationDelegate.h>
#import <AppleTestStationAutomation/AppleTestStationAutomation.h>
#import <AppleTestStationAutomation/HWTEControlledStation.h>
#import <AppleTestStationAutomation/TestStationKeys.h>
#import <eTraveler/eTraveler.h>

#ifdef __cplusplus
extern "C" {
#endif
    
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
    
#define LUA_AUTOMATION_LIBNAME	"automation"
LUAMOD_API int luaopen_automation(lua_State *L);
    
#ifdef __cplusplus
}
#endif

/********************************************************************************/
@interface LuaAutomation : NSObject<AppleControlledStationDelegate>

- (BOOL)station:(AppleControlledStation *)station startWithTravelers:(NSArray *)travelers;
- (BOOL)station:(AppleControlledStation *)station abortWithOptions:(NSDictionary *)options;
- (BOOL)station:(AppleControlledStation *)station query:(NSDictionary *)query;

@end
/********************************************************************************/






