//
//  main.m
//  OS3N_OC
//
//  Created by apple on 2/20/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <dirent.h>
#import <string.h>
#import "BojayMCU.h"

int searchPort(char *port){
    
    struct dirent *dirent;
    DIR *dir = opendir("/dev/");
    
    //    char *devicePath = NULL ; //空字符
    while ((dirent=readdir(dir)) != NULL) {
        char rootPath[60] = "/dev/"; //數組類型才可以來 strcat
        if (strcmp(strcat(rootPath,dirent->d_name),port) == 0) {
            
            printf("The fixture port found! ");
            
            return 0;
        }
    }
    
    return -1;
}

int write_then_readFor_OK(char *cmd ,int timeout){
    
    printf("The timeout is %d\n",timeout);
    
    int ret = -1;
    
    if (timeout == -1) timeout = TIMEOUT;
    ret = MCUWriteForuSeconds(cmd, timeout);
    
    printf("write command : %s\n",cmd);
    
    char *temp;
    switch (ret) {
        case 0:
            temp = "read : ok\n";
            break;
        case -1:
            temp = "read failed\n";
            break;
        case -2:
            temp = "write command failed\n";
            break;
        case -3:
            temp = "invalid command\n";
            break;
        case -4:
            temp = "read timeout\n";
            break;
        default:
            break;
    }
    printf("%s\n",temp);
    return ret;
}


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        if (argc < 2) {
            printf("usage: OS3N <command>\n");
            printf("where <command> if one of:\n");
            printf("\tintitalize       -initialize the fixture!\n");
            printf("\t......\n");
            return 1;
        }
        
//        NSString *arg = [[[NSProcessInfo processInfo] arguments] objectAtIndex:1];
        
        char *arg = (char *)argv[1];
        
        NSString *oArg = [NSString stringWithCString:arg encoding:NSUTF8StringEncoding];
        
        char *defaultPort = "/dev/cu.usb";
        
        if (searchPort(defaultPort)) {
            printf("Can't find the port!\n");
            
//            return 2;
        }
        
        int ret =  MCUOpen(defaultPort);
        
        if (ret == 0) {
            printf("Conncet the fixture succussful!");
        }
        
        //還是列出了對應命令和是否需要 timeout以及 timeout 多少比較好，這裡寫死了
        //最好用 oc，有字典和塊
//        write_then_readFor_OK(arg,-1);
        
        int (^selectedCommand)() = @{
            
                @"FANS ON" :^{ return TIMEOUT ;},
                @"FANS OFF" :^{ return TIMEOUT ;},
                @"CPC_ROTATE_ORIGINAL" : ^{return TIMEOUT ;},
                
                
        }[oArg];
        
        
        if (!selectedCommand) {
            printf("The command invalid!");
        }
         write_then_readFor_OK(arg,selectedCommand());
        
        return 0;
    }
    return 0;
}
