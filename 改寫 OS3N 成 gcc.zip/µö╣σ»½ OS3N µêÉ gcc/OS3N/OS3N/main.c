//
//  main.c
//  OS3N
//
//  Created by apple on 2/20/17.
//  Copyright © 2017 apple. All rights reserved.
//

#include <stdio.h>
#include "BojayMCU.h"
#include <dirent.h>
#include <string.h>


int searchPort(char *port){
    
    struct dirent *dirent;
    DIR *dir = opendir("/dev/");
    
//    char *devicePath = NULL ; //空字符
    while ((dirent=readdir(dir)) != NULL) {
        char rootPath[60] = "/dev/"; //數組類型才可以來 strcat
        if (strcmp(strcat(rootPath,dirent->d_name),port) == 0) {
            
            printf("The fixture port found! ");
            
            return 0;
        }
    }
    
    return -1;
}

int write_then_readFor_OK(char *cmd ,int timeout){
    
    int ret = -1;

    if (timeout == -1) timeout = TIMEOUT;
        ret = MCUWriteForuSeconds(cmd, timeout);
    
    printf("write command : %s\n",cmd);
    
    char *temp;
    switch (ret) {
        case 0:
            temp = "read : ok\n";
            break;
        case -1:
            temp = "read failed\n";
            break;
        case -2:
            temp = "write command failed\n";
            break;
        case -3:
            temp = "invalid command\n";
            break;
        case -4:
            temp = "read timeout\n";
            break;
        default:
            break;
    }
    printf("%s\n",temp);
    return ret;
}

int main(int argc, const char * argv[]) {
    
    if (argc < 2) {
        printf("usage: OS3N <command>\n");
        printf("where <command> if one of:\n");
        printf("\tintitalize       -initialize the fixture!\n");
        printf("\t......\n");
        return 1;
    }
    
    char *arg = (char *)argv[1];
    
    char *defaultPort = "/dev/cu.usb";
   
    if (searchPort(defaultPort)) {
        printf("Can't find the port!\n");
        
        return 2;
    }
    
    int ret =  MCUOpen(defaultPort);
    
    if (ret == 0) {
        printf("Conncet the fixture succussful!");
    }
    
    //還是列出了對應命令和是否需要 timeout以及 timeout 多少比較好，這裡寫死了
    //最好用 oc，有字典和塊
    write_then_readFor_OK(arg,-1);
    
    
    return 0;
}





























