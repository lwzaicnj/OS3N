//
//  main.m
//  多線程測試
//
//  Created by apple on 2/16/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <string.h>

void func (char arry[100]){
    printf("%lu\n",sizeof(arry));
}

void getmemory(char *p){
    p = (char *)malloc(100);
    printf("%lu\n",sizeof(p));
}
void test(void){
    char *str = NULL;
    getmemory(str);
//    strcpy(str, "hello world");//程序崩潰，因為 str 沒有分配內存
    printf("%s\n",str);
}

int main(int argc, const char * argv[]) {
    
    char string[] = "Foxconns";
    char *p = string;
    printf("%lu",sizeof(string));
    printf("%lu",sizeof(p));
    func("QTdsddddddddddddd");
    
    int  i = 0,sum;
    for(; i<5; ++i) {
        printf("%d\n",i);
        sum += i;}
    printf("%d\n",sum);
    
    test();
    
    char *str = "Diagffffff";
//    str[0] = 0; //定义了一个char型的指针，它只知道所指向的内存单元，并不知道这个内存单元有多大
    printf("%ld\n",sizeof(str));//計算一個字符指針的字節數，這裡是8
    
    printf("%lu\n",sizeof(char));
    
    int a[10] = {1,2,3,4,5,6,7,8,9};
//    printf("%ld\n",&a);
    int *p1 = (int *)(&a+1);//  &a 到數組最後  a[10]的地址 +1就是下一個地址
    printf("is %d\n",*(p1-3));
    
    printf("%d\n",sizeof(float *));
    
    int x =3,y = 5;
    int z = ++x||++y;
    printf("z %d\n",y);
    
    return NSApplicationMain(argc, argv);
}
