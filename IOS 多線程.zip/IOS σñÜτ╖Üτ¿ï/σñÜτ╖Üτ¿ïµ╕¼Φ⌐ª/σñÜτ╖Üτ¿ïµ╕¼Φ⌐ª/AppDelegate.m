//
//  AppDelegate.m
//  多線程測試
//
//  Created by apple on 2/16/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
    [_time setIntValue:100];
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    
    return YES;
}

- (IBAction)test:(id)sender {
    
//    NSThread *thread = [[NSThread alloc]initWithTarget:self selector:@selector(run:) object:nil];
//    
//    [thread start];
//*********************************************************************************************//
//    //1.创建NSBlockOperation对象
//    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
//        for (NSInteger i = 0; i < 5; i++){
//            NSLog(@"第 %ld 次 %@",i, [NSThread currentThread]);//串行
//        }
//    }];
//    
//    //添加多个Block
//    for (NSInteger i = 0; i < 5; i++) {
//        [operation addExecutionBlock:^{
//            NSLog(@"Add第%ld次：%@", i, [NSThread currentThread]);//並行
//        }];
//    }
//    
//    //2.开始任务
//    [operation start];
//*********************************************************************************************//
    //1.创建一个其他队列
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    //2.创建NSBlockOperation对象
    NSBlockOperation *operation2 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"%@", [NSThread currentThread]);
    }];
    
    //3.添加多个Block
    for (NSInteger i = 0; i < 5; i++) {
        [operation2 addExecutionBlock:^{
            NSLog(@"第%ld次：%@", i, [NSThread currentThread]);
        }];
    }
    
    //2.创建NSBlockOperation对象
    NSBlockOperation *operation3 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"任務2%@", [NSThread currentThread]);
    }];
    
    //3.添加多个Block
    for (NSInteger i = 0; i < 5; i++) {
        [operation3 addExecutionBlock:^{
            NSLog(@"任務2第%ld次：%@", i, [NSThread currentThread]);
        }];
    }
    
    queue.maxConcurrentOperationCount = 1;//會讓每個任務（封裝在NSBlockOperation里）串行執行
    //4.队列添加任务
    [queue addOperation:operation2];
    [queue addOperation:operation3];

    
//*********************************************************************************************//
    
    //1.任务一：下载图片
    NSBlockOperation *operation4 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"下载图片 - %@", [NSThread currentThread]);
        [NSThread sleepForTimeInterval:1.0];
    }];
    
    //2.任务二：打水印
    NSBlockOperation *operation5 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"打水印   - %@", [NSThread currentThread]);
        [NSThread sleepForTimeInterval:1.0];
    }];
    
    //3.任务三：上传图片
    NSBlockOperation *operation6 = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"上传图片 - %@", [NSThread currentThread]);
        [NSThread sleepForTimeInterval:1.0];
    }];
    
    //4.设置依赖
    [operation5 addDependency:operation4];      //任务二依赖任务一
    [operation6 addDependency:operation5];      //任务三依赖任务二
    
    //5.创建队列并加入任务
    NSOperationQueue *queue3 = [[NSOperationQueue alloc] init];
    [queue3 addOperations:@[operation6, operation5, operation4] waitUntilFinished:NO];

//*********************************************************************************************//
//    //1.创建队列组
//    dispatch_group_t group = dispatch_group_create();
//    //2.创建队列
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//    
//    //3.多次使用队列组的方法执行任务, 只有异步方法
//    //3.1.执行3次循环
//    dispatch_group_async(group, queue, ^(){
//        for (NSInteger i = 0; i < 3; i++) {
//            NSLog(@"group-01 - %@", [NSThread currentThread]);
//        }
//    });
//    
//    //3.2.主队列执行8次循环
//    dispatch_group_async(group, dispatch_get_main_queue(), ^{
//        for (NSInteger i = 0; i < 8; i++) {
//            NSLog(@"group-02 - %@", [NSThread currentThread]);
//        }
//    });
//    
//    //3.3.执行5次循环
//    dispatch_group_async(group, queue, ^{
//        for (NSInteger i = 0; i < 5; i++) {
//            NSLog(@"group-03 - %@", [NSThread currentThread]);
//        }
//    });
//    
//    //4.都完成后会自动通知
//    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
//        NSLog(@"完成 - %@", [NSThread currentThread]);
//    });

//*********************************************************************************************//
//    dispatch_queue_t queue = dispatch_queue_create("myQueue", DISPATCH_QUEUE_SERIAL);
//    
//    NSLog(@"之前 - %@", [NSThread currentThread]);
//    
//    dispatch_async(queue, ^(){
//        NSLog(@"sync之前 - %@", [NSThread currentThread]);
//        dispatch_sync(queue, ^(){
//            NSLog(@"sync - %@", [NSThread currentThread]);
//        });
//        NSLog(@"sync之后 - %@", [NSThread currentThread]);
//    });
//    NSLog(@"之后 - %@", [NSThread currentThread]);
    
//*********************************************************************************************//
    //sync 時主線程已經卡死，這時候把任務放在需要主線程執行的 main_queue就會一直阻塞
//    NSLog(@"之前 - %@", [NSThread currentThread]);
//    dispatch_sync(dispatch_get_main_queue(), ^(){
//        NSLog(@"sync - %@", [NSThread currentThread]);
//    });
//    NSLog(@"之后 - %@", [NSThread currentThread]);
    
//*********************************************************************************************//
    dispatch_queue_t queue2 = dispatch_queue_create("aQ", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(queue2, ^(){
        while (1) {
            int times = [_time intValue];
            
            sleep(1);
            times--;
            [_time setIntValue:times];
            
        }
    });
    
    [_btn setEnabled:NO];
}

- (void)run:(int)time{
    
//    if (_time.intValue > time) return;
    
    dispatch_queue_t queue = dispatch_queue_create("aQ", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(queue, ^(){
        while (1) {
          int times = [_time intValue];
        
            sleep(1);
          times--;
          [_time setIntValue:times];
            
        }
    });
    
    [_btn setEnabled:NO];
}


@end
