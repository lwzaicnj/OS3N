//
//  AppDelegate.h
//  多線程測試
//
//  Created by apple on 2/16/17.
//  Copyright © 2017 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

- (IBAction)test:(id)sender;
@property (weak) IBOutlet NSTextField *time;
@property (weak) IBOutlet NSButton *btn;

@end

