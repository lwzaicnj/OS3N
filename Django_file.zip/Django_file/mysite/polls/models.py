#coding=utf-8
from __future__ import unicode_literals

from django.db import models
from django.utils import timezone
from datetime import datetime
import datetime

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def was_published_recently(self):
        now = timezone.now()
        return  now - datetime.timedelta(days=1) <= self.pub_date <= now
    was_published_recently.admin_order_field = 'pub_date'
    was_published_recently.boolean = True
    was_published_recently.short_description = 'Published recently?' #表頭的說明


    def __unicode__(self):
        return self.question_text

class Choice(models.Model):
    #比如你删除某个表的时候后面加这个关键字,会在删除这个表的同时删除和该表有关系的其他对象
    #在數據庫中無法級聯刪除，先設定 SET FOREIGN_KEY_CHECKS = 0;
    question = models.ForeignKey(Question, on_delete=models.CASCADE) #CASCADE:級聯刪除(在 admin 站點上刪除的時候)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __unicode__(self):
        return self.choice_text
