#coding=utf-8
from django.contrib import admin
from .models import Question, Choice

#設定添加 model 的時候同時增加外鍵
class ChoiceInline(admin.TabularInline):#StackedInline
    model = Choice
    extra = 3 #可以新增主鍵的數量

class QuestionAdmin(admin.ModelAdmin):
    # fields = ['pub_date','question_text']
    list_display = ('id','question_text','pub_date','was_published_recently') #顯示列表
    list_filter = ['pub_date'] #過濾參數
    search_fields = ['question_text'] #搜索參數
    fieldsets = [(None,{'fields':['question_text']}),('Date information',{'fields':['pub_date']}),]
    inlines = [ChoiceInline]#添加 本身作為外鍵

class ChoiceAdmin(admin.ModelAdmin):
    list_display = ('id','choice_text','votes')
    fields = ['choice_text','question']

admin.site.register(Question,QuestionAdmin)
admin.site.register(Choice,ChoiceAdmin)
