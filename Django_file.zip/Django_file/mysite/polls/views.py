#coding=utf-8
from django.shortcuts import render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from .models import Question,Choice
from django.shortcuts import render_to_response,get_object_or_404
from django.urls import reverse
from django.template.context_processors import csrf
from django.views import generic
from django.utils import timezone

# def index(request):
#     latest_question_list = Question.objects.order_by('pub_date')[:5]
#     return render_to_response("polls/index.html",{'latest_question_list': latest_question_list})
#
#
# def detail(request,question_id):
#     # try:
#     #     question = Question.objects.get(pk=q_id)
#     # except Question.DoesNotExist:
#     #     raise Http404("Qusetion does not exist")
#     question = get_object_or_404(Question,pk=question_id)
#     return render(request,"polls/detail.html",{'question': question})
#
#
# def results(request, question_id):
#     question = get_object_or_404(Question, pk=question_id)
#     return render(request, 'polls/results.html', {'question': question})

class IndexView(generic.ListView):
    template_name = "polls/index.html"
    context_object_name = 'latest_question_list' #重命名默認的 question_list
    #传递给html 模板的对象数组内容 latest_question_list从下面获得
    def get_queryset(self):
        return Question.objects.filter(pub_date__lte=timezone.now()).order_by('-pub_date')[:5]

class DetailView(generic.DetailView):
    #根據 pk變量 自動提供 question 變量，因為利用了 Question model 上面是用傳過來的question_id 獲取
    model = Question
    #默认情况下，DetailView泛型视图使用一个称作<app name>/<model name>_detail.html的模板 polls/question_detail.html
    #這里重寫模板名稱
    template_name = 'polls/detail.html'
    def get_queryset(self):
        return Question.objects.filter(pub_date__lte=timezone.now())

class ResultsView(generic.DetailView):
    model = Question
    template_name = 'polls/results.html'


def vote(request, question_id): # detail--> detail.html---> form 裡面傳到url,-->vote 函數
    question = get_object_or_404(Question,pk=question_id)
    try:
        #<input type="radio" name="choice" id="choice{{forloop.counter}}" value="{{choice.id}}"/>
        # input 標籤的 name=value(即 choice={{choice.id}})
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # 发生choice未找到异常时，重新返回表单页面，并给出提示信息
        return render(request,'polls/detail.html',{'question':question,'error_message':"You didn't select a choice."})
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # 成功处理数据后，自动跳转到结果页面，防止用户连续多次提交。
        return HttpResponseRedirect(reverse('polls:results',args=(question.id,)))