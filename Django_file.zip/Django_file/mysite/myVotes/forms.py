#coding=utf-8
from django import forms
# from django.contrib.auth.models import User
from bootstrap_toolkit.widgets import BootstrapDateInput, BootstrapTextInput, BootstrapUneditableInput

#登錄表單
class LoginForm(forms.Form):
    username = forms.CharField(
        required=True, #必須輸入
        label=u"用戶名",
        error_messages={'required':u"請輸入用戶名"},
        widget=forms.TextInput(
            attrs={
                'placeholder':u"用戶名",
                'class':'special',
                'style':'width:180px;',
            }
        ),
    )

    password = forms.CharField(

        required=True,
        label=u'密碼',
        error_messages={'required':u"請輸入密碼"},
        widget=forms.PasswordInput(
            attrs={
                'placeholder':u"密碼",
                'class':'password',
            }
        ),
    )

    class Media:
        css = {
            'all':('style/mystyle.css',)
        }

    def clean(self):
        if not self.is_valid(): #表單無效
            raise forms.ValidationError(u"用戶名和密碼必須填寫")
        else: #登錄成功才可以有 cleaned_data屬性，get的時候沒有，表單驗證還沒通過
            cleaned_data = super(LoginForm,self).clean()
        return cleaned_data

#修改密碼表單
class ChangepwdForm(forms.Form):
    oldpassword = forms.CharField(
        required=True,
        label=u"原密碼",
        error_messages={'required':u"請輸入原密碼"},
        widget=forms.PasswordInput(
            attrs={'placeholder':u"原密碼"}
        ),
    )

    newpassword1 = forms.CharField(
        required=True,
        label=u"新密碼",
        error_messages={'required':u"請輸入新密碼"},
        widget=forms.PasswordInput(
            attrs={'placeholder':u"新密碼"}
        ),
    )

    newpassword2 = forms.CharField(
        required=True,
        label=u"新密碼",
        error_messages={'required': u"請再次輸入新密碼"},
        widget=forms.PasswordInput(
            attrs={
                'placeholder': u"確認密碼",
                # 'style':'margin:10px 0px 10px 500px;',
            }
        ),
    )

    class Media:
        css = {
            'all':('style/change.css',)
        }

    def clean(self):
        if not self.is_valid():
            raise forms.ValidationError(u"All the item need to input")
        elif self.cleaned_data['newpassword1'] <> self.cleaned_data['newpassword2']:
            raise forms.ValidationError(u"兩次輸入的新密碼不一致")
        else:
            clean_data = super(ChangepwdForm,self).clean()
        return clean_data


# class CommentForm(forms.Form):
#     name = forms.CharField(widget=forms.TextInput(attrs={'class': 'special'}))
#     url = forms.URLField()
#     comment = forms.CharField(widget=forms.TextInput(attrs={'size': '40'}))
#
#
# import django
# django.setup()
# f = CommentForm(auto_id=False)
# print f.as_table()
#
#
# g = LoginForm()
# print g.as_table()


#css
# class CalendarWidget(forms.TextInput):
#      class Media:
#          css = {
#              'all': ('pretty.css',)
#          }
#          js = ('animations.js', 'actions.js')
#
#
# class ContactForm(forms.Form):
#     date = forms.DateField(widget=CalendarWidget)
#     name = forms.CharField(max_length=40, widget=CalendarWidget)
#
#
# x = ContactForm()
#
# print x.media
"""
<link href="/static/pretty.css" type="text/css" media="all" rel="stylesheet" />
<script type="text/javascript" src="/static/animations.js"></script>
<script type="text/javascript" src="/static/actions.js"></script>
"""



