#coding=utf-8
from django.shortcuts import render,render_to_response, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib import auth, messages
from django.template.context import RequestContext

from bootstrap_toolkit.widgets import BootstrapUneditableInput
from django.contrib.auth.decorators import login_required

from .models import User, Candidate
from .forms import LoginForm, ChangepwdForm
#實例化上面定義的 form 表單

def login(request):
    if request.method == 'GET':
        form = LoginForm() #默認是get
        # print form.clean()
        # print form.as_table().encode('utf8')
        return render_to_response('myVotes/login.html',{'form':form,})

    else:
        form = LoginForm(request.POST)
        # print form.clean()

        if form.is_valid():
            #通過post 方法獲取表單傳來的 username 和 password
            username = request.POST.get('username','')
            password = request.POST.get('password','')

            #驗證用戶
            user = auth.authenticate(username=username, password=password)
            # 用戶驗證成功
            if user is not None and user.is_active:
                #把用戶加到數據庫
                if not User.objects.filter(name=username):
                    u = User(name=username)
                    u.save()
                get_user = User.objects.get(name=username)
                auth.login(request,user)
                # return render_to_response('myVotes/index.html',{'username':get_user}) #登錄成功的頁面
                return HttpResponseRedirect(reverse('myVotes:index',args=(get_user.id,)))#reverse生成一個可變的url
            else:
                return render_to_response('myVotes/login.html',{'form':form, 'password_is_wrong':True})

        else: #表單無效
            return render_to_response('myVotes/login.html',{'form':form,})


@login_required
def logout(request):
    auth.logout(request)
    return HttpResponseRedirect("/myVotes/login/")#


# 接收POST请求数据
# @login_required
def index(request,user_id):
    # ctx.update(csrf(request)) # csrf(request)构造出{‘csrf_token’: token}
    user = get_object_or_404(User, pk=user_id)
    ctx = {}
    ctx['username'] = user
    if request.POST:
        #增加候選人的時候把他和用戶關聯起來
        ctx['candidate'] = request.POST['q'].encode('utf-8')
        if ctx['candidate']:
            user.candidate_set.create(name=ctx['candidate'])
    return render(request,"myVotes/index.html",ctx)


@login_required
def changepwd(request):
    #一開始進入頁面的時候
    if request.method == 'GET':
        form = ChangepwdForm()
        return render_to_response('myVotes/changepwd.html',{'form':form,})
    else:
        print 'post'
        form = ChangepwdForm(request.POST)
        if form.is_valid():
            username = request.user.username
            oldpassword = request.POST.get('oldpassword','')
            user = auth.authenticate(username=username, password=oldpassword)
            get_user = User.objects.get(name=username)
            print form.clean()#有所有表單鍵值對
            if user is not None and user.is_active:
                newpassword = request.POST.get('newpassword1')
                user.set_password(newpassword) #操作的是表單上的數據(另外一個 auth_user 數據表)，不是你額外的數據庫
                user.save()
                # return render_to_response('myVotes/index.html',{'changepwd_success':True,'username':get_user})
                # return HttpResponseRedirect(reverse('myVotes:index',args=(get_user.id,)))
                return HttpResponseRedirect(reverse('myVotes:login'))
            else:
                return render_to_response('myVotes/changepwd.html',{'form': form,'oldpassword_is_wrong':True,})
        else:
            return render_to_response('myVotes/changepwd.html',{'form':form,})











































