from django.conf.urls import url

from . import views

app_name = 'myVotes'

urlpatterns = [

    url(r'^login/$',views.login,name='login'),
    url(r'^logout/$',views.logout,name='logout'),
    url(r'^index/(?P<user_id>[0-9]+)/$',views.index,name='index'),
    url(r'^changepwd/$',views.changepwd,name='changepwd'),

]