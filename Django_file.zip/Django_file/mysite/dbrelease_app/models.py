#coding=utf-8
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User #auth_user表


class Manager(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField(max_length=50)
    def __unicode__(self):
        return self.first_name + self.last_name

class Dba(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField(max_length=70)
    def __unicode__(self):
        return self.username+'-'+self.last_name + self.first_name


class State(models.Model):
    id = models.AutoField(primary_key=True)
    statename = models.CharField(max_length=30)
    def __unicode__(self):
        return self.statename

class Database(models.Model):
    id = models.AutoField(primary_key=True)
    databasename = models.CharField(max_length=30)
    databaseip = models.CharField(max_length=30)
    def __unicode__(self):
        return self.databasename + '-' + self.databaseip

class Task(models.Model):
    id = models.AutoField(primary_key=True)
    creater = models.ForeignKey(User)
    manager = models.ForeignKey(Manager)
    dba = models.ForeignKey(Dba)
    state = models.ForeignKey(State)
    database = models.ManyToManyField(Database)
    #blank=True:可空
    #null=True:為空時存 NULL
    sql = models.CharField(max_length=2000, blank=True, null=True)
    desc = models.CharField(max_length=2000, blank=True, null=True)
    createdtime = models.DateTimeField()
    lastupdatedtime = models.DateTimeField(blank=True, null=True)
    dbacomment = models.CharField(max_length=2000, blank=True, null=True)
    attachment = models.FileField(upload_to='load/tasks', blank=True, null=True)

    def __unicode__(self):
        return str(self.id)























