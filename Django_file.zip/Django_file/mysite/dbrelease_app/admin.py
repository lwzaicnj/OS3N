from django.contrib import admin
from .models import *


class TaskAdmin(admin.ModelAdmin):
    list_display = ('id','creater','state')


admin.site.register(Manager)
admin.site.register(Dba)
admin.site.register(Database)
admin.site.register(State)
admin.site.register(Task,TaskAdmin)