from __future__ import unicode_literals

from django.apps import AppConfig


class DbreleaseAppConfig(AppConfig):
    name = 'dbrelease_app'
