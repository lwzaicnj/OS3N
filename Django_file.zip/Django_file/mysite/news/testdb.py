#coding:utf-8
from django.http import HttpResponse
from .models import Reporter

def testdb(requst):
	r = Reporter(full_name='Wangzai')
	r.save()
	return HttpResponse("<p>Add data successfully! 添加數據到表 new_reporter</p>")

