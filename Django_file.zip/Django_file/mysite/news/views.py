#coding=utf-8
from django.shortcuts import render,render_to_response
from .models import Article

class Person(object):
	def __init__(self,name,age,sex):
		self.name = name
		self.age = age
		self.sex = sex

	def say(self):
		return "I'm" + self.name

def index(req):
	user = {'name':'tom','age':23,'sex':'male'}
	book_list = ['python','java','php','web']

	return render_to_response('index.html',{'title':'My page','book_list':book_list,'user':user})


def year_archive(request, year):
    a_list = Article.objects.filter(pub_date__year=year)#匹配，輸入的時間和數據庫的匹配
    context = {'year': year, 'article_list': a_list}
    return render(request, 'news/year_archive.html', context)

def month_archive(request, year, month):
	a_list = Article.objects.filter(pub_date__month=month)  # 匹配，輸入的時間和數據庫的匹配
	context = {'year': year, 'month': month, 'article_list': a_list}
	return render(request, 'news/month_archive.html', context)

def article_detail(request, year, month, day):
	a_list = Article.objects.filter(pub_date__day=day)
	context = {'year': year, 'month': month, 'day': day, 'article_list': a_list}
	return render(request, 'news/article_detail.html', context)


	#render 對比 render_to_response：多了 request 參數
 #render第二個是渲染的模板，第三個參數是上下文結構(傳達到模板的變量列表)
 #也可以直接用 Httpresponse(req,template,Context)實現  template = loader.template('index.html') ....