# -*- coding: utf-8 -*-

from django.contrib import admin
from .models import Article,Reporter,Reader


class ArticleInline(admin.TabularInline):
    model = Article

class ReporterAdmin(admin.ModelAdmin): #Reporter 是 Article的外鍵， 這裡兩個類可以讓 Article附在 Reporter編輯頁上
    inlines = [ArticleInline]  # Inline
    list_display = ('full_name','id')
    fieldsets = (
        ['Main',{
            'fields':('full_name',),
        }],
    )


class ArticleAdmin(admin.ModelAdmin):
    list_display = ('pub_date', 'headline','reporter') #增加選擇 修改時的顯示選項
    # 为该列表页增加搜索栏, 外鍵搜索時寫明  "本表外键字段__外键所在表需查询字段 reporter__full_name" 雙下劃線
    search_fields = ('pub_date','headline','reporter__full_name')


admin.site.register(Article, ArticleAdmin)
admin.site.register(Reporter, ReporterAdmin)
admin.site.register(Reader)