from django.conf.urls import url
from . import views,testdb,seach

urlpatterns = [
    url(r'^articles/([0-9]{4})/$', views.year_archive),
    url(r'^$', views.index, name='index'),
    url(r'^testdb/$',testdb.testdb),
    url(r'^search_form/$',seach.search_form),
    url(r'^search/$',seach.search),
    url(r'^search-post/$',seach.search_post),
    url(r'^articles/([0-9]{4})/([0-9]{2})/$', views.month_archive),
    url(r'^articles/([0-9]{4})/([0-9]{2})/([0-9]+)/$', views.article_detail),
]
