#coding:utf-8

from django.http import HttpResponse
from django.shortcuts import  render_to_response, render
from django.template.context_processors import csrf

def search_form(request):
    return render_to_response('search_form.html')

def search(request):
    request.encoding='utf-8'
    if 'g' in request.GET:
        message = '你搜索的內容為： ' + request.GET['g'].encode('utf-8')
    else:
        message = '你提交空白表單'

    return  HttpResponse(message)

#request 參數含當前請求 URL 的信息
# 接收POST请求数据
#用到 csrf 只能用render
def search_post(request):
	ctx ={}
	ctx.update(csrf(request)) # csrf(request)构造出{‘csrf_token’: token}
	if request.POST: # if request.method == 'POST' 才最好的判斷，因為表单form通过HTTP POST方法提交请求，但是表单中可以没有数据，因此，不能使用语句if request.POST来判断是否使用HTTP POST方法
		ctx['xx'] = request.POST['q'].encode('utf-8')
	return render(request, "post.html", ctx)
