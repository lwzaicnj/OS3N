#/usr/bin/env python
#coding=utf-8
from __future__ import unicode_literals

from django.db import models

class Reporter(models.Model):
	full_name = models.CharField(max_length=70)

	def __unicode__(self):
		return self.full_name

class Article(models.Model):
	pub_date = models.DateField()
	headline = models.CharField(max_length=200)
	content = models.TextField()
	#Article 以 Reporter 作外键，每个Reporter可以对应多个Article
	reporter = models.ForeignKey(Reporter, on_delete=models.CASCADE)

	def __unicode__(self):
		return self.headline

class Reader(models.Model):
	id = models.IntegerField(primary_key=True)
	name = models.CharField(max_length=70)
	article = models.ForeignKey(Article,on_delete=models.CASCADE)

	def __unicode__(self):
		return self.name

