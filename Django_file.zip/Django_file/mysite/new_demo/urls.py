#coding=utf-8
from django.conf.urls import url

from . import views
from django.views.generic import TemplateView

app_name = 'new_demo'

urlpatterns = [

    #利用固定的view，傳進模板即可
    url(r'^home/$', TemplateView.as_view(template_name='new_demo/index.html'), name="home"),
    url(r'^contact$', TemplateView.as_view(template_name='new_demo/contact.html'), name="contact"),
    url(r'^form/$',views.demo_form,name='form'),
    url(r'^form_template/$', views.demo_form_with_template,name='template'),
    url(r'^form_inline$', views.demo_form_inline,name="inline"),
    url(r'^formset/$', views.demo_formset, {}, name="formset"),
    url(r'^tabs/$', views.demo_tabs, {}, name="tabs"),
    url(r'^pagination/$', views.demo_pagination, {}, name="pagination"),
    url(r'^widgets/$', views.demo_widgets, {}, name="widgets"),
    url(r'^buttons$', TemplateView.as_view(template_name='new_demo/buttons.html'), name="buttons"),
    url(r'^post/$',views.try_csrf,name="csrf"),
]