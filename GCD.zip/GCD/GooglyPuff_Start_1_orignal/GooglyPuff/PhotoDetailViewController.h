//
//  PhotoDisplayViewController.h
//  GooglyPuff
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoDetailViewController : UIViewController

- (void)setupWithImage:(UIImage *)image;

@end
