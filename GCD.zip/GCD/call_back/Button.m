//
//  Button.m
//  call_back
//
//  Created by apple on 10/15/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "Button.h"

@implementation Button

- (void)click{
    _block(self);
}


@end
