//
//  Button.h
//  call_back
//
//  Created by apple on 10/15/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

//@class Button;

@interface Button : NSObject

typedef void (^ButtonBlock) (Button *);

@property (copy,nonatomic) ButtonBlock block; //copy建立一个索引计数为1的对象，然后释放旧对象  

- (void) click;
@end
