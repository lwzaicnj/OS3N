//
//  main.m
//  call_back
//
//  Created by apple on 10/15/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import "Button.h"

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        Button *btn = [[Button alloc] init];
        btn.block = ^(Button *btn1){
            NSLog(@"Button 被点击了");
        };
        
        [btn click];
        //[btn release];
    }
    return 0;
}
