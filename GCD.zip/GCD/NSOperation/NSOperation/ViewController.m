//
//  ViewController.m
//  NSOperation
//
//  Created by apple on 8/29/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController
@synthesize indicator = _indicator;

static NSOperationQueue *queue;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _indicator = [[UIActivityIndicatorView alloc]init];
    
    _indicator.frame = CGRectMake(120, 120, 80, 40);
    
    _indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
    
    _indicator.hidden = NO;
    
    [self.view addSubview:_indicator];
    
    _context = [[UITextField alloc]initWithFrame:CGRectMake(120, 200, 80, 40)];
    
    _context.borderStyle = UITextBorderStyleRoundedRect;
    
    _context.font = [UIFont systemFontOfSize:16];
    
    _context.textAlignment = NSTextAlignmentLeft;
    
    [self.view addSubview:_context];
    
}

- (IBAction)clickDown:(id)sender {
    
    self.indicator.hidden = NO;
    
    [self.indicator startAnimating];
    
    queue = [[NSOperationQueue alloc]init];
    
    NSInvocationOperation *op = [[NSInvocationOperation alloc]initWithTarget:self selector:@selector(download) object:nil];
    [queue addOperation:op];
    
}

- (void)download{

    NSURL *url = [NSURL URLWithString:@"https://www.baidu.com"];
    NSLog(@"Starting download");
    
    NSError *error;
    
    NSString *data = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
    
    sleep(60);
    
    NSLog(@"original data = %@",data);
    
//    UIImage *image = [[UIImage alloc]initWithData:data];
    
    [self performSelectorOnMainThread:@selector(updateUI:) withObject:data waitUntilDone:YES];
}

- (void)updateUI:(NSString *)data{
    
//    imageView *imageV = [[imageView alloc]initWithFrame:[[UIScreen mainScreen] bounds]];
//    
////    imageV.backgroundColor  = [UIColor grayColor];
//    imageV.image = image1;
//    [self.indicator stopAnimating];
//    NSLog(@"dowload finish");
//    [self.view addSubview:imageV];
    
    NSLog(@"call back data = %@",data);
    [self.indicator stopAnimating];
    self.indicator.hidden = YES;
    _context.text = data;
    
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_context resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
