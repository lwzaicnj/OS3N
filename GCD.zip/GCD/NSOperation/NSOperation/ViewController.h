//
//  ViewController.h
//  NSOperation
//
//  Created by apple on 8/29/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "imageView.h"

@interface ViewController : UIViewController{
    
    UIActivityIndicatorView *_indicator;
    UITextField *_context;
}

@property(nonatomic,strong)UIActivityIndicatorView *indicator;

@end

