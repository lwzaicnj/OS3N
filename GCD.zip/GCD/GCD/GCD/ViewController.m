//
//  ViewController.m
//  GCD
//
//  Created by apple on 8/29/16.
//  Copyright © 2016 apple. All rights reserved.
//

@import AssetsLibrary;
#import "ViewController.h"
#import "aViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) NSURL *url;

@end

@implementation ViewController

@synthesize indicator = _indicator;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _indicator = [[UIActivityIndicatorView alloc]init];
    
    _indicator.frame = CGRectMake(120, 100, 80, 40);
    
    _indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
    
    _indicator.hidden = NO;
    
    [self.view addSubview:_indicator];
    
    _click = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    [_click setTitle:@"Eric" forState:UIControlStateNormal];
    
    _click.frame = CGRectMake(180, 100, 40, 40);
    
    _context = [[UILabel alloc]initWithFrame:CGRectMake(180, 180, 40, 40)];
    
    [_click addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_click];
    
    
    _context.font = [UIFont systemFontOfSize:4.0];
    
    _context.numberOfLines = 0;
    _context.textAlignment = NSTextAlignmentLeft;
    _context.backgroundColor = [UIColor yellowColor];
    
    _context.lineBreakMode = NSLineBreakByCharWrapping;
    
    [self.view addSubview:_context];
    
    [self.navigationItem setPrompt:@"Add photoaa"];
    
}

- (IBAction)click:(id)sender{
    
    self.indicator.hidden = NO;
    
    [self.indicator startAnimating];
    
//    //下載文本
//    //dispatch_async：它不会做任何等待
//    //dispatch_get_global_queue後台運行，優先級默認
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        
//        NSURL *url = [NSURL URLWithString:@"http://linux.vbird.org/linux_basic/0310vi/man.config"];
//       
//        NSLog(@"Starting download");
//        
//        NSError *error;
//        
//        NSString *data = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:&error];
//        
//        if (data != nil) {
//            //主線程執行
//            dispatch_async(dispatch_get_main_queue(), ^{
//                NSLog(@"call back data = %@",data);
//                [self.indicator stopAnimating];
//                self.indicator.hidden = YES;
//                _context.text = data;
//                CGSize dataSize = [data sizeWithFont:[UIFont systemFontOfSize:4.0] constrainedToSize:CGSizeMake(200, 10000) lineBreakMode:NSLineBreakByCharWrapping];
//                CGRect rect = _context.frame;
//                rect.size.height = dataSize.height;
//                _context.frame = rect;
//            });
//        }
//        else{
//            NSLog(@"error when download:%@",error);
//        }
//    });
    
    //下載圖像
//    static NSURLSession *session;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
//        session = [NSURLSession sessionWithConfiguration:configuration];
//    });
//    

//    NSURLSessionDataTask *task = [session dataTaskWithURL:self.url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        self.image = [UIImage imageWithData:data];
//        
//        
//        imView.image = _image;
//        
//    }];
//    [task resume];
    
    NSURL *url = [NSURL URLWithString:@"http://i.imgur.com/tPzTg7A.jpg"];
    
    UIImageView *imView = [[UIImageView alloc]init];
    NSData *data = [[NSData alloc]initWithContentsOfURL:url];
    imView.image = [UIImage imageWithData:data];
    imView.backgroundColor = [UIColor grayColor];
    imView.frame = [[UIScreen mainScreen] bounds];
    
//    [self.view addSubview:imView];
//    可以這樣讀取裡面的 viewController
    UIStoryboard *board=[UIStoryboard storyboardWithName:@"Main"bundle:nil];
    aViewController *aView = [board instantiateViewControllerWithIdentifier:@"aViewController"];
    
    [self.navigationController pushViewController:aView animated:NO];
//    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [self.navigationItem setPrompt:@"Add photo"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
