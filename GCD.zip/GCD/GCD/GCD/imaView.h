//
//  imaView.h
//  GCD
//
//  Created by apple on 8/31/16.
//  Copyright © 2016 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imaView : UIImageView

@end
