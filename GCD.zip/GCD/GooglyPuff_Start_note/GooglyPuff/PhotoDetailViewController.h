//
//  PhotoDisplayViewController.h
//  GooglyPuff
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//

#import <UIKit/UIKit.h>

//它执行添加曲棍球眼睛到图像上的逻辑，并用一个 UIScrollView 来显示结果图片
@interface PhotoDetailViewController : UIViewController

- (void)setupWithImage:(UIImage *)image;

@end
