//
//  PhotoCollectionViewController.m
//  GCDTutorial
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//

@import AssetsLibrary; //導入很多其中定義的頭文件
#import "PhotoCollectionViewController.h"
#import "PhotoDetailViewController.h"
#import "ELCImagePickerController.h"

static const NSInteger kCellImageViewTag = 3;
static const CGFloat kBackgroundImageOpacity = 0.1f;

@interface PhotoCollectionViewController () <ELCImagePickerControllerDelegate,
UINavigationControllerDelegate,
UICollectionViewDataSource,
UIActionSheetDelegate>

@property (nonatomic, strong) ALAssetsLibrary *library;
@property (nonatomic, strong) UIPopoverController *popController;
@end

@implementation PhotoCollectionViewController

//*****************************************************************************/
#pragma mark - LifeCycle
//*****************************************************************************/

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.library = [[ALAssetsLibrary alloc] init];
    
    // Background image setup 設置 rootViewController 的背景圖片
    UIImageView *backgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background"]];
    backgroundImageView.alpha = kBackgroundImageOpacity;
    backgroundImageView.contentMode = UIViewContentModeCenter;//居中 比例也適調？
    [self.collectionView setBackgroundView:backgroundImageView];//被此 viewController 對象管理的 collectionView(畫板，可以比屏幕大。滑動顯示)
   
    //在 notification center 注册观察者：
    //NSNotificationCenter专门供程序中不同类间的消息通信而设置的.
    //addObserver:　观察者，即在什么地方接收通知;
    //selector:　收到通知后调用何种方法;
    //name：　通知的名字，也是通知的唯一标示，编译器就通过这个找到通知的。
    //object：传递的参数
    //notification center 消息中心,是消息的控制中心,所有发送的消息都是由通知中心来控制分发的。notification的信息被被包装在NSNotification对象里面
    //NSNotificationCenter:每个进程都有一个默认通知中心可以通过defaultCenter获取消息通知单例对象。这个通知中心在一个单一进程中处理。在同一个设备上不同进程之间进行通信需要使用。
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(contentChangedNotification:)
                                                 name:kPhotoManagerContentUpdateNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(contentChangedNotification:) name:kPhotoManagerAddedContentNotification
                                               object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self showOrHideNavPrompt];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//*****************************************************************************/
#pragma mark - UICollectionViewDataSource Methods
//*****************************************************************************/

////定义展示的UICollectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSInteger count = [[[PhotoManager sharedManager] photos] count];
    return count;
}

//每个UICollectionView展示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"photoCell";
    //複用
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:kCellImageViewTag];
    NSArray *photoAssets = [[PhotoManager sharedManager] photos];
    //[PhotoManager sharedManager] photos]的每個項都是 Photo 的一個對象
    Photo *photo = photoAssets[indexPath.row];
    
    switch (photo.status) {
        case PhotoStatusGoodToGo:
            imageView.image = [photo thumbnail];
            break;
        case PhotoStatusDownloading:
            imageView.image = [UIImage imageNamed:@"photoDownloading"];
            break;
        case PhotoStatusFailed:
            imageView.image = [UIImage imageNamed:@"photoDownloadError"];
        default:
            break;
    }
    return cell;
}

//*****************************************************************************/
#pragma mark - UICollectionViewDelegate
//*****************************************************************************/

//UICollectionView被选中时调用的方法 //選中的時候會放大 顯示整個屏幕
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSArray *photos = [[PhotoManager sharedManager] photos];
    Photo *photo = photos[indexPath.row];
    
    switch (photo.status) {
        case PhotoStatusGoodToGo: {
            UIImage *image = [photo image];
            //根據名稱找類 動態加載 返回指定的 viewController
            PhotoDetailViewController *photoDetailViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PhotoDetailViewController"];
            [photoDetailViewController setupWithImage:image];
            [self.navigationController pushViewController:photoDetailViewController animated:YES];
            break;
        }
        case PhotoStatusDownloading: {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Downloading"
                                                            message:@"The image is currently downloading"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil, nil];
            [alert show];
            break;
        }
        case PhotoStatusFailed: //Fall through to default
        default: {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Image Failed"
                                                            message:@"The image failed to be created"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil, nil];
            [alert show];
        }
    }
}

//*****************************************************************************/
#pragma mark - elcImagePickerControllerDelegate //實現了委託ELCImagePickerControllerDelegate
//*****************************************************************************/

- (void)elcImagePickerController:(ELCImagePickerController *)picker didFinishPickingMediaWithInfo:(NSArray *)info
{
    for (NSDictionary *dictionary in info) {
        [self.library assetForURL:dictionary[UIImagePickerControllerReferenceURL] resultBlock:^(ALAsset *asset) {
            Photo *photo = [[Photo alloc] initWithAsset:asset];
            [[PhotoManager sharedManager] addPhoto:photo];
        } failureBlock:^(NSError *error) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Permission Denied"
                                                            message:@"To access your photos, please change the permissions in Settings"
                                                           delegate:nil
                                                  cancelButtonTitle:@"ok"
                                                  otherButtonTitles:nil, nil];
            [alert show];
        }];
    }
    
    if (isIpad()) {
        [self.popController dismissPopoverAnimated:YES];
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)elcImagePickerControllerDidCancel:(ELCImagePickerController *)picker
{
    if (isIpad()) {
        [self.popController dismissPopoverAnimated:YES];
    } else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

//*****************************************************************************/
#pragma mark - IBAction Methods
//*****************************************************************************/

/// The upper right UIBarButtonItem method “＋”號觸發方法
- (IBAction)addPhotoAssets:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Get Photos From:" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Photo Library", @"Le Internet", nil];
    [actionSheet showInView:self.view];
}

//*****************************************************************************/
#pragma mark - UIActionSheetDelegate
//*****************************************************************************/

//点击按钮时触发的方法
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    static const NSInteger kButtonIndexPhotoLibrary = 0;//從上往下數，點加號后出現的按鈕
    static const NSInteger kButtonIndexInternet = 1;
    if (buttonIndex == kButtonIndexPhotoLibrary) {
        ELCImagePickerController *imagePickerController = [[ELCImagePickerController alloc] init];
        [imagePickerController setImagePickerDelegate:self];
        
        if (isIpad()) {
            //UIPopoverController它只占用部分屏幕空间来呈现信息，而且显示在屏幕的最前面.
            //由于UIPopoverController直接继承自NSObject，不具备可视化的能力，因此UIPopoverController上面的内容必须由另外一个继承自UIViewController的控制器来提供，这个控制器称为“内容控制器”
            if (![self.popController isPopoverVisible]) {
                self.popController = [[UIPopoverController alloc] initWithContentViewController:imagePickerController];
                
                [self.popController presentPopoverFromBarButtonItem:self.navigationItem.rightBarButtonItem permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }
        } else {
            //進入 iphone 的本地圖片庫
//            NSLog(@"Cancle");
            [self presentViewController:imagePickerController animated:YES completion:nil];
        }
    } else if (buttonIndex == kButtonIndexInternet) {
        //點擊 Le Internet
        [self downloadImageAssets];
    }
}

//*****************************************************************************/
#pragma mark - Private Methods
//*****************************************************************************/

- (void)contentChangedNotification:(NSNotification *)notification
{
    [self.collectionView reloadData];
    [self showOrHideNavPrompt];
}

//延時隊列
- (void)showOrHideNavPrompt
{
    NSUInteger count = [[PhotoManager sharedManager]photos].count;
    
    double delay = 1.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_MSEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^{
        if (!count) {
            [self.navigationItem setPrompt:@"Add photo with faces to Googlyify them"];
        }else{
            [self.navigationItem setPrompt:nil];
        }
    });
    
}

//下載成功
- (void)downloadImageAssets
{
    [[PhotoManager sharedManager] downloadPhotosWithCompletionBlock:^(NSError *error) {
        
        // This completion block currently executes at the wrong time
        NSString *message = error ? [error localizedDescription] : @"The images have finished downloading";
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Download Complete"
                                                            message:message
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil, nil];
        [alertView show];
    }];
}

@end
