//
//  PhotoCollectionViewController.h
//  GCDTutorial
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//

#import <UIKit/UIKit.h>

//应用开始的第一个视图控制器。它用缩略图展示所有选定的照片
@interface PhotoCollectionViewController : UICollectionViewController

@end
