//
//  Photo.m
//  GooglyPuff
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//
@import AssetsLibrary;
#import "Photo.h"
#import "UIImage+Resize.h"

//*****************************************************************************/
#pragma mark - Private Class AssetPhoto
//*****************************************************************************/

@interface __p_AssetPhoto : Photo //子類
@property (nonatomic, strong) ALAsset *asset;
@end

@implementation __p_AssetPhoto

// thumbnail縮略圖
- (UIImage *)thumbnail
{
    UIImage *thumbnail = [UIImage imageWithCGImage:[self.asset thumbnail]];
    return thumbnail;
}

- (UIImage *)image
{
    ALAssetRepresentation *representation = [self.asset defaultRepresentation];
    UIImage *image = [UIImage imageWithCGImage:[representation fullScreenImage]];
    return image;
}

- (PhotoStatus)status
{
    return PhotoStatusGoodToGo;
}

@end

//*****************************************************************************/
#pragma mark - Private Class DownloadPhoto
//*****************************************************************************/

@interface __p_DownloadPhoto : Photo
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) NSURL *url;
@property (nonatomic, strong) UIImage *thumbnail;
@end

@implementation __p_DownloadPhoto
@synthesize status = _status;

//正式下載圖片
- (void)downloadImageWithCompletion:(PhotoDownloadingCompletionBlock)completionBlock
{
    static NSURLSession *session;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //網絡下載 ephemeralSessionConfiguration瞬間會話模式：该模式不使用磁盘保存任何数据。所有和会话相关的caches，证书，cookies等都被保存在RAM中，因此当程序使会话无效，这些缓存的数据就会被自动清空
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        session = [NSURLSession sessionWithConfiguration:configuration];
    });
    NSURLSessionDataTask *task = [session dataTaskWithURL:self.url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        self.image = [UIImage imageWithData:data];
        if (!error && _image) {
            _status = PhotoStatusGoodToGo;
        } else {
            _status = PhotoStatusFailed;
        }
        //最多縮略64？
        self.thumbnail = [_image thumbnailImage:64
                          transparentBorder:0
                               cornerRadius:0
                       interpolationQuality:kCGInterpolationDefault];
        
        if (completionBlock) {
            completionBlock(_image, error);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotification *notification = [NSNotification notificationWithName:kPhotoManagerContentUpdateNotification object:nil];
            //观察者们和poster有可能都在不同的子线程中，这样观察者们就收不到通知事件
            //這裡的 poster 在PhotoCollectionViewController的 viewdidLoad
            // NSNotificationQueue，就像是notification的缓冲池。他有两个重要的feature，合并notifications以及异步发送通知。
            //NSNotificationQueue通常以FIFO(先进先出)的原则处理通知，当一个notification到了队列前面是，queue把他发送到notification Center，然后notification center再把他发送到observer。
            //每个线程都有一个与notification center相关的queue，你也可以创建自己的queue，这样就形成一个center和多个queue。
            //Notification center发送notification给接收者的方法是同步的. 也就是说, 当发送一个notification的时候, 除非所有的接收者都接到和处理了这个notification, 否则不会返回. 想要发送异步notification的话就需要用到notification queue
            [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
        });
    }];
    
    [task resume];
}

- (UIImage *)thumbnail
{
    return _thumbnail;
}

- (UIImage *)image
{
    return _image;
}

- (PhotoStatus)status
{
    return _status;
}

@end

//*****************************************************************************/
#pragma mark - Public Class Photo
//*****************************************************************************/

@interface Photo ()
//0 1 2三種狀態
@property (nonatomic, assign) PhotoStatus status; // Redeclare status as writeable.
@end

@implementation Photo

//
- (instancetype)initWithAsset:(ALAsset *)asset
{
    NSAssert(asset, @"Assset is nil");
    __p_AssetPhoto *assetPhoto;
    assetPhoto = [[__p_AssetPhoto alloc] init];
    if (assetPhoto) {
        assetPhoto.asset = asset;
        assetPhoto.status = PhotoStatusGoodToGo;
    }
    
    return assetPhoto;
}

- (instancetype)initwithURL:(NSURL *)url
{
    NSAssert(url, @"URL is nil");
    __p_DownloadPhoto *downloadPhoto;
    downloadPhoto = [[__p_DownloadPhoto alloc] init];
    if (downloadPhoto) {
        downloadPhoto.status = PhotoStatusDownloading;
        downloadPhoto.url = url;
        [downloadPhoto downloadImageWithCompletion:nil];
    }
    return downloadPhoto;
}

- (instancetype)initwithURL:(NSURL *)url withCompletionBlock:(PhotoDownloadingCompletionBlock)completionBlock
{
    NSAssert(url, @"URL is nil");
    __p_DownloadPhoto *downloadPhoto;
    downloadPhoto = [[__p_DownloadPhoto alloc] init];
    if (downloadPhoto) {
        downloadPhoto.status = PhotoStatusDownloading;
        downloadPhoto.url = url;
        [downloadPhoto downloadImageWithCompletion:[completionBlock copy]];
    }
    return downloadPhoto;
}

//*****************************************************************************/
#pragma mark - Don't use these in the abstract base class! I am cereal!
//*****************************************************************************/

- (PhotoStatus)status {
    NSAssert(NO, @"Use One of Photo's public initializer methods");
    return PhotoStatusFailed;
}

- (UIImage *)image
{
    NSAssert(NO, @"Use One of Photo's public initializer methods");
    return nil;
}

- (UIImage *)thumbnail
{
    NSAssert(NO, @"Use One of Photo's public initializer methods");
    return nil;
}

@end
