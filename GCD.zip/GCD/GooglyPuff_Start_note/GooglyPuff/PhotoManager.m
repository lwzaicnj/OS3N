//  PhotoManager.m
//  PhotoFilter
//
//  Created by A Magical Unicorn on A Sunday Night.
//  Copyright (c) 2014 Derek Selander. All rights reserved.
//

@import CoreImage;
@import AssetsLibrary;
#import "PhotoManager.h"

//私有屬性
@interface PhotoManager ()
@property (nonatomic, strong, readonly) NSMutableArray *photosArray;
@property (nonatomic,strong) dispatch_queue_t concurrentPhotoQueue;

@end

@implementation PhotoManager

//單例 會發生竟態條件，需要保護
+ (instancetype)sharedManager
{
    static PhotoManager *sharedPhotoManager = nil;
//    if (!sharedPhotoManager) {
//        //1 利用sleepForTimeInterval來強制發生一個上下文切換
//
//        [NSThread sleepForTimeInterval:2];
//        
//        sharedPhotoManager = [[PhotoManager alloc] init];
//        
//        //2
//         NSLog(@"Singleton has memory address at: %@", sharedPhotoManager);
//         [NSThread sleepForTimeInterval:2];
//        sharedPhotoManager->_photosArray = [NSMutableArray array];
//    }

    //利用 dispatch_once 來取代 if 條件判斷，單例就只執行一次
    //dispatch_once() 以线程安全的方式执行且仅执行其代码块一次
    static dispatch_once_t  onceToken;
    dispatch_once(&onceToken,^{
//        [NSThread sleepForTimeInterval:2];
        sharedPhotoManager = [[PhotoManager alloc] init];
//        NSLog(@"Singleton has memory address at: %@", sharedPhotoManager);
//        [NSThread sleepForTimeInterval:2];
        sharedPhotoManager->_photosArray = [NSMutableArray array];
        //添加 實例化concurrentPhotoQueue屬性
        sharedPhotoManager->_concurrentPhotoQueue = dispatch_queue_create("com.selander.GooglyPuff.photoQueue",DISPATCH_QUEUE_CONCURRENT);//並發隊列 （可以利用 dispathc_sync 來處理並發隊列，等待一個任務。然後才能執行其他處理）

    });
    
    return sharedPhotoManager;
}

//*****************************************************************************/
#pragma mark - Unsafe Setter/Getters
//*****************************************************************************/

//讀操作，使用 dipatch_sync 同步地提交工作并在返回前等待它完成
- (NSArray *)photos
{
    
//    return _photosArray;
    __block NSArray *array;
    //（可以利用 dispathc_sync 來處理並發隊列，等待一個任務。然後才能執行其他處理）
    dispatch_sync(self.concurrentPhotoQueue, ^{
        array = [NSArray arrayWithArray:_photosArray];
    });
    
    return array;
}

//添加照片操作
- (void)addPhoto:(Photo *)photo
{
//    if (photo) {
//        [_photosArray addObject:photo];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [self postContentAddedNotification];
//        });
//    }
    if (photo) {
        //由于它是一个障碍 Block ，这个 Block 永远不会同时和其它 Block 一起在 concurrentPhotoQueue 中执
        dispatch_barrier_async(self.concurrentPhotoQueue, ^{
            [_photosArray addObject:photo];
            //异步地调度另一个任务到主线程。
            dispatch_async(dispatch_get_main_queue(), ^{
                [self postContentAddedNotification];
            });
        });
    }
}

//*****************************************************************************/
#pragma mark - Public Methods
//*****************************************************************************/

- (void)downloadPhotosWithCompletionBlock:(BatchPhotoDownloadingCompletionBlock)completionBlock
{
    __block NSError *error;
    
    for (NSInteger i = 0; i < 3; i++) {
        NSURL *url;
        switch (i) {
            case 0:
                url = [NSURL URLWithString:kOverlyAttachedGirlfriendURLString];
                break;
            case 1:
                url = [NSURL URLWithString:kSuccessKidURLString];
                break;
            case 2:
                url = [NSURL URLWithString:kLotsOfFacesURLString];
                break;
            default:
                break;
        }
        //傳遞 url image error 下載照片
        Photo *photo = [[Photo alloc] initwithURL:url
                              withCompletionBlock:^(UIImage *image, NSError *_error) {
                                  if (_error) {
                                      error = _error;
                                  }
                              }];
    
        [[PhotoManager sharedManager] addPhoto:photo];
    }
    
    if (completionBlock) {
        completionBlock(error);
    }
}

//*****************************************************************************/
#pragma mark - Private Methods
//*****************************************************************************/

- (void)postContentAddedNotification
{
    static NSNotification *notification = nil;
    static dispatch_once_t onceToken; //執行一次
    dispatch_once(&onceToken, ^{
        notification = [NSNotification notificationWithName:kPhotoManagerAddedContentNotification object:nil];
    });
    
    [[NSNotificationQueue defaultQueue] enqueueNotification:notification postingStyle:NSPostASAP coalesceMask:NSNotificationCoalescingOnName forModes:nil];
}

@end
