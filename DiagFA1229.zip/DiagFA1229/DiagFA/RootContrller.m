//
//  rootContrller.m
//  DiagFA
//
//  Created by tom on 15/11/21.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import "RootContrller.h"

//內部定義的類
@interface  ContrllerToken: NSObject

//外部设置
@property (nonatomic,copy) NSString *cablePath;
//内部设置
@property (nonatomic) NSMutableArray *sendBuffer; //保存多條發送給設備的命令
@property (nonatomic) NSMutableString *communicationStr; //保存發送命令給設備后返回的 log
@property (nonatomic) NSMutableString *luaResultStr;
@property (nonatomic) NSMutableString *displayStr;

@end


@implementation ContrllerToken

- (instancetype)init {
    self = [super init];
    if (self) {
        _sendBuffer = [NSMutableArray new];
        _luaResultStr = [NSMutableString new];
        _displayStr = [NSMutableString new];
        _communicationStr = [NSMutableString new];
    }
    return self;
}

@end


/***************************************************/
/***************************************************/

//比 typedef enum {
//  ...
// }WorkMode; 清晰
typedef NS_ENUM(NSUInteger, WorkMode) {
    ManualMode = 0,
    LuaMode
};

@interface RootContrller ()

//UI控件引用
@property (weak) IBOutlet NSTextField *cmdTextField;
@property (weak) IBOutlet NSScrollView *scrollView;
@property  IBOutlet NSTextView *logTextField;
@property (weak) IBOutlet NSButton *luaButton;
@property (weak) IBOutlet NSButton *testItemButton;
@property (weak) IBOutlet NSPopUpButton *stationLabel;//存儲 工站信息
@property (weak) IBOutlet NSPopUpButton *itemLabel;//存儲工站對應的測項 兩個信息均在 lua 腳本裡面加入
@property NSDictionary *stationAndItem;

//命令交互模式与Lua自动测试模式
@property (nonatomic) WorkMode workMode;

//组合通信类和脚本类
@property (nonatomic) Communication *communication;
@property (nonatomic) LuaScript *luaScript;

//用于多台测试
@property (nonatomic) NSMutableArray *tokenArray;

//用于单台测试
@property (nonatomic) ContrllerToken *firstToken;

//操作共用容器的安全线程
@property (nonatomic) dispatch_queue_t publicSerialQueue;
@property (nonatomic) NSLock *publicLock; //lock 就是 阻塞线程的执行 unlock 就是接開阻塞

//@property (nonatomic) TestClass *testClass;

@end


@implementation RootContrller

- (ContrllerToken*)firstToken {
    if (_firstToken==nil) {
        _firstToken = _tokenArray.firstObject;
    }
    return _firstToken;
}

#pragma mark - 设置环境 -
- (void)getStart {
    
    //_x 是成員變量，內部用，self.x 是屬性，外部可以調用
    _communication = [Communication sharedCommunication];
    _luaScript = [LuaScript sharedLuaScript];
    _tokenArray = [NSMutableArray new];
    _publicSerialQueue = dispatch_queue_create("RootContrller_publicSerialQueue", DISPATCH_QUEUE_SERIAL);//創建串行線程，FIFO
    _publicLock = [NSLock new];
    self.cmdTextField.delegate = self;
    self.logTextField.delegate = self;
    
    //通过Lua脚本设置可选Button
    _stationAndItem = [self.luaScript arrayOrDictionaryWithContentsOfTable:@"stationAndItem"];//返回一個 table（dictinary）
    //把上面獲取的_stationAndItem 的 key 作為 popButton 的標題
    [self.stationLabel addItemsWithTitles:[self.stationAndItem allKeys]];

    //通过Lua脚本设置Button
    NSArray *buttonInfoArray = [self.luaScript arrayOrDictionaryWithContentsOfTable:@"buttonInfo"];
    [buttonInfoArray enumerateObjectsUsingBlock:^(id title, NSUInteger idx, BOOL *stop) {
        [(NSButton*)[self.view.subviews objectAtIndex:idx] setTitle:title]; //把 array 裡面的工站挑選后修改成 subViews 的名稱，選擇什麼工站，視圖的名稱就轉成什麼名稱 但是沒有添加怎麼去的 subview？
    }];
    
//    NSString *aPath = [[NSBundle mainBundle]pathForResource:@"nanokdp" ofType:nil];
//    NSLog(@"%@",aPath);
    
    //尝试打开通信
    if (![self searchCable]) {
        self.logTextField.string = @"Can not find the cable or can not open !!";
        return;
    }
    
    //设置Lua环境, 回调函数和委托方法之类
    [self configurLuaMode];
    
    [NSTimer scheduledTimerWithTimeInterval:0.008 target:self selector:@selector(upTextField) userInfo:nil repeats:YES];
}

-(BOOL)searchCable {
    NSArray *devArray = [[NSFileManager new] contentsOfDirectoryAtPath:@"/dev" error:nil]; //指定目錄/dev 下的子项（文件或文件夹）列表,在其下尋找 cable 線
    
    //枚舉數據，包括 dictionary 和 array
    [devArray enumerateObjectsUsingBlock:^(id cablePath, NSUInteger idx, BOOL *stop) {
        NSRange range = [(NSString*)cablePath rangeOfString:@"cu.kong.*" options:NSRegularExpressionSearch];//NSRegularExpressionSearch使用正則表達式匹配。返回第一個匹配到的字符串
        if (range.length==0) range = [(NSString*)cablePath rangeOfString:@"cu.usbmodem.*" options:NSRegularExpressionSearch];
        if (range.length!=0) {
            ContrllerToken *token = [ContrllerToken new];
            token.cablePath = (NSString*)cablePath;
            [self.tokenArray addObject:token]; //這個類含 cablePath
            [self.communication addCable:(NSString*)cablePath];
        }
    }];
    if ([self.tokenArray count]==0) return NO;
    [self configurCommunication];//通信配置，塊初始化等
    [self.communication allCableFire];//開始讀寫準備
    return YES;
}

- (ContrllerToken*)getRightTokenPacket:(NSString*)cablePah {
    NSArray *tokenArray = self.tokenArray;
    __block ContrllerToken *contrllerToken; //這樣子 block 內部就可以修改這個變量
    [tokenArray enumerateObjectsUsingBlock:^(id token, NSUInteger idx, BOOL *stop) {
        if ([(ContrllerToken*)token cablePath]==cablePah) {
            contrllerToken = (ContrllerToken*)token; //token 對應 cable
            *stop = 1;
        }
    }];
    return contrllerToken;
}

- (void)configurCommunication {
    __weak RootContrller *weekSelf = self;
    //block中用到的外部变量最好使用 __weak 修饰，避免内存泄露
    // NSString *cablePah 是參數，定義的時候是 NSString(返回) *(^stringToDev(聲明為塊))(NSString *cablePah(參數));
    //初始化塊的時候就是：stringToDev ＝ ^(NSString *cablePah){   return string;}
    //發送給設備的命令
    //調用的話就是 stringToDev(cablePath)
    self.communication.stringToDev = ^(NSString *cablePah) {
        ContrllerToken *contrllerToken = [weekSelf getRightTokenPacket:cablePah];//用 cablepah 找到
        NSMutableString * str = [NSMutableString stringWithString:@""];
        //dispatch_sync:同步添加操作。他是等待添加进队列里面的操作完成之后再继续执行
        dispatch_sync(weekSelf.publicSerialQueue, ^(){
            if (contrllerToken.sendBuffer.count==0) return;
            [str appendString:contrllerToken.sendBuffer.firstObject];
            [contrllerToken.sendBuffer removeObject:contrllerToken.sendBuffer.firstObject];//一個個發送給設備，發送后清除發送下一個
        });
        return str;//返回命令,寫進偽終端，每次都是第一條 FIFO
    };
    
    //設備返回的數據
    //初始化 block
    self.communication.stringFromDev =^(NSString *cablePah, NSString *dataStr) {
        if (dataStr!=0) {
            ContrllerToken *contrllerToken = [weekSelf getRightTokenPacket:cablePah];
            dispatch_async(weekSelf.publicSerialQueue, ^(){
                [contrllerToken.communicationStr appendString:dataStr];//接收返回值，讀回來的值
            });
        }
    };
}

- (BOOL)testLua {
    NSMutableString *testStr = (NSMutableString*)[self.luaScript testLuaScript];
    if (testStr!=nil) {
        self.logTextField.string = testStr;
        return NO;
    }
    return YES;
}

- (void)configurLuaMode {
    //tokenArray在 searchCable 的時候保存每一個包含cu.kong.* 的終端名稱
    [self.tokenArray enumerateObjectsUsingBlock:^(id token, NSUInteger idx, BOOL *stop) {
        [self.luaScript addLuaerWithIdentity:[token cablePath]];//傳遞 cablepath
    }];
    if (self.luaScript.strFromLua!=nil) return;
    
    __weak RootContrller *weekSelf = self;
    
    self.luaScript.strFromLua = ^(NSString *cablePah, NSString *cmd) {
        ContrllerToken *contrllerToken = [weekSelf getRightTokenPacket:cablePah];
        dispatch_async(weekSelf.publicSerialQueue, ^(){
            NSMutableString *str = [[NSMutableString alloc]initWithString:cmd];
            [str appendString:@"\n"];
            [contrllerToken.sendBuffer addObject:str];//裡面保存命令 cmd，來自 lua 腳本的命令，然後寫進偽終端
        });
    };
    
    self.luaScript.strToLua = ^(NSString *cablePah) {
        ContrllerToken *contrllerToken = [weekSelf getRightTokenPacket:cablePah];
        NSMutableString * str = [NSMutableString stringWithString:@""];
        dispatch_sync(weekSelf.publicSerialQueue, ^(){
            [str appendString:contrllerToken.communicationStr]; //contrllerToken.communicationStr來自於設備返回
            contrllerToken.communicationStr = [NSMutableString new];
        });
        return str;//就是輸入命令返回的數據，讀到的數據，然後在 lua 裡面切片等進行處理
    };
    
    self.luaScript.logLuaStr = ^(NSString *cablePah, NSString *log) {
        ContrllerToken *contrllerToken = [weekSelf getRightTokenPacket:cablePah];
        dispatch_async(weekSelf.publicSerialQueue, ^(){
            [contrllerToken.luaResultStr appendString:log];
        });
    };
    
    self.luaScript.upLoadLuaStr = ^(NSString *identity) {
        
    };
    
    self.luaScript.luaerDone = ^(NSString *cablePah) {
        usleep(1000000*0.5);
        for (int i=0; i<9; i++) [(NSButton*)[weekSelf.view.subviews objectAtIndex:i] setEnabled:YES];
        weekSelf.workMode = ManualMode;
    };
    
    self.luaScript.luaerAlertStr = ^(NSString *cablePah, NSString *alertStr) {
        //dispatch_sync:同步添加操作。他是等待添加进队列里面的操作完成之后再继续执行，裡面取得主序列
        dispatch_sync(dispatch_get_main_queue(), ^(){
        NSAlert *alert = [[NSAlert alloc] init];
        alert.messageText = alertStr;
        [alert runModal];
        });
    };
}

#pragma mark - Button 响应 -
- (IBAction)selectionButton:(NSPopUpButton *)sender {
    [self.itemLabel removeAllItems];
    if ([sender.selectedItem.title isEqualToString:@"None"]) {
        [self.itemLabel addItemWithTitle:@"None"];
        return;
    }
    [self.itemLabel addItemsWithTitles:[self.stationAndItem objectForKey:sender.title]];//sender是工站的 popUpButton,title 是工站名，一個工站對應多個 item
}



- (IBAction)wholeButton:(id)sender {
    if (self.tokenArray.count==0) return;
    if ([self testLua]==NO) return; //測試沒有 lua 腳本的棧頂是什麼，正常為空返回 YES
    self.workMode = LuaMode;
    for (int i=0; i<9; i++) [(NSButton*)[self.view.subviews objectAtIndex:i] setEnabled:NO];//把所有 button 設置為非激活

    NSString *title = [(NSButton*)sender title];
    if (![title compare:@"lua"]) {
        [self.luaScript allLuaFire];
        return;
    }
    //單獨運行單個工站下的單個命令
    else if (![title compare:@"testItem"]) {
        NSString *stationStr = self.stationLabel.selectedItem.title;
        NSString *itemStr = self.itemLabel.selectedItem.title;
        [self.luaScript runLuaFuncWithIdentity:self.firstToken.cablePath withNameA:stationStr nameB:itemStr];
        return;
    }else {
        [self.luaScript runLuaFuncWithIdentity:self.firstToken.cablePath withNameA:title nameB:@"Func"];
    }
}


#pragma mark - NSTextView 代理 -
- (BOOL)textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector {
    if (self.tokenArray.count==0) return YES;
    //sel_getName:Returns the name of the method specified by a given selector.
    if (strcmp("noop:", sel_getName(commandSelector))!=0) return NO;
    
    self.firstToken.displayStr = [NSMutableString new];
    self.logTextField.string = @"";
    return YES;
}

#pragma mark - NSTextField 代理 -
- (BOOL)control:(NSControl *)control textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector {
    if (self.tokenArray.count==0) { return YES; }    
    if (strcmp("insertNewline:", sel_getName(commandSelector))!=0) return NO;
    
    dispatch_async(self.publicSerialQueue, ^(){
        NSMutableString *str = [[NSMutableString alloc] initWithString:self.cmdTextField.stringValue];
        [str appendString:@"\n"];
        [self.firstToken.sendBuffer addObject:str];//添加 "輸入命令" 到 sendBuffer
        dispatch_async(dispatch_get_main_queue(), ^{
            self.cmdTextField.stringValue = @""; //清零
        });
    });
    
    return YES;
}

#pragma mark - NSTextField Log 更新 -
- (void)upTextField {
    dispatch_async(self.publicSerialQueue, ^{
        [self.publicLock lock];
        
        if (self.workMode==ManualMode) {
            if ([self.firstToken.communicationStr length]<1) {
                [self.publicLock unlock];
                return;
            }
            [self.firstToken.displayStr appendString:self.firstToken.communicationStr];
            self.firstToken.communicationStr =[NSMutableString new];
        }
        if (self.workMode==LuaMode) {
            //沒有返回值 log
            if ([self.firstToken.luaResultStr length]<1) {
                [self.publicLock unlock];
                return;
            }
            [self.firstToken.displayStr appendString:self.firstToken.luaResultStr];
            self.firstToken.luaResultStr =[NSMutableString new];
        }

        [self.firstToken.displayStr replaceOccurrencesOfString:@"[2J\e[" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, self.firstToken.displayStr.length)];
        [self.firstToken.displayStr replaceOccurrencesOfString:@"[0;35m" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, [self.firstToken.displayStr length])];
        [self.firstToken.displayStr replaceOccurrencesOfString:@"[0;33m" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, [self.firstToken.displayStr length])];
        [self.firstToken.displayStr replaceOccurrencesOfString:@"[0;31m" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, [self.firstToken.displayStr length])];
        [self.firstToken.displayStr replaceOccurrencesOfString:@"[1;33m" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, [self.firstToken.displayStr length])];
        [self.firstToken.displayStr replaceOccurrencesOfString:@"[0m" withString:@"" options:NSLiteralSearch range:NSMakeRange(0, [self.firstToken.displayStr length])];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.publicLock lock];
            self.logTextField.string = self.firstToken.displayStr;//輸出
            [self.publicLock unlock];
            
            //scrollView是 textview 的上一層
            self.scrollView.verticalScroller.floatValue = 1.000;
            
            
            //self.scrollView documentView:返回在其内容视图中的接收器滚动视图的 frame
            //畫布 contentView
            //NSLog(@"6666 %f",NSMaxY([[self.scrollView documentView] frame]) - NSHeight([[self.scrollView contentView] bounds]));
            [self.scrollView.contentView scrollToPoint:NSMakePoint(0.0, NSMaxY([[self.scrollView documentView] frame]) - NSHeight([[self.scrollView contentView] bounds]))];
        });
        
        [self.publicLock unlock];
    });
}

@end
