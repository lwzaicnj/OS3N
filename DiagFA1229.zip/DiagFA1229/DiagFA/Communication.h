//
//  Communication.h
//  DiagFA
//
//  Created by tom on 15/11/19.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Communication : NSObject

@property (nonatomic,copy) void (^stringFromDev)(NSString *cablePah, NSString *dataStr);
@property (nonatomic,copy) NSString *(^stringToDev)(NSString *cablePah);

+ (instancetype)sharedCommunication;
- (void)addCable:(NSString*)cablePah;
- (void)allCableFire;

@end
