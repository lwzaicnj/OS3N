//
//  LuaScript.h
//  DiagFA
//
//  Created by tom on 15/11/23.
//  Copyright © 2015年 TOM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LuaSrc/lapi.h"
#import "LuaSrc/lualib.h"
#import "LuaSrc/lauxlib.h"
#import "LuaSrc/lua.h"

@interface LuaScript : NSObject

@property (nonatomic,copy) void (^strFromLua)(NSString *identity, NSString *cmd);
@property (nonatomic,copy) NSString* (^strToLua)(NSString *identity);
@property (nonatomic,copy) void (^logLuaStr)(NSString *identity, NSString *log);
@property (nonatomic,copy) void (^upLoadLuaStr)(NSString *identity);
@property (nonatomic,copy) void (^luaerDone)(NSString *identity);
@property (nonatomic,copy) void (^luaerAlertStr)(NSString *identity, NSString *alert);


+ (instancetype)sharedLuaScript;
- (void)addLuaerWithIdentity:(NSString*)identity;
- (void)allLuaFire;
- (void)runLuaFuncWithIdentity:(NSString*)identity withNameA:(NSString*)nameA nameB:(NSString*)nameB;
- (NSString*)testLuaScript;
- (id)arrayOrDictionaryWithContentsOfTable:(NSString*)tableName;
@end
