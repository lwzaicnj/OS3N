//
// MATLAB Compiler: 6.0 (R2015a)
// Date: Thu Jul 28 15:07:51 2016
// Arguments: "-B" "macro_default" "-W" "cpplib:libaddmatrix" "-T" "link:lib"
// "-d" "/Users/apple/Desktop/add/libaddmatrix/for_testing" "-v"
// "/Users/apple/Desktop/add/addmatrix.m" 
//

#include <stdio.h>
#define EXPORTING_libaddmatrix 1
#include "libaddmatrix.h"

static HMCRINSTANCE _mcr_inst = NULL;


#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_libaddmatrix_C_API
#define LIB_libaddmatrix_C_API /* No special import/export declaration */
#endif

LIB_libaddmatrix_C_API 
bool MW_CALL_CONV libaddmatrixInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream((void *)(libaddmatrixInitializeWithHandlers));
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_libaddmatrix_C_API 
bool MW_CALL_CONV libaddmatrixInitialize(void)
{
  return libaddmatrixInitializeWithHandlers(mclDefaultErrorHandler, 
                                            mclDefaultPrintHandler);
}

LIB_libaddmatrix_C_API 
void MW_CALL_CONV libaddmatrixTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_libaddmatrix_C_API 
void MW_CALL_CONV libaddmatrixPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(&stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_libaddmatrix_C_API 
bool MW_CALL_CONV mlxAddmatrix(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "addmatrix", nlhs, plhs, nrhs, prhs);
}

LIB_libaddmatrix_CPP_API 
void MW_CALL_CONV addmatrix(int nargout, mwArray& a, const mwArray& b, const mwArray& c)
{
  mclcppMlfFeval(_mcr_inst, "addmatrix", nargout, 1, 2, &a, &b, &c);
}

