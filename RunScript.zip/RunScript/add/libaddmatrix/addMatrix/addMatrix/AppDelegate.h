//
//  AppDelegate.h
//  addMatrix
//
//  Created by apple on 7/28/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "libaddmatrix.h"
#include "mclcppclass.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>{
    IBOutlet NSButton *btn;
    IBOutlet NSWindow *window;
}

- (IBAction)add:(id)sender;

- (void)initApp:(id)param;

- (void)postTriangleRequest:(id)param;

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender;

- (void)terminateApp:(NSApplication *)theApplication;
@end

