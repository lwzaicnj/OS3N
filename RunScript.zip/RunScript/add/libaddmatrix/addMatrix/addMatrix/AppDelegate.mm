//
//  AppDelegate.m
//  addMatrix
//
//  Created by apple on 7/28/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import "AppDelegate.h"


@implementation AppDelegate

- (void)applicationWillFinishLaunching:(NSNotification *)notification{
    NSLog(@"Processing applicationWillFinishLaunching event");
    
    [NSThread detachNewThreadSelector:@selector(initApp:) toTarget:self withObject:nil];

//
//    //
//    // mclInitializeApplication must be called to use a MATLAB shared library
//    // component.
//    //
//    if (!mclInitializeApplication(NULL,0))
//    {
//        NSLog(@"mclInitializeApplication failed");
//        return;
//    }
//    //
//    // libsierpinskiInitialize must be called to initialize
//    // the MATLAB shared library component.
//    //
//    if (!libaddmatrixInitialize())
//    {
//        NSLog(@"libsierpinskiInitialize failed");
//        return;
//    }

//    sleep(8);
//    double data[] = {1,2,3,4,5,6,7,8,9};
//    mwArray in1(3, 3, mxDOUBLE_CLASS, mxREAL);
//    mwArray in2(3, 3, mxDOUBLE_CLASS, mxREAL);
//    in1.SetData(data, 9);
//    in2.SetData(data, 9);
//    
//    mwArray out;
//    
//    addmatrix(1, out, in1, in2);
//    
//    [btn setEnabled:YES];

//    libaddmatrixTerminate();
//    
//    mclTerminateApplication();
}

- (void)initApp:(id)param{
    
    NSLog(@"Executing initialization thread...");
    if (!mclInitializeApplication(NULL,0))
    {
        NSLog(@"mclInitializeApplication failed");
        return;
    }
    //
    // libsierpinskiInitialize must be called to initialize
    // the MATLAB shared library component.
    //
    if (!libaddmatrixInitialize())
    {
        NSLog(@"libsierpinskiInitialize failed");
        return;
    }
    
//    
//    double data[] = {100,2,3,40,5,6,7,8,9,10}; //利用 數組給矩陣傳值。
//    mwArray in1(2, 5, mxUINT8_CLASS, mxREAL);// (行，列，類型，是否為複數陣列)
//    mwArray in2(2, 5, mxUINT8_CLASS, mxREAL);
//    in1.SetData(data, 10);
//    in2.SetData(data, 10);
//    
//    mwArray out;
//    
//    addmatrix(1, out, in1, in2);

    [btn setEnabled: YES];
//    [window makeKeyAndOrderFront:nil];
    
    
}

- (IBAction)add:(id)sender
{
    NSLog( @"Processing draw triangle button event");
    [btn setEnabled: NO];      // Disable button, one request at a time
    [NSThread detachNewThreadSelector:@selector(postTriangleRequest:) toTarget:self withObject:nil];
}

- (void)postTriangleRequest:(id)param
{
    NSLog(@"Thread which will call component library request");
    //NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    // The following few lines, set up and call the MATLAB shared library component.
    double data[] = {1,2,3,4,5,6,7,8,9};
    mwArray in1(2, 3, mxDOUBLE_CLASS, mxREAL);
    mwArray in2(2, 3, mxDOUBLE_CLASS, mxREAL);
    in1.SetData(data, 6);
    in2.SetData(data, 6);
    
    double x;
    x = in1.Get(1,1,3);//返回第二行的 第三個元素 就是 6
    NSLog(@"%f ---- \n",x);
    
    mwArray out;

    addmatrix(1, out, in1, in2);

    
    
    [btn setEnabled: YES];  // Reenable button, ready for next request

}


- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender{

    NSLog(@"Processing applicationShouldTerminate event");
    [NSThread detachNewThreadSelector:@selector(terminateApp:) toTarget:self withObject:sender];
    return NSTerminateLater;
}

- (void)terminateApp:(NSApplication *)theApplication
{
    NSLog(@"Executing termination thread");
    //
    // libsierpinskiTerminate should be called to terminate use
    // of the MATLAB shared library component.
    //
    libaddmatrixTerminate();
    //
    // mclTerminateApplication should be called indicating that all
    // shared library component usage is completed.
    //
    mclTerminateApplication();
//    [theApplication replyToApplicationShouldTerminate: YES];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    NSLog(@"Processing applicationShouldTerminateAfterLastWindowClosed event");
    return YES;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
//    // Insert code here to initialize your application
//    NSLog(@"Processing applicationWillFinishLaunching event");
//    
//    //[NSThread detachNewThreadSelector:@selector(initApp:) toTarget:self withObject:nil];
//    
//    
//    //
//    // mclInitializeApplication must be called to use a MATLAB shared library
//    // component.
//    //
//    if (!mclInitializeApplication(NULL,0))
//    {
//        NSLog(@"mclInitializeApplication failed");
//        return;
//    }
//    //
//    // libsierpinskiInitialize must be called to initialize
//    // the MATLAB shared library component.
//    //
//    if (!libaddmatrixInitialize())
//    {
//        NSLog(@"libsierpinskiInitialize failed");
//        return;
//    }

}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
