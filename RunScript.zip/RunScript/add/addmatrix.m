function a = addmatrix(b,c)

    [m,n] = size(b);
    [k,p] = size(c);
    
    if([m,n] == [k,p])
        a = b + c
        %disp(['Here is ',mat2str(m)])
    return
end


