#!/bin/sh

exe_name=$0
exe_dir=`dirname "$0"`

eval echo "Hers" >>${exe_dir}/hello.txt