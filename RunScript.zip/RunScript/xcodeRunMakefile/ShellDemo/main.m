//
//  main.m
//  ShellDemo
//
//  Created by apple on 7/28/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
