//
// MATLAB Compiler: 6.0 (R2015a)
// Date: Thu Jul 28 10:50:58 2016
// Arguments: "-B" "macro_default" "-W" "cpplib:libsierpinski" "-T" "link:lib"
// "-d" "/Users/apple/Desktop/sierpinski/libsierpinski/for_testing" "-v"
// "/Users/apple/Desktop/sierpinski/sierpinski.m" 
//

#include <stdio.h>
#define EXPORTING_libsierpinski 1
#include "libsierpinski.h"

static HMCRINSTANCE _mcr_inst = NULL;


#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_libsierpinski_C_API
#define LIB_libsierpinski_C_API /* No special import/export declaration */
#endif

LIB_libsierpinski_C_API 
bool MW_CALL_CONV libsierpinskiInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler)
{
    int bResult = 0;
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
    {
        mclCtfStream ctfStream = 
            mclGetEmbeddedCtfStream((void *)(libsierpinskiInitializeWithHandlers));
        if (ctfStream) {
            bResult = mclInitializeComponentInstanceEmbedded(   &_mcr_inst,
                                                                error_handler, 
                                                                print_handler,
                                                                ctfStream);
            mclDestroyStream(ctfStream);
        } else {
            bResult = 0;
        }
    }  
    if (!bResult)
    return false;
  return true;
}

LIB_libsierpinski_C_API 
bool MW_CALL_CONV libsierpinskiInitialize(void)
{
  return libsierpinskiInitializeWithHandlers(mclDefaultErrorHandler, 
                                             mclDefaultPrintHandler);
}

LIB_libsierpinski_C_API 
void MW_CALL_CONV libsierpinskiTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

LIB_libsierpinski_C_API 
void MW_CALL_CONV libsierpinskiPrintStackTrace(void) 
{
  char** stackTrace;
  int stackDepth = mclGetStackTrace(&stackTrace);
  int i;
  for(i=0; i<stackDepth; i++)
  {
    mclWrite(2 /* stderr */, stackTrace[i], sizeof(char)*strlen(stackTrace[i]));
    mclWrite(2 /* stderr */, "\n", sizeof(char)*strlen("\n"));
  }
  mclFreeStackTrace(&stackTrace, stackDepth);
}


LIB_libsierpinski_C_API 
bool MW_CALL_CONV mlxSierpinski(int nlhs, mxArray *plhs[], int nrhs, mxArray *prhs[])
{
  return mclFeval(_mcr_inst, "sierpinski", nlhs, plhs, nrhs, prhs);
}

LIB_libsierpinski_CPP_API 
void MW_CALL_CONV sierpinski(int nargout, mwArray& x, mwArray& y, const mwArray& 
                             iterations, const mwArray& draw)
{
  mclcppMlfFeval(_mcr_inst, "sierpinski", nargout, 2, 2, &x, &y, &iterations, &draw);
}

