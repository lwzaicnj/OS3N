//
//  AppDelegate.m
//  sierpinski
//
//  Created by apple on 7/28/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationWillFinishLaunching:(NSNotification *)notification{
    NSLog(@"Processing applicationWillFinishLaunching event");
    [txtStatus setStringValue: @"Initializing..."];
    [NSThread detachNewThreadSelector:@selector(initApp:) toTarget:self withObject:nil];
}

- (void)initApp:(id)param
{
    NSLog(@"Executing initialization thread...");
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    //
    // mclInitializeApplication must be called to use a MATLAB shared library
    // component.
    //
    if (!mclInitializeApplication(NULL,0))
    {
        NSString *stringError =
        [NSString stringWithCString:mclGetLastErrorMessage()
                           encoding:NSMacOSRomanStringEncoding];
        [self popDialogue: @"mclInitializeApplicationFailed: " andInformation: stringError];
        [pool release];
        return;
    }
    //
    // libsierpinskiInitialize must be called to initialize
    // the MATLAB shared library component.
    //
    if (!libsierpinskiInitialize())
    {
        NSString *stringError =
        [NSString stringWithCString:mclGetLastErrorMessage()
                           encoding:NSMacOSRomanStringEncoding];
        [self popDialogue: @"component initialization failure: " andInformation: stringError];
        [pool release];
        return;
    }
    [txtStatus setStringValue:@"Initialized"];
    [btnDraw setEnabled: YES];
    [window makeKeyAndOrderFront:nil];
    [pool release];
}


- (IBAction)drawTriangle:(id)sender
{
    NSLog( @"Processing draw triangle button event");
    nIterations = [txtIterations intValue];
    [btnDraw setEnabled: NO];      // Disable button, one request at a time
    [NSThread detachNewThreadSelector:@selector(postTriangleRequest:) toTarget:self withObject:nil];
}

//- (void)postTriangleRequest:(id)param{
//    NSLog(@"Here is selector");
//}

- (void)postTriangleRequest:(id)param
{
    NSLog(@"Thread which will call component library request");
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    if (!nIterations)
    {
        [txtStatus setStringValue: @"Number of iterations defaulted to 7500"];
        nIterations = 7500;
    } else
    {
        [txtStatus setStringValue: [NSString stringWithFormat: @"Using %d iterations", nIterations]];
    }
    //
    // The following few lines, set up and call the MATLAB shared library component.
    mwArray iterations((mxDouble)nIterations);
    mwArray draw(true);
    // Create the output variables
    // The Sierpinski function returns the X and Y coordinates of the points
    // forming the pattern in the triangle.
    mwArray x;
    mwArray y;
    sierpinski(2, x, y, iterations, draw);  // call the shared MATLAB shared library component request
    [btnDraw setEnabled: YES];  // Reenable button, ready for next request
    [pool release];
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender
{
    NSLog(@"Processing applicationShouldTerminate event");
    [NSThread detachNewThreadSelector:@selector(terminateApp:) toTarget:self withObject:sender];
    return NSTerminateLater;
}

-(void)terminateApp:(NSApplication *)theApplication
{
    NSLog(@"Executing termination thread");
    //
    // libsierpinskiTerminate should be called to terminate use
    // of the MATLAB shared library component.
    //
    libsierpinskiTerminate();
    //
    // mclTerminateApplication should be called indicating that all
    // shared library component usage is completed.
    //
    mclTerminateApplication();
    [theApplication replyToApplicationShouldTerminate: YES];//NSTerminateLater 后必須使用這個方法
}


-(void) popDialogue: (NSString *)stringMessage andInformation: (NSString *)stringInformation {
    NSAlert *alert = [[[NSAlert alloc] init] autorelease];
    [alert addButtonWithTitle:@"OK"];
    [alert setMessageText:stringMessage];
    [alert setInformativeText:stringInformation];
    [alert setAlertStyle:NSWarningAlertStyle];
    [alert runModal];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender{
    NSLog(@"Processing applicationShouldTerminateAfterLastWindowClosed event");
    return YES;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
//    NSLog(@"Processing applicationWillFinishLaunching event");
//    [txtStatus setStringValue: @"Initializing..."];
//    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
//    //[NSThread detachNewThreadSelector:@selector(initApp:) toTarget:self withObject:nil];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
