//
//  AppDelegate.h
//  sierpinski
//
//  Created by apple on 7/28/16.
//  Copyright (c) 2016 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include "libsierpinski.h"
#include "mclcppclass.h"


@interface AppDelegate : NSObject <NSApplicationDelegate>{
    IBOutlet NSTextField *txtIterations;
    IBOutlet NSWindow *window;
    IBOutlet NSButton *btnDraw;
    IBOutlet NSTextField *txtStatus;
    int nIterations;
}


- (IBAction)drawTriangle:(id)sender;
- (void)postTriangleRequest:(id)param;
- (void)initApp:(id)param;
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender;
- (void)terminateApp:(NSApplication *)theApplication;
- (void) popDialogue: (NSString *)stringMessage andInformation: (NSString *)stringInformation;

@end

